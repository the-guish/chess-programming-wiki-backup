// myopic: A simple chess playing program for small systems
//
// Copyright (C) 2010 by chessnotation@me.com   (Some rights reserved)
//
// License: Creative Commons Attribution-Share Alike 3.0 License
// See: http://creativecommons.org/licenses/by-sa/3.0/
//
// Caution: No warranty; use at your own risk.

// Arduino include files

#include <avr/interrupt.h>
#include <avr/pgmspace.h>

// The Myopic source code file preprocessor include directives

#include "Source/BB.cpp"
#include "Source/BBMoveNode.cpp"
#include "Source/BBPosNode.cpp"
#include "Source/Board.cpp"
#include "Source/Book.cpp"
#include "Source/BookMove.cpp"
#include "Source/CIB.cpp"
#include "Source/CNPair.cpp"
#include "Source/Constants.cpp"
#include "Source/Counter.cpp"
#include "Source/FEnv.cpp"
#include "Source/FPos.cpp"
#include "Source/Hash.cpp"
#include "Source/History.cpp"
#include "Source/ICP.cpp"
#include "Source/ICPTest.cpp"
#include "Source/ICPCommands.cpp"
#include "Source/MGS.cpp"
#include "Source/ML.cpp"
#include "Source/Move.cpp"
#include "Source/Myopic.cpp"
#include "Source/PEnv.cpp"
#include "Source/PIR.cpp"
#include "Source/PVTable.cpp"
#include "Source/Pos.cpp"
#include "Source/PosCountMoves.cpp"
#include "Source/PosEvaluate.cpp"
#include "Source/PosGenerate.cpp"
#include "Source/PosMotion.cpp"
#include "Source/PosNoMoves.cpp"
#include "Source/SAN.cpp"
#include "Source/SS.cpp"
#include "Source/SSKing.cpp"
#include "Source/SSKnight.cpp"
#include "Source/Score.cpp"
#include "Source/Search.cpp"
#include "Source/SearchAB.cpp"
#include "Source/SearchMP.cpp"
#include "Source/State.cpp"
#include "Source/TBV.cpp"
#include "Source/TinyMove.cpp"
#include "Source/UnDo.cpp"
#include "Source/UnDoStack.cpp"
#include "Source/Utilities.cpp"
#include "Source/Window.cpp"
#include "Source/XCP.cpp"

// Configuration constants for optional hardware

static const bool AllowActLED    = true; // Set to allow activity LED output
static const bool AllowAudible   = true; // Set to allow piezo buzzer audible alert
static const bool AllowBackpack  = true; // Set to allow SparkFun RGB LED backpack (needs SPI)
static const bool AllowInterrupt = true; // Set to allow user interrupt zero
static const bool AllowSpi       = true; // Set to allow SPI usage

// The application control stage indicator

static acsType acs = acsInit;

// The application object single instance

static Myopic myopic;

// LED color assignments for chessmen (Don't use LC(1, 1, 1) under any circumstances!)

#define LC(r, g, b) (((r) << 5) | ((g) << 2) | (b))  // Bits: red[765], green[432], blue[10]

static const unsigned char ManToLEDColor[manLen] =
{
  LC(0, 1, 3), LC(0, 2, 3), LC(0, 4, 3), LC(0, 5, 2), LC(0, 6, 1), LC(0, 7, 0),  // White PNBRQK
  LC(1, 0, 3), LC(2, 0, 3), LC(4, 0, 3), LC(5, 0, 2), LC(6, 0, 1), LC(7, 0, 0),  // Black PNBRQK
  LC(0, 0, 0), LC(0, 0, 0)  // Vacant and Extra
};

// Arduino interrupt number for pushbutton interrupt

static const unsigned int userInterrupt = 0;  // Pushbutton interrupt on Mega pin 2

// Arduino Mega pin number for piezo buzzer output

static const unsigned int pinPiezoBuzzer = 12;  // Optional piezo buzzer

// Arduino Mega pin number for activity LED output

static const unsigned int pinActivityLED = 13;  // Standard single LED

// Arduino Mega pin numbers for SPI communication

static const unsigned int pinSpiMISO = 50;  // Master In/Slave Out (not used with SparkFun 8x8 RGB LED backpack)
static const unsigned int pinSpiMOSI = 51;  // Master Out/Slave In
static const unsigned int pinSpiSCK  = 52;  // SPI Clock
static const unsigned int pinSpiSS   = 53;  // Slave Select (selects SparkFun 8x8 RGB LED backpack)

// User interrupt routine

static void Interrupt(void) {myopic.Interrupt();}

// Low level SPI communication routines

static void InitializeSpi(void)
{
  // Initialize the Arduino SPI pin directions

  pinMode(pinSpiMISO, INPUT);
  pinMode(pinSpiMOSI, OUTPUT);
  pinMode(pinSpiSCK,  OUTPUT);
  pinMode(pinSpiSS,   OUTPUT);

  // Initialization of the AVR SPI control register

  SPCR =
    (0 << SPIE) | // Disable SPI interrupt
    (1 << SPE ) | // Enable SPI
    (0 << DORD) | // Most significant bit of byte sent first
    (1 << MSTR) | // AVR is SPI master
    (0 << CPOL) | // Data clock idle when low
    (0 << CPHA) | // Sample data on rising clock rising edge
    (1 << SPR1) | // SPI clock is 1/64 AVR clock (first timing bit)
    (0 << SPR0);  // SPI clock is 1/64 AVR clock (second timing bit)

  // Toss the updated values of the SPI status and data registers

  volatile byte discard;

  discard = SPSR; discard = SPDR;
}

static unsigned char WriteSpiByte(unsigned char data)
{
  SPDR = data;
  while (!(SPSR & (1 << SPIF)));
  return SPDR;
}

static void SetSpiSlaveSelectStatus(const unsigned int status) {digitalWrite(pinSpiSS, status);}

// SparkFun 8x8 RGB LED matrix display routines

static void SparkFunBackpackEnable(void)  {SetSpiSlaveSelectStatus(LOW ); delayMicroseconds(200);}
static void SparkFunBackpackDisable(void) {SetSpiSlaveSelectStatus(HIGH);}

static void SparkFunBackpackSingleColor(const unsigned int ledcolor)
{
  const unsigned int edgeLen = 8;

  SparkFunBackpackEnable();
  for (unsigned int row = 0; row < edgeLen; row++)
    for (unsigned int col = 0; col < edgeLen; col++)
      WriteSpiByte(ledcolor);
  SparkFunBackpackDisable();
}

static void SparkFunBackpackResetDisplay(void) {SparkFunBackpackSingleColor(0x00);}

// Arduino elapsed milliseconds (can be called externally)

unsigned long int TargetElapsedMsec(void) {return millis();}

// Arduino serial input status (can be called externally)

bool TargetSerialAvailable(void) {return Serial.available() > 0;}

// Arduino serial character input (can be called externally)

char TargetSerialInput(void) {return Serial.read();}

// Arduino serial character output (can be called externally)

void TargetSerialOutput(const char ch)
{
  if (ch != '\n') Serial.print(ch, BYTE); else Serial.println();
}

// Arduino random seed (can be called externally)

void TargetRandomSeed(const unsigned int seed) {randomSeed(seed);}

// Arduino random pick (can be called externally)

long int TargetRandomPick(const unsigned int limit) {return random(limit);}

// Control the standard single LED output (can be called externally)

void TargetLEDOutput(const bool flag)
{
  if (AllowActLED) digitalWrite(pinActivityLED, (flag ? HIGH : LOW));
}

// Issue a brief audible alert (can be called externally)

void TargetAudioAlert(void)
{
  if (AllowAudible)
  {
    for (unsigned int index = 0; index < 100; index++)
    {
      digitalWrite(pinPiezoBuzzer, HIGH);
      delayMicroseconds(1000);
      digitalWrite(pinPiezoBuzzer, LOW);
      delayMicroseconds(1000);
    };
  };
}

// Redraw the chessboard display (can be called externally)

void TargetUpdateBackpackBoardDisplay(const Board& board)
{
  if (AllowSpi && AllowBackpack)
  {
    SparkFunBackpackEnable();
    for (rankType rank = 0; rank < rankLen; rank++)
      for (fileType file = 0; file < fileLen; file++)
        WriteSpiByte(ManToLEDColor[board.GetMan(OtherFile(file), OtherRank(rank))]);
    SparkFunBackpackDisable();
  };
}

// Arduino system entry for one time initialization

void setup(void)
{
  // Initialize the only Arduino serial channel in use

  delay(2000); Serial.begin(9600);

  // Initialize the piezo buzzer

  if (AllowAudible) {pinMode(pinPiezoBuzzer, OUTPUT); digitalWrite(pinPiezoBuzzer, LOW);};

  // Initialize the activity LED

  if (AllowActLED) {pinMode(pinActivityLED, OUTPUT); TargetLEDOutput(false);};

  // Initialize the Serial Peripheral Interface

  if (AllowSpi) InitializeSpi();

  // Initialize the user interrupt

  if (AllowInterrupt) attachInterrupt(userInterrupt, Interrupt, RISING);

  // Set the SparkFun 8x8 RGB LED backpack to its default state

  if (AllowSpi && AllowBackpack)
  {
    SparkFunBackpackDisable();
    SparkFunBackpackResetDisplay();
  };
}

// Arduino system entry for main loop

void loop(void)
{
  switch (acs)
  {
    case acsInit: myopic.Init(); acs = acsMain; break;
    case acsMain: myopic.Main(); acs = acsTerm; break;
    case acsTerm: myopic.Term(); acs = acsExit; break;
    default: break;
  };
}
