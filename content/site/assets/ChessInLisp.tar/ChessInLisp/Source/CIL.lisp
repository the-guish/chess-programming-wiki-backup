;;;; CIL.lisp: Chess In Lisp

;;; Copyright 2011 by chessnotation@me.com. All rights reserved.
;;;
;;; Redistribution and use in source and binary forms, with or without modification, are
;;; permitted provided that the following conditions are met:
;;;
;;;    1. Redistributions of source code must retain the above copyright notice, this list of
;;;       conditions and the following disclaimer.
;;;
;;;    2. Redistributions in binary form must reproduce the above copyright notice, this list
;;;       of conditions and the following disclaimer in the documentation and/or other materials
;;;       provided with the distribution.
;;;
;;; THIS SOFTWARE IS PROVIDED BY chessnotation@me.com "AS IS" AND ANY EXPRESS OR IMPLIED
;;; WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
;;; FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL chessnotation@me.com OR
;;; CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
;;; CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
;;; SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
;;; ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
;;; NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
;;; ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
;;;
;;; The views and conclusions contained in the software and documentation are those of the
;;; author and should not be interpreted as representing official policies, either expressed
;;; or implied, of chessnotation@me.com.

;;; The above legalese is derived from the Simplified BSD License (a.k.a. the FreeBSD License).

;;; "Lisp has jokingly been called the most intelligent way to misuse a computer".
;;;
;;;  -- Edsger Dijkstra

;;; http://xkcd.com/297/

;;; ---------- Global proclaimations (pick at most one)

; (proclaim (quote (optimize (compilation-speed 0) (debug 0) (safety 0) (space 0) (speed 3))))
; (proclaim (quote (optimize (compilation-speed 0) (debug 2) (safety 3) (space 0) (speed 0))))

;;; ---------- Identification

(defconstant prog-name "Chess In Lisp Toolkit")
(defconstant prog-date "2011.05.17")
(defconstant prog-year "2011")
(defconstant prog-auth "chessnotation@me.com")

;;; ---------- Some common quoted symbols

(defconstant bitsym     (quote bit)     "The bit symbol; used for bit array element type.")
(defconstant countsym   (quote count)   "The count symbol; used in some alists.")
(defconstant errorsym   (quote error)   "The error symbol; used for some error return values.")
(defconstant fensym     (quote fen)     "The fen symbol; used in some alists.")
(defconstant freqsym    (quote freq)    "The freq symbol; used in some alists.")
(defconstant hnalistsym (quote hnalist) "The hnalist symbol; used to identify a hashnode alist.")
(defconstant isasym     (quote isa)     "The isa symbol; used for an alist type identification slot.")

;;; ---------- General predicate macros

(defmacro eq? (my-form0 my-form1) `(eq ,my-form0 ,my-form1))
(defmacro ne? (my-form0 my-form1) `(not (eq ,my-form0 ,my-form1)))

(defmacro atom? (my-form) `(atom  ,my-form))
(defmacro list? (my-form) `(listp ,my-form))

(defmacro zero?    (my-integer) `(zerop ,my-integer))
(defmacro nonzero? (my-integer) `(not (zerop ,my-integer)))

(defmacro positive? (my-integer) `(plusp  ,my-integer))
(defmacro negative? (my-integer) `(minusp ,my-integer))

(defmacro nonpositive? (my-integer) `(not (plusp  ,my-integer)))
(defmacro nonnegative? (my-integer) `(not (minusp ,my-integer)))

(defmacro one? (my-integer) `(= ,my-integer 1))

(defmacro even? (my-integer) `(evenp ,my-integer))
(defmacro odd?  (my-integer) `(oddp  ,my-integer))

(defmacro null?    (my-form)      `(null ,my-form))
(defmacro notnull? (my-form) `(not (null ,my-form)))

(defmacro bit? (my-bit-index my-integer) `(logbitp ,my-bit-index ,my-integer))

(defmacro stream? (my-stream) `(streamp ,my-stream))

;;; Shift macros

(defmacro 2* (my-integer)
  "Multiply by 2 via a shift."
  `(ash ,my-integer 1))

(defmacro 2/ (my-integer)
  "Divide by 2 via a shift."
  `(ash ,my-integer -1))

;;; Single bit mask construction macro

(defmacro 2^ (my-bit-index)
  "Construct a single element bit mask via a shift."
  `(ash 1 ,my-bit-index))

;;; General control macros

(defmacro dowhile (my-form &body my-body)
  "Construct an indefinite iteration loop; positive sense."
  `(do () ((not ,my-form))
    ,@my-body))

(defmacro dountil (my-form &body my-body)
  "Construct an indefinite iteration loop; negative sense."
  `(do () (,my-form)
    ,@my-body))

;;; ---------- Some ASCII character constants

(defconstant ascii-cr      (code-char 13))
(defconstant ascii-escape  (code-char 27))
(defconstant ascii-hyphen  (code-char 45))
(defconstant ascii-nl      (code-char 10))
(defconstant ascii-quote   (code-char 34))
(defconstant ascii-slash   (code-char 47))
(defconstant ascii-space   (code-char 32))
(defconstant ascii-tab     (code-char  9))

;;; ---------- ANSI escape sequence color constants

(defconstant ansi-color-black   0)
(defconstant ansi-color-red     1)
(defconstant ansi-color-green   2)
(defconstant ansi-color-yellow  3)
(defconstant ansi-color-blue    4)
(defconstant ansi-color-magneta 5)
(defconstant ansi-color-cyan    6)
(defconstant ansi-color-white   7)

;;; ---------- Association list routines

(defun alist-build (my-isa my-symbols)
  "Return a new association list with the given isa and symbols."
  (let ((result nil))
    (dolist (symbol my-symbols)
      (push (cons symbol nil) result))
    (push (cons isasym my-isa) result)
    result))

(defun alist-fetch (my-alist my-symbol)
  "Fetch the value of an existing tag."
  (let ((result nil) (pair (assoc my-symbol my-alist)))
    (if pair
      (setf result (rest pair))
      (error "alist-fetch: missing tag ~S" my-symbol))
  result))

(defun alist-stash (my-alist my-symbol my-value)
  "Change the value of an existing tag."
  (let ((pair (assoc my-symbol my-alist)))
    (if pair
      (setf (rest pair) my-value)
      (error "alist-stash: missing tag ~S" my-symbol)))
    (values))

;;; ---------- Character routines

(defun is-char-digitchar? (my-char)
  "Return t if the given character is a decimal digit."
  (and (char>= my-char (code-char 48)) (char<= my-char (code-char 57))))

(defun is-char-whitespace? (my-char)
  "Return t if the given character is a whitespace character."
  (cond
    ((not my-char)
      (error "is-char-whitespace?: null input"))
    ;
    ((or
      (char= my-char ascii-space)
      (char= my-char ascii-tab)
      (char= my-char ascii-nl)
      (char= my-char ascii-cr))
      t)
    ;
    (t
      nil)))

(defmacro digitchar->integer (my-char)
  "Return the integer value of the given decimal digit character."
  `(- (char-code ,my-char) 48))

(defun char+vec->index (my-char my-char-vec)
  "Return the position of a character in a vector; nil if not found."
  (position my-char my-char-vec))

;;; ---------- Stream routines

(defun open-fs-input (my-pathname)
  "Open a pathname as an input stream; return nil on error."
  (let ((stream (open my-pathname :direction :input :if-does-not-exist nil)))
    (unless (and stream (stream? stream) (input-stream-p stream))
      (setf stream nil))
    stream))

(defun open-fs-output (my-pathname)
  "Open a pathname as an output stream; return nil on error."
  (let ((stream (open my-pathname :direction :output :if-exists :supersede)))
    (unless (and stream (stream? stream) (output-stream-p stream))
      (setf stream nil))
    stream))

;;; ---------- Reading routines

(defmacro get-char (my-stream)
  "Return the next character on an input stream; return nil on end of stream."
  `(read-char ,my-stream nil nil))

(defmacro unget-char (my-stream my-char)
  "Push back the prior character on an input stream."
  `(unread-char ,my-char ,my-stream))

(defmacro read-textline (my-stream)
  "Read a single line of text from the given stream; return nil on eof or error."
  `(read-line ,my-stream nil nil))

(defun skip-whitespace (my-stream)
  "Advance past whitespace characters on the input stream."
  (let ((ch (get-char my-stream)))
    (dowhile (and ch (is-char-whitespace? ch))
      (setf ch (get-char my-stream)))
    (when ch
      (unget-char my-stream ch)))
  (values))

(defun is-token-end-ok? (my-stream)
  "Return t if the next character on the given stream is EOF or whitespace."
  (let ((result nil) (ch (get-char my-stream)))
    (cond
      ((not ch)
        (setf result t))
      ((is-char-whitespace? ch)
        (unget-char my-stream ch)
        (setf result t))
      (t
        (unget-char my-stream ch)
        (setf result nil)))
    result))

(defun read-unsigned-integer (my-stream)
  "Read a non-negative base ten integer from the given stream; return value or error symbol."
  (let ((result nil) (ch nil))
    (skip-whitespace my-stream)
    (setf ch (get-char my-stream))
    (cond
      ((not ch)
        (setf result errorsym))
      ((not (is-char-digitchar? ch))
        (unget-char my-stream ch)
        (setf result errorsym))
      (t
        (setf result (digitchar->integer ch))
        (setf ch (get-char my-stream))
        (dowhile (and ch (is-char-digitchar? ch))
          (setf result (+ (* result 10) (digitchar->integer ch)))
          (setf ch (get-char my-stream)))
        (when ch
          (unget-char my-stream ch))))
    result))

;;; ---------- Base 16 output routine that uses lower case letters

(defun fmt-hex-digit (my-stream my-hex-digit)
  "Put a hexadecimal digit value on the given stream."
  (format my-stream "~A" (elt "0123456789abcdef" my-hex-digit))
  (values))

;;; ---------- Some ASCII single character output routines

;;; Newline/blank output routines

(defun newline (my-stream)
  "Format a newline on the given stream."
  (format my-stream "~%")
  (values))

(defun blank (my-stream)
  "Format a blank on the given stream."
  (format my-stream " ")
  (values))

(defun blanks (my-stream my-limit)
  "Format a count of blanks on the given stream."
  (dotimes (index my-limit)
    (blank my-stream))
  (values))

;;; ---------- Banner output

(defun fmt-banner (my-stream)
  "Output the program identification banner."
  (format my-stream "~A   Release ~A~%" prog-name prog-date)
  (format my-stream "Copyright (C) ~A by ~A~%" prog-year prog-auth)
  (finish-output my-stream)
  (values))

;;; ---------- ANSI terminal escape output routines

(defun fmt-ansi-fc-bc-bold (my-stream my-fore-color my-back-color my-bold-flag)
  "Set the ANSI color and bold attributes on the given stream."
  (format my-stream "~A[~D;3~D;4~Dm"
    ascii-escape
    (if my-bold-flag 1 0)
    my-fore-color
    my-back-color)
  (values))

(defun fmt-ansi-attributes-reset (my-stream)
  "Reset the ANSI terminal attributes on the given stream."
  (format my-stream "~A[0m" ascii-escape)
  (values))

(defun ansi-screen-clear (my-stream)
  "Clear the screen."
  (format my-stream "~A[2J" ascii-escape)
  (values))

(defun ansi-line-clear-to-to-end (my-stream)
  "Clear from the cursor position to the end of line."
  (format my-stream "~A[K" ascii-escape)
  (values))

(defun ansi-cursor-hide (my-stream)
  "Hide the cursor."
  (format my-stream "~A[?25l" ascii-escape)
  (values))

(defun ansi-cursor-show (my-stream)
  "Hide the cursor."
  (format my-stream "~A[?25h" ascii-escape)
  (values))

(defun ansi-cursor-to-position (my-stream my-col my-row)
  "Move the cursor to the given coodinates."
  (format my-stream "~A[~D;~DH"
    ascii-escape
    (1+ my-row)
    (1+ my-col))
  (values))

(defun ansi-cursor-to-home (my-stream)
  "Move the cursor to the upper left corner of the screen."
  (ansi-cursor-to-position my-stream 0 0)
  (values))

(defun ansi-screen-reset (my-stream)
  "Move the cursor to the home position and erase the screen."
  (ansi-cursor-to-home my-stream)
  (ansi-screen-clear my-stream)
  (values))

;;; ---------- SI suffixes

(defconstant si-limit 8)
(defconstant si-lower-vec (make-array si-limit :initial-contents "munpfazy"))
(defconstant si-upper-vec (make-array si-limit :initial-contents "KMGTPEZY"))

(defun calc-si-list (my-value)
  "Return a list of a scaled value and the appropriate SI character suffix character."
  (let ((scaled-value (abs (float my-value))) (suffix nil) (index 0))
    (cond
      ((zero? scaled-value)
        nil)
      ((>= scaled-value 1000)
        (dowhile (and (>= scaled-value 1000) (< index si-limit))
          (setf scaled-value (/ scaled-value 1000))
          (incf index))
        (setf suffix (svref si-upper-vec (1- index))))
      ((< scaled-value 1)
        (dowhile (and (< scaled-value 1) (< index si-limit))
          (setf scaled-value (* scaled-value 1000))
          (incf index))
        (setf suffix (svref si-lower-vec (1- index))))
      (t nil))
    (when (negative? my-value)
      (setf scaled-value (- scaled-value)))
    (list scaled-value suffix)))

(defun encode-si-value (my-stream my-value my-unit-str)
  "Encode an SI value with a dimensional unit string suffix."
  (let* ((vs-pair (calc-si-list my-value)) (value (first vs-pair)) (suffix (second vs-pair)))
    (format my-stream "~F " (float value))
    (when suffix
      (format my-stream "~A" suffix))
    (format my-stream "~A" my-unit-str))
  (values))

(defun encode-si-frequency (my-stream my-frequency)
  "Encode an SI frequency (Hz)."
  (encode-si-value my-stream my-frequency "Hz")
  (values))

(defun frequency->string (my-frequency)
  "Encode a frequency to a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-si-frequency str-stream my-frequency)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun encode-si-time (my-stream my-seconds)
  "Encode an SI time (s)."
  (encode-si-value my-stream my-seconds "s")
  (values))

(defun time->string (my-seconds)
  "Encode a time to a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-si-time str-stream my-seconds)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

;;; ---------- Pseudorandom number generation

(defconstant prng-state-limit 31)

(defconstant prng-prime1-vec
  (make-array prng-state-limit
    :initial-contents
      (vector
          2   3   5   7  11  13  17  19
         23  29  31  37  41  43  47  53
         59  61  67  71  73  79  83  89
         97 101 103 107 109 113 127)))

(defconstant prng-prime2-vec
  (make-array prng-state-limit
    :initial-contents
      (vector
          4   6  10  14  22  26  34  38
         46  58  62  74  82  86  94 106
        118 122 134 142 146 158 166 178
        194 202 206 214 218 226 254)))

(defun new-prng-state ()
  "Return a new PRNG state."
  (make-array prng-state-limit :initial-element 0))

(defun prng-state-advance (my-prng-state)
  "Advance the given PRNG by one step."
  (dotimes (index prng-state-limit)
    (incf (svref my-prng-state index))
    (when (= (svref my-prng-state index) (svref prng-prime2-vec index))
      (setf (svref my-prng-state index) 0)))
  (values))

(defun prng-state-parity-odd? (my-prng-state)
  "Determine if the current bit of the given PRNG is set (i.e., odd parity calculaton)."
  (let ((result nil))
    (dotimes (index prng-state-limit)
      (when (>= (svref my-prng-state index) (svref prng-prime1-vec index))
        (setf result (not result))))
    result))

(defun prng-next-bit (my-prng-state)
  "Generate a pseudorandom bit and then advance the given PRNG state."
  (let ((result (prng-state-parity-odd? my-prng-state)))
    (prng-state-advance my-prng-state)
    result))

(defun prng-random-bits (my-prng-state my-bitcount)
  "Return the next N bits from the given PRNG state as an integer."
  (let ((result 0))
    (dotimes (index my-bitcount)
      (setf result (+ (2* result) (if (prng-next-bit my-prng-state) 1 0))))
    result))

(defun new-seeded-prng-state ()
  "Return a new PRNG state seeded with the Lisp library random routine."
  (let ((result (new-prng-state)))
    (dotimes (index prng-state-limit)
      (setf (svref result index) (2* (random (svref prng-prime1-vec index)))))
    (when (odd? (random 2))
      (prng-state-advance result))
    result))

;;; ---------- Constant value single active bit vector

(defconstant sab-limit (integer-length most-positive-fixnum) "Length of the single active bit vector")

(defun constant-sab-vec ()
  "Constant value of the single active bit vector."
  (let ((result (make-array sab-limit :initial-element 0)))
    (dotimes (index sab-limit)
      (setf (svref result index) (2^ index)))
    result))

(defvar sab-vec nil "The single active bit vector")

(defmacro index->bit (my-index) `(svref sab-vec ,my-index))

;;; ---------- Time unit ratios

(defconstant msec-per-second   1000 "Milliseconds in a second")
(defconstant second-per-minute   60 "Seconds in a minute")
(defconstant minute-per-hour     60 "Minutes in an hour")
(defconstant hour-per-day        24 "Hours in a day")

(defconstant msec-per-minute (* msec-per-second second-per-minute))
(defconstant msec-per-hour   (* msec-per-minute minute-per-hour))
(defconstant msec-per-day    (* msec-per-hour   hour-per-day))

;;; ---------- Time calculation routines

(defun situ->msec (my-situ)
  "Convert to milliseconds from system implementation time units."
  (values (floor (* msec-per-second (/ my-situ internal-time-units-per-second)))))

(defun msec->situ (my-msec)
  "Convert to system implementation time units from milliseconds."
  (values (floor (* internal-time-units-per-second (/ my-msec msec-per-second)))))

(defun msec->seconds (my-msec)
  "Convert milliseconds to seconds."
  (float (/ my-msec msec-per-second)))

(defun seconds->msec (my-sec)
  "Convert seconds to milliseconds."
  (float (* my-sec msec-per-second)))

(defun fetch-cb-msec ()
  "Return an integer representing the current base milliseconds count."
  (values (floor (situ->msec (get-internal-real-time)))))

(defun calc-seconds-delta (my-ituc0 my-ituc1)
  "Return the time difference in float seconds between the first and second times."
  (float (/ (- my-ituc1 my-ituc0) internal-time-units-per-second)))

;; Millisecond formatting

(defun encode-msec-as-seconds (my-stream my-msec)
  "Encode a millisecond count as decimal seconds with three post-radix digits."
  (format my-stream "~5,3F" (msec->seconds my-msec)))

;;; ---------- Structure timemark

(defstruct
  (timemark
    (:print-function meta-encode-timemark))
  "Value of a point in time."
  (year   0 :type fixnum)  ; Year                  [0-9999]
  (month  0 :type fixnum)  ; Month number          [1-12]
  (date   0 :type fixnum)  ; Day of month number   [1-31]
  (hour   0 :type fixnum)  ; Hour of day           [0-23]
  (minute 0 :type fixnum)  ; Minute of hour        [0-59]
  (second 0 :type fixnum)  ; Second of minute      [0-59]
  (msec   0 :type fixnum)) ; Millisecond of second [0-999]

(defun encode-timemark-date (my-stream my-timemark)
  "Encode the date of a timemark on the given stream."
  (format my-stream "~4,'0D.~2,'0D.~2,'0D"
    (timemark-year  my-timemark)
    (timemark-month my-timemark)
    (timemark-date  my-timemark))
  (values))

(defun timemark-date->string (my-timemark)
  "Encode the date of a timemark on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-timemark-date str-stream my-timemark)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun encode-timemark-time (my-stream my-timemark)
  "Encode the time of a timemark on the given stream."
  (format my-stream "~2,'0D:~2,'0D:~2,'0D"
    (timemark-hour   my-timemark)
    (timemark-minute my-timemark)
    (timemark-second my-timemark))
  (values))

(defun timemark-time->string (my-timemark)
  "Encode the time of a timemark on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-timemark-time str-stream my-timemark)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun encode-timemark (my-stream my-timemark)
  "Encode the date and time of a timemark on the given stream."
  (encode-timemark-date my-stream my-timemark)
  (blank my-stream)
  (encode-timemark-time my-stream my-timemark)
  (values))

(defun meta-encode-timemark (my-timemark my-stream my-level)
  "Glue to encode a timemark structure."
  (declare (ignore my-level))
  (encode-timemark my-stream my-timemark)
  (values))

(defun timemark->string (my-timemark)
  "Encode a timemark on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-timemark str-stream my-timemark)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun calc-timemark-from-tm-list (my-tm-list)
  "Return a new timemark calculated from a timemark list."
  (make-timemark
    :year   (sixth  my-tm-list)
    :month  (fifth  my-tm-list)
    :date   (fourth my-tm-list)
    :hour   (third  my-tm-list)
    :minute (second my-tm-list)
    :second (first  my-tm-list)
    :msec   0))

;;; Current LTZ/UTC time marks

(defun current-ltz->timemark ()
  "Return a timemark with the current local time zone time."
  (calc-timemark-from-tm-list (multiple-value-list (get-decoded-time))))

(defun current-utc->timemark ()
  "Return a timemark with the current UTC time."
  (calc-timemark-from-tm-list (multiple-value-list (decode-universal-time (get-universal-time) 0))))

;;; Current LTZ/UTC strings

(defun current-ltz->string ()
  "Return a string with the current local time zone time."
  (timemark->string (current-ltz->timemark)))

(defun current-utc->string ()
  "Return a string with the current UTC time."
  (timemark->string (current-utc->timemark)))

;;; ---------- Structure clockface

(defstruct
  (clockface
    (:print-function meta-encode-clockface))
  "Time components for DDD.HH:MM:SS.mmm."
  (days    0 :type fixnum)  ; Day count             [0-999]
  (hours   0 :type fixnum)  ; Hour of day           [0-23]
  (minutes 0 :type fixnum)  ; Minute of hour        [0-59]
  (seconds 0 :type fixnum)  ; Second of minute      [0-59]
  (msecs   0 :type fixnum)) ; Millisecond of second [0-999]

(defun encode-clockface (my-stream my-clockface)
  "Encode a clockface (DDD.HH:MM:SS.mmm) on the given stream."
  (format my-stream "~3,'0D.~2,'0D:~2,'0D:~2,'0D.~3,'0D"
    (clockface-days    my-clockface)
    (clockface-hours   my-clockface)
    (clockface-minutes my-clockface)
    (clockface-seconds my-clockface)
    (clockface-msecs   my-clockface))
  (values))

(defun meta-encode-clockface (my-clockface my-stream my-level)
  "Glue to encode a clockface structure."
  (declare (ignore my-level))
  (encode-clockface my-stream my-clockface)
  (values))

(defun clockface->string (my-clockface)
  "Encode a clockface DDD.HH:MM:SS.mmm on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-clockface str-stream my-clockface)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun msec->clockface (my-msec)
  "Return a new clockface initialized with the given millisecond count."
  (let ((result (make-clockface)) (residue my-msec))
    (setf (clockface-days result)    (truncate residue msec-per-day))
    (decf residue (* msec-per-day    (clockface-days result)))
    (setf (clockface-hours result)   (truncate residue msec-per-hour))
    (decf residue (* msec-per-hour   (clockface-hours result)))
    (setf (clockface-minutes result) (truncate residue msec-per-minute))
    (decf residue (* msec-per-minute (clockface-minutes result)))
    (setf (clockface-seconds result) (truncate residue msec-per-second))
    (decf residue (* msec-per-second (clockface-seconds result)))
    (setf (clockface-msecs result) residue)
    result))

(defun msec->string (my-msec)
  "Encode a millisecond value to a clockface string."
  (clockface->string (msec->clockface my-msec)))

;; Frequency and period reporting

(defun report-frequency-and-period (my-stream my-count my-seconds)
  "Generate a report of a frequency and period."
  (format my-stream "Count: ~:D   Elapsed: ~F   Frequency: ~A   Period: ~A"
    my-count
    (float my-seconds)
    (if (nonzero? my-seconds) (frequency->string (/ my-count (float my-seconds))) "-")
    (if (nonzero? my-count) (time->string (/ my-seconds (float my-count))) "-"))
  (values))

;;; ---------- Structure simpletimer

(defstruct
  (simpletimer
    (:print-function meta-encode-simpletimer))
  "A simpletimer that can count up or down in real time."
  (up-flag      nil)               ; Count up flag, assigned once at construction time
  (cr-flag      nil)               ; Currently running flag
  (initial-msec 0 :type integer)   ; Initial value in milliseconds (constant)
  (current-msec 0 :type integer)   ; Current value in milliseconds
  (updated-msec 0 :type integer))  ; Time of last update in milliseconds (system specific real-time base)

(defun simpletimer-update (my-simpletimer)
  "Update a simpletimer."
  (let ((new-cb-msec (fetch-cb-msec)) (old-cb-msec (simpletimer-updated-msec my-simpletimer)))
    (setf (simpletimer-updated-msec my-simpletimer) new-cb-msec)
    (when (simpletimer-cr-flag my-simpletimer)
      (let ((delta-msec (- new-cb-msec old-cb-msec)))
        (if (simpletimer-up-flag my-simpletimer)
          (incf (simpletimer-current-msec my-simpletimer) delta-msec)
          (if (>= (simpletimer-current-msec my-simpletimer) delta-msec)
            (decf (simpletimer-current-msec my-simpletimer) delta-msec)
            (setf (simpletimer-current-msec my-simpletimer) 0))))))
  my-simpletimer)

(defun encode-simpletimer (my-stream my-simpletimer)
  "Encode a simple simpletimer on the given stream."
  (simpletimer-update my-simpletimer)
  (let ((clockface (msec->clockface (simpletimer-current-msec my-simpletimer))))
    (encode-clockface my-stream clockface))
  (values))

(defun meta-encode-simpletimer (my-simpletimer my-stream my-level)
  "Glue to encode a simpletimer structure."
  (declare (ignore my-level))
  (encode-simpletimer my-stream my-simpletimer)
  (values))

(defun simpletimer->string (my-simpletimer)
  "Encode a simpletimer on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-simpletimer str-stream my-simpletimer)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun simpletimer-reset (my-simpletimer)
  "Reset the given simpletimer to its initial value."
  (setf (simpletimer-cr-flag      my-simpletimer) nil)
  (setf (simpletimer-current-msec my-simpletimer) (simpletimer-initial-msec my-simpletimer))
  (setf (simpletimer-updated-msec my-simpletimer) (fetch-cb-msec))
  (values))

(defun new-simpletimer-cd (my-runflag my-msec)
  "Return a new count-down simpletimer starting from the given millisecond count."
  (make-simpletimer
    :up-flag      nil
    :cr-flag      my-runflag
    :initial-msec my-msec
    :current-msec my-msec
    :updated-msec (fetch-cb-msec)))

(defun new-simpletimer-cu (my-runflag)
  "Return a new count-up simpletimer starting from zero."
  (make-simpletimer
    :up-flag      t
    :cr-flag      my-runflag
    :initial-msec 0
    :current-msec 0
    :updated-msec (fetch-cb-msec)))

(defmacro is-simpletimer-running? (my-simpletimer)      `(simpletimer-cr-flag ,my-simpletimer))
(defmacro is-simpletimer-stopped? (my-simpletimer) `(not (simpletimer-cr-flag ,my-simpletimer)))

(defun is-simpletimer-zero? (my-simpletimer)
  "Return t if the given simpletimer is at zero."
  (simpletimer-update my-simpletimer)
  (zero? (simpletimer-current-msec my-simpletimer)))

(defun simpletimer-start (my-simpletimer)
  "Turn on the given simpletimer."
  (unless (simpletimer-cr-flag my-simpletimer)
    (simpletimer-update my-simpletimer)
    (setf (simpletimer-cr-flag my-simpletimer) t))
  (values))

(defun simpletimer-stop (my-simpletimer)
  "Turn off the given simpletimer."
  (when (simpletimer-cr-flag my-simpletimer)
    (simpletimer-update my-simpletimer)
    (setf (simpletimer-cr-flag my-simpletimer) nil))
  (values))

(defun simpletimer->msec (my-simpletimer)
  "Return the integer value of the number of milliseconds on a simpletimer."
  (simpletimer-update my-simpletimer)
  (simpletimer-current-msec my-simpletimer))

(defun simpletimer->seconds (my-simpletimer)
  "Return the floating value of the number of seconds on a simpletimer."
  (float (/ (simpletimer->msec my-simpletimer) msec-per-second)))

(defun encode-simpletimer-fpr (my-stream my-simpletimer my-count)
  "Encode a frequency and period report from a simpletimer and an event count."
  (simpletimer-update my-simpletimer)
  (report-frequency-and-period
    my-stream
    my-count
    (msec->seconds (simpletimer-current-msec my-simpletimer))))

(defun new-cdt (my-minute)
  "Return a new, stopped count-down timer with the given number of minutes."
  (new-simpletimer-cd nil (* my-minute msec-per-minute)))

;;; ---------- Application context option flags

(defconstant acof-dbg0  0 "Debug: switch 0")
(defconstant acof-dbg1  1 "Debug: switch 1")
(defconstant acof-sssr  2 "Output a search summary statistics report")
(defconstant acof-trcv  3 "Trace: current variation")
(defconstant acof-trfv  4 "Trace: first time down variation")
(defconstant acof-trmo  5 "Trace: ply zero move ordering")
(defconstant acof-trps  6 "Trace: preliminary scoring operations")
(defconstant acof-trpv  7 "Trace: predicted variation")
(defconstant acof-trpz  8 "Trace: ply zero operations")
(defconstant acof-trsi  9 "Trace: search iteration")
(defconstant acof-trst 10 "Trace: search termination")

(defconstant acof-limit (1+ acof-trst) "Number of different application control option flags")

(defconstant acof-index-list
  (list
    acof-dbg0 acof-dbg1 acof-sssr acof-trcv acof-trfv acof-trmo acof-trps acof-trpv
    acof-trpz acof-trsi acof-trst))

(defmacro doacofs ((my-acof-var) &body my-body)
  "Construct a per application context flag iteration loop."
  `(dolist (,my-acof-var acof-index-list)
    ,@my-body))

(defmacro make-acofbits () `(make-array acof-limit :element-type bitsym :initial-element 0))

(defmacro acofbits-clone (my-acofbits) `(copy-seq ,my-acofbits))

(defmacro is-acof-set? (my-acofbits my-acof)
  "Determine if the given move flag is set."
  `(one? (sbit ,my-acofbits ,my-acof)))

(defmacro is-acof-reset? (my-acofbits my-acof)
  "Determine if the given move flag is reset."
  `(zero? (sbit ,my-acofbits ,my-acof)))

(defmacro acofbits-set-flag (my-acofbits my-acof)
  "Set an acof bit."
  `(setf (sbit ,my-acofbits ,my-acof) 1))

(defmacro acofbits-reset-flag (my-acofbits my-acof)
  "Reset an acof bit."
  `(setf (sbit ,my-acofbits ,my-acof) 0))

(defconstant acof-string-vec
  (make-array acof-limit
    :initial-contents
      (vector
        "dbg0" "dbg1" "sssr" "trcv" "trfv" "trmo" "trps" "trpv"
        "trpz" "trsi" "trst")))

(defmacro acof->string (my-acof) `(svref acof-string-vec ,my-acof))

(defun encode-acofbits (my-stream my-acofbits)
  "Encode the acofbits on the given stream."
  (format my-stream "[")
  (let ((needspace nil))
    (doacofs (acof)
      (when (is-acof-set? my-acofbits acof)
        (when needspace
          (blank my-stream))
        (format my-stream "~A" (acof->string acof))
        (setf needspace t))))
  (format my-stream "]")
  (values))

(defun acofbits->string (my-acofbits)
  "Encode the acofbits on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-acofbits str-stream my-acofbits)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

;;; ---------- Structure slim

(defstruct
  (slim
    (:print-function meta-encode-slim))
  "A search limitation structure."
  (iter nil)  ; Iteration limit; nil if none
  (msec nil)  ; Millisecond limit; nil if none
  (nc   nil)) ; Nodecount limit; nil if none

(defun encode-slim (my-stream my-slim)
  "Encode the slim on the given stream."
  (format my-stream "Draft: ~A   Node count: ~A   Time: ~A"
    (if (slim-iter my-slim) (format nil "~R ply" (slim-iter my-slim)) "-")
    (if (slim-nc   my-slim) (format nil "~:D" (slim-nc my-slim)) "-")
    (if (slim-msec my-slim) (format nil "~A" (msec->string (slim-msec my-slim))) "-"))
  (values))

(defun meta-encode-slim (my-slim my-stream my-level)
  "Glue to encode a slim structure."
  (declare (ignore my-level))
  (encode-slim my-stream my-slim)
  (values))

(defun slim->string (my-slim)
  "Encode the slim on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-slim str-stream my-slim)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun slim-clone (my-slim)
  "Return a clone of the given slim."
  (make-slim :iter (slim-iter my-slim) :msec (slim-msec my-slim) :nc (slim-nc my-slim)))

;;; ---------- Structure acs

(defstruct
  (acs)
  "An application context structure; has a single instance and is used to avoid excess global variables."
  (acofbits   (make-acofbits))         ; Application control option flags
  (ostream    *standard-output*)       ; Default output stream
  (prng-state (new-seeded-prng-state)) ; Default PRNG state
  (stcu       (new-simpletimer-cu t))  ; Active simpletimer counting up; set once at application start
  (slim       (make-slim :msec 5000))) ; Default search limiter (five second search)

;;; The single instance of an application context structure; initialized at end of toolkit source

(defvar *acs* nil "The global application context structure")

;;; Application general PRNG (not used for hash code generation)

(defun acs-prng-random-bits (my-bitcount)
  "Return the next N bits from the *acs* PRNG state as an integer."
  (prng-random-bits (acs-prng-state *acs*) my-bitcount))

(defun acs-random (my-integer)
  "Return a random number in zero to (my-integer - 1), with my-integer > 1."
  (let ((result nil) (bitcount (integer-length my-integer)))
    (dowhile (not result)
      (let ((bits (acs-prng-random-bits bitcount)))
        (when (< bits my-integer)
          (setf result bits))))
    result))

;;; Global flag tests

(defmacro is-gf-set?   (my-acof) `(is-acof-set?   (acs-acofbits *acs*) ,my-acof))
(defmacro is-gf-reset? (my-acof) `(is-acof-reset? (acs-acofbits *acs*) ,my-acof))

;;; ---------- Chessboard files

(defconstant file-a 0 "Queen rook file")
(defconstant file-b 1 "Queen knight file")
(defconstant file-c 2 "Queen bishop file")
(defconstant file-d 3 "Queen file")
(defconstant file-e 4 "King file")
(defconstant file-f 5 "King bishop file")
(defconstant file-g 6 "King knight file")
(defconstant file-h 7 "King rook file")

(defconstant file-limit (1+ file-h) "Number of chessboard files")

(defconstant file-index-list (list file-a file-b file-c file-d file-e file-f file-g file-h))

(defmacro dofiles ((my-file-var) &body my-body)
  "Construct a per file iteration loop."
  `(dolist (,my-file-var file-index-list)
    ,@my-body))

(defconstant file-char-vec (make-array file-limit :initial-contents "abcdefgh"))

(defmacro file->char (my-file) `(svref file-char-vec ,my-file))
(defmacro file->string (my-file) `(string (file->char ,my-file)))

(defmacro char->file (my-char) `(char+vec->index ,my-char file-char-vec))

(defun valid-file? (my-file)
  "Determine if the given file is valid."
  (and (>= my-file file-a) (<= my-file file-h)))

(defmacro other-file (my-file) `(- file-h ,my-file))

;;; ---------- Chessboard ranks

(defconstant rank-1 0 "White's first rank   / Black's eighth rank" )
(defconstant rank-2 1 "White's second rank  / Black's seventh rank")
(defconstant rank-3 2 "White's third rank   / Black's sixth rank"  )
(defconstant rank-4 3 "White's fourth rank  / Black's fifth rank"  )
(defconstant rank-5 4 "White's fifth rank   / Black's fourth rank" )
(defconstant rank-6 5 "White's sixth rank   / Black's third rank"  )
(defconstant rank-7 6 "White's seventh rank / Black's second rank" )
(defconstant rank-8 7 "White's eighth rank  / Black's first rank"  )

(defconstant rank-limit (1+ rank-8) "Number of chessboard ranks")

(defconstant rank-index-list (list rank-1 rank-2 rank-3 rank-4 rank-5 rank-6 rank-7 rank-8))

(defmacro doranks ((my-rank-var) &body my-body)
  "Construct a per rank iteration loop."
  `(dolist (,my-rank-var rank-index-list)
    ,@my-body))

(defconstant rank-index-rev-list (reverse rank-index-list))

(defconstant rank-char-vec (make-array rank-limit :initial-contents "12345678"))

(defmacro rank->char (my-rank) `(svref rank-char-vec ,my-rank))
(defmacro rank->string (my-rank) `(string (rank->char ,my-rank)))

(defmacro char->rank (my-char) `(char+vec->index ,my-char rank-char-vec))

(defun valid-rank? (my-rank)
  "Determine if the given rank is valid."
  (and (>= my-rank rank-1) (<= my-rank rank-8)))

(defmacro other-rank (my-rank) `(- rank-8 ,my-rank))

;;; ---------- Chessboard squares

(defmacro calc-sq (my-file my-rank)
  "Calculate a square from a file and a rank."
  `(+ ,my-file (* ,my-rank file-limit)))

(defconstant sq-a1 (calc-sq file-a rank-1) "White QR1 / Black QR8")
(defconstant sq-b1 (calc-sq file-b rank-1) "White QN1 / Black QN8")
(defconstant sq-c1 (calc-sq file-c rank-1) "White QB1 / Black QB8")
(defconstant sq-d1 (calc-sq file-d rank-1) "White Q1  / Black Q8" )
(defconstant sq-e1 (calc-sq file-e rank-1) "White K1  / Black K8" )
(defconstant sq-f1 (calc-sq file-f rank-1) "White KB1 / Black KB8")
(defconstant sq-g1 (calc-sq file-g rank-1) "White KN1 / Black KN8")
(defconstant sq-h1 (calc-sq file-h rank-1) "White KR1 / Black KR8")
(defconstant sq-a2 (calc-sq file-a rank-2) "White QR2 / Black QR7")
(defconstant sq-b2 (calc-sq file-b rank-2) "White QN2 / Black QN7")
(defconstant sq-c2 (calc-sq file-c rank-2) "White QB2 / Black QB7")
(defconstant sq-d2 (calc-sq file-d rank-2) "White Q2  / Black Q7" )
(defconstant sq-e2 (calc-sq file-e rank-2) "White K2  / Black K7" )
(defconstant sq-f2 (calc-sq file-f rank-2) "White KB2 / Black KB7")
(defconstant sq-g2 (calc-sq file-g rank-2) "White KN2 / Black KN7")
(defconstant sq-h2 (calc-sq file-h rank-2) "White KR2 / Black KR7")
(defconstant sq-a3 (calc-sq file-a rank-3) "White QR3 / Black QR6")
(defconstant sq-b3 (calc-sq file-b rank-3) "White QN3 / Black QN6")
(defconstant sq-c3 (calc-sq file-c rank-3) "White QB3 / Black QB6")
(defconstant sq-d3 (calc-sq file-d rank-3) "White Q3  / Black Q6" )
(defconstant sq-e3 (calc-sq file-e rank-3) "White K3  / Black K6" )
(defconstant sq-f3 (calc-sq file-f rank-3) "White KB3 / Black KB6")
(defconstant sq-g3 (calc-sq file-g rank-3) "White KN3 / Black KN6")
(defconstant sq-h3 (calc-sq file-h rank-3) "White KR3 / Black KR6")
(defconstant sq-a4 (calc-sq file-a rank-4) "White QR4 / Black QR5")
(defconstant sq-b4 (calc-sq file-b rank-4) "White QN4 / Black QN5")
(defconstant sq-c4 (calc-sq file-c rank-4) "White QB4 / Black QB5")
(defconstant sq-d4 (calc-sq file-d rank-4) "White Q4  / Black Q5" )
(defconstant sq-e4 (calc-sq file-e rank-4) "White K4  / Black K5" )
(defconstant sq-f4 (calc-sq file-f rank-4) "White KB4 / Black KB5")
(defconstant sq-g4 (calc-sq file-g rank-4) "White KN4 / Black KN5")
(defconstant sq-h4 (calc-sq file-h rank-4) "White KR4 / Black KR5")
(defconstant sq-a5 (calc-sq file-a rank-5) "White QR5 / Black QR4")
(defconstant sq-b5 (calc-sq file-b rank-5) "White QN5 / Black QN4")
(defconstant sq-c5 (calc-sq file-c rank-5) "White QB5 / Black QB4")
(defconstant sq-d5 (calc-sq file-d rank-5) "White Q5  / Black Q4" )
(defconstant sq-e5 (calc-sq file-e rank-5) "White K5  / Black K4" )
(defconstant sq-f5 (calc-sq file-f rank-5) "White KB5 / Black KB4")
(defconstant sq-g5 (calc-sq file-g rank-5) "White KN5 / Black KN4")
(defconstant sq-h5 (calc-sq file-h rank-5) "White KR5 / Black KR4")
(defconstant sq-a6 (calc-sq file-a rank-6) "White QR6 / Black QR3")
(defconstant sq-b6 (calc-sq file-b rank-6) "White QN6 / Black QN3")
(defconstant sq-c6 (calc-sq file-c rank-6) "White QB6 / Black QB3")
(defconstant sq-d6 (calc-sq file-d rank-6) "White Q6  / Black Q3" )
(defconstant sq-e6 (calc-sq file-e rank-6) "White K6  / Black K3" )
(defconstant sq-f6 (calc-sq file-f rank-6) "White KB6 / Black KB3")
(defconstant sq-g6 (calc-sq file-g rank-6) "White KN6 / Black KN3")
(defconstant sq-h6 (calc-sq file-h rank-6) "White KR6 / Black KR3")
(defconstant sq-a7 (calc-sq file-a rank-7) "White QR7 / Black QR2")
(defconstant sq-b7 (calc-sq file-b rank-7) "White QN7 / Black QN2")
(defconstant sq-c7 (calc-sq file-c rank-7) "White QB7 / Black QB2")
(defconstant sq-d7 (calc-sq file-d rank-7) "White Q7  / Black Q2" )
(defconstant sq-e7 (calc-sq file-e rank-7) "White K7  / Black K2" )
(defconstant sq-f7 (calc-sq file-f rank-7) "White KB7 / Black KB2")
(defconstant sq-g7 (calc-sq file-g rank-7) "White KN7 / Black KN2")
(defconstant sq-h7 (calc-sq file-h rank-7) "White KR7 / Black KR2")
(defconstant sq-a8 (calc-sq file-a rank-8) "White QR8 / Black QR1")
(defconstant sq-b8 (calc-sq file-b rank-8) "White QN8 / Black QN1")
(defconstant sq-c8 (calc-sq file-c rank-8) "White QB8 / Black QB1")
(defconstant sq-d8 (calc-sq file-d rank-8) "White Q8  / Black Q1" )
(defconstant sq-e8 (calc-sq file-e rank-8) "White K8  / Black K1" )
(defconstant sq-f8 (calc-sq file-f rank-8) "White KB8 / Black KB1")
(defconstant sq-g8 (calc-sq file-g rank-8) "White KN8 / Black KN1")
(defconstant sq-h8 (calc-sq file-h rank-8) "White KR8 / Black KR1")

(defconstant sq-limit (1+ sq-h8) "Number of squares on a chessboard")

(defconstant sq-index-list
  (list
    sq-a1 sq-b1 sq-c1 sq-d1 sq-e1 sq-f1 sq-g1 sq-h1
    sq-a2 sq-b2 sq-c2 sq-d2 sq-e2 sq-f2 sq-g2 sq-h2
    sq-a3 sq-b3 sq-c3 sq-d3 sq-e3 sq-f3 sq-g3 sq-h3
    sq-a4 sq-b4 sq-c4 sq-d4 sq-e4 sq-f4 sq-g4 sq-h4
    sq-a5 sq-b5 sq-c5 sq-d5 sq-e5 sq-f5 sq-g5 sq-h5
    sq-a6 sq-b6 sq-c6 sq-d6 sq-e6 sq-f6 sq-g6 sq-h6
    sq-a7 sq-b7 sq-c7 sq-d7 sq-e7 sq-f7 sq-g7 sq-h7
    sq-a8 sq-b8 sq-c8 sq-d8 sq-e8 sq-f8 sq-g8 sq-h8))

(defmacro dosqs ((my-sq-var) &body my-body)
  "Construct a per square iteration loop."
  `(dolist (,my-sq-var sq-index-list)
    ,@my-body))

(defconstant sq-string-vec
  (make-array sq-limit
    :initial-contents
      (vector
        "a1" "b1" "c1" "d1" "e1" "f1" "g1" "h1"
        "a2" "b2" "c2" "d2" "e2" "f2" "g2" "h2"
        "a3" "b3" "c3" "d3" "e3" "f3" "g3" "h3"
        "a4" "b4" "c4" "d4" "e4" "f4" "g4" "h4"
        "a5" "b5" "c5" "d5" "e5" "f5" "g5" "h5"
        "a6" "b6" "c6" "d6" "e6" "f6" "g6" "h6"
        "a7" "b7" "c7" "d7" "e7" "f7" "g7" "h7"
        "a8" "b8" "c8" "d8" "e8" "f8" "g8" "h8")))

(defmacro sq->string (my-sq) `(svref sq-string-vec ,my-sq))

(defmacro sq->file (my-sq) `(logand ,my-sq  7))
(defmacro sq->rank (my-sq) `(ash    ,my-sq -3))

(defmacro file+rank->sq (my-file my-rank) `(logior (ash ,my-rank 3) ,my-file))

(defmacro other-sq (my-sq) `(logxor ,my-sq 56))

(defun other-meta-sq (my-sq) (if my-sq (other-sq my-sq)))

;;; Square encoding routines

(defun encode-sq (my-stream my-sq)
  "Encode a square into algebraic coordinates on a stream."
  (format my-stream "~A" (sq->string my-sq))
  (values))

(defun encode-sq-meta (my-stream my-sq)
  "Encode a square into algebraic coordinates on a stream; allow for nil square coded as "-"."
  (if my-sq
    (encode-sq my-stream my-sq)
    (format my-stream "-"))
  (values))

;;; Square file/rank delta calculation

(defmacro calc-file-delta (my-sq0 my-sq1)
  "Calculate the file delta from the first square to the second."
  `(- (sq->file ,my-sq1) (sq->file ,my-sq0)))

(defmacro calc-rank-delta (my-sq0 my-sq1)
  "Calculate the rank delta from the first square to the second."
  `(- (sq->rank ,my-sq1) (sq->rank ,my-sq0)))

;;; Square file/rank predicates

(defmacro same-file? (my-sq0 my-sq1)
  "Return t if the two squares are on the same file."
  `(= (sq->file ,my-sq0) (sq->file ,my-sq1)))

(defmacro same-rank? (my-sq0 my-sq1)
  "Return t if the two squares are on the same rank."
  `(= (sq->rank ,my-sq0) (sq->rank ,my-sq1)))

;;; Intersquare distance calculation

(defun calc-taxicab-distance (my-sq0 my-sq1)
  "Calculate the taxicab distance between the first square and the second."
  (+ (abs (calc-file-delta my-sq0 my-sq1)) (abs (calc-rank-delta my-sq0 my-sq1))))

(defun calc-mintaxi-distance (my-sq0 my-sq1)
  "Calculate the minimum file/rank distance between the first square and the second."
  (min (abs (calc-file-delta my-sq0 my-sq1)) (abs (calc-rank-delta my-sq0 my-sq1))))

(defun calc-maxtaxi-distance (my-sq0 my-sq1)
  "Calculate the maximum file/rank distance between the first square and the second."
  (max (abs (calc-file-delta my-sq0 my-sq1)) (abs (calc-rank-delta my-sq0 my-sq1))))

;;; ---------- Center centisquare distance

(defconstant center-centisquare-distance-vec
  (make-array sq-limit
    :initial-contents
      (vector
        424 361 316 300 300 316 361 424
        361 283 224 200 200 224 283 361
        316 224 141 100 100 141 224 316
        300 200 100   0   0 100 200 300
        300 200 100   0   0 100 200 300
        316 224 141 100 100 141 224 316
        361 283 224 200 200 224 283 361
        424 361 316 300 300 316 361 424)))

;;; ---------- Center tropism

(defconstant center-tropism-vec
  (make-array sq-limit
    :initial-contents
      (vector
         0 10 20 30 30 20 10  0
        10 14 22 32 32 22 14 10
        20 22 28 36 36 28 22 20
        30 32 36 42 42 36 32 30
        30 32 36 42 42 36 32 30
        20 22 28 36 36 28 22 20
        10 14 22 32 32 22 14 10
         0 10 20 30 30 20 10  0)))

;;; ---------- Chessboard flanks

(defconstant flank-q 0 "Queen side flank")
(defconstant flank-k 1 "King side flank")

(defconstant flank-limit (1+ flank-k) "Number of chessboard flanks")

(defmacro other-flank (my-flank) `(- flank-k ,my-flank))

(defun sq->flank (my-sq)
  "Return the flank of the given square."
  (if (<= (sq->file my-sq) file-d) flank-q flank-k))

(defconstant flank-edge-file-vec (make-array flank-limit :initial-contents (vector file-a file-h)))

(defmacro flank->edge-file (my-flank) `(svref flank-edge-file-vec ,my-flank))

(defconstant flank-string-vec (make-array flank-limit :initial-contents (vector "queenside" "kingside")))

(defmacro flank->string (my-flank) `(svref flank-string-vec ,my-flank))

(defconstant flank-castling-string-vec (make-array flank-limit :initial-contents (vector "O-O-O" "O-O")))

(defmacro flank->castling-string (my-flank) `(svref flank-castling-string-vec ,my-flank))

;;; ---------- Chessboard homes

(defconstant home-w 0 "White's side half board")
(defconstant home-b 1 "Black's side half board")

(defconstant home-limit (1+ home-b) "Number of chessboard homes")

(defmacro other-home (my-home) `(- home-b ,my-home))

(defun sq->home (my-sq)
  "Return the home of the given square."
  (if (<= (sq->rank my-sq) rank-4) home-w home-b))

(defconstant home-edge-rank-vec (make-array home-limit :initial-contents (vector rank-1 rank-8)))

;;; ---------- Chessboard quadrants

(defconstant quadrant-wq 0 "The sixteen square White queen side quadrant")
(defconstant quadrant-wk 1 "The sixteen square White king side quadrant")
(defconstant quadrant-bq 2 "The sixteen square Black queen side quadrant")
(defconstant quadrant-bk 3 "The sixteen square Black king side quadrant")

(defconstant quadrant-limit (1+ quadrant-bk) "Number of chessboard quadrants")

(defconstant home-flank-quadrant-vec
  (make-array (list home-limit flank-limit)
    :initial-contents
      (vector
        (vector quadrant-wq quadrant-wk)
        (vector quadrant-bq quadrant-bk))))

(defmacro home+flank->quadrant (my-home my-flank) `(aref home-flank-quadrant-vec ,my-home ,my-flank))

(defun sq->quadrant (my-sq)
  "Return the quadrant of the given square."
  (home+flank->quadrant (sq->home my-sq) (sq->flank my-sq)))

;;; ---------- Chessboard directions

(defconstant dir-e    0 "East")
(defconstant dir-n    1 "North")
(defconstant dir-w    2 "West")
(defconstant dir-s    3 "South")
(defconstant dir-ne   4 "Northeast")
(defconstant dir-nw   5 "Northwest")
(defconstant dir-sw   6 "Southwest")
(defconstant dir-se   7 "Southeast")
(defconstant dir-ene  8 "East by northeast")
(defconstant dir-nne  9 "North by northeast")
(defconstant dir-nnw 10 "North by northwest")
(defconstant dir-wnw 11 "West by nothwest")
(defconstant dir-wsw 12 "West by southwest")
(defconstant dir-ssw 13 "South by southwest")
(defconstant dir-sse 14 "South by southeast")
(defconstant dir-ese 15 "East by southeast")

(defconstant dir-slimit (1+ dir-se)  "Number of sweep directions")
(defconstant dir-limit  (1+ dir-ese) "Number of total directions")

(defconstant ortho-dir-list (list dir-e  dir-n  dir-w  dir-s ) "Orthogonal directions")
(defconstant diago-dir-list (list dir-ne dir-nw dir-sw dir-se) "Diagonal directions")

(defconstant sweep-dir-list (append ortho-dir-list diago-dir-list) "Sweep directions")

(defconstant crook-dir-list
  (list dir-ene dir-nne dir-nnw dir-wnw dir-wsw dir-ssw dir-sse dir-ese) "Crooked (knight) directions")

(defconstant dir-index-list (append sweep-dir-list crook-dir-list) "All directions")

(defmacro dodirs ((my-dir-var) &body my-body)
  "Construct a per direction iteration loop."
  `(dolist (,my-dir-var dir-index-list)
    ,@my-body))

(defmacro doorthodirs ((my-orthodir-var) &body my-body)
  "Construct a per orthogonal direction iteration loop."
  `(dolist (,my-orthodir-var ortho-dir-list)
    ,@my-body))

(defmacro dodiagodirs ((my-diagodir-var) &body my-body)
  "Construct a per diagonal direction iteration loop."
  `(dolist (,my-diagodir-var diago-dir-list)
    ,@my-body))

(defmacro dosweepdirs ((my-sweepdir-var) &body my-body)
  "Construct a per sweep direction iteration loop."
  `(dolist (,my-sweepdir-var sweep-dir-list)
    ,@my-body))

(defmacro docrookdirs ((my-crookdir-var) &body my-body)
  "Construct a per crooked (i.e. knight) direction iteration loop."
  `(dolist (,my-crookdir-var crook-dir-list)
    ,@my-body))

;;; Simple direction predicates

(defconstant is-dir-ortho-vec
  (make-array dir-limit
    :initial-contents
      (vector t   t   t   t   nil nil nil nil nil nil nil nil nil nil nil nil)))

(defconstant is-dir-diago-vec
  (make-array dir-limit
    :initial-contents
      (vector nil nil nil nil t   t   t   t   nil nil nil nil nil nil nil nil)))

(defconstant is-dir-sweep-vec
  (make-array dir-limit
    :initial-contents
      (vector t   t   t   t   t   t   t   t   nil nil nil nil nil nil nil nil)))

(defconstant is-dir-crook-vec
  (make-array dir-limit
    :initial-contents
      (vector nil nil nil nil nil nil nil nil t   t   t   t   t   t   t   t  )))

(defmacro is-dir-ortho? (my-dir) `(svref is-dir-ortho-vec ,my-dir))
(defmacro is-dir-diago? (my-dir) `(svref is-dir-diago-vec ,my-dir))
(defmacro is-dir-sweep? (my-dir) `(svref is-dir-sweep-vec ,my-dir))
(defmacro is-dir-crook? (my-dir) `(svref is-dir-crook-vec ,my-dir))

;;; Opposite directions

(defconstant other-dir-vec
  (make-array dir-limit
    :initial-contents
      (vector
        dir-w   dir-s   dir-e   dir-n
        dir-sw  dir-se  dir-ne  dir-nw
        dir-wsw dir-sse dir-ssw dir-ese
        dir-ene dir-nne dir-nnw dir-wnw)) "Opposite direction vector")

(defmacro other-dir (my-dir) `(svref other-dir-vec ,my-dir))

;;; File deltas by direction

(defconstant file-delta-e    1)
(defconstant file-delta-n    0)
(defconstant file-delta-w   -1)
(defconstant file-delta-s    0)
(defconstant file-delta-ne   1)
(defconstant file-delta-nw  -1)
(defconstant file-delta-sw  -1)
(defconstant file-delta-se   1)
(defconstant file-delta-ene  2)
(defconstant file-delta-nne  1)
(defconstant file-delta-nnw -1)
(defconstant file-delta-wnw -2)
(defconstant file-delta-wsw -2)
(defconstant file-delta-ssw -1)
(defconstant file-delta-sse  1)
(defconstant file-delta-ese  2)

(defconstant dir-file-delta-vec
  (make-array dir-limit
    :initial-contents
      (vector
        file-delta-e   file-delta-n   file-delta-w   file-delta-s
        file-delta-ne  file-delta-nw  file-delta-sw  file-delta-se
        file-delta-ene file-delta-nne file-delta-nnw file-delta-wnw
        file-delta-wsw file-delta-ssw file-delta-sse file-delta-ese)))

(defmacro dir->file-delta (my-dir) `(svref dir-file-delta-vec ,my-dir))

;;; Rank deltas by direction

(defconstant rank-delta-e    0)
(defconstant rank-delta-n    1)
(defconstant rank-delta-w    0)
(defconstant rank-delta-s   -1)
(defconstant rank-delta-ne   1)
(defconstant rank-delta-nw   1)
(defconstant rank-delta-sw  -1)
(defconstant rank-delta-se  -1)
(defconstant rank-delta-ene  1)
(defconstant rank-delta-nne  2)
(defconstant rank-delta-nnw  2)
(defconstant rank-delta-wnw  1)
(defconstant rank-delta-wsw -1)
(defconstant rank-delta-ssw -2)
(defconstant rank-delta-sse -2)
(defconstant rank-delta-ese -1)

(defconstant dir-rank-delta-vec
  (make-array dir-limit
    :initial-contents
      (vector
        rank-delta-e   rank-delta-n   rank-delta-w   rank-delta-s
        rank-delta-ne  rank-delta-nw  rank-delta-sw  rank-delta-se
        rank-delta-ene rank-delta-nne rank-delta-nnw rank-delta-wnw
        rank-delta-wsw rank-delta-ssw rank-delta-sse rank-delta-ese)))

(defmacro dir->rank-delta (my-dir) `(svref dir-rank-delta-vec ,my-dir))

;;; Square deltas by direction

(defmacro calc-sq-delta (my-file-delta my-rank-delta)
  "Calculate a square delta from a file delta and a rank delta."
  `(+ ,my-file-delta (* ,my-rank-delta file-limit)))

(defconstant sq-delta-e   (calc-sq-delta file-delta-e   rank-delta-e  ))
(defconstant sq-delta-n   (calc-sq-delta file-delta-n   rank-delta-n  ))
(defconstant sq-delta-w   (calc-sq-delta file-delta-w   rank-delta-w  ))
(defconstant sq-delta-s   (calc-sq-delta file-delta-s   rank-delta-s  ))
(defconstant sq-delta-ne  (calc-sq-delta file-delta-ne  rank-delta-ne ))
(defconstant sq-delta-nw  (calc-sq-delta file-delta-nw  rank-delta-nw ))
(defconstant sq-delta-sw  (calc-sq-delta file-delta-sw  rank-delta-sw ))
(defconstant sq-delta-se  (calc-sq-delta file-delta-se  rank-delta-se ))
(defconstant sq-delta-ene (calc-sq-delta file-delta-ene rank-delta-ene))
(defconstant sq-delta-nne (calc-sq-delta file-delta-nne rank-delta-nne))
(defconstant sq-delta-nnw (calc-sq-delta file-delta-nnw rank-delta-nnw))
(defconstant sq-delta-wnw (calc-sq-delta file-delta-wnw rank-delta-wnw))
(defconstant sq-delta-wsw (calc-sq-delta file-delta-wsw rank-delta-wsw))
(defconstant sq-delta-ssw (calc-sq-delta file-delta-ssw rank-delta-ssw))
(defconstant sq-delta-sse (calc-sq-delta file-delta-sse rank-delta-sse))
(defconstant sq-delta-ese (calc-sq-delta file-delta-ese rank-delta-ese))

(defconstant dir-sq-delta-vec
  (make-array dir-limit
    :initial-contents
      (vector
        sq-delta-e   sq-delta-n   sq-delta-w   sq-delta-s
        sq-delta-ne  sq-delta-nw  sq-delta-sw  sq-delta-se
        sq-delta-ene sq-delta-nne sq-delta-nnw sq-delta-wnw
        sq-delta-wsw sq-delta-ssw sq-delta-sse sq-delta-ese)))

(defmacro dir->sq-delta (my-dir) `(svref dir-sq-delta-vec ,my-dir))

(defun calc-sq-sq-dir (my-sq0 my-sq1)
  "Calculate the direction from the first square to the second square."
  (let
    (
      (f-delta (calc-file-delta my-sq0 my-sq1))
      (r-delta (calc-rank-delta my-sq0 my-sq1))
    )
    (cond
      ((and (zero? f-delta)            (zero? r-delta))
        nil)
      ((and (positive? f-delta)        (zero? r-delta))
        dir-e)
      ((and (zero? f-delta)            (positive? r-delta))
        dir-n)
      ((and (negative? f-delta)        (zero? r-delta))
        dir-w)
      ((and (zero? f-delta)            (negative? r-delta))
        dir-s)
      ((and (= f-delta r-delta)        (positive? f-delta))
        dir-ne)
      ((and (= f-delta (- r-delta))    (negative? f-delta))
        dir-nw)
      ((and (= f-delta r-delta)        (negative? f-delta))
        dir-sw)
      ((and (= f-delta (- r-delta))    (positive? f-delta))
        dir-se)
      ((and (= f-delta file-delta-ene) (= r-delta rank-delta-ene))
        dir-ene)
      ((and (= f-delta file-delta-nne) (= r-delta rank-delta-nne))
        dir-nne)
      ((and (= f-delta file-delta-nnw) (= r-delta rank-delta-nnw))
        dir-nnw)
      ((and (= f-delta file-delta-wnw) (= r-delta rank-delta-wnw))
        dir-wnw)
      ((and (= f-delta file-delta-wsw) (= r-delta rank-delta-wsw))
        dir-wsw)
      ((and (= f-delta file-delta-ssw) (= r-delta rank-delta-ssw))
        dir-ssw)
      ((and (= f-delta file-delta-sse) (= r-delta rank-delta-sse))
        dir-sse)
      ((and (= f-delta file-delta-ese) (= r-delta rank-delta-ese))
        dir-ese)
      (t
        nil))))

;;; Routines and constant storage for the butterfly indexing vector

(defconstant bt-limit 1792 "Each butterfly table is this length instead of 64 * 64.")

(defun constant-butterfly-vec ()
  "Provide a constant value for the butterfly indexing vector."
  (let ((result (make-array (list sq-limit sq-limit) :initial-element nil)) (index 0))
    (dosqs (frsq)
      (dosqs (tosq)
        (when (calc-sq-sq-dir frsq tosq)
          (setf (aref result frsq tosq) index)
          (incf index))))
    result))

(defvar butterfly-vec nil "Map from-square/to-square to butterfly index.")

(defmacro sq+sq->btindex (my-frsq my-tosq)
  "Map a frsq/tosq to a butterfly table index."
  `(aref butterfly-vec ,my-frsq ,my-tosq))

;;; Routines and constant storage for next square along a direction

(defun calc-next-sq (my-sq my-dir)
  "Calculate the next square along a direction; return nil if off the board."
  (let
    (
      (new-file (+ (sq->file my-sq) (dir->file-delta my-dir)))
      (new-rank (+ (sq->rank my-sq) (dir->rank-delta my-dir)))
    )
    (when (and (valid-file? new-file) (valid-rank? new-rank))
      (file+rank->sq new-file new-rank))))

(defun constant-next-sq-vec ()
  "Constant value of the next-sq-vec."
  (let ((result (make-array (list sq-limit dir-limit) :initial-element nil)))
    (dosqs (sq)
      (dodirs (dir)
        (setf (aref result sq dir) (calc-next-sq sq dir))))
    result))

(defvar next-sq-vec nil "Map sq/dir to next sq")

(defmacro sq+dir->sq (my-sq my-dir) `(aref next-sq-vec ,my-sq ,my-dir))

;;; Routines and constant storage for converting a square pair into a direction

(defun constant-sq-sq-dir-vec ()
  "Return the constant value of the sq/sq to direction vector."
  (let ((result (make-array (list sq-limit sq-limit) :initial-element nil)))
    (dosqs (frsq)
      (dosqs (tosq)
        (setf (aref result frsq tosq) (calc-sq-sq-dir frsq tosq))))
    result))

(defvar sq-sq-dir-vec nil "Map sq/sq to dir")

(defmacro sq+sq->dir (my-frsq my-tosq) `(aref sq-sq-dir-vec ,my-frsq ,my-tosq))

;;; Routine and constant storage for converting a square pair into a sweep direction

(defun constant-sq-sq-inline-dir-vec ()
  "Constant value of the sq/sq to sweep direction inline status vector."
  (let ((result (make-array (list sq-limit sq-limit) :initial-element nil)))
    (dosqs (frsq)
      (dosqs (tosq)
        (let ((dir (sq+sq->dir frsq tosq)))
          (when (and dir (is-dir-sweep? dir))
            (setf (aref result frsq tosq) dir)))))
    result))

(defvar sq-sq-inline-dir-vec nil "Map sq/sq to inline sweep direction")

(defmacro sq+sq->inline-dir (my-frsq my-tosq) `(aref sq-sq-inline-dir-vec ,my-frsq ,my-tosq))

;;; Routines and constant storage for converting a square pair into a shadow square

(defun calc-shadow-sq (my-frsq my-tosq)
  "Calculate the shadow square, if any, on the from/to line beyond the to-square."
  (let ((result nil) (dir (sq+sq->inline-dir my-frsq my-tosq)))
    (when dir
      (setf result (sq+dir->sq my-tosq dir)))
    result))

(defun constant-shadow-sq-vec ()
  "Constant value of the sq/sq to shadow square vector."
  (let ((result (make-array (list sq-limit sq-limit) :initial-element nil)))
    (dosqs (frsq)
      (dosqs (tosq)
        (setf (aref result frsq tosq) (calc-shadow-sq frsq tosq))))
    result))

(defvar shadow-sq-vec nil "Map sq/sq to shadow sq")

(defmacro sq+sq->shadow (my-frsq my-tosq) `(aref shadow-sq-vec ,my-frsq ,my-tosq))

;;; Routines and constant storage for converting a square pair into a pathway list of squares

(defun calc-path (my-sq0 my-sq1)
  "Calculate the pathway square list from the first square to the second square."
  (let ((sqs nil) (dir (sq+sq->inline-dir my-sq0 my-sq1)))
    (when dir
      (let ((sq (sq+dir->sq my-sq0 dir)) (delta (dir->sq-delta dir)))
        (dowhile (and sq (/= sq my-sq1))
          (push sq sqs)
          (incf sq delta))))
    (nreverse sqs)))

(defun constant-path-sqs-vec ()
  "Constant value of the sq/sq to pathway square list vector."
  (let ((result (make-array (list sq-limit sq-limit) :initial-element nil)))
    (dosqs (frsq)
      (dosqs (tosq)
        (setf (aref result frsq tosq) (calc-path frsq tosq))))
    result))

(defvar path-sqs-vec nil "Map sq/sq to pathway square list")

(defmacro sq+sq->path-sqs (my-frsq my-tosq) `(aref path-sqs-vec ,my-frsq ,my-tosq))

;;; Routines and constant storage for converting a square pair into a beyond ray list of squares

(defun calc-beyond (my-sq0 my-sq1)
  "Calculate the beyond square list from the first square to the second square."
  (let ((sqs nil) (dir (sq+sq->inline-dir my-sq0 my-sq1)))
    (when dir
      (let ((sq (sq+dir->sq my-sq1 dir)))
        (dowhile sq
          (push sq sqs)
          (setf sq (sq+dir->sq sq dir)))))
    (nreverse sqs)))

(defun constant-beyond-sqs-vec ()
  "Constant value of the sq/sq to beyond square list vector."
  (let ((result (make-array (list sq-limit sq-limit) :initial-element nil)))
    (dosqs (frsq)
      (dosqs (tosq)
        (setf (aref result frsq tosq) (calc-beyond frsq tosq))))
    result))

(defvar beyond-sqs-vec nil "Map sq/sq to beyond square list")

(defmacro sq+sq->beyond-sqs (my-frsq my-tosq) `(aref beyond-sqs-vec ,my-frsq ,my-tosq))

;;; Routines and constant storage for converting a square pair into a beam ray list of squares

(defun calc-beam (my-sq0 my-sq1)
  "Calculate the beam square list from the first square to the second square."
  (let ((sqs nil) (dir (sq+sq->inline-dir my-sq0 my-sq1)))
    (when dir
      (let ((sq (sq+dir->sq my-sq0 dir)))
        (dowhile sq
          (push sq sqs)
          (setf sq (sq+dir->sq sq dir)))))
    (nreverse sqs)))

(defun constant-beam-sqs-vec ()
  "One time initialization of the sq/sq to beam square list vector."
  (let ((result (make-array (list sq-limit sq-limit) :initial-element nil)))
    (dosqs (frsq)
      (dosqs (tosq)
        (setf (aref result frsq tosq) (calc-beam frsq tosq))))
    result))

(defvar beam-sqs-vec nil "Map sq/sq to beam square list")

(defmacro sq+sq->beam-sqs (my-frsq my-tosq) `(aref beam-sqs-vec ,my-frsq ,my-tosq))

;;; ---------- Chessboard bidirections

(defconstant bidir-e  0 "East/West")
(defconstant bidir-n  1 "North/South")
(defconstant bidir-ne 2 "Northeast/Southwest")
(defconstant bidir-nw 3 "Northwest/Southeast")

(defconstant bidir-limit (1+ bidir-nw) "Number of bidirections")

(defconstant dir-bidir-vec
  (make-array dir-limit
    :initial-contents
      (vector
        bidir-e  bidir-n  bidir-e  bidir-n  bidir-ne bidir-nw bidir-ne bidir-nw
        nil      nil      nil      nil      nil      nil      nil      nil)))

(defmacro dir->bidir (my-dir) `(svref dir-bidir-vec ,my-dir))

(defun sq+sq->bidir (my-frsq my-tosq)
  "Return the bidirection, if any, between two squares."
  (let ((dir (sq+sq->inline-dir my-frsq my-tosq)))
    (if dir (dir->bidir dir))))

;;; ---------- Chess colors

(defconstant color-white  0 "The white side")
(defconstant color-black  1 "The black side")
(defconstant color-vacant 2 "The color of a vacant man")
(defconstant color-extra  3 "An extra color; not used much")

(defconstant color-rlimit (1+ color-black) "Number of playing colors")
(defconstant color-limit  (1+ color-extra) "Number of total colors")

(defconstant color-rindex-list (list color-white color-black))
(defconstant color-index-list  (list color-white color-black color-vacant color-extra))

(defmacro docolors ((my-color-var) &body my-body)
  "Construct a per color iteration loop (white/black only)."
  `(dolist (,my-color-var color-rindex-list)
    ,@my-body))

;;; Color characters

(defconstant color-lc-char-vec (make-array color-limit :initial-contents "wb ?"))
(defconstant color-uc-char-vec (make-array color-limit :initial-contents "WB ?"))

(defmacro color->lc-char (my-color) `(svref color-lc-char-vec ,my-color))
(defmacro color->uc-char (my-color) `(svref color-uc-char-vec ,my-color))

(defmacro lc-char->color (my-char) `(char+vec->index ,my-char color-lc-char-vec))
(defmacro uc-char->color (my-char) `(char+vec->index ,my-char color-uc-char-vec))

;;; Color indexed strings

(defconstant color-string-vec  (make-array color-limit :initial-contents (vector "white" "black" "vacant" "extra")))
(defconstant player-string-vec (make-array color-rlimit :initial-contents (vector "White" "Black")))

(defmacro color->string (my-color) `(svref color-string-vec ,my-color))
(defmacro player->string (my-color) `(svref player-string-vec ,my-color))

;;; Simple color predicates

(defmacro is-color-white?  (my-color) `(= ,my-color color-white))
(defmacro is-color-black?  (my-color) `(= ,my-color color-black))
(defmacro is-color-vacant? (my-color) `(= ,my-color color-vacant))

;;; Opposite colors

(defconstant other-color-vec
  (make-array color-limit
    :initial-contents
      (vector color-black color-white color-vacant color-extra)))

(defmacro other-color (my-color) `(svref other-color-vec ,my-color))

;;; Chessboard square colors

(defun calc-square-color (my-sq)
  "Return the color of the given square on a physical chessboard."
  (if (eq? (even? (sq->rank my-sq)) (even? (sq->file my-sq)))
    color-black
    color-white))

(defmacro is-sq-white? (my-sq) `(= (calc-square-color ,my-sq) color-white))
(defmacro is-sq-black? (my-sq) `(= (calc-square-color ,my-sq) color-black))

;;; Ranks by color viewpoint

(defconstant rank1-vec (make-array color-rlimit :initial-contents (vector rank-1 rank-8)))
(defconstant rank2-vec (make-array color-rlimit :initial-contents (vector rank-2 rank-7)))
(defconstant rank3-vec (make-array color-rlimit :initial-contents (vector rank-3 rank-6)))
(defconstant rank4-vec (make-array color-rlimit :initial-contents (vector rank-4 rank-5)))
(defconstant rank5-vec (make-array color-rlimit :initial-contents (vector rank-5 rank-4)))
(defconstant rank6-vec (make-array color-rlimit :initial-contents (vector rank-6 rank-3)))
(defconstant rank7-vec (make-array color-rlimit :initial-contents (vector rank-7 rank-2)))
(defconstant rank8-vec (make-array color-rlimit :initial-contents (vector rank-8 rank-1)))

;;; ---------- Structure chessclock

(defun new-cdt-pair (my-minute-limit)
  "Return a color indexed vector of simpletimers each set with a minute count."
  (vector (new-cdt my-minute-limit) (new-cdt my-minute-limit)))

(defstruct
  (chessclock
    (:print-function meta-encode-chessclock))
  "A chess clock."
  (good   color-vacant)      ; Active timer indicator; vacant -> neither
  (st-vec (new-cdt-pair 5))) ; A pair of stopped countdown timers (five-minute default)

(defun chessclock-update (my-chessclock)
  "Update the given chessclock."
  (let ((st-vec (chessclock-st-vec my-chessclock)))
    (docolors (color)
      (simpletimer-update (svref st-vec color))))
  (values))

(defun encode-chessclock (my-stream my-chessclock)
  "Encode a chessclock [DDD.HH:MM:SS.mmm ^ DDD.HH:MM:SS.mmm] on the given stream."
  (chessclock-update my-chessclock)
  (format my-stream "[~A ~A ~A]"
    (simpletimer->string (svref (chessclock-st-vec my-chessclock) color-white))
    (elt "<>^?" (chessclock-good my-chessclock))
    (simpletimer->string (svref (chessclock-st-vec my-chessclock) color-black)))
  (values))

(defun meta-encode-chessclock (my-chessclock my-stream my-level)
  "Glue to encode a chessclock structure."
  (declare (ignore my-level))
  (encode-chessclock my-stream my-chessclock)
  (values))

(defun chessclock->string (my-chessclock)
  "Encode a chessclock on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-chessclock str-stream my-chessclock)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun chessclock-stop (my-chessclock)
  "Stop a chessclock."
  (let ((good (chessclock-good my-chessclock)))
    (unless (is-color-vacant? good)
      (simpletimer-stop (svref (chessclock-st-vec my-chessclock) good))
      (setf (chessclock-good my-chessclock) color-vacant)))
  (values))

(defun chessclock-start (my-chessclock my-color)
  "Start a chessclock."
  (chessclock-stop my-chessclock)
  (setf (chessclock-good my-chessclock) my-color)
  (simpletimer-start (svref (chessclock-st-vec my-chessclock) my-color))
  (values))

;;; ---------- Chess pieces

(defconstant piece-pawn   0 "Pawn chess piece kind")
(defconstant piece-knight 1 "Knight chess piece kind")
(defconstant piece-bishop 2 "Bishop chess piece kind")
(defconstant piece-rook   3 "Rook chess piece kind")
(defconstant piece-queen  4 "Queen chess piece kind")
(defconstant piece-king   5 "King chess piece kind")
(defconstant piece-vacant 6 "Vacant (no color) chess piece kind")
(defconstant piece-extra  7 "An extra chess piece kind; not used much")

(defconstant piece-rlimit (1+ piece-king)  "Number of playing piece kinds")
(defconstant piece-limit  (1+ piece-extra) "Number of piece kinds")

(defconstant piece-rindex-list
  (list piece-pawn piece-knight piece-bishop piece-rook piece-queen piece-king))

(defmacro dopieces ((my-piece-var) &body my-body)
  "Construct a per piece iteration loop (PNBRQK only)."
  `(dolist (,my-piece-var piece-rindex-list)
    ,@my-body))

(defconstant piece-char-vec (make-array piece-limit :initial-contents "PNBRQK ?"))

(defconstant piece-string-vec
  (make-array piece-limit
    :initial-contents
      (vector "pawn" "knight" "bishop" "rook" "queen" "king" "vacant" "extra")))

(defmacro piece->char   (my-piece) `(svref piece-char-vec   ,my-piece))
(defmacro piece->string (my-piece) `(svref piece-string-vec ,my-piece))

(defconstant is-piece-stepper-vec (make-array piece-limit :initial-contents (vector t   t   nil nil nil t   nil nil)))
(defconstant is-piece-sweeper-vec (make-array piece-limit :initial-contents (vector nil nil t   t   t   nil nil nil)))

(defmacro is-piece-stepper? (my-piece) `(svref is-piece-stepper-vec ,my-piece))
(defmacro is-piece-sweeper? (my-piece) `(svref is-piece-sweeper-vec ,my-piece))

;;; Piece distribution signature increments

(defmacro piece->pdsinc (my-piece) `(2^ (* ,my-piece 4)))

(defconstant piece-increment-vec
  (make-array piece-rlimit
    :initial-contents
      (vector
        (piece->pdsinc piece-pawn)
        (piece->pdsinc piece-knight)
        (piece->pdsinc piece-bishop)
        (piece->pdsinc piece-rook)
        (piece->pdsinc piece-queen)
        (piece->pdsinc piece-king))))

(defmacro piece->increment (my-piece) `(svref piece-increment-vec ,my-piece))

;;; Piece material values (millipawns)

(defconstant value-pawn   1000)
(defconstant value-knight 3150)
(defconstant value-bishop 3300)
(defconstant value-rook   5000)
(defconstant value-queen  9000)
(defconstant value-king      0)
(defconstant value-vacant    0)
(defconstant value-extra     0)

(defconstant piece-value-vec
  (make-array piece-limit
    :initial-contents
      (vector value-pawn value-knight value-bishop value-rook value-queen value-king value-vacant value-extra)))

(defmacro piece->value (my-piece) `(svref piece-value-vec , my-piece))

;;; ---------- Chess men

(defconstant man-wp  0 "White pawn")
(defconstant man-wn  1 "White knight")
(defconstant man-wb  2 "White bishop")
(defconstant man-wr  3 "White rook")
(defconstant man-wq  4 "White queen")
(defconstant man-wk  5 "White king")
(defconstant man-bp  6 "Black pawn")
(defconstant man-bn  7 "Black knight")
(defconstant man-bb  8 "Black bishop")
(defconstant man-br  9 "Black rook")
(defconstant man-bq 10 "Black queen")
(defconstant man-bk 11 "Black king")
(defconstant man-v0 12 "A vacant man")
(defconstant man-x0 13 "An extra man; not used much")

(defconstant man-rlimit (1+ man-bk) "Number oy playing men kinds")
(defconstant man-vlimit (1+ man-v0) "Number of possible different square contents")
(defconstant man-limit  (1+ man-x0) "Number of man kinds")

(defconstant man-rindex-list
  (list man-wp man-wn man-wb man-wr man-wq man-wk man-bp man-bn man-bb man-br man-bq man-bk))

(defconstant man-index-list
  (list man-wp man-wn man-wb man-wr man-wq man-wk man-bp man-bn man-bb man-br man-bq man-bk man-v0 man-x0))

(defmacro domans ((my-man-var) &body my-body)
  "Construct a per man iteration loop (PNBRQKpnbrqk only)."
  `(dolist (,my-man-var man-rindex-list)
    ,@my-body))

(defconstant man-char-vec (make-array man-limit :initial-contents "PNBRQKpnbrqk ?"))

(defmacro man->char (my-man) `(svref man-char-vec ,my-man))

(defmacro char->man (my-char) `(char+vec->index ,my-char man-char-vec))

(defconstant man-string-vec
  (make-array man-limit
    :initial-contents
      (vector "wP" "wN" "wB" "wR" "wQ" "wK" "bP" "bN" "bB" "bR" "bQ" "bK" "  " "??")))

(defmacro man->string (my-man) `(svref man-string-vec ,my-man))

(defconstant man-color-vec
  (make-array man-limit
    :initial-contents
      (vector
         color-white  color-white  color-white  color-white  color-white  color-white
         color-black  color-black  color-black  color-black  color-black  color-black
         color-vacant color-extra)))

(defmacro man->color (my-man) `(svref man-color-vec ,my-man))

(defconstant man-piece-vec
  (make-array man-limit
    :initial-contents
      (vector
         piece-pawn   piece-knight piece-bishop piece-rook   piece-queen  piece-king
         piece-pawn   piece-knight piece-bishop piece-rook   piece-queen  piece-king
         piece-vacant piece-extra)))

(defmacro man->piece (my-man) `(svref man-piece-vec ,my-man))

(defconstant other-man-vec
  (make-array man-limit
    :initial-contents
      (vector
        man-bp man-bn man-bb man-br man-bq man-bk
        man-wp man-wn man-wb man-wr man-wq man-wk
        man-v0 man-x0)))

(defmacro other-man (my-man) `(svref other-man-vec ,my-man))

;;; Sweeper/steeper predicates

(defconstant is-man-stepper-vec
  (make-array man-limit
    :initial-contents
      (vector t   t   nil nil nil t   t   t   nil nil nil t   nil nil)))

(defconstant is-man-sweeper-vec
  (make-array man-limit
    :initial-contents
      (vector nil nil t   t   t   nil nil nil t   t   t   nil nil nil)))

(defmacro is-man-stepper? (my-man) `(svref is-man-stepper-vec ,my-man))
(defmacro is-man-sweeper? (my-man) `(svref is-man-sweeper-vec ,my-man))

;;; Color predicates

(defconstant is-man-white-vec
  (make-array man-limit
    :initial-contents
      (vector t   t   t   t   t   t   nil nil nil nil nil nil nil nil)))

(defconstant is-man-black-vec
  (make-array man-limit
    :initial-contents
      (vector nil nil nil nil nil nil t   t   t   t   t   t   nil nil)))

(defmacro is-man-white? (my-man) `(svref is-man-white-vec ,my-man))
(defmacro is-man-black? (my-man) `(svref is-man-black-vec ,my-man))

;;; Piece predicates

(defconstant is-man-pawn-vec
  (make-array man-limit
    :initial-contents
      (vector t   nil nil nil nil nil t   nil nil nil nil nil nil nil)))

(defconstant is-man-knight-vec
  (make-array man-limit
    :initial-contents
      (vector nil t   nil nil nil nil nil t   nil nil nil nil nil nil)))

(defconstant is-man-bishop-vec
  (make-array man-limit
    :initial-contents
      (vector nil nil t   nil nil nil nil nil t   nil nil nil nil nil)))

(defconstant is-man-rook-vec
  (make-array man-limit
    :initial-contents
      (vector nil nil nil t   nil nil nil nil nil t   nil nil nil nil)))

(defconstant is-man-queen-vec
  (make-array man-limit
    :initial-contents
      (vector nil nil nil nil t   nil nil nil nil nil t   nil nil nil)))

(defconstant is-man-king-vec
  (make-array man-limit
    :initial-contents
      (vector nil nil nil nil nil t   nil nil nil nil nil t   nil nil)))

(defmacro is-man-pawn?   (my-man) `(svref is-man-pawn-vec   ,my-man))
(defmacro is-man-knight? (my-man) `(svref is-man-knight-vec ,my-man))
(defmacro is-man-bishop? (my-man) `(svref is-man-bishop-vec ,my-man))
(defmacro is-man-rook?   (my-man) `(svref is-man-rook-vec   ,my-man))
(defmacro is-man-queen?  (my-man) `(svref is-man-queen-vec  ,my-man))
(defmacro is-man-king?   (my-man) `(svref is-man-king-vec   ,my-man))

;;; Vacancy predicates

(defmacro is-man-vacant? (my-man) `( = ,my-man man-v0))
(defmacro is-man-nonvac? (my-man) `(/= ,my-man man-v0))

;; Man synthesis (general)
;
(defconstant color-piece-man-vec
  (make-array (list color-rlimit piece-rlimit)
    :initial-contents
      (vector
        (vector man-wp man-wn man-wb man-wr man-wq man-wk)
        (vector man-bp man-bn man-bb man-br man-bq man-bk))))

(defmacro color+piece->man (my-color my-piece) `(aref color-piece-man-vec ,my-color ,my-piece))

;;; Man synthesis (piece specific)

(defconstant color-pawn-vec   (make-array color-rlimit :initial-contents (vector man-wp man-bp)))
(defconstant color-knight-vec (make-array color-rlimit :initial-contents (vector man-wn man-bn)))
(defconstant color-bishop-vec (make-array color-rlimit :initial-contents (vector man-wb man-bb)))
(defconstant color-rook-vec   (make-array color-rlimit :initial-contents (vector man-wr man-br)))
(defconstant color-queen-vec  (make-array color-rlimit :initial-contents (vector man-wq man-bq)))
(defconstant color-king-vec   (make-array color-rlimit :initial-contents (vector man-wk man-bk)))

(defmacro color->pawn   (my-color) `(svref color-pawn-vec   ,my-color))
(defmacro color->knight (my-color) `(svref color-knight-vec ,my-color))
(defmacro color->bishop (my-color) `(svref color-bishop-vec ,my-color))
(defmacro color->rook   (my-color) `(svref color-rook-vec   ,my-color))
(defmacro color->queen  (my-color) `(svref color-queen-vec  ,my-color))
(defmacro color->king   (my-color) `(svref color-king-vec   ,my-color))

;;; Man material values (millipawns)

(defconstant value-wp value-pawn  )
(defconstant value-wn value-knight)
(defconstant value-wb value-bishop)
(defconstant value-wr value-rook  )
(defconstant value-wq value-queen )
(defconstant value-wk value-king  )
(defconstant value-bp value-pawn  )
(defconstant value-bn value-knight)
(defconstant value-bb value-bishop)
(defconstant value-br value-rook  )
(defconstant value-bq value-queen )
(defconstant value-bk value-king  )
(defconstant value-v0 value-vacant)
(defconstant value-x0 value-extra )

(defconstant man-value-vec
  (make-array man-limit
    :initial-contents
      (vector
        value-wp value-wn value-wb value-wr value-wq value-wk
        value-bp value-bn value-bb value-br value-bq value-bk
        value-v0 value-x0)))

(defmacro man->value (my-man) `(svref man-value-vec , my-man))

;;; ---------- Chess castlings

(defconstant castling-wq 0 "White queen side castling")
(defconstant castling-wk 1 "White king side castling")
(defconstant castling-bq 2 "Black queen side castling")
(defconstant castling-bk 3 "Black king side castling")

(defconstant castling-limit (1+ castling-bk) "Number of different possible castlings")

(defconstant castling-index-list (list castling-wq castling-wk castling-bq castling-bk))

(defmacro docastlings ((my-castling-var) &body my-body)
  "Construct a per castling iteration loop."
  `(dolist (,my-castling-var castling-index-list)
    ,@my-body))

(defconstant castling-char-vec (make-array castling-limit :initial-contents "QKqk"))

(defmacro castling->char (my-castling) `(svref castling-char-vec ,my-castling))

(defmacro char->castling (my-char) `(char+vec->index ,my-char castling-char-vec))

(defconstant color-castlings-vec
  (make-array color-rlimit :initial-contents (vector (list castling-wq castling-wk) (list castling-bq castling-bk))))

(defmacro color->castlings (my-color) `(svref color-castlings-vec ,my-color))

(defconstant castling-color-vec
  (make-array castling-limit :initial-contents (vector color-white color-white color-black color-black)))

(defmacro castling->color (my-castling) `(svref castling-color-vec ,my-castling))

(defconstant castling-flank-vec
  (make-array castling-limit :initial-contents (vector flank-q flank-k flank-q flank-k)))

(defmacro castling->flank (my-castling) `(svref castling-flank-vec ,my-castling))

(defconstant king-home-vec (make-array castling-limit :initial-contents (vector sq-e1 sq-e1 sq-e8 sq-e8)))
(defconstant king-away-vec (make-array castling-limit :initial-contents (vector sq-c1 sq-g1 sq-c8 sq-g8)))
(defconstant rook-home-vec (make-array castling-limit :initial-contents (vector sq-a1 sq-h1 sq-a8 sq-h8)))
(defconstant rook-away-vec (make-array castling-limit :initial-contents (vector sq-d1 sq-f1 sq-d8 sq-f8)))

(defmacro castling->king-home (my-castling) `(svref king-home-vec ,my-castling))
(defmacro castling->king-away (my-castling) `(svref king-away-vec ,my-castling))
(defmacro castling->rook-home (my-castling) `(svref rook-home-vec ,my-castling))
(defmacro castling->rook-away (my-castling) `(svref rook-away-vec ,my-castling))

(defun cancels-castling? (my-castling my-frsq my-tosq)
  "Determine if the given castling is canceled by the given from and to squares of a move."
  (or
    (= my-frsq (castling->king-home my-castling))
    (= my-frsq (castling->rook-home my-castling))
    (= my-tosq (castling->rook-home my-castling))))

(defconstant other-castling-vec
  (make-array castling-limit :initial-contents (vector castling-bq castling-bk castling-wq castling-wk)))

(defmacro other-castling (my-castling) `(svref other-castling-vec ,my-castling))

(defconstant castling-attack-sqs-vec
  (make-array castling-limit
    :initial-contents (vector (list sq-c1 sq-d1) (list sq-f1 sq-g1) (list sq-c8 sq-d8) (list sq-f8 sq-g8))))

(defmacro castling->attack-sqs (my-castling) `(svref castling-attack-sqs-vec ,my-castling))

(defconstant castling-vacant-sqs-vec
  (make-array castling-limit
    :initial-contents (vector (list sq-b1 sq-c1 sq-d1) (list sq-f1 sq-g1) (list sq-b8 sq-c8 sq-d8) (list sq-f8 sq-g8))))

(defmacro castling->vacant-sqs (my-castling) `(svref castling-vacant-sqs-vec ,my-castling))

;;; ---------- Castling availability bits

(defmacro calc-cast-mask (my-castling)
  "Return a single bit castling availability mask from a castling."
  `(2^ ,my-castling))

(defconstant cast-wq (calc-cast-mask castling-wq) "Bit for White queen side castling")
(defconstant cast-wk (calc-cast-mask castling-wk) "Bit for White king side castling")
(defconstant cast-bq (calc-cast-mask castling-bq) "Bit for Black queen side castling")
(defconstant cast-bk (calc-cast-mask castling-bk) "Bit for Black king side castling")

(defconstant cast-limit (2^ castling-limit) "Number of possible castling combinations")

(defconstant cast-none  0                              "No castlings")
(defconstant cast-white (logior cast-wq cast-wk)       "White castlings")
(defconstant cast-black (logior cast-bq cast-bk)       "Black castlings")
(defconstant cast-full  (logior cast-white cast-black) "All castlings")

(defmacro cast-allows-castling? (my-cast my-castling)
  "Determine if the given castling availability bits value allows the given castling."
  `(bit? ,my-castling ,my-cast))

(defun constant-cast-string-vec ()
  "Constant value of the cast-string-vec."
  (let ((result (make-array cast-limit :initial-element nil)))
    (dotimes (cast cast-limit)
      (let ((str (make-string-output-stream)))
        (if (= cast cast-none)
          (format str "-")
          (dolist (castling (list castling-wk castling-wq castling-bk castling-bq))
            (when (cast-allows-castling? cast castling)
              (format str "~A" (castling->char castling)))))
        (setf (svref result cast) (get-output-stream-string str))))
    result))

(defvar cast-string-vec nil "FEN castling availability strings")

(defmacro cast->string (my-cast) `(svref cast-string-vec ,my-cast))

(defun encode-cast (my-stream my-cast)
  "Encode a castling availability on a stream."
  (format my-stream "~A" (cast->string my-cast))
  (values))

(defun calc-other-cast (my-cast)
  "Formulate the flipped castling availability bits."
  (let ((result cast-none))
    (docastlings (castling)
      (when (cast-allows-castling? my-cast (other-castling castling))
        (setf result (logior result (calc-cast-mask castling)))))
    result))

(defun constant-other-cast-vec ()
  "Constant value for the other-cast-vec."
  (let ((result (make-array cast-limit :initial-element nil)))
    (dotimes (cast cast-limit)
      (setf (svref result cast) (calc-other-cast cast)))
    result))

(defvar other-cast-vec nil "Flipped castling availabily bits")

(defmacro other-cast (my-cast) `(svref other-cast-vec ,my-cast))

;;; ---------- Advance/retreat by color: directions and square deltas

(defconstant color-adv-dir-vec (make-array color-rlimit :initial-contents (vector dir-n dir-s)))
(defconstant color-ret-dir-vec (make-array color-rlimit :initial-contents (vector dir-s dir-n)))

(defmacro color->adv-dir (my-color) `(svref color-adv-dir-vec ,my-color))
(defmacro color->ret-dir (my-color) `(svref color-ret-dir-vec ,my-color))

(defconstant color-adv-delta-vec (make-array color-rlimit :initial-contents (vector sq-delta-n sq-delta-s)))
(defconstant color-ret-delta-vec (make-array color-rlimit :initial-contents (vector sq-delta-s sq-delta-n)))

(defmacro color->adv-delta (my-color) `(svref color-adv-delta-vec ,my-color))
(defmacro color->ret-delta (my-color) `(svref color-ret-delta-vec ,my-color))

;;; ---------- Pawn single step count

(defconstant pawn-s1c-vec
  (make-array (list color-rlimit sq-limit)
    :initial-contents
      (vector
        (vector
          0 0 0 0 0 0 0 0
          0 0 0 0 0 0 0 0
          1 1 1 1 1 1 1 1
          2 2 2 2 2 2 2 2
          3 3 3 3 3 3 3 3
          4 4 4 4 4 4 4 4
          5 5 5 5 5 5 5 5
          0 0 0 0 0 0 0 0)
        (vector
          0 0 0 0 0 0 0 0
          5 5 5 5 5 5 5 5
          4 4 4 4 4 4 4 4
          3 3 3 3 3 3 3 3
          2 2 2 2 2 2 2 2
          1 1 1 1 1 1 1 1
          0 0 0 0 0 0 0 0
          0 0 0 0 0 0 0 0))))

(defmacro color+sq->pawn-s1c (my-color my-sq) `(aref pawn-s1c-vec ,my-color ,my-sq))

;;; ---------- Pawn squared biased step count

(defconstant pawn-s2bc-vec
  (make-array (list color-rlimit sq-limit)
    :initial-contents
      (vector
        (vector
           0  0  0  0  0  0  0  0
           4  4  4  4  4  4  4  4
           9  9  9  9  9  9  9  9
          16 16 16 16 16 16 16 16
          25 25 25 25 25 25 25 25
          36 36 36 36 36 36 36 36
          49 49 49 49 49 49 49 49
           0  0  0  0  0  0  0  0)
        (vector
           0  0  0  0  0  0  0  0
          49 49 49 49 49 49 49 49
          36 36 36 36 36 36 36 36
          25 25 25 25 25 25 25 25
          16 16 16 16 16 16 16 16
           9  9  9  9  9  9  9  9
           4  4  4  4  4  4  4  4
           0  0  0  0  0  0  0  0))))

(defmacro color+sq->pawn-s2bc (my-color my-sq) `(aref pawn-s2bc-vec ,my-color ,my-sq))

;;; ---------- Pawn next square

(defconstant pawn-nextsq-vec
  (make-array (list color-rlimit sq-limit)
    :initial-contents
      (vector
        (vector
          sq-a2 sq-b2 sq-c2 sq-d2 sq-e2 sq-f2 sq-g2 sq-h2
          sq-a3 sq-b3 sq-c3 sq-d3 sq-e3 sq-f3 sq-g3 sq-h3
          sq-a4 sq-b4 sq-c4 sq-d4 sq-e4 sq-f4 sq-g4 sq-h4
          sq-a5 sq-b5 sq-c5 sq-d5 sq-e5 sq-f5 sq-g5 sq-h5
          sq-a6 sq-b6 sq-c6 sq-d6 sq-e6 sq-f6 sq-g6 sq-h6
          sq-a7 sq-b7 sq-c7 sq-d7 sq-e7 sq-f7 sq-g7 sq-h7
          sq-a8 sq-b8 sq-c8 sq-d8 sq-e8 sq-f8 sq-g8 sq-h8
          sq-a1 sq-b1 sq-c1 sq-d1 sq-e1 sq-f1 sq-g1 sq-h1)
        (vector
          sq-a7 sq-b7 sq-c7 sq-d7 sq-e7 sq-f7 sq-g7 sq-h7
          sq-a6 sq-b6 sq-c6 sq-d6 sq-e6 sq-f6 sq-g6 sq-h6
          sq-a5 sq-b5 sq-c5 sq-d5 sq-e5 sq-f5 sq-g5 sq-h5
          sq-a4 sq-b4 sq-c4 sq-d4 sq-e4 sq-f4 sq-g4 sq-h4
          sq-a3 sq-b3 sq-c3 sq-d3 sq-e3 sq-f3 sq-g3 sq-h3
          sq-a2 sq-b2 sq-c2 sq-d2 sq-e2 sq-f2 sq-g2 sq-h2
          sq-a1 sq-b1 sq-c1 sq-d1 sq-e1 sq-f1 sq-g1 sq-h1
          sq-a8 sq-b8 sq-c8 sq-d8 sq-e8 sq-f8 sq-g8 sq-h8))))

(defmacro color+sq->pawn-nextsq (my-color my-sq) `(aref pawn-nextsq-vec ,my-color ,my-sq))

;;; ---------- Pawn motion

;;; Pawn attack directions by color

(defconstant pawn-atk-dirs-vec
  (make-array color-rlimit
    :initial-contents
      (vector (list dir-ne dir-nw) (list dir-sw dir-se))))

(defmacro color->pawn-atk-dirs (my-color) `(svref pawn-atk-dirs-vec ,my-color))

;;; Frozen pawn detection by color and pin direction

(defconstant color-dir-pawn-freeze-vec
  (make-array (list color-rlimit dir-slimit)
    :initial-contents
      (vector
        (vector t nil t nil t   t   nil nil)
        (vector t nil t nil nil nil t   t  ))))

(defmacro color+dir->pawn-freeze (my-color my-dir) `(aref color-dir-pawn-freeze-vec ,my-color ,my-dir))

;;; Storage and initialization routine for the pawn attack square lists

(defun constant-pawn-atk-sqs-vec ()
  "Initialize the pawn-atk-sqs-vec."
  (let ((result (make-array (list color-rlimit sq-limit) :initial-element nil)))
    (docolors (color)
      (let ((pawndirs (color->pawn-atk-dirs color)))
        (dosqs (frsq)
          (let ((sqs nil))
            (dolist (dir pawndirs)
              (let ((tosq (sq+dir->sq frsq dir)))
                (when tosq
                  (push tosq sqs))))
            (setf (aref result color frsq) (nreverse sqs))))))
    result))

(defvar pawn-atk-sqs-vec nil)

(defmacro color+sq->pawn-atk-sqs (my-color my-sq) `(aref pawn-atk-sqs-vec ,my-color ,my-sq))

;;; ---------- Knight motion

(defun constant-knight-atk-sqs-vec ()
  "Constant value of the knight-atk-sqs-vec."
  (let ((result (make-array sq-limit :initial-element nil)))
    (dosqs (frsq)
      (let ((sqs nil))
        (docrookdirs (dir)
          (let ((tosq (sq+dir->sq frsq dir)))
            (when tosq
              (push tosq sqs))))
        (setf (svref result frsq) (nreverse sqs))))
    result))

(defvar knight-atk-sqs-vec nil)

(defmacro sq->knight-atk-sqs (my-sq) `(svref knight-atk-sqs-vec ,my-sq))

;;; ---------- King motion

(defun constant-king-atk-sqs-vec ()
  "Constant value of the king-atk-sqs-vec."
  (let ((result (make-array sq-limit :initial-element nil)))
    (dosqs (frsq)
      (let ((sqs nil))
        (dosweepdirs (dir)
          (let ((tosq (sq+dir->sq frsq dir)))
            (when tosq
              (push tosq sqs))))
        (setf (svref result frsq) (nreverse sqs))))
    result))

(defvar king-atk-sqs-vec nil)

(defmacro sq->king-atk-sqs (my-sq) `(svref king-atk-sqs-vec ,my-sq))

;;; ---------- Sweep motion

(defun constant-sweep-atk-sqs-vec ()
  "Constant value of the sweep-atk-sqs-vec."
  (let ((result (make-array (list sq-limit dir-slimit) :initial-element nil)))
    (dosqs (frsq)
      (dosweepdirs (dir)
        (let ((sqs nil) (tosq (sq+dir->sq frsq dir)))
          (dowhile tosq
            (push tosq sqs)
            (setf tosq (sq+dir->sq tosq dir)))
          (setf (aref result frsq dir) (nreverse sqs)))))
    result))

(defvar sweep-atk-sqs-vec nil)

(defmacro sq+dir->sweep-atk-sqs (my-sq my-dir) `(aref sweep-atk-sqs-vec ,my-sq ,my-dir))

;;; ---------- Pawn mobility

(defun constant-pawn-mobility-vec ()
  "Constant value of the pawn-mobility-vec."
  (let ((result (make-array (list color-rlimit sq-limit) :initial-element nil)))
    (docolors (color)
      (dosqs (frsq)
        (setf (aref result color frsq) (length (color+sq->pawn-atk-sqs color frsq)))))
    result))

(defvar pawn-mobility-vec nil)

;;; ---------- Knight mobility

(defun constant-knight-mobility-vec ()
  "Constant value of the knight-mobility-vec."
  (let ((result (make-array sq-limit :initial-element nil)))
    (dosqs (frsq)
      (setf (svref result frsq) (length (sq->knight-atk-sqs frsq))))
    result))

(defvar knight-mobility-vec nil)

;;; ---------- King mobility

(defun constant-king-mobility-vec ()
  "Constant value of the king-mobility-vec."
  (let ((result (make-array sq-limit :initial-element nil)))
    (dosqs (frsq)
      (setf (svref result frsq) (length (sq->king-atk-sqs frsq))))
    result))

(defvar king-mobility-vec nil)

;;; ---------- En passant routines

(defun calc-ep-origin-sq (my-good my-epsq)
  "Calculate the en passant victim pawn origin square."
  (sq+dir->sq my-epsq (color->adv-dir my-good)))

(defun calc-ep-victim-sq (my-good my-epsq)
  "Calculate the en passant victim pawn square."
  (sq+dir->sq my-epsq (color->ret-dir my-good)))

;;; ---------- Position dependent game terminations

(defconstant pdgt-checkmate    0 "Checkmate")
(defconstant pdgt-fiftymoves   1 "Draw by the fifty move rule")
(defconstant pdgt-insufficient 2 "Draw by insufficient mating material")
(defconstant pdgt-repetition   3 "Draw by position repetition")
(defconstant pdgt-stalemate    4 "Draw by stalemate")
(defconstant pdgt-unterminated 5 "Unterminated")

(defconstant pdgt-limit (1+ pdgt-unterminated) "Number of possible position dependent game terminations")

(defconstant pdgt-index-list
  (list pdgt-checkmate pdgt-fiftymoves pdgt-insufficient pdgt-repetition pdgt-stalemate pdgt-unterminated))

(defmacro dopdgts ((my-pdgt-var) &body my-body)
  "Construct a per position dependent game termination iteration loop."
  `(dolist (,my-pdgt-var pdgt-index-list)
    ,@my-body))

(defconstant pdgt-string-vec
  (make-array pdgt-limit
    :initial-contents
      (vector "Checkmate" "FiftyMoves" "Insufficient" "Repetition" "Stalemate" "Unterminated")))

(defmacro pdgt->string (my-pdgt) `(svref pdgt-string-vec ,my-pdgt))

;;; ---------- Game score results

(defconstant gsr-double-forfeit 0 "Double forfeit; no points to either color")
(defconstant gsr-draw           1 "Drawn result; half point to each color")
(defconstant gsr-unterminated   2 "Unterminated game; no points to either color")
(defconstant gsr-win-by-black   3 "Black won; one point to Black, no points to White")
(defconstant gsr-win-by-white   4 "White won; one point to White, no points to Black")

(defconstant gsr-limit (1+ gsr-win-by-white))

(defconstant gsr-index-list
  (list gsr-double-forfeit gsr-draw gsr-unterminated gsr-win-by-black gsr-win-by-white))

(defmacro dogsrs ((my-gsr-var) &body my-body)
  "Construct a per game score result iteration loop."
  `(dolist (,my-gsr-var gsr-index-list)
    ,@my-body))

(defconstant gsr-string-vec
  (make-array gsr-limit
    :initial-contents
      (vector "0-0" "1/2-1/2" "*" "0-1" "1-0")))

(defmacro gsr->string (my-gsr) `(svref gsr-string-vec ,my-gsr))

;; Color/pdgt->gsr map

(defconstant color-pdgt-gsr-vec
  (make-array (list color-rlimit pdgt-limit)
    :initial-contents
      (vector
        (vector gsr-win-by-black gsr-draw gsr-draw gsr-draw gsr-draw gsr-unterminated)
        (vector gsr-win-by-white gsr-draw gsr-draw gsr-draw gsr-draw gsr-unterminated))))

(defmacro color+pdgt->gsr (my-good my-pdgt) `(aref color-pdgt-gsr-vec ,my-good ,my-pdgt))

;;; ---------- Structure wld

(defstruct
  (wld
    (:print-function meta-encode-wld))
  "A win-lose-draw counter set."
  (wc 0 :type integer)  ; Win count
  (lc 0 :type integer)  ; Lose count
  (dc 0 :type integer)) ; Draw count

(defun encode-wld (my-stream my-wld)
  "Encode the contests of a win-lose-draw counter set to a stream."
  (format my-stream "[w:~:D l:~:D d:~:D]"
    (wld-wc my-wld)
    (wld-lc my-wld)
    (wld-dc my-wld))
  (values))

(defun meta-encode-wld (my-wld my-stream my-level)
  "Glue to encode a wld structure."
  (declare (ignore my-level))
  (encode-wld my-stream my-wld)
  (values))

(defun wld-clone (my-wld)
  "Return a clone of the given wld."
  (make-wld :wc (wld-wc my-wld) :lc (wld-lc my-wld) :dc (wld-dc my-wld)))

(defun wld-reset (my-wld)
  "Reset the given wld."
  (setf (wld-wc my-wld) 0 (wld-lc my-wld) 0 (wld-dc my-wld) 0)
  (values))

(defun wld-reverse (my-wld)
  "Reverse the win and loss counts in the given wld."
  (rotatef (wld-wc my-wld) (wld-lc my-wld))
  (values))

(defun wld-total (my-wld)
  "Return the total of the sums of the given wld."
  (+ (wld-wc my-wld) (wld-lc my-wld) (wld-dc my-wld)))

(defun wld->expectation (my-wld)
  "Calculate and return the scoring expectation (0.0 to 1.0) of the given wld."
  (/
    (+ (* (wld-wc my-wld) 1.0) (* (wld-dc my-wld) 0.5))
    (float (wld-total my-wld))))

;;; ---------- Early move special case declarations

(defconstant msc-reg 0 "Regular moves including simple captures")
(defconstant msc-epc 1 "En passant capture")
(defconstant msc-cqs 2 "Castles queen side")
(defconstant msc-cks 3 "Castles king side")
(defconstant msc-ppn 4 "Pawn promotion to a knight")
(defconstant msc-ppb 5 "Pawn promotion to a bishop")
(defconstant msc-ppr 6 "Pawn promotion to a rook")
(defconstant msc-ppq 7 "Pawn promotion to a queen")

(defconstant msc-limit (1+ msc-ppq) "Number of chess move special cases")

(defconstant msc-index-list (list msc-reg msc-epc msc-cqs msc-cks msc-ppn msc-ppb msc-ppr msc-ppq))

(defmacro domscs ((my-msc-var) &body my-body)
  "Construct a per move special case iteration loop."
  `(dolist (,my-msc-var msc-index-list)
    ,@my-body))

;; Map msc to value for move gain estimation

(defconstant msc-value-vec
  (make-array msc-limit
    :initial-contents
      (vector
        0
        value-pawn
        0
        0
        (- value-knight value-pawn)
        (- value-bishop value-pawn)
        (- value-rook   value-pawn)
        (- value-queen  value-pawn))))

(defmacro msc->value (my-msc)
  "Map a msc into a value; used with move gain estimation."
  `(svref msc-value-vec ,my-msc))

;;; ---------- Structure hash

(defconstant ht-exact 116                                   "A hash has exactly this many effective bits")
(defconstant hb-limit (integer-length most-positive-fixnum) "Hash bits per hashword")
(defconstant hw-limit (ceiling (/ ht-exact hb-limit))       "Hash code word count; must be >= 1")
(defconstant ht-limit (* hw-limit hb-limit)                 "Total hash bits stored per hash value")

(defstruct
  (hash
    (:print-function meta-encode-hash))
  "A hash."
  (hw-vec (make-array hw-limit :initial-element 0))) ; Array of hashwords each with hb-limit bits

(defun hash-fetch-nth-bit (my-hash my-bitindex)
  "Return the value (0/1) of the nth bit in the given hash."
  (if (>= my-bitindex ht-exact)
    0
    (logand
      (ash
        (svref (hash-hw-vec my-hash) (truncate my-bitindex hb-limit))
        (- (mod my-bitindex hb-limit)))
      1)))

(defun encode-hash (my-stream my-hash)
  "Encode the hexidecimal digits of a hash to a stream."
  (let ((ht-index 0) (hd-list nil))
    (dowhile (< ht-index ht-exact)
      (let
        (
          (b0 (hash-fetch-nth-bit my-hash (+ ht-index 0)))
          (b1 (hash-fetch-nth-bit my-hash (+ ht-index 1)))
          (b2 (hash-fetch-nth-bit my-hash (+ ht-index 2)))
          (b3 (hash-fetch-nth-bit my-hash (+ ht-index 3)))
        )
        (push (+ (* b3 8) (* b2 4) (* b1 2) (* b0 1)) hd-list)
      (incf ht-index 4)))
    (dowhile hd-list
      (fmt-hex-digit my-stream (pop hd-list))))
  (values))

(defun meta-encode-hash (my-hash my-stream my-level)
  "Glue to encode a hash structure."
  (declare (ignore my-level))
  (encode-hash my-stream my-hash)
  (values))

(defun hash-reset (my-hash)
  "Reset the given hash."
  (let ((hw-vec (hash-hw-vec my-hash)))
    (dotimes (index hw-limit)
      (setf (svref hw-vec index) 0)))
  (values))

(defun hash-clone (my-hash)
  "Return a clone of the given hash."
  (make-hash :hw-vec (copy-seq (hash-hw-vec my-hash))))

(defun random-hash (my-prng-state)
  "Return a hash initialized with the PRNG."
  (let* ((result (make-hash)) (hw-vec (hash-hw-vec result)) (ht-index 0))
    (dotimes (hw-index hw-limit)
      (let ((hashword 0))
        (dotimes (hb-index hb-limit)
          (when (and (< ht-index ht-exact) (prng-next-bit my-prng-state))
            (incf hashword (index->bit hb-index)))
          (incf ht-index))
        (setf (svref hw-vec hw-index) hashword)))
    result))

(defun hash->integer (my-hash)
  "Convert a hash into an integer."
  (let ((result 0))
    (dotimes (index ht-exact)
      (setf result (2* result))
      (when (one? (hash-fetch-nth-bit my-hash (- (1- ht-exact) index)))
        (incf result)))
    result))

(defun integer->hash (my-integer)
  "Convert an integer into a hash."
  (let* ((result (make-hash)) (hw-vec (hash-hw-vec result)))
    (dotimes (ht-index ht-exact)
      (when (odd? (ash my-integer (- ht-index)))
        (incf (svref hw-vec (truncate ht-index hb-limit)) (2^ (mod ht-index hb-limit)))))
    result))

(defun hash-rotate-right (my-hash)
  "Return a new hash by that is the input hash rotated to the right by one bit."
  (let* ((intval (hash->integer my-hash)) (odd (odd? intval)))
    (setf intval (2/ intval))
    (when odd
      (incf intval (2^ (1- ht-exact))))
    (integer->hash intval)))

(defmacro hash-xor2 (my-hash0 my-hash1)
  "Return an exclusive-or of two hashes."
  `(let*
    (
      (result  (make-hash))
      (hwr-vec (hash-hw-vec result))
      (hw0-vec (hash-hw-vec ,my-hash0))
      (hw1-vec (hash-hw-vec ,my-hash1))
    )
    (dotimes (index hw-limit)
      (setf (svref hwr-vec index) (logxor (svref hw0-vec index) (svref hw1-vec index))))
  result))

(defmacro hash-xor2d (my-hash0 my-hash1)
  "Perform an exclusive-or of the second hash into the first."
  `(let
    (
      (hw0-vec (hash-hw-vec ,my-hash0))
      (hw1-vec (hash-hw-vec ,my-hash1))
    )
    (dotimes (index hw-limit)
      (setf (svref hw0-vec index) (logxor (svref hw0-vec index) (svref hw1-vec index))))))

(defmacro hash-eq? (my-hash0 my-hash1)
  "Determine if the two hashes have the same value."
  `(equalp ,my-hash0 ,my-hash1))

(defun hash-gt? (my-hash0 my-hash1)
  "Determine if the first hash is greater than the second hash."
  (let
    (
      (result   nil)
      (hw0-vec (hash-hw-vec my-hash0))
      (hw1-vec (hash-hw-vec my-hash1))
      (index   0)
      (undone  t)
    )
    (dowhile (and undone (< index hw-limit))
      (let*
        (
          (alt-index (- (1- hw-limit) index))
          (hv0       (svref hw0-vec alt-index))
          (hv1       (svref hw1-vec alt-index))
        )
        (cond
          ((< hv0 hv1)
            (setf result nil)
            (setf undone nil))
          ((> hv0 hv1)
            (setf result t)
            (setf undone nil))
          (t
            (incf index)))))
    result))

(defun hash-lt? (my-hash0 my-hash1)
  "Determine if the first hash is less than the second hash."
  (let
    (
      (result   nil)
      (hw0-vec (hash-hw-vec my-hash0))
      (hw1-vec (hash-hw-vec my-hash1))
      (index   0)
      (undone  t)
    )
    (dowhile (and undone (< index hw-limit))
      (let*
        (
          (alt-index (- (1- hw-limit) index))
          (hv0       (svref hw0-vec alt-index))
          (hv1       (svref hw1-vec alt-index))
        )
        (cond
          ((< hv0 hv1)
            (setf result t)
            (setf undone nil))
          ((> hv0 hv1)
            (setf result nil)
            (setf undone nil))
          (t
            (incf index)))))
    result))

;;; Storage and initialization routine for the empty hash code

(defun constant-empty-hash ()
  "Constant value for the empty hash code."
  (make-hash))

(defvar empty-hash nil "A zero hash code")

;;; Storage and initialization routine for the man/sq hash code vector

(defun constant-man-sq-hash-vec (my-prng-state)
  "Constant value for the man-sq-hash-vec."
  (let ((result (make-array (list man-rlimit sq-limit) :initial-element nil)))
    (domans (man)
      (dosqs (sq)
        (setf (aref result man sq) (random-hash my-prng-state))))
    result))

(defvar man-sq-hash-vec nil "Man/sq hash codes")

(defmacro man+sq->hash (my-man my-sq) `(aref man-sq-hash-vec ,my-man ,my-sq))

;;; Storage and initialization routine for the castling hash code vector

(defun constant-castling-hash-vec (my-prng-state)
  "Constant value for the castling-hash-vec."
  (let ((result (make-array castling-limit :initial-element nil)))
    (docastlings (castling)
      (setf (svref result castling) (random-hash my-prng-state)))
    result))

(defvar castling-hash-vec nil "Castling hash codes")

(defmacro castling->hash (my-castling) `(svref castling-hash-vec ,my-castling))

;;; Storage and initialization routine for the castling availability bits hash code vector

(defun constant-cast-hash-vec ()
  "Constant value for the cast-hash-vec."
  (let ((result (make-array cast-limit :initial-element nil)))
    (dotimes (cast cast-limit)
      (let ((hash (make-hash)))
        (docastlings (castling)
          (when (cast-allows-castling? cast castling)
            (hash-xor2d hash (castling->hash castling))))
        (setf (svref result cast) hash)))
    result))

(defvar cast-hash-vec nil "Castling availability bits hash codes")

(defmacro cast->hash (my-cast) `(svref cast-hash-vec ,my-cast))

;;; Storage and initialization routine for the en passant file hash code vector

(defun constant-epfile-hash-vec (my-prng-state)
  "Constant value for the epfile-hash-vec."
  (let ((result (make-array file-limit :initial-element nil)))
    (dofiles (file)
      (setf (svref result file) (random-hash my-prng-state)))
    result))

(defvar epfile-hash-vec nil "En passant file hash codes")

(defmacro epfile->hash (my-epfile) `(svref epfile-hash-vec ,my-epfile))

;;; Hash fetch routine for an en passant target square

(defun fetch-epsq-hash (my-epsq)
  "Return the hash for the given en passant target square (not a copy)."
  (if my-epsq
    (epfile->hash (sq->file my-epsq))
    empty-hash))

;;; Storage and initialization routine for the game score result hash code vector

(defun constant-gsr-hash-vec (my-prng-state)
  "Constant value for the gsr-hash-vec."
  (let ((result (make-array gsr-limit :initial-element nil)))
    (dogsrs (gsr)
      (setf (svref result gsr) (random-hash my-prng-state)))
    result))

(defvar gsr-hash-vec nil "Game score result hash codes")

(defmacro gsr->hash (my-gsr) `(svref gsr-hash-vec ,my-gsr))

;;; Storage and initialization routine for the color hash code vector

(defun constant-color-hash-vec (my-prng-state)
  "Constant value for the color-hash-vec."
  (let ((result (make-array color-rlimit :initial-element nil)))
    (docolors (color)
      (setf (svref result color) (random-hash my-prng-state)))
    result))

(defvar color-hash-vec nil "Color hash codes")

(defmacro color->hash (my-color) `(svref color-hash-vec ,my-color))

;;; Storage and initialization routine for the move special case hash code vector

(defun constant-msc-hash-vec (my-prng-state)
  "Constant value for the gsr-vec."
  (let ((result (make-array msc-limit :initial-element nil)))
    (domscs (msc)
      (setf (svref result msc) (random-hash my-prng-state)))
    result))

(defvar msc-hash-vec nil "Move special case hash codes")

(defmacro msc->hash (my-msc) `(svref msc-hash-vec ,my-msc))

;;; Hash list operations

(defun hashlist-clone (my-hashs)
  "Return a clone of the given hash list."
  (mapcar (function hash-clone) my-hashs))

;;; ---------- Structure hashnode

(defstruct
  (hashnode)
    "Hash keyed binary tree node."
    (hash      (make-hash) :type hash) ; Hash key for this node
    (subtree-l nil)                    ; Left subtree (hash keys less than this hash key)
    (subtree-r nil)                    ; Right subtree (hash keys greater than this hash key)
    (hook      nil))                   ; General purpose hook for attached data

(defun hashnode-search (my-root my-hash)
  "Recursively search a hash node tree for a matching entry."
  (let ((result nil) (node my-root))
    (cond
      ((null? node)
        (setf result nil))
      ((hash-eq? my-hash (hashnode-hash node))
        (setf result node))
      ((hash-lt? my-hash (hashnode-hash node))
        (setf result (hashnode-search (hashnode-subtree-l node) my-hash)))
      ((hash-gt? my-hash (hashnode-hash node))
        (setf result (hashnode-search (hashnode-subtree-r node) my-hash)))
      (t
        (error "hashnode-search: bad compare")))
    result))

;;; ---------- Structure hashtree

(defstruct
  (hashtree)
  "A binary tree of hash nodes."
  (root        nil)              ; Base of the hash node tree
  (entry-count 0 :type integer)) ; Number of insertions

(defun hashtree-reset (my-hashtree)
  "Reset the given hash tree."
  (setf (hashtree-root my-hashtree) nil)
  (setf (hashtree-entry-count my-hashtree) 0)
  (values))

(defun hashtree-search (my-hashtree my-hash)
  "Search for a node in the given hash tree."
  (hashnode-search (hashtree-root my-hashtree) my-hash))

(defun hashtree-insert-aux (my-root my-hash my-hashnode)
  "Helper routine for hashtree-insert."
  (let
    (
      (hash      (hashnode-hash      my-root))
      (subtree-l (hashnode-subtree-l my-root))
      (subtree-r (hashnode-subtree-r my-root))
    )
    (cond
      ((hash-lt? my-hash hash)
        (if (null? subtree-l)
          (setf (hashnode-subtree-l my-root) my-hashnode)
          (hashtree-insert-aux subtree-l my-hash my-hashnode)))
      ((hash-gt? my-hash hash)
        (if (null? subtree-r)
          (setf (hashnode-subtree-r my-root) my-hashnode)
          (hashtree-insert-aux subtree-r my-hash my-hashnode)))
      (t
        (error "hashtree-insert-aux: bad relation ~A ~A" my-hash hash))))
  (values))

(defun hashtree-insert (my-hashtree my-hashnode)
  "Insert a node into the given hash tree."
  (let ((root (hashtree-root my-hashtree)))
    (if (null? root)
      (setf (hashtree-root my-hashtree) my-hashnode)
      (hashtree-insert-aux root (hashnode-hash my-hashnode) my-hashnode))
    (incf (hashtree-entry-count my-hashtree)))
  (values))

(defun new-htvec (my-limit)
  "Return a vector of hash trees."
  (let ((result (make-array my-limit :initial-element nil)))
    (dotimes (index my-limit)
      (setf (svref result index) (make-hashtree)))
    result))

(defun new-cihtvec ()
  "Return a color indexed vector of two hash trees."
  (new-htvec color-rlimit))

;;; ---------- Target IDs

(defconstant army-limit (2* file-limit) "Number of men in a starting army per color")

(defconstant tid-w00  0 "Target ID for the white king")
(defconstant tid-w01  1 "Target ID for a nonspecific white non-king")
(defconstant tid-w02  2 "Target ID for a nonspecific white non-king")
(defconstant tid-w03  3 "Target ID for a nonspecific white non-king")
(defconstant tid-w04  4 "Target ID for a nonspecific white non-king")
(defconstant tid-w05  5 "Target ID for a nonspecific white non-king")
(defconstant tid-w06  6 "Target ID for a nonspecific white non-king")
(defconstant tid-w07  7 "Target ID for a nonspecific white non-king")
(defconstant tid-w08  8 "Target ID for a nonspecific white non-king")
(defconstant tid-w09  9 "Target ID for a nonspecific white non-king")
(defconstant tid-w10 10 "Target ID for a nonspecific white non-king")
(defconstant tid-w11 11 "Target ID for a nonspecific white non-king")
(defconstant tid-w12 12 "Target ID for a nonspecific white non-king")
(defconstant tid-w13 13 "Target ID for a nonspecific white non-king")
(defconstant tid-w14 14 "Target ID for a nonspecific white non-king")
(defconstant tid-w15 15 "Target ID for a nonspecific white non-king")
(defconstant tid-b00 16 "Target ID for the black king")
(defconstant tid-b01 17 "Target ID for a nonspecific black non-king")
(defconstant tid-b02 18 "Target ID for a nonspecific black non-king")
(defconstant tid-b03 19 "Target ID for a nonspecific black non-king")
(defconstant tid-b04 20 "Target ID for a nonspecific black non-king")
(defconstant tid-b05 21 "Target ID for a nonspecific black non-king")
(defconstant tid-b06 22 "Target ID for a nonspecific black non-king")
(defconstant tid-b07 23 "Target ID for a nonspecific black non-king")
(defconstant tid-b08 24 "Target ID for a nonspecific black non-king")
(defconstant tid-b09 25 "Target ID for a nonspecific black non-king")
(defconstant tid-b10 26 "Target ID for a nonspecific black non-king")
(defconstant tid-b11 27 "Target ID for a nonspecific black non-king")
(defconstant tid-b12 28 "Target ID for a nonspecific black non-king")
(defconstant tid-b13 29 "Target ID for a nonspecific black non-king")
(defconstant tid-b14 30 "Target ID for a nonspecific black non-king")
(defconstant tid-b15 31 "Target ID for a nonspecific black non-king")

(defconstant tid-limit (1+ tid-b15) "Number of target IDs (0-15: white, 16-31: black")

(defconstant tid-index-list
  (list
    tid-w00 tid-w01 tid-w02 tid-w03 tid-w04 tid-w05 tid-w06 tid-w07
    tid-w08 tid-w09 tid-w10 tid-w11 tid-w12 tid-w13 tid-w14 tid-w15
    tid-b00 tid-b01 tid-b02 tid-b03 tid-b04 tid-b05 tid-b06 tid-b07
    tid-b08 tid-b09 tid-b10 tid-b11 tid-b12 tid-b13 tid-b14 tid-b15))

(defmacro dotids ((my-tid-var) &body my-body)
  "Construct a per target ID iteration loop."
  `(dolist (,my-tid-var tid-index-list)
    ,@my-body))

(defconstant tid-wk tid-w00 "Target ID of the white king")
(defconstant tid-bk tid-b00 "Target ID of the black king")

(defconstant king-tid-vec (make-array color-rlimit :initial-contents (vector tid-wk tid-bk)))

;;; ---------- Structure tracker

(defstruct
  (tracker)
    "Target tracking vectors."
    (sq-vec  (make-array tid-limit :initial-element nil))  ; Target squares by target ID
    (tid-vec (make-array sq-limit  :initial-element nil))) ; Target IDs by square

(defun tracker-reset (my-tracker)
  "Reset the given target tracker."
  (let ((sq-vec (tracker-sq-vec my-tracker)) (tid-vec (tracker-tid-vec my-tracker)))
    (dosqs (sq)
      (setf (svref tid-vec sq) nil))
    (dotids (tid)
      (setf (svref sq-vec tid) nil)))
  (values))

(defun tracker-clone (my-tracker)
  "Return a clone of the given tracker."
  (let ((result (make-tracker)))
    (setf (tracker-sq-vec  result) (copy-seq (tracker-sq-vec  my-tracker)))
    (setf (tracker-tid-vec result) (copy-seq (tracker-tid-vec my-tracker)))
    result))

(defun tracker-add-sq (my-tracker my-sq my-tid)
  "Load a square and target ID into the given tracker."
  (setf (svref (tracker-sq-vec my-tracker)  my-tid) my-sq)
  (setf (svref (tracker-tid-vec my-tracker) my-sq)  my-tid)
  (values))

(defun tracker-del-sq (my-tracker my-sq)
  "Delete a square (and its associated target ID) from the given tracker; return captured target ID."
  (let ((tid (svref (tracker-tid-vec my-tracker) my-sq)))
    (setf (svref (tracker-sq-vec  my-tracker) tid)   nil)
    (setf (svref (tracker-tid-vec my-tracker) my-sq) nil)
    tid))

(defun tracker-move (my-tracker my-frsq my-tosq)
  "Move a target ID from one square to another square."
  (let ((tid (svref (tracker-tid-vec my-tracker) my-frsq)))
    (setf (svref (tracker-sq-vec my-tracker) tid) my-tosq)
    (setf (svref (tracker-tid-vec my-tracker) my-frsq) nil)
    (setf (svref (tracker-tid-vec my-tracker) my-tosq) tid))
  (values))

(defmacro tracker-fetch-sq (my-tracker my-tid)
  "Return the square for a given target ID."
  `(svref (tracker-sq-vec ,my-tracker) ,my-tid))

(defmacro tracker-fetch-tid (my-tracker my-sq)
  "Return the target ID for a given square."
  `(svref (tracker-tid-vec ,my-tracker) ,my-sq))

;;; ---------- Structure census

(defstruct
  (census)
    "Color/man board census."
    (ccvec (make-array color-rlimit :initial-element 0))  ; Count of men by color
    (mcvec (make-array man-rlimit   :initial-element 0))) ; Count of men by man

(defun census-reset (my-census)
  "Reset the given census."
  (let ((ccvec (census-ccvec my-census)))
    (docolors (color)
      (setf (svref ccvec color) 0)))
  (let ((mcvec (census-mcvec my-census)))
    (domans (man)
      (setf (svref mcvec man) 0)))
  (values))

(defun census-clone (my-census)
  "Return a clone of the given census."
  (make-census
    :ccvec (copy-seq (census-ccvec my-census))
    :mcvec (copy-seq (census-mcvec my-census))))

(defun census-add-man (my-census my-man)
  "Add a man to the given census."
  (incf (svref (census-ccvec my-census) (man->color my-man)))
  (incf (svref (census-mcvec my-census) my-man))
  (values))

(defun census-del-man (my-census my-man)
  "Delete a man from the given census."
  (decf (svref (census-ccvec my-census) (man->color my-man)))
  (decf (svref (census-mcvec my-census) my-man))
  (values))

(defun census-sufficient-material-by-color (my-census my-color)
  "Determine if a census has sufficient mating material for the given color."
  (let ((mcvec (census-mcvec my-census)))
    (or
      (positive? (svref mcvec (color->pawn my-color)))
      (positive? (svref mcvec (color->rook my-color)))
      (positive? (svref mcvec (color->queen my-color)))
      (>= (svref mcvec (color->bishop my-color)) 2)
      (>= (svref mcvec (color->knight my-color)) 3)
      (and
        (positive? (svref mcvec (color->knight my-color)))
        (positive? (svref mcvec (color->bishop my-color)))))))

(defun census-sufficient-material (my-census)
  "Determine if a census has sufficient mating material for either color."
  (or
    (census-sufficient-material-by-color my-census color-white)
    (census-sufficient-material-by-color my-census color-black)))

(defun valid-color-mc-apc? (my-color my-mcvec my-apc)
  "Helper routine for census checking; handles available pawn promotions."
  (let ((valid t) (apc my-apc))
    (when valid
      (let ((queen-count (svref my-mcvec (color->queen my-color))))
        (if (or (< queen-count 0) (> queen-count (+ apc 1)))
          (setf valid nil)
          (when (> queen-count 1) (decf apc (- queen-count 1))))))
    (when valid
      (let ((rook-count (svref my-mcvec (color->rook my-color))))
        (if (or (< rook-count 0) (> rook-count (+ apc 2)))
          (setf valid nil)
          (when (> rook-count 2) (decf apc (- rook-count 2))))))
    (when valid
      (let ((bishop-count (svref my-mcvec (color->bishop my-color))))
        (if (or (< bishop-count 0) (> bishop-count (+ apc 2)))
          (setf valid nil)
          (when (> bishop-count 2) (decf apc (- bishop-count 2))))))
    (when valid
      (let ((knight-count (svref my-mcvec (color->knight my-color))))
        (if (or (< knight-count 0) (> knight-count (+ apc 2)))
          (setf valid nil)
          (when (> knight-count 2) (decf apc (- knight-count 2))))))
    valid))

(defun valid-census-by-color? (my-census my-color)
  "Determine if a specific color half of a census is valid."
  (let* ((valid t) (ccvec (census-ccvec my-census)) (cc (svref ccvec my-color)))
    (if (or (< cc 1) (> cc army-limit))
      (setf valid nil)
      (let ((mcvec (census-mcvec my-census)))
        (if (/= (svref mcvec (color->king my-color)) 1)
          (setf valid nil)
          (let ((pawn-count (svref mcvec (color->pawn my-color))))
            (if (> pawn-count file-limit)
              (setf valid nil)
              (unless (valid-color-mc-apc? my-color mcvec (- file-limit pawn-count))
                (setf valid nil)))))))
    valid))

(defun valid-census? (my-census)
  "Determine if a census is valid."
  (and
    (valid-census-by-color? my-census color-white)
    (valid-census-by-color? my-census color-black)))

;;; ---------- Structure board

(defstruct
  (board
    (:print-function meta-encode-board))
  "A chessboard."
  (manv (make-array sq-limit :initial-element man-v0)))

(defconstant initial-man-vec
  (make-array sq-limit
    :initial-contents
      (vector
        man-wr man-wn man-wb man-wq man-wk man-wb man-wn man-wr
        man-wp man-wp man-wp man-wp man-wp man-wp man-wp man-wp
        man-v0 man-v0 man-v0 man-v0 man-v0 man-v0 man-v0 man-v0
        man-v0 man-v0 man-v0 man-v0 man-v0 man-v0 man-v0 man-v0
        man-v0 man-v0 man-v0 man-v0 man-v0 man-v0 man-v0 man-v0
        man-v0 man-v0 man-v0 man-v0 man-v0 man-v0 man-v0 man-v0
        man-bp man-bp man-bp man-bp man-bp man-bp man-bp man-bp
        man-br man-bn man-bb man-bq man-bk man-bb man-bn man-br)))

(defun new-board ()
  "Return a new board with the chess initial array."
  (make-board :manv (copy-seq initial-man-vec)))

(defun encode-board-rank (my-stream my-board my-rank)
  "Encode one rank of FEN MPD (Man Placement Data) of a board to a stream."
  (let ((spaces 0) (man-vec (board-manv my-board)))
    (dofiles (file)
      (let ((man (svref man-vec (file+rank->sq file my-rank))))
        (if (is-man-vacant? man)
          (incf spaces)
          (progn
            (when (positive? spaces)
              (format my-stream "~D" spaces)
              (setf spaces 0))
            (format my-stream "~A" (man->char man))))))
    (when (positive? spaces)
      (format my-stream "~D" spaces)))
  (values))

(defun encode-board (my-stream my-board)
  "Encode the FEN MPD (Man Placement Data) of a board to a stream."
  (dolist (rank rank-index-rev-list)
    (encode-board-rank my-stream my-board rank)
    (when (/= rank rank-1)
      (format my-stream "/")))
  (values))

(defun meta-encode-board (my-board my-stream my-level)
  "Glue to encode a board structure."
  (declare (ignore my-level))
  (encode-board my-stream my-board)
  (values))

(defun board->string (my-board)
  "Encode a board on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-board str-stream my-board)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defmacro get-man (my-board my-sq)        `(svref (board-manv ,my-board) ,my-sq))
(defmacro put-man (my-board my-sq my-man) `(setf (svref (board-manv ,my-board) ,my-sq) ,my-man))
(defmacro clr-man (my-board my-sq)        `(setf (svref (board-manv ,my-board) ,my-sq) man-v0))

(defmacro mov-man (my-board my-frsq my-tosq)
  "Move a man on a board."
  `(let ((manv (board-manv ,my-board)))
    (rotatef (svref manv ,my-frsq) (svref manv ,my-tosq))))

(defun board-reset (my-board)
  "Reset the given board."
  (dosqs (sq)
    (clr-man my-board sq))
  (values))

(defun board-clone (my-board)
  "Return a clone of the given board."
  (make-board :manv (copy-seq (board-manv my-board))))

(defun encode-board-graphic-mono (my-stream my-board)
  "Encode a simple monochrome graphic of a board to a stream."
  (dolist (rank rank-index-rev-list)
    (dofiles (file)
      (let* ((sq (file+rank->sq file rank)) (man (get-man my-board sq)))
        (if (is-man-nonvac? man)
          (format my-stream "~A" (man->string man))
          (format my-stream "~A" (if (is-sq-white? sq) "  " "::")))))
    (newline my-stream))
  (values))

(defun encode-board-graphic-color-sq (my-stream my-board my-sq)
  "Emit a two character graphic for the given square and the given board."
  (let
    (
      (man        (get-man my-board my-sq))
      (back-color (if (is-sq-white? my-sq) ansi-color-white ansi-color-green))
    )
    (if (is-man-vacant? man)
      (fmt-ansi-fc-bc-bold my-stream ansi-color-black back-color nil)
      (if (is-man-white? man)
        (fmt-ansi-fc-bc-bold my-stream ansi-color-red  back-color nil)
        (fmt-ansi-fc-bc-bold my-stream ansi-color-blue back-color nil)))
    (format my-stream "~A" (man->string man))
    (fmt-ansi-attributes-reset my-stream))
  (values))

(defun encode-board-graphic-color (my-stream my-board)
  "Encode a simple color graphic of a board to a stream."
  (dolist (rank rank-index-rev-list)
    (dofiles (file)
      (encode-board-graphic-color-sq my-stream my-board (file+rank->sq file rank)))
    (newline my-stream))
  (values))

(defun board-locate-king-by-color (my-board my-color)
  "Locate the king of a given color on the given board."
  (let ((result nil) (sqs sq-index-list) (king-man (color->king my-color)))
    (dowhile (and (not result) sqs)
      (let ((sq (pop sqs)))
        (if (= king-man (get-man my-board sq))
          (setf result sq))))
    result))

(defun board-color-attacks-sq? (my-board my-color my-sq)
  "Determine if a color attacks a square on the given board."
  (let ((result nil))
    ;;
    ;; Pawn attacks
    ;;
    (unless result
      (let ((pawn-man (color->pawn my-color)) (sqs (color+sq->pawn-atk-sqs (other-color my-color) my-sq)))
        (dowhile (and (not result) sqs)
          (when (= (get-man my-board (pop sqs)) pawn-man)
            (setf result t)))))
    ;;
    ;; Knight attacks
    ;;
    (unless result
      (let ((knight-man (color->knight my-color)) (sqs (sq->knight-atk-sqs my-sq)))
        (dowhile (and (not result) sqs)
          (when (= (get-man my-board (pop sqs)) knight-man)
            (setf result t)))))
    ;;
    ;; King attacks
    ;;
    (unless result
      (let ((king-man (color->king my-color)) (sqs (sq->king-atk-sqs my-sq)))
        (dowhile (and (not result) sqs)
          (when (= (get-man my-board (pop sqs)) king-man)
            (setf result t)))))
    ;;
    ;; Sweeper attacks
    ;;
    (unless result
      (let ((queen-man (color->queen my-color)))
        ;;
        ;; Diagonal sweeper attacks
        ;;
        (unless result
          (let ((bishop-man (color->bishop my-color)) (dirs diago-dir-list))
            (dowhile (and (not result) dirs)
              (let ((unstopped t) (sqs (sq+dir->sweep-atk-sqs my-sq (pop dirs))))
                (dowhile (and unstopped sqs)
                  (let ((man (get-man my-board (pop sqs))))
                    (unless (is-man-vacant? man)
                      (setf unstopped nil)
                      (when (or (= man bishop-man) (= man queen-man))
                        (setf result t)))))))))
        ;;
        ;; Orthogonal sweeper attacks
        ;;
        (unless result
          (let ((rook-man (color->rook my-color)) (dirs ortho-dir-list))
            (dowhile (and (not result) dirs)
              (let ((unstopped t) (sqs (sq+dir->sweep-atk-sqs my-sq (pop dirs))))
                (dowhile (and unstopped sqs)
                  (let ((man (get-man my-board (pop sqs))))
                    (unless (is-man-vacant? man)
                      (setf unstopped nil)
                      (when (or (= man rook-man) (= man queen-man))
                        (setf result t)))))))))))
    result))

(defun board-count-color-sq-attacks (my-board my-color my-sq)
  "Count the number of color attacks to a square on the given board."
  (let ((result 0))
    ;;
    ;; Pawn attacks
    ;;
    (let ((pawn-man (color->pawn my-color)) (sqs (color+sq->pawn-atk-sqs (other-color my-color) my-sq)))
      (dowhile sqs
        (when (= (get-man my-board (pop sqs)) pawn-man)
          (incf result))))
    ;;
    ;; Knight attacks
    ;;
    (let ((knight-man (color->knight my-color)) (sqs (sq->knight-atk-sqs my-sq)))
      (dowhile sqs
        (when (= (get-man my-board (pop sqs)) knight-man)
          (incf result))))
    ;;
    ;; King attacks
    ;;
    (let ((king-man (color->king my-color)) (sqs (sq->king-atk-sqs my-sq)))
      (dowhile sqs
        (when (= (get-man my-board (pop sqs)) king-man)
          (incf result))))
    ;;
    ;; Sweeper attacks
    ;;
    (let ((queen-man (color->queen my-color)))
      ;;
      ;; Diagonal sweeper attacks
      ;;
      (let ((bishop-man (color->bishop my-color)) (dirs diago-dir-list))
        (dowhile dirs
          (let ((unstopped t) (sqs (sq+dir->sweep-atk-sqs my-sq (pop dirs))))
            (dowhile (and unstopped sqs)
              (let ((man (get-man my-board (pop sqs))))
                (unless (is-man-vacant? man)
                  (setf unstopped nil)
                  (when (or (= man bishop-man) (= man queen-man))
                    (incf result))))))))
      ;;
      ;; Orthogonal sweeper attacks
      ;;
      (let ((rook-man (color->rook my-color)) (dirs ortho-dir-list))
        (dowhile dirs
          (let ((unstopped t) (sqs (sq+dir->sweep-atk-sqs my-sq (pop dirs))))
            (dowhile (and unstopped sqs)
              (let ((man (get-man my-board (pop sqs))))
                (unless (is-man-vacant? man)
                  (setf unstopped nil)
                  (when (or (= man rook-man) (= man queen-man))
                    (incf result)))))))))
    result))

(defun board-has-epsq-pawn-attacker? (my-board my-good my-epsq)
  "Determine if there is a good pawn attacker to the en passant target square."
  (let
    (
      (result   nil)
      (pawn-man (color->pawn my-good))
      (sqs      (color+sq->pawn-atk-sqs (other-color my-good) my-epsq))
    )
    (dowhile (and (not result) sqs)
      (when (= pawn-man (get-man my-board (pop sqs)))
        (setf result t)))
    result))

(defun board-reload-tracker (my-board my-tracker)
  "Reload a tracker from a board."
  (tracker-reset my-tracker)
  (let ((tid-ord-vec (copy-seq king-tid-vec)))
    (dosqs (sq)
      (let ((man (get-man my-board sq)))
        (unless (is-man-vacant? man)
          (let*
            (
              (color (man->color man))
              (tid   (if (is-man-king? man) (svref king-tid-vec color) (incf (svref tid-ord-vec color))))
            )
            (tracker-add-sq my-tracker sq tid))))))
  (values))

(defun board-generate-census (my-board)
  "Generate a census from a board."
  (let ((result (make-census)))
    (dosqs (sq)
      (let ((man (get-man my-board sq)))
        (unless (is-man-vacant? man)
          (census-add-man result man))))
    result))

(defun valid-board-census? (my-board)
  "Determine if the board's census data is valid."
  (valid-census? (board-generate-census my-board)))

(defun valid-board-pawn-placement? (my-board)
  "Determine if the board's pawn placement data is valid."
  (let ((valid t) (files file-index-list))
    (dowhile (and valid files)
      (let ((file (pop files)))
        (when
          (or
            (= (man->piece (get-man my-board (file+rank->sq file rank-1))) piece-pawn)
            (= (man->piece (get-man my-board (file+rank->sq file rank-8))) piece-pawn))
          (setf valid nil))))
    valid))

(defun valid-board? (my-board)
  "Determine if a board is valid."
  (and (valid-board-census? my-board) (valid-board-pawn-placement? my-board)))

(defun vaild-board-cast-combo? (my-board my-cast)
  "Determine if a board/cast combination is valid."
  (let ((valid t) (castlings castling-index-list))
    (dowhile (and valid castlings)
      (let ((castling (pop castlings)))
        (when (bit? castling my-cast)
          (let ((color (castling->color castling)))
            (if
              (or
                (/= (get-man my-board (castling->king-home castling)) (color->king color))
                (/= (get-man my-board (castling->rook-home castling)) (color->rook color)))
              (setf valid nil))))))
    valid))

(defun valid-board-good-epsq-combo? (my-board my-good my-epsq)
  "Determine if a board/epsq combination is valid."
  (and
    (= (sq->rank my-epsq) (svref rank6-vec my-good))
    (is-man-vacant? (get-man my-board my-epsq))
    (is-man-vacant? (get-man my-board (calc-ep-origin-sq my-good my-epsq)))
    (= (color->pawn (other-color my-good)) (get-man my-board (calc-ep-victim-sq my-good my-epsq)))
    (board-has-epsq-pawn-attacker? my-board my-good my-epsq)))

;;; Other board formulation

(defun other-board (my-board)
  "Formulate the flipped version of the input board."
  (let ((result (make-board)))
    (dosqs (sq)
      (put-man result sq (other-man (get-man my-board (other-sq sq)))))
    result))

;;; Board MPD decoding

(defun is-char-mpd-skip-digit? (my-char)
  "Return t if the given character can be used as a skip digit in a FEN MPD field."
  (if (is-char-digitchar? my-char)
    (let ((dc-val (digitchar->integer my-char)))
      (and (>= dc-val 1) (<= dc-val file-limit)))))

(defun is-char-mpd-man? (my-char)
  "Return t if the given character can be used as a man in a FEN MPD field."
  (let ((man (char->man my-char)))
    (and man (< man man-rlimit))))

(defun is-char-mpd? (my-char)
  "Return t if the given character can be used in a FEN Man Placement Data field."
  (or (char= my-char ascii-slash) (is-char-mpd-skip-digit? my-char) (is-char-mpd-man? my-char)))

(defun stream->board (my-stream)
  "Decode a FEN MPD (Man Placement Data) from a stream; return a board or an error symbol."
  (let ((result nil) (ch nil))
    (skip-whitespace my-stream)
    (setf ch (get-char my-stream))
    (cond
      ((not ch)
        (setf result errorsym))
      ((not (is-char-mpd? ch))
        (unget-char my-stream ch)
        (setf result errorsym))
      (t
        (let ((file file-a) (rank rank-8))
          (setf result (make-board))
          (dowhile (and ch (ne? result errorsym) (is-char-mpd? ch))
            (cond
              ((char= ch ascii-slash)
                (if (= rank rank-1)
                  (progn (unget-char my-stream ch) (setf result errorsym))
                  (progn
                    (dowhile (< file file-limit)
                      (clr-man result (file+rank->sq file rank))
                      (incf file))
                    (setf file file-a)
                    (decf rank)
                    (setf ch (get-char my-stream)))))
              ((is-char-mpd-skip-digit? ch)
                (if (= file file-limit)
                  (progn (unget-char my-stream ch) (setf result errorsym))
                  (let ((dc-val (digitchar->integer ch)))
                    (if (< (- file-limit file) dc-val)
                      (progn (unget-char my-stream ch) (setf result errorsym))
                      (progn
                        (dotimes (index dc-val)
                          (put-man result (file+rank->sq file rank) man-v0)
                          (incf file))
                        (setf ch (get-char my-stream)))))))
              ((is-char-mpd-man? ch)
                (if (= file file-limit)
                  (progn (unget-char my-stream ch) (setf result errorsym))
                  (progn
                    (put-man result (file+rank->sq file rank) (char->man ch))
                    (incf file)
                    (setf ch (get-char my-stream)))))
              (t
                (error "stream->board: cond fault"))))
          (when (ne? result errorsym)
            (when ch
              (unget-char my-stream ch))
            (if (/= rank rank-1)
              (setf result errorsym)
              (dowhile (< file file-limit)
                (clr-man result (file+rank->sq file rank))
                (incf file)))))))
    result))

(defun string->board (my-string)
  "Calculate a board from a string; return nil on error."
  (let ((result nil) (str-stream (make-string-input-stream my-string)))
    (setf result (stream->board str-stream))
    (close str-stream)
    result))

;;; ---------- Pawn promotions

(defconstant prom-knight 0 "Pawn promotion to a knight")
(defconstant prom-bishop 1 "Pawn promotion to a bishop")
(defconstant prom-rook   2 "Pawn promotion to a rook")
(defconstant prom-queen  3 "Pawn promotion to a queen")

(defconstant prom-limit (1+ prom-queen) "Number of possible promotion kinds")

(defconstant prom-piece-vec
  (make-array prom-limit
    :initial-contents
      (vector piece-knight piece-bishop piece-rook piece-queen)))

(defmacro prom->piece (my-prom) `(svref prom-piece-vec ,my-prom))

;;; ---------- More move special case declarations

(defconstant msc-promotion-list (list msc-ppq msc-ppn msc-ppr msc-ppb))

(defconstant msc-diago-promotion-list (list msc-ppq msc-ppb))
(defconstant msc-ortho-promotion-list (list msc-ppq msc-ppr))

(defconstant msc-castling-flank-vec
  (make-array msc-limit
    :initial-contents
      (vector nil nil flank-q flank-k nil nil nil nil)))

(defmacro msc->castling-flank (my-msc) `(svref  msc-castling-flank-vec ,my-msc))

(defconstant msc-prom-vec
  (make-array msc-limit
    :initial-contents
      (vector nil nil nil nil prom-knight prom-bishop prom-rook prom-queen)))

(defmacro msc->prom (my-msc) `(svref msc-prom-vec ,my-msc))

(defconstant color-msc-castling-vec
  (make-array (list color-rlimit msc-limit)
    :initial-contents
      (vector
        (vector nil nil castling-wq castling-wk nil nil nil nil)
        (vector nil nil castling-bq castling-bk nil nil nil nil))))

(defmacro color+msc->castling (my-color my-msc) `(aref color-msc-castling-vec ,my-color ,my-msc))

(defconstant castling-msc-vec (make-array castling-limit :initial-contents (vector msc-cqs msc-cks msc-cqs msc-cks)))

(defmacro castling->msc (my-castling) `(svref castling-msc-vec ,my-castling))

(defconstant is-msc-regular-vec    (make-array msc-limit :initial-contents (vector t   nil nil nil nil nil nil nil)))
(defconstant is-msc-en-passant-vec (make-array msc-limit :initial-contents (vector nil t   nil nil nil nil nil nil)))
(defconstant is-msc-castling-vec   (make-array msc-limit :initial-contents (vector nil nil t   t   nil nil nil nil)))
(defconstant is-msc-promotion-vec  (make-array msc-limit :initial-contents (vector nil nil nil nil t   t   t   t  )))

(defmacro is-msc-regular?    (my-msc) `(svref is-msc-regular-vec    ,my-msc))
(defmacro is-msc-en-passant? (my-msc) `(svref is-msc-en-passant-vec ,my-msc))
(defmacro is-msc-castling?   (my-msc) `(svref is-msc-castling-vec   ,my-msc))
(defmacro is-msc-promotion?  (my-msc) `(svref is-msc-promotion-vec  ,my-msc))

;;; ---------- Move flags

(defconstant mf-andf  0 "Move SAN needs file letter disambiguation")
(defconstant mf-andr  1 "Move SAN needs rank digit disambiguation")
(defconstant mf-book  2 "Move is from a book")
(defconstant mf-bust  3 "Move is broken; usually means passive king in check")
(defconstant mf-cert  4 "Move has certain score")
(defconstant mf-chck  5 "Move checks the opponent's king")
(defconstant mf-chmt  6 "Move checkmates the opponent's king")
(defconstant mf-dbfm  7 "Move draws by fifty moves")
(defconstant mf-dbim  8 "Move draws by insufficient material")
(defconstant mf-dbrp  9 "Move draws by repetition")
(defconstant mf-dbsm 10 "Move draws by stalemate")
(defconstant mf-draw 11 "Move draws")
(defconstant mf-gain 12 "Move does gain material")
(defconstant mf-hold 13 "Move does not gain material")
(defconstant mf-note 14 "Move has andf/andr/chck/chmt notation flags set as needed")
(defconstant mf-null 15 "Move is null (a pass)")
(defconstant mf-srch 16 "Move has been searched")
(defconstant mf-tblb 17 "Move is from a tablebase")
(defconstant mf-term 18 "Move terminates game")
(defconstant mf-void 19 "Move is void (a placeholder)")

(defconstant mf-limit (1+ mf-void) "Number of different move flags")

(defconstant mf-index-list
  (list
    mf-andf mf-andr mf-book mf-bust mf-cert mf-chck mf-chmt mf-dbfm
    mf-dbim mf-dbrp mf-dbsm mf-draw mf-gain mf-hold mf-note mf-null
    mf-srch mf-tblb mf-term mf-void))

(defmacro domfs ((my-mf-var) &body my-body)
  "Construct a per move flag iteration loop."
  `(dolist (,my-mf-var mf-index-list)
    ,@my-body))

(defmacro make-mfbits () `(make-array mf-limit :element-type bitsym :initial-element 0))

(defmacro mfbits-clone (my-mfbits) `(copy-seq ,my-mfbits))

(defmacro is-mf-set? (my-mfbits my-mf)
  "Determine if the given move flag is set."
  `(one? (sbit ,my-mfbits ,my-mf)))

(defmacro is-mf-reset? (my-mfbits my-mf)
  "Determine if the given move flag is reset."
  `(zero? (sbit ,my-mfbits ,my-mf)))

(defconstant mf-string-vec
  (make-array mf-limit
    :initial-contents
      (vector
        "andf" "andr" "book" "bust" "cert" "chck" "chmt" "dbfm"
        "dbim" "dbrp" "dbsm" "draw" "gain" "hold" "note" "null"
        "srch" "tblb" "term" "void")))

(defmacro mf->string (my-mf) `(svref mf-string-vec ,my-mf))

(defun encode-mfbits (my-stream my-mfbits)
  "Encode the mfbits on the stream."
  (format my-stream "[")
  (let ((needspace nil))
    (domfs (mf)
      (when (is-mf-set? my-mfbits mf)
        (when needspace
          (blank my-stream))
        (format my-stream "~A" (mf->string mf))
        (setf needspace t))))
  (format my-stream "]")
  (values))

(defun mfbits->string (my-mfbits)
  "Encode the mfbits on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-mfbits str-stream my-mfbits)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

;;; ---------- Structure fgpair

(defstruct
  (fgpair
    (:print-function meta-encode-fgpair))
  "Full move number / good color pair."
  (fmvn 1 :type fixnum)            ; Full move number
  (good color-white :type fixnum)) ; Color on the move

(defun encode-fgpair (my-stream my-fgpair)
  "Encode the fgpair on the stream."
  (format my-stream "~D" (fgpair-fmvn my-fgpair))
  (if (is-color-black? (fgpair-good my-fgpair))
    (format my-stream "..."))
  (values))

(defun meta-encode-fgpair (my-fgpair my-stream my-level)
  "Glue to encode a fgpair structure."
  (declare (ignore my-level))
  (encode-fgpair my-stream my-fgpair)
  (values))

(defun fgpair->string (my-fgpair)
  "Encode the fgpair on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-fgpair str-stream my-fgpair)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun fgpair-clone (my-fgpair)
  "Return a clone of the given fgpair."
  (make-fgpair
    :fmvn (fgpair-fmvn my-fgpair)
    :good (fgpair-good my-fgpair)))

(defun fgpair-flip-color (my-fgpair)
  "Flip the color of the fgpair."
  (setf (fgpair-good my-fgpair) (other-color (fgpair-good my-fgpair)))
  (values))

(defun fgpair-incf (my-fgpair)
  "Increment the fgpair by one ply."
  (fgpair-flip-color my-fgpair)
  (when (is-color-white? (fgpair-good my-fgpair))
    (incf (fgpair-fmvn my-fgpair)))
  (values))

(defun fgpair-decf (my-fgpair)
  "Decrement the fgpair by one ply."
  (fgpair-flip-color my-fgpair)
  (when (is-color-black? (fgpair-good my-fgpair))
    (decf (fgpair-fmvn my-fgpair)))
  (values))

;;; ---------- Scores

(defconstant score-scale       1000                "All non-special scores use millipawn units")
(defconstant score-float-scale (float score-scale) "Floating point version of the score scale")

;;; Score upper/lower bounds based on 24 bit arithmetic

(defconstant score-bit-width 24                   "Should be at least this many bits is a fixnum")
(defconstant score-bit-range (2^ score-bit-width) "Range of 16,777,216 units")

;;; Special scores: the broken score (illegal position) and the infinities

(defconstant broken-score (-     score-bit-range)  "Illegal/broken/missing")
(defconstant posinf-score (1-    score-bit-range)  "Better than any possible evaluation")
(defconstant neginf-score (1+ (- score-bit-range)) "Worse than any possible evaluation")

;;; The even score

(defconstant even-score 0 "The even score; used for all draws")

;;; The score margin limit allows out of range mate/lose distances deep in a search tree

(defconstant score-margin-limit (2^ 10) "Margin limit of 1,024")

;;; Who knows what the longest possible mate might be?

(defconstant longest-mate-move-limit (2^ 13) "Longest possible mate is mate in 8,192 moves")

;;; Extrema for the mate and lose score ranges

(defconstant mate-in-1-score (1- (- posinf-score score-margin-limit)) "Mate in 1 move")
(defconstant lose-in-0-score     (+ neginf-score score-margin-limit)  "Checkmated")

;;; Some synonyms

(defconstant draw-score       even-score      "Used for known draws")
(defconstant checkmated-score lose-in-0-score "Used for good player in checkmate")

;;; Mate/lose score synthesis

(defmacro synth-mate-in-n (my-fmvc)
  "Synthesize a mate in N moves score given the full move count."
  `(- mate-in-1-score (1- ,my-fmvc)))

(defmacro synth-lose-in-n (my-fmvc)
  "Synthesize a lose in N moves score given the full move count."
  `(+ lose-in-0-score ,my-fmvc))

;;; More synonyms

(defconstant lose-in-1-score (synth-lose-in-n 1) "Checkmated in 1 move")
(defconstant mate-in-2-score (synth-mate-in-n 2) "Checkmate in 2 moves")
(defconstant lose-in-2-score (synth-lose-in-n 2) "Checkmated in 2 moves")
(defconstant mate-in-3-score (synth-mate-in-n 3) "Checkmate in 3 moves")

;;; Longest mate/longest lose scores

(defconstant longest-mate-score (synth-mate-in-n     longest-mate-move-limit))
(defconstant longest-lose-score (synth-lose-in-n (1- longest-mate-move-limit)))

;;; Range testing for mate/lose scores

(defun is-score-mating? (my-score)
  "Return t if the score is a mating score."
  (and (/= my-score broken-score) (>= my-score longest-mate-score)))

(defun is-score-losing? (my-score)
  "Return t if the score is a losing score."
  (and (/= my-score broken-score) (<= my-score longest-lose-score)))

;;; Calculate full move counts for mate/lose scores

(defun calc-mate-distance (my-score)
  "Calculate the mating distance in full moves for the given mating score."
  (1+ (- mate-in-1-score my-score)))

(defun calc-lose-distance (my-score)
  "Calculate the losing distance in full moves for the given losing score."
  (- my-score lose-in-0-score))

;;; Routines to adjust scores for moving down or up in a search tree

(defun downshift-score (my-score)
  "Adjust a score moving down one ply (time travel to future)."
  (cond
    ((= my-score broken-score)   my-score)
    ((= my-score even-score)     my-score)
    ((= my-score posinf-score)   neginf-score)
    ((= my-score neginf-score)   posinf-score)
    ((is-score-mating? my-score) (synth-lose-in-n (1- (calc-mate-distance my-score))))
    ((is-score-losing? my-score) (synth-mate-in-n     (calc-lose-distance my-score)))
    (t                           (- my-score))))

(defun upshift-score (my-score)
  "Adjust a score moving up one ply (time travel to past)."
  (cond
    ((= my-score broken-score)   my-score)
    ((= my-score even-score)     my-score)
    ((= my-score posinf-score)   neginf-score)
    ((= my-score neginf-score)   posinf-score)
    ((is-score-mating? my-score) (synth-lose-in-n     (calc-mate-distance my-score)))
    ((is-score-losing? my-score) (synth-mate-in-n (1+ (calc-lose-distance my-score))))
    (t                           (- my-score))))

;;; Score encoding

(defun encode-score (my-stream my-score)
  "Produce a formatted score on the given stream."
  (cond
    ((= my-score broken-score)
      (format my-stream "Broken"))
    ((= my-score posinf-score)
      (format my-stream "PosInf"))
    ((= my-score neginf-score)
      (format my-stream "NegInf"))
    ((= my-score even-score)
      (format my-stream "Even"))
    ((= my-score checkmated-score)
      (format my-stream "Checkmated"))
    ((is-score-mating? my-score)
      (format my-stream "MateIn~D" (calc-mate-distance my-score)))
    ((is-score-losing? my-score)
      (format my-stream "LoseIn~D" (calc-lose-distance my-score)))
    ((> my-score even-score)
      (format my-stream "+~5,3F" (/ my-score score-float-scale)))
    ((< my-score even-score)
      (format my-stream "-~5,3F" (/ (- my-score) score-float-scale)))
    (t
      (error "encode-score: cond fault: ~S" my-score)))
  (values))

(defun score->string (my-score)
  "Encode a score on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-score str-stream my-score)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
  result))

;;; ---------- Alpha/beta score window structure

(defstruct
  (window
    (:print-function meta-encode-window))
  "An alpha/beta score window; fuly open as a default."
  (alfa neginf-score :type integer)  ; The lower score bound
  (beta posinf-score :type integer)) ; The upper score bound

(defun encode-window (my-stream my-window)
  "Encode the bounds of a window on the given stream."
  (format my-stream "[~A ~A]"
    (score->string (window-alfa my-window))
    (score->string (window-beta my-window)))
  (values))

(defun meta-encode-window (my-window my-stream my-level)
  "Glue to encode a window structure."
  (declare (ignore my-level))
  (encode-window my-stream my-window)
  (values))

(defun window->string (my-window)
  "Encode a window on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-window str-stream my-window)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
  result))

(defun window-reset (my-window)
  "Reset the bounds of the given window to make the window full width."
  (setf (window-alfa my-window) neginf-score)
  (setf (window-beta my-window) posinf-score)
  (values))

(defun window-clone (my-window)
  "Return a clone of the given window."
  (make-window :alfa (window-alfa my-window) :beta (window-beta my-window)))

;;; Window downshifting (moving one ply away from the root of a search tree)

(defun downshift-window (my-window)
  "Return a downshifted window (time travel to future); original unmodified."
  (make-window
    :alfa (downshift-score (window-beta my-window))
    :beta (downshift-score (window-alfa my-window))))

;;; Window predicates

(defun is-window-cutoff? (my-window)
  "Determine if the window is a cut off (i.e., A/B intersect)."
  (>= (window-alfa my-window) (window-beta my-window)))

(defun is-window-zero-width? (my-window)
  "Determine if the window is zero width (i.e., no possible admittance, but not A/B intersect)."
  (= (1+ (window-alfa my-window)) (window-beta my-window)))

;;; Making a zero width window

(defun window->zw (my-window)
  "Make a zero width window based on the alfa of the given window."
  (make-window :alfa (window-alfa my-window) :beta (1+ (window-alfa my-window))))

;;; Score/window predicates

(defmacro is-score-outside-low? (my-score my-window)
  "Determine if the given score is below the given window."
  `(<= ,my-score (window-alfa ,my-window)))

(defmacro is-score-outside-high? (my-score my-window)
  "Determine if the given score is above the given window."
  `(>= ,my-score (window-beta ,my-window)))

(defun is-score-inside? (my-score my-window)
  "Determine if the given score is inside the given window."
  (and (> my-score (window-alfa my-window)) (< my-score (window-beta my-window))))

;;; ---------- Structure move

(defstruct
  (move
    (:print-function meta-encode-move))
  "A chess move."
  (frsq   sq-a1   :type fixnum)        ; The from square
  (tosq   sq-a1   :type fixnum)        ; The to square
  (frman  man-v0  :type fixnum)        ; The from man
  (toman  man-v0  :type fixnum)        ; The to man
  (msc    msc-reg :type fixnum)        ; Move special case indicator
  (mfbits (make-mfbits))               ; Move flags; all initially reset
  (order  0 :type integer)             ; Move ordering
  (score  broken-score :type integer)) ; Score

;; Move cloning

(defun move-clone (my-move)
  "Return a clone of the given move."
  (make-move
    :frsq   (move-frsq  my-move)
    :tosq   (move-tosq  my-move)
    :frman  (move-frman my-move)
    :toman  (move-toman my-move)
    :msc    (move-msc   my-move)
    :mfbits (mfbits-clone (move-mfbits my-move))
    :order  (move-order my-move)
    :score  (move-score my-move)))

;;; Move flag access (set/reset)

(defmacro move-set-flag (my-move my-mf)
  "Set the indicated move flag in the given move."
  `(setf (sbit (move-mfbits ,my-move) ,my-mf) 1))

(defmacro move-reset-flag (my-move my-mf)
  "Reset the indicated move flag in the given move."
  `(setf (sbit (move-mfbits ,my-move) ,my-mf) 0))

;;; Move flag access (tests)

(defmacro is-move-flag-set? (my-move my-mf)
  "Determine if the given move has the indicated move flag set."
  `(is-mf-set? (move-mfbits ,my-move) ,my-mf))

(defmacro is-move-flag-reset? (my-move my-mf)
  "Determine if the given move has the indicated move flag reset."
  `(is-mf-reset? (move-mfbits ,my-move) ,my-mf))

;;; Move predicates for flag testing

(defun is-move-marked-certain? (my-move)
  "Determine if a move is marked as a certain move."
  (is-move-flag-set? my-move mf-cert))

(defun is-move-marked-check? (my-move)
  "Determine if a move is marked as a checking move."
  (is-move-flag-set? my-move mf-chck))

(defun is-move-marked-checkmate? (my-move)
  "Determine if a move is marked as a checkmating move."
  (is-move-flag-set? my-move mf-chmt))

(defun is-move-marked-stalemate? (my-move)
  "Determine if a move is marked as a stalemating move."
  (is-move-flag-set? my-move mf-dbsm))

(defun is-move-marked-gainer? (my-move)
  "Determine if a move is marked as a gainer move."
  (is-move-flag-set? my-move mf-gain))

(defun is-move-marked-holder? (my-move)
  "Determine if a move is marked as a holder move."
  (is-move-flag-set? my-move mf-hold))

(defun is-move-marked-notated? (my-move)
  "Determine if a move is marked as a notated move."
  (is-move-flag-set? my-move mf-note))

(defun is-move-marked-null? (my-move)
  "Determine if a move is marked as a null move."
  (is-move-flag-set? my-move mf-null))

(defun is-move-marked-void? (my-move)
  "Determine if a move is marked as a void move."
  (is-move-flag-set? my-move mf-void))

;;; Null/void combined test

(defun is-move-null-or-void? (my-move)
  "Determine if a move is morked null or void."
  (or (is-move-marked-null? my-move) (is-move-marked-void? my-move)))

;;; Mover (color) determination

(defun move->mover (my-move)
  "Determine the color of the mover for the given move."
  (if (is-move-null-or-void? my-move)
    color-vacant
    (man->color (move-frman my-move))))

;; Hash from move

(defun move->hash (my-move)
  "Return the hash of a move."
  (let ((result (make-hash)))
    (unless (is-move-null-or-void? my-move)
      (let
        (
          (frsq   (move-frsq  my-move))
          (tosq   (move-tosq  my-move))
          (frman  (move-frman my-move))
          (toman  (move-toman my-move))
          (msc    (move-msc   my-move))
        )
        (hash-xor2d result (man+sq->hash frman frsq))
        (hash-xor2d result (man+sq->hash frman tosq))
        (unless (is-man-vacant? toman)
          (hash-xor2d result (man+sq->hash toman tosq)))
        (hash-xor2d result (msc->hash msc))))
    result))

;;; Integral mapping

(defun move->nemo (my-move)
  "Return the integer scalar version of a move (nemo; numeric equivalent move ordinal)."
  (logior
        (move-frsq  my-move)
   (ash (move-tosq  my-move)  6)
   (ash (move-frman my-move) 12)
   (ash (move-toman my-move) 16)
   (ash (move-msc   my-move) 20)))

(defun nemo->move (my-integer)
  "Return the move version of an integer scalar (nemo; numeric equivalent move ordinal)."
  (make-move
    :frsq  (logand      my-integer      63)
    :tosq  (logand (ash my-integer  -6) 63)
    :frman (logand (ash my-integer -12) 15)
    :toman (logand (ash my-integer -16) 15)
    :msc   (logand (ash my-integer -20)  7)))

;;; ---------- SAN move encoding

(defun encode-move-aux (my-stream my-move)
  "Encode the SAN form of a non-null, non-void chess move on a stream."
  (let
    (
      (frsq   (move-frsq   my-move))
      (tosq   (move-tosq   my-move))
      (frman  (move-frman  my-move))
      (toman  (move-toman  my-move))
      (msc    (move-msc    my-move))
      (mfbits (move-mfbits my-move))
    )
    (when (is-mf-set? mfbits mf-bust)
      (format my-stream "*"))
    (cond
      ;;
      ;; Regular move
      ;;
      ((is-msc-regular? msc)
        (if (is-man-pawn? frman)
          (progn
            (format my-stream "~A" (file->string (sq->file frsq)))
            (if (is-man-vacant? toman)
              (format my-stream "~A" (rank->string (sq->rank tosq)))
              (format my-stream "x~A" (sq->string tosq))))
          (progn
            (format my-stream "~A" (string (piece->char (man->piece frman))))
            (when (is-mf-set? mfbits mf-andf)
              (format my-stream "~A" (file->string (sq->file frsq))))
            (when (is-mf-set? mfbits mf-andr)
              (format my-stream "~A" (rank->string (sq->rank frsq))))
            (unless (is-man-vacant? toman)
              (format my-stream "x"))
            (format my-stream "~A" (sq->string tosq)))))
      ;;
      ;; En passant move
      ;;
      ((is-msc-en-passant? msc)
        (format my-stream "~Ax~A"
          (file->string (sq->file frsq))
          (sq->string (calc-ep-victim-sq (man->color frman) tosq))))
      ;;
      ;; Castling move
      ;;
      ((is-msc-castling? msc)
        (format my-stream "~A" (flank->castling-string (msc->castling-flank msc))))
      ;;
      ;; Promotion move
      ;;
      ((is-msc-promotion? msc)
        (format my-stream "~A" (file->string (sq->file frsq)))
        (if (is-man-vacant? toman)
          (format my-stream "~A" (rank->string (sq->rank tosq)))
          (format my-stream "x~A" (sq->string tosq)))
        (format my-stream "=~A" (string (piece->char (prom->piece (msc->prom msc))))))
      ;;
      (t
        (error "encode-move-aux: bad msc: ~S" msc)))
    ;;
    ;; Checks and checkmates
    ;;
    (when (is-move-marked-check? my-move)
      (format my-stream "~A" (if (is-move-marked-checkmate? my-move) "#" "+"))))
  (values))

(defun encode-move (my-stream my-move)
  "Encode the SAN form of a chess move on a stream."
  (cond
    ((is-move-marked-null? my-move)
      (format my-stream "<null>"))
    ((is-move-marked-void? my-move)
      (format my-stream "<void>"))
    (t
      (encode-move-aux my-stream my-move)))
  (values))

(defun meta-encode-move (my-move my-stream my-level)
  "Glue to encode a move structure."
  (declare (ignore my-level))
  (encode-move my-stream my-move)
  (values))

(defun move->string (my-move)
  "Encode a move on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-move str-stream my-move)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

;;; ---------- Long text man encoding

(defun encode-man-longtext (my-stream my-man)
  "Encode the long text version of a move on the given stream."
  (format my-stream "~A ~A"
    (color->string (man->color my-man))
    (piece->string (man->piece my-man)))
  (values))

(defun man->longtext (my-man)
  "Encode the long text form of a man on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-man-longtext str-stream my-man)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

;;; ---------- Long text move encoding

(defun encode-move-longtext-aux (my-stream my-move)
  "Encode the long text form of a non-null, non-void chess move on a stream."
  (let*
    (
      (frsq   (move-frsq   my-move))
      (tosq   (move-tosq   my-move))
      (frman  (move-frman  my-move))
      (toman  (move-toman  my-move))
      (msc    (move-msc    my-move))
      (good   (move->mover my-move))
      (evil   (other-color good))
    )
    (cond
      ;;
      ;; Regular move
      ;;
      ((is-msc-regular? msc)
        (format my-stream "The ~A at square ~A"
          (man->longtext frman)
          (sq->string frsq))
        (if (is-man-vacant? toman)
          (format my-stream " moves to square ~A" (sq->string tosq))
          (format my-stream " captures the ~A at square ~A"
            (man->longtext toman)
            (sq->string tosq))))
      ;;
      ;; En passant move
      ;;
      ((is-msc-en-passant? msc)
        (format my-stream "The ~A at square ~A moves to square ~A and captures the ~A at square ~A en passant"
          (man->longtext frman)
          (sq->string frsq)
          (sq->string tosq)
          (man->longtext (color->pawn evil))
          (sq->string (calc-ep-victim-sq good tosq))))
      ;;
      ;; Castling move
      ;;
      ((is-msc-castling? msc)
        (format my-stream "~A castles ~A"
          (player->string good)
          (flank->string (msc->castling-flank msc))))
      ;;
      ;; Promotion move
      ;;
      ((is-msc-promotion? msc)
        (format my-stream "The ~A at square ~A"
          (man->longtext frman)
          (sq->string frsq))
        (if (is-man-vacant? toman)
          (format my-stream " moves to square ~A" (sq->string tosq))
          (format my-stream " captures the ~A at square ~A"
            (man->longtext toman)
            (sq->string tosq)))
        (format my-stream " and promotes to a ~A" (piece->string (prom->piece (msc->prom msc)))))
      ;
      (t
        (error "encode-move-longtext-aux: bad msc: ~S" msc)))
    ;;
    ;; Stalemates, checkmates, and checks
    ;;
    (cond
      ((is-move-marked-stalemate? my-move)
        (format my-stream " giving stalemate"))
      ((is-move-marked-checkmate? my-move)
        (format my-stream " giving checkmate"))
      ((is-move-marked-check? my-move)
        (format my-stream " giving check"))
      (t
        nil))
    ;;
    ;; Final stop
    ;;
    (format my-stream "."))
  (values))

(defun encode-move-longtext (my-stream my-move)
  "Encode the long text version of a move on the given stream."
  (cond
    ((is-move-marked-null? my-move)
      (format my-stream "Null move."))
    ((is-move-marked-void? my-move)
      (format my-stream "Void move."))
    (t
      (encode-move-longtext-aux my-stream my-move)))
  (values))

(defun move->longtext (my-move)
  "Encode the long text form of a move on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-move-longtext str-stream my-move)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

;; Predicates for move kind based on move special case

(defmacro is-move-regular? (my-move)
  "Determine if a move is a regular move."
  `(is-msc-regular? (move-msc ,my-move)))

(defmacro is-move-en-passant? (my-move)
  "Determine if a move is an en passant move."
  `(is-msc-en-passant? (move-msc ,my-move)))

(defmacro is-move-castling? (my-move)
  "Determine if a move is a castling move."
  `(is-msc-castling? (move-msc ,my-move)))

(defmacro is-move-promotion? (my-move)
  "Determine if a move is a promotion move."
  `(is-msc-promotion? (move-msc ,my-move)))

(defmacro is-move-prom-knight? (my-move)
  "Determine if a move is a promotion to knight move."
  `(= (move-msc ,my-move) msc-ppn))

(defmacro is-move-prom-bishop? (my-move)
  "Determine if a move is a promotion to bishop move."
  `(= (move-msc ,my-move) msc-ppb))

(defmacro is-move-prom-rook? (my-move)
  "Determine if a move is a promotion to rook move."
  `(= (move-msc ,my-move) msc-ppr))

(defmacro is-move-prom-queen? (my-move)
  "Determine if a move is a promotion to queen move."
  `(= (move-msc ,my-move) msc-ppq))

;;; Miscellaneous move predicates

(defmacro is-move-simple-capture? (my-move)
  "Determine if a move is a simple capture."
  `(/= (move-toman ,my-move) man-v0))

(defun is-move-capture? (my-move)
  "Determine if a move is a capture."
  (or (is-move-simple-capture? my-move) (is-move-en-passant? my-move)))

(defun is-move-gainer? (my-move)
  "Determine if a move gains material."
  (or (is-move-capture? my-move) (is-move-promotion? my-move)))

(defmacro is-move-holder? (my-move)
  "Determine if a move does not gain material."
  `(not (is-move-gainer? ,my-move)))

(defmacro is-move-pawn-move? (my-move)
  "Determine if a move is a pawn move."
  `(is-man-pawn? (move-frman ,my-move)))

(defun is-move-hmvc-resetter? (my-move)
  "Determine if a move resets the halfmove counter."
  (or (is-move-simple-capture? my-move) (is-move-pawn-move? my-move)))

(defun is-move-pawn-double-advance? (my-move)
  "Determine if a move is a pawn double square advance."
  (and
    (is-move-pawn-move? my-move)
    (= (logxor (move-frsq my-move) (move-tosq my-move)) (2* file-limit))))

(defun same-moves? (my-move0 my-move1)
  "Determine if two moves are essentially the same; fields mfbits, order, and score are not significant."
  (and
    (= (move-tosq  my-move0) (move-tosq  my-move1))
    (= (move-frsq  my-move0) (move-frsq  my-move1))
    (= (move-frman my-move0) (move-frman my-move1))
    (= (move-toman my-move0) (move-toman my-move1))
    (= (move-msc   my-move0) (move-msc   my-move1))))

;;; Constant move initialization and storage

(defun constant-null-move ()
  "Constant value of the null move."
  (let ((result (make-move)))
    (move-set-flag result mf-null)
    result))

(defvar null-move nil "The null move")

(defun constant-void-move ()
  "Constant value of the void move."
  (let ((result (make-move)))
    (move-set-flag result mf-void)
    result))

(defvar void-move nil "The void move")

;;; Constant castling moves

(defun constant-castling-move-vec ()
  "Constant value of the castling move vector."
  (let ((result (make-array castling-limit :initial-element nil)))
    (docastlings (castling)
      (setf
        (svref result castling)
        (make-move
          :frsq  (castling->king-home castling)
          :tosq  (castling->king-away castling)
          :frman (color->king (castling->color castling))
          :msc   (castling->msc castling))))
    result))

(defvar castling-move-vec nil "The four castling moves")

(defmacro castling->move (my-castling) `(svref castling-move-vec ,my-castling))

;;; Other move formulation

(defun other-move (my-move)
  "Formulate the flipped version of the input move."
  (cond
    ((is-move-marked-null? my-move)
      (move-clone null-move))
    ((is-move-marked-void? my-move)
      (move-clone void-move))
    (t
      (make-move
        :frsq   (other-sq (move-frsq my-move))
        :tosq   (other-sq (move-tosq my-move))
        :frman  (other-man (move-frman my-move))
        :toman  (other-man (move-toman my-move))
        :msc    (move-msc my-move)
        :mfbits (mfbits-clone (move-mfbits my-move))
        :order  (move-order my-move)
        :score  (move-score my-move)))))

;;; Encoding moves with full move number/good color prefix data

(defun encode-fgpair-move (my-stream my-fgpair my-move)
  "Encode a move vith a full move number/good color prefix string on the given stream."
  (encode-fgpair my-stream my-fgpair)
  (blank my-stream)
  (encode-move my-stream my-move)
  (values))

(defun fgpair+move->string (my-fgpair my-move)
  "Encode an fgpair and a move on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-fgpair-move str-stream my-fgpair my-move)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun encode-fgpair-moves (my-stream my-fgpair my-moves)
  "Encode a move list vith a full move number/good color prefixes on the given stream."
  (when my-moves
    (let ((fgpair (fgpair-clone my-fgpair)) (moves my-moves))
      (encode-fgpair-move my-stream fgpair (pop moves))
      (dowhile moves
        (fgpair-incf fgpair)
        (blank my-stream)
        (when (is-color-white? (fgpair-good fgpair))
          (encode-fgpair my-stream fgpair)
          (blank my-stream))
        (encode-move my-stream (pop moves)))))
  (values))

(defun fgpair+moves->string (my-fgpair my-moves)
  "Encode an fgpair and a move sequence on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-fgpair-moves str-stream my-fgpair my-moves)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

;;; ---------- Move square effects; used for board movies

(defun move->changed-sqs (my-move)
  "For the given move, return a list of squares with changed contents."
  (let ((result nil))
    (unless (is-move-null-or-void? my-move)
      (let
        (
          (frsq (move-frsq my-move))
          (tosq (move-tosq my-move))
          (msc  (move-msc  my-move))
        )
        (push frsq result)
        (push tosq result)
        (cond
          ((is-msc-regular? msc)
            nil)
          ((is-msc-en-passant? msc)
            (push (calc-ep-victim-sq (move->mover my-move) tosq) result))
          ((is-msc-castling? msc)
            (let ((castling (color+msc->castling (move->mover my-move) msc)))
              (push (castling->rook-home castling) result)
              (push (castling->rook-away castling) result)))
          ((is-msc-promotion? msc)
            nil)
          (t
            (error "move->changed-sqs: cond fault ~S" msc)))))
    result))

;;; ---------- Board movies

(defun board-movie-start (my-stream my-board)
  "Start a board movie."
  (ansi-screen-reset my-stream)
  (encode-board-graphic-color my-stream my-board)
  (ansi-cursor-hide my-stream)
  (finish-output my-stream)
  (values))

(defun board-movie-update (my-stream my-board my-move)
  "Update the board movie with a move."
  (dolist (sq (move->changed-sqs my-move))
    (ansi-cursor-to-position my-stream (2* (sq->file sq)) (other-rank (sq->rank sq)))
    (encode-board-graphic-color-sq my-stream my-board sq))
  (ansi-cursor-to-position my-stream 0 rank-limit)
  (ansi-line-clear-to-to-end my-stream)
  (finish-output my-stream)
  (values))

(defun board-movie-finish (my-stream)
  "Finish a board movie."
  (ansi-cursor-show my-stream)
  (finish-output my-stream)
  (values))

;;; ---------- Move search order calculations

(defun move-simple-est-gain (my-move)
  "Calculate a simple estimated gain for the given move."
  (+ (man->value (move-toman my-move)) (msc->value (move-msc my-move))))

;;; ---------- Move list flag set/reset

(defun movelist-set-all-single-flag (my-moves my-mf)
  "Set the indicated flag for each move in the given move list."
  (dolist (move my-moves)
    (move-set-flag move my-mf))
  my-moves)

(defun movelist-reset-all-single-flag (my-moves my-mf)
  "Reset the indicated flag for each move in the given move list."
  (dolist (move my-moves)
    (move-reset-flag move my-mf))
  my-moves)

;;; ---------- Move list certain score operations

(defun movelist-collect-certain-score-moves (my-moves)
  "Return a list of the moves with certain scores."
  (let ((result nil))
    (dolist (move my-moves)
      (when (is-move-marked-certain? move)
        (push move result)))
    result))

(defun movelist-count-certain-scores (my-moves)
  "Return a count of the moves with certain scores."
  (length (movelist-collect-certain-score-moves my-moves)))

(defun movelist-best-certain-score (my-moves)
  "Return the best certain score among moves with certain scores."
  (let ((result nil))
    (dolist (move (movelist-collect-certain-score-moves my-moves))
      (let ((score (move-score move)))
        (when (or (not result) (> score result))
          (setf result score))))
    result))

(defun movelist-collect-moves-with-certain-score (my-moves my-score)
  "Return a list of moves with the given certain score."
  (let ((result nil))
    (dolist (move (movelist-collect-certain-score-moves my-moves))
      (when (= my-score (move-score move))
        (push move result)))
    result))

(defun movelist-first-uncertain-move (my-moves)
  "Return the first uncertain move from the given move list."
  (let ((result nil) (moves my-moves))
    (dowhile (and (not result) moves)
      (let ((move (pop moves)))
        (unless (is-move-marked-certain? move)
          (setf result move))))
    result))

;;; ---------- Move picking

(defun movelist-pick-random (my-moves)
  "Return a randomly picked move; nil if no moves."
  (let ((result nil) (movecount (length my-moves)))
    (when (positive? movecount)
      (setf result (nth (acs-random movecount) my-moves)))
    result))

;;; ---------- Miscellaneous move list operations with mapcar

(defun movelist-clone (my-moves)
  "Return a clone of the given move list."
  (mapcar (function move-clone) my-moves))

(defun other-movelist (my-moves)
  "Formulate a flipped version of the given move list."
  (mapcar (function other-move) my-moves))

(defun movelist->nemolist (my-moves)
  "Return a list of nemo values from a list of moves with order preserved."
  (mapcar (function move->nemo) my-moves))

(defun movelist->sanlist (my-moves)
  "Return a list of SAN move strings from a list of moves with order preserved."
  (mapcar (function move->string) my-moves))

;;; ---------- Move vector cloning

(defun movevector-clone (my-movevector)
  "Return a clone of the given move vector."
  (let* ((limit (length my-movevector)) (result (make-array limit :initial-element nil)))
    (dotimes (index limit)
      (setf (svref result index) (move-clone (svref my-movevector index))))
    result))

;;; ---------- Move vector conversion operations

(defun movelist->movevector (my-moves)
  "Convert from a move list to a move vector with order preservation."
  (let* ((moves my-moves) (limit (length moves)) (result (make-array limit :initial-element nil)))
    (dotimes (index limit)
      (setf (svref result index) (pop moves)))
    result))

(defun movevector->movelist (my-movevector)
  "Convert from a move vector to a move list with order preservation."
  (let ((result nil) (limit (length my-movevector)))
    (dotimes (index limit)
      (push (svref my-movevector (- (1- limit) index)) result))
    result))

;;; ---------- Move vector move location

(defun movevector-locate-move-index (my-movevector my-move)
  "Locate the matching move index in the move vector; nil on fail."
  (let ((result nil) (index 0) (limit (length my-movevector)))
    (dowhile (and (not result) (< index limit))
      (if (same-moves? my-move (svref my-movevector index))
        (setf result index)
        (incf index)))
    result))

(defun movevector-locate-move-index-no-fail (my-movevector my-move)
  "Locate the matching move index in the move vector; error on fail."
  (let ((result (movevector-locate-move-index my-movevector my-move)))
    (unless result
      (error "movevector-locate-move-index-no-fail: move ~A" my-move))
    result))

(defun movevector-locate-move (my-movevector my-move)
  "Locate the matching move in the move vector; nil on fail."
  (let ((result nil) (index (movevector-locate-move-index my-movevector my-move)))
    (when index
      (setf result (svref my-movevector index)))
    result))

(defun movevector-locate-move-no-fail (my-movevector my-move)
  "Locate the matching move in the move vector; error on fail."
  (let ((result (movevector-locate-move my-movevector my-move)))
    (unless result
      (error "movevector-locate-move-no-fail: move ~A" my-move))
    result))

;; Move picking

(defun movevector-pick-best-unsearched-move (my-movevector)
  "Return the best (by order score) unsearched move."
  (let ((result nil) (bestorder nil) (limit (length my-movevector)))
    (dotimes (index limit)
      (let ((move (svref my-movevector index)))
        (when (is-move-flag-reset? move mf-srch)
          (let ((order (move-order move)))
            (when (or (not result) (> order bestorder))
              (setf bestorder order)
              (setf result move))))))
    (when result
      (move-set-flag result mf-srch))
    result))

;;; ---------- Move vector sorting

(defun movevector-sort-by-san (my-movevector)
  "Sort a move vector by SAN in place (ASCII string ordering; ascending)."
  (let*
    (
      (limit   (length my-movevector))
      (limit-1 (1- limit))
      (san-vec (make-array limit :initial-element nil))
    )
    (dotimes (index limit)
      (setf (svref san-vec index) (move->string (svref my-movevector index))))
    (dotimes (pass limit-1)
      (dotimes (pair (- limit-1 pass))
        (let ((i0 pair) (i1 (1+ pair)))
          (when (string> (svref san-vec i0) (svref san-vec i1))
            (rotatef (svref san-vec       i0) (svref san-vec       i1))
            (rotatef (svref my-movevector i0) (svref my-movevector i1)))))))
  my-movevector)

(defun movevector-sort-by-nemo (my-movevector)
  "Sort a move vector by nemo in place (numeric equivalent move ordinal; ascending)."
  (let*
    (
      (limit    (length my-movevector))
      (limit-1  (1- limit))
      (nemo-vec (make-array limit :initial-element nil))
    )
    (dotimes (index limit)
      (setf (svref nemo-vec index) (move->nemo (svref my-movevector index))))
    (dotimes (pass limit-1)
      (dotimes (pair (- limit-1 pass))
        (let ((i0 pair) (i1 (1+ pair)))
          (when (> (svref nemo-vec i0) (svref nemo-vec i1))
            (rotatef (svref nemo-vec      i0) (svref nemo-vec      i1))
            (rotatef (svref my-movevector i0) (svref my-movevector i1)))))))
  my-movevector)

(defun movevector-sort-by-order (my-movevector)
  "Sort a move vector by order in place (move order selection; descending)."
  (let*
    (
      (limit     (length my-movevector))
      (limit-1   (1- limit))
      (order-vec (make-array limit :initial-element nil))
    )
    (dotimes (index limit)
      (setf (svref order-vec index) (move-order (svref my-movevector index))))
    (dotimes (pass limit-1)
      (dotimes (pair (- limit-1 pass))
        (let ((i0 pair) (i1 (1+ pair)))
          (when (< (svref order-vec i0) (svref order-vec i1))
            (rotatef (svref order-vec     i0) (svref order-vec     i1))
            (rotatef (svref my-movevector i0) (svref my-movevector i1)))))))
  my-movevector)

(defun movevector-sort-by-score (my-movevector)
  "Sort a move vector by score in place (move score selection; descending)."
  (let*
    (
      (limit     (length my-movevector))
      (limit-1   (1- limit))
      (score-vec (make-array limit :initial-element nil))
    )
    (dotimes (index limit)
      (setf (svref score-vec index) (move-score (svref my-movevector index))))
    (dotimes (pass limit-1)
      (dotimes (pair (- limit-1 pass))
        (let ((i0 pair) (i1 (1+ pair)))
          (when (< (svref score-vec i0) (svref score-vec i1))
            (rotatef (svref score-vec     i0) (svref score-vec     i1))
            (rotatef (svref my-movevector i0) (svref my-movevector i1)))))))
  my-movevector)

;;; ---------- Move list sorting

(defun movelist-sort-by-san (my-moves)
  "Return a list of moves sorted by SAN (ASCII string ascending; canonical ordering)."
  (movevector->movelist (movevector-sort-by-san (movelist->movevector my-moves))))

(defun movelist-sort-by-nemo (my-moves)
  "Return a list of moves sorted by nemo (numeric equivalent move ordinal ascending)."
  (movevector->movelist (movevector-sort-by-nemo (movelist->movevector my-moves))))

(defun movelist-sort-by-order (my-moves)
  "Return a list of moves sorted by order (move order selection; descending)."
  (movevector->movelist (movevector-sort-by-order (movelist->movevector my-moves))))

(defun movelist-sort-by-score (my-moves)
  "Return a list of moves sorted by score (descending)."
  (movevector->movelist (movevector-sort-by-score (movelist->movevector my-moves))))

;;; ---------- Structure bb

(defstruct
  (bb
    (:print-function meta-encode-bb))
  "A bitboard (64 values of type bit)."
  (b-vec (make-array sq-limit :element-type bitsym :initial-element 0)))

(defun encode-bb (my-stream my-bb)
  "Encode a bitboard to a stream."
  (format my-stream "[")
  (let ((b-vec (bb-b-vec my-bb)) (needspace nil))
    (dosqs (sq)
      (when (one? (sbit b-vec sq))
        (when needspace
          (blank my-stream))
        (format my-stream "~A" (sq->string sq))
        (setf needspace t))))
  (format my-stream "]")
  (values))

(defun meta-encode-bb (my-bb my-stream my-level)
  "Glue to encode a bb structure."
  (declare (ignore my-level))
  (encode-bb my-stream my-bb)
  (values))

(defun bb->string (my-bb)
  "Encode a bitboard on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-bb str-stream my-bb)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defmacro bb-copy (my-bb0 my-bb1)
  "Copy the contents of the first bitboard into the second bitboard."
  `(let ((b0-vec (bb-b-vec ,my-bb0)) (b1-vec (bb-b-vec ,my-bb1)))
    (dosqs (sq)
      (setf (sbit b1-vec sq) (sbit b0-vec sq)))))

(defun bb-clone (my-bb)
  "Return a clone of the given bitboard."
  (make-bb :b-vec (copy-seq (bb-b-vec my-bb))))

(defun bb-reset (my-bb)
  "Reset the given bitboard."
  (let ((b-vec (bb-b-vec my-bb)))
    (dosqs (sq)
      (setf (sbit b-vec sq) 0)))
  (values))

;;; Equality testing

(defmacro bb-eq? (my-bb0 my-bb1)
  "Determine if the two bitboards have the same value."
  `(equalp ,my-bb0 ,my-bb1))

;;; Square reset/set/test

(defmacro bb-reset-sq (my-bb my-sq)
  "Reset a square in a bitboard."
  `(setf (sbit (bb-b-vec ,my-bb) ,my-sq) 0))

(defmacro bb-set-sq (my-bb my-sq)
  "Set a square in a bitboard."
  `(setf (sbit (bb-b-vec ,my-bb) ,my-sq) 1))

(defmacro bb-sq-reset? (my-bb my-sq)
  "Determine if a square in a bitboard is reset."
  `(zero? (sbit (bb-b-vec ,my-bb) ,my-sq)))

(defmacro bb-sq-set? (my-bb my-sq)
  "Determine if a square in a bitboard is set."
  `(one? (sbit (bb-b-vec ,my-bb) ,my-sq)))

;;; Nondestructive bit-wise operations

(defmacro bb-not1 (my-bb)
  "Return the bit-wise complement of a bitboard."
  `(make-bb :b-vec (bit-not (bb-b-vec ,my-bb) nil)))

(defmacro bb-and2 (my-bb0 my-bb1)
  "Return the bit-wise AND of two bitboards."
  `(make-bb :b-vec (bit-and (bb-b-vec ,my-bb0) (bb-b-vec ,my-bb1) nil)))

(defmacro bb-and2c2 (my-bb0 my-bb1)
  "Return the bit-wise AND of two bitboards (second argument complement)."
  `(make-bb :b-vec (bit-andc2 (bb-b-vec ,my-bb0) (bb-b-vec ,my-bb1) nil)))

(defmacro bb-ior2 (my-bb0 my-bb1)
  "Return the bit-wise OR of two bitboards."
  `(make-bb :b-vec (bit-ior (bb-b-vec ,my-bb0) (bb-b-vec ,my-bb1) nil)))

(defmacro bb-xor2 (my-bb0 my-bb1)
  "Return the bit-wise XOR of two bitboards."
  `(make-bb :b-vec (bit-xor (bb-b-vec ,my-bb0) (bb-b-vec ,my-bb1) nil)))

;;; Destructive bit-wise operations

(defmacro bb-not1d (my-bb)
  "Destructively bit-wise complement a bitboard."
  `(bit-not (bb-b-vec ,my-bb) t))

(defmacro bb-and2d (my-bb0 my-bb1)
  "Destructively bit-wise AND a bitboard with a second bitboard."
  `(bit-and (bb-b-vec ,my-bb0) (bb-b-vec ,my-bb1) t))

(defmacro bb-and2c2d (my-bb0 my-bb1)
  "Destructively bit-wise AND a bitboard with a complement of a second bitboard."
  `(bit-andc2 (bb-b-vec ,my-bb0) (bb-b-vec ,my-bb1) t))

(defun bb-and3d (my-bb0 my-bb1 my-bb2)
  "Destructively bit-wise AND a bitboard with second and third bitboards."
  (bit-and (bb-b-vec my-bb0) (bb-b-vec my-bb1) t)
  (bit-and (bb-b-vec my-bb0) (bb-b-vec my-bb2) t))

(defmacro bb-ior2d (my-bb0 my-bb1)
  "Destructively bit-wise IOR a bitboard with a second bitboard."
  `(bit-ior (bb-b-vec ,my-bb0) (bb-b-vec ,my-bb1) t))

(defun bb-ior3d (my-bb0 my-bb1 my-bb2)
  "Destructively bit-wise IOR a bitboard with second and third bitboards."
  (bit-ior (bb-b-vec my-bb0) (bb-b-vec my-bb1) t)
  (bit-ior (bb-b-vec my-bb0) (bb-b-vec my-bb2) t))

(defmacro bb-xor2d (my-bb0 my-bb1)
  "Destructively bit-wise XOR a bitboard with a second bitboard."
  `(bit-xor (bb-b-vec ,my-bb0) (bb-b-vec ,my-bb1) t))

;;; Scanning routines

(defmacro bb-first (my-bb)
  "Return the first (lowest index) square set in a bitboard; nil if none."
  `(position 1 (bb-b-vec ,my-bb)))

(defmacro bb-last (my-bb)
  "Return the last (highest index) square set in a bitboard; nil if none."
  `(position 1 (bb-b-vec ,my-bb) :from-end t))

(defmacro bb-card (my-bb)
  "Return the number of 1 bits in the given bitboard (i.e., cardinality)."
  `(reduce (function +) (bb-b-vec ,my-bb)))

;;; Miscelaneous bitboard whole object predicates

(defmacro bb-empty? (my-bb)
  "Return t if the given bitboard contains all zeroes."
  `(every (function zerop) (bb-b-vec ,my-bb)))

(defmacro bb-not-empty? (my-bb)
  "Return t if the given bitboard does not contain all zeroes."
  `(not (bb-empty? ,my-bb)))

(defmacro bb-ni2? (my-bb0 my-bb1)
  "Determine if the two bitboards have a null intersection."
  `(bb-empty? (bb-and2 ,my-bb0 ,my-bb1)))

(defmacro bb-ni3? (my-bb0 my-bb1 my-bb2)
  "Determine if the three bitboards have a null intersection."
  `(bb-empty? (bb-and2 ,my-bb0 (bb-and2 ,my-bb1 ,my-bb2))))

;;; General bitboard scanning marcros

(defmacro bb-scan ((my-bb my-sq) &body my-body)
  "Generate a bitboard scanning loop."
  `(let* ((b-vec (bb-b-vec ,my-bb)) (,my-sq (position 1 b-vec)))
    (dowhile ,my-sq
      (setf (sbit b-vec ,my-sq) 0)
      ,@my-body
      (setf ,my-sq (position 1 b-vec :start ,my-sq)))))

(defmacro bb-scan-while ((my-bb my-sq my-exp) &body my-body)
  "Generate a bitboard scanning loop with continuation test expression."
  `(let* ((b-vec (bb-b-vec ,my-bb)) (,my-sq (position 1 b-vec)))
    (dowhile (and ,my-sq ,my-exp)
      (setf (sbit b-vec ,my-sq) 0)
      ,@my-body
      (setf ,my-sq (position 1 b-vec :start ,my-sq)))))

;;; Conversion from a bitboard to ordered square list

(defun bb->sqs (my-bb)
  "Return a list of squares from a bitboard (ascending order)."
  (let ((result nil) (bb (bb-clone my-bb)))
    (bb-scan (bb sq)
      (push sq result))
    (nreverse result)))

(defun bb->rev-sqs (my-bb)
  "Return a list of squares from a bitboard (descending order)."
  (let ((result nil) (bb (bb-clone my-bb)))
    (bb-scan (bb sq)
      (push sq result))
    result))

;;; Conversion from square list to a bitboard

(defun sqs->bb (my-sqs)
  "Return a bitboard from a list of squares."
  (let ((result (make-bb)) (sqs my-sqs))
    (dolist (sq sqs)
      (bb-set-sq result sq))
    result))

;;; The empty bitboard: initialization and storage

(defun constant-empty-bb ()
  "Constant value for the empty bitboard."
  (make-bb))

(defvar empty-bb nil)

;;; The corner bitboard: initialization and storage

(defun constant-corner-bb ()
  "Constant value for the corner bitboard."
  (let ((result (make-bb)))
    (dolist (file (list file-a file-h))
      (dolist (rank (list rank-1 rank-8))
        (bb-set-sq result (file+rank->sq file rank))))
    result))

(defvar corner-bb nil)

;;; The rim bitboard: initialization and storage

(defun constant-rim-bb ()
  "Constant value for the rim bitboard."
  (let ((result (make-bb)))
    (dofiles (file)
      (doranks (rank)
        (when (or (= file file-a) (= file file-h) (= rank rank-1) (= rank rank-8))
          (bb-set-sq result (file+rank->sq file rank)))))
    result))

(defvar rim-bb nil)

;;; Bitboard files: initialization, storage, and access

(defun constant-file-bb-vec ()
  "Constant value of the constant file-bb-vec."
  (let ((result (make-array file-limit :initial-element nil)))
    (dofiles (file)
      (setf (svref result file) (make-bb))
      (doranks (rank)
        (bb-set-sq (svref result file) (file+rank->sq file rank))))
    result))

(defvar file-bb-vec nil)

(defmacro file->bb (my-file) `(svref file-bb-vec ,my-file))

;;; Bitboard ranks: initialization, storage, and access

(defun constant-rank-bb-vec ()
  "Constant value of the constant rank-bb-vec."
  (let ((result (make-array rank-limit :initial-element nil)))
    (doranks (rank)
      (setf (svref result rank) (make-bb))
      (dofiles (file)
        (bb-set-sq (svref result rank) (file+rank->sq file rank))))
    result))

(defvar rank-bb-vec nil)

(defmacro rank->bb (my-rank) `(svref rank-bb-vec ,my-rank))

;; Bitboard pawn attacks: initialization, storage, and access

(defun constant-pawn-atk-bb-vec ()
  "Constant value of the constant pawn-atk-bb-vec."
  (let ((result (make-array (list color-rlimit sq-limit) :initial-element nil)))
    (docolors (color)
      (dosqs (sq)
        (setf (aref result color sq) (sqs->bb (color+sq->pawn-atk-sqs color sq)))))
    result))

(defvar pawn-atk-bb-vec nil)

(defmacro color+sq->pawn-atk-bb (my-color my-sq) `(aref pawn-atk-bb-vec ,my-color ,my-sq))

;;; Bitboard knight attacks: initialization, storage, and access

(defun constant-knight-atk-bb-vec ()
  "Constant value of the constant knight-atk-bb-vec."
  (let ((result (make-array sq-limit :initial-element nil)))
    (dosqs (sq)
      (setf (svref result sq) (sqs->bb (sq->knight-atk-sqs sq))))
    result))

(defvar knight-atk-bb-vec nil)

(defmacro sq->knight-atk-bb (my-sq) `(svref knight-atk-bb-vec ,my-sq))

;;; Bitboard king attacks: initialization, storage, and access

(defun constant-king-atk-bb-vec ()
  "Constant value of the constant king-atk-bb-vec."
  (let ((result (make-array sq-limit :initial-element nil)))
    (dosqs (sq)
      (setf (svref result sq) (sqs->bb (sq->king-atk-sqs sq))))
    result))

(defvar king-atk-bb-vec nil)

(defmacro sq->king-atk-bb (my-sq) `(svref king-atk-bb-vec ,my-sq))

;;; Bitboard sweep attacks: initialization, storage, and access

(defun constant-sweep-atk-bb-vec ()
  "Constant value of the constant sweep-atk-bb-vec."
  (let ((result (make-array (list sq-limit dir-slimit) :initial-element nil)))
    (dosqs (sq)
      (dosweepdirs (dir)
        (setf (aref result sq dir) (sqs->bb (sq+dir->sweep-atk-sqs sq dir)))))
    result))

(defvar sweep-atk-bb-vec nil)

(defmacro sq+dir->sweep-atk-bb (my-sq my-dir) `(aref sweep-atk-bb-vec ,my-sq ,my-dir))

;;; Bitboard merged diago ray attacks: initialization, storage, and access

(defun constant-diago-rays-atk-bb-vec ()
  "Constant value of the constant diago-rays-atk-bb-vec."
  (let ((result (make-array sq-limit :initial-element nil)))
    (dosqs (sq)
      (setf (svref result sq) (make-bb))
      (dodiagodirs (dir)
        (bb-ior2d (svref result sq) (sq+dir->sweep-atk-bb sq dir))))
    result))

(defvar diago-rays-atk-bb-vec nil)

(defmacro sq->diago-rays-atk-bb (my-sq) `(svref diago-rays-atk-bb-vec ,my-sq))

;;; Bitboard merged ortho ray attacks: initialization, storage, and access

(defun constant-ortho-rays-atk-bb-vec ()
  "Constant value of the constant ortho-rays-atk-bb-vec."
  (let ((result (make-array sq-limit :initial-element nil)))
    (dosqs (sq)
      (setf (svref result sq) (make-bb))
      (doorthodirs (dir)
        (bb-ior2d (svref result sq) (sq+dir->sweep-atk-bb sq dir))))
    result))

(defvar ortho-rays-atk-bb-vec nil)

(defmacro sq->ortho-rays-atk-bb (my-sq) `(svref ortho-rays-atk-bb-vec ,my-sq))

;;; Bitboard merged sweep ray attacks: initialization, storage, and access

(defun constant-sweep-rays-atk-bb-vec ()
  "Constant value of the constant sweep-rays-atk-bb-vec."
  (let ((result (make-array sq-limit :initial-element nil)))
    (dosqs (sq)
      (setf (svref result sq) (make-bb))
      (dosweepdirs (dir)
        (bb-ior2d (svref result sq) (sq+dir->sweep-atk-bb sq dir))))
    result))

(defvar sweep-rays-atk-bb-vec nil)

(defmacro sq->sweep-rays-atk-bb (my-sq) `(svref sweep-rays-atk-bb-vec ,my-sq))

;;; Bitboard pathways: initialization, storage, and access

(defun constant-path-bb-vec ()
  "Constant value of the constant path-bb-vec."
  (let ((result (make-array (list sq-limit sq-limit) :initial-element nil)))
    (dosqs (frsq)
      (dosqs (tosq)
        (setf (aref result frsq tosq) (sqs->bb (sq+sq->path-sqs frsq tosq)))))
    result))

(defvar path-bb-vec nil)

(defmacro sq+sq->path-bb (my-frsq my-tosq) `(aref path-bb-vec ,my-frsq ,my-tosq))

;;; Bitboard squares beyond a square pair: initialization, storage, and access

(defun constant-beyond-bb-vec ()
  "Constant value of the constant beyond-bb-vec."
  (let ((result (make-array (list sq-limit sq-limit) :initial-element nil)))
    (dosqs (frsq)
      (dosqs (tosq)
        (setf (aref result frsq tosq) (sqs->bb (sq+sq->beyond-sqs frsq tosq)))))
    result))

(defvar beyond-bb-vec nil)

(defmacro sq+sq->beyond-bb (my-frsq my-tosq) `(aref beyond-bb-vec ,my-frsq ,my-tosq))

;;; Bitboard beam squares for a square pair: initialization, storage, and access

(defun constant-beam-bb-vec ()
  "Constant value of the constant beam-bb-vec."
  (let ((result (make-array (list sq-limit sq-limit) :initial-element nil)))
    (dosqs (frsq)
      (dosqs (tosq)
        (setf (aref result frsq tosq) (sqs->bb (sq+sq->beam-sqs frsq tosq)))))
    result))

(defvar beam-bb-vec nil)

(defmacro sq+sq->beam-bb (my-frsq my-tosq) `(aref beam-bb-vec ,my-frsq ,my-tosq))

;;; Bitboard castling attack squares for a castling: initialization, storage, and access

(defun constant-castling-attack-bb-vec ()
  "Constant value of the constant castling-attack-bb-vec."
  (let ((result (make-array castling-limit :initial-element nil)))
    (docastlings (castling)
      (setf (svref result castling) (sqs->bb (castling->attack-sqs castling))))
    result))

(defvar castling-attack-bb-vec nil)

(defmacro castling->attack-bb (my-castling) `(svref castling-attack-bb-vec ,my-castling))

;;; Bitboard castling vacant squares for a castling: initialization, storage, and access

(defun constant-castling-vacant-bb-vec ()
  "Constant value of the constant castling-vacant-bb-vec."
  (let ((result (make-array castling-limit :initial-element nil)))
    (docastlings (castling)
      (setf (svref result castling) (sqs->bb (castling->vacant-sqs castling))))
    result))

(defvar castling-vacant-bb-vec nil)

(defmacro castling->vacant-bb (my-castling) `(svref castling-vacant-bb-vec ,my-castling))

;;; Bitboard forward pawn track vector: initialization, storage, and access

(defun constant-pawn-track-bb-vec ()
  "Constant value of the constant pawn-track-bb-vec."
  (let ((result (make-array (list color-rlimit sq-limit) :initial-element nil)))
    (docolors (color)
      (let ((dir (color->adv-dir color)))
        (dosqs (sq)
          (setf (aref result color sq) (bb-clone (sq+dir->sweep-atk-bb sq dir))))))
    result))

(defvar pawn-track-bb-vec nil)

(defmacro color+sq->pawn-track-bb (my-color my-sq) `(aref pawn-track-bb-vec ,my-color ,my-sq))

;;; Bitboard passed pawn mask vector: initialization, storage, and access

(defun constant-passed-pawn-bb-vec ()
  "Constant value of the constant passed-pawn-bb-vec."
  (let ((result (make-array (list color-rlimit sq-limit) :initial-element nil)))
    (docolors (color)
      (dosqs (sq)
        (let ((file (sq->file sq)) (rank (sq->rank sq)) (bb (bb-clone (color+sq->pawn-track-bb color sq))))
          (when (> file file-a)
            (bb-ior2d bb (color+sq->pawn-track-bb color (file+rank->sq (1- file) rank))))
          (when (< file file-h)
            (bb-ior2d bb (color+sq->pawn-track-bb color (file+rank->sq (1+ file) rank))))
          (setf (aref result color sq) bb))))
    result))

(defvar passed-pawn-bb-vec nil)

(defmacro color+sq->passed-pawn-bb (my-color my-sq) `(aref passed-pawn-bb-vec ,my-color ,my-sq))

;;; Bitboard connected pawn mask vector: initialization, storage, and access

(defun constant-connect-pawn-bb-vec ()
  "Constant value of the constant connect-pawn-bb-vec."
  (let ((result (make-array sq-limit :initial-element nil)))
    (dosqs (sq)
      (let ((bb (make-bb)))
        (dolist (dir (list dir-se dir-e dir-ne dir-nw dir-w dir-sw))
          (let ((tosq (sq+dir->sq sq dir)))
            (when tosq
              (bb-set-sq bb tosq))))
        (setf (svref result sq) bb)))
    result))

(defvar connect-pawn-bb-vec nil)

(defmacro color+sq->connect-pawn-bb (my-sq) `(svref connect-pawn-bb-vec ,my-sq))

;;; ---------- Bitboard list operations

(defun bblist-clone (my-bbs)
  "Return a clone of the given bitboard list."
  (mapcar (function bb-clone) my-bbs))

;;; ---------- Bitboard vector operations

(defun new-bbvector (my-length)
  "Return a vector of new bitboards."
  (let ((result (make-array my-length :initial-element nil)))
    (dotimes (index my-length)
      (setf (svref result index) (make-bb)))
    result))

(defun bbvector-reset (my-bbvector)
  "Reset the elements of the given bitboard vector."
  (let ((limit (length my-bbvector)))
    (dotimes (index limit)
      (bb-reset (svref my-bbvector index))))
  (values))

(defun bbvector-clone (my-bbvector)
  "Return a clone of the given bitboard vector."
  (let* ((limit (length my-bbvector)) (result (make-array limit :initial-element nil)))
    (dotimes (index limit)
      (setf (svref result index) (bb-clone (svref my-bbvector index))))
    result))

;;; ---------- Structure bbdb

(defstruct
  (bbdb)
  "A bitboard database for a chessboard."
  (merge (make-bb) :type bb)                                                      ; All men merged
  (sweep (make-bb) :type bb)                                                      ; Sweeper men merged
  (locbc (make-array color-rlimit :initial-contents (new-bbvector color-rlimit))) ; Locus by color
  (locbm (make-array man-rlimit   :initial-contents (new-bbvector man-rlimit)))   ; Locus by man
  (atkbc (make-array color-rlimit :initial-contents (new-bbvector color-rlimit))) ; Attacked by color
  (atkfs (make-array sq-limit     :initial-contents (new-bbvector sq-limit)))     ; Attacks from squares
  (atkts (make-array sq-limit     :initial-contents (new-bbvector sq-limit))))    ; Attacks to squares

(defun bbdb-reset (my-bbdb)
  "Reset the given bitboard database."
  (bb-reset (bbdb-merge my-bbdb))
  (bb-reset (bbdb-sweep my-bbdb))
  (bbvector-reset (bbdb-locbc my-bbdb))
  (bbvector-reset (bbdb-locbm my-bbdb))
  (bbvector-reset (bbdb-atkbc my-bbdb))
  (bbvector-reset (bbdb-atkfs my-bbdb))
  (bbvector-reset (bbdb-atkts my-bbdb))
  (values))

(defun bbdb-clone (my-bbdb)
  "Return a clone of the given bitboard database."
  (make-bbdb
    :merge (bb-clone (bbdb-merge my-bbdb))
    :sweep (bb-clone (bbdb-sweep my-bbdb))
    :locbc (bbvector-clone (bbdb-locbc my-bbdb))
    :locbm (bbvector-clone (bbdb-locbm my-bbdb))
    :atkbc (bbvector-clone (bbdb-atkbc my-bbdb))
    :atkfs (bbvector-clone (bbdb-atkfs my-bbdb))
    :atkts (bbvector-clone (bbdb-atkts my-bbdb))))

(defun bbdb-calc-man-color (my-bbdb my-sq)
  "Calculate the color of the man (if any) on the given square in the given bitboard database."
  (let ((result nil))
    (if (bb-sq-reset? (bbdb-merge my-bbdb) my-sq)
      (setf result color-vacant)
      (setf result
        (if (bb-sq-set? (svref (bbdb-locbc my-bbdb) color-white) my-sq)
          color-white
          color-black)))
    result))

;;; Bitboard database attack/square tables update: add/delete/propagate/cut

(defun bbdb-atkadd (my-bbdb my-sq my-man)
  "Add attacks to a square by a man in the given bitboard database."
  (let
    (
      (color (man->color my-man))
      (piece (man->piece my-man))
      (merge (bbdb-merge my-bbdb))
      (afrbb (make-bb))
    )
    (cond
      ((= piece piece-pawn)
        (bb-copy (color+sq->pawn-atk-bb color my-sq) afrbb))
      ((= piece piece-knight)
        (bb-copy (sq->knight-atk-bb my-sq) afrbb))
      ((= piece piece-bishop)
        (dodiagodirs (dir)
          (let ((unstopped t) (sqs (sq+dir->sweep-atk-sqs my-sq dir)))
            (dowhile (and unstopped sqs)
              (let ((sq (pop sqs)))
                (bb-set-sq afrbb sq)
                (when (bb-sq-set? merge sq)
                  (setf unstopped nil)))))))
      ((= piece piece-rook)
        (doorthodirs (dir)
          (let ((unstopped t) (sqs (sq+dir->sweep-atk-sqs my-sq dir)))
            (dowhile (and unstopped sqs)
              (let ((sq (pop sqs)))
                (bb-set-sq afrbb sq)
                (when (bb-sq-set? merge sq)
                  (setf unstopped nil)))))))
      ((= piece piece-queen)
        (dosweepdirs (dir)
          (let ((unstopped t) (sqs (sq+dir->sweep-atk-sqs my-sq dir)))
            (dowhile (and unstopped sqs)
              (let ((sq (pop sqs)))
                (bb-set-sq afrbb sq)
                (when (bb-sq-set? merge sq)
                  (setf unstopped nil)))))))
      ((= piece piece-king)
        (bb-copy (sq->king-atk-bb my-sq) afrbb))
      (t
        (error "bbdb-atkadd: bad piece: ~S" piece)))
    (bb-copy afrbb (svref (bbdb-atkfs my-bbdb) my-sq))
    (bb-ior2d (svref (bbdb-atkbc my-bbdb) color) afrbb)
    (let ((atkts (bbdb-atkts my-bbdb)))
      (bb-scan (afrbb sq)
        (bb-set-sq (svref atkts sq) my-sq))))
  (values))

(defun bbdb-atkdel (my-bbdb my-sq my-man)
  "Delete attacks from a square by a man in the given bitboard database."
  (let*
    (
      (color (man->color my-man))
      (locbc (bbdb-locbc my-bbdb))
      (atkbc (bbdb-atkbc my-bbdb))
      (atkfs (bbdb-atkfs my-bbdb))
      (atkts (bbdb-atkts my-bbdb))
      (aclbb (svref locbc color))
      (abcbb (svref atkbc color))
      (afsbb (bb-clone (svref atkfs my-sq)))
    )
    (bb-reset (svref atkfs my-sq))
    (bb-scan (afsbb afssq)
      (bb-reset-sq (svref atkts afssq) my-sq)
      (when (bb-ni2? aclbb (svref atkts afssq))
        (bb-reset-sq abcbb afssq))))
  (values))

(defun bbdb-atkpro (my-bbdb my-sq)
  "Propagate attacks through a square in the given bitboard database."
  (let*
    (
      (merge (bbdb-merge my-bbdb))
      (sweep (bbdb-sweep my-bbdb))
      (atkbc (bbdb-atkbc my-bbdb))
      (atkfs (bbdb-atkfs my-bbdb))
      (atkts (bbdb-atkts my-bbdb))
      (atsbb (bb-clone (svref atkts my-sq)))
    )
    (bb-scan (atsbb atssq)
      (when (bb-sq-set? sweep atssq)
        (let*
          (
            (color (bbdb-calc-man-color my-bbdb atssq))
            (abcbb (svref atkbc color))
            (afsbb (svref atkfs atssq))
            (bysqs (sq+sq->beyond-sqs atssq my-sq))
            (unstopped t)
          )
          (dowhile (and unstopped bysqs)
            (let ((bysq (pop bysqs)))
              (bb-set-sq afsbb bysq)
              (bb-set-sq (svref atkts bysq) atssq)
              (bb-set-sq abcbb bysq)
              (when (bb-sq-set? merge bysq)
                (setf unstopped nil))))))))
  (values))

(defun bbdb-atkcut (my-bbdb my-sq)
  "Cut attacks from a square in the given bitboard database."
  (let*
    (
      (merge (bbdb-merge my-bbdb))
      (sweep (bbdb-sweep my-bbdb))
      (locbc (bbdb-locbc my-bbdb))
      (atkbc (bbdb-atkbc my-bbdb))
      (atkfs (bbdb-atkfs my-bbdb))
      (atkts (bbdb-atkts my-bbdb))
      (atsbb (bb-clone (svref atkts my-sq)))
    )
    (bb-scan (atsbb atssq)
      (when (bb-sq-set? sweep atssq)
        (let*
          (
            (color (bbdb-calc-man-color my-bbdb atssq))
            (aclbb (svref locbc color))
            (abcbb (svref atkbc color))
            (afsbb (svref atkfs atssq))
            (bysqs (sq+sq->beyond-sqs atssq my-sq))
            (unstopped t)
          )
          (dowhile (and unstopped bysqs)
            (let ((bysq (pop bysqs)))
              (bb-reset-sq afsbb bysq)
              (bb-reset-sq (svref atkts bysq) atssq)
              (when (bb-ni2? aclbb (svref atkts bysq))
                (bb-reset-sq abcbb bysq))
              (when (bb-sq-set? merge bysq)
                (setf unstopped nil))))))))
  (values))

;;; Bitboard database man placement updating: add/delete/move

(defun bbdb-add-man (my-bbdb my-sq my-man)
  "Add a man to the given bitboard database."
  (bb-set-sq (bbdb-merge my-bbdb) my-sq)
  (when (is-man-sweeper? my-man)
    (bb-set-sq (bbdb-sweep my-bbdb) my-sq))
  (bb-set-sq (svref (bbdb-locbc my-bbdb) (man->color my-man)) my-sq)
  (bb-set-sq (svref (bbdb-locbm my-bbdb) my-man) my-sq)
  (bbdb-atkcut my-bbdb my-sq)
  (bbdb-atkadd my-bbdb my-sq my-man)
  (values))

(defun bbdb-del-man (my-bbdb my-sq my-man)
  "Delete a man from the given bitboard database."
  (bb-reset-sq (bbdb-merge my-bbdb) my-sq)
  (when (is-man-sweeper? my-man)
    (bb-reset-sq (bbdb-sweep my-bbdb) my-sq))
  (bb-reset-sq (svref (bbdb-locbc my-bbdb) (man->color my-man)) my-sq)
  (bb-reset-sq (svref (bbdb-locbm my-bbdb) my-man) my-sq)
  (bbdb-atkdel my-bbdb my-sq my-man)
  (bbdb-atkpro my-bbdb my-sq)
  (values))

(defun bbdb-mov-man (my-bbdb my-frsq my-tosq my-man)
  "Move a man in the given bitboard database."
  (let
    (
      (merge   (bbdb-merge my-bbdb))
      (sweep   (bbdb-sweep my-bbdb))
      (lbcbb   (svref (bbdb-locbc my-bbdb) (man->color my-man)))
      (lbmbb   (svref (bbdb-locbm my-bbdb) my-man))
      (sweeper (is-man-sweeper? my-man))
    )
    ;;
    ;; Man delete
    ;;
    (bb-reset-sq merge my-frsq)
    (when sweeper
      (bb-reset-sq sweep my-frsq))
    (bb-reset-sq lbcbb my-frsq)
    (bb-reset-sq lbmbb my-frsq)
    (bbdb-atkdel my-bbdb my-frsq my-man)
    (bbdb-atkpro my-bbdb my-frsq)
    ;;
    ;; Man add
    ;;
    (bb-set-sq merge my-tosq)
    (when sweeper
      (bb-set-sq sweep my-tosq))
    (bb-set-sq lbcbb my-tosq)
    (bb-set-sq lbmbb my-tosq)
    (bbdb-atkcut my-bbdb my-tosq)
    (bbdb-atkadd my-bbdb my-tosq my-man))
  (values))

;;; ---------- Constant FEN (Forsyth-Edwards Notation) scalars: initial and reset values

(defconstant cia-good color-white "Chess initial array color on the move")
(defconstant cia-evil color-black "Chess initial array color not on the move")
(defconstant cia-cast cast-full   "Chess initial array castling availability bits")
(defconstant cia-epsq nil         "Chess initial array en passant target square")
(defconstant cia-hmvc 0           "Chess initial array half move counter")
(defconstant cia-fmvn 1           "Chess initial array full move number")

(defconstant cleared-good color-white "Cleared board color on the move")
(defconstant cleared-evil color-black "Cleared board color not on the move")
(defconstant cleared-cast cast-none   "Cleared board castling availability bits")
(defconstant cleared-epsq nil         "Cleared board en passant target square")
(defconstant cleared-hmvc 0           "Cleared board half move counter")
(defconstant cleared-fmvn 1           "Cleared board full move number")

;;; ---------- Constant FEN (Forsyth-Edwards Notation) strings: initial and reset values

(defconstant cia-fen     "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
(defconstant cleared-fen "8/8/8/8/8/8/8/8 w - - 0 1")

;;; ---------- Structure pos

(defstruct
  (pos
    (:include board)
    (:print-function meta-encode-pos))
  "A chess position with ancillary data"
  (good     cleared-good :type fixnum)                      ; The color (side) on the move
  (evil     cleared-evil :type fixnum)                      ; The color (side) not on the move
  (cast     cleared-cast :type fixnum)                      ; Castling availability bits
  (epsq     cleared-epsq)                                   ; En passant target square, if any
  (hmvc     cleared-hmvc :type fixnum)                      ; Half move counter
  (fmvn     cleared-fmvn :type fixnum)                      ; Full move number
  (cens     (make-census) :type census)                     ; Board census
  (trac     (make-tracker) :type tracker)                   ; Target tracker
  (bbdb     (make-bbdb) :type bbdb)                         ; Bitboard database
  (ksqv     (make-array color-rlimit :initial-element nil)) ; Location squares of kings by color
  (rmtv     (make-array color-rlimit :initial-element 0))   ; Raw material total by color
  (pdsv     (make-array color-rlimit :initial-element 0))   ; Piece distribution signatures by color
  (inch     nil)                                            ; Good king in check flag (regenerated)
  (dbch     nil)                                            ; Good king in double check flag (regenerated)
  (pmbb     (make-bb) :type bb)                             ; Pinned man bitboard (regenerated)
  (fmbb     (make-bb) :type bb)                             ; Frozen man bitboard (regenerated)
  (mdhs     (make-hash) :type hash)                         ; Merged data hash signature (board/cast/epsq)
  (pshs     (make-hash) :type hash)                         ; Pawn structure data hash signature
  (ltid     nil)                                            ; Last captured target ID (or nil)
  (cast-pdl nil)                                            ; Castling bits PDL
  (epsq-pdl nil)                                            ; En passant target PDL
  (hmvc-pdl nil)                                            ; Halfmove counter PDL
  (inch-pdl nil)                                            ; Good king in check flag PDL
  (dbch-pdl nil)                                            ; Good king in double check flag PDL
  (pmbb-pdl nil)                                            ; Pinned man bitboard PDL
  (fmbb-pdl nil)                                            ; Frozen man bitboard PDL
  (ltid-pdl nil)                                            ; Last captured target ID PDL
  (mdhx     nil)                                            ; Position history hashes (saved mdhs values)
  (pmvs     nil)                                            ; Played moves
  (fmvs     nil)                                            ; Future moves; needs to be saved at times
  (pops     0 :type fixnum)                                 ; Count of retraction pops available
  (ifen     (copy-seq cleared-fen) :type string))           ; Initial FEN string; set at position load

(defun encode-pos-fen-scalars (my-stream my-pos)
  "Encode a set of FEN scalar components from a position to a stream."
  (format my-stream "~A" (color->lc-char (pos-good my-pos)))
  (blank my-stream)
  (encode-cast my-stream (pos-cast my-pos))
  (blank my-stream)
  (encode-sq-meta my-stream (pos-epsq my-pos))
  (format my-stream " ~D ~D"
    (pos-hmvc my-pos)
    (pos-fmvn my-pos))
  (values))

(defun encode-pos (my-stream my-pos)
  "Encode a position to a stream."
  (encode-board my-stream my-pos)
  (blank my-stream)
  (encode-pos-fen-scalars my-stream my-pos)
  (values))

(defun meta-encode-pos (my-pos my-stream my-level)
  "Glue to encode a pos structure."
  (declare (ignore my-level))
  (encode-pos my-stream my-pos)
  (values))

(defun pos->string (my-pos)
  "Encode a position on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-pos str-stream my-pos)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun pos-reset-fen-scalars (my-pos)
  "Reset the FEN scalars in a position."
  (setf (pos-good my-pos) cleared-good)
  (setf (pos-evil my-pos) cleared-evil)
  (setf (pos-cast my-pos) cleared-cast)
  (setf (pos-epsq my-pos) cleared-epsq)
  (setf (pos-hmvc my-pos) cleared-hmvc)
  (setf (pos-fmvn my-pos) cleared-fmvn)
  (values))

(defun pos-reset-king-location-data (my-pos)
  "Reset the king location vector in a position."
  (let ((ksqv (pos-ksqv my-pos)))
    (docolors (color)
      (setf (svref ksqv color) nil)))
  (values))

(defun pos-reset-raw-material-data (my-pos)
  "Reset the raw material total vector in a position."
  (let ((rmtv (pos-rmtv my-pos)))
    (docolors (color)
      (setf (svref rmtv color) 0)))
  (values))

(defun pos-reset-piece-distribution-signature-data (my-pos)
  "Reset the piece distribution signature vector in a position."
  (let ((pdsv (pos-pdsv my-pos)))
    (docolors (color)
      (setf (svref pdsv color) 0)))
  (values))

(defun pos-reset-regenerated-data (my-pos)
  "Reset all regenerated data in a position."
  (setf (pos-inch my-pos) nil)
  (setf (pos-dbch my-pos) nil)
  (bb-reset (pos-pmbb my-pos))
  (bb-reset (pos-fmbb my-pos))
  (values))

(defun pos-truncate-past (my-pos)
  "Truncate all past position data."
  (setf (pos-cast-pdl my-pos) nil)
  (setf (pos-epsq-pdl my-pos) nil)
  (setf (pos-hmvc-pdl my-pos) nil)
  (setf (pos-inch-pdl my-pos) nil)
  (setf (pos-dbch-pdl my-pos) nil)
  (setf (pos-pmbb-pdl my-pos) nil)
  (setf (pos-fmbb-pdl my-pos) nil)
  (setf (pos-ltid-pdl my-pos) nil)
  (setf (pos-mdhx     my-pos) nil)
  (setf (pos-pmvs     my-pos) nil)
  (setf (pos-pops     my-pos) 0)
  (values))

(defun pos-truncate-future (my-pos)
  "Truncate all future position data."
  (setf (pos-fmvs my-pos) nil)
  (values))

(defun pos-truncate (my-pos)
  "Truncate all past and future position data."
  (pos-truncate-past   my-pos)
  (pos-truncate-future my-pos)
  (values))

(defun pos-reset (my-pos)
  "Reset the given position."
  (board-reset my-pos)
  (pos-reset-fen-scalars my-pos)
  (census-reset (pos-cens my-pos))
  (tracker-reset (pos-trac my-pos))
  (bbdb-reset (pos-bbdb my-pos))
  (pos-reset-king-location-data my-pos)
  (pos-reset-raw-material-data my-pos)
  (pos-reset-piece-distribution-signature-data my-pos)
  (pos-reset-regenerated-data my-pos)
  (hash-reset (pos-mdhs my-pos))
  (setf (pos-ltid my-pos) nil)
  (setf (pos-ifen my-pos) (copy-seq cleared-fen))
  (pos-truncate my-pos)
  (values))

(defun pos-clone (my-pos)
  "Return a clone of the given position; a relatively costly operation."
  (let ((result (make-pos)))
    (setf (pos-manv     result) (copy-seq (pos-manv my-pos)))
    (setf (pos-good     result) (pos-good my-pos))
    (setf (pos-evil     result) (pos-evil my-pos))
    (setf (pos-cast     result) (pos-cast my-pos))
    (setf (pos-epsq     result) (pos-epsq my-pos))
    (setf (pos-hmvc     result) (pos-hmvc my-pos))
    (setf (pos-fmvn     result) (pos-fmvn my-pos))
    (setf (pos-cens     result) (census-clone (pos-cens my-pos)))
    (setf (pos-trac     result) (tracker-clone (pos-trac my-pos)))
    (setf (pos-bbdb     result) (bbdb-clone (pos-bbdb my-pos)))
    (setf (pos-ksqv     result) (copy-seq (pos-ksqv my-pos)))
    (setf (pos-rmtv     result) (copy-seq (pos-rmtv my-pos)))
    (setf (pos-pdsv     result) (copy-seq (pos-pdsv my-pos)))
    (setf (pos-inch     result) (pos-inch my-pos))
    (setf (pos-dbch     result) (pos-dbch my-pos))
    (setf (pos-pmbb     result) (bb-clone (pos-pmbb my-pos)))
    (setf (pos-fmbb     result) (bb-clone (pos-fmbb my-pos)))
    (setf (pos-mdhs     result) (hash-clone (pos-mdhs my-pos)))
    (setf (pos-pshs     result) (hash-clone (pos-pshs my-pos)))
    (setf (pos-ltid     result) (pos-ltid my-pos))
    (setf (pos-cast-pdl result) (copy-seq (pos-cast-pdl my-pos)))
    (setf (pos-epsq-pdl result) (copy-seq (pos-epsq-pdl my-pos)))
    (setf (pos-hmvc-pdl result) (copy-seq (pos-hmvc-pdl my-pos)))
    (setf (pos-inch-pdl result) (copy-seq (pos-inch-pdl my-pos)))
    (setf (pos-dbch-pdl result) (copy-seq (pos-dbch-pdl my-pos)))
    (setf (pos-pmbb-pdl result) (bblist-clone (pos-pmbb-pdl my-pos)))
    (setf (pos-fmbb-pdl result) (bblist-clone (pos-fmbb-pdl my-pos)))
    (setf (pos-ltid-pdl result) (copy-seq (pos-ltid-pdl my-pos)))
    (setf (pos-mdhx     result) (hashlist-clone (pos-mdhx my-pos)))
    (setf (pos-pmvs     result) (movelist-clone (pos-pmvs my-pos)))
    (setf (pos-fmvs     result) (movelist-clone (pos-fmvs my-pos)))
    (setf (pos-pops     result) (pos-pops my-pos))
    (setf (pos-ifen     result) (copy-seq (pos-ifen my-pos)))
  result))

;;; Prior move

(defmacro pos-prior-move-count (my-pos)
  "Return the count of prior moves in a position."
  `(pos-pops ,my-pos))

(defmacro pos-has-prior-move? (my-pos)
  "Determine if the position has a prior move."
  `(positive? (pos-prior-move-count ,my-pos)))

(defun pos-prior-move (my-pos)
  "Return the last played move (if any)."
  (when (pos-has-prior-move? my-pos) (first (pos-pmvs my-pos))))

;;; Clear pathway predicates

(defun pos-clear-path? (my-pos my-frsq my-tosq)
  "Determine if there is an unobstructed path between the two squares on a line."
  (bb-ni2? (bbdb-merge (pos-bbdb my-pos)) (sq+sq->path-bb my-frsq my-tosq)))

(defun pos-clear-inline-sweep-path? (my-pos my-sq0 my-sq1 my-sq2)
  "Determine if three squares are inline and a clear pathway between the first two squares."
  (let ((dir01 (sq+sq->inline-dir my-sq0 my-sq1)))
    (when dir01
      (let ((dir12 (sq+sq->inline-dir my-sq1 my-sq2)))
        (when (and dir12 (= dir01 dir12))
          (bb-ni2? (sq+sq->path-bb my-sq0 my-sq1) (bbdb-merge (pos-bbdb my-pos))))))))

;;; Signature folding

(defmacro pos-fold-mdhs (my-pos my-hash)
  "Modify the given position's merged data hash signature."
  `(hash-xor2d (pos-mdhs ,my-pos) ,my-hash))

(defmacro pos-fold-pshs (my-pos my-hash)
  "Modify the given position's pawn structure hash signature."
  `(hash-xor2d (pos-pshs ,my-pos) ,my-hash))

;;; Signature delta application

(defun pos-apply-cast-delta-hash (my-pos my-cast0 my-cast1)
  "Calculate and apply castling availability bits delta hash."
  (pos-fold-mdhs my-pos (cast->hash my-cast0))
  (pos-fold-mdhs my-pos (cast->hash my-cast1))
  (values))

(defun pos-apply-epsq-delta-hash (my-pos my-epsq0 my-epsq1)
  "Calculate and apply en passant target delta hash."
  (when my-epsq0
    (pos-fold-mdhs my-pos (epfile->hash (sq->file my-epsq0))))
  (when my-epsq1
    (pos-fold-mdhs my-pos (epfile->hash (sq->file my-epsq1))))
  (values))

;;; Position updating for add/delete/move man

(defun pos-add-man (my-pos my-sq my-man)
  "Add a man to the given position."
  (let
    (
      (color (man->color my-man))
      (piece (man->piece my-man))
      (hash  (man+sq->hash my-man my-sq))
    )
    (put-man my-pos my-sq my-man)
    (census-add-man (pos-cens my-pos) my-man)
    (bbdb-add-man (pos-bbdb my-pos) my-sq my-man)
    (when (= piece piece-king)
      (setf (svref (pos-ksqv my-pos) color) my-sq))
    (incf (svref (pos-rmtv my-pos) color) (man->value my-man))
    (incf (svref (pos-pdsv my-pos) color) (piece->increment piece))
    (pos-fold-mdhs my-pos hash)
    (when (= piece piece-pawn)
      (pos-fold-pshs my-pos hash)))
  (values))

(defun pos-del-man (my-pos my-sq my-man)
  "Delete a man from the given position."
  (let
    (
      (color (man->color my-man))
      (piece (man->piece my-man))
      (hash  (man+sq->hash my-man my-sq))
    )
    (clr-man my-pos my-sq)
    (census-del-man (pos-cens my-pos) my-man)
    (bbdb-del-man (pos-bbdb my-pos) my-sq my-man)
    (when (= piece piece-king)
      (setf (svref (pos-ksqv my-pos) color) nil))
    (decf (svref (pos-rmtv my-pos) color) (man->value my-man))
    (decf (svref (pos-pdsv my-pos) color) (piece->increment piece))
    (pos-fold-mdhs my-pos hash)
    (when (= piece piece-pawn)
      (pos-fold-pshs my-pos hash)))
  (values))

(defun pos-mov-man (my-pos my-frsq my-tosq my-man)
  "Move a man in the given position."
  (let
    (
      (color (man->color my-man))
      (piece (man->piece my-man))
      (hash  (hash-xor2 (man+sq->hash my-man my-frsq) (man+sq->hash my-man my-tosq)))
    )
    (mov-man my-pos my-frsq my-tosq)
    (bbdb-mov-man (pos-bbdb my-pos) my-frsq my-tosq my-man)
    (when (= piece piece-king)
      (setf (svref (pos-ksqv my-pos) color) my-tosq))
    (pos-fold-mdhs my-pos hash)
    (when (= piece piece-pawn)
      (pos-fold-pshs my-pos hash)))
  (values))

;;; Position tracker target routines

(defun pos-reload-tracker (my-pos)
  "Reload the position's target tracker; done only with a new position."
  (board-reload-tracker my-pos (pos-trac my-pos))
  (values))

;;; ---------- Advanced en passant routines

(defun is-en-passant-move-playable? (my-pos my-epmove)
  "Determine if a given en passant capture move is legal in the given position."
  (let*
    (
      (result    nil)
      (good      (pos-good my-pos))
      (evil      (pos-evil my-pos))
      (epsq      (pos-epsq my-pos))
      (bbdb      (pos-bbdb my-pos))
      (ksqv      (pos-ksqv my-pos))
      (atkbc     (bbdb-atkbc bbdb))
      (good-pawn (color->pawn good))
      (evil-pawn (color->pawn evil))
      (frsq      (move-frsq my-epmove))
      (vpsq      (calc-ep-victim-sq good epsq))
    )
    (bbdb-del-man bbdb vpsq evil-pawn)
    (bbdb-mov-man bbdb frsq epsq good-pawn)
    (when (bb-sq-reset? (svref atkbc evil) (svref ksqv good))
      (setf result t))
    (bbdb-mov-man bbdb epsq frsq good-pawn)
    (bbdb-add-man bbdb vpsq evil-pawn)
    result))

(defun is-en-passant-move-playable-and-checks? (my-pos my-epmove)
  "Determine if a given en passant capture move is legal and also gives check in the given position."
  (let*
    (
      (result    nil)
      (good      (pos-good my-pos))
      (evil      (pos-evil my-pos))
      (epsq      (pos-epsq my-pos))
      (bbdb      (pos-bbdb my-pos))
      (ksqv      (pos-ksqv my-pos))
      (atkbc     (bbdb-atkbc bbdb))
      (good-pawn (color->pawn good))
      (evil-pawn (color->pawn evil))
      (frsq      (move-frsq my-epmove))
      (vpsq      (calc-ep-victim-sq good epsq))
    )
    (bbdb-del-man bbdb vpsq evil-pawn)
    (bbdb-mov-man bbdb frsq epsq good-pawn)
    (when
      (and
        (bb-sq-reset? (svref atkbc evil) (svref ksqv good))
        (bb-sq-set?   (svref atkbc good) (svref ksqv evil)))
      (setf result t))
    (bbdb-mov-man bbdb epsq frsq good-pawn)
    (bbdb-add-man bbdb vpsq evil-pawn)
    result))

(defun pos-can-cancel-en-passant? (my-pos)
  "Determine if a non-null en passant target square can be safely set to nil."
  (let ((result nil) (epsq (pos-epsq my-pos)))
    (when epsq
      (setf result t)
      (let
        (
          (good-pawn (color->pawn (pos-good my-pos)))
          (frsqs     (color+sq->pawn-atk-sqs (pos-evil my-pos) epsq))
        )
        (dowhile (and result frsqs)
          (let* ((frsq (pop frsqs)) (frman (get-man my-pos frsq)))
            (when (= frman good-pawn)
              (let ((ep-move (make-move :frsq frsq :tosq epsq :frman frman :msc msc-epc)))
                (when (is-en-passant-move-playable? my-pos ep-move)
                  (setf result nil))))))))
    result))

(defun pos-cancel-en-passant (my-pos)
  "Cancel the en passant status of the given position."
  (pos-fold-mdhs my-pos (fetch-epsq-hash (pos-epsq my-pos)))
  (setf (pos-epsq my-pos) nil)
  (values))

(defun pos-en-passant-reduction (my-pos)
  "Handle possible en passant cancellation."
  (when (pos-can-cancel-en-passant? my-pos)
    (pos-cancel-en-passant my-pos))
  (values))

;;; ---------- Position regeneration

(defun pos-regenerate-checking-data (my-pos)
  "Regenerate checking data for an updated (or new) position."
  (let*
    (
      (good         (pos-good my-pos))
      (evil         (pos-evil my-pos))
      (ksqv         (pos-ksqv my-pos))
      (bbdb         (pos-bbdb my-pos))
      (locbc        (bbdb-locbc bbdb))
      (atkbc        (bbdb-atkbc bbdb))
      (atkts        (bbdb-atkts bbdb))
      (good-king-sq (svref ksqv good))
    )
    (setf (pos-inch my-pos) (bb-sq-set? (svref atkbc evil) good-king-sq))
    (setf (pos-dbch my-pos)
      (and
        (pos-inch my-pos)
        (> (bb-card (bb-and2 (svref atkts good-king-sq) (svref locbc evil))) 1))))
  (values))

(defun pos-regenerate-pinned-data (my-pos)
  "Regenerate pinned data for an updated (or new) position."
  (let*
    (
      (bbdb  (pos-bbdb my-pos))
      (ksqv  (pos-ksqv my-pos))
      (pmbb  (pos-pmbb my-pos))
      (sweep (bbdb-sweep bbdb))
      (locbc (bbdb-locbc bbdb))
      (atkbc (bbdb-atkbc bbdb))
      (atkts (bbdb-atkts bbdb))
    )
    (bb-reset pmbb)
    (docolors (color)
      (let*
        (
          (king-sq (svref ksqv color))
          (other   (other-color color))
          (ocsm-bb (bb-and2 (svref locbc other) sweep))
          (cand-bb (bb-clone (svref locbc color)))
        )
        (bb-and3d cand-bb (sq->sweep-rays-atk-bb king-sq) (svref atkbc other))
        (bb-scan (cand-bb cand-sq)
          (when (pos-clear-path? my-pos king-sq cand-sq)
            (unless (bb-ni3? ocsm-bb (svref atkts cand-sq) (sq+sq->beyond-bb king-sq cand-sq))
              (bb-set-sq pmbb cand-sq)))))))
  (values))

(defun pos-regenerate-frozen-data (my-pos)
  "Regenerate frozen data for an updated (or new) position."
  (let*
    (
      (bbdb  (pos-bbdb my-pos))
      (ksqv  (pos-ksqv my-pos))
      (pmbb  (pos-pmbb my-pos))
      (fmbb  (pos-fmbb my-pos))
      (locbc (bbdb-locbc bbdb))
    )
    (bb-reset fmbb)
    (docolors (color)
      (let
        (
          (king-sq (svref ksqv color))
          (cand-bb (bb-and2 pmbb (svref locbc color)))
        )
        (bb-scan (cand-bb cand-sq)
          (let ((piece (man->piece (get-man my-pos cand-sq))))
            (cond
              ((= piece piece-pawn)
                (when (color+dir->pawn-freeze color (sq+sq->dir cand-sq king-sq))
                  (bb-set-sq fmbb cand-sq)))
              ((= piece piece-knight)
                (bb-set-sq fmbb cand-sq))
              ((= piece piece-bishop)
                (when (is-dir-ortho? (sq+sq->dir cand-sq king-sq))
                  (bb-set-sq fmbb cand-sq)))
              ((= piece piece-rook)
                (when (is-dir-diago? (sq+sq->dir cand-sq king-sq))
                  (bb-set-sq fmbb cand-sq)))
              ((= piece piece-queen)
                nil)
              (t
                (error "pos-regenerate-frozen-data: bad piece: ~S" piece))))))))
  (values))

(defun pos-regenerate-pin-data (my-pos)
  "Regenerate the pinned and frozen bitboards for an updated (or new) position."
  (pos-regenerate-pinned-data my-pos)
  (pos-regenerate-frozen-data my-pos)
  (values))

(defun pos-regenerate (my-pos)
  "Regenerate various position components for an updated (or new) position."
  (pos-regenerate-checking-data my-pos)
  (pos-regenerate-pin-data my-pos)
  (values))

;;; ---------- Miscellaneous position routines

(defun pos->fgpair (my-pos)
  "Return a new fgpair derived from the given position."
  (make-fgpair :good (pos-good my-pos) :fmvn (pos-fmvn my-pos)))

(defun pos-toggle-colors (my-pos)
  "Exchange good and evil in the given position."
  (rotatef (pos-good my-pos) (pos-evil my-pos))
  (values))

(defun pos-load-from-board-and-scalars (my-pos my-board my-good my-evil my-cast my-epsq my-hmvc my-fmvn)
  "Load/return a position from a board and a set of FEN scalars."
  (pos-reset my-pos)
  (let ((sm-vec (make-array piece-rlimit :initial-element nil)))
    (dosqs (sq)
      (let ((man (get-man my-board sq)))
        (unless (is-man-vacant? man)
          (push (list sq man) (svref sm-vec (man->piece man))))))
    (dolist (piece (list piece-pawn piece-knight piece-king piece-bishop piece-rook piece-queen))
      (dowhile (svref sm-vec piece)
        (let ((pair (pop (svref sm-vec piece))))
          (pos-add-man my-pos (first pair) (second pair))))))
  (setf (pos-good my-pos) my-good)
  (setf (pos-evil my-pos) my-evil)
  (setf (pos-cast my-pos) my-cast)
  (setf (pos-epsq my-pos) my-epsq)
  (setf (pos-hmvc my-pos) my-hmvc)
  (setf (pos-fmvn my-pos) my-fmvn)
  (pos-fold-mdhs my-pos (cast->hash (pos-cast my-pos)))
  (pos-fold-mdhs my-pos (fetch-epsq-hash (pos-epsq my-pos)))
  (pos-reload-tracker my-pos)
  (pos-regenerate my-pos)
  (pos-en-passant-reduction my-pos)
  (setf (pos-ifen my-pos) (pos->string my-pos))
  my-pos)

(defun new-pos ()
  "Return a new position with the chess initial array."
  (pos-load-from-board-and-scalars
    (make-pos)
    (new-board)
    cia-good
    cia-evil
    cia-cast
    cia-epsq
    cia-hmvc
    cia-fmvn))

;;; Castling permissibility

(defun pos-can-castle? (my-pos my-castling)
  "Determine if a given castling is legal in the given position."
  (let*
    (
      (good  (pos-good my-pos))
      (evil  (pos-evil my-pos))
      (cast  (pos-cast my-pos))
      (bbdb  (pos-bbdb my-pos))
      (inch  (pos-inch my-pos))
      (merge (bbdb-merge bbdb))
      (atkbc (bbdb-atkbc bbdb))
    )
    (and
      (not inch)
      (= good (castling->color my-castling))
      (cast-allows-castling? cast my-castling)
      (bb-ni2? (castling->attack-bb my-castling) (svref atkbc evil))
      (bb-ni2? (castling->vacant-bb my-castling) merge))))

;;; Pawn capture squares calculation

(defun pos-calc-pawn-capture-sqs (my-pos my-frsq my-rdir)
  "Return a list of regular pawn capture squares given a possible direction restriction."
  (let*
    (
      (result  nil)
      (good    (pos-good my-pos))
      (evil    (pos-evil my-pos))
      (bbdb    (pos-bbdb my-pos))
      (locbc   (bbdb-locbc bbdb))
      (evil-bb (svref locbc evil))
    )
    (dolist (tosq (color+sq->pawn-atk-sqs good my-frsq))
      (when
        (and
          (bb-sq-set? evil-bb tosq)
          (or
            (not my-rdir)
            (= (sq+sq->dir my-frsq tosq) my-rdir)))
        (push tosq result)))
    result))

;;; ---------- Position decoding

(defun decode-fen-good (my-stream)
  "Read a FEN good color from a stream; return value or error symbol."
  (let ((result nil) (ch nil))
    (skip-whitespace my-stream)
    (setf ch (get-char my-stream))
    (cond
      ((not ch)
        (setf result errorsym))
      ((null? (lc-char->color ch))
        (unget-char my-stream ch)
        (setf result errorsym))
      (t
        (setf result (lc-char->color ch))
        (when (>= result color-rlimit)
          (unget-char my-stream ch)
          (setf result errorsym))))
    result))

(defun decode-fen-cast (my-stream)
  "Read a FEN castling bits from a stream; return value or error symbol."
  (let ((result nil) (ch nil))
    (skip-whitespace my-stream)
    (setf ch (get-char my-stream))
    (cond
      ((not ch)
        (setf result errorsym))
      ((char= ch ascii-hyphen)
        (setf result cast-none))
      ((null? (char->castling ch))
        (unget-char my-stream ch)
        (setf result errorsym))
      (t
        (setf result (calc-cast-mask (char->castling ch)))
        (setf ch (get-char my-stream))
        (dowhile (and ch (char->castling ch))
          (setf result (logior result (calc-cast-mask (char->castling ch))))
          (setf ch (get-char my-stream)))
        (when ch
          (unget-char my-stream ch))))
    result))

(defun decode-fen-epsq (my-stream)
  "Read a FEN en passant square from a stream; return value or error symbol."
  (let ((result nil) (ch nil))
    (skip-whitespace my-stream)
    (setf ch (get-char my-stream))
    (cond
      ((not ch)
        (setf result errorsym))
      ((char= ch ascii-hyphen)
        (setf result nil))
      ((not (char->file ch))
        (unget-char my-stream ch)
        (setf result errorsym))
      (t
        (let ((file (char->file ch)))
          (setf ch (get-char my-stream))
          (cond
            ((not ch)
              (setf result errorsym))
            ((not (char->rank ch))
              (unget-char my-stream ch)
              (setf result errorsym))
            (t
              (setf result (file+rank->sq file (char->rank ch))))))))
    result))

(defun stream->pos (my-stream)
  "Decode a position from a stream; return value or error symbol."
  (let
    (
      (result nil)
      (fault  nil)
      (board  nil)
      (good   nil)
      (evil   nil)
      (cast   nil)
      (epsq   nil)
      (hmvc   nil)
      (fmvn   nil)
    )
    ;;
    ;; Read the board
    ;;
    (unless fault
      (setf board (stream->board my-stream))
      (when
        (or
          (eq? board errorsym)
          (not (is-token-end-ok? my-stream))
          (not (valid-board? board)))
        (setf fault t)))
    ;;
    ;; Read the good color
    ;;
    (unless fault
      (setf good (decode-fen-good my-stream))
      (when
        (or
          (eq? good errorsym)
          (not (is-token-end-ok? my-stream))
          (>
            (board-count-color-sq-attacks board
              (other-color good)
              (board-locate-king-by-color board good))
            2)
          (board-color-attacks-sq?
            board
            good
            (board-locate-king-by-color board (other-color good))))
        (setf fault t)))
    ;;
    ;; Calculate the evil color
    ;;
    (unless fault
      (setf evil (other-color good)))
    ;;
    ;; Read the castling availability
    ;;
    (unless fault
      (setf cast (decode-fen-cast my-stream))
      (when
        (or
          (eq? cast errorsym)
          (not (is-token-end-ok? my-stream))
          (not (vaild-board-cast-combo? board cast)))
        (setf fault t)))
    ;;
    ;; Read the en passant target square
    ;;
    (unless fault
      (setf epsq (decode-fen-epsq my-stream))
      (when
        (or
          (eq? epsq errorsym)
          (not (is-token-end-ok? my-stream))
          (and epsq (not (valid-board-good-epsq-combo? board good epsq))))
        (setf fault t)))
    ;;
    ;; Read the half move counter
    ;;
    (unless fault
      (setf hmvc (read-unsigned-integer my-stream))
      (when
        (or
          (eq? hmvc errorsym)
          (not (is-token-end-ok? my-stream))
          (and epsq (nonzero? hmvc)))
        (setf fault t)))
    ;;
    ;; Read the full move number
    ;;
    (unless fault
      (setf fmvn (read-unsigned-integer my-stream))
      (when
        (or
          (eq? fmvn errorsym)
          (not (is-token-end-ok? my-stream))
          (zero? fmvn))
        (setf fault t)))
    ;;
    ;; Handle clearing obviously superfluous en passant capture square
    ;;
    (unless fault
      (when (and epsq (not (board-has-epsq-pawn-attacker? board good epsq)))
        (setf epsq nil)))
    ;;
    ;; Create/load the position (handle clearing not so obviously superfluous en passant capture square)
    ;;
    (unless fault
      (setf result
        (pos-load-from-board-and-scalars (make-pos) board good evil cast epsq hmvc fmvn)))
    ;;
    ;; Return an error symbol if there was a problem
    ;;
    (when fault
      (setf result errorsym))
    result))

(defun string->pos (my-string)
  "Calculate a position from a string; return nil on error."
  (let ((result nil) (str-stream (make-string-input-stream my-string)))
    (setf result (stream->pos str-stream))
    (close str-stream)
    result))

;;; ---------- Move execution

(defun pos-execute (my-pos my-move)
  "Execute a move."
  (let
    (
      (mover     (pos-good my-pos))
      (save-cast (pos-cast my-pos))
      (save-epsq (pos-epsq my-pos))
      (frsq      (move-frsq  my-move))
      (tosq      (move-tosq  my-move))
      (frman     (move-frman my-move))
      (toman     (move-toman my-move))
      (msc       (move-msc   my-move))
      (notnull   (not (is-move-marked-null? my-move)))
      (tracker   (pos-trac my-pos))
    )
    ;;
    ;; Handle the future move list; pop on match, else truncate
    ;;
    (when (pos-fmvs my-pos)
      (if (same-moves? my-move (first (pos-fmvs my-pos)))
        (pop (pos-fmvs my-pos))
        (pos-truncate-future my-pos)))
    ;;
    ;; Save a history move and the position hash; cloning required
    ;;
    (push (move-clone my-move) (pos-pmvs my-pos))
    (push (hash-clone (pos-mdhs my-pos)) (pos-mdhx my-pos))
    ;;
    ;; Save copies of the cast/epsq/hmvc FEN scalars
    ;;
    (push (pos-cast my-pos) (pos-cast-pdl my-pos))
    (push (pos-epsq my-pos) (pos-epsq-pdl my-pos))
    (push (pos-hmvc my-pos) (pos-hmvc-pdl my-pos))
    ;;
    ;; Save the regeneration itmes: check status and the pinned/frozen bitboards
    ;;
    (push (pos-inch my-pos) (pos-inch-pdl my-pos))
    (push (pos-dbch my-pos) (pos-dbch-pdl my-pos))
    (push (bb-clone (pos-pmbb my-pos)) (pos-pmbb-pdl my-pos))
    (push (bb-clone (pos-fmbb my-pos)) (pos-fmbb-pdl my-pos))
    ;;
    ;; Save the value of the target ID of the just captured man, if any
    ;;
    (push (pos-ltid my-pos) (pos-ltid-pdl my-pos))
    ;;
    ;; Reset the last target ID capture
    ;;
    (setf (pos-ltid my-pos) nil)
    ;;
    ;; Increment the saved state count
    ;;
    (incf (pos-pops my-pos))
    ;;
    ;; Do the locomotion
    ;;
    (when notnull
      (cond
        ;;
        ;; Regular move
        ;;
        ((is-msc-regular? msc)
          (unless (is-man-vacant? toman)
            (pos-del-man my-pos tosq toman)
            (setf (pos-ltid my-pos) (tracker-del-sq tracker tosq)))
          (pos-mov-man my-pos frsq tosq frman)
          (tracker-move tracker frsq tosq))
        ;;
        ;; En passant move
        ;;
        ((is-msc-en-passant? msc)
          (let ((vpsq (calc-ep-victim-sq mover tosq)))
            (pos-del-man my-pos vpsq (color->pawn (other-color mover)))
            (setf (pos-ltid my-pos) (tracker-del-sq tracker vpsq))
            (pos-mov-man my-pos frsq tosq frman)
            (tracker-move tracker frsq tosq)))
        ;;
        ;; Castling move
        ;;
        ((is-msc-castling? msc)
          (let*
            (
              (castling (color+msc->castling mover msc))
              (rhsq     (castling->rook-home castling))
              (rasq     (castling->rook-away castling))
            )
            (pos-mov-man my-pos frsq tosq frman)
            (tracker-move tracker frsq tosq)
            (pos-mov-man my-pos rhsq rasq (color->rook mover))
            (tracker-move tracker rhsq rasq)))
        ;;
        ;; Promotion move
        ;;
        ((is-msc-promotion? msc)
          (unless (is-man-vacant? toman)
            (pos-del-man my-pos tosq toman)
            (setf (pos-ltid my-pos) (tracker-del-sq tracker tosq)))
          (pos-del-man my-pos frsq frman)
          (pos-add-man my-pos tosq (color+piece->man mover (prom->piece (msc->prom msc))))
          (tracker-move tracker frsq tosq))
        ;
        (t
          (error "pos-execute: bad msc: ~S" msc))))
    ;;
    ;; Update colors
    ;;
    (pos-toggle-colors my-pos)
    ;;
    ;; Update castling availability
    ;;
    (when (and notnull (/= save-cast cast-none))
      (let ((cast save-cast))
        (docastlings (castling)
          (when
            (and
              (cast-allows-castling? save-cast castling)
              (cancels-castling? castling frsq tosq))
            (setf cast (logxor cast (calc-cast-mask castling)))))
        (when (/= cast save-cast)
          (setf (pos-cast my-pos) cast)
          (pos-apply-cast-delta-hash my-pos (pos-cast my-pos) save-cast))))
    ;;
    ;; Update en passant items
    ;;
    (when save-epsq
      (setf (pos-epsq my-pos) nil)
      (pos-fold-mdhs my-pos (fetch-epsq-hash save-epsq)))
    (when (and notnull (is-move-pawn-double-advance? my-move))
      (let ((cand-epsq (+ frsq (color->adv-delta mover))))
        (when (board-has-epsq-pawn-attacker? my-pos (other-color mover) cand-epsq)
          (setf (pos-epsq my-pos) cand-epsq)
          (pos-fold-mdhs my-pos (fetch-epsq-hash cand-epsq)))))
    ;;
    ;; Update the halfmove counter
    ;;
    (if (and notnull (is-move-hmvc-resetter? my-move))
      (setf (pos-hmvc my-pos) 0)
      (incf (pos-hmvc my-pos)))
    ;;
    ;; Update the full move number
    ;;
    (when (is-color-black? mover)
      (incf (pos-fmvn my-pos)))
    ;;
    ;; Remove any pseudolegal en passant target square if no en passant capture possible
    ;;
    (pos-en-passant-reduction my-pos)
    ;;
    ;; Regenerate the check status and the pinned/frozen bitboards
    ;;
    (pos-regenerate my-pos))
  (values))

(defun pos-execute-next (my-pos)
  "Execute the next future move."
  (pos-execute my-pos (first (pos-fmvs my-pos)))
  (values))

(defun pos-execute-all (my-pos)
  "Execute all future moves."
  (dowhile (pos-fmvs my-pos)
    (pos-execute-next my-pos))
  (values))

;;; ---------- Move retraction

(defun pos-retract (my-pos)
  "Retract the previously executed move."
  (let*
    (
      (mover     (pos-evil my-pos))
      (save-cast (pos-cast my-pos))
      (save-epsq (pos-epsq my-pos))
      (save-ltid (pos-ltid my-pos))
      (last-move (pop (pos-pmvs my-pos)))
      (last-mdhs (pop (pos-mdhx my-pos)))
      (frsq      (move-frsq  last-move))
      (tosq      (move-tosq  last-move))
      (frman     (move-frman last-move))
      (toman     (move-toman last-move))
      (msc       (move-msc   last-move))
      (notnull   (not (is-move-marked-null? last-move)))
      (tracker   (pos-trac my-pos))
    )
    ;;
    ;; Save the last move as a future move
    ;;
    (push (move-clone last-move) (pos-fmvs my-pos))
    ;;
    ;; Restore the cast/epsq/hmvc FEN scalars
    ;;
    (setf (pos-cast my-pos) (pop (pos-cast-pdl my-pos)))
    (setf (pos-epsq my-pos) (pop (pos-epsq-pdl my-pos)))
    (setf (pos-hmvc my-pos) (pop (pos-hmvc-pdl my-pos)))
    ;;
    ;; Restore the regenerated data: check status and the pinned/frozen bitboards
    ;;
    (setf (pos-inch my-pos) (pop (pos-inch-pdl my-pos)))
    (setf (pos-dbch my-pos) (pop (pos-dbch-pdl my-pos)))
    (setf (pos-pmbb my-pos) (pop (pos-pmbb-pdl my-pos)))
    (setf (pos-fmbb my-pos) (pop (pos-fmbb-pdl my-pos)))
    ;;
    ;; Restore the last captured target ID, if any
    ;;
    (setf (pos-ltid my-pos) (pop (pos-ltid-pdl my-pos)))
    ;;
    ;; Decrement the saved state count
    ;;
    (decf (pos-pops my-pos))
    ;;
    ;; Undo color swap
    ;;
    (pos-toggle-colors my-pos)
    ;;
    ;; Undo castling change update
    ;;
    (when (/= (pos-cast my-pos) save-cast)
      (pos-apply-cast-delta-hash my-pos (pos-cast my-pos) save-cast))
    ;;
    ;; Undo en passant change update
    ;;
    (when (or (pos-epsq my-pos) save-epsq)
      (pos-apply-epsq-delta-hash my-pos (pos-epsq my-pos) save-epsq))
    ;;
    ;; Undo the full move number update
    ;;
    (when (is-color-black? (pos-good my-pos))
      (decf (pos-fmvn my-pos)))
    ;;
    ;; Undo the locomotion
    ;;
    (when notnull
      (cond
        ;;
        ;; Regular move
        ;;
        ((is-msc-regular? msc)
          (pos-mov-man my-pos tosq frsq frman)
          (tracker-move tracker tosq frsq)
          (unless (is-man-vacant? toman)
            (pos-add-man my-pos tosq toman)
            (tracker-add-sq tracker tosq save-ltid)))
        ;;
        ;; En passant move
        ;;
        ((is-msc-en-passant? msc)
          (let ((vpsq (calc-ep-victim-sq mover tosq)))
            (pos-mov-man my-pos tosq frsq frman)
            (tracker-move tracker tosq frsq)
            (pos-add-man my-pos vpsq (color->pawn (other-color mover)))
            (tracker-add-sq tracker vpsq save-ltid)))
        ;;
        ;; Castling move
        ;;
        ((is-msc-castling? msc)
          (let*
            (
              (castling (color+msc->castling mover msc))
              (rhsq     (castling->rook-home castling))
              (rasq     (castling->rook-away castling))
            )
            (pos-mov-man my-pos rasq rhsq (color->rook mover))
            (tracker-move tracker rasq rhsq)
            (pos-mov-man my-pos tosq frsq frman)
            (tracker-move tracker tosq frsq)))
        ;;
        ;; Promotion move
        ;;
        ((is-msc-promotion? msc)
          (pos-del-man my-pos tosq (color+piece->man mover (prom->piece (msc->prom msc))))
          (pos-add-man my-pos frsq frman)
          (tracker-move tracker tosq frsq)
          (unless (is-man-vacant? toman)
            (pos-add-man my-pos tosq toman)
            (tracker-add-sq tracker tosq save-ltid)))
        ;;
        (t
          (error "pos-retract: bad msc: ~S" msc))))
    ;;
    ;; Hash restoration check
    ;;
    (unless (hash-eq? (pos-mdhs my-pos) last-mdhs)
      (error "pos-retract: bad mdhs: ~S ~S" (pos-mdhs my-pos) last-mdhs)))
  (values))

(defun pos-retract-all (my-pos)
  "Retract the all previously executed moves."
  (dowhile (pos-pmvs my-pos)
    (pos-retract my-pos))
  (values))

;;; ---------- Position scroll repositioning

(defun pos-scroll (my-pos my-pops)
  "Scroll the given positon to the indicated pops index."
  (when (/= (pos-prior-move-count my-pos) my-pops)
    (if (< (pos-prior-move-count my-pos) my-pops)
      (dowhile (< (pos-prior-move-count my-pos) my-pops)
        (pos-execute-next my-pos))
      (dowhile (> (pos-prior-move-count my-pos) my-pops)
        (pos-retract my-pos))))
  (values))

;;; ---------- Move generation

(defun generate-evasion (my-pos)
  "Return a list of moves generated for the given position (called with good king in check)."
  (let*
    (
      (result         nil)
      (good           (pos-good my-pos))
      (evil           (pos-evil my-pos))
      (epsq           (pos-epsq my-pos))
      (bbdb           (pos-bbdb my-pos))
      (ksqv           (pos-ksqv my-pos))
      (pmbb           (pos-pmbb my-pos))
      (sweep          (bbdb-sweep bbdb))
      (locbc          (bbdb-locbc bbdb))
      (locbm          (bbdb-locbm bbdb))
      (atkbc          (bbdb-atkbc bbdb))
      (atkfs          (bbdb-atkfs bbdb))
      (atkts          (bbdb-atkts bbdb))
      (good-king-sq   (svref ksqv good))
      (good-bb        (svref locbc good))
      (good-pawn      (color->pawn good))
      (good-pawn-bb   (svref locbm good-pawn))
      (good-king      (color->king good))
      (good-r2        (svref rank2-vec good))
      (good-r7        (svref rank7-vec good))
      (adv-delta      (color->adv-delta good))
      (checker-bb     (bb-and2 (svref locbc evil) (svref atkts good-king-sq)))
      (singlecheck    (not (pos-dbch my-pos)))
      (checker-sq     (when singlecheck (bb-first checker-bb)))
      (checker-man    (if singlecheck (get-man my-pos checker-sq) man-v0))
      (interpose-test (and singlecheck (is-man-sweeper? checker-man)))
      (interpose-bb   (when interpose-test (sq+sq->path-bb good-king-sq checker-sq)))
      (interpose-flag (and interpose-test (bb-not-empty? interpose-bb)))
    )
    ;;
    ;; Try: Capture of a single checker (not including a capture by the king)
    ;;
    (when singlecheck
      (let ((frbb (bb-and2 good-bb (svref atkts checker-sq))))
        (bb-reset-sq frbb good-king-sq)
        (bb-and2c2d frbb pmbb)
        (bb-scan (frbb frsq)
          (let ((frman (get-man my-pos frsq)))
            (if (and (= frman good-pawn) (= (sq->rank frsq) good-r7))
              (dolist (msc msc-promotion-list)
                (push (make-move :frsq frsq :tosq checker-sq :frman frman :toman checker-man :msc msc) result))
              (push (make-move :frsq frsq :tosq checker-sq :frman frman :toman checker-man) result))))))
    ;;
    ;; Try: King moves (including captures by the king)
    ;;
    (let
      (
        (sweep-checker-bb (bb-and2 checker-bb sweep))
        (tobb (bb-and2c2 (sq->king-atk-bb good-king-sq) good-bb))
      )
      (bb-and2c2d tobb (svref atkbc evil))
      (bb-scan (sweep-checker-bb sweep-checker-sq)
        (let ((shadow-sq (sq+sq->shadow sweep-checker-sq good-king-sq)))
          (when shadow-sq
            (bb-reset-sq tobb shadow-sq))))
      (bb-scan (tobb tosq)
        (push (make-move :frsq good-king-sq :tosq tosq :frman good-king :toman (get-man my-pos tosq)) result)))
    ;;
    ;; Try: Interposition for a single sweep checker (not including pawn interpositinons)
    ;;
    (when interpose-flag
      (let ((frbb (bb-and2c2 good-bb pmbb)))
        (bb-reset-sq frbb good-king-sq)
        (bb-and2c2d frbb good-pawn-bb)
        (bb-scan (frbb frsq)
          (let ((tobb (bb-and2 interpose-bb (svref atkfs frsq))))
            (bb-scan (tobb tosq)
              (push (make-move :frsq frsq :tosq tosq :frman (get-man my-pos frsq)) result))))))
    ;;
    ;; Try: Interposition for a single sweep checker (only by pawn single square advance interpositions)
    ;;
    (when interpose-flag
      (let ((frbb (bb-and2c2 good-pawn-bb pmbb)))
        (bb-scan (frbb frsq)
          (let ((tosq (+ frsq adv-delta)))
            (when (bb-sq-set? interpose-bb tosq)
              (if (= (sq->rank frsq) good-r7)
                (dolist (msc msc-promotion-list)
                  (push (make-move :frsq frsq :tosq tosq :frman good-pawn :msc msc) result))
                (push (make-move :frsq frsq :tosq tosq :frman good-pawn) result)))))))
    ;;
    ;; Try: Interposition for a single sweep checker (only by pawn double square advance interpositions)
    ;;
    (when interpose-flag
      (let ((frbb (bb-and2c2 good-pawn-bb pmbb)))
        (bb-and2d frbb (rank->bb good-r2))
        (bb-scan (frbb frsq)
          (let ((tosq (+ frsq adv-delta)))
            (when (is-man-vacant? (get-man my-pos tosq))
              (incf tosq adv-delta)
              (when (bb-sq-set? interpose-bb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman good-pawn) result)))))))
    ;;
    ;; Try: En passant captures
    ;;
    (when epsq
      (let ((frbb (bb-and2 good-pawn-bb (svref atkts epsq))))
        (bb-scan (frbb frsq)
          (let ((ep-move (make-move :frsq frsq :tosq epsq :frman good-pawn :msc msc-epc)))
            (when (is-en-passant-move-playable? my-pos ep-move)
              (push ep-move result))))))
    ;;
    result))

(defun generate-nocheck (my-pos)
  "Return a list of moves generated for the given position (called with good king not in check)."
  (let*
    (
      (result       nil)
      (good         (pos-good my-pos))
      (evil         (pos-evil my-pos))
      (epsq         (pos-epsq my-pos))
      (bbdb         (pos-bbdb my-pos))
      (ksqv         (pos-ksqv my-pos))
      (pmbb         (pos-pmbb my-pos))
      (fmbb         (pos-fmbb my-pos))
      (merge        (bbdb-merge bbdb))
      (locbc        (bbdb-locbc bbdb))
      (atkbc        (bbdb-atkbc bbdb))
      (atkfs        (bbdb-atkfs bbdb))
      (good-king-sq (svref ksqv good))
      (good-bb      (svref locbc good))
      (adv-delta    (color->adv-delta good))
      (target-bb    (bb-not1 good-bb))
      (rmbb         (bb-and2c2 pmbb fmbb))
      (frbb         (bb-and2c2 good-bb fmbb))
    )
    (bb-scan (frbb frsq)
      (let*
        (
          (frman   (get-man my-pos frsq))
          (frpiece (man->piece frman))
          (afsbb   (svref atkfs frsq))
        )
        (cond
          ;;
          ;; Moves for a pawn
          ;;
          ((= frpiece piece-pawn)
            (let*
              (
                (frrank (sq->rank frsq))
                (rdir   (when (bb-sq-set? rmbb frsq) (sq+sq->dir good-king-sq frsq)))
                (r2flag (= frrank (svref rank2-vec good)))
                (r7flag (= frrank (svref rank7-vec good)))
                (pcsqs  (pos-calc-pawn-capture-sqs my-pos frsq rdir))
              )
              ;;
              ;; Advance
              ;;
              (when (or (not rdir) (= bidir-n (dir->bidir rdir)))
                (let ((tosq (+ frsq adv-delta)))
                  (when (bb-sq-reset? merge tosq)
                    (if r7flag
                      (dolist (msc msc-promotion-list)
                        (push (make-move :frsq frsq :tosq tosq :frman frman :msc msc) result))
                      (progn
                        (push (make-move :frsq frsq :tosq tosq :frman frman) result)
                        (when (and r2flag (bb-sq-reset? merge (+ tosq adv-delta)))
                          (push (make-move :frsq frsq :tosq (+ tosq adv-delta) :frman frman) result)))))))
              ;;
              ;; Capture (not en passant)
              ;;
              (dolist (tosq pcsqs)
                (let ((toman (get-man my-pos tosq)))
                  (if r7flag
                    (dolist (msc msc-promotion-list)
                      (push (make-move :frsq frsq :tosq tosq :frman frman :toman toman :msc msc) result))
                    (push (make-move :frsq frsq :tosq tosq :frman frman :toman toman) result))))
              ;;
              ;; En passant
              ;;
              (when (and epsq (find epsq (color+sq->pawn-atk-sqs good frsq)))
                (let ((ep-move (make-move :frsq frsq :tosq epsq :frman frman :msc msc-epc)))
                  (when (is-en-passant-move-playable? my-pos ep-move)
                    (push ep-move result))))))
          ;;
          ;; Moves for a knight
          ;;
          ((= frpiece piece-knight)
            (let ((tobb (bb-and2 afsbb target-bb)))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman :toman (get-man my-pos tosq)) result))))
          ;;
          ;; Moves for a sweeper
          ;;
          ((or (= frpiece piece-bishop) (= frpiece piece-rook) (= frpiece piece-queen))
            (let ((tobb (bb-and2 afsbb target-bb)))
              (when (bb-sq-set? rmbb frsq)
                (bb-and2d tobb (sq+sq->beam-bb good-king-sq frsq)))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman :toman (get-man my-pos tosq)) result))))
          ;;
          ;; Moves for a king
          ;;
          ((= frpiece piece-king)
            (let ((tobb (bb-and2c2 (bb-and2 afsbb target-bb) (svref atkbc evil))))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman :toman (get-man my-pos tosq)) result)))
            (when (nonzero? (pos-cast my-pos))
              (dolist (castling (color->castlings good))
                (when (pos-can-castle? my-pos castling)
                  (push (move-clone (castling->move castling)) result)))))
          ;;
          (t
            (error "generate-nocheck: bad frpiece: ~A" frpiece)))))
    result))

(defun generate-nocheck-gainers (my-pos)
  "Return a list of gainer moves generated for the given position (called with good king not in check)."
  (let*
    (
      (result       nil)
      (good         (pos-good my-pos))
      (evil         (pos-evil my-pos))
      (epsq         (pos-epsq my-pos))
      (bbdb         (pos-bbdb my-pos))
      (ksqv         (pos-ksqv my-pos))
      (pmbb         (pos-pmbb my-pos))
      (fmbb         (pos-fmbb my-pos))
      (merge        (bbdb-merge bbdb))
      (locbc        (bbdb-locbc bbdb))
      (atkbc        (bbdb-atkbc bbdb))
      (atkfs        (bbdb-atkfs bbdb))
      (good-king-sq (svref ksqv good))
      (good-bb      (svref locbc good))
      (evil-bb      (svref locbc evil))
      (adv-delta    (color->adv-delta good))
      (target-bb    evil-bb)
      (rmbb         (bb-and2c2 pmbb fmbb))
      (frbb         (bb-and2c2 good-bb fmbb))
    )
    (bb-scan (frbb frsq)
      (let*
        (
          (frman   (get-man my-pos frsq))
          (frpiece (man->piece frman))
          (afsbb   (svref atkfs frsq))
        )
        (cond
          ;;
          ;; Moves for a pawn
          ;;
          ((= frpiece piece-pawn)
            (let*
              (
                (frrank (sq->rank frsq))
                (rdir   (when (bb-sq-set? rmbb frsq) (sq+sq->dir good-king-sq frsq)))
                (r7flag (= frrank (svref rank7-vec good)))
                (pcsqs  (pos-calc-pawn-capture-sqs my-pos frsq rdir))
              )
              ;;
              ;; Advance (promotion only)
              ;;
              (when (and r7flag (or (not rdir) (= bidir-n (dir->bidir rdir))))
                (let ((tosq (+ frsq adv-delta)))
                  (when (bb-sq-reset? merge tosq)
                    (dolist (msc msc-promotion-list)
                      (push (make-move :frsq frsq :tosq tosq :frman frman :msc msc) result)))))
              ;;
              ;; Capture (not en passant)
              ;;
              (dolist (tosq pcsqs)
                (let ((toman (get-man my-pos tosq)))
                  (if r7flag
                    (dolist (msc msc-promotion-list)
                      (push (make-move :frsq frsq :tosq tosq :frman frman :toman toman :msc msc) result))
                    (push (make-move :frsq frsq :tosq tosq :frman frman :toman toman) result))))
              ;;
              ;; En passant
              ;;
              (when (and epsq (find epsq (color+sq->pawn-atk-sqs good frsq)))
                (let ((ep-move (make-move :frsq frsq :tosq epsq :frman frman :msc msc-epc)))
                  (when (is-en-passant-move-playable? my-pos ep-move)
                    (push ep-move result))))))
          ;;
          ;; Moves for a knight
          ;;
          ((= frpiece piece-knight)
            (let ((tobb (bb-and2 afsbb target-bb)))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman :toman (get-man my-pos tosq)) result))))
          ;;
          ;; Moves for a sweeper
          ;;
          ((or (= frpiece piece-bishop) (= frpiece piece-rook) (= frpiece piece-queen))
            (let ((tobb (bb-and2 afsbb target-bb)))
              (when (bb-sq-set? rmbb frsq)
                (bb-and2d tobb (sq+sq->beam-bb good-king-sq frsq)))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman :toman (get-man my-pos tosq)) result))))
          ;;
          ;; Moves for a king
          ;;
          ((= frpiece piece-king)
            (let ((tobb (bb-and2c2 (bb-and2 afsbb target-bb) (svref atkbc evil))))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman :toman (get-man my-pos tosq)) result))))
          ;;
          (t
            (error "generate-nocheck-gainers: bad frpiece: ~A" frpiece)))))
    ;;
    ;; Mark all moves as gainers
    ;;
    (movelist-set-all-single-flag result mf-gain)
    ;;
    result))

(defun generate-nocheck-holders (my-pos)
  "Return a list of holder moves generated for the given position (called with good king not in check)."
  (let*
    (
      (result       nil)
      (good         (pos-good my-pos))
      (evil         (pos-evil my-pos))
      (bbdb         (pos-bbdb my-pos))
      (ksqv         (pos-ksqv my-pos))
      (pmbb         (pos-pmbb my-pos))
      (fmbb         (pos-fmbb my-pos))
      (merge        (bbdb-merge bbdb))
      (locbc        (bbdb-locbc bbdb))
      (atkbc        (bbdb-atkbc bbdb))
      (atkfs        (bbdb-atkfs bbdb))
      (good-king-sq (svref ksqv good))
      (good-bb      (svref locbc good))
      (evil-bb      (svref locbc evil))
      (adv-delta    (color->adv-delta good))
      (target-bb    (bb-and2c2 (bb-not1 good-bb) evil-bb))
      (rmbb         (bb-and2c2 pmbb fmbb))
      (frbb         (bb-and2c2 good-bb fmbb))
    )
    (bb-scan (frbb frsq)
      (let*
        (
          (frman   (get-man my-pos frsq))
          (frpiece (man->piece frman))
          (afsbb   (svref atkfs frsq))
        )
        (cond
          ;;
          ;; Moves for a pawn
          ;;
          ((= frpiece piece-pawn)
            (let*
              (
                (frrank (sq->rank frsq))
                (rdir   (when (bb-sq-set? rmbb frsq) (sq+sq->dir good-king-sq frsq)))
                (r2flag (= frrank (svref rank2-vec good)))
                (r7flag (= frrank (svref rank7-vec good)))
              )
              ;;
              ;; Advance (not promotion)
              ;;
              (when (and (not r7flag) (or (not rdir) (= bidir-n (dir->bidir rdir))))
                (let ((tosq (+ frsq adv-delta)))
                  (when (bb-sq-reset? merge tosq)
                    (push (make-move :frsq frsq :tosq tosq :frman frman) result)
                    (when (and r2flag (bb-sq-reset? merge (+ tosq adv-delta)))
                      (push (make-move :frsq frsq :tosq (+ tosq adv-delta) :frman frman) result)))))))
          ;;
          ;; Moves for a knight
          ;;
          ((= frpiece piece-knight)
            (let ((tobb (bb-and2 afsbb target-bb)))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman) result))))
          ;;
          ;; Moves for a sweeper
          ;;
          ((or (= frpiece piece-bishop) (= frpiece piece-rook) (= frpiece piece-queen))
            (let ((tobb (bb-and2 afsbb target-bb)))
              (when (bb-sq-set? rmbb frsq)
                (bb-and2d tobb (sq+sq->beam-bb good-king-sq frsq)))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman) result))))
          ;;
          ;; Moves for a king
          ;;
          ((= frpiece piece-king)
            (let ((tobb (bb-and2c2 (bb-and2 afsbb target-bb) (svref atkbc evil))))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman) result)))
            (when (nonzero? (pos-cast my-pos))
              (dolist (castling (color->castlings good))
                (when (pos-can-castle? my-pos castling)
                  (push (move-clone (castling->move castling)) result)))))
          ;;
          (t
            (error "generate-nocheck-holders: bad frpiece: ~A" frpiece)))))
    ;;
    ;; Mark all moves as holders
    ;;
    (movelist-set-all-single-flag result mf-hold)
    result))

(defun generate (my-pos)
  "Return a list of moves generated for the given position."
  (if (pos-inch my-pos)
    (generate-evasion my-pos)
    (generate-nocheck my-pos)))

;;; ---------- Move counting

(defun count-moves-evasion (my-pos)
  "Return a count of moves generated for the given position (called with good king in check)."
  (let*
    (
      (result         0)
      (good           (pos-good my-pos))
      (evil           (pos-evil my-pos))
      (epsq           (pos-epsq my-pos))
      (bbdb           (pos-bbdb my-pos))
      (ksqv           (pos-ksqv my-pos))
      (pmbb           (pos-pmbb my-pos))
      (sweep          (bbdb-sweep bbdb))
      (locbc          (bbdb-locbc bbdb))
      (locbm          (bbdb-locbm bbdb))
      (atkbc          (bbdb-atkbc bbdb))
      (atkfs          (bbdb-atkfs bbdb))
      (atkts          (bbdb-atkts bbdb))
      (good-king-sq   (svref ksqv good))
      (good-bb        (svref locbc good))
      (good-pawn      (color->pawn good))
      (good-pawn-bb   (svref locbm good-pawn))
      (good-r2        (svref rank2-vec good))
      (good-r7        (svref rank7-vec good))
      (evil-bb        (svref locbc evil))
      (adv-delta      (color->adv-delta good))
      (checker-bb     (bb-and2 evil-bb (svref atkts good-king-sq)))
      (singlecheck    (not (pos-dbch my-pos)))
      (checker-sq     (when singlecheck (bb-first checker-bb)))
      (checker-man    (if singlecheck (get-man my-pos checker-sq) man-v0))
      (interpose-test (and singlecheck (is-man-sweeper? checker-man)))
      (interpose-bb   (when interpose-test (sq+sq->path-bb good-king-sq checker-sq)))
      (interpose-flag (and interpose-test (bb-not-empty? interpose-bb)))
    )
    ;;
    ;; Try: Capture of a single checker (not including a capture by the king)
    ;;
    (when singlecheck
      (let ((frbb (bb-and2 good-bb (svref atkts checker-sq))))
        (bb-reset-sq frbb good-king-sq)
        (bb-and2c2d frbb pmbb)
        (bb-scan (frbb frsq)
          (let ((frman (get-man my-pos frsq)))
            (if (and (= frman good-pawn) (= (sq->rank frsq) good-r7))
              (incf result prom-limit)
              (incf result))))))
    ;;
    ;; Try: King moves (including captures by the king)
    ;;
    (let
      (
        (sweep-checker-bb (bb-and2 checker-bb sweep))
        (tobb (bb-and2c2 (sq->king-atk-bb good-king-sq) good-bb))
      )
      (bb-and2c2d tobb (svref atkbc evil))
      (bb-scan (sweep-checker-bb sweep-checker-sq)
        (let ((shadow-sq (sq+sq->shadow sweep-checker-sq good-king-sq)))
          (when shadow-sq
            (bb-reset-sq tobb shadow-sq))))
      (incf result (bb-card tobb)))
    ;;
    ;; Try: Interposition for a single sweep checker (not including pawn interpositinons)
    ;;
    (when interpose-flag
      (let ((frbb (bb-and2c2 good-bb pmbb)))
        (bb-reset-sq frbb good-king-sq)
        (bb-and2c2d frbb good-pawn-bb)
        (bb-scan (frbb frsq)
          (let ((tobb (bb-and2 interpose-bb (svref atkfs frsq))))
            (incf result (bb-card tobb))))))
    ;;
    ;; Try: Interposition for a single sweep checker (only by pawn single square advance interpositions)
    ;;
    (when interpose-flag
      (let ((frbb (bb-and2c2 good-pawn-bb pmbb)))
        (bb-scan (frbb frsq)
          (let ((tosq (+ frsq adv-delta)))
            (when (bb-sq-set? interpose-bb tosq)
              (if (= (sq->rank frsq) good-r7)
                (incf result prom-limit)
                (incf result)))))))
    ;;
    ;; Try: Interposition for a single sweep checker (only by pawn double square advance interpositions)
    ;;
    (when interpose-flag
      (let ((frbb (bb-and2c2 good-pawn-bb pmbb)))
        (bb-and2d frbb (rank->bb good-r2))
        (bb-scan (frbb frsq)
          (let ((tosq (+ frsq adv-delta)))
            (when (is-man-vacant? (get-man my-pos tosq))
              (incf tosq adv-delta)
              (when (bb-sq-set? interpose-bb tosq)
                (incf result)))))))
    ;;
    ;; Try: En passant captures
    ;;
    (when epsq
      (let ((frbb (bb-and2 good-pawn-bb (svref atkts epsq))))
        (bb-scan (frbb frsq)
          (let ((ep-move (make-move :frsq frsq :tosq epsq :frman good-pawn :msc msc-epc)))
            (when (is-en-passant-move-playable? my-pos ep-move)
              (incf result))))))
    ;;
    result))

(defun count-moves-nocheck (my-pos)
  "Return a count of moves generated for the given position (called with good king not in check)."
  (let*
    (
      (result       0)
      (good         (pos-good my-pos))
      (evil         (pos-evil my-pos))
      (epsq         (pos-epsq my-pos))
      (bbdb         (pos-bbdb my-pos))
      (ksqv         (pos-ksqv my-pos))
      (pmbb         (pos-pmbb my-pos))
      (fmbb         (pos-fmbb my-pos))
      (merge        (bbdb-merge bbdb))
      (locbc        (bbdb-locbc bbdb))
      (atkbc        (bbdb-atkbc bbdb))
      (atkfs        (bbdb-atkfs bbdb))
      (good-king-sq (svref ksqv good))
      (good-bb      (svref locbc good))
      (adv-delta    (color->adv-delta good))
      (target-bb    (bb-not1 good-bb))
      (rmbb         (bb-and2c2 pmbb fmbb))
      (frbb         (bb-and2c2 good-bb fmbb))
    )
    (bb-scan (frbb frsq)
      (let*
        (
          (frman   (get-man my-pos frsq))
          (frpiece (man->piece frman))
          (afsbb   (svref atkfs frsq))
        )
        (cond
          ;;
          ;; Moves for a pawn
          ;;
          ((= frpiece piece-pawn)
            (let*
              (
                (frrank (sq->rank frsq))
                (rdir   (when (bb-sq-set? rmbb frsq) (sq+sq->dir good-king-sq frsq)))
                (r2flag (= frrank (svref rank2-vec good)))
                (r7flag (= frrank (svref rank7-vec good)))
                (pcsqs  (pos-calc-pawn-capture-sqs my-pos frsq rdir))
              )
              ;;
              ;; Advance
              ;;
              (when (or (not rdir) (= bidir-n (dir->bidir rdir)))
                (let ((tosq (+ frsq adv-delta)))
                  (when (bb-sq-reset? merge tosq)
                    (if r7flag
                      (incf result prom-limit)
                      (progn
                        (incf result)
                        (when (and r2flag (bb-sq-reset? merge (+ tosq adv-delta)))
                          (incf result)))))))
              ;;
              ;; Capture (not en passant)
              ;;
              (let ((tocount (length pcsqs)))
                (if r7flag
                  (incf result (* prom-limit tocount))
                  (incf result tocount)))
              ;;
              ;; En passant
              ;;
              (when (and epsq (find epsq (color+sq->pawn-atk-sqs good frsq)))
                (let ((ep-move (make-move :frsq frsq :tosq epsq :frman frman :msc msc-epc)))
                  (when (is-en-passant-move-playable? my-pos ep-move)
                    (incf result))))))
          ;;
          ;; Moves for a knight
          ;;
          ((= frpiece piece-knight)
            (let ((tobb (bb-and2 afsbb target-bb)))
              (incf result (bb-card tobb))))
          ;;
          ;; Moves for a sweeper
          ;;
          ((or (= frpiece piece-bishop) (= frpiece piece-rook) (= frpiece piece-queen))
            (let ((tobb (bb-and2 afsbb target-bb)))
              (when (bb-sq-set? rmbb frsq)
                (bb-and2d tobb (sq+sq->beam-bb good-king-sq frsq)))
              (incf result (bb-card tobb))))
          ;;
          ;; Moves for a king
          ;;
          ((= frpiece piece-king)
            (let ((tobb (bb-and2c2 (bb-and2 afsbb target-bb) (svref atkbc evil))))
              (incf result (bb-card tobb)))
            (when (nonzero? (pos-cast my-pos))
              (dolist (castling (color->castlings good))
                (when (pos-can-castle? my-pos castling)
                  (incf result)))))
          ;;
          (t
            (error "count-moves-nocheck: bad frpiece: ~A" frpiece)))))
    result))

(defun count-moves (my-pos)
  "Return a count of moves generated for the given position."
  (if (pos-inch my-pos)
    (count-moves-evasion my-pos)
    (count-moves-nocheck my-pos)))

;;; ---------- No moves condition detection

(defun pos-has-no-moves-evasion? (my-pos)
  "Determine if the given position is a checkmate (called with good king in check)."
  (let*
    (
      (result         t)
      (good           (pos-good my-pos))
      (evil           (pos-evil my-pos))
      (epsq           (pos-epsq my-pos))
      (bbdb           (pos-bbdb my-pos))
      (ksqv           (pos-ksqv my-pos))
      (pmbb           (pos-pmbb my-pos))
      (sweep          (bbdb-sweep bbdb))
      (locbc          (bbdb-locbc bbdb))
      (locbm          (bbdb-locbm bbdb))
      (atkbc          (bbdb-atkbc bbdb))
      (atkts          (bbdb-atkts bbdb))
      (atkfs          (bbdb-atkfs bbdb))
      (good-king-sq   (svref ksqv good))
      (good-bb        (svref locbc good))
      (good-pawn      (color->pawn good))
      (good-pawn-bb   (svref locbm good-pawn))
      (good-r2        (svref rank2-vec good))
      (evil-bb        (svref locbc evil))
      (adv-delta      (color->adv-delta good))
      (checker-bb     (bb-and2 evil-bb (svref atkts good-king-sq)))
      (singlecheck    (not (pos-dbch my-pos)))
      (checker-sq     (when singlecheck (bb-first checker-bb)))
      (checker-man    (if singlecheck (get-man my-pos checker-sq) man-v0))
      (interpose-test (and singlecheck (is-man-sweeper? checker-man)))
      (interpose-bb   (when interpose-test (sq+sq->path-bb good-king-sq checker-sq)))
      (interpose-flag (and interpose-test (bb-not-empty? interpose-bb)))
    )
    ;;
    ;; Try: Capture of a single checker (not including a capture by the king)
    ;;
    (when (and result singlecheck)
      (let ((frbb (bb-and2 good-bb (svref atkts checker-sq))))
        (bb-reset-sq frbb good-king-sq)
        (bb-and2c2d frbb pmbb)
        (when (bb-not-empty? frbb)
          (setf result nil))))
    ;;
    ;; Try: King moves (including captures by the king)
    ;;
    (when result
      (let
        (
          (sweep-checker-bb (bb-and2 checker-bb sweep))
          (tobb (bb-and2c2 (sq->king-atk-bb good-king-sq) good-bb))
        )
        (bb-and2c2d tobb (svref atkbc evil))
        (bb-scan (sweep-checker-bb sweep-checker-sq)
          (let ((shadow-sq (sq+sq->shadow sweep-checker-sq good-king-sq)))
            (when shadow-sq
              (bb-reset-sq tobb shadow-sq))))
        (when (bb-not-empty? tobb)
          (setf result nil))))
    ;;
    ;; Try: Interposition for a single sweep checker (not including pawn interpositinons)
    ;;
    (when (and result interpose-flag)
      (let ((frbb (bb-and2c2 good-bb pmbb)))
        (bb-reset-sq frbb good-king-sq)
        (bb-and2c2d frbb good-pawn-bb)
        (bb-scan-while (frbb frsq result)
          (let ((tobb (bb-and2 interpose-bb (svref atkfs frsq))))
            (when (bb-not-empty? tobb)
              (setf result nil))))))
    ;;
    ;; Try: Interposition for a single sweep checker (only by pawn single square advance interpositions)
    ;;
    (when (and result interpose-flag)
      (let ((frbb (bb-and2c2 good-pawn-bb pmbb)))
        (bb-scan-while (frbb frsq result)
          (let ((tosq (+ frsq adv-delta)))
            (when (bb-sq-set? interpose-bb tosq)
              (setf result nil))))))
    ;;
    ;; Try: Interposition for a single sweep checker (only by pawn double square advance interpositions)
    ;;
    (when (and result interpose-flag)
      (let ((frbb (bb-and2c2 good-pawn-bb pmbb)))
        (bb-and2d frbb (rank->bb good-r2))
        (bb-scan-while (frbb frsq result)
          (let ((tosq (+ frsq adv-delta)))
            (when (is-man-vacant? (get-man my-pos tosq))
              (incf tosq adv-delta)
              (when (bb-sq-set? interpose-bb tosq)
                (setf result nil)))))))
    ;;
    ;; Try: En passant captures
    ;;
    (when (and result epsq)
      (let ((frbb (bb-and2 good-pawn-bb (svref atkts epsq))))
        (bb-scan-while (frbb frsq result)
          (let ((ep-move (make-move :frsq frsq :tosq epsq :frman good-pawn :msc msc-epc)))
            (when (is-en-passant-move-playable? my-pos ep-move)
              (setf result nil))))))
    ;;
    result))

(defun pos-has-no-moves-nocheck? (my-pos)
  "Determine if the given position is a stalemate (called with good king not in check)."
  (let*
    (
      (result       t)
      (good         (pos-good my-pos))
      (evil         (pos-evil my-pos))
      (epsq         (pos-epsq my-pos))
      (bbdb         (pos-bbdb my-pos))
      (ksqv         (pos-ksqv my-pos))
      (pmbb         (pos-pmbb my-pos))
      (fmbb         (pos-fmbb my-pos))
      (merge        (bbdb-merge bbdb))
      (locbc        (bbdb-locbc bbdb))
      (atkbc        (bbdb-atkbc bbdb))
      (atkfs        (bbdb-atkfs bbdb))
      (good-king-sq (svref ksqv good))
      (good-bb      (svref locbc good))
      (adv-delta    (color->adv-delta good))
      (target-bb    (bb-not1 good-bb))
      (rmbb         (bb-and2c2 pmbb fmbb))
      (frbb         (bb-and2c2 good-bb fmbb))
    )
    (bb-scan-while (frbb frsq result)
      (let*
        (
          (frman   (get-man my-pos frsq))
          (frpiece (man->piece frman))
          (afsbb   (svref atkfs frsq))
        )
        (cond
          ;;
          ;; Moves for a pawn
          ;;
          ((= frpiece piece-pawn)
            (let*
              (
                (rdir  (when (bb-sq-set? rmbb frsq) (sq+sq->dir good-king-sq frsq)))
                (pcsqs (pos-calc-pawn-capture-sqs my-pos frsq rdir))
              )
              ;;
              ;; Advance
              ;;
              (when (or (not rdir) (= bidir-n (dir->bidir rdir)))
                (let ((tosq (+ frsq adv-delta)))
                  (when (bb-sq-reset? merge tosq)
                    (setf result nil))))
              ;;
              ;; Capture (not en passant)
              ;;
              (when (and result pcsqs)
                (setf result nil))
              ;;
              ;; En passant
              ;;
              (when (and result epsq (find epsq (color+sq->pawn-atk-sqs good frsq)))
                (let ((ep-move (make-move :frsq frsq :tosq epsq :frman frman :msc msc-epc)))
                  (when (is-en-passant-move-playable? my-pos ep-move)
                    (setf result nil))))))
          ;;
          ;; Moves for a knight
          ;;
          ((= frpiece piece-knight)
            (let ((tobb (bb-and2 afsbb target-bb)))
              (when (bb-not-empty? tobb)
                (setf result nil))))
          ;;
          ;; Moves for a sweeper
          ;;
          ((or (= frpiece piece-bishop) (= frpiece piece-rook) (= frpiece piece-queen))
            (let ((tobb (bb-and2 afsbb target-bb)))
              (when (bb-sq-set? rmbb frsq)
                (bb-and2d tobb (sq+sq->beam-bb good-king-sq frsq)))
              (when (bb-not-empty? tobb)
                (setf result nil))))
          ;;
          ;; Moves for a king
          ;;
          ((= frpiece piece-king)
            (let ((tobb (bb-and2c2 (bb-and2 afsbb target-bb) (svref atkbc evil))))
              (when (bb-not-empty? tobb)
                (setf result nil)))
            (when (and result (nonzero? (pos-cast my-pos)))
              (let ((castlings (color->castlings good)))
                (dowhile (and result castlings)
                  (when (pos-can-castle? my-pos (pop castlings))
                    (setf result nil))))))
          ;;
          (t
            (error "pos-has-no-moves-nocheck?: bad frpiece: ~A" frpiece)))))
    result))

(defun pos-has-no-moves? (my-pos)
  "Determine if the given position is a mate, either a checkmate or a stalemate."
  (if (pos-inch my-pos)
    (pos-has-no-moves-evasion? my-pos)
    (pos-has-no-moves-nocheck? my-pos)))

;;; ---------- Position repetition counting

(defun pos-count-past-occurances (my-pos my-occurance-limit)
  "Return the number of times the current position has occurred subject to the occurance limit."
  (let
    (
      (result    0)
      (hash      (pos-mdhs my-pos))
      (pop-count 0)
      (pop-limit (min (pos-hmvc my-pos) (pos-prior-move-count my-pos)))
      (mdhx      (pos-mdhx my-pos))
    )
    (dowhile (and (< result my-occurance-limit) (< pop-count pop-limit))
      (let ((old-mdhs (pop mdhx)))
        (incf pop-count)
        (when (and (even? pop-count) (hash-eq? hash old-mdhs))
          (incf result))))
      result))

;;; At least one repetiton detection

(defun pos-is-repeated? (my-pos)
  "Determine if the current position has had at least one prior occurance."
  (and (>= (pos-hmvc my-pos) 4) (= (pos-count-past-occurances my-pos 1) 1)))

;;; ---------- Game termination detection

(defun pos-is-checkmate? (my-pos)
  "Determine if a position is a checkmate."
  (and (pos-inch my-pos) (pos-has-no-moves? my-pos)))

(defun pos-is-stalemate? (my-pos)
  "Determine if a position is a stalemate."
  (and (not (pos-inch my-pos)) (pos-has-no-moves? my-pos)))

(defun pos-is-draw-fiftymoves? (my-pos)
  "Determine if a position is a draw based on the fifty move rule."
  (>= (pos-hmvc my-pos) 100))

(defun pos-is-draw-insufficient? (my-pos)
  "Determine if a position is a draw due to insufficient material."
  (not (census-sufficient-material (pos-cens my-pos))))

(defun pos-is-draw-repetition? (my-pos)
  "Determine if a position is a draw due to position repetition."
  (and (>= (pos-hmvc my-pos) 8) (= (pos-count-past-occurances my-pos 2) 2)))

(defun pos-is-draw-fir? (my-pos)
  "Determine if a position is a draw due to the three easy cases (fiftymoves/insufficient/repetition)."
  (or
    (pos-is-draw-fiftymoves?   my-pos)
    (pos-is-draw-insufficient? my-pos)
    (pos-is-draw-repetition?   my-pos)))

(defun pos-is-draw-stalemate? (my-pos)
  "Determine if a position is a draw due to stalemate."
  (pos-is-stalemate? my-pos))

(defun pos-is-draw? (my-pos)
  "Determine if a position is a draw."
  (or (pos-is-draw-fir? my-pos) (pos-is-draw-stalemate? my-pos)))

(defun pos->pdgt (my-pos)
  "Calculate the position dependent game termination code for the given position."
  (if (pos-has-no-moves? my-pos)
    (if (pos-inch my-pos) pdgt-checkmate pdgt-stalemate)
    (if (pos-is-draw-fiftymoves? my-pos) pdgt-fiftymoves
      (if (pos-is-draw-insufficient? my-pos) pdgt-insufficient
        (if (pos-is-draw-repetition? my-pos) pdgt-repetition pdgt-unterminated)))))

(defun pos->gsr (my-pos)
  "Return the game status result from a position."
  (color+pdgt->gsr (pos-good my-pos) (pos->pdgt my-pos)))

(defun pos-is-game-over? (my-pos)
  "Determine if the position is an automatic game over."
  (or (pos-is-draw-fir? my-pos) (pos-has-no-moves? my-pos)))

(defun pos-is-game-going? (my-pos)
  "Determine if the position is not an automatic game over."
  (not (pos-is-game-over? my-pos)))

;;; ---------- Structure runwayset

(defstruct
  (runwayset)
  "A set of bitboards giving runway bitboard for attacks to a given square."
  (prwbb (make-bb))  ; Pawn landing squares
  (nrwbb (make-bb))  ; Knight landing squares
  (brwbb (make-bb))  ; Bishop landing squares
  (rrwbb (make-bb))  ; Rook landing squares
  (qrwbb (make-bb))  ; Queen landing squares
  (disbb (make-bb))) ; Discovery squares

(defun new-runwayset (my-pos)
  "Return a new runmay set for the good player color and the evil king square."
  (let*
    (
      (good         (pos-good my-pos))
      (evil         (pos-evil my-pos))
      (bbdb         (pos-bbdb my-pos))
      (ksqv         (pos-ksqv my-pos))
      (merge        (bbdb-merge bbdb))
      (sweep        (bbdb-sweep bbdb))
      (locbc        (bbdb-locbc bbdb))
      (atkts        (bbdb-atkts bbdb))
      (good-bb      (svref locbc good))
      (good-sweep   (bb-and2 good-bb sweep))
      (evil-bb      (svref locbc evil))
      (evil-king-sq (svref ksqv evil))
      (prwbb        (bb-and2c2 (color+sq->pawn-atk-bb evil evil-king-sq) good-bb))
      (nrwbb        (bb-and2c2 (sq->knight-atk-bb evil-king-sq) good-bb))
      (brwbb        (make-bb))
      (rrwbb        (make-bb))
      (qrwbb        (make-bb))
      (disbb        (make-bb))
    )
    ;;
    ;;  Calculate runways: orthogonals
    ;;
    (doorthodirs (dir)
      (let ((sqs (sq+dir->sweep-atk-sqs evil-king-sq dir)))
        (do ((sq (pop sqs))) ((not sq))
          (if (bb-sq-reset? merge sq)
            (progn
              (bb-set-sq rrwbb sq)
              (setf sq (pop sqs)))
            (progn
              (if (bb-sq-set? evil-bb sq)
                (bb-set-sq rrwbb sq)
                (bb-set-sq disbb sq))
              (setf sq nil))))))
    (bb-ior2d qrwbb rrwbb)
    ;;
    ;;  Calculate runways: diagonals
    ;;
    (dodiagodirs (dir)
      (let ((sqs (sq+dir->sweep-atk-sqs evil-king-sq dir)))
        (do ((sq (pop sqs))) ((not sq))
          (if (bb-sq-reset? merge sq)
            (progn
              (bb-set-sq brwbb sq)
              (setf sq (pop sqs)))
            (progn
              (if (bb-sq-set? evil-bb sq)
                (bb-set-sq brwbb sq)
                (bb-set-sq disbb sq))
              (setf sq nil))))))
    (bb-ior2d qrwbb brwbb)
    ;;
    ;; Finalize discovery bitboard
    ;;
    (let ((cand-bb (bb-clone disbb)))
      (bb-scan (cand-bb cand-sq)
        (when
          (bb-ni3?
            good-sweep
            (svref atkts cand-sq)
            (sq+sq->beyond-bb evil-king-sq cand-sq))
          (bb-reset-sq disbb cand-sq))))
    ;;
    ;; Return the new runway set
    ;;
    (make-runwayset :prwbb prwbb :nrwbb nrwbb :brwbb brwbb :rrwbb rrwbb :qrwbb qrwbb :disbb disbb)))

;;; ---------- Checkmate/stalemate move tests

(defun is-move-checkmating? (my-move my-pos)
  "Determine if a move gives checkmate."
  (let ((result nil) (fmvs (pos-fmvs my-pos)))
    (pos-execute my-pos my-move)
    (when (pos-is-checkmate? my-pos)
      (setf result t))
    (pos-retract my-pos)
    (setf (pos-fmvs my-pos) fmvs)
    result))

(defun is-move-stalemating? (my-move my-pos)
  "Determine if a move gives stalemate."
  (let ((result nil) (fmvs (pos-fmvs my-pos)))
    (pos-execute my-pos my-move)
    (when (pos-is-stalemate? my-pos)
      (setf result t))
    (pos-retract my-pos)
    (setf (pos-fmvs my-pos) fmvs)
    result))

;;; ---------- Move terminal assignments

(defun move-set-terminal (my-move my-score)
  "Set the mf-term and mf-cert move flags and a score for a move."
  (move-set-flag my-move mf-term)
  (move-set-flag my-move mf-cert)
  (setf (move-score my-move) my-score)
  (values))

(defun move-set-terminal-checkmating (my-move)
  "Set the appropriate move flags and a checkmating score for a move."
  (move-set-flag my-move mf-chmt)
  (move-set-terminal my-move mate-in-1-score)
  (values))

(defun move-set-terminal-drawing (my-move my-drawing-mf)
  "Set the appropriate move flags and a draw score for a move."
  (move-set-flag my-move my-drawing-mf)
  (move-set-flag my-move mf-draw)
  (move-set-terminal my-move draw-score)
  (values))

;;; ---------- Move list equality

(defun same-ordered-movelists? (my-moves0 my-moves1)
  "Determine if the two movelists are the same; order is significant."
  (let ((result t) (moves0 my-moves0) (moves1 my-moves1))
    (dowhile (and result moves0 moves1)
      (unless (same-moves? (pop moves0) (pop moves1))
        (setf result nil)))
    (when (and result (or moves0 moves1))
      (setf result nil))
    result))

(defun same-movelists? (my-moves0 my-moves1)
  "Determine if the two movelists are the same regardless of ordering."
  (same-ordered-movelists? (movelist-sort-by-nemo my-moves0) (movelist-sort-by-nemo my-moves1)))

;;; ---------- Move list search

(defun locate-move (my-moves my-move)
  "Return the matching move in a move list."
  (let ((result nil) (moves my-moves))
    (dowhile (and (not result) moves)
      (let ((move (pop moves)))
        (when (same-moves? move my-move)
          (setf result move))))
    result))

(defun locate-move-no-fail (my-moves my-move)
  "Return the matching move in a move list; fatal error if not found."
  (let ((result (locate-move my-moves my-move)))
    (unless result
      (error "locate-move-no-fail: ~A ~A" my-moves my-move))
    result))

;;; ---------- Move list flag marking

(defun movelist-setflags-gainers-holders (my-moves)
  "Handle gainer/holder flag assignments for a list of moves."
  (dolist (move my-moves)
    (move-set-flag move (if (is-move-gainer? move) mf-gain mf-hold)))
  my-moves)

(defun movelist-slow-setflags-checks (my-moves my-pos)
  "Slowly and simply handle check flag assignments for a list of moves each from the given position."
  (let ((fmvs (pos-fmvs my-pos)))
    (dolist (move my-moves)
      (pos-execute my-pos move)
      (when (pos-inch my-pos)
        (move-set-flag move mf-chck))
      (pos-retract my-pos))
    (setf (pos-fmvs my-pos) fmvs))
  my-moves)

(defun movelist-setflags-checks (my-moves my-pos)
  "Handle check flag assignments for a list of moves each from the given position."
  (let*
    (
      (runwayset    (new-runwayset my-pos))
      (prwbb        (runwayset-prwbb runwayset))
      (nrwbb        (runwayset-nrwbb runwayset))
      (brwbb        (runwayset-brwbb runwayset))
      (rrwbb        (runwayset-rrwbb runwayset))
      (qrwbb        (runwayset-qrwbb runwayset))
      (disbb        (runwayset-disbb runwayset))
      (good         (pos-good my-pos))
      (evil         (pos-evil my-pos))
      (ksqv         (pos-ksqv my-pos))
      (good-king-sq (svref ksqv good))
      (evil-king-sq (svref ksqv evil))
      (memo-frsq    nil)
      (memo-frman   nil)
      (memo-frpiece nil)
      (memo-inline  nil)
      (memo-beam-bb nil)
    )
    ;;
    ;; Scan the moves and handle according to move special case
    ;;
    (dolist (move my-moves)
      (let ((frsq (move-frsq move)) (tosq (move-tosq move)))
        (when (or (not memo-frsq) (/= memo-frsq frsq))
          (setf memo-frsq    frsq)
          (setf memo-frman   (move-frman move))
          (setf memo-frpiece (man->piece memo-frman))
          (setf memo-inline  (bb-sq-set? disbb memo-frsq))
          (setf memo-beam-bb (when memo-inline (sq+sq->beam-bb evil-king-sq memo-frsq))))
        (cond
          ;;
          ;; Regular move check detection
          ;;
          ((is-move-regular? move)
            (cond
              ((= memo-frpiece piece-pawn)
                (when
                  (or
                    (bb-sq-set? prwbb tosq)
                    (and memo-inline (bb-sq-reset? memo-beam-bb tosq)))
                  (move-set-flag move mf-chck)))
              ((= memo-frpiece piece-knight)
                (when (or memo-inline (bb-sq-set? nrwbb tosq))
                  (move-set-flag move mf-chck)))
              ((= memo-frpiece piece-bishop)
                (when (or memo-inline (bb-sq-set? brwbb tosq))
                  (move-set-flag move mf-chck)))
              ((= memo-frpiece piece-rook)
                (when (or memo-inline (bb-sq-set? rrwbb tosq))
                  (move-set-flag move mf-chck)))
              ((= memo-frpiece piece-queen)
                (when (bb-sq-set? qrwbb tosq)
                  (move-set-flag move mf-chck)))
              ((= memo-frpiece piece-king)
                (when (and memo-inline (bb-sq-reset? memo-beam-bb tosq))
                  (move-set-flag move mf-chck)))
              (t
                (error "movelist-setflags-checks: cond fault/1"))))
        ;;
        ;; En passant capture check detection
        ;;
        ((is-move-en-passant? move)
          (when (is-en-passant-move-playable-and-checks? my-pos move)
            (move-set-flag move mf-chck)))
        ;;
        ;; Castling move check detection
        ;;
        ((is-move-castling? move)
          (let ((rook-away-sq (castling->rook-away (color+msc->castling good (move-msc move)))))
            (when
              (or
                (and (same-file? evil-king-sq rook-away-sq) (pos-clear-path? my-pos evil-king-sq rook-away-sq))
                (and (same-rank? evil-king-sq good-king-sq) (pos-clear-path? my-pos evil-king-sq good-king-sq)))
              (move-set-flag move mf-chck))))
        ;;
        ;; Pawn promotion check detection
        ;;
        ((is-move-promotion? move)
          (cond
            ((is-move-prom-knight? move)
              (when (or memo-inline (bb-sq-set? nrwbb tosq))
                (move-set-flag move mf-chck)))
            ((is-move-prom-bishop? move)
              (if (or memo-inline (bb-sq-set? brwbb tosq))
                (move-set-flag move mf-chck)
                (when
                  (and
                    (is-man-nonvac? (move-toman move))
                    (pos-clear-inline-sweep-path? my-pos evil-king-sq frsq tosq))
                  (move-set-flag move mf-chck))))
            ((is-move-prom-rook? move)
              (if (or memo-inline (bb-sq-set? rrwbb tosq))
                (move-set-flag move mf-chck)
                (when
                  (and
                    (is-man-vacant? (move-toman move))
                    (pos-clear-inline-sweep-path? my-pos evil-king-sq frsq tosq))
                  (move-set-flag move mf-chck))))
            ((is-move-prom-queen? move)
              (when
                (or
                  memo-inline
                  (bb-sq-set? qrwbb tosq)
                  (pos-clear-inline-sweep-path? my-pos evil-king-sq frsq tosq))
                (move-set-flag move mf-chck)))
            (t
              (error "movelist-setflags-checks: cond fault/2"))))
        (t
          (error "movelist-setflags-checks: cond fault"))))))
  my-moves)

(defun movelist-setflags-checkmates (my-moves my-pos)
  "Handle checkmate flag assignments for a list of moves (with check marking) each from the given position."
  (dolist (move my-moves)
    (when (and (is-move-flag-set? move mf-chck) (is-move-checkmating? move my-pos))
      (move-set-terminal-checkmating move)))
  my-moves)

(defun movelist-setflags-checks-checkmates (my-moves my-pos)
  "Handle check/checkmate flag assignments for a list of moves each from the given position."
  (movelist-setflags-checks my-moves my-pos)
  (movelist-setflags-checkmates my-moves my-pos)
  my-moves)

(defun movelist-setflags-draws (my-moves my-pos)
  "Handle draw flags assignments for a list of moves each from the given position."
  (let ((fmvs (pos-fmvs my-pos)))
    (dolist (move my-moves)
      (pos-execute my-pos move)
      (let ((pdgt (pos->pdgt my-pos)))
        (cond
          ((= pdgt pdgt-stalemate)
            (move-set-terminal-drawing move mf-dbsm))
          ((= pdgt pdgt-fiftymoves)
            (move-set-terminal-drawing move mf-dbfm))
          ((= pdgt pdgt-insufficient)
            (move-set-terminal-drawing move mf-dbim))
          ((= pdgt pdgt-repetition)
            (move-set-terminal-drawing move mf-dbrp))
          (t
            nil)))
      (pos-retract my-pos))
    (setf (pos-fmvs my-pos) fmvs))
  my-moves)

(defun movelist-setflags-checks-checkmates-draws (my-moves my-pos)
  "Handle check/draw/checkmate flag assignments for a list of moves each from the given position."
  (movelist-setflags-checks-checkmates my-moves my-pos)
  (movelist-setflags-draws my-moves my-pos)
  my-moves)

(defun movelist-setflags-disambiguation (my-moves my-pos)
  "Handle file/rank disambiguation flag assignments for a list of moves each from the given position."
  (let
    (
      (mcvec   (census-mcvec (pos-cens my-pos)))
      (tsc-vec (make-array sq-limit :initial-element 0))
    )
    ;;
    ;; Initialize the to-square count vector
    ;;
    (dolist (move my-moves)
      (incf (svref tsc-vec (move-tosq move))))
    ;;
    ;; Outer pass of the move list
    ;;
    (dolist (move my-moves)
      (let ((tosq (move-tosq move)))
        (when (> (svref tsc-vec tosq) 1)
          (let ((frman (move-frman move)))
            (unless (or (is-man-pawn? frman) (one? (svref mcvec frman)))
              (let*
                (
                  (frsq   (move-frsq move))
                  (frfile (sq->file frsq))
                  (frrank (sq->rank frsq))
                  (filemc 0)
                  (rankmc 0)
                  (basemc 0)
                )
                ;;
                ;; Inner pass of the move list
                ;;
                (dolist (move1 my-moves)
                  (when (and (= tosq (move-tosq move1)) (= frman (move-frman move1)))
                    (incf basemc)
                    (let ((frsq1 (move-frsq move1)))
                      (when (= frfile (sq->file frsq1))
                        (incf filemc))
                      (when (= frrank (sq->rank frsq1))
                        (incf rankmc)))))
                ;;
                ;; Assign any needed flags based on the inner pass results
                ;;
                (when (> basemc 1)
                  (when (or (> rankmc 1) (and (one? rankmc) (one? filemc)))
                    (move-set-flag move mf-andf))
                  (when (> filemc 1)
                    (move-set-flag move mf-andr))))))))))
  my-moves)

(defun movelist-setflags-notation (my-moves my-pos)
  "Handle all notation flag assignments for a list of moves from the given position."
  (movelist-setflags-checks-checkmates my-moves my-pos)
  (movelist-setflags-disambiguation my-moves my-pos)
  (movelist-set-all-single-flag my-moves mf-note)
  my-moves)

(defun movelist-setflags-super (my-moves my-pos)
  "Handle all notation/draw/gainer/holder flag assignments for a list of moves from the given position."
  (movelist-setflags-notation my-moves my-pos)
  (movelist-setflags-draws my-moves my-pos)
  (movelist-setflags-gainers-holders my-moves)
  my-moves)

;;; ---------- Move list filtering

(defun movelist-pass-checkers (my-moves)
  "Return a new list of moves built from the marked checking moves in the given move list."
  (remove-if-not (function is-move-marked-check?) my-moves))

(defun movelist-pass-checkmaters (my-moves)
  "Return a new list of moves built from the marked checkmating moves in the given move list."
  (remove-if-not (function is-move-marked-checkmate?) my-moves))

(defun movelist-pass-gainers (my-moves)
  "Return a new list of moves built from the marked gainer moves in the given move list."
  (remove-if-not (function is-move-marked-gainer?) my-moves))

(defun movelist-pass-holders (my-moves)
  "Return a new list of moves built from the marked holder moves in the given move list."
  (remove-if-not (function is-move-marked-holder?) my-moves))

;;; ---------- Check/checkmate move generation routines

(defun generate-nocheck-checkers (my-pos)
  "Return a list of checking moves generated for the given position (called with good king not in check)."
  (let*
    (
      (result       nil)
      (runwayset    (new-runwayset my-pos))
      (prwbb        (runwayset-prwbb runwayset))
      (nrwbb        (runwayset-nrwbb runwayset))
      (brwbb        (runwayset-brwbb runwayset))
      (rrwbb        (runwayset-rrwbb runwayset))
      (qrwbb        (runwayset-qrwbb runwayset))
      (disbb        (runwayset-disbb runwayset))
      (good         (pos-good my-pos))
      (evil         (pos-evil my-pos))
      (epsq         (pos-epsq my-pos))
      (bbdb         (pos-bbdb my-pos))
      (ksqv         (pos-ksqv my-pos))
      (pmbb         (pos-pmbb my-pos))
      (fmbb         (pos-fmbb my-pos))
      (merge        (bbdb-merge bbdb))
      (locbc        (bbdb-locbc bbdb))
      (atkbc        (bbdb-atkbc bbdb))
      (atkfs        (bbdb-atkfs bbdb))
      (good-bb      (svref locbc good))
      (good-king-sq (svref ksqv good))
      (evil-king-sq (svref ksqv evil))
      (adv-delta    (color->adv-delta good))
      (target-bb    (bb-not1 good-bb))
      (rmbb         (bb-and2c2 pmbb fmbb))
      (frbb         (bb-and2c2 good-bb fmbb))
    )
    ;
    (bb-scan (frbb frsq)
      (let*
        (
          (frman   (get-man my-pos frsq))
          (frpiece (man->piece frman))
          (afsbb   (svref atkfs frsq))
          (disflag (bb-sq-set? disbb frsq))
        )
        (cond
          ;;
          ;; Moves for a pawn
          ;;
          ((= frpiece piece-pawn)
            (let*
              (
                (frrank    (sq->rank frsq))
                (rdir      (when (bb-sq-set? rmbb frsq) (sq+sq->dir good-king-sq frsq)))
                (r2flag    (= frrank (svref rank2-vec good)))
                (r7flag    (= frrank (svref rank7-vec good)))
                (pcsqs     (pos-calc-pawn-capture-sqs my-pos frsq rdir))
                (ekfbidir  (when disflag (sq+sq->bidir evil-king-sq frsq)))
                (advchflag (when ekfbidir (/= ekfbidir bidir-n)))
              )
              ;;
              ;; Advance
              ;;
              (when (or (not rdir) (= bidir-n (dir->bidir rdir)))
                (let ((tosq (+ frsq adv-delta)))
                  (when (bb-sq-reset? merge tosq)
                    (cond
                      ;;
                      ;; Advance from second rank
                      ;;
                      (r2flag
                        (when (or advchflag (bb-sq-set? prwbb tosq))
                          (push (make-move :frsq frsq :tosq tosq :frman frman) result))
                        (incf tosq adv-delta)
                        (when (bb-sq-reset? merge tosq)
                          (when (or advchflag (bb-sq-set? prwbb tosq))
                            (push (make-move :frsq frsq :tosq tosq :frman frman) result))))
                      ;;
                      ;; Advance from seventh rank
                      ;;
                      (r7flag
                        (if advchflag
                          ;;
                          ;; Check by discovery
                          ;;
                          (dolist (msc msc-promotion-list)
                            (push (make-move :frsq frsq :tosq tosq :frman frman :msc msc) result))
                          ;;
                          ;; Check by the new piece made from the promotion
                          ;;
                          (let ((ektdir (sq+sq->dir evil-king-sq tosq)))
                            (when ektdir
                              (cond
                                ((is-dir-crook? ektdir)
                                  (push (make-move :frsq frsq :tosq tosq :frman frman :msc msc-ppn) result))
                                ((is-dir-diago? ektdir)
                                  (when (pos-clear-path? my-pos evil-king-sq tosq)
                                    (dolist (msc msc-diago-promotion-list)
                                      (push (make-move :frsq frsq :tosq tosq :frman frman :msc msc) result))))
                                ((is-dir-ortho? ektdir)
                                  (when
                                    (or
                                      (and (same-rank? evil-king-sq tosq) (pos-clear-path? my-pos evil-king-sq tosq))
                                      (and (same-file? evil-king-sq frsq) (pos-clear-path? my-pos evil-king-sq frsq)))
                                    (dolist (msc msc-ortho-promotion-list)
                                      (push (make-move :frsq frsq :tosq tosq :frman frman :msc msc) result))))
                                (t
                                  (error "generate-nocheck-checkers: cond fault/1")))))))
                      ;;
                      ;; Advance from third, fourth, fifth, or sixth rank
                      ;;
                      (t
                        (when (or advchflag (bb-sq-set? prwbb tosq))
                          (push (make-move :frsq frsq :tosq tosq :frman frman) result)))))))
              ;;
              ;; Capture (not en passant)
              ;;
              (dolist (tosq pcsqs)
                (let*
                  (
                    (toman      (get-man my-pos tosq))
                    (captdir    (sq+sq->dir frsq tosq))
                    (captbidir  (dir->bidir captdir))
                    (captchflag (when disflag (/= ekfbidir captbidir)))
                  )
                  (if r7flag
                    ;;
                    ;; Capture with promotion
                    ;;
                    (if captchflag
                      ;;
                      ;; Check by discovery
                      ;;
                      (dolist (msc msc-promotion-list)
                        (push (make-move :frsq frsq :tosq tosq :frman frman :toman toman :msc msc) result))
                      ;;
                      ;; Check by the new piece made from the promotion
                      ;;
                      (let ((ektdir (sq+sq->dir evil-king-sq tosq)))
                        (when ektdir
                          (cond
                            ((is-dir-crook? ektdir)
                              (push (make-move :frsq frsq :tosq tosq :frman frman :toman toman :msc msc-ppn) result))
                            ((is-dir-diago? ektdir)
                              (when
                                (or
                                  (pos-clear-path? my-pos evil-king-sq tosq)
                                  (and
                                    (= ektdir captdir)
                                    (pos-clear-path? my-pos evil-king-sq frsq)))
                                (dolist (msc msc-diago-promotion-list)
                                  (push (make-move :frsq frsq :tosq tosq :frman frman :toman toman :msc msc) result))))
                            ((is-dir-ortho? ektdir)
                              (when (pos-clear-path? my-pos evil-king-sq tosq)
                                (dolist (msc msc-ortho-promotion-list)
                                  (push (make-move :frsq frsq :tosq tosq :frman frman :toman toman :msc msc) result))))
                            (t
                              (error "generate-nocheck-checkers: cond fault/2"))))))
                    ;;
                    ;; Capture without promotion
                    ;;
                    (when (or captchflag (bb-sq-set? prwbb tosq))
                      (push (make-move :frsq frsq :tosq tosq :frman frman :toman toman) result)))))
              ;;
              ;; En passant
              ;;
              (when (and epsq (find epsq (color+sq->pawn-atk-sqs good frsq)))
                (let ((ep-move (make-move :frsq frsq :tosq epsq :frman frman :msc msc-epc)))
                  (when (is-en-passant-move-playable-and-checks? my-pos ep-move)
                    (push ep-move result))))))
          ;;
          ;; Moves for a knight
          ;;
          ((= frpiece piece-knight)
            (let ((tobb (bb-and2 afsbb target-bb)))
              (unless disflag
                (bb-and2d tobb nrwbb))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman :toman (get-man my-pos tosq)) result))))
          ;;
          ;; Moves for a bishop
          ;;
          ((= frpiece piece-bishop)
            (let ((tobb (bb-and2 afsbb target-bb)))
              (when (bb-sq-set? rmbb frsq)
                (bb-and2d tobb (sq+sq->beam-bb good-king-sq frsq)))
              (unless disflag
                (bb-and2d tobb brwbb))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman :toman (get-man my-pos tosq)) result))))
          ;;
          ;; Moves for a rook
          ;;
          ((= frpiece piece-rook)
            (let ((tobb (bb-and2 afsbb target-bb)))
              (when (bb-sq-set? rmbb frsq)
                (bb-and2d tobb (sq+sq->beam-bb good-king-sq frsq)))
              (unless disflag
                (bb-and2d tobb rrwbb))
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman :toman (get-man my-pos tosq)) result))))
          ;;
          ;; Moves for a queen
          ;;
          ((= frpiece piece-queen)
            (let ((tobb (bb-and2 afsbb target-bb)))
              (when (bb-sq-set? rmbb frsq)
                (bb-and2d tobb (sq+sq->beam-bb good-king-sq frsq)))
              (bb-and2d tobb qrwbb)
              (bb-scan (tobb tosq)
                (push (make-move :frsq frsq :tosq tosq :frman frman :toman (get-man my-pos tosq)) result))))
          ;;
          ;; Moves for a king
          ;;
          ((= frpiece piece-king)
            (when disflag
              (let ((tobb (bb-and2c2 (bb-and2 afsbb target-bb) (svref atkbc evil))))
                (bb-and2c2d tobb (sq+sq->beam-bb evil-king-sq good-king-sq))
                (bb-scan (tobb tosq)
                  (push (make-move :frsq frsq :tosq tosq :frman frman :toman (get-man my-pos tosq)) result))))
            (when (nonzero? (pos-cast my-pos))
              (dolist (castling (color->castlings good))
                (when (pos-can-castle? my-pos castling)
                  (let ((rook-away-sq (castling->rook-away castling)))
                    (when
                      (or
                        (and (same-file? evil-king-sq rook-away-sq) (pos-clear-path? my-pos evil-king-sq rook-away-sq))
                        (and (same-rank? evil-king-sq good-king-sq) (pos-clear-path? my-pos evil-king-sq good-king-sq)))
                      (push (move-clone (castling->move castling)) result)))))))
          ;;
          (t
            (error "generate-nocheck-checkers: bad frpiece: ~A" frpiece)))))
    ;;
    ;; Mark all moves as checks
    ;;
    (movelist-set-all-single-flag result mf-chck)
    ;;
    result))

(defun generate-evasion-checkers (my-pos)
  "Return a list of checking moves generated for the given position (called with good king in check)."
  (movelist-pass-checkers (movelist-setflags-checks (generate-evasion my-pos) my-pos)))

(defun generate-checkers (my-pos)
  "Generate all the checking moves from a position."
  (if (pos-inch my-pos)
    (generate-evasion-checkers my-pos)
    (generate-nocheck-checkers my-pos)))

(defun generate-checkmaters (my-pos)
  "Generate all the checkmating moves from a position."
  (movelist-pass-checkmaters (movelist-setflags-checkmates (generate-checkers my-pos) my-pos)))

;;; ---------- Gainer/holder move generation routines

(defun generate-gainers (my-pos)
  "Generate all the gainer (i.e., gains material) moves from a position."
  (if (pos-inch my-pos)
    (movelist-pass-gainers (movelist-setflags-gainers-holders (generate-evasion my-pos)))
    (generate-nocheck-gainers my-pos)))

(defun generate-holders (my-pos)
  "Generate all the holder (i.e., does not gain material) moves from a position."
  (if (pos-inch my-pos)
    (movelist-pass-holders (movelist-setflags-gainers-holders (generate-evasion my-pos)))
    (generate-nocheck-holders my-pos)))

;;; ---------- Advanced move generation routines

(defun generate-notated (my-pos)
  "Return a list of moves generated for the given position; mark each move as needed."
  (movelist-setflags-notation (generate my-pos) my-pos))

(defun generate-canonical (my-pos)
  "Return a list of moves generated for the given position; mark each move as needed and sort by SAN."
  (movelist-sort-by-san (generate-notated my-pos)))

(defun generate-super (my-pos)
  "Return a list of moves generated for the given position; mark each move fully and sort by SAN."
  (movelist-sort-by-san (movelist-setflags-super (generate my-pos) my-pos)))

;;; ---------- Advanced mate/lose detection routines

(defun pos-is-mate-in-1? (my-pos)
  "Determine if a mate in 1 exists in the given position."
  (let ((result nil) (moves (generate-checkers my-pos)) (fmvs (pos-fmvs my-pos)))
    (dowhile (and (not result) moves)
      (let ((move (pop moves)))
        (pos-execute my-pos move)
        (when (pos-has-no-moves? my-pos)
          (setf result t))
        (pos-retract my-pos)))
    (setf (pos-fmvs my-pos) fmvs)
    result))

(defun pos-is-lose-in-1? (my-pos)
  "Determine if the given position is a lose in 1."
  (let ((result nil) (moves (generate my-pos)))
    (when moves
      (let ((fmvs (pos-fmvs my-pos)))
        (setf result t)
        (dowhile (and result moves)
          (let ((move (pop moves)))
            (pos-execute my-pos move)
            (unless (pos-is-mate-in-1? my-pos)
              (setf result nil))
            (pos-retract my-pos)))
        (setf (pos-fmvs my-pos) fmvs)))
    result))

;;; ---------- Verification routines

(defun pos-verify-generation (my-pos)
  "Run move generation verification tests on a position."
  (let*
    (
      (msg    nil)
      (moves0 (generate my-pos))
      (moves1 (generate-gainers my-pos))
      (moves2 (generate-holders my-pos))
      (moves3 (generate-checkers my-pos))
      (moves4 (movelist-pass-checkers (movelist-setflags-checks (generate my-pos) my-pos)))
      (moves5 (movelist-pass-checkers (movelist-slow-setflags-checks (generate my-pos) my-pos)))
      (moves6 (append moves1 moves2))
      (count0 (length moves0))
      (count1 (length moves1))
      (count2 (length moves2))
      (count3 (length moves3))
      (count4 (length moves4))
      (count5 (length moves5))
      (count6 (length moves6))
    )
    (unless msg
      (when (/= count0 (+ count1 count2))
        (setf msg "(/= count0 (+ count1 count2))")))
    (unless msg
      (when (/= count0 count6)
        (setf msg "(/= count0 count6)")))
    (unless msg
      (when (/= count3 count4)
        (setf msg "(/= count3 count4)")))
    (unless msg
      (when (/= count3 count5)
        (setf msg "(/= count3 count5)")))
    (unless msg
      (when (not (same-movelists? moves0 moves6))
        (setf msg "(not (same-movelists? moves0 moves6))")))
    (unless msg
      (when (not (same-movelists? moves3 moves4))
        (setf msg "(not (same-movelists? moves3 moves4))")))
    (unless msg
      (when (not (same-movelists? moves3 moves5))
        (setf msg "(not (same-movelists? moves3 moves5))")))
    (when msg
      (encode-pos (acs-ostream *acs*) my-pos)
      (error "pos-verify-generation: ~A" msg)))
  t)

;;; ---------- Move list sequence notation marking

(defun movelist-notate-sequence (my-moves my-pos)
  "Mark the each move in the sequence that starts from the given position."
  (let ((pops (pos-prior-move-count my-pos)) (fmvs (pos-fmvs my-pos)))
    (dolist (move my-moves)
      (unless (is-move-marked-notated? move)
        (let ((genmove (locate-move-no-fail (generate-notated my-pos) move)))
          (bit-ior (move-mfbits move) (move-mfbits genmove) t)))
      (pos-execute my-pos move))
    (dowhile (> (pos-prior-move-count my-pos) pops)
      (pos-retract my-pos))
    (setf (pos-fmvs my-pos) fmvs))
  my-moves)

(defun pos-notate-moves (my-pos)
  "Ensure notation marks for all moves (history and future) in a position."
  (let ((pops (pos-prior-move-count my-pos)))
    (pos-retract-all my-pos)
    (movelist-notate-sequence (pos-fmvs my-pos) my-pos)
    (pos-scroll my-pos pops))
  (values))

;;; ---------- Simple move ordering routines

(defun movevector-assign-order-negative-mobility (my-movevector my-pos)
  "Assign move order metrics for a move vector based on negative evil mobility."
  (let ((limit (length my-movevector)) (fmvs (pos-fmvs my-pos)))
    (dotimes (index limit)
      (let ((move (svref my-movevector index)))
        (pos-execute my-pos move)
        (let ((evilcount (count-moves my-pos)))
          (if (and (pos-inch my-pos) (zero? evilcount))
            (setf (move-order move) (* value-queen 4))
            (setf (move-order move) (- evilcount))))
        (pos-retract my-pos)))
    (setf (pos-fmvs my-pos) fmvs))
  my-movevector)

(defun movevector-assign-order-simple-est-gain (my-movevector)
  "Assign move order metrics for a move vector based on a simple estimated gain."
  (let ((limit (length my-movevector)))
    (dotimes (index limit)
      (let ((move (svref my-movevector index)))
        (setf (move-order move) (move-simple-est-gain move)))))
  my-movevector)

(defun movevector-assign-order-better-est-gain (my-movevector my-pos)
  "Assign move order metrics for a move vector based on a better estimated gain."
  (let*
    (
      (limit (length my-movevector))
      (atkbc (bbdb-atkbc (pos-bbdb my-pos)))
      (abgbb (svref atkbc (pos-good my-pos)))
      (abebb (svref atkbc (pos-evil my-pos)))
    )
    (dotimes (index limit)
      (let*
        (
          (move   (svref my-movevector index))
          (frsq   (move-frsq  move))
          (tosq   (move-tosq  move))
          (frman  (move-frman move))
          (toman  (move-toman move))
          (msc    (move-msc   move))
          (d0flag (bb-sq-set? abgbb frsq))
          (a0flag (bb-sq-set? abebb frsq))
          (a1flag (bb-sq-set? abebb tosq))
          (order  even-score)
        )
        (setf order (+ (man->value toman) (msc->value msc)))
        (when (and (not d0flag) a0flag)
          (incf order (man->value frman)))
        (when a1flag
          (decf order (man->value frman)))
        (decf order (svref center-tropism-vec frsq))
        (incf order (svref center-tropism-vec tosq))
        (setf (move-order move) order))))
  my-movevector)

;;; ---------- Maximum ply and iteration limits

(defconstant ply-limit       256 "Used to avoid variable length ply indexed vectors")
(defconstant iteration-limit  64 "Used to avoid variable length iteration indexed vectors")

;;; ---------- Search termination status

(defconstant sts-all-bad-but-one     0 "All moves but one are bad")
(defconstant sts-all-certain         1 "All moves have certain scores")
(defconstant sts-book-move           2 "Book move located")
(defconstant sts-certain-lose        3 "Certain lose located")
(defconstant sts-certain-mate        4 "Certain mate located")
(defconstant sts-immediate-draw      5 "Immediate draw detected")
(defconstant sts-immediate-lose      6 "Immediate lose detected")
(defconstant sts-interrupt           7 "Interrupted")
(defconstant sts-maximum-depth       8 "Maximum depth limit")
(defconstant sts-no-moves            9 "No moves available")
(defconstant sts-param-fault        10 "Parameter fault")
(defconstant sts-program-error      11 "Program error detected")
(defconstant sts-program-iter-limit 12 "Program iteration limit")
(defconstant sts-random-move        13 "Random move selected")
(defconstant sts-rl-iterations      14 "Resource limit (iterations)")
(defconstant sts-rl-nc              15 "Resource limit (node count)")
(defconstant sts-rl-time            16 "Resource limit (time)")
(defconstant sts-singleton          17 "Only one move available")
(defconstant sts-unterminated       18 "Search is still active")

(defconstant sts-limit (1+ sts-unterminated))

(defconstant sts-string-vec
  (make-array sts-limit
    :initial-contents
      (vector
        "All moves but one are bad"
        "All moves have certain scores"
        "Book move located"
        "Certain lose located"
        "Certain mate located"
        "Immediate draw detected"
        "Immediate lose detected"
        "Interrupted"
        "Maximum depth limit"
        "No moves available"
        "Parameter fault"
        "Program error detected"
        "Program iteration limit"
        "Random move selected"
        "Resource limit (iterations)"
        "Resource limit (node count)"
        "Resource limit (time)"
        "Only one move available"
        "Search is still active")))

(defmacro sts->string (my-sts) `(svref sts-string-vec ,my-sts))

;;; ---------- Move string decoding

(defun pos-match-san (my-pos my-san)
  "Return the move (if any) that matches the input SAN move string."
  (let ((result nil) (moves (generate-notated my-pos)))
    (dowhile (and (not result) moves)
      (let ((move (pop moves)))
        (when (string= my-san (move->string move))
          (setf result move))))
    result))

;;; ---------- Random moves

(defun pos-select-random-move (my-pos)
  "Select a random move to play."
  (let* ((moves (generate my-pos)) (move-count (length moves)))
    (elt moves (acs-random move-count))))

(defun pos-select-and-play-random-move (my-pos)
  "Select a random move and play it."
  (pos-execute my-pos (pos-select-random-move my-pos))
  (values))

;;; ---------- PGN tag names

(defconstant ptn-event  0 "PGN tag name: Event")
(defconstant ptn-site   1 "PGN tag name: Site")
(defconstant ptn-date   2 "PGN tag name: Date")
(defconstant ptn-round  3 "PGN tag name: Round")
(defconstant ptn-white  4 "PGN tag name: White")
(defconstant ptn-black  5 "PGN tag name: Black")
(defconstant ptn-result 6 "PGN tag name: Result")
(defconstant ptn-utc    7 "PGN tag name: UTC")

(defconstant ptn-limit (1+ ptn-utc))

(defconstant ptn-index-list
  (list
    ptn-event
    ptn-site
    ptn-date
    ptn-round
    ptn-white
    ptn-black
    ptn-result
    ptn-utc))

(defmacro doptns ((my-ptn-var) &body my-body)
  "Construct a per PGN tag name iteration loop."
  `(dolist (,my-ptn-var ptn-index-list)
    ,@my-body))

(defconstant ptn-string-vec
  (make-array ptn-limit
    :initial-contents
      (vector "Event" "Site" "Date" "Round" "White" "Black" "Result" "UTC")))

(defmacro ptn->string (my-ptn) `(svref ptn-string-vec ,my-ptn))

;;; PGN tag pair encoding

(defun encode-ptpair (my-stream my-ptn my-ptvalue)
  "Encode a PGN tag pair to a stream."
  (format my-stream "[~A ~A~A~A]" (ptn->string my-ptn) ascii-quote my-ptvalue ascii-quote)
  (values))

(defun ptpair->string (my-ptn my-ptvalue)
  "Encode the PGN tag pair on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-ptpair str-stream my-ptn my-ptvalue)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

;;; ---------- PGN tag pair vector

(defun new-ptp-vec ()
  "Return a new vector of default PGN tag pairs."
  (let ((result (make-array ptn-limit :initial-element nil)))
    (setf (svref result ptn-event)  "Unknown event")
    (setf (svref result ptn-site)   "Unknown site")
    (setf (svref result ptn-date)   (timemark-date->string (current-ltz->timemark)))
    (setf (svref result ptn-round)  "-")
    (setf (svref result ptn-white)  "Unknown player")
    (setf (svref result ptn-black)  "Unknown player")
    (setf (svref result ptn-result) (gsr->string gsr-unterminated))
    (setf (svref result ptn-utc)    (current-utc->string))
    result))

;;; ---------- Structure game

(defstruct
  (game
    (:print-function meta-encode-game))
  "A chess game"
  (pos     (new-pos))        ; The position
  (gsr     gsr-unterminated) ; The game score result
  (ptp-vec (new-ptp-vec)))   ; A vector of PGN tag values (each nil or string)

(defun encode-game-tag-pairs (my-stream my-game)
  "Encode the tag pairs of a game to a stream."
  (let ((ptp-vec (game-ptp-vec my-game)))
    (doptns (ptn)
      (when (svref ptp-vec ptn)
        (encode-ptpair my-stream ptn (svref ptp-vec ptn))
        (newline my-stream))))
  (values))

(defun encode-game-move-text-item (my-stream my-column my-item)
  "Encode a single move text item string; return the updated column."
  (let ((column my-column) (column-limit 80) (item-length (length my-item)))
    (cond
      ((zero? column)
        (format my-stream "~A" my-item)
        (setf column item-length))
      ((< (+ column (1+ item-length)) column-limit)
        (format my-stream " ~A" my-item)
        (incf column (1+ item-length)))
      (t
        (format my-stream "~%~A" my-item)
        (setf column item-length)))
    column))

(defun encode-game-move-text (my-stream my-game)
  "Encode the move text of a game to a stream."
  (let*
    (
      (pos  (game-pos my-game))
      (pops (pos-prior-move-count pos))
    )
    (pos-notate-moves pos)
    (pos-retract-all pos)
    (let
      (
        (column 0)
        (fgpair (make-fgpair :good (pos-good pos) :fmvn (pos-fmvn pos)))
        (first1 t)
      )
      (dolist (move (pos-fmvs pos))
        (when (or first1 (is-color-white? (fgpair-good fgpair)))
          (setf column (encode-game-move-text-item my-stream column (fgpair->string fgpair))))
        (setf column (encode-game-move-text-item my-stream column (move->string move)))
        (setf first1 nil)
        (fgpair-incf fgpair))
      (setf column (encode-game-move-text-item my-stream column (gsr->string (game-gsr my-game))))
      (newline my-stream))
    (pos-scroll pos pops))
  (values))

(defun encode-game (my-stream my-game)
  "Encode a game to a stream."
  (encode-game-tag-pairs my-stream my-game)
  (newline my-stream)
  (encode-game-move-text my-stream my-game)
  (newline my-stream)
  (values))

(defun meta-encode-game (my-game my-stream my-level)
  "Glue to encode a game structure."
  (declare (ignore my-level))
  (encode-game my-stream my-game)
  (values))

(defun game-reset (my-game)
 "Reset the given game."
 (pos-reset (game-pos my-game))
 (setf (game-gsr my-game) gsr-unterminated)
 (setf (game-ptp-vec my-game) (new-ptp-vec))
 (values))

(defun game-set-gsr (my-game my-gsr)
  "Set the gsr and the Result tag value in a game using a gsr indication."
  (setf (game-gsr my-game) my-gsr)
  (setf (svref (game-ptp-vec my-game) ptn-result) (gsr->string my-gsr))
  (values))

(defun game->hash (my-game)
  "Generate a hash for the given game."
  (let*
    (
      (pos  (game-pos my-game))
      (pops (pos-prior-move-count pos))
      (hash (hash-clone (gsr->hash (game-gsr my-game))))
    )
    (pos-retract-all pos)
    (dowhile (pos-fmvs pos)
      (setf hash (hash-rotate-right hash))
      (hash-xor2d hash (pos-mdhs pos))
      (pos-execute-next pos))
    (setf hash (hash-rotate-right hash))
    (hash-xor2d hash (pos-mdhs pos))
    (pos-scroll pos pops)
    hash))

;;; ---------- Game lists

(defun encode-games (my-stream my-games)
  "Encode a list of games to a stream."
  (dolist (game my-games)
    (encode-game my-stream game))
  (values))

;;; ---------- Random game enumeration

(defun new-random-game ()
  "Generate a random game."
  (let*
    (
      (game (make-game))
      (pos  (game-pos game))
    )
    (dountil (pos-is-game-over? pos)
      (pos-select-and-play-random-move pos))
    (game-set-gsr game (pos->gsr pos))
    game))

(defun calculate-random-game-terminations (my-limit)
  "Generate random games and return a vector of position dependent game termination totals."
  (let ((result (make-array pdgt-limit :initial-element 0)))
    (dotimes (index my-limit)
      (incf (svref result (pos->pdgt (game-pos (new-random-game))))))
    result))

;;; ----------  Basic pawn location score vector

(defconstant pawn-color-sq-value-vec
  (make-array (list color-rlimit sq-limit)
    :initial-contents
      (vector
        (vector
             0    0    0    0    0    0    0    0
             0    0    0    0    0    0    0    0
            16   16   32   32   32   32   16   16
            32   32   64   64   64   64   32   32
            48   48   96   96   96   96   48   48
            64   64  128  128  128  128   64   64
            80   80  160  160  160  160   80   80
             0    0    0    0    0    0    0    0)
        (vector
             0    0    0    0    0    0    0    0
            80   80  160  160  160  160   80   80
            64   64  128  128  128  128   64   64
            48   48   96   96   96   96   48   48
            32   32   64   64   64   64   32   32
            16   16   32   32   32   32   16   16
             0    0    0    0    0    0    0    0
             0    0    0    0    0    0    0    0))))

;;; ---------- Structure pawnst

(defstruct
  (pawnst)
  "A pawn structure; used in a pawn transposition table entry."
  (connbb   nil)  ; Connected pawn bitboard
  (lonebb   nil)  ; Isolated pawn bitboard
  (multbb   nil)  ; Multiple pawn bitboard
  (passbb   nil)  ; Passed pawn bitboard
  (pcbcfvec nil)  ; Pawn count by color/file vector
  (scorevec nil)) ; A color indexed vector of scores

(defun new-pawnst ()
  "Return a new pawn structure."
  (make-pawnst
    :connbb   (make-bb)
    :lonebb   (make-bb)
    :multbb   (make-bb)
    :passbb   (make-bb)
    :pcbcfvec (make-array (list color-rlimit file-limit) :initial-element 0)
    :scorevec (make-array color-rlimit :initial-element even-score)))

(defun pawnst-reset (my-pawnst)
  "Reset the given full pawn stucture."
  (bb-reset (pawnst-connbb my-pawnst))
  (bb-reset (pawnst-lonebb my-pawnst))
  (bb-reset (pawnst-multbb my-pawnst))
  (bb-reset (pawnst-passbb my-pawnst))
  (docolors (color)
    (dofiles (file)
      (setf (aref (pawnst-pcbcfvec my-pawnst) color file) 0))
    (setf (svref (pawnst-scorevec my-pawnst) color) even-score))
  (values))

(defun pawnst-build (my-pos)
  "Build a new pawn structure from the given position; only pawn data used."
  (let*
    (
      (result   (new-pawnst))
      (connbb   (pawnst-connbb result))
      (lonebb   (pawnst-lonebb result))
      (multbb   (pawnst-multbb result))
      (passbb   (pawnst-passbb result))
      (pcbcfvec (pawnst-pcbcfvec result))
      (scorevec (pawnst-scorevec result))
      (bbdb     (pos-bbdb my-pos))
      (locbm    (bbdb-locbm bbdb))
      (wplbb    (svref locbm man-wp))
      (bplbb    (svref locbm man-bp))
      (plsbc    (make-array color-rlimit :initial-contents (vector wplbb bplbb)))
    )
    ;;
    ;; Building: The color/file count vector
    ;;
    (docolors (color)
      (let ((bb (bb-clone (svref plsbc color))))
        (bb-scan (bb sq)
          (incf (aref pcbcfvec color (sq->file sq))))))
    ;;
    ;; Building: The connected pawn bitboard
    ;;
    (docolors (color)
      (let ((bb (bb-clone (svref plsbc color))) (orig-bb (svref plsbc color)))
        (bb-scan (bb sq)
          (unless (bb-ni2? (color+sq->connect-pawn-bb sq) orig-bb)
            (bb-set-sq connbb sq)))))
    ;;
    ;; Building: The isolated pawn bitboard
    ;;
    (docolors (color)
      (let ((bb (bb-clone (svref plsbc color))))
        (bb-scan (bb sq)
          (let ((file (sq->file sq)) (sum 0))
            (when (> file file-a)
              (incf sum (aref pcbcfvec color (1- file))))
            (when (< file file-h)
              (incf sum (aref pcbcfvec color (1+ file))))
            (when (zero? sum)
              (bb-set-sq lonebb sq))))))
    ;;
    ;; Building: The multiple pawn bitboard
    ;;
    (docolors (color)
      (let ((bb (bb-clone (svref plsbc color))))
        (bb-scan (bb sq)
          (when (> (aref pcbcfvec color (sq->file sq)) 1)
            (bb-set-sq multbb sq)))))
    ;;
    ;; Building: The passed pawn bitboard
    ;;
    (docolors (color)
      (let ((bb (bb-clone (svref plsbc color))) (other-bb (svref plsbc (other-color color))))
        (bb-scan (bb sq)
          (when (bb-ni2? (color+sq->passed-pawn-bb color sq) other-bb)
            (bb-set-sq passbb sq)))))
    ;;
    ;; Scoring: The connected pawn bitboard
    ;;
    (docolors (color)
      (let ((bb (bb-and2 connbb (svref plsbc color))))
        (bb-scan (bb sq)
          (incf (svref scorevec color) 8))))
    ;;
    ;; Scoring: The isolated pawn bitboard
    ;;
    (docolors (color)
      (let ((bb (bb-and2 lonebb (svref plsbc color))))
        (bb-scan (bb sq)
          (incf (svref scorevec color) -200))))
    ;;
    ;; Scoring: The multiple pawn bitboard
    ;;
    (docolors (color)
      (let ((bb (bb-and2 multbb (svref plsbc color))))
        (bb-scan (bb sq)
          (incf (svref scorevec color) -80))))
    ;;
    ;; Scoring: The passed pawn bitboard (TBD)
    ;;
    ;;
    ;; Scoring: Location
    ;;
    (docolors (color)
      (let ((bb (bb-clone (svref plsbc color))))
        (bb-scan (bb sq)
          ;;
          ;; Fold simple location scores into the accumulators
          ;;
          (incf (svref scorevec color) (aref pawn-color-sq-value-vec color sq)))))
    ;;
    result))

;;; ---------- General transposition table score value interpretation

(defconstant tsv-empty 0 "Transposition score value: empty")
(defconstant tsv-exact 1 "Transposition score value: exact value")
(defconstant tsv-lower 2 "Transposition score value: lower bound")
(defconstant tsv-upper 3 "Transposition score value: upper bound")

(defun score+window->tsv (my-score my-window)
  "Return the score intepetation given a score and a window."
  (cond
    ((is-score-outside-high? my-score my-window)
      tsv-lower)
    ((is-score-outside-low? my-score my-window)
      tsv-upper)
    (t
      tsv-exact)))

;;; ---------- Structure ttentry

(defstruct
  (ttentry)
  "A base structure for a transposition table entry."
  (hash nil)) ; Position hash; copy of mdhs or pshs; nil if vacant entry

(defun ttentry-reset (my-ttentry)
  "Reset the given transposition table entry."
  (setf (ttentry-hash my-ttentry) nil))

;;; ---------- Structure ttbase

(defstruct
  (ttbase)
  "A base structure for a transposition table."
  (log2n 0 :type fixnum)  ; Log base two of the table entry count
  (limit 0 :type fixnum)  ; Count of table entries
  (amask 0 :type fixnum)  ; Address generation mask
  (usage 0 :type fixnum)  ; Current usage count
  (ecmat 0 :type integer) ; Event count: match
  (ecpro 0 :type integer) ; Event count: probe
  (ecsto 0 :type integer) ; Event count: store
  (stvec nil))            ; Storage vector for transposition table entries

(defun ttbase-reset-stats (my-ttbase)
  "Reset the statistics in the given transposition table."
  (setf (ttbase-ecmat my-ttbase) 0)
  (setf (ttbase-ecpro my-ttbase) 0)
  (setf (ttbase-ecsto my-ttbase) 0)
  (values))

(defun ttbase-reset-scalars (my-ttbase)
  "Reset the scalars in the given transposition table for a reset operation."
  (setf (ttbase-usage my-ttbase) 0)
  (ttbase-reset-stats my-ttbase)
  (values))

(defun ttbase-dumpstats (my-ttbase my-color)
  "Output labeled statistics for the given ttbase."
  (format (acs-ostream *acs*)  "    (~A) size: ~:D   usage: ~:D   match: ~:D   probe: ~:D   store: ~:D~%"
    (color->string my-color)
    (ttbase-limit my-ttbase)
    (ttbase-usage my-ttbase)
    (ttbase-ecmat my-ttbase)
    (ttbase-ecpro my-ttbase)
    (ttbase-ecsto my-ttbase))
  (values))

(defmacro ttbase-offset (my-ttbase my-hash)
  "Calculate the offset into the entry store for the given hash."
  `(logand (svref (hash-hw-vec ,my-hash) 0) (ttbase-amask ,my-ttbase)))

;;; ---------- Structure gttentry

(defstruct
  (gttentry
    (:include ttentry))
  "A general transposition table entry."
  (nemo  0 :type fixnum)             ; Numeric equivalent move ordinal or zero if no move data
  (score broken-score :type integer) ; Position score if present, may be a bound
  (tsv   tsv-empty :type fixnum)     ; Score value interpretation
  (draft 0 :type fixnum))            ; Analysis draft

(defun gttentry-reset (my-gttentry)
  "Reset the given general transposition table entry."
  (ttentry-reset my-gttentry)
  (setf (gttentry-nemo  my-gttentry) 0)
  (setf (gttentry-score my-gttentry) broken-score)
  (setf (gttentry-tsv   my-gttentry) tsv-empty)
  (setf (gttentry-draft my-gttentry) 0)
  (values))

;;; ---------- Structure gttbase

(defstruct
  (gttbase
    (:include ttbase))
  "A general transposition table.")

(defun new-gttbase (my-log2n)
  "Return a new general transposition table."
  (let*
    (
      (limit  (2^ my-log2n))
      (amask  (1- limit))
      (stvec  (make-array limit :initial-element nil))
    )
    (dotimes (index limit)
      (setf (svref stvec index) (make-gttentry)))
    (make-gttbase :log2n my-log2n :limit limit :amask amask :stvec stvec)))

(defun gttbase-reset (my-gttbase)
  "Reset the given general transposition table."
  (ttbase-reset-scalars my-gttbase)
  (let ((limit (gttbase-limit my-gttbase)) (stvec (gttbase-stvec my-gttbase)))
    (dotimes (index limit)
      (gttentry-reset (svref stvec index))))
  (values))

(defun gttbase-dumpstats (my-gttbase my-color)
  "Output labeled statistics for the given gttbase."
  (ttbase-dumpstats my-gttbase my-color)
  (values))

(defmacro gttbase-offset (my-gttbase my-pos)
  "Calculate the offset into the entry store for the given general transposition table and position."
  `(ttbase-offset ,my-gttbase (pos-mdhs ,my-pos)))

(defun gttbase-fetch (my-gttbase my-pos)
  "Return the corresponding gttentry for the given general transposition table and position (hash may not match)."
  (svref (gttbase-stvec my-gttbase) (gttbase-offset my-gttbase my-pos)))

(defun gttbase-probe (my-gttbase my-pos)
  "Probe the given general transposition table for a match to the given position; nil if not found."
  (incf (gttbase-ecpro my-gttbase))
  (let ((result (gttbase-fetch my-gttbase my-pos)))
    (if (hash-eq? (gttentry-hash result) (pos-mdhs my-pos))
      (incf (gttbase-ecmat my-gttbase))
      (setf result nil))
    result))

(defun gttbase-store (my-gttbase my-pos my-move my-score my-tsv my-draft)
  "Store the position/result combination in the given general transposition table."
  (incf (gttbase-ecsto my-gttbase))
  (let ((gttentry (gttbase-fetch my-gttbase my-pos)))
    (unless (gttentry-hash gttentry)
      (incf (gttbase-usage my-gttbase)))
    (setf (gttentry-hash  gttentry) (hash-clone (pos-mdhs my-pos)))
    (setf (gttentry-nemo  gttentry) (if my-move (move->nemo my-move) 0))
    (setf (gttentry-score gttentry) my-score)
    (setf (gttentry-tsv   gttentry) my-tsv)
    (setf (gttentry-draft gttentry) my-draft))
  (values))

;;; ---------- Structure gttpair

(defstruct
  (gttpair)
  "A pair of general transposition tables."
  (ttvec (make-array color-rlimit :initial-element nil))) ; Color indexed vector of tables

(defun new-gttpair (my-log2n)
  "Return a new general transposition table pair."
  (let ((result (make-gttpair)))
    (docolors (color)
      (setf (svref (gttpair-ttvec result) color) (new-gttbase my-log2n)))
    result))

(defun gttpair-reset (my-gttpair)
  "Reset the given general transposition table pair."
  (docolors (color)
    (gttbase-reset (svref (gttpair-ttvec my-gttpair) color)))
  (values))

(defun gttpair-dumpstats (my-gttpair)
  "Output labeled statistics for the given gttpair."
  (docolors (color)
    (gttbase-dumpstats (svref (gttpair-ttvec my-gttpair) color) color))
  (values))

(defun gttpair-probe (my-gttpair my-pos)
  "Return the matching entry for the given general transposition table pair and position; nil if not found."
  (gttbase-probe
    (svref (gttpair-ttvec my-gttpair) (pos-good my-pos))
    my-pos))

(defun gttpair-store (my-gttpair my-pos my-move my-score my-tsv my-draft)
  "Store the position/result combination in the given general transposition table pair."
  (gttbase-store
    (svref (gttpair-ttvec my-gttpair) (pos-good my-pos))
    my-pos
    my-move
    my-score
    my-tsv
    my-draft)
  (values))

;;; ---------- Structure pttentry

(defstruct
  (pttentry
    (:include ttentry))
  "A pawn transposition table entry."
  (pawnst (new-pawnst))) ; Full pawn structure

(defun pttentry-reset (my-pttentry)
  "Reset the given pawn transposition table entry."
  (ttentry-reset my-pttentry)
  (pawnst-reset (pttentry-pawnst my-pttentry))
  (values))

;;; ---------- Structure pttbase

(defstruct
  (pttbase
    (:include ttbase))
  "A pawn transposition table.")

(defun new-pttbase (my-log2n)
  "Return a new pawn transposition table."
  (let*
    (
      (limit  (2^ my-log2n))
      (amask  (1- limit))
      (stvec  (make-array limit :initial-element nil))
    )
    (dotimes (index limit)
      (setf (svref stvec index) (make-pttentry)))
    (make-pttbase :log2n my-log2n :limit limit :amask amask :stvec stvec)))

(defun pttbase-reset (my-pttbase)
  "Reset the given pawn transposition table."
  (ttbase-reset-scalars my-pttbase)
  (let ((limit (pttbase-limit my-pttbase)) (stvec (pttbase-stvec my-pttbase)))
    (dotimes (index limit)
      (pttentry-reset (svref stvec index))))
  (values))

(defun pttbase-dumpstats (my-pttbase my-color)
  "Output labeled statistics for the given pttbase."
  (ttbase-dumpstats my-pttbase my-color)
  (values))

(defmacro pttbase-offset (my-pttbase my-pos)
  "Calculate the offset into the entry store for the given pawn transposition table and position."
  `(ttbase-offset ,my-pttbase (pos-pshs ,my-pos)))

(defun pttbase-fetch (my-pttbase my-pos)
  "Return the corresponding pttentry for the given pawn transposition table and position (hash may not match)."
  (svref (pttbase-stvec my-pttbase) (pttbase-offset my-pttbase my-pos)))

(defun pttbase-probe (my-pttbase my-pos)
  "Probe the given pawn transposition table for a match to the given position; nil if not found."
  (incf (pttbase-ecpro my-pttbase))
  (let ((result (pttbase-fetch my-pttbase my-pos)))
    (if (hash-eq? (pttentry-hash result) (pos-pshs my-pos))
      (incf (pttbase-ecmat my-pttbase))
      (setf result nil))
    result))

(defun pttbase-store (my-pttbase my-pos my-pawnst)
  "Store the position/result combination in the given pawn transposition table."
  (incf (pttbase-ecsto my-pttbase))
  (let ((pttentry (pttbase-fetch my-pttbase my-pos)))
    (unless (pttentry-hash pttentry)
      (incf (pttbase-usage my-pttbase)))
    (setf (pttentry-hash     pttentry) (hash-clone (pos-pshs my-pos)))
    (setf (pttentry-pawnst pttentry) my-pawnst))
  (values))

;;; ---------- Structure pttpair

(defstruct
  (pttpair)
  "A pair of pawn transposition tables."
  (ttvec (make-array color-rlimit :initial-element nil))) ; Color indexed vector of tables

(defun new-pttpair (my-log2n)
  "Return a new pawn transposition table pair."
  (let ((result (make-pttpair)))
    (docolors (color)
      (setf (svref (pttpair-ttvec result) color) (new-pttbase my-log2n)))
    result))

(defun pttpair-reset (my-pttpair)
  "Reset the given pawn transposition table pair."
  (docolors (color)
    (pttbase-reset (svref (pttpair-ttvec my-pttpair) color)))
  (values))

(defun pttpair-dumpstats (my-pttpair)
  "Output labeled statistics for the given pttpair."
  (docolors (color)
    (pttbase-dumpstats (svref (pttpair-ttvec my-pttpair) color) color))
  (values))

(defun pttpair-probe (my-pttpair my-pos)
  "Return the matching entry for the given pawn transposition table pair and position; nil if not found."
  (pttbase-probe
    (svref (pttpair-ttvec my-pttpair) (pos-good my-pos))
    my-pos))

(defun pttpair-store (my-pttpair my-pos my-pawnst)
  "Store the position/result combination in the given pawn transposition table pair."
  (pttbase-store
    (svref (pttpair-ttvec my-pttpair) (pos-good my-pos))
    my-pos
    my-pawnst)
  (values))

;;; ---------- Structure csr

(defstruct
  (csr
    (:print-function meta-encode-csr))
  "A compact search result."
  (score neginf-score :type integer) ; The expectation
  (pv    nil))                       ; The predicted variation moves in playing order

(defun encode-csr (my-stream my-csr)
  "Encode a csr on the given stream."
  (format my-stream "~A" (csr-pv my-csr))
  (format my-stream "   Score: ")
  (encode-score my-stream (csr-score my-csr))
  (values))

(defun meta-encode-csr (my-csr my-stream my-level)
  "Glue to encode a csr structure."
  (declare (ignore my-level))
  (encode-csr my-stream my-csr)
  (values))

(defun csr->string (my-csr)
  "Encode a csr on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-csr str-stream my-csr)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun csr-load (my-csr my-pv my-score)
  "Load a csr with the given pv and score."
  (setf (csr-pv    my-csr) my-pv)
  (setf (csr-score my-csr) my-score)
  (values))

(defun csr-clamp (my-csr my-window)
  "Turn a fail-soft score into a fail-hard score."
  (let ((score (csr-score my-csr)))
    (cond
      ((< score (window-alfa my-window))
        (setf (csr-score my-csr) (window-alfa my-window)))
      ((> score (window-beta my-window))
        (setf (csr-score my-csr) (window-beta my-window)))
      (t
        nil)))
  (values))

;;; ---------- Structure analysis

(defstruct
  (analysis
    (:include csr)
    (:print-function meta-encode-analysis))
  "An anlysis; the result of a search."
  (fgpair    (make-fgpair) :type fgpair) ; The starting fmvn/good pair of the predicted variation
  (draft     0 :type fixnum)             ; Analysis search depth
  (nc        0 :type integer)            ; Analysis node count
  (tbpc      0 :type integer)            ; Tablebase probe count
  (usage     0 :type integer)            ; Millisecond CPU usage
  (sts       sts-unterminated))          ; Search terminatino status

(defun encode-analysis-pv (my-stream my-analysis)
  "Encode the predicted variation of an analysis on the given stream."
  (encode-fgpair-moves my-stream (analysis-fgpair my-analysis) (analysis-pv my-analysis)))

(defun analysis-pv->string (my-analysis-pv)
  "Encode an analysis predicted variation on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-analysis-pv str-stream my-analysis-pv)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

(defun encode-analysis (my-stream my-analysis)
  "Encode an analysis on the given stream."
  (format my-stream "[~A/~:D/~A/~:D/~:D]"
    (score->string (analysis-score my-analysis))
    (analysis-draft my-analysis)
    (format nil "~,3F" (/ (analysis-usage my-analysis) 1000.0))
    (analysis-nc my-analysis)
    (analysis-tbpc my-analysis))
  (when (analysis-pv my-analysis)
    (format my-stream " ~A" (analysis-pv->string my-analysis)))
  (values))

(defun meta-encode-analysis (my-analysis my-stream my-level)
  "Glue to encode an analysis structure."
  (declare (ignore my-level))
  (encode-analysis my-stream my-analysis)
  (values))

(defun analysis->string (my-analysis)
  "Encode an analysis on a string."
  (let ((result nil) (str-stream (make-string-output-stream)))
    (encode-analysis str-stream my-analysis)
    (setf result (get-output-stream-string str-stream))
    (close str-stream)
    result))

;;; ---------- Structure pir

(defstruct
  (pir)
  "A ply indexed record."
  (ttmove nil)  ; Transposition table move
  (k0move nil)  ; Most recent killer move
  (k1move nil)) ; Second most recent killer move

(defun new-pirvec ()
  "Return a new vector of ply indexed records."
  (let ((result (make-array ply-limit :initial-element nil)))
    (dotimes (index ply-limit)
      (setf (svref result index) (make-pir)))
    result))

(defun pir-bestmove (my-pir my-move)
  "Adjust the given ply indexed record for the best move after a move scan (move may be nil)."
  ;;
  ;; Adjust the killer moves
  ;;
  (when (and my-move (is-move-holder? my-move))
    (let ((k0move (pir-k0move my-pir)))
      (when (or (not k0move) (not (same-moves? k0move my-move)))
        (setf (pir-k1move my-pir) k0move)
        (setf (pir-k0move my-pir) my-move))))
  (values))

;;; ---------- Compact search result combination

(defun combine-node-desc-results (my-move my-node-csr my-desc-csr)
  "Combine the result of a subsearch into the current node's result."
  (let
    (
      (result  nil)
      (upscore (upshift-score (csr-score my-desc-csr)))
    )
    (when (> upscore (csr-score my-node-csr))
      (setf (csr-score my-node-csr) upscore)
      (setf (csr-pv my-node-csr) (append (list my-move) (csr-pv my-desc-csr)))
      (setf result t))
    result))

;;; ---------- Fractional depth measurement

(defconstant frac-depth-delta 256 "Depth delta per ply; provides for fractional depth measurement")

(defconstant frac-depth-delta/2 (floor frac-depth-delta 2))
(defconstant frac-depth-delta/4 (floor frac-depth-delta 4))
(defconstant frac-depth-delta/8 (floor frac-depth-delta 8))

;;; ---------- Structure scs

(defstruct
  (scs
    (:print-function meta-encode-scs))
  "A search context structure; used as a parameter to node searching routines"
  (ostream    t)                          ; Output stream; used for trace output
  (slim       (make-slim))                ; Search limiter
  (rootfgpair nil)                        ; The fmvn/good pair at the root of the search
  (rootmc     0 :type fixnum)             ; The move count at the root position
  (rootmoves  nil)                        ; The moves at the root of the search (super marked and sorted by SAN)
  (rootmvec   nil)                        ; The moves at the root of the search (vector, reordered during search)
  (rootpos    nil)                        ; The position at the root of the search (not modified during search)
  (stcu       (new-simpletimer-cu t))     ; Active simpletimer counting up; set once at search start
  (msec       0 :type integer)            ; Current elapsed milliseconds; copied from the count-up simpletimer
  (iteration  0 :type fixnum)             ; The current iteration; zero origin, incremented on completion
  (gttpair    (new-gttpair 16))           ; General transposition table pair
  (pttpair    (new-pttpair 12))           ; Pawn transposition table pair
  (pirvec     (new-pirvec))               ; Ply indexed record storage
  (pos        nil)                        ; The position at each node of the search (changed on execute/retract)
  (ply        0 :type fixnum)             ; The ply at each node of the search (incf/decf on execute/retract)
  (depth      0 :type fixnum)             ; The depth at each node of the search (decf/incf on execute/retract)
  (rcv        nil)                        ; The reversed current variation at each node of the search
  (ftdflag    t)                          ; First time down per iteration flag
  (nc         0 :type integer)            ; Node count (all nodes combined)
  (ncautoval  0 :type integer)            ; Node count (autoval nodes)
  (nccapture  0 :type integer)            ; Node count (capture nodes)
  (ncevasion  0 :type integer)            ; Node count (evasion nodes)
  (ncgeneral  0 :type integer)            ; Node count (general nodes)
  (ncplyzero  0 :type integer)            ; Node count (plyzero nodes)
  (ncterminal 0 :type integer)            ; Node count (terminal nodes)
  (ttprune0   0 :type integer)            ; Transposition table prunings: attempts
  (ttprune1   0 :type integer)            ; Transposition table prunings: matches
  (ttprune2   0 :type integer)            ; Transposition table prunings: sufficient draft
  (ttprune3   0 :type integer)            ; Transposition table prunings: successes
  (priorpv    nil)                        ; The predicted variation from the prior iteration; used for move ordering
  (priorscore broken-score :type integer) ; The predicted score from the prior iteration
  (lastpv     nil)                        ; The last recorded predicted variation; used as a result
  (lastscore  broken-score :type integer) ; The last recorded predicted score; used as a result
  (lastiter   0 :type fixnum)             ; Iteration when lastpv/lastscore is set; used in analysis result
  (lastmsec   0 :type integer)            ; Elapsed milliseconds when lastpv/lastscore is set; used in analysis result
  (lastnc     0 :type integer)            ; Node count when lastpv/lastscore is set; used in analysis result
  (prelflag   nil)                        ; Indicatation of preliminary scoring scan in progress
  (interrupt  nil)                        ; Set on interrupt; cleared on acknowledgment
  (abortflag  nil)                        ; Set on search abort event (interrupt or resource limit encountered)
  (sts        sts-unterminated))          ; Search termination status

(defun encode-scs (my-stream my-scs)
  "Encode a scs on a stream."
  (format my-stream "[ply:~D depth:~D]" (scs-ply my-scs) (scs-depth my-scs))
  (values))

(defun meta-encode-scs (my-scs my-stream my-level)
  "Glue to encode a scs structure."
  (declare (ignore my-level))
  (encode-scs my-stream my-scs)
  (values))

(defun new-scs (my-pos)
  "Return a new search context structure for the given search root position."
  (let ((moves (generate-super my-pos)))
    (make-scs
      :ostream    (acs-ostream *acs*)
      :slim       (slim-clone (acs-slim *acs*))
      :rootpos    my-pos
      :rootfgpair (pos->fgpair my-pos)
      :rootmc     (length moves)
      :rootmoves  moves
      :rootmvec   (movelist->movevector moves)
      :pos        (pos-clone my-pos))))

(defun scs-update-msec (my-scs)
  "Update the current elapsed milliseconds component in the given search context structure."
  (setf (scs-msec my-scs) (simpletimer->msec (scs-stcu my-scs)))
  (values))

(defun scs-notate-rcv (my-scs)
  "Apply notation marking to the reversed current variation; request may come at any ply."
  (movelist-notate-sequence (reverse (scs-rcv my-scs)) (scs-rootpos my-scs))
  (values))

(defun scs-set-last (my-scs my-pv my-score)
  "For the given scs, set a final result candidate from the given pv and score; always called at ply zero."
  ;;
  ;; Capture the main data for the final result candidate
  ;;
  (setf (scs-lastpv    my-scs) (movelist-clone my-pv))
  (setf (scs-lastscore my-scs) my-score)
  ;;
  ;; Capture other relevant data for the final result candidate
  ;;
  (setf (scs-lastiter  my-scs) (scs-iteration my-scs))
  (setf (scs-lastmsec  my-scs) (simpletimer->msec (scs-stcu my-scs)))
  (setf (scs-lastnc    my-scs) (scs-nc my-scs))
  ;;
  ;; Ensure that the final result candidate is fully notated
  ;;
  (movelist-notate-sequence (scs-lastpv my-scs) (scs-rootpos my-scs))
  (values))

(defun scs-best-csr (my-scs my-csr my-window)
  "Handle post-scan best compact search result processing at the current node."
  (let*
    (
      (pv    (csr-pv    my-csr))
      (score (csr-score my-csr))
      (move  (if pv (first pv) nil))
    )
    ;;
    ;; Handle the ply indexed record items
    ;;
    (when move
      (pir-bestmove (svref (scs-pirvec my-scs) (scs-ply my-scs)) move))
    ;;
    ;; Handle the general position transposition table items
    ;;
    (gttpair-store
      (scs-gttpair my-scs)
      (scs-pos my-scs)
      move
      score
      (score+window->tsv score my-window)
      (scs-depth my-scs)))
  (values))

(defun scs-probe-general-transposition-table (my-scs my-window)
  "Probe the general transposition table and return a compact search result on success, else nil."
  (let*
    (
      (result nil)
      (ply    (scs-ply my-scs))
      (pir    (svref (scs-pirvec my-scs) ply))
    )
    ;;
    ;; Set the default value for the transposition table move used for move ordering
    ;;
    (setf (pir-ttmove pir) nil)
    ;;
    ;; Skip processing at the root
    ;;
    (unless (zero? ply)
      ;;
      ;; Perform a probe
      ;;
      (let ((gttentry (gttpair-probe (scs-gttpair my-scs) (scs-pos my-scs))))
        (incf (scs-ttprune0 my-scs))
        ;;
        ;; Was a matching entry located?
        ;;
        (when gttentry
          (incf (scs-ttprune1 my-scs))
          ;;
          ;; Fetch the transposition move (if any) and store it in the current ply indexed record
          ;;
          (let*
            (
              (nemo (gttentry-nemo gttentry))
              (move (if (nonzero? nemo) (nemo->move nemo) nil))
            )
            (setf (pir-ttmove pir) move)
            ;;
            ;; Is the analysis draft of the matching entry sufficiently deep and are not at a PV node?
            ;;
            (when
              (and
                (>= (gttentry-draft gttentry) (scs-depth my-scs))
                (is-window-zero-width? my-window))
              (incf (scs-ttprune2 my-scs))
              (let*
                (
                  (score (gttentry-score gttentry))
                  (tsv   (gttentry-tsv   gttentry))
                  (pv    (if move (list move) nil))
                )
                ;;
                ;; Can the entry be used for pruning at the current node?
                ;;
                (when
                  (or
                    (and (= tsv tsv-lower) (>= score (window-beta my-window)))
                    (and (= tsv tsv-upper) (<= score (window-alfa my-window)))
                    (= tsv tsv-exact))
                  (incf (scs-ttprune3 my-scs))
                  ;;
                  ;; Generate a pruning compact search result
                  ;;
                  (setf result (make-csr :pv pv :score score)))))))))
    result))

;;; ---------- Trace output prefix formatting

(defun trace-prefix (my-scs my-label)
  "Emit a trace prefix label."
  (format (scs-ostream my-scs) "[~A] " my-label)
  (values))

;;; Search termination

(defmacro scs-is-search-going? (my-scs)
  "Determine if the search is going."
  `(= (scs-sts ,my-scs) sts-unterminated))

(defmacro scs-is-search-over? (my-scs)
  "Determine if the search is over."
  `(/= (scs-sts ,my-scs) sts-unterminated))

(defun scs-terminate-search (my-scs my-sts)
  "End the search and set the termination status; called once per search."
  ;;
  ;; Stop the timer and set the termination status
  ;;
  (simpletimer-stop (scs-stcu my-scs))
  (setf (scs-sts my-scs) my-sts)
  ;;
  ;; Handle search termination trace
  ;;
  (when (is-gf-set? acof-trst)
    (let ((ostream (scs-ostream my-scs)))
      (trace-prefix my-scs "st")
      (format ostream "~A   Elapsed: ~A~%"
        (sts->string my-sts)
        (simpletimer->string (scs-stcu my-scs)))))
  (values))

(defun scs-set-last-and-terminate-search (my-scs my-pv my-score my-sts)
  "Set the final compact search result and terminate the search."
  (scs-set-last my-scs my-pv my-score)
  (scs-terminate-search my-scs my-sts)
  (values))

;;; Search abort handling

(defun scs-abort-search (my-scs my-sts)
  "Abort the search and set the termination status; interrupt or resource limit encountered."
  (setf (scs-abortflag my-scs) t)
  (scs-terminate-search my-scs my-sts)
  (values))

;;; Search statistics summary report

(defun scs-report-statistics (my-scs)
  "Produce a statistics report summary of a search."
  (let ((ostream (acs-ostream *acs*)))
    (format ostream "Search statistics summary report at ~A~%" (current-ltz->string))
    ;;
    (format ostream "  Input parameters:~%")
    (format ostream "    Position: ~A~%" (scs-rootpos my-scs))
    (format ostream "    Moves (~R):~%" (scs-rootmc my-scs))
    (format ostream "      ~A~%" (scs-rootmoves my-scs))
    (format ostream "    Search limits:~%")
    (format ostream "      ~A~%" (scs-slim my-scs))
    ;;
    (format ostream "  Analysis:~%")
    (format ostream "    PV: ~A~%" (fgpair+moves->string (scs-rootfgpair my-scs) (scs-lastpv my-scs)))
    (format ostream "    Expectation: ~A~%" (score->string (scs-lastscore my-scs)))
    (format ostream "    Draft: ~:D ply   Node count: ~:D   Time: ~A~%"
      (1+ (scs-lastiter my-scs))
      (scs-lastnc my-scs)
      (msec->string (scs-lastmsec my-scs)))
    (format ostream "    Frequency: ~A   Period: ~A~%"
      (if (nonzero? (scs-lastmsec my-scs))
        (frequency->string (/ (scs-lastnc my-scs) (/ (scs-lastmsec my-scs) 1000.0)))
        "-")
      (if (nonzero? (scs-lastnc my-scs))
        (time->string (/ (/ (scs-lastmsec my-scs) 1000.0) (scs-lastnc my-scs)))
        "-"))
    (format ostream "    Termination status: ~A~%" (sts->string (scs-sts my-scs)))
    ;;
    (format ostream "  Node counts:~%")
    (format ostream "    Total: ~:D   Interior: ~:D   Terminal: ~:D~%"
      (scs-nc my-scs)
      (- (scs-nc my-scs) (scs-ncterminal my-scs))
      (scs-ncterminal my-scs))
    (format ostream "    AutoVal: ~:D   Capture: ~:D   Evasion: ~:D   General: ~:D   PlyZero: ~:D~%"
      (scs-ncautoval my-scs)
      (scs-nccapture my-scs)
      (scs-ncevasion my-scs)
      (scs-ncgeneral my-scs)
      (scs-ncplyzero my-scs))
    ;;
    (format ostream "  Total timing statistics:~%")
    (format ostream "    Elapsed: ~A   Frequency: ~A   Period: ~A~%"
      (scs-stcu my-scs)
      (if (nonzero? (scs-msec my-scs))
        (frequency->string (/ (scs-nc my-scs) (/ (scs-msec my-scs) 1000.0)))
        "-")
      (if (nonzero? (scs-nc my-scs))
        (time->string (/ (/ (scs-msec my-scs) 1000.0) (scs-nc my-scs)))
        "-"))
    ;;
    (format ostream "  Transposition pruning counts:~%")
    (format ostream "    Attempted: ~:D   Matched: ~:D   Sufficient draft: ~:D   Pruned: ~:D~%"
      (scs-ttprune0 my-scs)
      (scs-ttprune1 my-scs)
      (scs-ttprune2 my-scs)
      (scs-ttprune3 my-scs))
    ;;
    (format ostream "  Transposition table statistics (general position tables by color):~%")
    (gttpair-dumpstats (scs-gttpair my-scs))
    ;;
    (format ostream "  Transposition table statistics (pawn structure tables by color):~%")
    (pttpair-dumpstats (scs-pttpair my-scs)))
  (values))

;;; Map a search context structure result into an analysis

(defun scs->analysis (my-scs)
  "Return a new analysis structure from the given scs; called once after a search is terminated."
  (make-analysis
    :draft  (1+ (scs-lastiter my-scs))
    :fgpair (scs-rootfgpair my-scs)
    :nc     (scs-lastnc my-scs)
    :pv     (scs-lastpv my-scs)
    :score  (scs-lastscore my-scs)
    :sts    (scs-sts my-scs)
    :usage  (scs-lastmsec my-scs)))

;;; Move exection and retraction

(defun scs-execute (my-scs my-move)
  "For the given search context structure, execute the indicated move."
  (push my-move (scs-rcv my-scs))
  (incf (scs-ply my-scs))
  (decf (scs-depth my-scs) frac-depth-delta)
  (pos-execute (scs-pos my-scs) my-move)
  (values))

(defun scs-retract (my-scs)
  "For the given search context structure, retract the last played move."
  (pos-retract (scs-pos my-scs))
  (decf (scs-ply my-scs))
  (incf (scs-depth my-scs) frac-depth-delta)
  (pop (scs-rcv my-scs))
  (values))

;;; ---------- Predicted move and variation access

(defun scs-rotate-to-front (my-scs my-move)
  "Rotate the matching move in the root move vector to the zero index of the vector."
  (let*
    (
      (mvec  (scs-rootmvec my-scs))
      (index (movevector-locate-move-index-no-fail mvec my-move))
    )
    (when (nonzero? index)
      (let ((move (svref mvec index)))
        (dotimes (swapdex index)
          (setf (svref mvec (- index swapdex)) (svref mvec (1- (- index swapdex)))))
        (setf (svref mvec 0) move))))
  (values))

;;; ---------- Search variation trace routines

(defun scs-trace-pv (my-scs)
  "Emit a trace of the indicated predicted variation; assume the PV is already notated."
  (let ((ostream (scs-ostream my-scs)))
    (trace-prefix my-scs "pv")
    (format ostream "~A   score: ~A~%"
      (fgpair+moves->string (scs-rootfgpair my-scs) (scs-lastpv my-scs))
      (score->string (scs-lastscore my-scs)))
    (finish-output ostream))
  (values))

(defun scs-trace-rcv (my-scs my-label)
  "Emit a trace of the reversed current variation; may be called at any ply."
  (let ((ostream (scs-ostream my-scs)))
    (scs-notate-rcv my-scs)
    (trace-prefix my-scs my-label)
    (format ostream "~A~%" (fgpair+moves->string (scs-rootfgpair my-scs) (reverse (scs-rcv my-scs))))
    (finish-output ostream))
  (values))

;;; ----------  The grand minimaxer

(defun scs-minimaxer (my-scs my-window my-move my-node-csr my-desc-csr)
  "Do minimax given the scs, the search window, the searched move, the node csr, and the descendent csr."
  (declare (ignore my-scs))
  (let
    (
      (result  nil)
      (upscore (upshift-score (csr-score my-desc-csr)))
    )
    ;;
    ;; Is the upshifted descendent score better than the current score at the node?
    ;;
    (when (> upscore (csr-score my-node-csr))
      ;;
      ;; Not fail-low; a new best score has been found, so update the node csr score and the window lower bound
      ;;
      (setf (csr-score my-node-csr) upscore)
      (setf (window-alfa my-window) upscore)
      ;;
      ;; If the new score is too good then set a single move PV else set a new PV with the played move and sub-PV
      ;;
      (if (>= upscore (window-beta my-window))
        ;;
        ;; Fail-high
        ;;
        (setf (csr-pv my-node-csr) (list my-move))
        ;;
        ;; Neither fail-low nor fail-high; PV score detected
        ;;
        (setf (csr-pv my-node-csr) (append (list my-move) (csr-pv my-desc-csr))))
      ;;
      ;; Set result flag indicating a new best score and move
      ;;
      (setf result t))
    result))

;;; ---------- Structure bucket

(defconstant bpm-capture 0 "Bucket pick mode: capture node")
(defconstant bpm-evasion 1 "Bucket pick mode: evasion node")
(defconstant bpm-general 2 "Bucket pick mode: general node")
(defconstant bpm-plyzero 3 "Bucket pick mode: plyzero node")

(defconstant bpm-limit (1+ bpm-plyzero))

(defstruct
  (bucket)
  "A bucket used for picking a move to be searched."
  (bpm  nil)             ; Bucket pick mode; set once at initialization
  (mvec nil)             ; A move vector with the generated moves; set once at initialization
  (mc   0 :type fixnum)  ; The move count for the move vector; set once at initialization
  (uc   0 :type fixnum)) ; The unpick count for the move vector

(defun new-bucket (my-scs my-bpm)
  "Initialize and return a new move pick bucket."
  (let*
    (
      (result (make-bucket :bpm my-bpm))
      (ply    (scs-ply my-scs))
      (pir    (svref (scs-pirvec my-scs) ply))
      (pos    (scs-pos my-scs))
      (mvec   nil))
    ;;
    ;; Generate and order moves based on the bucket pick mode
    ;;
    (cond
      ((= my-bpm bpm-capture)
        (let ((moves (generate-gainers pos)))
          (when (positive? (length moves))
            (setf moves (movelist-setflags-checks moves pos)))
          (setf mvec (movelist->movevector moves)))
        (movevector-assign-order-better-est-gain mvec pos))
      ((= my-bpm bpm-evasion)
        (setf mvec (movelist->movevector (generate-evasion pos)))
        (movevector-assign-order-better-est-gain mvec pos))
      ((= my-bpm bpm-general)
        (setf mvec (movelist->movevector (generate pos)))
        (movevector-assign-order-better-est-gain mvec pos))
      ((= my-bpm bpm-plyzero)
        (setf mvec (movevector-clone (scs-rootmvec my-scs))))
      (t
        (error "new-bucket: bad bpm: ~S" my-bpm)))
    ;;
    ;; Initialize the generated move data for the bucket
    ;;
    (setf (bucket-mvec result) mvec)
    (setf (bucket-mc   result) (length mvec))
    (setf (bucket-uc   result) (bucket-mc result))
    ;;
    ;; Handle special moves, but not at ply zero
    ;;
    (unless (= my-bpm bpm-plyzero)
      ;;
      ;; If the predicted variation move is present, adjust its move order value
      ;;
      (let ((pvmove (if (scs-ftdflag my-scs) (nth ply (scs-priorpv my-scs)))))
        (when pvmove
          (let ((move (movevector-locate-move mvec pvmove)))
            (when move
              (incf (move-order move) (* 4 value-queen))))))
      ;;
      ;; If the transposition table move is present, adjust its move order value
      ;;
      (let ((ttmove (pir-ttmove pir)))
        (when ttmove
          (let ((move (movevector-locate-move mvec ttmove)))
            (when move
              (incf (move-order move) (* 3 value-queen))))))
      ;;
      ;; If the killer 0 move is present, adjust its move order value
      ;;
      (let ((k0move (pir-k0move pir)))
        (when k0move
          (let ((move (movevector-locate-move mvec k0move)))
            (when move
              (incf (move-order move) value-pawn)))))
      ;;
      ;; If the killer 1 move is present, adjust its move order value
      ;;
      (let ((k1move (pir-k1move pir)))
        (when k1move
          (let ((move (movevector-locate-move mvec k1move)))
            (when move
              (incf (move-order move) (2/ value-pawn)))))))
    result))

(defmacro bucket-has-moves? (my-bucket)
  "Determine if there are unpicked moves in the given bucket."
  `(positive? (bucket-uc ,my-bucket)))

(defun bucket-select-next (my-bucket)
  "Select the next unsearched move in the given bucket; at least one should be present."
  (let ((result (svref (bucket-mvec my-bucket) (- (bucket-mc my-bucket) (bucket-uc my-bucket)))))
    result))

(defun bucket-select-best (my-bucket)
  "Select the best unsearched move in the given bucket; at least one should be present."
  (let ((result (movevector-pick-best-unsearched-move (bucket-mvec my-bucket))))
    result))

(defun bucket-pick (my-bucket)
  "Pick an unsearched move in the given bucket."
  (let ((result nil))
    (when (bucket-has-moves? my-bucket)
      (if (= (bucket-bpm my-bucket) bpm-plyzero)
        (setf result (bucket-select-next my-bucket))
        (setf result (bucket-select-best my-bucket)))
      (move-set-flag result mf-srch)
      (decf (bucket-uc my-bucket)))
    result))

;;; ---------- Structure player

(defstruct
  (player)
  "A game context structure; one instance per game."
  (name     "Unknown player")  ; Name of the player
  (selector nil))              ; Function used to access player move selection

(defun new-player (my-name my-selector)
  "Return a new, initialized player structure."
  (make-player
    :name     my-name
    :selector my-selector))

;;; ---------- Structure gcs

(defstruct
  (gcs)
  "A game context structure; one instance per game."
  (game       nil)  ; The game object for the game
  (playervec  nil)  ; Color indexed vector of player structures
  (chessclock nil)  ; The chessclock for the game
  (stcu       nil)) ; Active simpletimer counting up; set once at context creation

(defun new-gcs (my-white-player my-black-player)
  "Return a new gcs object."
  (make-gcs
    :game       (make-game)
    :playervec  (vector my-white-player my-black-player)
    :chessclock (make-chessclock)
    :stcu       (new-simpletimer-cu t)))

;;; ---------- The simpleton positional evaluator; inspired by the report on Chess 4.x by Slate and Atkin

(defun simpleton-evaluate (my-scs)
  "Return a evaluation score for the current position."
  (let*
    (
      (result   nil)
      (scorevec (make-array color-rlimit :initial-element even-score))
      (pos      (scs-pos my-scs))
      (good     (pos-good pos))
      (evil     (pos-evil pos))
      (cens     (pos-cens pos))
      (ksqv     (pos-ksqv pos))
      (bbdb     (pos-bbdb pos))
      (rmtv     (pos-rmtv pos))
      (pmbb     (pos-pmbb pos))
      (locbc    (bbdb-locbc bbdb))
      (locbm    (bbdb-locbm bbdb))
      (atkbc    (bbdb-atkbc bbdb))
      (atkfs    (bbdb-atkfs bbdb))
      (ccvec    (census-ccvec cens))
      (pawnst   nil)
    )
    ;;
    ;; Pawn structure probe
    ;;
    (let ((pttentry (pttpair-probe (scs-pttpair my-scs) pos)))
      ;;
      ;; Copy on match; else generate and store
      ;;
      (if pttentry
        (setf pawnst (pttentry-pawnst pttentry))
        (progn
          (setf pawnst (pawnst-build pos))
          (pttpair-store (scs-pttpair my-scs) pos pawnst))))
    ;;
    ;; Raw material balance
    ;;
    (docolors (color)
      (incf (svref scorevec color) (svref rmtv color)))
    ;;
    ;; Piece type: Pawns
    ;;
    (docolors (color)
      ;;
      ;; Pawns only scoring
      ;;
      (incf (svref scorevec color) (svref (pawnst-scorevec pawnst) color))
      ;;
      ;; Pawn/piece relationship scoring
      ;;
      (let*
        (
          (pawn  (color->pawn color))
          (bb    (bb-clone (svref locbm pawn)))
          (other (other-color color))
        )
        (bb-scan (bb sq)
          ;;
          ;; Passed pawn scoring
          ;;
          (when (bb-sq-set? (pawnst-passbb pawnst) sq)
            (let
              (
                (nextsq (color+sq->pawn-nextsq color sq))
                (bonus  23)
              )
              (when (bb-sq-set? (svref atkbc color) nextsq)
                (incf bonus  3))
              (when (bb-sq-set? (svref atkbc other) nextsq)
                (incf bonus -4))
              (when (bb-sq-set? (svref locbc other) nextsq)
                (incf bonus -7))
              (incf (svref scorevec color) (* bonus (color+sq->pawn-s2bc color sq))))))))
    ;;
    ;; Piece type: Knights
    ;;
    (docolors (color)
      (let*
        (
          (knight (color->knight color))
          (bb     (bb-clone (svref locbm knight)))
          (other  (other-color color))
        )
        (bb-scan (bb sq)
          ;;
          ;; Development
          ;;
          (when (bb-sq-set? rim-bb sq)
            (incf (svref scorevec color) -94))
          ;;
          ;; Other king tropism
          ;;
          (incf (svref scorevec color) (* (calc-taxicab-distance sq (svref ksqv other)) -16))
          ;;
          ;; Mobility
          ;;
          (unless (bb-sq-set? pmbb sq)
            (incf (svref scorevec color) (* (svref knight-mobility-vec sq) 40))))))
    ;;
    ;; Piece type: Bishops
    ;;
    (docolors (color)
      (let*
        (
          (bishop (color->bishop color))
          (bb     (bb-clone (svref locbm bishop)))
        )
        (bb-scan (bb sq)
          ;;
          ;; Development
          ;;
          (when (bb-sq-set? rim-bb sq)
            (incf (svref scorevec color) -110))
          ;;
          ;; Mobility
          ;;
          (unless (bb-sq-set? pmbb sq)
            (incf (svref scorevec color) (* (bb-card (svref atkfs sq)) 24))))))
    ;;
    ;; Piece type: Rooks
    ;;
    (docolors (color)
      (let*
        (
          (rook  (color->rook color))
          (bb    (bb-clone (svref locbm rook)))
          (other (other-color color))
        )
        (bb-scan (bb sq)
          ;;
          ;; Other king tropism
          ;;
          (incf (svref scorevec color) (* (calc-mintaxi-distance sq (svref ksqv other)) -16))
          ;;
          ;; File scoring
          ;;
          (let ((file (sq->file sq)) (pcbcfvec (pawnst-pcbcfvec pawnst)))
            (when (zero? (aref pcbcfvec color file))
              (if (zero? (aref pcbcfvec other file))
                (incf (svref scorevec color) 80)
                (incf (svref scorevec color) 30))))
          ;;
          ;; Connected rooks
          ;;
          (incf (svref scorevec color) (* (bb-card (bb-and2 (svref locbm rook) (svref atkfs sq))) 80))
          ;;
          ;; Mobility
          ;;
          (unless (bb-sq-set? pmbb sq)
            (incf (svref scorevec color) (* (bb-card (svref atkfs sq)) 16))))))
    ;;
    ;; Piece type: Queens
    ;;
    (docolors (color)
      (let*
        (
          (queen (color->queen color))
          (bb    (bb-clone (svref locbm queen)))
          (other (other-color color))
        )
        (bb-scan (bb sq)
          ;;
          ;; Other king tropism
          ;;
          (incf (svref scorevec color) (* (calc-mintaxi-distance sq (svref ksqv other)) -8))
          ;;
          ;; Mobility
          ;;
          (unless (bb-sq-set? pmbb sq)
            (incf (svref scorevec color) (* (bb-card (svref atkfs sq)) 8))))))
    ;;
    ;; Piece type: Kings
    ;;
    (docolors (color)
      (let*
        (
          (king  (color->king color))
          (bb    (bb-clone (svref locbm king)))
          (other (other-color color))
        )
        (bb-scan (bb sq)
          ;;
          ;; Lone king center distance penalty
          ;;
          (when (one? (svref ccvec color))
            (incf (svref scorevec color) (* (svref center-centisquare-distance-vec sq) -1)))
          ;;
          ;; King to lone king tropism
          ;;
          (when (one? (svref ccvec other))
            (incf (svref scorevec color) (* (calc-maxtaxi-distance sq (svref ksqv other)) -60))))))
    ;;
    ;; Set the final result accoring to good/evil colors
    ;;
    (setf result (- (svref scorevec good) (svref scorevec evil)))
    ;;
    result))

;;; ----------  The simpleton search recursion routine

(defun simpleton-recurse (my-scs my-window my-move)
  "Recursively call the simpleton node gateway; return a csr structure."
  (let ((result nil))
    (scs-execute my-scs my-move)
    (setf result (simpleton-node my-scs (downshift-window my-window)))
    (scs-retract my-scs)
    result))

;;; ----------  The simpleton search node processors (traditional A/B move selection)

(defun simpleton-node-capture (my-scs my-window)
  "Simpleton search node procesor for depth <= 0, not in check, capture search; return a csr."
  (let
    (
      (result     (make-csr :score (window-alfa my-window)))
      (window     (window-clone my-window))
      (save-depth (scs-depth my-scs))
      (bucket     (new-bucket my-scs bpm-capture))
      (basescore  (simpleton-evaluate my-scs))
      (trycount   0)
    )
    ;;
    ;; Bump the capture node count
    ;;
    (incf (scs-nccapture my-scs))
    ;;
    ;; Conditionally update the current window using the stand-pat base score
    ;;
    (when (> basescore (window-alfa window))
      (setf (csr-score result) basescore)
      (setf (window-alfa window) basescore))
    ;;
    ;; Move scanning loop
    ;;
    (dowhile
      (and
        (scs-is-search-going? my-scs)
        (not (is-window-cutoff? window))
        (bucket-has-moves? bucket))
      (let
        (
          (desc-csr nil)
          (move     (bucket-pick bucket))
        )
        ;;
        ;; Futility check
        ;;
        (when
          (or
            (is-move-marked-check? move)
            (> (+ basescore (move-simple-est-gain move)) (window-alfa window)))
          ;;
          ;; Recursion
          ;;
          (setf desc-csr (simpleton-recurse my-scs window move))
          ;;
          ;; Perform the A/B minimax including some side-effects
          ;;
          (unless (scs-abortflag my-scs)
            (scs-minimaxer my-scs window move result desc-csr)))
        ;;
        ;; Increment the count of tried moves
        ;;
        (incf trycount)))
    ;;
    ;; Depth restoration
    ;;
    (setf (scs-depth my-scs) save-depth)
    ;;
    ;; No mate detection as only gainer moves were generated
    ;;
    result))

(defun simpleton-node-evasion (my-scs my-window)
  "Simpleton search node procesor for check evasion at ply > 0, full width; return a csr."
  (let*
    (
      (result     (make-csr :score (window-alfa my-window)))
      (window     (window-clone my-window))
      (ispvnode   (not (is-window-zero-width? my-window)))
      (dopvflag   ispvnode)
      (save-depth (scs-depth my-scs))
      (bucket     (new-bucket my-scs bpm-evasion))
      (mc         (bucket-mc bucket))
      (trycount   0)
    )
    ;;
    ;; Bump the evasion node count
    ;;
    (incf (scs-ncevasion my-scs))
    ;;
    ;; Depth extension for basic evasion
    ;;
    (incf (scs-depth my-scs) frac-depth-delta)
    ;;
    ;; Depth extension for limited reply count
    ;;
    (when (< mc 3)
      (cond
        ((= mc 1)
          (incf (scs-depth my-scs) frac-depth-delta/2))
        ((= mc 2)
          (incf (scs-depth my-scs) frac-depth-delta/4))
        (t
          nil)))
    ;;
    ;; Move scanning loop
    ;;
    (dowhile
      (and
        (scs-is-search-going? my-scs)
        (not (is-window-cutoff? window))
        (bucket-has-moves? bucket))
      (let
        (
          (desc-csr nil)
          (move     (bucket-pick bucket))
        )
        ;;
        ;; Recursion
        ;;
        (if dopvflag
          (setf desc-csr (simpleton-recurse my-scs window move))
          (progn
            (setf desc-csr (simpleton-recurse my-scs (window->zw window) move))
            (unless (scs-abortflag my-scs)
              (when (and ispvnode (> (upshift-score (csr-score desc-csr)) (window-alfa window)))
                (setf desc-csr (simpleton-recurse my-scs window move))))))
        ;;
        ;; Perform the A/B minimax including some side-effects
        ;;
        (unless (scs-abortflag my-scs)
          (scs-minimaxer my-scs window move result desc-csr))
        ;;
        ;; Ensure that the PV window search flag is reset
        ;;
        (setf dopvflag nil)
        ;;
        ;; Increment the count of tried moves
        ;;
        (incf trycount)))
    ;;
    ;; Depth restoration
    ;;
    (setf (scs-depth my-scs) save-depth)
    ;;
    ;; Checkmate detection
    ;;
    (unless (scs-abortflag my-scs)
      (when (zero? mc)
        (csr-load result nil checkmated-score)))
    result))

(defun simpleton-node-general (my-scs my-window)
  "Simpleton search node procesor for ply > 0, depth > 0, not in check, full width; return a csr."
  (let*
    (
      (result     (make-csr :score (window-alfa my-window)))
      (window     (window-clone my-window))
      (ispvnode   (not (is-window-zero-width? my-window)))
      (dopvflag   ispvnode)
      (save-depth (scs-depth my-scs))
      (bucket     (new-bucket my-scs bpm-general))
      (mc         (bucket-mc bucket))
      (trycount   0)
    )
    ;;
    ;; Bump the general node count
    ;;
    (incf (scs-ncgeneral my-scs))
    ;;
    ;; Depth extension for limited reply count
    ;;
    (when (< mc 3)
      (cond
        ((= mc 1)
          (incf (scs-depth my-scs) frac-depth-delta/2))
        ((= mc 2)
          (incf (scs-depth my-scs) frac-depth-delta/4))
        (t
          nil)))
    ;;
    ;; Move scanning loop
    ;;
    (dowhile
      (and
        (scs-is-search-going? my-scs)
        (not (is-window-cutoff? window))
        (bucket-has-moves? bucket))
      (let
        (
          (desc-csr nil)
          (move     (bucket-pick bucket))
        )
        ;;
        ;; Recursion
        ;;
        (if dopvflag
          (setf desc-csr (simpleton-recurse my-scs window move))
          (progn
            (setf desc-csr (simpleton-recurse my-scs (window->zw window) move))
            (unless (scs-abortflag my-scs)
              (when (and ispvnode (> (upshift-score (csr-score desc-csr)) (window-alfa window)))
                (setf desc-csr (simpleton-recurse my-scs window move))))))
        ;;
        ;; Perform the A/B minimax including some side-effects
        ;;
        (unless (scs-abortflag my-scs)
          (scs-minimaxer my-scs window move result desc-csr))
        ;;
        ;; Ensure that the PV window search flag is reset
        ;;
        (setf dopvflag nil)
        ;;
        ;; Increment the count of tried moves
        ;;
        (incf trycount)))
    ;;
    ;; Depth restoration
    ;;
    (setf (scs-depth my-scs) save-depth)
    ;;
    ;; Stalemate detection
    ;;
    (unless (scs-abortflag my-scs)
      (when (zero? mc)
        (csr-load result nil draw-score)))
    result))

(defun simpleton-node-plyzero (my-scs my-window)
  "Simpleton search node procesor for ply zero; return a csr."
  (let*
    (
      (result     (make-csr :score (window-alfa my-window)))
      (window     (window-clone my-window))
      (ispvnode   (not (is-window-zero-width? my-window)))
      (dopvflag   ispvnode)
      (save-depth (scs-depth my-scs))
      (prelflag   (scs-prelflag my-scs))
      (bucket     (new-bucket my-scs bpm-plyzero))
      (mc         (bucket-mc bucket))
      (ostream    (scs-ostream my-scs))
      (trycount   0)
    )
    ;;
    ;; Bump the plyzero node count
    ;;
    (incf (scs-ncplyzero my-scs))
    ;;
    ;; Move scanning loop
    ;;
    (dowhile
      (and
        (scs-is-search-going? my-scs)
        (not (is-window-cutoff? window))
        (bucket-has-moves? bucket))
      (let*
        (
          (desc-csr nil)
          (move     (bucket-pick bucket))
          (rootmove (locate-move-no-fail (scs-rootmoves my-scs) move))
        )
        ;;
        ;; Ply zero trace
        ;;
        (when (is-gf-set? acof-trpz)
          (trace-prefix my-scs "pz")
          (format ostream "Trying ~A~%" rootmove))
        ;;
        ;; Either certainty or recursion
        ;;
        (if (is-move-marked-certain? move)
          ;;
          ;; Move has a certain score; assign downshifted version for the later combine/upshift
          ;;
          (setf desc-csr (make-csr :score (downshift-score (move-score move))))
          ;;
          ;; Move does not have a certain score; perform a recursive search instead
          ;;
          (if (or dopvflag prelflag)
            (setf desc-csr (simpleton-recurse my-scs window move))
            (progn
              (setf desc-csr (simpleton-recurse my-scs (window->zw window) move))
              (unless (scs-abortflag my-scs)
                (when (and ispvnode (> (upshift-score (csr-score desc-csr)) (window-alfa window)))
                  (setf desc-csr (simpleton-recurse my-scs window move)))))))
        ;;
        ;; Perform the A/B minimax including some side-effects
        ;;
        (unless (scs-abortflag my-scs)
          (when (scs-minimaxer my-scs window move result desc-csr)
            ;;
            ;; Save the ply zero predicted variation and predicted score
            ;;
            (scs-set-last my-scs (csr-pv result) (csr-score result))
            ;;
            ;; Handle the predicted variation trace
            ;;
            (when (is-gf-set? acof-trpv)
              (scs-trace-pv my-scs))
            ;;
            ;; Move the best move so far to the front of the root move vector for the next iteration
            ;;
            (scs-rotate-to-front my-scs move)))
        ;;
        ;; Some special processing for the preliminary score scan
        ;;
        (when prelflag
          ;;
          ;; Set the move score and order; reset the search window bounds to full
          ;;
          (let ((rootmovescore (upshift-score (csr-score desc-csr))))
            (setf (move-score rootmove) rootmovescore)
            (setf (move-order rootmove) rootmovescore)
            (window-reset window)
            ;;
            ;; Handle preliminary score trace
            ;;
            (when (is-gf-set? acof-trps)
              (trace-prefix my-scs "ps")
              (format ostream "Move: ~A   score: ~A~%"
                rootmove
                (score->string rootmovescore)))))
        ;;
        ;; Ensure that the PV window search flag is reset
        ;;
        (setf dopvflag nil)
        ;;
        ;; Check for a sufficiently fast mate that allows an early exit from the search
        ;;
        (when
          (and
            (scs-is-search-going? my-scs)
            (not prelflag)
            (is-score-mating? (scs-lastscore my-scs))
            (<= (calc-mate-distance (scs-lastscore my-scs)) (1+ (scs-iteration my-scs))))
          (scs-terminate-search my-scs sts-certain-mate))
        ;;
        ;; Increment the count of tried moves
        ;;
        (incf trycount)))
    ;;
    ;; Depth restoration
    ;;
    (setf (scs-depth my-scs) save-depth)
    ;;
    ;; Mate detection
    ;;
    (unless (scs-abortflag my-scs)
      (when (zero? mc)
        (csr-load result nil (if (pos-inch (scs-pos my-scs)) checkmated-score draw-score))
        (scs-set-last my-scs (csr-pv result) (csr-score result))))
    ;;
    ;; Root node result is also in the scs lastpv/lastscore components
    ;;
    result))

;;; ----------  The simpleton search node gateway

(defun simpleton-node (my-scs my-window)
  "Simpleton search node procesor all nodes; invoke specialized node processor and return a csr."
  (let*
    (
      (result   nil)
      (depth    (scs-depth  my-scs))
      (nc       (scs-nc     my-scs))
      (ply      (scs-ply    my-scs))
      (pos      (scs-pos    my-scs))
      (ply0flag (zero? ply))
      (repcount (pos-count-past-occurances pos 2))
      (save-nc  (scs-nc my-scs))
    )
    ;;
    ;; Timing update
    ;;
    (scs-update-msec my-scs)
    ;;
    ;; Input polling
    ;;
    (unless (scs-interrupt my-scs)
      (when (listen)
        (setf (scs-interrupt my-scs) t)))
    ;;
    ;; If a PV has been set and not running the preliminary score scan, check possible search abort conditions
    ;;
    (when (and (scs-lastpv my-scs) (not (scs-prelflag my-scs)))
      (let ((sts nil) (slim (scs-slim my-scs)))
        ;;
        ;; Abort condition 1 of 3: interrupt
        ;;
        (unless sts
          (when (scs-interrupt my-scs)
            (setf sts sts-interrupt)))
        ;;
        ;; Abort condition 2 of 3: node count limit
        ;;
        (unless sts
          (let ((nc-limit (slim-nc slim)))
            (when (and nc-limit (>= nc nc-limit))
              (setf sts sts-rl-nc))))
        ;;
        ;; Abort condition 3 of 3: time limit
        ;;
        (unless sts
          (let ((msec-limit (slim-msec slim)))
            (when (and msec-limit (>= (scs-msec my-scs) msec-limit))
              (setf sts sts-rl-time))))
        ;;
        ;; Conditionally abort the search with a broken score for this node
        ;;
        (when sts
          (setf result (make-csr :score broken-score))
          (scs-abort-search my-scs sts))))
    ;;
    ;; Continue if the search is still active
    ;;
    (when (scs-is-search-going? my-scs)
      ;;
      ;; Bump the node count
      ;;
      (incf (scs-nc my-scs))
      ;;
      ;; Handle trace of the first time down variation
      ;;
      (when (and (scs-ftdflag my-scs) (is-gf-set? acof-trfv))
        (scs-trace-rcv my-scs "fv"))
      ;;
      ;; Handle trace of the current variation
      ;;
      (when (is-gf-set? acof-trcv)
        (scs-trace-rcv my-scs "cv"))
      ;;
      ;; Score cannot be improved?
      ;;
      (unless result
        (when (>= (window-alfa my-window) mate-in-1-score)
          (setf result (make-csr :score (window-alfa my-window)))))
      ;;
      ;; Ply overflow check (rather unlikely)
      ;;
      (unless result
        (when (= ply ply-limit)
          (setf result (make-csr :score (simpleton-evaluate my-scs)))))
      ;;
      ;; Deep repetition detection
      ;;
      (unless result
        (when (and (> ply 2) (positive? repcount))
          (setf result (make-csr :score draw-score))))
      ;;
      ;; Draw detection: fifty moves / insufficient material / repetition
      ;;
      (unless result
        (when
          (and
            (not ply0flag)
            (or (pos-is-draw-fiftymoves? pos) (pos-is-draw-insufficient? pos) (> repcount 1)))
          (setf result (make-csr :score draw-score))))
      ;;
      ;; Transposition table probe
      ;;
      (unless result
        (let ((trans-csr (scs-probe-general-transposition-table my-scs my-window)))
          (when trans-csr
            (setf result trans-csr))))
      ;;
      ;; Either an auto value result or a node analyzer dispatch
      ;;
      (if result
        ;;
        ;; Result present and auto value assigned; no need for a search
        ;;
        (progn
          (incf (scs-ncautoval my-scs))
          (csr-clamp result my-window))
        ;;
        ;; No result yet; dispatch to one of the four specialized node processors according to conditions
        ;;
        (progn
          (cond
            (ply0flag
              (setf result (simpleton-node-plyzero my-scs my-window)))
            ((pos-inch pos)
              (setf result (simpleton-node-evasion my-scs my-window)))
            ((nonpositive? depth)
              (setf result (simpleton-node-capture my-scs my-window)))
            (t
              (setf result (simpleton-node-general my-scs my-window))))
          ;;
          ;; Post-scan result processing; includes a possible store of a transposition table entry
          ;;
          (unless (scs-abortflag my-scs)
            ;;
            ;; Clamp
            ;;
            (csr-clamp result my-window)
            ;;
            ;; Set the best compact search result for the sub-search
            ;;
            (scs-best-csr my-scs result my-window)))))
    ;;
    ;; Clear the first time down flag
    ;;
    (setf (scs-ftdflag my-scs) nil)
    ;;
    ;; Terminal node counting
    ;;
    (when (= (1- (scs-nc my-scs)) save-nc)
      (incf (scs-ncterminal my-scs)))
    ;;
    ;;
    ;; The result is ignored when returning from the root node; root node result is in scs lastpv/lastscore
    ;;
    result))

;;; ----------  The simpleton search iteration control

(defun simpleton-iteration (my-scs)
  "Perform a single A/B search iteration; result is in scs lastpv/lastscore."
  (let
    (
      (iteration-number (1+ (scs-iteration my-scs)))
      (prelflag         (scs-prelflag my-scs))
      (ostream          (scs-ostream my-scs))
    )
    ;;
    ;; Handle iteration trace
    ;;
    (when (is-gf-set? acof-trsi)
      (trace-prefix my-scs "si")
      (if prelflag
        (format ostream "Starting the preliminary scoring iteration~%")
        (format ostream "Starting iteration ~R~%" iteration-number)))
    ;;
    ;; Set up the search for this iteration
    ;;
    (setf (scs-depth      my-scs) (* iteration-number frac-depth-delta))
    (setf (scs-ftdflag    my-scs) t)
    (setf (scs-priorpv    my-scs) (scs-lastpv my-scs))
    (setf (scs-priorscore my-scs) (scs-lastscore my-scs))
    ;;
    ;; Perform the search for this iteration; always start with a fully wide window
    ;;
    (simpleton-node my-scs (make-window))
    ;;
    ;; Check for a sufficiently fast lose that allows an early exit from the search
    ;;
    (when
      (and
        (scs-is-search-going? my-scs)
        (not prelflag)
        (is-score-losing? (scs-lastscore my-scs))
        (< (calc-lose-distance (scs-lastscore my-scs)) (1+ (scs-iteration my-scs))))
      (scs-terminate-search my-scs sts-certain-lose)))
  (values))

(defun simpleton-iteration-scan (my-scs)
  "Perform multiple A/B search iterations; result is in scs lastpv/lastscore."
  (let ((iter (slim-iter (scs-slim my-scs))))
    ;;
    ;; Loop through the iterations
    ;;
    (setf (scs-iteration my-scs) 1)
    (dowhile (and (scs-is-search-going? my-scs) (< (scs-iteration my-scs) iteration-limit))
      ;;
      ;; Perform the iteration and increment the attempted iteration count
      ;;
      (simpleton-iteration my-scs)
      (incf (scs-iteration my-scs))
      ;;
      ;; Handle iteration count search limit
      ;;
      (when (and (scs-is-search-going? my-scs) iter (>= (scs-iteration my-scs) iter))
        (scs-terminate-search my-scs sts-rl-iterations))))
  ;;
  ;; Ensure that the search is marked as terminated
  ;;
  (when (scs-is-search-going? my-scs)
    (scs-terminate-search my-scs sts-program-iter-limit))
  (values))

(defun simpleton-preliminary-scoring (my-scs)
  "Assign preliminary scores to the root move vector and sort it in descending order."
  (let ((mvec (scs-rootmvec my-scs)) (ostream (scs-ostream my-scs)))
    ;;
    ;; Use the search to generate preliminary scores with A/B pruning disabled at ply zero
    ;;
    (setf (scs-prelflag my-scs) t)
    (simpleton-iteration my-scs)
    (setf (scs-prelflag my-scs) nil)
    ;;
    ;; Sort the root move vector by order score (descending order)
    ;;
    (movevector-sort-by-order mvec)
    ;;
    ;; Handle trace of initial move ordering
    ;;
    (when (is-gf-set? acof-trmo)
      (trace-prefix my-scs "mo")
      (format ostream "Order: ~A~%" (movevector->movelist mvec))))
  (values))

;;; ----------  The simpleton search top level control

(defun simpleton-iterated-alfa-beta-search (my-scs)
  "Perform a simple traditional iterated A/B search; result is in scs lastpv/lastscore."
  (simpleton-preliminary-scoring my-scs)
  (simpleton-iteration-scan my-scs)
  (values))

(defun simpleton-analyze (my-scs)
  "Analyze a position including a search if needed; result is in scs lastpv/lastscore."
  (let
    (
      (done  nil)
      (mc    (scs-rootmc    my-scs))
      (moves (scs-rootmoves my-scs))
      (pos   (scs-pos       my-scs))
    )
    ;;
    ;; Try: Position dependent game termination detection
    ;;
    (unless done
      (let ((pdgt (pos->pdgt pos)))
        (unless (= pdgt pdgt-unterminated)
          (if (= pdgt pdgt-checkmate)
            (scs-set-last-and-terminate-search my-scs nil checkmated-score sts-immediate-lose)
            (scs-set-last-and-terminate-search my-scs nil draw-score       sts-immediate-draw))
          (setf done t))))
    ;;
    ;; Try: Singleton detection
    ;;
    (unless done
      (when (one? mc)
        (scs-set-last-and-terminate-search my-scs (list (first moves)) even-score sts-singleton)
        (setf done t)))
    ;;
    ;; Mark all moves that result in a mate in 1 position (to avoid allowing an immediate checkmate)
    ;;
    (unless done
      (dolist (move moves)
        (unless (is-move-marked-certain? move)
          (pos-execute pos move)
          (when (pos-is-mate-in-1? pos)
            (move-set-terminal move lose-in-1-score))
          (pos-retract pos))))
    ;;
    ;; Mark all moves that result in a lose in 1 position (to avoid missing a mate in 2 move)
    ;;
    (unless done
      (dolist (move moves)
        (unless (is-move-marked-certain? move)
          (pos-execute pos move)
          (when (pos-is-lose-in-1? pos)
            (move-set-terminal move mate-in-2-score))
          (pos-retract pos))))
    ;;
    ;; Try: All certain scores detection
    ;;
    (unless done
      (when (= mc (movelist-count-certain-scores moves))
        (let*
          (
            (score    (movelist-best-certain-score moves))
            (bestmove (movelist-pick-random (movelist-collect-moves-with-certain-score moves score)))
          )
          (scs-set-last-and-terminate-search my-scs (list bestmove) score sts-all-certain))
        (setf done t)))
    ;;
    ;; Try: Known checkmating detection
    ;;
    (unless done
      (let ((score (movelist-best-certain-score moves)))
        (when (and score (is-score-mating? score))
          (let ((bestmove (movelist-pick-random (movelist-collect-moves-with-certain-score moves score))))
            (scs-set-last-and-terminate-search my-scs (list bestmove) score sts-certain-mate))
          (setf done t))))
    ;;
    ;; Try: All bad but one
    ;;
    (unless done
      (when
        (and
          (> mc 1)
          (one? (- mc (movelist-count-certain-scores moves)))
          (is-score-losing? (movelist-best-certain-score moves)))
        (let ((bestmove (movelist-first-uncertain-move moves)))
          (scs-set-last-and-terminate-search my-scs (list bestmove) even-score sts-all-bad-but-one))
        (setf done t)))
    ;;
    ;; Try: A/B search (always causes a search termination)
    ;;
    (unless done
      (simpleton-iterated-alfa-beta-search my-scs)
      (setf done t)))
  ;;
  ;; Done; result is in scs lastpv/lastscore
  ;;
  (values))

(defun simpleton (my-pos)
  "Perform a simpleton move selection for the given position; return an analysis."
  (let ((scs (new-scs my-pos)))
    (encode-board-graphic-color (scs-ostream scs) my-pos)
    (simpleton-analyze scs)
    (when (is-gf-set? acof-sssr)
      (scs-report-statistics scs))
    (scs->analysis scs)))

(defun new-simpleton-player ()
  "Return a new simpleton player structure."
  (new-player "Simpleton" (function simpleton)))

;;; ---------- The stoner move selector

(defun stoner (my-pos)
  "Perform a stoner move selection for the given position; return an analysis."
  (make-analysis
    :pv     (list (movelist-pick-random (generate-notated my-pos)))
    :score  even-score
    :fgpair (pos->fgpair my-pos)
    :sts    sts-random-move))

(defun new-stoner-player ()
  "Return a new stoner player structure."
  (new-player "Stoner" (function stoner)))

;;; ---------- Test game generation

(defun gcs-test-game (my-gcs)
  "Given a game context structure, play a sample game and return it."
  (let*
    (
      (ostream   (acs-ostream *acs*))
      (game      (gcs-game      my-gcs))
      (playervec (gcs-playervec my-gcs))
      (pos       (game-pos     game))
      (ptp-vec   (game-ptp-vec game))
    )
    ;;
    ;; Initialize various PGN tag pairs
    ;;
    (setf (svref ptp-vec ptn-event) "Simpleton autoplay test")
    (setf (svref ptp-vec ptn-site)  "Autoplay test site")
    (setf (svref ptp-vec ptn-white) (player-name (svref playervec color-white)))
    (setf (svref ptp-vec ptn-black) (player-name (svref playervec color-black)))
    ;;
    ;; Generate and play moves until the game is over
    ;;
    (dowhile (pos-is-game-going? pos)
      (encode-board-graphic-color ostream pos)
      (let*
        (
          (good     (pos-good pos))
          (player   (svref playervec good))
          (selector (player-selector player))
          (analysis (funcall selector pos))
          (move (first (analysis-pv analysis)))
        )
        (format ostream "~A~%" (analysis->string analysis))
        (format ostream "Playing ~A~%" (fgpair+move->string (pos->fgpair pos) move))
        (pos-execute pos move)
        (format ostream "~A~%" (pos->string pos))))
    (encode-board-graphic-color ostream pos)
    (game-set-gsr game (pos->gsr pos))
    game))

(defun run-test0-game ()
  "Produce a simpleton/simpleton test game."
  (let ((gcs (new-gcs (new-simpleton-player) (new-simpleton-player))))
    (gcs-test-game gcs)))

(defun run-test1-game ()
  "Produce a simpleton/stoner test game."
  (let ((gcs (new-gcs (new-simpleton-player) (new-stoner-player))))
    (gcs-test-game gcs)))

;;; ---------- Benchmarking

(defun bench-emp-aux (my-pos my-depth)
  "Return the count of movepaths from the given position of the indicated length."
  (if (zero? my-depth)
    1
    (let ((sum 0) (new-depth (1- my-depth)) (moves (generate my-pos)))
      (dolist (move moves)
        (pos-execute my-pos move)
        (incf sum (bench-emp-aux my-pos new-depth))
        (pos-retract my-pos))
      sum)))

(defun bench-emp (my-pos my-depth)
  "Return the node frequency of a movepath enumeration."
  (let ((st (new-simpletimer-cu t)))
    (let ((sum (bench-emp-aux my-pos my-depth)))
      (/ sum (simpletimer->seconds st)))))

(defun bench-report-emp (my-pos my-depth)
  "Calculate and report the node frequency of a movepath enumeration."
  (let ((nps (bench-emp my-pos my-depth)) (ostream (acs-ostream *acs*)))
    (format ostream "Frequency: ~A   Period: ~A~%" (frequency->string nps) (time->string (/ 1.0 nps))))
  (values))

(defun bench ()
  "Calculate and report a simple node frequency benchmark."
  (bench-report-emp (string->pos "2qrr1n1/3b1kp1/2pBpn1p/1p2PP2/p2P4/1BP5/P3Q1PP/4RRK1 w - - 0 1") 4)
  (values))

;;; ---------- Toolkit initialization

(defun initialize-toolkit ()
  "Chess In Lisp initialization control."
  (let ((ostream (acs-ostream *acs*)))
    ;;
    ;; Sign on
    ;;
    (fmt-banner ostream)
    ;;
    ;; Initialize constant values of the single active bit integer vector
    ;;
    (setf sab-vec (constant-sab-vec))
    ;;
    ;; Initialize constant values of the butterfly indexing vector
    ;;
    (setf butterfly-vec (constant-butterfly-vec))
    ;;
    ;; Initialize constant values of the next-sq, sq-sq-dir, and sq-sq-inline-dir vectors
    ;;
    (setf next-sq-vec          (constant-next-sq-vec))
    (setf sq-sq-dir-vec        (constant-sq-sq-dir-vec))
    (setf sq-sq-inline-dir-vec (constant-sq-sq-inline-dir-vec))
    ;;
    ;; Initialize constant values of the shadow square vector
    ;;
    (setf shadow-sq-vec (constant-shadow-sq-vec))
    ;;
    ;; Initialize constant values of the path, beyond, and beam square list vectors
    ;;
    (setf path-sqs-vec   (constant-path-sqs-vec))
    (setf beyond-sqs-vec (constant-beyond-sqs-vec))
    (setf beam-sqs-vec   (constant-beam-sqs-vec))
    ;;
    ;; Initialize constant values of castling related items
    ;;
    (setf cast-string-vec (constant-cast-string-vec))
    (setf other-cast-vec  (constant-other-cast-vec))
    ;;
    ;; Initialize constant values of the piece attack square list vectors
    ;;
    (setf pawn-atk-sqs-vec   (constant-pawn-atk-sqs-vec))
    (setf knight-atk-sqs-vec (constant-knight-atk-sqs-vec))
    (setf king-atk-sqs-vec   (constant-king-atk-sqs-vec))
    (setf sweep-atk-sqs-vec  (constant-sweep-atk-sqs-vec))
    ;;
    ;; Initialize constant values for the mobility square count vectors
    ;;
    (setf pawn-mobility-vec   (constant-pawn-mobility-vec))
    (setf knight-mobility-vec (constant-knight-mobility-vec))
    (setf king-mobility-vec   (constant-king-mobility-vec))
    ;;
    ;; Initialize constant values for various bitboards
    ;;
    (setf empty-bb  (constant-empty-bb))
    (setf corner-bb (constant-corner-bb))
    (setf rim-bb    (constant-rim-bb))
    ;;
    ;; Initialize constant values for various bitboard vectors
    ;;
    (setf file-bb-vec            (constant-file-bb-vec))
    (setf rank-bb-vec            (constant-rank-bb-vec))
    (setf pawn-atk-bb-vec        (constant-pawn-atk-bb-vec))
    (setf knight-atk-bb-vec      (constant-knight-atk-bb-vec))
    (setf king-atk-bb-vec        (constant-king-atk-bb-vec))
    (setf sweep-atk-bb-vec       (constant-sweep-atk-bb-vec))
    (setf diago-rays-atk-bb-vec  (constant-diago-rays-atk-bb-vec))
    (setf ortho-rays-atk-bb-vec  (constant-ortho-rays-atk-bb-vec))
    (setf sweep-rays-atk-bb-vec  (constant-sweep-rays-atk-bb-vec))
    (setf path-bb-vec            (constant-path-bb-vec))
    (setf beyond-bb-vec          (constant-beyond-bb-vec))
    (setf beam-bb-vec            (constant-beam-bb-vec))
    (setf castling-attack-bb-vec (constant-castling-attack-bb-vec))
    (setf castling-vacant-bb-vec (constant-castling-vacant-bb-vec))
    (setf pawn-track-bb-vec      (constant-pawn-track-bb-vec))
    (setf passed-pawn-bb-vec     (constant-passed-pawn-bb-vec))
    (setf connect-pawn-bb-vec    (constant-connect-pawn-bb-vec))
    ;;
    ;; Initialize constant values for the hash codes; same codes on each invocation
    ;;
    (let ((prng-state (new-prng-state)))
      (setf empty-hash        (constant-empty-hash))
      (setf man-sq-hash-vec   (constant-man-sq-hash-vec prng-state))
      (setf castling-hash-vec (constant-castling-hash-vec prng-state))
      (setf cast-hash-vec     (constant-cast-hash-vec))
      (setf epfile-hash-vec   (constant-epfile-hash-vec prng-state))
      (setf gsr-hash-vec      (constant-gsr-hash-vec prng-state))
      (setf color-hash-vec    (constant-color-hash-vec prng-state))
      (setf msc-hash-vec      (constant-msc-hash-vec prng-state)))
    ;;
    ;; Initialize constant values for various moves
    ;;
    (setf null-move         (constant-null-move))
    (setf void-move         (constant-void-move))
    (setf castling-move-vec (constant-castling-move-vec))
    ;;
    ;; Report ready
    ;;
    (format ostream "Ready~%")
    (finish-output ostream))
  (values))

;;; ---------- Global initialization

(defun create-acs ()
  "Create and assign a new application context structure for the application invocation."
    (setf *random-state* (make-random-state t))
    (setf *acs* (make-acs))
    (initialize-toolkit)
    (values))

;;; ---------- Start

(create-acs)

;;; End of the CIL source

;;;; Start of the sample code source

;;; ---------- Sample code: Random game termination enumeration

(defun report-random-game-terminations (my-limit)
  "Generate random games and report a termination summary."
  (let ((result nil) (st (new-simpletimer-cu t)) (ostream (acs-ostream *acs*)))
    (setf result (calculate-random-game-terminations my-limit))
    (encode-simpletimer-fpr ostream st my-limit)
    (newline ostream)
    (dopdgts (pdgt)
      (unless (= pdgt pdgt-unterminated)
        (format ostream "~A ~A ~A~%"
          (pdgt->string pdgt)
          (svref result pdgt)
          (/ (svref result pdgt) (float my-limit))))))
  (values))

;;; ---------- Sample code: Movepath enumeration tests

(defvar *emp-hashtree*     nil "Movepath enumeration hash tree for some enumeration routines")
(defvar *emp-hashtree-vec* nil "Movepath enumeration hash tree vector for some enumeration routines")

(defun new-hnalist ()
  "Return a new hashnode alist."
  (alist-build hnalistsym (list countsym freqsym fensym)))

;;; Enumeration mode 1 of 5: Enumerate movepaths by visiting every node

(defun emp1-aux (my-pos my-depth my-ply)
  "Movepath enumeration with movie; emp0 helper routine."
  (let ((result nil))
    (cond
      ((zero? my-depth)
        (setf result 1))
      (t
        (let ((new-depth (1- my-depth)) (new-ply (1+ my-ply)) (ostream (acs-ostream *acs*)))
          (setf result 0)
          (dolist (move (if (zero? my-ply) (generate-canonical my-pos) (generate my-pos)))
            (pos-execute my-pos move)
            (board-movie-update ostream my-pos move)
            (let ((subtotal (emp1-aux my-pos new-depth new-ply)))
              (when (one? new-ply)
                (format ostream "~A ~:D~%" move subtotal))
              (incf result subtotal))
            (pos-retract my-pos)
            (board-movie-update ostream my-pos move)))))
    result))

(defun emp1 (my-pos my-depth)
  "Movepath enumeration with movie; full node visitation."
  (let ((result nil) (st (new-simpletimer-cu t)) (ostream (acs-ostream *acs*)))
    (board-movie-start ostream my-pos)
    (setf result (emp1-aux my-pos my-depth 0))
    (board-movie-finish ostream)
    (encode-simpletimer-fpr ostream st result)
    (newline ostream)
    result))

;;; Enumeration mode 2 of 5: Enumerate movepaths by visiting every depth one node and using bulk counting

(defun emp2-aux (my-pos my-depth my-ply)
  "Movepath enumeration; emp1 helper routine."
  (let ((result nil))
    (cond
      ((zero? my-depth)
        (setf result 1))
      ((one? my-depth)
        (setf result (count-moves my-pos)))
      (t
        (let ((new-depth (1- my-depth)) (new-ply (1+ my-ply)))
          (setf result 0)
          (dolist (move (if (zero? my-ply) (generate-canonical my-pos) (generate my-pos)))
            (pos-execute my-pos move)
            (let ((subtotal (emp2-aux my-pos new-depth new-ply)))
              (when (one? new-ply)
                (format (acs-ostream *acs*) "~A ~:D~%" move subtotal))
              (incf result subtotal))
            (pos-retract my-pos)))))
    result))

(defun emp2 (my-pos my-depth)
  "Movepath enumeration; bulk counting."
  (let ((result nil) (st (new-simpletimer-cu t)) (ostream (acs-ostream *acs*)))
    (setf result (emp2-aux my-pos my-depth 0))
    (encode-simpletimer-fpr ostream st result)
    (newline ostream)
    result))

;;; Enumeration mode 3 of 5: Enumerate movepaths by visiting every node with unique position counting

(defun count-hashnodes (my-hashnode)
  (if (null? my-hashnode)
    0
    (+
      (count-hashnodes (hashnode-subtree-l my-hashnode))
      1
      (count-hashnodes (hashnode-subtree-r my-hashnode)))))

(defun emp3-aux (my-pos my-depth my-ply)
  "Movepath enumeration; emp2 helper routine."
  (let ((result nil))
    (cond
      ((zero? my-depth)
        (let ((hash (pos-mdhs my-pos)))
          (unless (hashtree-search *emp-hashtree* hash)
            (hashtree-insert *emp-hashtree* (make-hashnode :hash (hash-clone hash))))
          (setf result 1)))
      (t
        (let ((new-depth (1- my-depth)) (new-ply (1+ my-ply)))
          (setf result 0)
          (dolist (move (if (zero? my-ply) (generate-canonical my-pos) (generate my-pos)))
            (pos-execute my-pos move)
            (let ((subtotal (emp3-aux my-pos new-depth new-ply)))
              (when (one? new-ply)
                (format (acs-ostream *acs*) "~A ~:D~%" move subtotal))
              (incf result subtotal))
            (pos-retract my-pos)))))
    result))

(defun emp3 (my-pos my-depth)
  "Movepath enumeration; full node visitation with distinct position counting."
  (let ((result nil) (st (new-simpletimer-cu t)) (ostream (acs-ostream *acs*)))
    (setf *emp-hashtree* (make-hashtree))
    (setf result (emp3-aux my-pos my-depth 0))
    (encode-simpletimer-fpr ostream st result)
    (newline ostream)
    (format ostream "Distinct position count: ~A~%" (hashtree-entry-count *emp-hashtree*))
    (format ostream "Dictionary hashnode count: ~A~%" (count-hashnodes (hashtree-root *emp-hashtree*)))
    (setf *emp-hashtree* nil)
    result))

;;; Enumeration mode 4 of 5: Enumerate movepaths with use of a hash tree pair that stores subtree counts

(defun dump-hashnode (my-stream my-hashnode)
  "Dump a hashnode."
  (let
    (
      (subtree-l (hashnode-subtree-l my-hashnode))
      (subtree-r (hashnode-subtree-r my-hashnode))
      (hnalist   (hashnode-hook      my-hashnode))
    )
    (when subtree-l
      (dump-hashnode my-stream subtree-l))
    (format my-stream "~A ~A~%"
      (alist-fetch hnalist fensym)
      (alist-fetch hnalist freqsym))
    (when subtree-r
      (dump-hashnode my-stream subtree-r)))
  (values))

(defun emp4-aux (my-pos my-depth my-ply)
  "Movepath enumeration; emp4 helper routine."
  (let*
    (
      (result   nil)
      (hashtree (svref *emp-hashtree-vec* my-ply))
      (hash     (pos-mdhs my-pos))
      (hashnode (hashtree-search hashtree hash))
    )
    (if hashnode
      (let* ((hnalist (hashnode-hook hashnode)) (freq (alist-fetch hnalist freqsym)))
        (incf freq)
        (alist-stash hnalist freqsym freq)
        (setf result (alist-fetch hnalist countsym)))
      (progn
        (cond
          ((zero? my-depth)
            (setf result 1))
          (t
            (let ((new-depth (1- my-depth)) (new-ply (1+ my-ply)))
              (setf result 0)
                (dolist (move (if (zero? my-ply) (generate-canonical my-pos) (generate my-pos)))
                (pos-execute my-pos move)
                (let ((subtotal (emp4-aux my-pos new-depth new-ply)))
                  (when (one? new-ply)
                    (format (acs-ostream *acs*) "~A ~:D~%" move subtotal))
                  (incf result subtotal))
                (pos-retract my-pos)))))
        (setf hashnode (make-hashnode :hash (hash-clone hash)))
        (hashtree-insert hashtree hashnode)
        (let ((hnalist (new-hnalist)))
          (alist-stash hnalist countsym result)
          (alist-stash hnalist fensym (pos->string my-pos))
          (alist-stash hnalist freqsym 1)
          (setf (hashnode-hook hashnode) hnalist))))
    result))

(defun emp4 (my-pos my-depth)
  "Movepath enumeration; full node visitation with ply indexed hashed position counting."
  (let ((result nil) (st (new-simpletimer-cu t)) (ostream (acs-ostream *acs*)))
    (setf *emp-hashtree-vec* (make-array ply-limit :initial-element nil))
    (dotimes (index ply-limit)
      (setf (svref *emp-hashtree-vec* index) (make-hashtree)))
    (setf result (emp4-aux my-pos my-depth 0))
    (encode-simpletimer-fpr ostream st result)
    (newline ostream)
    (let ((hashtree (svref *emp-hashtree-vec* my-depth)))
      (format ostream "Distinct position count: ~A~%" (hashtree-entry-count hashtree))
      (format ostream "Dictionary hashnode count: ~A~%" (count-hashnodes (hashtree-root hashtree)))
      (let ((ofs (open-fs-output "emp.txt")))
        (dump-hashnode ofs (hashtree-root hashtree))
        (close ofs)))
    (setf *emp-hashtree-vec* nil)
    result))

;;; Enumeration mode 5 of 5: Enumerate movepaths with bulk counting and using a hash tree that stores subtree counts

(defun emp5-aux (my-pos my-depth my-ply)
  "Movepath enumeration; emp5 helper routine."
  (let ((result nil))
    (cond
      ((zero? my-depth)
        (setf result 1))
      ((one? my-depth)
        (setf result (count-moves my-pos)))
      (t
        (let*
          (
            (hashtree (svref *emp-hashtree-vec* my-ply))
            (hash     (pos-mdhs my-pos))
            (hashnode (hashtree-search hashtree hash))
          )
          (if hashnode
            (setf result (alist-fetch (hashnode-hook hashnode) countsym))
            (let ((new-depth (1- my-depth)) (new-ply (1+ my-ply)))
              (setf result 0)
                (dolist (move (if (zero? my-ply) (generate-canonical my-pos) (generate my-pos)))
                (pos-execute my-pos move)
                (let ((subtotal (emp5-aux my-pos new-depth new-ply)))
                  (when (one? new-ply)
                    (format (acs-ostream *acs*) "~A ~:D~%" move subtotal))
                  (incf result subtotal))
                (pos-retract my-pos))
              (setf hashnode (make-hashnode :hash (hash-clone hash)))
              (hashtree-insert hashtree hashnode)
              (let ((hnalist (new-hnalist)))
                (alist-stash hnalist countsym result)
                (alist-stash hnalist freqsym 1)
                (setf (hashnode-hook hashnode) hnalist)))))))
    result))

(defun emp5 (my-pos my-depth)
  "Movepath enumeration; fast version with ply indexed hashed position counting."
  (let ((result nil) (st (new-simpletimer-cu t)) (ostream (acs-ostream *acs*)))
    (setf *emp-hashtree-vec* (make-array ply-limit :initial-element nil))
    (dotimes (index ply-limit)
      (setf (svref *emp-hashtree-vec* index) (make-hashtree)))
    (setf result (emp5-aux my-pos my-depth 0))
    (encode-simpletimer-fpr ostream st result)
    (newline ostream)
    (setf *emp-hashtree-vec* nil)
    result))

;;; ---------- Sample code: Make a FEN file from an EPD file

(defun epdfile->fenfile (my-epd-pathname my-fen-pathname)
  "Make a FEN file from an EPD file."
  (let
    (
      (ifs (open-fs-input  my-epd-pathname))
      (ofs (open-fs-output my-fen-pathname))
    )
    (when (null? ifs)
      (error "Can't open ~A for input" my-epd-pathname))
    (when (null? ofs)
      (error "Can't open ~A for output" my-fen-pathname))
    (let ((count 0) (st (new-simpletimer-cu t)) (text (read-textline ifs)))
      (dowhile text
        (let ((pos (string->pos text)))
          (format ofs "~A~%" pos)
          (incf count)
          (setf text (read-textline ifs))))
      (encode-simpletimer-fpr (acs-ostream *acs*) st count))
    (close ifs)
    (close ofs))
  (values))

;;; ---------- Sample code: Simple and fast movepath enumeration set

(defun test ()
  "Simple and fast movepath enumeration set."
  (format (acs-ostream *acs*) "(emp1 (new-pos) 4)~%")
  (emp1 (new-pos) 4)
  (format (acs-ostream *acs*) "(emp2 (new-pos) 5)~%")
  (emp2 (new-pos) 5)
  (values))

;;; End of the sample code source
