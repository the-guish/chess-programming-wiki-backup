#ifndef CHESSJOB
#define CHESSJOB
#include "job.h"
#include "hydra.h"
#include "parstack.h"
/**
*/

class ChessJob : public Job, public Hydra
 {
  private:

  public :
          ParStack<LocalVariables> ParSt;
          ParStack<int> TestSt;
          void Test(void);
          ChessJob() { }
          ~ChessJob();
 };

#endif

