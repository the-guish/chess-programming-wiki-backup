#include "hash.h"
#include "move.h"
#include "messages.h"
#include <stdio.h>

#ifndef NO_MP
#include "communicator.h"
#endif

unsigned int32 hashcodeIDs=1;

unsigned int32 Hashtable::SendQuery(int64 hashvalue,int8 castle_state, int8 en_passent, int8 WTM, int distributed, int nodeID, int16* hv, int16* hrd, int8 *hf, Move* hMv, int8 *hXf, Move* hXMv, int16* hXrd, int16 rd)
{
  TableEntry* t;
  int i;
#ifndef NO_MP
  int n = ((Communicator *)C)->GetN();
  int id = ((Communicator *)C)->GetID();
#else
  int n = 1;
  int id = 0;
#endif
  
  hashvalue ^= ((castle_state<<16) ^ en_passent);
  if (!WTM) hashvalue ^= ((((int64)0xffffffff)<<32)|0xffffffff);

  if (distributed == false || n < 2 || ((unsigned int)(hashvalue&0xffffffff))%n==id) {
    for (i=0;i<3;i++) {
      unsigned int ix = ((unsigned int)(hashvalue & 0xffffffff)%Ts+i)%Ts;
      t=&table[ix];
      if (t->Key == hashvalue) {
	*hv = t->Val;
	*hrd = t->rDepth;
	*hf = t->Flgs & FLAGS;
	if(1 || *hf == EXACT || *hf ==  FAILH)
	  *hMv = t->Mv;
      }
      if (t->XKey == hashvalue) {
	*hXrd = t->XrDepth;
	*hXf = (t->XFlgs & XFLAGS);
	*hXMv = t->XMv;
      }
    }
    return 0;
  } else if (1||rd > 1) {
    hashcodeIDs++;
    if (hashcodeIDs == 0) hashcodeIDs++;
    class Communicator::Message m;
    HashQuery HQ;
    HQ.Key = hashvalue;
    HQ.hashcodeID = hashcodeIDs;
    m.mh.cmd = HASH_QUERY;
    m.data = (char*)&HQ;
    m.mh.size=sizeof(HashQuery);
    m.mh.srce = id;
    m.mh.dest = ((unsigned int)(hashvalue&0xffffffff))%n;
    ((Communicator*)C)->Send(&m);
    return hashcodeIDs;
  }
}

void Hashtable::PushHash(Move* pbMv,int8 flgs, int16 hv, int16 rd, int distributed, int64 hashvalue, int8 castle_state, int8 en_passent, int8 WTM)
{
  TableEntry* t,*tmin;
  int i;

#ifndef NO_MP
  int n = ((Communicator *)C)->GetN();
  int id = ((Communicator *)C)->GetID();
#else
  int n = 1;
  int id = 0;
#endif
  hashvalue ^= ((castle_state<<16) ^ en_passent);
  if (!WTM) hashvalue ^= ((((int64)0xffffffff)<<32)|0xffffffff);
  
  if (distributed == false || n < 2 || ((unsigned int)(hashvalue&0xffffffff))%n==id) {
    unsigned int ix = ((unsigned int)(hashvalue & 0xffffffff))%Ts;
    tmin=&table[ix];
    for (i=0;i<3;i++) {
      ix = (((unsigned int)(hashvalue & 0xffffffff))%Ts+i)%Ts;
      t=&table[ix];
      if (t->Key==hashvalue) {
        tmin=&table[ix];
	break;
      }
      if(t->rDepth<tmin->rDepth || ((t->Flgs&OLD_ENTRY) && !(tmin->Flgs&OLD_ENTRY))) tmin=t;
    }
    t=tmin;
    if (t->rDepth <= rd || (t->Flgs&OLD_ENTRY)) {
      t->Key = hashvalue;
      t->Val = hv;
      t->rDepth = rd;
      t->Flgs = flgs;
      t->Mv = *pbMv;
    }
  } else if (1|| rd > 1) {
    class Communicator::Message m;
    HashPush HP;
    HP.Key = hashvalue;
    HP.rDepth = rd;
    HP.Flgs = flgs;
    HP.Mv = *pbMv;
    HP.Val = hv;
    m.mh.cmd = HASH_PUSH_MESSAGE;
    m.data = (char*)&HP;
    m.mh.size=sizeof(HashPush);
    m.mh.srce = id;
    m.mh.dest = ((unsigned int)(hashvalue&0xffffffff))%n;
    ((Communicator*)C)->Send(&m);
  }
}

void Hashtable::PushExt(int16 rd, int distributed, int64 hashvalue, int8 castle_state, int8 en_passent, int8 WTM, Move* pXMv,int8 Xfl)
{
  TableEntry* t,*tmin;
  int i;
  return;
  
#ifndef NO_MP
  int n = ((Communicator *)C)->GetN();
  int id = ((Communicator *)C)->GetID();
#else
  int n = 1;
  int id = 0;
#endif
  hashvalue ^= ((castle_state<<16) ^ en_passent);
  if (!WTM) hashvalue ^= ((((int64)0xffffffff)<<32)|0xffffffff);
  
  if (distributed == false || n < 2 || ((unsigned int)(hashvalue&0xffffffff))%n==id) {
    unsigned int ix = ((unsigned int)(hashvalue & 0xffffffff))%Ts;
    tmin=&table[ix];
    for (i=0;i<3;i++) {
      unsigned int ix = (((unsigned int)(hashvalue & 0xffffffff))%Ts+i)%Ts;
      t=&table[ix];
      if (t->XKey==hashvalue) {
        tmin=&table[ix];
	break;
      }
      if(t->XrDepth<tmin->XrDepth || ((t->Flgs&OLD_ENTRY) && !(tmin->Flgs&OLD_ENTRY))) tmin=t;
    }
    t=tmin;
    if (t->XrDepth <= rd || (t->XFlgs&OLD_ENTRY)) {
      t->XKey = hashvalue;
      t->XrDepth = rd;
      t->XFlgs = Xfl;
      t->XMv = *pXMv;
    }
  } else {
    class Communicator::Message m;
    HashPushExtension HE;
    HE.XKey = hashvalue;
    HE.XrDepth = rd;
    HE.XFlgs = Xfl;
    HE.XMv = *pXMv;
    m.mh.cmd = HASH_EXT_PUSH_MESSAGE;
    m.data = (char*)&HE;
    m.mh.size=sizeof(HashPushExtension);
    m.mh.srce = id;
    m.mh.dest = ((unsigned int)(hashvalue&0xffffffff))%n;
    ((Communicator*)C)->Send(&m);
  }
}

void Hashtable::ClearHash(int full)
{
  if (full)
    for (int i = 0; i < Ts;i++) {
      table[i].Key =  table[i].XKey = 0;//table[i].Mv.from = table[i].Mv.to = table[i].Mv.flag =  table[i].Val = table[i].rDepth = table[i].Flgs = table[i].XFlgs = 0;
      table[i].rDepth = table[i].XrDepth = 0;
      table[i].Flgs = table[i].XFlgs = 0;
    }
  else
    for (int i = 0; i < Ts;i++) {
      table[i].Flgs |= OLD_ENTRY;
      table[i].XFlgs |= OLD_ENTRY;
    }
}

