#ifndef MASTER
#define MASTER
#include "basic_types.h"
#include "commprint.h"
#include "communicator.h"
#include "keypress.h"
#include <stdlib.h>
#include <time.h>

/**
*/

class Master:public KeyPress, public CommPrint
 {
  private:  int testsUnterwegs, aliveCheck;
            time_t checkpoint;
	    
  public :  Master(){};
           ~Master(){};
	   
	    void SetAliveCheck(int check, int sec);
	    int AliveEvent();

	    void Run(Communicator*);
	    void MessageAuswerten(Communicator*, class Communicator::Message*);
	    
	    virtual int Ping(class Communicator::Message* mess){  
                                     fprintf(stderr,"."); 
                                     fflush(stderr);  
                                     return 0; 
                                  }
	    virtual int Echo(class Communicator::Message* mess)
                   {  fprintf(stderr,":"); fflush(stderr);  return 0; }
	    virtual int UserCommando(Communicator*, char*){ return 0; }
	    virtual void UserMessage(Communicator*, class Communicator::Message*){}
	    virtual void DoStep(Communicator*){}

	    virtual int StartFurtherIteration(int,int,int,int,int,int,int64,int64){ return 1;} 
	    virtual void SetResponseTime(int,int,int,int,int,int,int){ ResetTime(); }
	    virtual void ResetTime(void);
	    virtual unsigned int32 GetElapsedTime(void);
	    virtual void AddExtrTime(int,int){ }
	    virtual void SetExtrTime(int,int){ }
	    virtual int ChangeResponseTime(int,int){ return 0; }
	    virtual void ClrExtrTime( void ){ }
	    virtual unsigned int32 GetTime(void);
	    virtual int TimeOut(void);
 };

#define TESTANTWORT 4096
#define TEST 8192
#define ENDE 12288
#define ALIVECHECK 16384

#define ON 1
#define OFF 0

#endif

