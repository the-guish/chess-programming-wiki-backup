#include "localvariables.h"

void* LocalVariables::operator new(size_t s) 
{
   LocalVariables *j;
   
   if (free_locva==0L) {
     j = (LocalVariables*)malloc(s);
   } else {
     j = free_locva;
     free_locva = free_locva->next;
   }
   return (void*)j;
}

void LocalVariables::operator delete(void* p, size_t s) 
{
  LocalVariables *j = (LocalVariables*)p;
  if (free_locva==0L) {
    j->next = 0L;
    free_locva = j;
  } else {
    j->next = free_locva;
    free_locva = j;
  }
}
