#include "communicator.h"

#ifdef LINUX
extern "C" void *memalign(size_t, size_t);
#endif

Communicator::Communicator(int *argc, char ***argv, int BsendBuffersize,
                                  int InBuffsize, int OutBuffsize)
{
 MPI_Init(argc, argv);
#ifdef LINUX
 BsendBuffer = (void*)memalign(64, BsendBuffersize);
#endif
#ifdef WIN32
 BsendBuffer = (void*)malloc(BsendBuffersize+100);
 // allignment?
#endif

 anz_klMess=0;        
 klMessFreiliste=NULL;
 Qu_list.first = NULL;
 Qu_list.last = NULL;
 for (int i = 0;i < 10;i++) DataFreeListe[i] = NULL;
 
 InBuffersize=InBuffsize;
 OutBuffersize=OutBuffsize;
 InBuffer = new char[InBuffersize];
 OutBuffer = new char[OutBuffersize];
 MPI_Buffer_attach(BsendBuffer, BsendBuffersize);
 MPI_Comm_size(MPI_COMM_WORLD, &N);
 MPI_Comm_rank(MPI_COMM_WORLD, &ID);

 for(int i=0; i<N; i++)
   {
    if(i!=ID)
      {
       MPI_Ibsend(&i, sizeof(int), MPI_BYTE, i, 0, MPI_COMM_WORLD, &Sq);
       MPI_Wait(&Sq, &Sst);
      }
   }

 for(int i=1; i<N; i++)
   {
    MPI_Irecv(InBuffer,sizeof(int),MPI_BYTE,MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD, &Sq);
    MPI_Wait(&Sq, &Sst);
   }

 MPI_Barrier(MPI_COMM_WORLD);

}


Communicator::~Communicator()
{
 MPI_Finalize();
 delete InBuffer;
 delete OutBuffer;
 free(BsendBuffer);
}


int Communicator::GetID()
{
 return ID;
}


int Communicator::GetN()
{
 return N;
}


int Communicator::GetNextMessage( MyList_t *List,Message **to_be_returned )   
{                                          
 if (!((List)->first))
   {                     
    *(to_be_returned) = NULL;              
    return 0;
   } 
 else                                      
   {                                       
    *(to_be_returned) = (List)->last;      
    if (!((List)->last->next))             
       (List)->last = (List)->first = NULL;
    else                                   
       (List)->last = (List)->last->next;  
   }
 return 1;                                         
}

void Communicator::FreeMess(Message *mess)
{
 if(mess->mh.size!=0)
    DataFree(mess->data, mess->mh.size);                                                                    
 MessageFree(mess);  
}
	   

int Communicator::HiddenRecv()
{
  int msgtag;
  Message *akt_mess;
  int flag;
  MPI_Status stat, stat2;
  MPI_Request request;
    
  MessageAlloc(&akt_mess);
  
  do{
     MPI_Iprobe(MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&flag,&stat);
     
     if (!flag) break;

     msgtag = stat.MPI_TAG;
  
     MPI_Irecv(InBuffer,InBuffersize,MPI_BYTE,stat.MPI_SOURCE,stat.MPI_TAG,MPI_COMM_WORLD,&request);
     MPI_Wait(&request, &stat2);
     memcpy( &(akt_mess->mh), InBuffer, sizeof(MessageHead));
     
     /* Kontrolle: */
     if ( akt_mess->mh.size) {
       DataAlloc( &(akt_mess->data), akt_mess->mh.size);
	
       if ( !(akt_mess->data )) { 
	 mefprint(ID, "In QU: No more Memory for message of size: %d\n",akt_mess->mh.size);
	 exit(10);
       }
       memcpy(akt_mess->data,InBuffer+sizeof(MessageHead),akt_mess->mh.size);
     } else akt_mess->data = NULL;
     InQueue(&Qu_list, akt_mess);	          
     MessageAlloc(&akt_mess);
     
    } 
  while( 1 );

  MessageFree(akt_mess);
  return 0;
}


void Communicator::Send(Message *M)
{
  int flag=0;

#define REALITY_SEMANTIC
#ifdef STANDARD_SEMANTIC
  HiddenRecv();

  if(M->mh.size==0) {
    while(!flag) {
      HiddenRecv();
      MPI_Test(&Sq,&flag,&Sst);
    } 
    memcpy(OutBuffer,&(M->mh), sizeof(MessageHead));                      
    MPI_Ibsend(OutBuffer, sizeof(MessageHead), MPI_BYTE, M->mh.dest, 0 , MPI_COMM_WORLD, &Sq);      
  } else {
    while(!flag) {
      HiddenRecv();
      MPI_Test(&Sq, &flag, &Sst);
    }
    memcpy(OutBuffer, &(M->mh), sizeof(MessageHead));
    memcpy(OutBuffer+sizeof(MessageHead), M->data, M->mh.size);
    MPI_Ibsend(OutBuffer, sizeof(MessageHead)+M->mh.size, MPI_BYTE, M->mh.dest, 0 , MPI_COMM_WORLD,&Sq);
  }   
#endif
#ifdef REALITY_SEMANTIC
  //HiddenRecv();
  if(M->mh.size==0) {
    memcpy(OutBuffer,&(M->mh), sizeof(MessageHead));                      
    MPI_Isend(OutBuffer, sizeof(MessageHead), MPI_BYTE, M->mh.dest, 0 , MPI_COMM_WORLD, &Sq);      
    MPI_Test(&Sq,&flag,&Sst);
    while(!flag) {
      HiddenRecv();
      MPI_Test(&Sq,&flag,&Sst);
    } 
  } else {
    memcpy(OutBuffer, &(M->mh), sizeof(MessageHead));
    memcpy(OutBuffer+sizeof(MessageHead), M->data, M->mh.size);
    MPI_Isend(OutBuffer, sizeof(MessageHead)+M->mh.size, MPI_BYTE, M->mh.dest, 0 , MPI_COMM_WORLD,&Sq);
    MPI_Test(&Sq, &flag, &Sst);
    while(!flag) {
      HiddenRecv();
      MPI_Test(&Sq, &flag, &Sst);
    }
  }   
#endif
}




