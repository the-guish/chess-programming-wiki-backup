#include <stropts.h>
#include <stdio.h>
#include <errno.h>
#include <sys/ioctl.h>
/*
#include <sys/filio.h>
#include <sys/termio.h>
*/
#include <assert.h>



long keypressC( void )
{
   int n;
   long nr;
   struct strpeek data;

#define FIO_OK
#ifdef FIO_OK
   errno = 0;
   n = ioctl( 0, FIONREAD, &nr );
   return nr;
#else
   errno = 0;
   data.flags = 0;
   data.ctlbuf.maxlen = 0;
   data.databuf.maxlen = 0;
   n = ioctl( 0, I_PEEK, &data );
   return n;
#endif
}
