#include "keypress.h"
#include <stdio.h>
#ifdef LINUX
#include <unistd.h>
#endif
#ifdef WIN32
#include <string.h>
#include <conio.h>
#endif

int KeyPress::psgets(char *eingabe)
{
  int len,slen;

  strcpy(eingabe,"");
#ifdef WIN32
  gets(eingabe);
  return 0;
#endif
  len = slen = 0;
  do {
     slen = (int)strlen(eingabe);
#ifdef LINUX
     len = (int)read(0, eingabe+slen, 1);
#endif
     eingabe[len+slen] = 0;
     if (eingabe[slen] == '\n') { eingabe[slen] = 0; break; }
  } while (len == 1);
  return 0;
}

#ifdef LINUX
extern "C" long keypressC(void);

long KeyPress::keypress()
{
  if(!keypressC()) return 0;
  return 1;
}
#endif
#ifdef WIN32
long KeyPress::keypress()
{
  if(!_kbhit()) return 0;
  return 1;
}
#endif

