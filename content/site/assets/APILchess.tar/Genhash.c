#include <stdlib.h>
#include <stdio.h>

int main(int argc, char **argv)
{
  FILE *fp = fopen("hashconsts.h","w");
  int i,j;
  int r1,r2;
  char c1[20],c2[20];
  
  fprintf(fp,"static int64 Hconst[][192] = {\n");
  for (i = 0;i <= 12;i++) {
    fprintf(fp,"  ");
    for (j = 0;j < 192;j++) {
      r1 = rand();
      r2 = rand();
      sprintf(c1,"%x",r1);
      sprintf(c2,"%x",r2);      
      fprintf(fp,"(((((int64)0x%s)&0x00000000ffffffff)<<32)|(0x%s & 0x00000000ffffffff))",c1,&(c2[0]));      
      if (i!= 12 || j != 191)  fprintf(fp,","); 
    }
    fprintf(fp,"\n");
  }
  fprintf(fp,"};\n\n");
  
  fprintf(fp,"static int32 MSconst[13][12] = {\n");
  for (i = 0;i <= 12;i++) {
    fprintf(fp,"  ");
    for (j = 0;j < 12;j++) {
      fprintf(fp,"0x%x",rand());
      if (i!= 12 || j != 11)  fprintf(fp,","); 
    }
    fprintf(fp,"\n");
  }
  fprintf(fp,"};\n");
}
