#ifndef CHESSWORKER
#define CHESSWORKER
#include "commprint.h"
#include "communicator.h"
#include "worker.h"
#ifdef LINUX
#include <iostream.h>
#endif
#ifdef WIN32
#include <iostream>
#endif
#include "localvariables.h"
/**
*/

class ChessWorker : public Worker 
{
 public:  ChessWorker() {}
         ~ChessWorker() {}

 	  void DoStep(Communicator*);
	  void UserMessage(Communicator*, class Communicator::Message*);

          void Deliver(LocalVariables*, Communicator *C, int32);
          void PingEcho(class Communicator::Message* mess);
};

#endif
