#define WORDLENGTH 4
#ifdef LINUX
#define int64 long long 
#define int32  int
#define int16  short
#define int8   char
#define DWORD  int
#endif
#ifdef WIN32
#define int64 _int64 
#define int32 _int32
#define int16 _int32
#define int8  _int32
#endif
