#ifndef JOB
#define JOB
#include "commprint.h"
#include "communicator.h"
/**
*/

#define READY     0
#define WAIT      1
#define RUNNING   2
#define FINISHED  3

class Job
 {
  private:
   
  public :
            Job *next;
            Job *prev;
	    int jid; // Job-ID
	    int master_id;
	    int master_jid;
            int state;

            Job(){ next = prev = NULL; jid = master_jid = master_id = -1; state = READY; }
           ~Job(){
	      next = prev = NULL;
 	      jid = -2;
            }
	   Job *NextJob_Pointer(Job*);	   

	   void* operator new(size_t s);
	   void operator delete(void* p, size_t s);
 };

class Job_Container
 {
  private:

  public :  
            Job *first;
            Job *last;
            int active;

            Job_Container(){ first = NULL; active = 0; }
           ~Job_Container(){
            }

	    void Test();
	    int CountJobs();
	    int CountFreeJobs();
	    void Insert_Job(Job* job);
	    void Release_Job(Job* job);	   
	    Job *GetFIFO_Job();	   
	    Job *GetLIFO_Job();	   
	    Job *SelectJob();	   
 };


#endif

