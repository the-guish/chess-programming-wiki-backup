#include <stdio.h>

#define MPI_debug(a,b,d)                                                   \
{                                                                          \
  int i,j=0;                                                               \
  for (i = 0; i < (a);i++)                                                 \
    if (!strcmp((b)[i],"-ddd")) {                                          \
      j = 1;                                                               \
      break;                                                               \
    } else if (!strcmp((b)[i],"-gdb")) {                                   \
      j = 2;                                                               \
      break;                                                               \
    }                                                                      \
  if (j > 0) {                                                             \
    char name[1000];                                                       \
    if (j == 2) sprintf(name, "xterm -e gdb %s %d &", (b)[0],getpid());    \
    else        sprintf(name, "ddd %s %d &", (b)[0],getpid());             \
    system(name);                                                          \
    sleep(3);                                                              \
  }                                                                        \
}
