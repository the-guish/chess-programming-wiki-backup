#ifndef LOCVAR
#define LOCVAR

#include "APILchessdefs.h"
#include "hash.h"
#include <stdlib.h>

class LocalVariables
{
 private:
  LocalVariables* next;
  
 public:
  int16 a,b,rd,d,nd;
  int8 node_type;
  int64 *counter;
  Move *pMv;
  int16 pXPc;
  int8 WTM;
  Move list[250];
  Move Xlist[50];
  int32 IsRemote[300];
  int32 RemoteProcs[300];
  int64 ncount[300];
  int64 nmcount;
  int64 hashvalue;
  unsigned int32 hashcodeID;
  Move nullmove;
  Move *l;
  Move *pbMv;
  int64 bMcnt;
  int ownext,oppext;
  
  int nodeID;

  int n,xn,i,legals,j,donull,pcs,pat;
  int16 s,v,u,o,store_a,store_b;
  Move bMv;
  Move fpgaMv;
  Move dummyMv;

  int16 hv,hrd,Xhrd;
  int8 hf,Xflgs;
  int8 wait4hash;
  
  int16 xp;
  int8 save_casp;
  int8 save_ep;
  Move curMv;
  Move extMv;
  int8 ExtType;
  int8 PExtType;
  int8 PPExtType;
  int ext,extfound;

  int16 *result;
  int status;

  LocalVariables(int16 ca, int16 cb, int16 crd, int16 cd, Move* cpMv, int8 cWTM, int16 *cr, int st, int cntype, int64*ccounter, int cownext, int coppext, Move* cpbMv, int8 cPPExtT, int8 cPExtT, int16 cpXPc) {
    a = ca;
    b = cb;
    rd = crd;
    d = cd;
    WTM = cWTM;
    pMv = cpMv;
    pXPc=cpXPc;
    node_type = cntype;
    counter = ccounter;
    result = cr;
    status = st;
    pbMv = cpbMv;
    ownext = cownext;
    oppext = coppext;
    bMv.from = 255;
    ExtType=0;
    extMv.from=255;
    ext=extfound=0;
    hf = NO_ENTRY;
    Xflgs = NO_ENTRY;
    nullmove.from = NULLMOVE_SQ;
    nullmove.flag = 0;
    PPExtType = cPPExtT;
    PExtType = cPExtT;    
    hashcodeID=0;
  }
  
  ~LocalVariables(){ }

   void* operator new(size_t s);
   void operator delete(void* p, size_t s);
};

#ifdef _MAIN
LocalVariables *free_locva = NULL;
#else
extern LocalVariables *free_locva;
#endif

#endif

