#include "commprint.h"


void CommPrint::reverse(char s[])
{
  char c;
  size_t i,j;
  for (i = 0, j = strlen(s)-1;i < j;i++,j--)
    {
      c = s[i];
      s[i] = s[j];
      s[j] = c;
    }
}

void CommPrint::itoa(int n, char s[])
{
  int i,sign;
  if ((sign = n) < 0) n = -n;
  i = 0;
  do {
   s[i++] = n % 10 + '0';
  } while ((n /= 10) > 0);
  if (sign < 0) s[i++] = '-';
  s[i] = 0;
  reverse(s);
}


int CommPrint::mefprint(int ID, char *fmt ...)
{
   char fname[200];
   char IDStr[10];
 
   va_list argpoint;
   FILE *file=NULL;

   strcpy(fname,"./Error/SFehler");
   sprintf(IDStr,"%d",ID);
   strcat(fname,IDStr);

   if(!(file=fopen( fname, "a" ))){
     puts("!!!!!!!!!!! Konnte mefprint-File nicht oeffnen!\n");
     return 0;
   }

   va_start(argpoint, fmt );
   vfprintf( file, fmt, argpoint );
   fflush(file);
   fclose(file);
   va_end(argpoint);
   return 0;
}

