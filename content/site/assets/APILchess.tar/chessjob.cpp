#define _MAIN
#include "chessjob.h"
#include "localvariables.h"

ChessJob::~ChessJob() 
{
  LocalVariables *lvp;
  while(!ParSt.Empty()) {
    lvp = ParSt.Pop();
    // send STOP to network
    delete lvp;
  }
}

void ChessJob::Test(void)
{
  int x5=5,x4=4,*x5p;
  int i;

  for (i = 0;i < 100;i++) {
    x5p = &x4;
    if (rand()%2 == 0) TestSt.Push(&x5);
    else if (!TestSt.Empty()) x5p=TestSt.Pop();
    fprintf(stderr,"%d, %d\n",TestSt.CountItems(),*x5p);
    fflush(stderr);
  }
  
  TestSt.~ParStack();
  fprintf(stderr,"%d, %d\n",TestSt.CountItems(),-10);
  fflush(stderr);
}
