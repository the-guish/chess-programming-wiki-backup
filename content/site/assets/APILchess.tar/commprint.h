#ifndef COMMPRINT
#define COMMPRINT
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
/**
*/

class CommPrint 
{
 public : int mefprint(int ID, char *fmt ... );
          void reverse(char*);
          void itoa(int, char*);
};	  


#endif
