#ifndef PARSTACK
#define PARSTACK

#include <stddef.h>

#ifdef _MAIN
void *free_par_item = NULL;
#else
extern void *free_par_item;
#endif

template <class T> class ParItem
{
  private:

  public :
    ParItem<T>* prev;
    ParItem<T>* next;
    T* item;

    void* operator new(size_t s);
    void operator delete(void* p, size_t s);
};

template <class T> void* ParItem<T>::operator new(size_t s) 
{
   ParItem<T> *j;
   
   if (free_par_item==0L) {
     j = (ParItem<T>*)malloc(s);
   } else {
     j = (ParItem<T>*)free_par_item;
     free_par_item = (void*)(((ParItem<T>*)free_par_item)->next);
   }
   return (void*)j;
}

template <class T> void ParItem<T>::operator delete(void* p, size_t s) 
{
  ParItem<T> *j = (ParItem<T>*)p;
  if (free_par_item==0L) {
    j->next = 0L;
    free_par_item = (void*)j;
  } else {
    j->next = (ParItem<T>*)free_par_item;
    free_par_item = (void*)j;
  }
}

template <class T> class ParStack
 {
  private:

  public :
            ParItem<T>*first;
            ParItem<T>*last;
            ParItem<T>*current;

            ParStack(){ first = last = current = NULL; }
           ~ParStack(){
              while(first) Pop();
            }

            int CountItems(void);
            void Push(T *stp);
	    T* Pop();
	    int Empty();
	    T* GetCurStEl( void );
	    T* GetLstStEl( void );
 };

template <class T> int ParStack<T>::Empty( void )
{
  if (last) return 0;
  return 1;
}

template <class T> int ParStack<T>::CountItems( void )
{
  int i=0;
  ParItem<T> *pt=first;
  while (pt) {
    i++;
    pt=pt->next;
  }
  return i;
}

template <class T> T* ParStack<T>::GetCurStEl( void )
{
  return current->item;
}

template <class T> T* ParStack<T>::GetLstStEl( void )
{
  return last->item;
}

template <class T> void ParStack<T>::Push(T *stp)
{
  ParItem<T> *lstSt;

  if (!last) {
    lstSt = new ParItem<T>;
    lstSt->next = lstSt->prev = NULL;
    lstSt->item = stp;
    first = lstSt;
    last = lstSt;
    current = lstSt;
  } else {
    lstSt = new ParItem<T>;
    lstSt->next = lstSt->prev = NULL;
    lstSt->item = stp;
    last->next = lstSt;
    lstSt->prev = last;
    last = current = lstSt;
  }
}

template <class T> T* ParStack<T>::Pop(void)
{
  ParItem<T> *lstSt;
  T *item;

  lstSt = last;
  last = last->prev;
  current = last;
  if (last == NULL) {
    first = NULL;
    current = NULL;
  } else {
    last->next = NULL;
    lstSt->prev = NULL;
  }
  item = lstSt->item;
  delete lstSt;
  return item;
}

#endif

