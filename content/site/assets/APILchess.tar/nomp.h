#ifndef _NOMP
#define _NOMP

#define MPI_COMM_WORLD 0
#define MPI_BYTE 0
#define MPI_ANY_TAG 0
#define MPI_ANY_SOURCE 0

typedef struct MPI_Status_t 
{
  int MPI_SOURCE;
  int MPI_TAG;
  int MPI_ERROR;
} MPI_Status;

typedef struct MPI_Request_t 
{
  int MPI_SOURCE;
} MPI_Request;

void MPI_Init(int*, char***);
void MPI_Buffer_attach(void*,int);
void MPI_Comm_rank(int, int*);
void MPI_Comm_size(int, int*);
void MPI_Wait(MPI_Request *, MPI_Status*);
void MPI_Barrier(int);
void MPI_Finalize(void);
void MPI_Ibsend(void *, int, int , int, int, int, MPI_Request *);
void MPI_Isend(void *, int, int , int, int, int, MPI_Request *);
void MPI_Irecv(void *, int , int , int , int , int, MPI_Request*);
void MPI_Iprobe(int , int, int, int*, MPI_Status*);
void MPI_Test(MPI_Request*, int *, MPI_Status*);

#endif
