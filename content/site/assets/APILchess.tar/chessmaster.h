#ifndef CHESSMASTER
#define CHESSMASTER
#include "basic_types.h"
#include "statistics.h"
#include "master.h"
#include "localvariables.h"

/**
*/

class ChessMaster:public Master
 {
  public :  ChessMaster(){}
           ~ChessMaster(){}

	    char* GetToken(char *token, char* str);
	    void DoStep(Communicator*);
	    int UserCommando(Communicator*, char*);
	    void UserMessage(Communicator*, class Communicator::Message*);

            void Deliver(LocalVariables*, Communicator *C, int32);
#ifdef HYDRA_ACTIVE
	    int StartFurtherIteration(int cnt_mvs,int depth,int trivialflg,int val,int prvval, int cnt_mainline, int64 cnt_nodes, int64 cnt_fstsuc); 
	    void SetResponseTime(int legalmvs,int mvnr,int trivialmv, int sudden_death, int rem_time, int time_inc, int movestogo);
	    void ResetTime(void);
	    unsigned int32 GetElapsedTime(void);
	    void AddExtrTime(int mult,int div);
	    void SetExtrTime(int mult,int div);
	    int ChangeResponseTime(int mult,int div);
	    void ClrExtrTime( void );
	    unsigned int32 GetTime(void);
	    int TimeOut(void);
#endif
	    int16 GetFHbeta(int16 alpha,int16 beta);
	    int16 GetFLalpha(int16 alpha,int16 beta);

	    int Ping(class Communicator::Message* mess); 
	    int Echo(class Communicator::Message* mess); 
 };
#endif

