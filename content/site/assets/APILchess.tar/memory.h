
/**
*/

class Memory {
  int m;
};
