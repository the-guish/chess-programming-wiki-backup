#include "chessmaster.h"
#include "chessjob.h"
#include "localvariables.h"
#include "hash.h"
#include "messages.h"
#ifdef HYDRA_ACTIVE
#include "chesscommunicator.h"
#endif
#ifdef LINUX
#include <unistd.h>
#endif
#ifdef WIN32
#define sleep(a) 
#include <direct.h>
#define getcwd _getcwd
#endif

static Job_Container jobs;
static ChessJob hyd;
static GameHistory GamHist[1000];
static time_t tim;
static Hashtable *H=NULL;

#define SE_ASPWIN    32
#define SE_NORMAL     0
#define SE_DEPTH      1
#define SE_NODES      2
#define SE_MOVE_TIME  3
#define SE_UNLIMITED  4
#define SE_MAXDEPTH  32

#define NOFAIL   0
#define FAILHIGH 1
#define FAILLOW  2

#define minimum(a,b) ((a) < (b) ? (a) : (b))
#define maximum(a,b) ((a) > (b) ? (a) : (b))

static int debug_mode=false;
static int UCI_mode=false;
static int se_movestogo=-255;
static int se_wtime=0;
static int se_btime=0;
static int se_winc=0;
static int se_binc=0;
static int se_stop=false;
static int se_depth=0;
static int se_fail=NOFAIL;

static int pondering=false;
static int search_mode=SE_NORMAL;

static int se_online=0;
static int IterationCounter=0;

static int16 result;
static Move prevMov;
static int16 alpha,beta;
static char nodes[100];

static Move RootMoves[250];
static Move RootXMoves[50];
static int64 RootNodeCnt[300];
static int CntRootMoves;
static int CntRootXMoves;
static int CntLegalRootMoves;
static int RootJobID;
static Move bRMv;

static int WaitForISREADYMessages=0;
static int WaitForORACLEMessages=0;

void ChessMaster::DoStep(Communicator* C)
{
  ChessJob *chessjob;

  if (se_online) {
    chessjob = (ChessJob*)jobs.SelectJob();
    if (!pondering && TimeOut() && chessjob && chessjob->CntPVLine()>0) {
      se_stop = true;
      printf("info string TIMEOUT!!\n");
      fflush(stdout);
    }
    if (chessjob) {
      if (se_stop) {
        se_stop = false;
        if (chessjob->jid == RootJobID && chessjob->CntPVLine()>0) {
	  static class Communicator::Message StatMess;
          StatMess.mh.dest = 1;
          StatMess.mh.srce = 0;
	  StatMess.mh.cmd = ALIVECHECK;
	  Ping(&StatMess);
	  if (C->GetN() > 1) C->Send(&StatMess);
          else Echo(&StatMess);
          result = -result;
          if (!chessjob->WTM) result = -result;
	  printf("info score cp %d depth %d time %ld pv %s\n",
                  ((long)result*1L)/1L,se_depth,GetElapsedTime(),
                  chessjob->PVline2Str());
	  printf("bestmove %s ",chessjob->Move2Str(&(chessjob->PVtbl[0])));
	  if (chessjob->CntPVLine()>1) printf("ponder %s\n",chessjob->Move2Str(&(chessjob->PVtbl[1])));
          else printf("\n");
	  fflush(stdout);
	}
	while (!chessjob->ParSt.Empty()) {
	  LocalVariables *lLV = chessjob->ParSt.Pop();
	  if (lLV->status & REKURSION_4)
	    chessjob->UndoMove(&lLV->nullmove, lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
			       &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
	  else if (lLV->status & REKURSION) 
	    chessjob->UndoMove(&lLV->curMv, lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
			       &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
	  Deliver(lLV,C,chessjob->IterationCnt);
	  delete lLV;
	}
	//Do not forget to undo the search-history moves!!
	for (int i = chessjob->search_history_length-1; i >= 0; i--) {
	  chessjob->UndoMove(
			     &(chessjob->search_history[i].mv),
			     chessjob->search_history[i].Xpc, 
			     &chessjob->en_passent, 
			     chessjob->search_history[i].ep, 
			     &chessjob->castle_state, 
			     chessjob->search_history[i].castle, 
			     chessjob->search_history[i].WTM, 
			     true);
	  chessjob->WTM = chessjob->search_history[i].WTM;
	}
	jobs.Release_Job(chessjob);
	delete chessjob;
      } else if (!chessjob->ParSt.Empty()) {
        while(!chessjob->ParSt.Empty()) {
	  (chessjob)->AlphabetaStep(&chessjob->ParSt,H);
          if (!chessjob->ParSt.Empty() && (chessjob->ParSt.last->item->status & (SYNC|START))) break;
	}
      } else if (chessjob->jid == RootJobID) {
	static class Communicator::Message StatMess;
	StatMess.mh.dest = 1;
	StatMess.mh.srce = 0;
	StatMess.mh.cmd = ALIVECHECK;
	Ping(&StatMess);
	if (C->GetN() > 1) C->Send(&StatMess);
	else Echo(&StatMess);
	result = -result;
        if (!chessjob->WTM) result = -result;
        printf("info score cp %d depth %d time %ld pv %s\n",
                ((long)result*1L)/1L,se_depth,GetElapsedTime(),
                chessjob->PVline2Str());
	fflush(stdout);
        if (((chessjob->WTM && result <= alpha) || (!chessjob->WTM && result >= beta)) && se_fail != FAILHIGH) {
	  // fail low
          int16 newASP=GetFLalpha(alpha,beta);
          AddExtrTime(4,1);
          if (chessjob->WTM) {
	    beta = maximum(result+1,-INFTY);
	    alpha = beta-newASP;
	    alpha = maximum(alpha,-INFTY);
	  } else {
	    alpha = result-1;
	    beta = alpha+newASP;
	    beta = minimum(beta,INFTY);
	  }
	  hyd.InitLimits(se_depth+11, IterationCounter);
	  chessjob->InitLimits(se_depth+11, IterationCounter++);
	  for (int k=0;k<300;k++) RootNodeCnt[k]=0;
	  if (chessjob->WTM) chessjob->ParSt.Push(new LocalVariables(alpha,beta,se_depth,0,&prevMov,chessjob->WTM,&result, START,1, &RootNodeCnt[0], 0,0,&bRMv,0,0,0));
          else               chessjob->ParSt.Push(new LocalVariables(-beta,-alpha,se_depth,0,&prevMov,chessjob->WTM,&result, START,1, &RootNodeCnt[0], 0,0,&bRMv,0,0,0));
          se_fail = FAILLOW;
	  printf("info string fail low: set alpha := %d, beta := %d\n",alpha,beta);
	  fflush(stdout);
	} else if ((result >= beta && chessjob->WTM) || (result <= alpha && !chessjob->WTM)) {
	  //fail high
          int16 newASP=GetFLalpha(alpha,beta);
	  if (chessjob->WTM) {
	    alpha = result-1;
	    beta = alpha+newASP;
	    beta = minimum(beta,INFTY);
	  } else {
	    beta = maximum(result+1,-INFTY);
	    alpha = beta-newASP;
	    alpha = maximum(alpha,-INFTY);
	  }
	  hyd.InitLimits(se_depth+11, IterationCounter);
	  chessjob->InitLimits(se_depth+11, IterationCounter++);
	  for (int k=0;k<300;k++) RootNodeCnt[k]=0;
	  if (chessjob->WTM) chessjob->ParSt.Push(new LocalVariables(alpha,beta,se_depth,0,&prevMov,chessjob->WTM,&result, START,1, &RootNodeCnt[0], 0,0,&bRMv,0,0,0));
          else               chessjob->ParSt.Push(new LocalVariables(-beta,-alpha,se_depth,0,&prevMov,chessjob->WTM,&result, START,1, &RootNodeCnt[0], 0,0,&bRMv,0,0,0));
          se_fail = FAILHIGH;
	  printf("info string fail high: set alpha := %d, beta := %d\n",alpha,beta);
	  fflush(stdout);
	} else {
          int SFI;
          int64 SumOfNodes=0;
          for (int i = 0;i < CntLegalRootMoves;i++) SumOfNodes += RootNodeCnt[i];
          SFI = StartFurtherIteration(CntLegalRootMoves,se_depth,true,-result,-result/*prvval*/,
		         	      chessjob->PVLineIsEmpty()?0:1,SumOfNodes,RootNodeCnt[0]);
          if (se_depth < SE_MAXDEPTH) se_depth++;
	  else sleep(1);
	  if(pondering || SFI) {
            alpha = maximum(-INFTY,result-SE_ASPWIN);
	    beta = minimum(result+SE_ASPWIN,INFTY);
            hyd.InitLimits(se_depth+11, IterationCounter);
            chessjob->InitLimits(se_depth+11, IterationCounter++);
	    for (int k=0;k<300;k++) RootNodeCnt[k]=0;
	    if (chessjob->WTM) chessjob->ParSt.Push(new LocalVariables(alpha,beta,se_depth,0,&prevMov,chessjob->WTM,&result, START,1, &RootNodeCnt[0], 0,0,&bRMv,0,0,0));
	    else               chessjob->ParSt.Push(new LocalVariables(-beta,-alpha,se_depth,0,&prevMov,chessjob->WTM,&result, START,1, &RootNodeCnt[0], 0,0,&bRMv,0,0,0));
            se_fail = NOFAIL;
            printf("info string set alpha := %d, beta := %d\n",alpha,beta);
	    fflush(stdout);
	  } else {
	    printf("bestmove %s ",chessjob->Move2Str(&(chessjob->PVtbl[0])));
	    if (chessjob->CntPVLine()>1) printf("ponder %s\n",chessjob->Move2Str(&(chessjob->PVtbl[1])));
	    else printf("\n");
	    chessjob->PrintTypeCnt();
	    chessjob->PrintNodeCnt();
	    jobs.Release_Job(chessjob);
	    fflush(stdout);
            delete chessjob;
	  }
	}
      } else { jobs.Release_Job(chessjob);delete chessjob; }
    } else {
      SetAliveCheck(OFF,0);
      se_online = false;
    }
  } else se_stop = false;
}

int ChessMaster::UserCommando(Communicator* C, char* s)
{ 
  char *p,*q;
  char token[200];
  char substring[4000];
  Communicator::Message M;
  ChessJob *chessjob;
  LocalVariables *LV;
  int i;
  
  if (!strcmp(s,"USER")) { printf("Userkommando!\n");fflush(stdout);}
  
  C->mefprint(0,"%s\n",s);
  
  strcpy(token,"");
  strcpy(substring,"");
  p = GetToken(token,s);
  if (!strcmp(token,"stop")) {
    se_stop = true;
  } else if (!strcmp(token,"ponderhit")) {
    pondering = false;
  } else if (!strcmp(token,"quit")) {
    return 1;
  } else if (!strcmp(token,"TESTGO")) {
    tim = time(NULL);
    chessjob = new ChessJob;
    chessjob->SetGranularity(hyd.gran_con);
    jobs.Insert_Job(chessjob);
    p = GetToken(token,p);

    chessjob->SetupBoard(C, NULL, this, &(chessjob->ParSt),hyd.BoardData, hyd.en_passent, hyd.WTM, hyd. castle_state, hyd.Pieces, 
			 hyd.PieceCnt, hyd.game_history, hyd.game_history_length, hyd.hashvalue, hyd.pawnhash, hyd.MaterialSignatur,hyd.MatVal);
    chessjob->ClearNodes();
    chessjob->GuestSetup();
#ifdef GUEST
    printf("statische FPGA-Bewertung: %d\n",chessjob->HyW_FPGAEval(chessjob->WTM));
    fflush(stdout);
    prevMov.from = 0x0a;
    prevMov.to = prevMov.flag = 0;
    //printf("dynamische FPGA-Bewertung: %d\n",chessjob->HyW_FPGASearchRes(0,3,&prevMov,chessjob->WTM, chessjob->en_passent, &prevMov));

    prevMov.from = 0x0a;
    prevMov.to = prevMov.flag = 0;
    printf("dynamische FPGA-Bewertung: %d\n",chessjob->Alphabeta(-INFTY,INFTY,3,0,&prevMov,chessjob->WTM, 1, &RootNodeCnt[0], 0,0,&bRMv,H));
    fflush(stdout);
    for (int u = 0; u < 100;u++) chessjob->Alphabeta(-INFTY,INFTY,3,0,&prevMov,chessjob->WTM,1,&RootNodeCnt[0], 0,0,&bRMv,H);
    printf("dynamische FPGA-Bewertung: %d\n",chessjob->Alphabeta(-INFTY,INFTY,3,0,&prevMov,chessjob->WTM,1,&RootNodeCnt[0], 0,0,&bRMv,H));
    fflush(stdout);
#endif
    se_depth = 3;
    LV = new LocalVariables(alpha=-INFTY,beta=INFTY,se_depth,0,&prevMov,chessjob->WTM,&result, START, 1, &RootNodeCnt[0], 0,0,&bRMv,0,0,0);
    chessjob->ClearNodes();
    hyd.InitLimits(se_depth+11,IterationCounter);
    for (int k=0;k<300;k++) RootNodeCnt[k]=0;
    chessjob->InitLimits(se_depth+11,IterationCounter++);
    chessjob->ParSt.Push(LV);
    se_fail = NOFAIL;
    se_online = true;
    SetAliveCheck(ON,0);
    printf("done\n");
    fflush(stdout);
  } else if (!strcmp(token,"go")) {
    pondering = false;
    se_movestogo = -255;
    p = GetToken(token,p);
    while (strlen(token) > 0) {
      if (!strcmp(token,"ponder")) {
        pondering = true;
      } else if (!strcmp(token,"wtime")) {
        p = GetToken(token,p);
        sscanf(token,"%d",&se_wtime);
      } else if (!strcmp(token,"btime")) {
        p = GetToken(token,p);
        sscanf(token,"%d",&se_btime);
      } else if (!strcmp(token,"winc")) {
      } else if (!strcmp(token,"binc")) {
      } else if (!strcmp(token,"movestogo")) {
        p = GetToken(token,p);
        sscanf(token,"%d",&se_movestogo);
      } else if (!strcmp(token,"depth")) {
      } else if (!strcmp(token,"nodes")) {
      } else if (!strcmp(token,"mate")) {
      } else if (!strcmp(token,"movetime")) {
      } else if (!strcmp(token,"infinite")) {
      }
      p = GetToken(token,p);      
    }
    tim = time(NULL);
    chessjob = new ChessJob;
    RootJobID = chessjob->jid;
    for (int k=0;k<300;k++) RootNodeCnt[k]=0;
    chessjob->SetGranularity(hyd.gran_con);
    jobs.Insert_Job(chessjob);
    chessjob->SetupBoard(C, NULL, this, &(chessjob->ParSt),hyd.BoardData, hyd.en_passent, hyd.WTM, hyd. castle_state, hyd.Pieces, 
			 hyd.PieceCnt, hyd.game_history, hyd.game_history_length, hyd.hashvalue, hyd.pawnhash, hyd.MaterialSignatur,hyd.MatVal);
    chessjob->GuestSetup();
    chessjob->ClearNodes();
    se_depth = 3;
    chessjob->ClearPVLine();
    chessjob->ClearKillers();
    chessjob->ClearHistory();
    H->ClearHash(false);
    LV = new LocalVariables(alpha=-INFTY,beta=INFTY,se_depth,0,&prevMov,chessjob->WTM,&result, START, 1, &RootNodeCnt[0], 0,0,&bRMv,0,0,0);
    hyd.InitLimits(se_depth+11,IterationCounter);
    chessjob->InitLimits(se_depth+11,IterationCounter++);
    chessjob->ParSt.Push(LV);
    chessjob->GenerateMoves(RootMoves,RootXMoves,chessjob->WTM,&CntRootMoves,&CntRootXMoves);
    chessjob->ExtractLegalMoves(RootMoves,RootXMoves,chessjob->WTM,&CntRootMoves,&CntRootXMoves);
    CntLegalRootMoves = CntRootMoves+CntRootXMoves;
    SetResponseTime(CntLegalRootMoves,(chessjob->game_history_length+1)/2,CntLegalRootMoves > 1 ? false : true,
                    se_movestogo==-255,chessjob->WTM?se_wtime:se_btime,chessjob->WTM?se_winc:se_binc,se_movestogo);
    se_fail = NOFAIL;
    SetAliveCheck(ON,0);
    if (C->GetN() == 1) se_online = true;
    else {
      int i;
      class Communicator::Message m;
      Oracle O;
      O.hyd = hyd;
      for (i = 0;i < hyd.game_history_length;i++) O.gamehistory[i]=GamHist[i];
      for (i = 1;i < C->GetN();i++) {
	m.mh.cmd = ORACLE_MESSAGE;
	m.data = (char*)&O;
	m.mh.size=sizeof(Oracle);
	m.mh.srce = C->GetID();
	m.mh.dest = i;
	C->Send(&m);
      }
      WaitForORACLEMessages = C->GetN()-1;
    }
  } else if (!strcmp(token,"isready")) {
#ifdef GUEST
    char pathbuffer[1024];
#endif
    int i;
    class Communicator::Message m;
    for (i = 1;i < C->GetN();i++) {
      m.mh.cmd = ISREADY_MESSAGE;
      m.data = NULL;
      m.mh.size=0;
      m.mh.srce = C->GetID();
      m.mh.dest = i;
      C->Send(&m);
    }
    WaitForISREADYMessages = C->GetN()-1;
    if (H == NULL) {
#ifdef GUEST
      int lEresult;
      if (C->GetN() > 1) {
        printf("info string ID:%d 1-ID:%d\n",C->GetID(),1-C->GetID());
	fflush(stdout);
	lEresult = hyd.HyW_FPGALoadEngineByIndex(getcwd(pathbuffer, 1024),"Brutus.bit",C->GetID());
      } else lEresult = hyd.HyW_FPGALoadEngineByIndex(getcwd(pathbuffer, 1024),"Brutus.bit",1);
      if (!lEresult) C->mefprint(C->GetID(),"FPGA-Card-Error");
      else {
        hyd.HyW_FPGASetClockRate(27*1000000.0);
	C->mefprint(C->GetID(),"Successfully installed FPGA-Card\n");
      }
#endif
      H = new Hashtable(6000000,C);
#ifdef HYDRA_ACTIVE
      ((ChessCommunicator*)C)->SetHashtable(H);
#endif
      prevMov.from = 0x0a;
      prevMov.to = prevMov.flag = 0;
      hyd.SetGranularity(3);
    }
    if (C->GetN() == 1) printf("readyok\n");
    fflush(stdout);
  } else if (!strcmp(token,"debug")) {
    p = GetToken(token,p);
    if (!strcmp(token,"on")) debug_mode = true;
    else debug_mode = false;
  } else if (!strcmp(token,"MOVE")) {
    Move mv;
    int16 Xpc;
    
    p = GetToken(token,p);
    printf("'%s'\n",token);
    mv.from = (token[0] - 'a') + 0x70-0x10*(token[1] - '1');
    mv.to =   (token[2] - 'a') + 0x70-0x10*(token[3] - '1');
    mv.flag = 0;
    if ((hyd.Board[mv.from] & (wP|bP)) && !hyd.Board[mv.to] && column(mv.from) != column(mv.to))
      mv.flag |= EN_PASSENT;
    if ((hyd.Board[mv.from] & (wK|bK)) && abs(column(mv.from)-column(mv.to)) > 1)
      mv.flag |= CASTLE;
    if ((hyd.Board[mv.from] & (wP|bP)) && (line(mv.to)==line(A8) || line(mv.to) == line(A1))) {
      switch (token[4]) {
      case 'q':mv.flag |= PROM_Q;break;
      case 'Q':mv.flag |= PROM_Q;break;
      case 'r':mv.flag |= PROM_R;break;
      case 'R':mv.flag |= PROM_R;break;
      case 'B':mv.flag |= PROM_B;break;
      case 'b':mv.flag |= PROM_B;break;
      case 'N':mv.flag |= PROM_N;break;
      case 'n':mv.flag |= PROM_N;break;
      default:mv.flag |= PROM_Q;   
      }
    }
    hyd.game_history[hyd.game_history_length].hash = hyd.hashvalue;
    hyd.game_history[hyd.game_history_length].mv = mv;		   
    hyd.game_history_length++;
    hyd.DoMove(&mv, &Xpc, &hyd.castle_state, &hyd.en_passent,hyd.WTM, true);
    hyd.WTM = 1- hyd.WTM;
    hyd.PrintBoard();
    fflush(stdout);
  } else if (!strcmp(token,"uci")) {
    UCI_mode = true;
    printf("id author U. Lorenz, C. Donninger\n");
    printf("id name Hydra 1.0\n");
    printf("uciok\n");
    fflush(stdout);
  } else if (!strcmp(token,"NEW")) {
    p = GetToken(token,p);
    if (!strcmp(token,"chessjob")) {
      printf("Userkommando: NEW chessjob\n");
      chessjob = new ChessJob;
      chessjob->SetGranularity(-1000);
      jobs.Insert_Job(chessjob);
      for (i = 1;i < C->GetN();i++) {
	M.mh.cmd = NEW_CHESSJOB;
	M.data = NULL;
	M.mh.size = 0;
	M.mh.srce = 0;
	M.mh.dest = i;
	C->Send(&M);
      }
      //chessjob->Test();
    }
    fflush(stdout);
  } else if (!strcmp(token,"position")) {
    p = GetToken(token,p);
    q = strstr(s, "moves");
    if (q) {
      *q = 0;
      q+=5;
      strcpy(substring,q);
    }
    
    if (!strcmp(token,"fen")) {
      hyd.SetupBoard(C, NULL, this, &(hyd.ParSt),p,substring,GamHist);
      hyd.ClearNodes();
      printf("info string Userkommando: position fen %s\n",p);
    } else if (!strcmp(token,"startpos")) {
      hyd.SetupBoard(C, NULL, this, &(hyd.ParSt),substring,GamHist);
      hyd.ClearNodes();
      printf("info string Userkommando: %s\n",s);
    }
    fflush(stdout);
  } else if (!strcmp(token,"PRINT")) {
    p = GetToken(token,p);
    if (!strcmp(token,"position")) {
      sscanf(p,"%d",&i);
      if (i == 0) {
	Job *j;
	j = jobs.first;
	while (j) {
	  ((ChessJob*)j)->PrintBoard();
	  printf("\n");
	  j=j->next;
	}
	hyd.PrintBoard();
      } else {
	M.mh.cmd = PRINT_POS;
	M.data = NULL;
	M.mh.size = 0;
	M.mh.srce = 0;
	M.mh.dest = i;
	C->Send(&M);
      }
      printf("Userkommando: PRINT position %s\n",p);
    }
    fflush(stdout);
  }
  return 0;
}

int16 ChessMaster::GetFHbeta(int16 alpha,int16 beta)
{
  if (beta - alpha <= 64) return 2*64;
  if (beta - alpha <= 3*64) return 9*64;
  return 2000;
}

int16 ChessMaster::GetFLalpha(int16 alpha,int16 beta)
{
  if (beta - alpha <= 64) return 2*64;
  if (beta - alpha <= 3*64) return 9*64;
  return 2000;
}

static int32 message_code=0;
static Work workbuffer[MAX_SEARCH_DEPTH+1];
static Move tmpPVline[MAX_PVL+10];

void ChessMaster::UserMessage(Communicator* C, class Communicator::Message* M)
{
  // class Communicator::Message* m = new Communicator::Message;
  if (M->mh.cmd == NO_WORK_MESSAGE) {
    C->mefprint(C->GetID(),"Error: Got NO_WORK_MESSAGE\n");
  } else if (M->mh.cmd == WORK_MESSAGE) {
    C->mefprint(C->GetID(),"Error: Got Work\n");
  } else if (M->mh.cmd == REQUEST_MESSAGE) {
    Job *cj;
    ParItem<LocalVariables> *stp;
    int count,candidate,work_found=false;
   
    for (cj=jobs.first;cj;cj=cj->next) {
      for (count=0,stp = ((ChessJob*)cj)->mystack->first;stp;stp=stp->next,count++) {
	if (stp->item->status == REKURSION_7) {      // Internal Iterative Deepening
	} else if (stp->item->status == REKURSION_4) { //Nullmove
	} else if (stp->item->status & (/*REKURSION_3|REKURSION_5 | REKURSION_6*/REKURSION_2 | REKURSION_1)) {
	  //Nullmove-Research, Singular Extensions, Scout-Nullwindow-Search, Scout-Research 
	  if (/*stp->item->d > 0 &&*/ stp->item->i > 0 && stp->item->i+1 < stp->item->n+stp->item->xn) {
	    candidate = stp->item->i+1;
	    work_found = true;
	    while(stp->item->IsRemote[candidate]) {
	      candidate++;
              if (candidate >= stp->item->n+stp->item->xn) {
		work_found = false;
		break;
	      }
	    }
	    break;
	  }
	}
      }
      if (work_found) break;
    }
    
    if (work_found) {
      int i;
      Work *w;
      Move *mvs;
      class Communicator::Message m;
      int sizeof_message=sizeof(Work)+sizeof(Move)*(((ChessJob*)cj)->search_history_length+count+3);
      w = workbuffer;
      mvs = w->mvs = (Move*)(w+1);
//#define M_DEB
#ifdef M_DEB
      C->mefprint(C->GetID(),"------------------------------\n");      
      //char outstr[1000];
      //((ChessJob*)cj)->Board2Str(outstr);
      //C->mefprint(C->GetID(),"%s\n",outstr);
#endif
      m.mh.cmd = WORK_MESSAGE;
      m.data = (char*)w;
      m.mh.dest = M->mh.srce;
      m.mh.srce = C->GetID();
      m.mh.size = sizeof_message;

      w->code = message_code++;
      if (w->code == -1) w->code = message_code++;
      if (w->code ==  0) w->code = message_code++;

      //father's data
      w->stackpt = (void*)stp->item;
      w->d=stp->item->d;
      w->rd=stp->item->rd;
      w->nd=stp->item->nd;
      w->a=stp->item->a; 
      w->b=stp->item->b;
      w->s=stp->item->s;
      w->u=stp->item->u;
      w->o=stp->item->o;
      w->cntmvs=count+((ChessJob*)cj)->search_history_length;
      w->type=stp->item->node_type;
      w->ownext=stp->item->ownext;
      w->oppext=stp->item->oppext;
      w->PExtType=stp->item->PExtType;
      w->ExtType=stp->item->ExtType;
      w->extfound=stp->item->extfound;
      w->ext=stp->item->ext;
      w->extMv=stp->item->extMv;
      w->curMv=stp->item->curMv;
      w->mvnr=candidate;
      w->state=stp->item->status;
      w->IterationCounter=hyd.IterationCnt;
      w->LimitExtPly=hyd.LimitExtPly;
      for (i=0;i<((ChessJob*)cj)->search_history_length;i++) {
	(*mvs)=((ChessJob*)cj)->search_history[i].mv;
	//C->mefprint(C->GetID(),"%s ",((ChessJob*)cj)->Move2Str(mvs));
        mvs++;
      }
      for (i=0,stp = ((ChessJob*)cj)->mystack->first;i<count;stp=stp->next,i++) {      
	(*mvs)=stp->item->curMv;
#ifdef M_DEB
	C->mefprint(C->GetID(),"%s,%d,%d ",((ChessJob*)cj)->Move2Str(mvs),i,stp->item->status);
#endif
        mvs++;
      }
      (*mvs)=stp->item->l[candidate];
#ifdef M_DEB
      C->mefprint(C->GetID(),"%s,%d ",((ChessJob*)cj)->Move2Str(mvs),((ChessJob*)cj)->mystack->first->item->status);
      ChessJob *chessjob = (ChessJob*)cj;
      C->mefprint(C->GetID(),"\ngive away a:%d b:%d s:%d u:%d o:%d, an %d\n",w->a,
                                      w->b,w->s,w->u,w->o,m.mh.dest);
      C->mefprint(C->GetID(),"................................\n");
#endif
      mvs++;
      stp->item->IsRemote[candidate]=w->code;
      stp->item->RemoteProcs[candidate]=m.mh.dest;
      C->Send(&m);
    } else {
      class Communicator::Message m;
      m.mh.cmd = NO_WORK_MESSAGE;
      m.mh.dest = M->mh.srce;
      m.mh.srce = C->GetID();
      m.mh.size = 0;
      C->Send(&m);
    }
  } else if (M->mh.cmd == RESULT_MESSAGE) {
    Result *r = (Result*)(M->data);
    Move *mvs = (Move*)(r+1);r->mvs = mvs;
    ParItem<LocalVariables> *stp;
    Job *cj;
    ChessJob *chessjob;
    LocalVariables *LV;
    int lv_found=false;
    int i,iy;
    
    for (cj=jobs.first;cj;cj=cj->next) {
      for (stp = ((ChessJob*)cj)->mystack->first;stp;stp=stp->next) {
	if ((void*)(stp->item) == r->stackpt) {
	  LV = stp->item;
	  chessjob = (ChessJob*)cj;
	  lv_found = true;
	  break;
	}
      }
      if (lv_found) break;
    }
    
    if (lv_found) {
      for (i = 0;i < LV->n+LV->xn;i++) 
	if (LV->IsRemote[i]==r->code) {
	  LV->IsRemote[i] = -1;
          LV->ncount[i] = r->nodes;
#ifdef M_DEB
	  C->mefprint(C->GetID(),"Got the result: %d, r->state:%d LV->state%d r->code%d\n",r->v,r->state,LV->status,r->code);
#endif
	  if ((r->state & (REKURSION_1 | REKURSION_2)) && (LV->status & (REKURSION_1 | REKURSION_2 | SYNC_5))) {
	    if (r->v > -INFTY) LV->legals++;
	    //if (r->v > LV->u) LV->u = r->v;
	    //LV->o = LV->u+1;
	    if (r->v > LV->s) {
	      *(LV->pbMv) = r->mvs[0];
	      
              if ((r->mvs[0].from == 0 && r->mvs[0].to == 0))
                 C->mefprint(C->GetID(),"error:received a strange move!!\n");
              if (LV->d < MAX_PVL-1 && r->cntmvs > 0 ) {
		iy = chessjob->ComputeVIndex(LV->d);
                //save PV line
		for (i = 0;chessjob->PVtbl[iy+i].from != 255 && i < MAX_PVL+5;i++)
		  tmpPVline[i] = chessjob->PVtbl[iy+i];
                tmpPVline[i].from = 255;
		//sent line to PVtable
		chessjob->PVtbl[iy+i].from = 255;
		for (i = 0;i < r->cntmvs;i++)
		  chessjob->PVtbl[iy+i] = mvs[i];
		chessjob->PVtbl[iy+i].from = 255;
		chessjob->VarImproved(LV->d);
		//restore PV line
		for (i = 0; tmpPVline[i].from != 255 && i < MAX_PVL+5;i++)
		  chessjob->PVtbl[iy+i] = tmpPVline[i];
		chessjob->PVtbl[iy+i].from = 255;
//#define V_DEB
#ifdef V_DEB
		for (iy = 0;iy < chessjob->search_history_length;iy++)
		  C->mefprint(C->GetID(),"%s ",chessjob->Move2Str(&(chessjob->search_history[iy].mv)));
		C->mefprint(C->GetID(),"|");
		for (iy=0,stp = ((ChessJob*)cj)->mystack->first;stp->item != LV;stp=stp->next,iy++)
		  C->mefprint(C->GetID(),"%s ",((ChessJob*)cj)->Move2Str(&stp->item->curMv),iy,stp->item->status);
		C->mefprint(C->GetID(),"|");
		iy = chessjob->ComputeVIndex(LV->d-1);
                for (i = 0;chessjob->PVtbl[iy+i].from != 255;i++)
		  C->mefprint(C->GetID(),"%s ",chessjob->Move2Str(&chessjob->PVtbl[iy+i]));
		C->mefprint(C->GetID(),"\n");
#endif
	      }
	      if (r->cntmvs > 0) {
		LV->s = r->v;
		if (LV->d == 0) { 
		  printf("info score cp %d depth %d pv %s\n",LV->s,LV->rd,((ChessJob*)cj)->PVline2Str());
		  fflush(stdout);
		}
		if (LV->s >= LV->b) {
#ifdef V_DEB
		  C->mefprint(C->GetID(),"remote cutoff!!\n");
#endif
		  H->PushHash(LV->pbMv,FAILH, LV->b, LV->rd, true, r->hashvalue,r->cstle, r->ep, LV->WTM);
		  chessjob->InsertKiller(LV->d,LV->pbMv);      
		  chessjob->InsertHistory(r->nodes,LV->pbMv);
		  //now close all levels > d
		  while (chessjob->ParSt.last->item != LV) {
		    LocalVariables *lLV = chessjob->ParSt.Pop();
		    if (lLV->status & REKURSION_4)
		      chessjob->UndoMove(&lLV->nullmove, lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
					 &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
		    else if (lLV->status & REKURSION) 
		      chessjob->UndoMove(&lLV->l[lLV->i], lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
					 &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
		    for(int k=0;k<lLV->n;k++) (*lLV->counter)+=lLV->ncount[k];
		    (*lLV->counter)+=lLV->nmcount;
		    if (lLV->d == 0) for(int k=0;k<lLV->n;k++) lLV->counter[k]=lLV->ncount[k];
                    Deliver(lLV,C,chessjob->IterationCnt);
		    delete lLV;
		  }
		  //now return the result in level d
		  LV = chessjob->ParSt.Pop();
                  if (LV->status & REKURSION_4)
		    chessjob->UndoMove(&LV->nullmove, LV->xp, &(chessjob->en_passent), LV->save_ep , 
				       &(chessjob->castle_state), LV->save_casp, LV->WTM, true);
		  else if (LV->status & REKURSION) 
		    chessjob->UndoMove(&LV->l[LV->i], LV->xp, &(chessjob->en_passent), LV->save_ep , 
				       &(chessjob->castle_state), LV->save_casp, LV->WTM, true);

		  *LV->result = -LV->s;
		  for(int k=0;k<LV->n;k++) (*LV->counter)+=LV->ncount[k];
		  (*LV->counter)+=LV->nmcount;
		  if (LV->d == 0) for(int k=0;k<LV->n;k++) LV->counter[k]=LV->ncount[k];
		  Deliver(LV,C,chessjob->IterationCnt);
		  delete LV;
		  //StepRETURN(LV->s/*b*/,LV->result)
		}
	      } else C->mefprint(C->GetID(),"Result 1/2: improvement, but no move\n");
	    }
	  } else if (r->state == (REKURSION_3 | REKURSION_7)) {
	    if (r->v > LV->s) {
	      if (r->cntmvs > 0) {
		LV->bMv = *(LV->pbMv) = r->mvs[0];
		LV->bMcnt = LV->ncount[LV->i];
		LV->s = r->v;
		if (LV->s >= LV->b) {
		  //now close all levels > d
		  while (chessjob->ParSt.last->item != LV) {
		    LocalVariables *lLV = chessjob->ParSt.Pop();
		    if (lLV->status & REKURSION) 
		      chessjob->UndoMove(&lLV->l[lLV->i], lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
					 &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
		    for(int k=0;k<lLV->n;k++) (*lLV->counter)+=lLV->ncount[k];
		    (*lLV->counter)+=lLV->nmcount;
		    if (lLV->d == 0) for(int k=0;k<lLV->n;k++) lLV->counter[k]=lLV->ncount[k];
		    delete lLV;
		  }
		  //now return the result in level d
		  if (LV->status & REKURSION) 
		    chessjob->UndoMove(&LV->l[LV->i], LV->xp, &(chessjob->en_passent), LV->save_ep , 
				       &(chessjob->castle_state), LV->save_casp, LV->WTM, true);
		  LV->status = SYNC_3;
		  //break;
		}
	      } else C->mefprint(C->GetID(),"Result 3/7: improvement, but no move\n");	
	    }
	  } else if (r->state == REKURSION_5) { // Nullmove Repetition-Search
	    if (r->v > LV->s) {
	      if (r->cntmvs > 0) {
		*(LV->pbMv) = r->mvs[0];
		LV->s = r->v;
		if (LV->s >= LV->b) {
		  H->PushHash(LV->pbMv,FAILH, LV->b, LV->rd, true, r->hashvalue,r->cstle, r->ep, LV->WTM);
		  chessjob->InsertKiller(LV->d,LV->pbMv);      
		  chessjob->InsertHistory(r->nodes,LV->pbMv);
		  //now close all levels > d
		  while (chessjob->ParSt.last->item != LV) {
		    LocalVariables *lLV = chessjob->ParSt.Pop();
		    if (lLV->status & REKURSION) 
		      chessjob->UndoMove(&lLV->l[lLV->i], lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
					 &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
		    for(int k=0;k<lLV->n;k++) (*lLV->counter)+=lLV->ncount[k];
		    (*lLV->counter)+=lLV->nmcount;
		    if (lLV->d == 0) for(int k=0;k<lLV->n;k++) lLV->counter[k]=lLV->ncount[k];
		    delete lLV;
		  }
		  //now return the result in level d
		  if (LV->status & REKURSION) 
		    chessjob->UndoMove(&LV->l[LV->i], LV->xp, &(chessjob->en_passent), LV->save_ep , 
				       &(chessjob->castle_state), LV->save_casp, LV->WTM, true);
		  *LV->result = -LV->s;
		  for(int k=0;k<LV->n;k++) (*LV->counter)+=LV->ncount[k];
		  (*LV->counter)+=LV->nmcount;
		  if (LV->d == 0) for(int k=0;k<LV->n;k++) LV->counter[k]=LV->ncount[k];
		  delete LV;
		  //StepRETURN(LV->s/*b*/,LV->result)
		}
	      } else C->mefprint(C->GetID(),"Result 5: improvement, but no move\n");
	    }
	  } else if (r->state == REKURSION_6) {
	    if (r->v > LV->a) {
	      LV->j++;
	      if (LV->extMv.from == 255) {
		if (r->cntmvs > 0) LV->extMv = r->mvs[0];
		else C->mefprint(C->GetID(),"Result 6: improvement, but no move\n");
	      }
	    }
	    if (LV->j>1) {
	      //now close all levels > d
	      while (chessjob->ParSt.last->item != LV) {
		LocalVariables *lLV = chessjob->ParSt.Pop();
		if (lLV->status & REKURSION) 
		  chessjob->UndoMove(&lLV->l[lLV->i], lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
				     &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
		for(int k=0;k<lLV->n;k++) (*lLV->counter)+=lLV->ncount[k];
		(*lLV->counter)+=lLV->nmcount;
		if (lLV->d == 0) for(int k=0;k<lLV->n;k++) lLV->counter[k]=lLV->ncount[k];
		delete lLV;
	      }
	      //now incorporate the result in level d
	      if (LV->status & REKURSION) 
		chessjob->UndoMove(&LV->l[LV->i], LV->xp, &(chessjob->en_passent), LV->save_ep , 
				   &(chessjob->castle_state), LV->save_casp, LV->WTM, true);
	      LV->status = SYNC_4;
	      //break;
	    } 
	  } //else C->mefprint(C->GetID(),"fatal: have received REKURSION_X result\n");
	  break;
	}
    }
  } else if (M->mh.cmd == KILL_MESSAGE) {
    Job *cj;
    ChessJob *chessjob;
    for (cj=jobs.first;cj;cj=cj->next) {
      chessjob = ((ChessJob*)cj);
      if ((int32)M->mh.FreierPointer == chessjob->IterationCnt && M->mh.kennung == chessjob->start_code) {
	C->mefprint(C->GetID(),"found problem to stop\n");
	while (!chessjob->ParSt.Empty()) {
	  LocalVariables *lLV = chessjob->ParSt.Pop();
	  if (lLV->status & REKURSION_4)
	    chessjob->UndoMove(&lLV->nullmove, lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
			       &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
	  else if (lLV->status & REKURSION) 
	    chessjob->UndoMove(&lLV->curMv, lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
			       &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
	  Deliver(lLV,C,chessjob->IterationCnt);
	  delete lLV;
	}
	//Do not forget to undo the search-history moves!!
	for (int i = chessjob->search_history_length-1; i >= 0; i--) {
	  chessjob->UndoMove(
			     &(chessjob->search_history[i].mv),
			     chessjob->search_history[i].Xpc, 
			     &chessjob->en_passent, 
			     chessjob->search_history[i].ep, 
			     &chessjob->castle_state, 
			     chessjob->search_history[i].castle, 
			     chessjob->search_history[i].WTM, 
			     true);
	  chessjob->WTM = chessjob->search_history[i].WTM;
	}
	jobs.Release_Job(chessjob);
	delete chessjob;
      }
    }
  } else if (M->mh.cmd == ISREADY_MESSAGE) {
    WaitForISREADYMessages--;
    if (WaitForISREADYMessages==0) { printf("readyok\n");fflush(stdout); }
  } else if (M->mh.cmd == ORACLE_MESSAGE) {
    WaitForORACLEMessages--;
    if (WaitForORACLEMessages==0) se_online = true;
  } else if (M->mh.cmd == HASH_PUSH_MESSAGE) {
    HashPush *hp=(HashPush*)(M->data);
    H->PushHash(&hp->Mv,hp->Flgs,hp->Val,hp->rDepth,false,hp->Key,0,0,1);
  } else if (M->mh.cmd == HASH_EXT_PUSH_MESSAGE) {
    HashPushExtension *hep=(HashPushExtension*)(M->data);
    H->PushExt(hep->XrDepth,false,hep->XKey,0,0,1,&hep->XMv,hep->XFlgs);
  } else if (M->mh.cmd == HASH_QUERY) {
    class Communicator::Message m;
    HashQuery *HQ=(HashQuery*)(M->data);
    HashAnswer HA;
    HA.Key = HQ->Key;
    HA.hashcodeID= HQ->hashcodeID;
    HA.hflgs = HA.hXflgs = NO_ENTRY;
    H->SendQuery(HA.Key,0,0,1,false,0,&HA.hval,&HA.hrd,&HA.hflgs,&HA.hMv,&HA.hXflgs,&HA.hXMv,&HA.hXrd,0);
    if (HA.hflgs != NO_ENTRY || HA.hXflgs != NO_ENTRY) {
      m.mh.cmd = HASH_ANSWER;
      m.data = (char*)&HA;
      m.mh.size=sizeof(HashAnswer);
      m.mh.srce = C->GetID();
      m.mh.dest = M->mh.srce;
      ((Communicator*)C)->Send(&m);
    }
  } else if (M->mh.cmd == HASH_ANSWER) {
    HashAnswer *HA=(HashAnswer*)(M->data);
    Job *cj;
    ParItem<LocalVariables> *stp;
    LocalVariables* LV;
    int MustBeCancelled=1;
    for (cj=jobs.first;cj;cj=cj->next) {
      for (stp = ((ChessJob*)cj)->mystack->first;stp;stp=stp->next) {
	LV=stp->item;
	if (LV->hashcodeID == HA->hashcodeID) {
          LV->wait4hash = 0;
	  LV->hv = HA->hval;
	  LV->hrd  = HA->hrd;
	  LV->hf = HA->hflgs;
	  if (LV->hf != NO_ENTRY) LV->bMv  = HA->hMv;
	  LV->Xflgs = HA->hXflgs;
	  if (LV->Xflgs != NO_ENTRY) LV->extMv = HA->hXMv;
	  LV->Xhrd = HA->hXrd;
	  if (LV->hf != NO_ENTRY) {
            if (LV->status == REKURSION_1 || LV->status == REKURSION_2)
	      for (int ii = 0;ii <= LV->i;ii++)
                if (HA->hMv.from == LV->list[ii].from && HA->hMv.to == LV->list[ii].to) {MustBeCancelled = 0;break; }
	    if (LV->status == REKURSION_3 || LV->status == REKURSION_6 ||  LV->status == REKURSION_4 || 
		LV->status == REKURSION_5 || LV->status == REKURSION_7 || 
		((LV->status == REKURSION_1 || LV->status == REKURSION_2) && MustBeCancelled)) {
	      //now close all levels > d
	      while (((ChessJob*)cj)->ParSt.last->item != LV) {
		LocalVariables *lLV = ((ChessJob*)cj)->ParSt.Pop();
		if (lLV->status & REKURSION_4)
		  ((ChessJob*)cj)->UndoMove(&lLV->nullmove, lLV->xp, &(((ChessJob*)cj)->en_passent), lLV->save_ep , 
					    &(((ChessJob*)cj)->castle_state), lLV->save_casp, lLV->WTM, true);
		else if (lLV->status & REKURSION) 
		  ((ChessJob*)cj)->UndoMove(&lLV->l[lLV->i], lLV->xp, &(((ChessJob*)cj)->en_passent), lLV->save_ep , 
					    &(((ChessJob*)cj)->castle_state), lLV->save_casp, lLV->WTM, true);
		for(int k=0;k<lLV->n;k++) (*lLV->counter)+=lLV->ncount[k];
		(*lLV->counter)+=lLV->nmcount;
		if (lLV->d == 0) for(int k=0;k<lLV->n;k++) lLV->counter[k]=lLV->ncount[k];
		Deliver(lLV,C,((ChessJob*)cj)->IterationCnt);
		delete lLV;
	      }
	      //now return the result in level d
	      if (LV->status & REKURSION_4)
		((ChessJob*)cj)->UndoMove(&LV->nullmove, LV->xp, &(((ChessJob*)cj)->en_passent), LV->save_ep , 
					  &(((ChessJob*)cj)->castle_state), LV->save_casp, LV->WTM, true);
	      else if (LV->status & REKURSION) 
		((ChessJob*)cj)->UndoMove(&LV->l[LV->i], LV->xp, &(((ChessJob*)cj)->en_passent), LV->save_ep , 
					  &(((ChessJob*)cj)->castle_state), LV->save_casp, LV->WTM, true);
	      Deliver(LV,C,((ChessJob*)cj)->IterationCnt);
	      
	      LV->a = LV->store_a;
	      LV->b = LV->store_b;
	      LV->status = SYNC_1;
	    }
	  }
          return;
	}
      }
    }
  }
}

void ChessMaster::Deliver(LocalVariables *LV, Communicator *C, int32 ICnt)
{
  if (LV->status & (REKURSION|SYNC))
    for (int i=0;i < LV->n+LV->xn;i++)
      if (LV->IsRemote[i] != 0 && LV->IsRemote[i] != -1) {
	class Communicator::Message m;
	m.mh.cmd = KILL_MESSAGE;
	m.mh.dest = LV->RemoteProcs[i];
	m.mh.srce = C->GetID();
	m.mh.size = 0;
	m.mh.kennung = LV->IsRemote[i];
	m.mh.FreierPointer = (void*)ICnt;
	m.mh.size = 0;
	C->Send(&m);
      }
}

char* ChessMaster::GetToken(char *token, char* str)
{
  char* p=str;
  while(*p == ' ') p++;
  while(*p && *p != '\n' && *p != ' ' && *p != ',' && *p != '.' && *p != ';') *token++ = *p++;
  *token = 0;
  if (*p) p++;
  return p;
}
  
int ChessMaster::Ping(class Communicator::Message* mess)
{  
  ChessJob *chessjob=(ChessJob*)jobs.SelectJob();
  int32 nums=0;
  static Statistics mystats;
  mystats.nodes = chessjob->GetNodes();
  mess->mh.size = sizeof(Statistics);
  mess->data = (char*)(&mystats);
  //printf("info string local nodes: %ld\n",mystats.nodes);
  //for (int i=0;i < CntLegalRootMoves;i++) nums += RootNodeCnt[i];
  //printf("info string collected nodes: %ld\n",nums);
  return 0; 
}

int ChessMaster::Echo(class Communicator::Message* mess)
{
  Statistics *mystat = (Statistics *)mess->data;
  unsigned int i;
  
  if (mystat->nodes/1000000 > 0)
     sprintf(nodes,"%d%6d",(int)(mystat->nodes/1000000),(int)(mystat->nodes%1000000));
  else 
     sprintf(nodes,"%d",(int)(mystat->nodes%1000000));
  for (i = 0; i < strlen(nodes);i++) if (nodes[i] == ' ') nodes[i] = '0';
  printf("info nodes %s nps %ld\n",nodes,(GetElapsedTime()>1000?(int)(mystat->nodes/(GetElapsedTime()/1000)):0));
  fflush(stdout);
  return 0; 
}
