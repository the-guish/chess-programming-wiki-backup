#ifndef APILCHESSDEFS
#define APILCHESSDEFS

#include "basic_types.h"
#include "move.h"

#define MATE_VAL 7168 
#define INFTY 15000
static const int16 MaterialValues[] = {0,100,300,300,500,900,14000,-100,-300,-300,-500,-900,-14000};

//Piece-Representation on Board
#define  white    1
#define  black    0
#define  IL  0x8000
#define  wP       1
#define  wN       2
#define  wB       4
#define  wR       8
#define  wQ      16
#define  wK      32

#define  bP      64
#define  bN     128
#define  bB     256
#define  bR     512
#define  bQ    1024
#define  bK    2048

#define BLACK (bP|bN|bB|bR|bQ|bK)
#define WHITE (wP|wN|wB|wR|wQ|wK)

//Piece-Representation for Piecelists
#define  wPindex       1
#define  wNindex       2
#define  wBindex       3
#define  wRindex       4
#define  wQindex       5
#define  wKindex       6

#define  bPindex       7
#define  bNindex       8
#define  bBindex       9
#define  bRindex      10
#define  bQindex      11
#define  bKindex      12

//Castle Info
#define W_LONG  2
#define W_SHORT 1
#define B_LONG  8
#define B_SHORT 4

//Move Properties
#define EN_PASSENT  8
#define CASTLE     32
#define PROMOTION   7
#define PROM_Q      5
#define PROM_R      4
#define PROM_B      3
#define PROM_N      2
#define CAPTURE    64
#define PAWNMOVE  128

//Other
#define Linc      16
#define Cinc       1
#define A1H8inc   15
#define H1A8inc   17

#define NULLMOVE_SQ 0x0a
#define IsNullmove(a) ((a).from == 0x0a)

//Sqares
#define A8   0x00  
#define B8   0x01  
#define C8   0x02  
#define D8   0x03  
#define E8   0x04  
#define F8   0x05  
#define G8   0x06  
#define H8   0x07  

#define A7   0x10  
#define B7   0x11  
#define C7   0x12  
#define D7   0x13  
#define E7   0x14  
#define F7   0x15  
#define G7   0x16  
#define H7   0x17  

#define A6   0x20  
#define B6   0x21  
#define C6   0x22  
#define D6   0x23  
#define E6   0x24  
#define F6   0x25  
#define G6   0x26  
#define H6   0x27  

#define A5   0x30  
#define B5   0x31  
#define C5   0x32  
#define D5   0x33  
#define E5   0x34  
#define F5   0x35  
#define G5   0x36  
#define H5   0x37  

#define A4   0x40  
#define B4   0x41  
#define C4   0x42  
#define D4   0x43  
#define E4   0x44  
#define F4   0x45  
#define G4   0x46  
#define H4   0x47  

#define A3   0x50  
#define B3   0x51  
#define C3   0x52  
#define D3   0x53  
#define E3   0x54  
#define F3   0x55  
#define G3   0x56  
#define H3   0x57  

#define A2   0x60  
#define B2   0x61  
#define C2   0x62  
#define D2   0x63  
#define E2   0x64  
#define F2   0x65  
#define G2   0x66  
#define H2   0x67  

#define A1   0x70  
#define B1   0x71  
#define C1   0x72  
#define D1   0x73  
#define E1   0x74  
#define F1   0x75  
#define G1   0x76  
#define H1   0x77  

#endif
