#include "chessworker.h"
#include "chessjob.h"
#include "localvariables.h"
#include "hash.h"
#include "messages.h"
#ifdef HYDRA_ACTIVE
#include "chesscommunicator.h"
#endif
#ifdef LINUX
#include <unistd.h>
#endif
#ifdef WIN32
#include <direct.h>
#define getcwd _getcwd
#endif

static Job_Container jobs;
static ChessJob hyd;
static GameHistory GamHist[1000];
static Hashtable *H=NULL;

static int8 request_on_tour=false;
static int32 message_code=0;
static Work workbuffer[MAX_SEARCH_DEPTH+1];
static Result resultbuffer[MAX_SEARCH_DEPTH+1];

static int32 waitim=1;
static int32 waitcnt=1;

void ChessWorker::DoStep(Communicator* C)
{
  ChessJob *chessjob;

  chessjob = (ChessJob*)jobs.SelectJob();
  if (chessjob) {
    if (!chessjob->ParSt.Empty()) {
      while(!chessjob->ParSt.Empty()) {
	(chessjob)->AlphabetaStep(&chessjob->ParSt,H);
	if (!chessjob->ParSt.Empty() && (chessjob->ParSt.last->item->status & (SYNC|START))) break;
      }
    } else if ((chessjob->start_state & (REKURSION_1 | REKURSION_2)) &&
         chessjob->Rval > chessjob->start_u && chessjob->Rval < chessjob->start_b && 
         chessjob->start_mvnr > 0 && chessjob->research == false) {
      //if (chessjob->start_a != chessjob->start_u) C->mefprint(C->GetID(),"research %d; %d %d %d, %d %d\n",chessjob->start_d+chessjob->start_rd,
      //chessjob->start_u,chessjob->Rval,chessjob->start_o,chessjob->start_a,chessjob->start_b);
      chessjob->research = true;
      chessjob->ParSt.Push(
			   new LocalVariables(-chessjob->start_b,-chessjob->Rval,chessjob->start_rd-1,chessjob->start_d+1,
                            &(chessjob->search_history[chessjob->search_history_length-1].mv),chessjob->WTM,
                            &(chessjob->Rval), START,chessjob->NodeType(chessjob->start_type,chessjob->start_mvnr),
                            &(chessjob->NodeCnt),chessjob->start_oppext,
                            chessjob->start_ownext+((chessjob->start_extfound && chessjob->start_curFMv.from==chessjob->start_extMv.from 
                            && chessjob->start_curFMv.to==chessjob->start_extMv.to)?chessjob->start_ext:0),
                            &(chessjob->bRMv),chessjob->start_PExtType,chessjob->start_ExtType,
                            chessjob->search_history[chessjob->search_history_length-1].Xpc)
      );      
    } else {
      int i,iy;
      Result *r;
      Move *mvs;
      r = resultbuffer;
      mvs = r->mvs = (Move*)(r+1);
      class Communicator::Message m;
      r->nodes = chessjob->NodeCnt;
      r->code = chessjob->start_code;
      r->d = chessjob->start_d;
      r->v = chessjob->Rval;
      r->state = chessjob->start_state;
      r->mvnr = chessjob->start_mvnr;
      r->cntmvs = 0;
      if (r->d < MAX_PVL-1) {// a PV is not always available
	iy = chessjob->ComputeVIndex(r->d);
	for (i = 0;chessjob->PVtbl[iy+i].from != 255;i++)
	  mvs[i] = chessjob->PVtbl[iy+i];
	r->cntmvs = i;
        if (i < 1) C->mefprint(C->GetID(),"Fatal: start move is deleted\n");
        if (mvs[0].from != chessjob->search_history[chessjob->search_history_length-1].mv.from ||
            mvs[0].to != chessjob->search_history[chessjob->search_history_length-1].mv.to)
           C->mefprint(C->GetID(),"Fatal: move from father to this node is not clear\n");
      }
      mvs[0] = chessjob->search_history[chessjob->search_history_length-1].mv; //this should always be available
      if (r->cntmvs == 0) r->cntmvs = 1;
      
      if (mvs[0].from == 0 && mvs[0].to == 0)
        C->mefprint(C->GetID(),"Fatal: move from father to this node is empty\n");
//#define M_DEB
#ifdef M_DEB
      C->mefprint(C->GetID(),"+++++++++++++++++++++++++++++++\n");  
      for (i=0;i<r->cntmvs;i++) C->mefprint(C->GetID(),"%s ",chessjob->Move2Str(&mvs[i]));    
      C->mefprint(C->GetID(),"\n+++++++++++++++++++++++++++++++\n");  
#endif

      r->IterationCounter = chessjob->IterationCnt;
      r->stackpt = chessjob->MasterStackpt;
      r->hashvalue = chessjob->search_history[chessjob->search_history_length-1].hash;
      r->cstle = chessjob->search_history[chessjob->search_history_length-1].castle;
      r->ep = chessjob->search_history[chessjob->search_history_length-1].ep;

      //Do not forget to undo the search-history moves!!
      for (i = chessjob->search_history_length-1; i >= 0; i--) {
	chessjob->UndoMove(
            &(chessjob->search_history[i].mv),
	    chessjob->search_history[i].Xpc, 
	    &chessjob->en_passent, 
	    chessjob->search_history[i].ep, 
	    &chessjob->castle_state, 
	    chessjob->search_history[i].castle, 
	    chessjob->search_history[i].WTM, 
	    true);
         chessjob->WTM = chessjob->search_history[i].WTM;
      }

      m.mh.cmd = RESULT_MESSAGE;
      m.mh.srce = C->GetID();
      m.mh.dest = chessjob->MasterProc;
      m.mh.size = sizeof(Result)+(r->cntmvs+3)*sizeof(Move);
      m.data = (char*)r;
      C->Send(&m);
      //SendAnswer();
#ifdef M_DEB
      C->mefprint(C->GetID(),"finished a:%d b:%d s:%d u:%d o:%d res:%d re-s?:%d\n",chessjob->start_a,
                                      chessjob->start_b,chessjob->start_s,chessjob->start_u,chessjob->start_o,
                                      chessjob->Rval,chessjob->research);
#endif
      jobs.Release_Job(chessjob);
      delete chessjob;
    }
  } else if (C->GetN() > 1 && !request_on_tour) {
    if (waitim <= waitcnt) {
      class Communicator::Message m;
      int dest;
      
      m.mh.cmd = REQUEST_MESSAGE;
      m.mh.srce = C->GetID();
      dest = rand() % (C->GetN()-1);
      if (dest == C->GetID()) dest = C->GetN()-1;
      m.mh.dest = dest;
      m.mh.size = 0;
      C->Send(&m);
      request_on_tour = 1;
    } else {
      waitcnt++;
    }
  }
}

static ChessJob *oldchessjob=0;
static Move tmpPVline[MAX_PVL+10];

void ChessWorker::UserMessage(Communicator* C, class Communicator::Message* M)
{
  if (M->mh.cmd == NO_WORK_MESSAGE) {
    request_on_tour = 0;
    waitim *= 2;
    if (waitim > 10000) waitim = 10001;
    waitcnt=1;
  } else if (M->mh.cmd == WORK_MESSAGE) {
    ChessJob *chessjob;
    request_on_tour = 0;
    waitim=1;
    waitcnt=1;
#ifdef M_DEB
    C->mefprint(C->GetID(),"Got Work from %d\n",M->mh.srce);
#endif
    Work *w = (Work*)(M->data);
    Move *mvs = (Move*)(w+1);
    if (w->IterationCounter >= hyd.IterationCnt) {
      chessjob = new ChessJob;
      if (oldchessjob != chessjob) {
	if (oldchessjob != 0) C->mefprint(C->GetID(),"Error in Chessjob-Handling!\n");
	oldchessjob = chessjob;
	chessjob->SetGranularity(hyd.gran_con);
	jobs.Insert_Job(chessjob);
	chessjob->SetupBoard(C, this, NULL,&(chessjob->ParSt),hyd.BoardData, hyd.en_passent, hyd.WTM, hyd. castle_state, hyd.Pieces, 
			     hyd.PieceCnt, hyd.game_history, hyd.game_history_length, hyd.hashvalue, hyd.pawnhash, hyd.MaterialSignatur,hyd.MatVal);
      } else {
	jobs.Insert_Job(chessjob);
      }
      
      //chessjob->GuestSetup();
      chessjob->ClearPVLine();
      chessjob->research = false;
      chessjob->start_code = w->code;
      chessjob->start_type = w->type;
      chessjob->IterationCnt = w->IterationCounter;
      if (hyd.IterationCnt < chessjob->IterationCnt) hyd.IterationCnt = chessjob->IterationCnt;
      chessjob->start_state = w->state; //makes e.g. immediate research of negascout-research possible
      
      if (w->s > w->u) w->u = w->s;
      w->o = w->u + 1;
      
      chessjob->start_s = w->s;
      chessjob->start_a = w->a;
      chessjob->start_b = w->b;
      chessjob->start_d = w->d;
      chessjob->start_rd = w->rd;
      chessjob->start_nd = w->nd;
      chessjob->start_u = w->u;
      chessjob->start_o = w->o;
      chessjob->start_ownext = w->ownext;
      chessjob->start_oppext = w->oppext;
      chessjob->start_mvnr = w->mvnr;
      chessjob->start_ExtType = w->ExtType;
      chessjob->start_PExtType = w->PExtType;
      chessjob->start_extfound = w->extfound;
      chessjob->start_ext = w->ext;
      chessjob->start_extMv = w->extMv;
      chessjob->start_curFMv = w->curMv;
      chessjob->MasterProc = M->mh.srce;
      chessjob->MasterStackpt = w->stackpt;
      
      chessjob->InitLimits(w->LimitExtPly,w->IterationCounter);
      chessjob->bRMv.from = 255;
      chessjob->Rval = -INFTY;
      chessjob->NodeCnt = 0;
      chessjob->search_history_length = 0;
      
      //C->mefprint(C->GetID(),"------------------------------\n");
      //char outstr[5000];
      //chessjob->Board2Str(outstr);
      //C->mefprint(C->GetID(),"%s\n",outstr);
      while (chessjob->search_history_length<=w->cntmvs) {
	chessjob->search_history[chessjob->search_history_length].hash = chessjob->hashvalue;
	chessjob->search_history[chessjob->search_history_length].mv = *mvs;
	//C->mefprint(C->GetID(),"%s ",chessjob->Move2Str(&chessjob->search_history[chessjob->search_history_length].mv));
	chessjob->search_history[chessjob->search_history_length].WTM = chessjob->WTM;
	chessjob->search_history[chessjob->search_history_length].castle = chessjob->castle_state;
	chessjob->search_history[chessjob->search_history_length].ep = chessjob->en_passent;
	chessjob->DoMove(mvs,&chessjob->search_history[chessjob->search_history_length].Xpc, 
			 &chessjob->castle_state, &chessjob->en_passent,chessjob->WTM, true);
	chessjob->WTM = 1- chessjob->WTM;
	chessjob->search_history_length++;
	mvs++;
      }
      chessjob->AddVar(w->d,&(chessjob->search_history[chessjob->search_history_length-1].mv)); //enter the last move into PV table
      
      //chessjob->SHV2Str(outstr);
      //C->mefprint(C->GetID(),"%s\n",outstr);
      //int ixx=chessjob->ComputeVIndex(w->d);
      //for (int i = 0;chessjob->PVtbl[ixx+i].from != 255;i++) {
      //  C->mefprint(C->GetID(),"%s ",chessjob->Move2Str(&chessjob->PVtbl[ixx+i]));  
      //}
      //C->mefprint(C->GetID(),"%s\n",chessjob->Move2Str(&(chessjob->search_history[chessjob->search_history_length-1].mv)));       
      //C->mefprint(C->GetID(),"\n................................\n");
      if (chessjob->search_history_length <= 0) C->mefprint(C->GetID(),"fatal: got wrong work 1\n");
      
      if (w->state == REKURSION_5) {
	chessjob->ParSt.Push(
			     new LocalVariables(-w->b,-w->b+1,w->nd,w->d+1,&(chessjob->search_history[chessjob->search_history_length-1].mv),chessjob->WTM,
						&(chessjob->Rval), START,chessjob->NodeType(w->type,w->mvnr),&(chessjob->NodeCnt),w->oppext,w->ownext,
						&(chessjob->bRMv),w->PExtType,w->ExtType,chessjob->search_history[chessjob->search_history_length-1].Xpc)
			     );      
      } else if (w->state == REKURSION_6){
	chessjob->ParSt.Push(
			     new LocalVariables(-w->a-1,-w->a,w->nd,w->d+1,&(chessjob->search_history[chessjob->search_history_length-1].mv),chessjob->WTM,
						&(chessjob->Rval), START,chessjob->NodeType(w->type,w->mvnr),&(chessjob->NodeCnt),w->oppext,w->ownext,
						&(chessjob->bRMv),w->PExtType,w->ExtType,chessjob->search_history[chessjob->search_history_length-1].Xpc)
			     );      
      } else if (w->state & (REKURSION_1 | REKURSION_2)){
	chessjob->ParSt.Push(
			     new LocalVariables(-w->o,-w->u,w->rd-1,w->d+1,&(chessjob->search_history[chessjob->search_history_length-1].mv),chessjob->WTM,
						&(chessjob->Rval), START,chessjob->NodeType(w->type,w->mvnr),&(chessjob->NodeCnt),w->oppext,
						w->ownext+((w->extfound && w->curMv.from==w->extMv.from && w->curMv.to==w->extMv.to)?w->ext:0),
						&(chessjob->bRMv),w->PExtType,w->ExtType,chessjob->search_history[chessjob->search_history_length-1].Xpc)
			     );      
      } else if (w->state == REKURSION_3){
	chessjob->ParSt.Push(
			     new LocalVariables(-w->o,-w->u,w->nd,w->d+1,&(chessjob->search_history[chessjob->search_history_length-1].mv),chessjob->WTM,
						&(chessjob->Rval), START,chessjob->NodeType(w->type,w->mvnr),&(chessjob->NodeCnt),w->oppext,w->ownext,
						&(chessjob->bRMv),w->PExtType,w->ExtType,chessjob->search_history[chessjob->search_history_length-1].Xpc)
			     );      
      } else if (w->state == REKURSION_7){
	C->mefprint(C->GetID(),"fatal: have received REKURSION_7 work\n");
      }
    }
  } else if (M->mh.cmd == REQUEST_MESSAGE) {
    Job *cj;
    ParItem<LocalVariables> *stp;
    int count,candidate,work_found=false;
   
    for (cj=jobs.first;cj;cj=cj->next) {
      for (count=0,stp = ((ChessJob*)cj)->mystack->first;stp;stp=stp->next,count++) {
	if (stp->item->status == REKURSION_7) {      // Internal Iterative Deepening
	} else if (stp->item->status == REKURSION_4) { //Nullmove
	} else if (stp->item->status & (/*REKURSION_3 | REKURSION_5 | REKURSION_6 |*/REKURSION_2 | REKURSION_1)) {
	  //Nullmove-Research, Singular Extensions, Scout-Nullwindow-Search, Scout-Research 
	  if (stp->item->i > 0 && stp->item->i+1 < stp->item->n+stp->item->xn) {
	    candidate = stp->item->i+1;
	    work_found = true;
	    while(stp->item->IsRemote[candidate]) {
	      candidate++;
              if (candidate >= stp->item->n+stp->item->xn) {
		work_found = false;
		break;
	      }
	    }
	    break;
	  }
	}
      }
      if (work_found) break;
    }
    
    if (work_found) {
      Work *w;
      Move *mvs;
      class Communicator::Message m;
      int i;
      int sizeof_message=sizeof(Work)+sizeof(Move)*(((ChessJob*)cj)->search_history_length+count+3);
      w = workbuffer;
      mvs = w->mvs = (Move*)(w+1);
      
      m.mh.cmd = WORK_MESSAGE;
      m.data = (char*)w;
      m.mh.dest = M->mh.srce;
      m.mh.srce = C->GetID();
      m.mh.size = sizeof_message;

      w->code = message_code++;
      if (w->code == -1) w->code = message_code++;
      if (w->code ==  0) w->code = message_code++;

      //father's data
      w->stackpt = stp->item;
      w->d=stp->item->d;
      w->rd=stp->item->rd;
      w->nd=stp->item->nd;
      w->a=stp->item->a; 
      w->b=stp->item->b;
      w->s=stp->item->s;
      w->u=stp->item->u;
      w->o=stp->item->o;
      w->cntmvs=count+((ChessJob*)cj)->search_history_length;
      w->type=stp->item->node_type;
      w->ownext=stp->item->ownext;
      w->oppext=stp->item->oppext;
      w->PExtType=stp->item->PExtType;
      w->ExtType=stp->item->ExtType;
      w->extfound=stp->item->extfound;
      w->ext=stp->item->ext;
      w->extMv=stp->item->extMv;
      w->curMv=stp->item->curMv;
      w->mvnr=candidate;
      w->state=stp->item->status;
      w->IterationCounter=hyd.IterationCnt;
      w->LimitExtPly=hyd.LimitExtPly;
      for (i=0;i<((ChessJob*)cj)->search_history_length;i++) {
	(*mvs)=((ChessJob*)cj)->search_history[i].mv;
        mvs++;
      }
      for (i=0,stp = ((ChessJob*)cj)->mystack->first;i<count;stp=stp->next,i++) {      
	(*mvs)=stp->item->curMv;
        mvs++;
      }
      (*mvs)=stp->item->l[candidate];
#ifdef M_DEB
      C->mefprint(C->GetID(),"%s,%d ",((ChessJob*)cj)->Move2Str(mvs),((ChessJob*)cj)->mystack->first->item->status);
      ChessJob *chessjob = (ChessJob*)cj;
      C->mefprint(C->GetID(),"\ngive away a:%d b:%d s:%d u:%d o:%d, an %d\n",w->a,
                                      w->b,w->s,w->u,w->o,m.mh.dest);
      C->mefprint(C->GetID(),"................................\n");
#endif
      mvs++;
      stp->item->IsRemote[candidate]=w->code;
      stp->item->RemoteProcs[candidate]=m.mh.dest;
      C->Send(&m);
    } else {
      class Communicator::Message m;
      m.mh.cmd = NO_WORK_MESSAGE;
      m.mh.dest = M->mh.srce;
      m.mh.srce = C->GetID();
      m.mh.size = 0;
      C->Send(&m);
    }
  } else if (M->mh.cmd == RESULT_MESSAGE) {
    Result *r = (Result*)(M->data);
    Move *mvs = (Move*)(r+1);r->mvs = mvs;
    ParItem<LocalVariables> *stp;
    Job *cj;
    ChessJob *chessjob;
    LocalVariables *LV;
    int lv_found=false;
    int i,iy;
    
    for (cj=jobs.first;cj;cj=cj->next) {
      for (stp = ((ChessJob*)cj)->mystack->first;stp;stp=stp->next) {
	if ((void*)(stp->item) == r->stackpt) {
	  LV = stp->item;
	  chessjob = (ChessJob*)cj;
	  lv_found = true;
	  break;
	}
      }
      if (lv_found) break;
    }
    
    if (lv_found) {
      for (i = 0;i < LV->n+LV->xn;i++) 
	if (LV->IsRemote[i]==r->code) {
	  LV->IsRemote[i] = -1;
          LV->ncount[i] = r->nodes;
#ifdef M_DEB
	  C->mefprint(C->GetID(),"Got the result: %d, r->state:%d LV->state%d r->code%d\n",r->v,r->state,LV->status,r->code);
#endif
	  if ((r->state & (REKURSION_1 | REKURSION_2)) && (LV->status & (REKURSION_1 | REKURSION_2 | SYNC_5))) {
	    if (r->v > -INFTY) LV->legals++;
            // be careful! the u and o variables are dangerous!!
              // e.g.: u = v => normal search may be hindered of an important research
	      //if (r->v > LV->u) LV->u = r->v;
	      //LV->o = LV->u+1;
	    if (r->v > LV->s) {
	      *(LV->pbMv) = r->mvs[0];

              if ((r->mvs[0].from == 0 && r->mvs[0].to == 0))
                 C->mefprint(C->GetID(),"error:received a strange move!!\n");
              if (LV->d < MAX_PVL-1 && r->cntmvs > 0) {
		iy = chessjob->ComputeVIndex(LV->d);
                //save PV line
		for (i = 0;chessjob->PVtbl[iy+i].from != 255 && i < MAX_PVL+5;i++)
		  tmpPVline[i] = chessjob->PVtbl[iy+i];
                tmpPVline[i].from = 255;
		//sent line to PVtable
		chessjob->PVtbl[iy+i].from = 255;
		for (i = 0;i < r->cntmvs;i++)
		  chessjob->PVtbl[iy+i] = mvs[i];
		chessjob->PVtbl[iy+i].from = 255;
		chessjob->VarImproved(LV->d);
		//restore PV line
		for (i = 0; tmpPVline[i].from != 255 && i < MAX_PVL+5;i++)
		  chessjob->PVtbl[iy+i] = tmpPVline[i];
		chessjob->PVtbl[iy+i].from = 255;
//#define V_DEB
#ifdef V_DEB
		for (iy = 0;iy < chessjob->search_history_length;iy++)
		  C->mefprint(C->GetID(),"%s ",chessjob->Move2Str(&(chessjob->search_history[iy].mv)));
		C->mefprint(C->GetID(),"|");
		for (iy=0,stp = ((ChessJob*)cj)->mystack->first;stp->item != LV;stp=stp->next,iy++)
		  C->mefprint(C->GetID(),"%s ",((ChessJob*)cj)->Move2Str(&stp->item->curMv),iy,stp->item->status);
		C->mefprint(C->GetID(),"|");
		iy = chessjob->ComputeVIndex(LV->d-1);
                for (i = 0;chessjob->PVtbl[iy+i].from != 255;i++)
		  C->mefprint(C->GetID(),"%s ",chessjob->Move2Str(&chessjob->PVtbl[iy+i]));
		C->mefprint(C->GetID(),"\n");
#endif
	      }
	      if (r->cntmvs > 0) {
		LV->s = r->v;
		if (LV->s >= LV->b) {
#ifdef V_DEB
		  C->mefprint(C->GetID(),"remote cutoff!!\n");
#endif
		  H->PushHash(LV->pbMv,FAILH, LV->b, LV->rd, true, r->hashvalue,r->cstle, r->ep, LV->WTM);
		  chessjob->InsertKiller(LV->d,LV->pbMv);      
		  chessjob->InsertHistory(r->nodes,LV->pbMv);
		  //now close all levels > d
		  while (chessjob->ParSt.last->item != LV) {
		    LocalVariables *lLV = chessjob->ParSt.Pop();
		    if (lLV->status & REKURSION_4)
		      chessjob->UndoMove(&lLV->nullmove, lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
					 &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
		    else if (lLV->status & REKURSION) 
		      chessjob->UndoMove(&lLV->l[lLV->i], lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
					 &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
		    for(int k=0;k<lLV->n;k++) (*lLV->counter)+=lLV->ncount[k];
		    (*lLV->counter)+=lLV->nmcount;
		    if (lLV->d == 0) for(int k=0;k<lLV->n;k++) lLV->counter[k]=lLV->ncount[k];
                    Deliver(lLV,C,chessjob->IterationCnt);
		    delete lLV;
		  }
		  //now return the result in level d
		  LV = chessjob->ParSt.Pop();
                  if (LV->status & REKURSION_4)
		    chessjob->UndoMove(&LV->nullmove, LV->xp, &(chessjob->en_passent), LV->save_ep , 
				       &(chessjob->castle_state), LV->save_casp, LV->WTM, true);
		  else if (LV->status & REKURSION) 
		    chessjob->UndoMove(&LV->l[LV->i], LV->xp, &(chessjob->en_passent), LV->save_ep , 
				       &(chessjob->castle_state), LV->save_casp, LV->WTM, true);
		  *LV->result = -LV->s;
		  for(int k=0;k<LV->n;k++) (*LV->counter)+=LV->ncount[k];
		  (*LV->counter)+=LV->nmcount;
		  if (LV->d == 0) for(int k=0;k<LV->n;k++) LV->counter[k]=LV->ncount[k];
		  Deliver(LV,C,chessjob->IterationCnt);
		  delete LV;
		  //StepRETURN(LV->s/*b*/,LV->result)
		}
	      } else C->mefprint(C->GetID(),"Result 1/2: improvement, but no move\n");
	    }
	  } else if (r->state == (REKURSION_3 | REKURSION_7)) {
	    if (r->v > LV->s) {
	      if (r->cntmvs > 0) {
		LV->bMv = *(LV->pbMv) = r->mvs[0];
		LV->bMcnt = LV->ncount[LV->i];
		LV->s = r->v;
		if (LV->s >= LV->b) {
		  //now close all levels > d
		  while (chessjob->ParSt.last->item != LV) {
		    LocalVariables *lLV = chessjob->ParSt.Pop();
		    if (lLV->status & REKURSION) 
		      chessjob->UndoMove(&lLV->l[lLV->i], lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
					 &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
		    for(int k=0;k<lLV->n;k++) (*lLV->counter)+=lLV->ncount[k];
		    (*lLV->counter)+=lLV->nmcount;
		    if (lLV->d == 0) for(int k=0;k<lLV->n;k++) lLV->counter[k]=lLV->ncount[k];
		    delete lLV;
		  }
		  //now return the result in level d
		  if (LV->status & REKURSION) 
		    chessjob->UndoMove(&LV->l[LV->i], LV->xp, &(chessjob->en_passent), LV->save_ep , 
				       &(chessjob->castle_state), LV->save_casp, LV->WTM, true);
		  LV->status = SYNC_3;
		  //break;
		}
	      } else C->mefprint(C->GetID(),"Result 3/7: improvement, but no move\n");	
	    }
	  } else if ((r->state == REKURSION_5)  && (LV->status & (REKURSION_5 | SYNC_2))) { // Nullmove Repetition-Search
	    if (r->v > LV->s) {
	      if (r->cntmvs > 0) {
		*(LV->pbMv) = r->mvs[0];
		LV->s = r->v;
		if (LV->s >= LV->b) {
		  H->PushHash(LV->pbMv,FAILH, LV->b, LV->rd, true, r->hashvalue,r->cstle, r->ep, LV->WTM);
		  chessjob->InsertKiller(LV->d,LV->pbMv);      
		  chessjob->InsertHistory(r->nodes,LV->pbMv);
		  //now close all levels > d
		  while (chessjob->ParSt.last->item != LV) {
		    LocalVariables *lLV = chessjob->ParSt.Pop();
		    if (lLV->status & REKURSION) 
		      chessjob->UndoMove(&lLV->l[lLV->i], lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
					 &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
		    for(int k=0;k<lLV->n;k++) (*lLV->counter)+=lLV->ncount[k];
		    (*lLV->counter)+=lLV->nmcount;
		    if (lLV->d == 0) for(int k=0;k<lLV->n;k++) lLV->counter[k]=lLV->ncount[k];
		    delete lLV;
		  }
		  //now return the result in level d
		  if (LV->status & REKURSION) 
		    chessjob->UndoMove(&LV->l[LV->i], LV->xp, &(chessjob->en_passent), LV->save_ep , 
				       &(chessjob->castle_state), LV->save_casp, LV->WTM, true);
		  *LV->result = -LV->s;
		  for(int k=0;k<LV->n;k++) (*LV->counter)+=LV->ncount[k];
		  (*LV->counter)+=LV->nmcount;
		  if (LV->d == 0) for(int k=0;k<LV->n;k++) LV->counter[k]=LV->ncount[k];
		  delete LV;
		  //StepRETURN(LV->s/*b*/,LV->result)
		}
	      } else C->mefprint(C->GetID(),"Result 5: improvement, but no move\n");
	    }
	  } else if (r->state == REKURSION_6) {
	    if (r->v > LV->a) {
	      LV->j++;
	      if (LV->extMv.from == 255) {
		if (r->cntmvs > 0) LV->extMv = r->mvs[0];
		else C->mefprint(C->GetID(),"Result 6: improvement, but no move\n");
	      }
	    }
	    if (LV->j>1) {
	      //now close all levels > d
	      while (chessjob->ParSt.last->item != LV) {
		LocalVariables *lLV = chessjob->ParSt.Pop();
		if (lLV->status & REKURSION) 
		  chessjob->UndoMove(&lLV->l[lLV->i], lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
				     &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
		for(int k=0;k<lLV->n;k++) (*lLV->counter)+=lLV->ncount[k];
		(*lLV->counter)+=lLV->nmcount;
		if (lLV->d == 0) for(int k=0;k<lLV->n;k++) lLV->counter[k]=lLV->ncount[k];
		delete lLV;
	      }
	      //now incorporate the result in level d
	      if (LV->status & REKURSION) 
		chessjob->UndoMove(&LV->l[LV->i], LV->xp, &(chessjob->en_passent), LV->save_ep , 
				   &(chessjob->castle_state), LV->save_casp, LV->WTM, true);
	      LV->status = SYNC_4;
	      //break;
	    } 
	  } //else C->mefprint(C->GetID(),"fatal: have received REKURSION_X result\n");
	  break;
	}
    }
  } else if (M->mh.cmd == ISREADY_MESSAGE) {
#ifdef GUEST
    char pathbuffer[1024];
#endif
    if(H == NULL) {
#ifdef GUEST
      int lEresult = hyd.HyW_FPGALoadEngineByIndex(getcwd(pathbuffer, 1024),"Brutus.bit",C->GetID());
      if (!lEresult) C->mefprint(C->GetID(),"FPGA-Card-Error");
      else {
        hyd.HyW_FPGASetClockRate(27*1000000.0);
	C->mefprint(C->GetID(),"Successfully installed FPGA-Card\n");
      }
#endif
      H = new Hashtable(6000000,C);
#ifdef HYDRA_ACTIVE
      ((ChessCommunicator*)C)->SetHashtable(H);
#endif
    }
    class Communicator::Message m;
    m.mh.cmd = ISREADY_MESSAGE;
    m.mh.dest = M->mh.srce;
    m.mh.srce = C->GetID();
    m.mh.size = 0;
    C->Send(&m);
  } else if (M->mh.cmd == ORACLE_MESSAGE) {
    int i;
    oldchessjob = 0;
    ChessJob* Mhyd = &(((Oracle*)M->data)->hyd);
    //hyd = ((Oracle*)M->data)->hyd;
    hyd.SetupBoard(C, this, NULL, &(hyd.ParSt),Mhyd->BoardData, Mhyd->en_passent, Mhyd->WTM, Mhyd->castle_state, Mhyd->Pieces, 
			 Mhyd->PieceCnt, GamHist, Mhyd->game_history_length, Mhyd->hashvalue, Mhyd->pawnhash, Mhyd->MaterialSignatur,Mhyd->MatVal);

    hyd.InitLimits(Mhyd->LimitExtPly,Mhyd->IterationCnt);
    hyd.SetGranularity(Mhyd->gran_con);
    //hyd.search_history_length = 0;
    //hyd.InitBasics();
    //hyd.game_history = GamHist;
    for (i = 0;i < hyd.game_history_length;i++) GamHist[i] = ((Oracle*)M->data)->gamehistory[i];
    hyd.ClearKillers();
    hyd.ClearHistory();
    H->ClearHash(false);
    hyd.ClearNodes();
    class Communicator::Message m;
    m.mh.cmd = ORACLE_MESSAGE;
    m.mh.dest = M->mh.srce;
    m.mh.srce = C->GetID();
    m.mh.size = 0;
    C->Send(&m);
    hyd.GuestSetup();
  } else if (M->mh.cmd == KILL_MESSAGE) {
    Job *cj;
    ChessJob *chessjob;
    for (cj=jobs.first;cj;cj=cj->next) {
      chessjob = ((ChessJob*)cj);
      if ((int32)M->mh.FreierPointer == chessjob->IterationCnt && M->mh.kennung == chessjob->start_code) {
	//C->mefprint(C->GetID(),"found problem to stop\n");
	while (!chessjob->ParSt.Empty()) {
	  LocalVariables *lLV = chessjob->ParSt.Pop();
	  if (lLV->status & REKURSION_4)
	    chessjob->UndoMove(&lLV->nullmove, lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
			       &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
	  else if (lLV->status & REKURSION) 
	    chessjob->UndoMove(&lLV->curMv, lLV->xp, &(chessjob->en_passent), lLV->save_ep , 
			       &(chessjob->castle_state), lLV->save_casp, lLV->WTM, true);
	  Deliver(lLV,C,chessjob->IterationCnt);
	  delete lLV;
	}
	//Do not forget to undo the search-history moves!!
	for (int i = chessjob->search_history_length-1; i >= 0; i--) {
	  chessjob->UndoMove(
			     &(chessjob->search_history[i].mv),
			     chessjob->search_history[i].Xpc, 
			     &chessjob->en_passent, 
			     chessjob->search_history[i].ep, 
			     &chessjob->castle_state, 
			     chessjob->search_history[i].castle, 
			     chessjob->search_history[i].WTM, 
			     true);
	  chessjob->WTM = chessjob->search_history[i].WTM;
	}
	jobs.Release_Job(chessjob);
	delete chessjob;
      }
    }
  } else if (M->mh.cmd == NEW_CHESSJOB) {
    ChessJob *chessjob;
    chessjob = new ChessJob;
    jobs.Insert_Job(chessjob);
  } else if (M->mh.cmd == PRINT_POS) {
    Job *j;
    j = jobs.first;
    while (j) {
      ((ChessJob*)j)->PrintBoard();
      printf("\n");
      j=j->next;
    }
  } else if (M->mh.cmd == HASH_PUSH_MESSAGE) {
    HashPush *hp=(HashPush*)(M->data);
    H->PushHash(&hp->Mv,hp->Flgs,hp->Val,hp->rDepth,false,hp->Key,0,0,1);
  } else if (M->mh.cmd == HASH_EXT_PUSH_MESSAGE) {
    HashPushExtension *hep=(HashPushExtension*)(M->data);
    H->PushExt(hep->XrDepth,false,hep->XKey,0,0,1,&hep->XMv,hep->XFlgs);
  } else if (M->mh.cmd == HASH_QUERY) {
    class Communicator::Message m;
    HashQuery *HQ=(HashQuery*)(M->data);
    HashAnswer HA;
    HA.Key = HQ->Key;
    HA.hashcodeID = HQ->hashcodeID;
    HA.hflgs = HA.hXflgs = NO_ENTRY;
    H->SendQuery(HA.Key,0,0,1,false,0,&HA.hval,&HA.hrd,&HA.hflgs,&HA.hMv,&HA.hXflgs,&HA.hXMv,&HA.hXrd,0);
    if (HA.hflgs != NO_ENTRY || HA.hXflgs != NO_ENTRY) {
      m.mh.cmd = HASH_ANSWER;
      m.data = (char*)&HA;
      m.mh.size=sizeof(HashAnswer);
      m.mh.srce = C->GetID();
      m.mh.dest = M->mh.srce;
      ((Communicator*)C)->Send(&m);
    }
  } else if (M->mh.cmd == HASH_ANSWER) {
    HashAnswer *HA=(HashAnswer*)(M->data);
    Job *cj;
    ParItem<LocalVariables> *stp;
    LocalVariables* LV;
    int MustBeCancelled=1;
    for (cj=jobs.first;cj;cj=cj->next) {
      for (stp = ((ChessJob*)cj)->mystack->first;stp;stp=stp->next) {
	LV=stp->item;
	if (LV->hashcodeID == HA->hashcodeID) {
          LV->wait4hash = 0;
	  LV->hv = HA->hval;
	  LV->hrd  = HA->hrd;
	  LV->hf = HA->hflgs;
	  if (LV->hf != NO_ENTRY) LV->bMv  = HA->hMv;
	  LV->Xflgs = HA->hXflgs;
	  if (LV->Xflgs != NO_ENTRY) LV->extMv = HA->hXMv;
	  LV->Xhrd = HA->hXrd;
	  if (LV->hf != NO_ENTRY) {
            if (LV->status == REKURSION_1 || LV->status == REKURSION_2)
	      for (int ii = 0;ii <= LV->i;ii++)
                if (HA->hMv.from == LV->list[ii].from && HA->hMv.to == LV->list[ii].to) {MustBeCancelled = 0;break; }
	    if (LV->status == REKURSION_3 || LV->status == REKURSION_6 ||  LV->status == REKURSION_4 || 
		LV->status == REKURSION_5 || LV->status == REKURSION_7 || 
		((LV->status == REKURSION_1 || LV->status == REKURSION_2) && MustBeCancelled)) {
	      //now close all levels > d
	      while (((ChessJob*)cj)->ParSt.last->item != LV) {
		LocalVariables *lLV = ((ChessJob*)cj)->ParSt.Pop();
		if (lLV->status & REKURSION_4)
		  ((ChessJob*)cj)->UndoMove(&lLV->nullmove, lLV->xp, &(((ChessJob*)cj)->en_passent), lLV->save_ep , 
					    &(((ChessJob*)cj)->castle_state), lLV->save_casp, lLV->WTM, true);
		else if (lLV->status & REKURSION) 
		  ((ChessJob*)cj)->UndoMove(&lLV->l[lLV->i], lLV->xp, &(((ChessJob*)cj)->en_passent), lLV->save_ep , 
					    &(((ChessJob*)cj)->castle_state), lLV->save_casp, lLV->WTM, true);
		for(int k=0;k<lLV->n;k++) (*lLV->counter)+=lLV->ncount[k];
		(*lLV->counter)+=lLV->nmcount;
		if (lLV->d == 0) for(int k=0;k<lLV->n;k++) lLV->counter[k]=lLV->ncount[k];
		Deliver(lLV,C,((ChessJob*)cj)->IterationCnt);
		delete lLV;
	      }
	      //now return the result in level d
	      if (LV->status & REKURSION_4)
		((ChessJob*)cj)->UndoMove(&LV->nullmove, LV->xp, &(((ChessJob*)cj)->en_passent), LV->save_ep , 
					  &(((ChessJob*)cj)->castle_state), LV->save_casp, LV->WTM, true);
	      else if (LV->status & REKURSION) 
		((ChessJob*)cj)->UndoMove(&LV->l[LV->i], LV->xp, &(((ChessJob*)cj)->en_passent), LV->save_ep , 
					  &(((ChessJob*)cj)->castle_state), LV->save_casp, LV->WTM, true);
	      Deliver(LV,C,((ChessJob*)cj)->IterationCnt);
	      
	      LV->a = LV->store_a;
	      LV->b = LV->store_b;
	      LV->status = SYNC_1;
	    }
	  }
          return;
	}
      }
    }
  }
}

void ChessWorker::Deliver(LocalVariables *LV, Communicator *C, int32 ICnt)
{
  if (LV->status & (REKURSION|SYNC))
    for (int i=0;i < LV->n+LV->xn;i++)
      if (LV->IsRemote[i] != 0 && LV->IsRemote[i] != -1) {
	class Communicator::Message m;
	m.mh.cmd = KILL_MESSAGE;
	m.mh.dest = LV->RemoteProcs[i];
	m.mh.srce = C->GetID();
	m.mh.size = 0;
	m.mh.kennung = LV->IsRemote[i];
	m.mh.FreierPointer = (void*)ICnt;
	m.mh.size = 0;
	C->Send(&m);
      }
}

void ChessWorker::PingEcho(class Communicator::Message* mess)
{
  ChessJob *chessjob=(ChessJob*)jobs.SelectJob();
  Statistics *mystats = (Statistics *)mess->data;
  mystats->nodes += chessjob->GetNodes();
}


