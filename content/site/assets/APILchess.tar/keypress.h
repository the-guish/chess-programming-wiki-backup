#ifndef KEYPRESS
#define KEYPRESS

#ifdef LINUX
#include <iostream.h>
#endif
#ifdef WIN32
#include <iostream>
#endif

class KeyPress
{

public: char commando[10000];
	
	long keypress(); 
        int psgets(char*);

};

#endif


