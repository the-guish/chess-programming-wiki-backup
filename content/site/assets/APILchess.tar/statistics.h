#ifndef MYSTATS
#define MYSTATS

#include "basic_types.h"

class Statistics
{
  public:
   int64 nodes;
};


#endif
