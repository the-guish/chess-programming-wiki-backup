#ifndef HYDRA
#define HYDRA

#include "APILchess.h"

class Hydra : public APILchess
{
 public:
#ifdef GUEST
    int HyW_FPGALoadEngine(const char *pPath, const char *engine, int card);
    int HyW_FPGALoadEngineByIndex(const char *pPath, const char *engine, int card);
    int HyW_FPGASetClockRate(double rate);
    int HyW_FPGAReleaseCard();
    int HyW_FPGAReset(int8 hy_castle,unsigned int ply);
    int HyW_FPGAEval(int8);
    int HyW_FPGASearchRes(int16 alpha,int16 depth,Move* pMv, int8 wtm, int8 en_passent, Move* resMov,unsigned undo);
    int HyW_FPGASetupPiece(int8 pc,int8 sqr);
    int HyW_FPGAClearPiece(int8 pc,int8 sqr,int8 wtm);
    int HyW_FPGADoMove(int8 , Move*);
    int HyW_FPGAUndoMove(int8 , Move*);
    int HyW_FPGAUndoNullMove(unsigned int WTM);
    int HyW_FPGADoNullMove(unsigned int WTM);
    void HyW_FPGASetupBoard(int16* brd);
    void HyW_FPGASetPSTable(void);
    void HyW_FPGASetKingTable(void);
    void HyW_FPGASetPassedTbl(void);
    void HyW_FPGASetPwnTbl(void);
    void HyW_FPGASetBNPSigTbl(void);
    void HyW_FPGASetQRBNSigTbl(void);
    void HyW_FPGASetRBNFullSigTbl(void);
    void HyW_FPGASetKCover(void);
    void HyW_FPGASetPcSigTbl(void);
    void HyW_FPGASetExChgTbl(void);
    void HyW_FPGASetGPhaseTbl(void);
    void HyW_FPGASetEndgShiftTbl(void);
    void HyW_FPGAClrKillerTbl(void);
    void HyW_FPGASetMatTbl(void);
    void HyW_SetupBoard(void);

    void GuestSetup();

    int GetExtension(int WTM, unsigned int exttype, unsigned int extensions, int16 pXPc);
    int wKingbPwnThreat(int fromsqr);
    int bKingwPwnThreat(int fromsqr);
    int CalcStrongThreat(int8 WTM, Move *mv);
    int CalcExtension(int8 WTM, int16 extensions, int8 *exttype, int MaxExtPly, Move *pMv, int ppexttype, int16 pXPc);

    int AlphabetaStep(ParStack<LocalVariables>*, Hashtable *H);
    int Alphabeta(int16 a, int16 b, int16 rd, int16 d, Move* pMv, int8 WTM, int8, int64*, int, int, Move*, Hashtable *H);
    void SortMoves(Move* list, int* n, Move* bMv, int d, int rd, int a, int b);
    void GuestDoMove(Move *ptm, int8 castle, int8 ep, int8 WTM);
    void GuestUndoMove(Move *ptm,int16 Xpiece, int8 ep, int8 castle, int8 WTM);

#endif
    Hydra(){ }
    ~Hydra(){ }
};

#endif
