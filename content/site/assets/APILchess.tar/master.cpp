#include "master.h"

#ifdef LINUX
#include <unistd.h>
#include <sys/time.h>
#include <sys/times.h>
static struct timeval tv_start;
#endif

#ifdef WIN32
#define TIMEFRACTION 1000   // Fraction of a second for time resolution
#endif
#ifdef LINUX
#define TIMEFRACTION 1   // Fraction of a second for time resolution
#endif

static unsigned int32 Time0;

void Master::Run(Communicator* C )
{ 
 int n;
 
 class Communicator::Message *message;
 class Communicator::Message nachricht;
 
 nachricht.mh.srce=0;
 nachricht.mh.cmd=TEST;
 nachricht.mh.size=0;
 n = C->GetN();	
 SetAliveCheck(OFF,0);

 mefprint(C->GetID(), "Start Master!!!\n");    
#ifdef LOG_OUT  
 cout << "Start of Master!!!"<< endl;
#endif 

 while (true)
  {
    if (keypress()) { 
      psgets(commando);
#ifdef LOG_OUT  
      fprintf(stderr,"Command: '%s'\n",commando);
      fflush(stderr);
#endif      
      if (!strcmp(commando, "ENDE")) {
	for(int i=1; i<n ;i++) {
	  nachricht.mh.dest=i;
	  nachricht.mh.cmd = ENDE;
	  C->Send(&nachricht);
	} 
	break;
      } else if (!strcmp(commando, "TEST")) {
	printf("Teste Priority-Queue.\n");
	fflush(stdout);
	testsUnterwegs=n-1;
	for(int i=1; i<n ;i++) {
	  nachricht.mh.dest=i;
	  C->Send(&nachricht);
	} 	
	SetAliveCheck(ON,0);   
      } else if (UserCommando(C, commando)) {
	for(int i=1; i<n ;i++) {
	  nachricht.mh.dest=i;
	  nachricht.mh.cmd = ENDE;
	  C->Send(&nachricht);
	} 
	break;
      }
      
    }
    
    if (AliveEvent()) {
      nachricht.mh.dest=1;
      nachricht.mh.cmd = ALIVECHECK;
      if (aliveCheck == ON) SetAliveCheck(ON,5);
      Ping(&nachricht);
      if (C->GetN() > 1) C->Send(&nachricht);
    }

    C->HiddenRecv();
    
    while (C->GetNextMessage(&(C->Qu_list), &message)!=0)
	MessageAuswerten(C, message);

    DoStep(C);
  }
#ifdef LOG_OUT  
 cout << "Master beendet!!!" <<endl;
#endif 
}


void Master::MessageAuswerten(Communicator* C, class Communicator::Message* mess)
{
   if (mess->mh.cmd == TESTANTWORT) {
     testsUnterwegs--;
     if (!testsUnterwegs) {
       SetAliveCheck(OFF,0);   
       printf("All messages arrived.  Test finished!!!\n");
       fflush(stdout);
     } 
   } else if (mess->mh.cmd == ALIVECHECK) {
     Echo(mess);
   } else {
     UserMessage(C, mess);
   }   
   C->FreeMess(mess);  
}

void Master::SetAliveCheck(int check, int sec)
{
  aliveCheck = check;
  checkpoint = time(NULL) + sec;
}

int Master::AliveEvent()
{
  if (aliveCheck == ON && time(NULL) > checkpoint) return 1;
  return 0;
}

void Master::ResetTime(void) {
#ifdef WIN32
  Time0 = GetTime();
#endif
#ifdef LINUX
  Time0=0;
  gettimeofday(&tv_start, NULL);
#endif
}

unsigned int32 Master::GetTime(void)
{
#ifdef WIN32
  return (GetTickCount());
#endif
#ifdef LINUX
  struct timeval tv_evnt;
  int sec, usec;
  
  gettimeofday(&tv_evnt, NULL);
  sec = tv_evnt.tv_sec - tv_start.tv_sec;
  usec = tv_evnt.tv_usec - tv_start.tv_usec;
  return sec*1000+usec/1000;
#endif
}

int Master::TimeOut(void) {
  if(GetTime()-Time0>1000*10) // uci interface time unites are millisecs 
    return true;
  else return false;
}

unsigned int32 Master::GetElapsedTime(void){ GetTime()-Time0; }
