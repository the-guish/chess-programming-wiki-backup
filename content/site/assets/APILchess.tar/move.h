#ifndef MOVES
#define MOVES

typedef struct Move_t
{
  unsigned int8 from;
  unsigned int8 to;
  int16 flag;
} Move;

#endif
