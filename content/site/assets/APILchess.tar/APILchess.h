#ifndef APILCHESS
#define APILCHESS

/**
*/

#include "APILchessdefs.h"
#include "localvariables.h"
#include "parstack.h"
#include "hash.h"
#include "chessmaster.h"
#include "chessworker.h"
#include "communicator.h"

#define START        0
#define REKURSION_1  1
#define REKURSION_2  2
#define REKURSION_3  4
#define REKURSION_4  8
#define REKURSION_5 16
#define REKURSION_6 32
#define REKURSION_7 64
#define SYNC_1     128
#define SYNC_2     256
#define SYNC_3     512
#define SYNC_4    1024
#define SYNC_5    2048

#define REKURSION (REKURSION_1|REKURSION_2|REKURSION_3|REKURSION_4|REKURSION_5|REKURSION_6|REKURSION_7)
#define SYNC (SYNC_1|SYNC_2|SYNC_3|SYNC_4|SYNC_5)

static const int16 EmptyBoard[]={IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,
                                 IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,
				 IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				 IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				 IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				 IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				 IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				 IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				 IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				 IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				 IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,
				 IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL
};

static const int16 StdBoard[]= {IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,
                                IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,
				IL,bR,bN,bB,bQ,bK,bB,bN,bR,IL,IL,IL,IL,IL,IL,IL,
				IL,bP,bP,bP,bP,bP,bP,bP,bP,IL,IL,IL,IL,IL,IL,IL,
				IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				IL, 0, 0, 0, 0, 0, 0, 0, 0,IL,IL,IL,IL,IL,IL,IL,
				IL,wP,wP,wP,wP,wP,wP,wP,wP,IL,IL,IL,IL,IL,IL,IL,
				IL,wR,wN,wB,wQ,wK,wB,wN,wR,IL,IL,IL,IL,IL,IL,IL,
				IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,
				IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL,IL
};

#define column(sq) ((sq)&0x0f)
#define line(sq) (((sq)>>4)&0x0f)
#define MAX_SEARCH_HISTORY 50
#define MAX_SEARCH_DEPTH   48
#define MAX_PVL 20
#define MAX_KILLER_DEPTH 64

#define EXT_CHECK      1
#define EXT_CAP        2
#define EXT_ONEMV      4
#define EXT_PASSED     8
#define EXT_STRTHREAT 16
#define EXT_KTHREAT   32
#define EXT_NMV       64

class GameHistory
{
  public:
    Move mv;
    int64 hash;
    int16 Xpc;
    int8 WTM,castle,ep;
};

class APILchess
 {
  private:
   
  public :
    int8 *PieceIndex;
    ParStack<LocalVariables>* mystack;
    Communicator *C;
    ChessMaster *M;
    ChessWorker *W;
    
    int16 BoardData[192];
    int16 *Board;
    int8  en_passent;
    int8  castle_state;
    int8  WTM;
    GameHistory search_history[MAX_SEARCH_HISTORY];
    int   search_history_length;
    GameHistory  *game_history;
    int   game_history_length;
    int64 hashvalue;
    int64 pawnhash;
    int32 MaterialSignatur;
    
    unsigned int8 Pieces[13][12];
    int8 PieceCnt[13];
    int16 MatVal;

    Move PVtbl[MAX_PVL*(MAX_PVL+1)/2+MAX_PVL];
    int16 gran_con;
    int8 LimitExtPly;

    int32 start_code;
    int  IterationCnt;
    int start_state;
    int start_type;
    int16 start_s;
    int16 start_a;
    int16 start_b;
    int16 start_d;
    int16 start_rd;
    int16 start_nd;
    int16 start_u;
    int16 start_o;
    int start_ownext,start_oppext;
    int start_mvnr;
    int start_ExtType;
    int start_PExtType;
    int start_extfound;
    int start_ext;
    Move start_extMv;
    Move start_curFMv;
    Move bRMv;
    int16 Rval;
    int16 MasterProc;
    void* MasterStackpt;
    int64 NodeCnt;
    int research;
    
    void InitLimits(int8 lxp, int itc) { LimitExtPly = lxp; IterationCnt = itc; }
    void ClearNodes();
    void SetGranularity(int16 gc) { gran_con = gc; }
    int64 GetNodes();
    void PrintMove(Move*);
    void PrintBoard();
    void PrintPV();
    void PrintSHV();
    char *PVline2Str();
    char *Move2Str(Move *);
    void SHV2Str(char *);
    void PV2Str(char *);
    void Board2Str(char *str);
    void SetupBoard(Communicator *C, ChessWorker* W, ChessMaster *M, ParStack<LocalVariables>*, char *movestr, GameHistory *gam_his);
    void SetupBoard(Communicator *C, ChessWorker* W, ChessMaster *M, ParStack<LocalVariables>*,char *fen, char *movestr, GameHistory *gam_his);
    void SetupBoard(Communicator *C, ChessWorker* W, ChessMaster *M, ParStack<LocalVariables>*,int16 *start_board, int8 ep, int8 side, 
                    int8 castles, unsigned int8 pcs[][12], 
                    int8 *pcs_cnt, GameHistory *gam_his, int gam_his_len, int64 hsh, int64 pwnhsh, int32 msig, int16 RootMatVal);
    int Draw(int64 hval, int8 cstat, int8 ep, int8 WTM);

    unsigned int8 *FindPiece(int8,unsigned int8);
    void DoMove(Move *, int16 *, int8 *, int8 *, int8, int8);
    void UndoMove(Move *,int16, int8 *, int8, int8*, int8, int8, int8);

    int ComputeVIndex(int d);
    void AddVar(int16 d, Move* m);
    void VarImproved(int16 d);
    void ClearPVLine(void);
    int PVLineIsEmpty(void);
    int CntPVLine(void);
    void ClearKillers(void);
    int NodeType(int, int);
    void NodeCounting(int8 ntype, int64 *counter);
    void PrintNodeCnt(void);
    void PrintTypeCnt(void);
    int ComputeNodeID();

    int16 FieldIsAttacked(unsigned int8 f, int8 WTM);
    int16 connected(unsigned int8 from,unsigned int8 to,int16 piece);
    void RookMoves(Move* list, Move*, unsigned int8 from, int8, int *, int *);
    void BishopMoves(Move* list, Move*, unsigned int8 from, int8, int *, int *);
    void KnightMoves(Move* list, Move*, unsigned int8 from, int8, int *, int *);
    void KingMoves(Move* list, Move*, unsigned int8 from, int8, int *, int *);
    void PawnMoves(Move* list, Move*, unsigned int8 from, int8 WTM, int *, int *);
    void GenerateMoves(Move* list,Move*, int8 WTM, int *, int *);
    void ExtractLegalMoves(Move *, Move *, int8 WTM , int*, int*);
    int IsLegalMove(Move* list, int* n, Move* Xlist, int* xn, Move* Mv);
    void InsertKiller(int depth,Move *bestmv);
    void ClearHistory(void); 
    void InsertHistory(int64 amount,Move *bestmv);
    void MergeMoves(Move* list, int* n, Move* Xlist, int* xn);
    int ProblemOnTour(LocalVariables* LV);

    virtual void SortMoves(Move* list, int* n, Move* bMv, int d, int rd, int a, int b);
    virtual int AlphabetaStep(ParStack<LocalVariables>*, Hashtable *H);
    virtual int Alphabeta(int16, int16, int16, int16, Move*, int8, int8, int64*, int, int, Move*, Hashtable *H);
    virtual int Eval(int16, int16, int8);
    
    void InitBasics();
    APILchess();
    ~APILchess(){ }
    
    virtual void GuestSetup() { }
    virtual void GuestDoMove(Move *ptm, int8 castle, int8 ep, int8 WTM) { }
    virtual void GuestUndoMove(Move *ptm,int16 Xpiece, int8 ep, int8 castle, int8 WTM) { }
    
 };

#endif





