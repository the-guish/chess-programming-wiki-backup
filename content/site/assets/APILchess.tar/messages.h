#ifndef MESSAGES
#define MESSAGES

#include "basic_types.h"
#include "move.h"
#include "chessjob.h"
#include "APILchess.h"

#define NEW_CHESSJOB    20480
#define NEW_POS         24576
#define PRINT_POS       28672
#define WORK_MESSAGE    32768
#define NO_WORK_MESSAGE 36864
#define REQUEST_MESSAGE 40960
#define ISREADY_MESSAGE 45056
#define ORACLE_MESSAGE  49152
#define RESULT_MESSAGE  53248
#define KILL_MESSAGE    57344
#define HASH_PUSH_MESSAGE        61460
#define HASH_EXT_PUSH_MESSAGE    65536
#define HASH_QUERY               69632
#define HASH_ANSWER              73728

class Work 
{
  public:
    int32 code;
    int16 d;
    int16 rd;
    int16 nd;
    int16 a;
    int16 b;
    int16 u;
    int16 o;
    int16 s;
    int state;
    int cntmvs;
    int mvnr;
    Move *mvs;
    int8 type;
    int ownext,oppext;
    int LimitExtPly;
    int32 IterationCounter;
    int ExtType;
    int PExtType;
    int extfound;
    int ext;
    Move extMv;
    Move curMv;
    void *stackpt;
};

class Result
{
  public:
    int64 nodes;
    int32 code;
    int16 d;
    int16 v;
    int state;
    int mvnr;
    Move *mvs;
    int cntmvs;
    int32 IterationCounter;
    void *stackpt;
    int64 hashvalue;
    int8 cstle;
    int8 ep;
};

class Oracle 
{
  public:
    ChessJob hyd;
    GameHistory gamehistory[1000];
};

class HashPushExtension
{
  public:
    unsigned int64 XKey;
    Move XMv;
    int8 XrDepth;
    int8 XFlgs;
};

class HashPush
{
  public:
    unsigned int64 Key;
    Move Mv;
    int16 Val;
    int8 rDepth;
    int8 Flgs;
};

class HashQuery
{
  public:
    unsigned int64 Key;
    unsigned int32 hashcodeID;
};

class HashAnswer
{
  public:
    unsigned int64 Key;
    unsigned int32 hashcodeID;
    Move hMv;
    Move hXMv;
    int16 hval;
    int16 hrd;
    int16 hXrd;
    int8 hflgs;
    int8 hXflgs;
};


#endif
