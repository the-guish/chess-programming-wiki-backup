#include "memory.h"
#include "stdio.h"
#ifdef HYDRA_ACTIVE
#include "chesscommunicator.h"
#endif
#include "chessworker.h"
#include "chessmaster.h"

#ifndef NO_MP
#include <mpi.h>
#else
#include "nomp.h"
void MPI_Init(int*, char***) {}

void MPI_Buffer_attach(void*,int) {}
void MPI_Comm_rank(int x, int*y) {*y = 0;}
void MPI_Comm_size(int x, int*y) {*y = 1;}
void MPI_Wait(MPI_Request *, MPI_Status*) {}
void MPI_Barrier(int) {}
void MPI_Finalize(void) {}
void MPI_Ibsend(void *, int, int , int, int, int, MPI_Request *) {}
void MPI_Isend(void *, int, int, int,int , int, MPI_Request *){}      
void MPI_Irecv(void *, int , int , int , int , int, MPI_Request*) {}
void MPI_Iprobe(int a, int b, int c, int* d, MPI_Status* e) {*d = 0;}
void MPI_Test(MPI_Request* a, int *b, MPI_Status *c) {*b = 1;}
#endif
#ifdef LINUX
#include "MPIdebug.h"
#include <unistd.h>
#endif

int main(int argc, char **argv)
{
#ifdef HYDRA_ACTIVE
 ChessCommunicator *C;
#else
 Communicator *C;
#endif
 ChessMaster *M;
 ChessWorker *W;

#ifdef HYDRA_ACTIVE
 C = new ChessCommunicator(&argc, &argv, 15000000, 108000, 108000);
#else
 C = new Communicator(&argc, &argv, 15000000, 108000, 108000);
#endif

#ifdef LINUX
 MPI_debug(argc,argv,0);
#endif

 //#include <sys/types.h>
 //#include <sys/processor.h>
 //#include <sys/procset.h>
 //processor_bind(P_PID, P_MYID, C->GetID(), NULL);

 if (C->GetID() == 0)
   {
    M = new ChessMaster();
    M->Run(C);
    delete M;
   } 
 else
   {
    W = new ChessWorker();
    W->Run(C);
    delete W;
   }  

 delete C;

}

