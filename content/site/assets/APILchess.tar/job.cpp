#include "job.h"

static Job *free_jobs = NULL;

void Job_Container::Test()
{
  Job *j;
  Job_Container *jc = new Job_Container;
  int i;
  
  for (i = 0;i < 1000;i++) { 
    j = new Job;
    jc->Insert_Job(j);
    jc->Release_Job(j);
    delete j;
    j = new Job;
    jc->Insert_Job(j);
  }
  for (i = 0,j=jc->first;j && i < 1000;i++,j=j->next) {
    if (i % 200 == 0) {
        Job *k=j->next;
        jc->Release_Job(j);
        delete j;
        j=k;
    }
  }

  i = jc->CountJobs();
  int k = jc->CountFreeJobs();

  fprintf(stderr,"Jobs:%d FreeJobs:%d\n",i,k);
  fflush(stderr);
  delete jc;
}

void Job_Container::Insert_Job(Job *j )
{
  if (first == 0L) {
    first = j;
    j->prev = 0L;
    j->next = 0L;
    last = first;
  } else {
    j->prev = 0L;
    j->next = first;
    first->prev = j;
    first = j;
  }
}

Job *Job_Container::GetLIFO_Job()
{
  Job *j = first;
  if (!j || !first) return NULL;
  if (j == last) last = last->prev;
  if (first == j) first = j->next;
  if (j->prev) j->prev->next = j->next;
  if (j->next) j->next->prev = j->prev;  
  j->next = j->prev = NULL;
  return j;
}

Job *Job_Container::GetFIFO_Job()
{
  Job *j = last;
  if (!j || !first) return NULL;
  if (j == last) last = last->prev;
  if (first == j) first = j->next;
  if (j->prev) j->prev->next = j->next;
  if (j->next) j->next->prev = j->prev;  
  j->next = j->prev = NULL;
  return j;
}

Job *Job_Container::SelectJob()
{
  Job *j = first;
  return j;
}

void Job_Container::Release_Job(Job *j )
{
  if (!j || !first) return;
  if (j == last) last = last->prev;
  if (first == j) first = j->next;
  if (j->prev) j->prev->next = j->next;
  if (j->next) j->next->prev = j->prev;  
  j->next = j->prev = NULL;
}

int Job_Container::CountJobs()
{
  int i;
  Job *j;
  for (i = 0,j = first;j;j=j->next)
    i++;
  return i;
}

int Job_Container::CountFreeJobs()
{
  int i;
  Job *j;
  for (i = 0,j = free_jobs;j;j=j->next)
    i++;
  return i;
}

Job *Job::NextJob_Pointer(Job *j)
{
  return j->next;
}

void* Job::operator new(size_t s) 
{
   Job *j;
   if (free_jobs==0L) {
     j = (Job*)malloc(s);
   } else {
     j = free_jobs;
     free_jobs = free_jobs->next;
   }
   return (void*)j;
}

void Job::operator delete(void* p, size_t s) 
{
  Job *j = (Job*)p;
   
  if (free_jobs==0L) {
    j->next = 0L;
    free_jobs = j;
  } else {
    j->next = free_jobs;
    free_jobs = j;
  }
}

