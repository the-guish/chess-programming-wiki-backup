#ifndef COMMUNICATOR
#define COMMUNICATOR
#include "commprint.h"
#ifndef NO_MP
#include <mpi.h>
#else
#include "nomp.h"
#endif



class Communicator: public CommPrint 
 {
  private :
	     class MessageHead          /* Beinhaltet alle wichtigen logistischen Informationen */
	                                /* ueber die Nachricht, die verschickt werden soll*/
                   {
		    public:
                    unsigned int cmd;   /* Welches Kommando folgt ?        */
                    int size;           /* Laenge  der folgenden Nachricht */
                    int srce;           /* Woher kommt die Nachricht */
                    int dest;           /* Wohin wird diese Nachricht gesendet */
                    long  kennung;
                    void *FreierPointer;
                   } ;
  public :		   
             class Message              /* Die Nachricht selbst, beinhaltet Daten und einen Kopf */
	                                /* (siehe class MessageHead) mit wichtigen Infos */
                   {
                    public : Message *next;   /* Pointer auf naechste Nachricht*/
                             MessageHead mh;  /* NachrichtKopf */
                             char *data;      /* Pointer auf die Daten der Nachricht */
                   };
  public :		   
	     class MyList_t             /* Liste von Messages */
	           {
                    public: Message *first;
                             Message *last;
                   };  
	
	    int N;
            int ID;
	    void* BsendBuffer;
            char* InBuffer;
	    char* OutBuffer;
	    int InBuffersize;
	    int OutBuffersize;
	    MPI_Status Sst;
	    MPI_Request Sq; 
	    Message *DataFreeListe[10];
	    int *kinder;
	    int anz_klMess;        
            Message *klMessFreiliste;
	    
  public  : MyList_t Qu_list;
            
            Communicator() {}
	    Communicator(int*, char ***, int, int, int);             
           ~Communicator();
            virtual int  HiddenRecv(); 
	    void Send(Message *M);
            int GetNextMessage(MyList_t *, Message **);
	    void FreeMess(Message*);
	    int GetID();
	    int GetN(); 

 };
 
static FILE *out=stdout; 
 
#define NUMHEADS 4500

  
#define MyInitList(l)      \
{                          \
 (l)->first=(l)->last=NULL;\
} 


#define InQueue( List, mess )             \
{                                         \
 if (!((List)->first))                    \
   {                                      \
    (mess)->next = NULL;                  \
    (List)->first = (List)->last = (mess);\
   }                                      \
 else                                     \
   {                                      \
    (mess)->next = NULL;                  \
    (List)->first->next = (mess);         \
    (List)->first = (mess);               \
   }                                      \
}


#define MessageAlloc( z )                                  \
{                                                          \
  if (klMessFreiliste)                                     \
    {                                                      \
     *(z) = klMessFreiliste;                               \
     klMessFreiliste = klMessFreiliste->next;              \
    }                                                      \
  else                                                     \
    {                                                      \
     *(z) = new Message;                                   \
     if (*(z) == NULL) mefprint(ID, "Kein Speicher bei new\n");\
     anz_klMess++;                                         \
    }                                                      \
}


#define MessageFree( zeiger )      \
{                                  \
  (zeiger)->next = klMessFreiliste;\
  klMessFreiliste = (zeiger);      \
}


#define DataAlloc( z,s )                                     \
{                                                            \
 int fs=10000;                                               \
 int fsInh[] = {20,100,500,1000,2000,20000};                 \
 Message *mh;                                                \
 if ((s) < 20)         fs = 0;                               \
 else if ((s) < 100)   fs = 1;                               \
 else if ((s) < 500)   fs = 2;                               \
 else if ((s) < 1000)  fs = 3;                               \
 else if ((s) < 2000)  fs = 4;                               \
 else if ((s) < 20000) fs = 5;                               \
 else                                                        \
   {                                                         \
    *(z) = (char *)malloc((s));                              \
    if (*(z) == NULL)                                        \
      mefprint(ID, "Kein Speicher bei malloc\n");                \
   }                                                         \
 if (fs < 100)                                               \
   {                                                         \
    if (DataFreeListe[fs])                                   \
      {                                                      \
       mh = DataFreeListe[fs];                               \
       *(z) = (char *)DataFreeListe[fs]->data;               \
       DataFreeListe[fs] = DataFreeListe[fs]->next;          \
       mh->data=NULL;                                        \
       mh->next=NULL;                                        \
       MessageFree(mh);                                      \
      }                                                      \
    else                                                     \
      {                                                      \
       *(z) = (char *)malloc(fsInh[fs]);                     \
       if (*(z) == NULL)                                     \
         mefprint(ID, "Kein Speicher bei malloc\n");             \
       anz_klMess++;                                         \
      }                                                      \
    }                                                        \
}                                                            

#define DataFree( zeiger,s )                                                           \
{                                                                                      \
 int fs=100;                                                                           \
 Message *mh;                                                                          \
 if ((s) < 20) fs = 0;                                                                 \
 else if ((s) < 100) fs = 1;                                                           \
 else if ((s) < 500) fs = 2;                                                           \
 else if ((s) < 1000) fs = 3;                                                          \
 else if ((s) < 2000) fs = 4;                                                          \
 else if ((s) < 20000) fs = 5;                                                         \
 else free(zeiger);                                                                    \
 if (fs < 100)                                                                         \
   {                                                                                   \
    MessageAlloc(&mh);                                                                 \
    mh->data = (char *)(zeiger);                                                       \
    mh->next = DataFreeListe[fs];                                                      \
    DataFreeListe[fs] = mh;                                                            \
   }                                                                                   \
}

#endif
