#include "APILchess.h"
#include <stdio.h>
#include <string.h>

#define maximum(a,b) ((a) > (b) ? (a) : (b))

static int8 StaticPieceIndex[3000];
int64 History[255][255];

#include "hashconsts.h"
//static int64 Hconst[13][192]; // constants for Zobrists hashing
//static int32 MSconst[13][12]; // constants for MaterialSignatur

char *c2s[]={"  ", "wB","wS","wL","wT","wD","wK","sB","sS","sL","sT","sD","sK"};
char pvstr[MAX_PVL*8];
char mvstr[8];
int64 nodes;
int64 t1_n,t2_n,t3_n,t4_n,t5_n;
Move Killer0[MAX_KILLER_DEPTH];
Move Killer1[MAX_KILLER_DEPTH];
Move Killer2[MAX_KILLER_DEPTH];
Move Killer3[MAX_KILLER_DEPTH];

char * APILchess::Move2Str(Move* m)
{
  char fp=0;
  
  if( m->from == 255 ) {
    sprintf(mvstr,"il");
    return mvstr;
  }
  
  if((m->flag & PROMOTION) == PROM_Q) fp = 'Q';
  if((m->flag & PROMOTION) == PROM_R) fp = 'R';
  if((m->flag & PROMOTION) == PROM_N) fp = 'N';
  if((m->flag & PROMOTION) == PROM_B) fp = 'B';

  if (fp) sprintf(mvstr,"%c%c%c%c%c",(m->from % 16) + 'a',7 - (m->from / 16) + '1',(m->to % 16)+'a',7 - (m->to / 16)+'1',fp);
  else sprintf(mvstr,"%c%c%c%c",(m->from % 16) + 'a',7 - (m->from / 16) + '1',(m->to % 16)+'a',7 - (m->to / 16)+'1');

  return mvstr;
}

void APILchess::PrintMove(Move* m)
{
    if( m->from == 255 ) {
      fprintf(stderr,"illegal");
      fputc(' ',stderr);
      fflush(stderr);
      return;
   }

   fputc(((int16) m->from % 16) + 'a',stderr);
   fputc(7 - ((int16)m->from / 16) + '1',stderr);

   fputc(((int16)m->to % 16)+'a',stderr);
   fputc(7 - ((int16)m->to / 16)+'1',stderr);

   if((m->flag & PROMOTION) == PROM_Q)    fputc('Q',stderr);
   if((m->flag & PROMOTION) == PROM_R)    fputc('R',stderr);
   if((m->flag & PROMOTION) == PROM_N)    fputc('N',stderr);
   if((m->flag & PROMOTION) == PROM_B)    fputc('B',stderr);

   fputc(' ',stderr);
   fflush(stderr);
}

void APILchess::PrintPV()
{
  Move *m;
  ParStack<LocalVariables> *stpt = mystack;
  ParItem<LocalVariables> *itpt = stpt->last;
  
  if (mystack == NULL) { fprintf(stderr,"Sorry, this operation is not allowed.");fflush(stderr); }
  
  if (!itpt) return;
  itpt = itpt->prev;

  while (itpt) {
    LocalVariables *LV = itpt->item;
   
    m = &LV->curMv;
    
    if( m->from == 255 ) {
      fprintf(stderr,"illegal");
      fputc(' ',stderr);
      fflush(stderr);
      return;
   }

   fputc(((int16) m->from % 16) + 'a',stderr);
   fputc(7 - ((int16)m->from / 16) + '1',stderr);

   fputc(((int16)m->to % 16)+'a',stderr);
   fputc(7 - ((int16)m->to / 16)+'1',stderr);

   if((m->flag & PROMOTION) == PROM_Q)    fputc('Q',stderr);
   if((m->flag & PROMOTION) == PROM_R)    fputc('R',stderr);
   if((m->flag & PROMOTION) == PROM_N)    fputc('N',stderr);
   if((m->flag & PROMOTION) == PROM_B)    fputc('B',stderr);

   fprintf(stderr,"(%d %d)",LV->WTM,LV->status);

   fputc(' ',stderr);
   
   itpt=itpt->prev;
   
  }
  fputc('\n',stderr);
  fflush(stderr);
}

void APILchess::PV2Str(char *str)
{
  Move *m;
  char *s;
  char lstr[50];
  ParStack<LocalVariables> *stpt = mystack;
  ParItem<LocalVariables> *itpt = stpt->last;
  
  if (mystack == NULL) sprintf(str,"Sorry, this operation is not allowed.");
  if (!itpt) return;
  itpt = itpt->prev;

  while (itpt) {
    LocalVariables *LV = itpt->item;
   
    m = &LV->curMv;
    s = Move2Str(m);
    strcat(str,s);
    sprintf(lstr,"(%d %d)",LV->WTM,LV->status);
    strcat(str," ");
    itpt=itpt->prev;
  }
  strcat(str,"\n");
}

void APILchess::PrintSHV()
{
  Move *m;

  fprintf(stderr,"Search-History:\n");
  for (int i = search_history_length-1; i >= 0; i--) {
    m = &(search_history[i].mv);
    
    if( m->from == 255 ) {
      fprintf(stderr,"illegal");
      fputc(' ',stderr);
      fflush(stderr);
      return;
    }
    
    fputc(((int16) m->from % 16) + 'a',stderr);
    fputc(7 - ((int16)m->from / 16) + '1',stderr);
    
    fputc(((int16)m->to % 16)+'a',stderr);
    fputc(7 - ((int16)m->to / 16)+'1',stderr);
    
    if((m->flag & PROMOTION) == PROM_Q)    fputc('Q',stderr);
    if((m->flag & PROMOTION) == PROM_R)    fputc('R',stderr);
    if((m->flag & PROMOTION) == PROM_N)    fputc('N',stderr);
    if((m->flag & PROMOTION) == PROM_B)    fputc('B',stderr);
    
    fputc(' ',stderr);
  }
  fputc('\n',stderr);
  fflush(stderr);
}

void APILchess::SHV2Str(char *str)
{
  Move *m;
  char *s;
  
  sprintf(str,"Search-History:\n");
  for (int i = search_history_length-1; i >= 0; i--) {
    m = &(search_history[i].mv);
    s = Move2Str(m);
    strcat(str,s);
    strcat(str," ");
  }
  strcat(str,"\n");
}

void APILchess::PrintBoard()
{
  int h;

  fprintf(stderr,"\n");
  for(h = 0; h <= 0x70 ; h+=0x10)
    fprintf(stderr,"|%s|%s|%s|%s|%s|%s|%s|%s|\n-------------------------\n",
            c2s[PieceIndex[Board[h+A8]]],
	    c2s[PieceIndex[Board[h+B8]]],
            c2s[PieceIndex[Board[h+C8]]],
            c2s[PieceIndex[Board[h+D8]]],
            c2s[PieceIndex[Board[h+E8]]],
            c2s[PieceIndex[Board[h+F8]]],
            c2s[PieceIndex[Board[h+G8]]],
            c2s[PieceIndex[Board[h+H8]]]);
  fprintf(stderr,"\n");
  fflush(stderr);
}

void APILchess::Board2Str(char *str)
{
  int h;
  char lstr[100];

  sprintf(str,"\n");
  for(h = 0; h <= 0x70 ; h+=0x10) {
    sprintf(lstr,"|%s|%s|%s|%s|%s|%s|%s|%s|\n-------------------------\n",
            c2s[PieceIndex[Board[h+A8]]],
	    c2s[PieceIndex[Board[h+B8]]],
            c2s[PieceIndex[Board[h+C8]]],
            c2s[PieceIndex[Board[h+D8]]],
            c2s[PieceIndex[Board[h+E8]]],
            c2s[PieceIndex[Board[h+F8]]],
            c2s[PieceIndex[Board[h+G8]]],
            c2s[PieceIndex[Board[h+H8]]]);
    strcat(str,lstr);
  }
  strcat(str,"\n");
}

void APILchess::SetupBoard(Communicator *lC, ChessWorker *lW, ChessMaster *lM, ParStack<LocalVariables>* mys, char *movestr, GameHistory *gam_his)
{
  int i,j,ucipt;
  Move mv;
  int16 Xpc;
  char onemove[100];
  
  mystack = mys;
  C = lC;
  M = lM;
  W = lW;
  
  for (i=0;i < 192;i++) BoardData[i] = StdBoard[i];  
  WTM = true;
  castle_state = W_LONG | W_SHORT | B_SHORT | B_LONG;
  en_passent = 0;
  Pieces[ 1][0] = A2; Pieces[ 1][1] = B2; Pieces[ 1][2] = C2; Pieces[ 1][3] = D2;
  Pieces[ 1][4] = E2; Pieces[ 1][5] = F2; Pieces[ 1][6] = G2; Pieces[ 1][7] = H2;
  Pieces[ 2][0] = B1; Pieces[ 2][1] = G1;
  Pieces[ 3][0] = C1; Pieces[ 3][1] = F1;
  Pieces[ 4][0] = A1; Pieces[ 4][1] = H1;
  Pieces[ 5][0] = D1;
  Pieces[ 6][0] = E1;
  PieceCnt[1] = 8;PieceCnt[2] = 2;PieceCnt[3] = 2;PieceCnt[4] = 2;PieceCnt[5] = 1;PieceCnt[6] = 1;
  
  Pieces[ 7][0] = A7; Pieces[ 7][1] = B7; Pieces[ 7][2] = C7; Pieces[ 7][3] = D7;
  Pieces[ 7][4] = E7; Pieces[ 7][5] = F7; Pieces[ 7][6] = G7; Pieces[ 7][7] = H7;
  Pieces[ 8][0] = B8; Pieces[ 8][1] = G8;
  Pieces[ 9][0] = C8; Pieces[ 9][1] = F8;
  Pieces[10][0] = A8; Pieces[10][1] = H8;
  Pieces[11][0] = D8;
  Pieces[12][0] = E8;
  PieceCnt[7] = 8;PieceCnt[8] = 2;PieceCnt[9] = 2;PieceCnt[10] = 2;PieceCnt[11] = 1;PieceCnt[12] = 1;

  hashvalue = 0;
  MaterialSignatur = 0;
  pawnhash = 0;
  for (i=1;i<=12;i++)
    for (j=0;j<PieceCnt[i];j++) {
      MaterialSignatur ^= MSconst[i][j];
      hashvalue ^= Hconst[i][Pieces[i][j]];
    }
  for (i=1;i<=7;i+=6)
    for (j=0;j<PieceCnt[i];j++)
      pawnhash ^= Hconst[i][Pieces[i][j]];

  // now the moves
  game_history = gam_his;
  game_history_length = 0;
  search_history_length = 0;
  
  ucipt=0;
  while (1) {
    while (movestr[ucipt] == ' ') ucipt++;
    if (strlen(movestr+ucipt) < 3) break;
    sscanf(movestr+ucipt,"%s",onemove);
    mv.from = (onemove[0] - 'a') + 0x70-0x10*(onemove[1] - '1');
    mv.to =   (onemove[2] - 'a') + 0x70-0x10*(onemove[3] - '1');
    mv.flag = 0;
    
    if (Board[mv.to])
      mv.flag |= CAPTURE;
    if ((Board[mv.from] & (wP|bP)) && !Board[mv.to] && column(mv.from) != column(mv.to))
      mv.flag |= EN_PASSENT;
    if ((Board[mv.from] & (wK|bK)) && abs(column(mv.from)-column(mv.to)) > 1)
      mv.flag |= CASTLE;
    if ((Board[mv.from] & (wP|bP)) && (line(mv.to)==line(A8) || line(mv.to) == line(A1))) {
      switch (onemove[4]) {
      case 'q':mv.flag |= PROM_Q;break;
      case 'Q':mv.flag |= PROM_Q;break;
      case 'r':mv.flag |= PROM_R;break;
      case 'R':mv.flag |= PROM_R;break;
      case 'B':mv.flag |= PROM_B;break;
      case 'b':mv.flag |= PROM_B;break;
      case 'N':mv.flag |= PROM_N;break;
      case 'n':mv.flag |= PROM_N;break;
      default:mv.flag |= PROM_Q;   
      }
    }
    ucipt+=strlen(onemove);
    
    gam_his[game_history_length].hash = hashvalue;
    gam_his[game_history_length].mv = mv;		   
    gam_his[game_history_length].WTM = WTM;		   
    gam_his[game_history_length].castle = castle_state;		   
    gam_his[game_history_length].ep = en_passent;		   
    game_history_length++;
    
    DoMove(&mv, &Xpc, &castle_state, &en_passent,WTM, false);
    WTM = 1- WTM;
  }
  for (int i=1,MatVal=0;i<=12;i++) MatVal+=MaterialValues[PieceCnt[i]];
  //GuestSetup(); must be done explicitely
}

void APILchess::SetupBoard(Communicator *lC, ChessWorker *lW, ChessMaster *lM, ParStack<LocalVariables>* mys, char *fen, char *movestr, GameHistory *gam_his)
{
  char line2[200], line3[200], line4[200];
  char s1[10],s2[10],s3[10],s4[10];
  int col,row,i,j,ucipt;
  Move mv;
  int16 Xpc;
  char onemove[100];

  mystack = mys;
  C = lC;
  M = lM;
  W = lW;
    
  for (i=0;i < 192;i++) BoardData[i] = EmptyBoard[i];  
  for (i=1;i <= 12;i++) PieceCnt[i] = 0;

  strcpy(line2,fen+(fen[0] == '"' ? 1 :0));
  sscanf(line2,"%s%s%s%s%s%s",line4,line3,s1,s2,s3,s4);

  row = 0;
  col = 0;
  i = 0;
  if (line3[0] == 'w') WTM = true;
  else WTM = false;
  
  while(row+col <= 0x77) {
    switch(line2[i]) {
    case 'p':Board[col+row] = bP;Pieces[ 7][PieceCnt[ 7]++]=col+row;i++;col++;break;
    case 'n':Board[col+row] = bN;Pieces[ 8][PieceCnt[ 8]++]=col+row;i++;col++;break;
    case 'b':Board[col+row] = bB;Pieces[ 9][PieceCnt[ 9]++]=col+row;i++;col++;break;
    case 'r':Board[col+row] = bR;Pieces[10][PieceCnt[10]++]=col+row;i++;col++;break;
    case 'q':Board[col+row] = bQ;Pieces[11][PieceCnt[11]++]=col+row;i++;col++;break;
    case 'k':Board[col+row] = bK;Pieces[12][PieceCnt[12]++]=col+row;i++;col++;break;
    case 'P':Board[col+row] = wP;Pieces[ 1][PieceCnt[ 1]++]=col+row;i++;col++;break;
    case 'N':Board[col+row] = wN;Pieces[ 2][PieceCnt[ 2]++]=col+row;i++;col++;break;
    case 'B':Board[col+row] = wB;Pieces[ 3][PieceCnt[ 3]++]=col+row;i++;col++;break;
    case 'R':Board[col+row] = wR;Pieces[ 4][PieceCnt[ 4]++]=col+row;i++;col++;break;
    case 'Q':Board[col+row] = wQ;Pieces[ 5][PieceCnt[ 5]++]=col+row;i++;col++;break;
    case 'K':Board[col+row] = wK;Pieces[ 6][PieceCnt[ 6]++]=col+row;i++;col++;break;
    case '/':col=0;row+=0x10;i++;break;
    case '1':col+=1;i++;break;
    case '2':col+=2;i++;break;
    case '3':col+=3;i++;break;
    case '4':col+=4;i++;break;
    case '5':col+=5;i++;break;
    case '6':col+=6;i++;break;
    case '7':col+=7;i++;break;
    case '8':col+=8;i++;break;
    case '9':col+=9;i++;break;
    }
  }
  castle_state = 0;
  if(strstr(s1,"q")) castle_state |= B_LONG;
  if(strstr(s1,"k")) castle_state |= B_SHORT;
  if(strstr(s1,"Q")) castle_state |= W_LONG;
  if(strstr(s1,"K")) castle_state |= W_SHORT;
  if(strlen(s2) > 1) en_passent = s2[0];
  else en_passent = 0;

  hashvalue = 0;
  MaterialSignatur = 0;
  pawnhash = 0;
  for (i=1;i<=12;i++)
    for (j=0;j<PieceCnt[i];j++) {
      MaterialSignatur ^= MSconst[i][j];
      hashvalue ^= Hconst[i][Pieces[i][j]];
    }
  for (i=1;i<=7;i+=6)
    for (j=0;j<PieceCnt[i];j++)
      pawnhash ^= Hconst[i][Pieces[i][j]];

  // now the moves:
  game_history = gam_his;
  game_history_length = 0;
  search_history_length = 0;

  ucipt=0;
  while (1) {
    while (movestr[ucipt] == ' ') ucipt++;
    if (strlen(movestr+ucipt) < 3) break;
    sscanf(movestr+ucipt,"%s",onemove);
    mv.from = (onemove[0] - 'a') + 0x70-0x10*(onemove[1] - '1');
    mv.to =   (onemove[2] - 'a') + 0x70-0x10*(onemove[3] - '1');
    mv.flag = 0;
    
    if ((Board[mv.from] & (wP|bP)) && !Board[mv.to] && column(mv.from) != column(mv.to))
      mv.flag |= EN_PASSENT;
    if ((Board[mv.from] & (wK|bK)) && abs(column(mv.from)-column(mv.to)) > 1)
      mv.flag |= CASTLE;
    if ((Board[mv.from] & (wP|bP)) && (line(mv.to)==line(A8) || line(mv.to) == line(A1))) {
      switch (onemove[4]) {
      case 'q':mv.flag |= PROM_Q;break;
      case 'Q':mv.flag |= PROM_Q;break;
      case 'r':mv.flag |= PROM_R;break;
      case 'R':mv.flag |= PROM_R;break;
      case 'B':mv.flag |= PROM_B;break;
      case 'b':mv.flag |= PROM_B;break;
      case 'N':mv.flag |= PROM_N;break;
      case 'n':mv.flag |= PROM_N;break;
      default:mv.flag |= PROM_Q;   
      }
    }
    ucipt+=strlen(onemove);
    
    gam_his[game_history_length].hash = hashvalue;
    gam_his[game_history_length].mv = mv;		   
    gam_his[game_history_length].WTM = WTM;		   
    gam_his[game_history_length].castle = castle_state;		   
    gam_his[game_history_length].ep = en_passent;		   
    game_history_length++;
    
    DoMove(&mv, &Xpc, &castle_state, &en_passent,WTM, false);
    WTM = 1- WTM;
  }
  for (int i=1,MatVal=0;i<=12;i++) MatVal+=MaterialValues[PieceCnt[i]];
  //GuestSetup(); must be done explicitely
}

void APILchess::SetupBoard(Communicator *lC, ChessWorker *lW, ChessMaster *lM, ParStack<LocalVariables>* mys, int16 *start_board, int8 ep, 
                       int8 side, int8 castles, unsigned int8 pcs[][12], 
                       int8 *pcs_cnt, GameHistory *gam_his, int gam_his_len, int64 hsh, int64 pwnhsh, int32 msig, int16 mval)
{
  int i,j;
  
  mystack = mys;
  C = lC;
  M = lM;
  W = lW;

  MatVal = mval;
  for (i=0;i < 192;i++) BoardData[i] = start_board[i];  
  for (i=1;i <= 12;i++) PieceCnt[i] = pcs_cnt[i];
  for (i=1;i <= 12;i++) 
    for (j=0;j < PieceCnt[i];j++)
      Pieces[i][j] = pcs[i][j];
  en_passent = ep;
  WTM = side;
  castle_state = castles;
  hashvalue = hsh;
  MaterialSignatur = msig;
  pawnhash = pwnhsh;

  game_history = gam_his;
  game_history_length = gam_his_len;
  search_history_length = 0;
  //GuestSetup(); must be done explicitely
}

int APILchess::Draw(int64 hval, int8 cstat, int8 ep, int8 lWTM) {
   ParItem<LocalVariables> *stp;
   int count,i;
   
   for (count=0,stp = mystack->current;stp;stp=stp->prev,count++)
     if (count>0 /*&& !(count&1)*/ && stp->item->hashvalue==hval && stp->item->save_casp==cstat && stp->item->WTM==lWTM && ep==stp->item->save_ep) return true;
     else if (0&&count >= 100) return true;
     else if (count > 0 && IsNullmove(stp->item->curMv)) return false;
     else if (count > 0 && (stp->item->curMv.flag & (CAPTURE|EN_PASSENT|CASTLE|PAWNMOVE))) return false;
   for (i=search_history_length-1;i>=0;i--,count++)
     if (count>0 && /*!(count&1) &&*/ search_history[i].hash==hval && search_history[i].castle==cstat && search_history[i].WTM==lWTM && search_history[i].ep==ep) return true;
     else if (count > 100) return true;
     else if (IsNullmove(search_history[i].mv)) return false;
     else if (search_history[i].mv.flag & (CAPTURE|EN_PASSENT|CASTLE|PAWNMOVE)) return false;
   for (i=game_history_length-1;i>=0;i--,count++)
     if (count>0 /*&& !(count&1)*/ && game_history[i].hash==hval && game_history[i].castle==cstat && game_history[i].WTM==lWTM && game_history[i].ep==ep) return true;
     else if (count > 100) return true;
     else if (count > 0 &&IsNullmove(game_history[i].mv)) return false;
     else if (count > 0 && (game_history[i].mv.flag & (CAPTURE|EN_PASSENT|CASTLE|PAWNMOVE))) return false;
   return false;
}

#define TakePiece(p,f) {              \
  unsigned int8 *Ppt;                 \
  Ppt = FindPiece((p),(f));           \
  *Ppt = Pieces[(p)][--PieceCnt[(p)]];\
  if (Board[(f)] & (wP|bP))           \
    pawnhash ^= Hconst[(p)][(f)];     \
  hashvalue ^= Hconst[(p)][(f)];      \
  MaterialSignatur ^= MSconst[(p)][PieceCnt[(p)]];\
  Board[(f)] = 0;                     \
}

#define PutPiece(p,t,b) {             \
  if ((b) & (wP|bP))                  \
    pawnhash ^= Hconst[(p)][(t)];     \
  hashvalue ^= Hconst[(p)][(t)];      \
  MaterialSignatur ^= MSconst[(p)][PieceCnt[(p)]];\
  Board[(t)] = (b);                   \
  Pieces[(p)][PieceCnt[(p)]++] = (t); \
}

#define MovePiece(p,f,t) {                                      \
  unsigned int8 *Ppt;                                           \
  hashvalue = hashvalue ^ Hconst[(p)][(f)] ^ Hconst[(p)][(t)];  \
  if (Board[(f)] & (wP|bP))                                     \
    pawnhash = pawnhash ^ Hconst[(p)][(f)] ^ Hconst[(p)][(t)];  \
  Ppt = FindPiece((p),(f));                                     \
  *Ppt = (t);                                                   \
  Board[(t)] = Board[(f)];                                      \
  Board[(f)] = 0;                                               \
}

unsigned int8 *APILchess::FindPiece(int8 p,unsigned int8 f)
{
  for (int i=0;i<PieceCnt[p];i++)
    if(Pieces[p][i]==f) return &(Pieces[p][i]);
  fprintf(stderr,"Fatal Error: Piece not found in 'FindPiece(.)'\n");
  fflush(stderr);
  return 0;
}

void APILchess::DoMove(Move *ptm, int16 *Xpiece, int8 *casp, int8 *epp, int8 lWTM, int8 DoG)
  // ptm: pointer to the move that must be done
  // Xpiece: the captured piece is returned here
  // casp: contains the present state of the castles, is replaced after the move
  // epp: contains the present state of en_passent, is replaced after the move
  // lWTM: white to move?
  // DoG: do the move of the Guest, as well
{      
  if (DoG) GuestDoMove(ptm, *casp, *epp, lWTM);
  if (IsNullmove(*ptm)) return;
  if (!lWTM) { /* black to move */
    if (ptm->flag & CASTLE) *casp &= W_LONG | W_SHORT;
  } else if (ptm->flag & CASTLE) *casp &= B_LONG | B_SHORT;
  
  if (ptm->from == A8 || ptm->to == A8) *casp &= (W_LONG | W_SHORT | B_SHORT);
  if (ptm->from == H8 || ptm->to == H8) *casp &= (W_LONG | W_SHORT | B_LONG);
  if (ptm->from == A1 || ptm->to == A1) *casp &= (B_LONG | B_SHORT | W_SHORT);
  if (ptm->from == H1 || ptm->to == H1) *casp &= (B_LONG | B_SHORT | W_LONG);
  if (ptm->from == E8) *casp &= (W_SHORT | W_LONG);
  else if (ptm->from == E1) *casp &= (B_SHORT | B_LONG);
  
  if ((Board[ptm->from] & (wP|bP)) && abs(ptm->from-ptm->to) == A6-A8) // pawn goes 2 steps 
    *epp = 'a'+column(ptm->from);
  else *epp = 0;

  if (*Xpiece = Board[ptm->to]) TakePiece(PieceIndex[*Xpiece],ptm->to)
  MovePiece(PieceIndex[Board[ptm->from]],ptm->from,ptm->to)

  if (ptm->flag & CASTLE) {
    switch(ptm->to) {
      case G8:MovePiece(bRindex,H8,F8);break;
      case C8:MovePiece(bRindex,A8,D8);break;
      case C1:MovePiece(wRindex,A1,D1);break;
      case G1:MovePiece(wRindex,H1,F1);break;
    }
  } else if (ptm->flag & EN_PASSENT) {
    if (!lWTM) TakePiece(wPindex,ptm->to-(A7-A8)) /* black takes white */
    else      TakePiece(bPindex,ptm->to+(A7-A8))
  } else
    if (ptm->flag & PROMOTION) {
      if (!lWTM) /* black promotes */ {
        TakePiece(bPindex,ptm->to) /* take pawn */
	if ((ptm->flag & PROMOTION) == PROM_Q) PutPiece(bQindex,ptm->to,bQ) 
	else if ((ptm->flag & PROMOTION) == PROM_N) PutPiece(bNindex,ptm->to,bN) 
	else if ((ptm->flag & PROMOTION) == PROM_R) PutPiece(bRindex,ptm->to,bR) 
	else if ((ptm->flag & PROMOTION) == PROM_B) PutPiece(bBindex,ptm->to,bB) 
      } else {
        TakePiece(wPindex,ptm->to) /* take pawn */
	if ((ptm->flag & PROMOTION) == PROM_Q) PutPiece(wQindex,ptm->to,wQ) 
	else if ((ptm->flag & PROMOTION) == PROM_N) PutPiece(wNindex,ptm->to,wN) 
	else if ((ptm->flag & PROMOTION) == PROM_R) PutPiece(wRindex,ptm->to,wR) 
	else if ((ptm->flag & PROMOTION) == PROM_B) PutPiece(wBindex,ptm->to,wB) 
      }
    }
}  
      
      
void APILchess::UndoMove(Move *ptm,int16 Xpiece, int8 *epp, int8 saved_ep, int8 *casp, int8 saved_cas, int8 lWTM, int8 UndoG)
  //ptm: a pointer to the move that must be undone
  //Xpiece: the captured piece
  //epp: a pointer to the en_passent variable; is set to saved_ep
  //epp: a pointer to the castle variable; is set to saved_cas
  //lWTM: white to move?
  //UndoG: Undo the move of the Guest, as well
{
  if (!IsNullmove(*ptm)) {
      *epp = saved_ep;
      *casp = saved_cas;
      
      if (ptm->flag & CASTLE) {
	switch(ptm->to) {
	 case G8:MovePiece(bRindex,F8,H8);break;
	 case C8:MovePiece(bRindex,D8,A8);break;
	 case C1:MovePiece(wRindex,D1,A1);break;
	 case G1:MovePiece(wRindex,F1,H1);break;
	}
      } else if (ptm->flag & EN_PASSENT) {
	if (!lWTM) PutPiece(wPindex,ptm->to-(A7-A8),wP) /* black takes white */
	else      PutPiece(bPindex,ptm->to+(A7-A8),bP)
      } else
	if (ptm->flag & PROMOTION) {
	  if (!lWTM) {
	    if ((ptm->flag & PROMOTION) == PROM_Q) TakePiece(bQindex,ptm->to) 
	    else if ((ptm->flag & PROMOTION) == PROM_N) TakePiece(bNindex,ptm->to) 
	    else if ((ptm->flag & PROMOTION) == PROM_R) TakePiece(bRindex,ptm->to) 
	    else if ((ptm->flag & PROMOTION) == PROM_B) TakePiece(bBindex,ptm->to) 
	    PutPiece(bPindex,ptm->to,bP) /* put pawn */
          } else {
	    if ((ptm->flag & PROMOTION) == PROM_Q) TakePiece(wQindex,ptm->to) 
	    else if ((ptm->flag & PROMOTION) == PROM_N) TakePiece(wNindex,ptm->to) 
	    else if ((ptm->flag & PROMOTION) == PROM_R) TakePiece(wRindex,ptm->to) 
	    else if ((ptm->flag & PROMOTION) == PROM_B) TakePiece(wBindex,ptm->to) 
	    PutPiece(wPindex,ptm->to,wP) /* take pawn */
							  }
	}
      
      MovePiece(PieceIndex[Board[ptm->to]],ptm->to,ptm->from);
      if (Xpiece) PutPiece(PieceIndex[Xpiece],ptm->to,Xpiece)
  }
  if (UndoG) GuestUndoMove(ptm, Xpiece, *epp, *casp, lWTM);
}

static const int8 interfere[] = {  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
				   0,  0,  0,  0,  0,  0,  0,  0,  0,  7,  0,  0,  0,  0,  0,  0,
				   2,  0,  0,  0,  0,  0,  0,  6,  0,  0,  7,  0,  0,  0,  0,  0,
				   2,  0,  0,  0,  0,  0,  6,  0,  0,  0,  0,  7,  0,  0,  0,  0,
				   2,  0,  0,  0,  0,  6,  0,  0,  0,  0,  0,  0,  7,  0,  0,  0,
				   2,  0,  0,  0,  6,  0,  0,  0,  0,  0,  0,  0,  0,  7,  0,  0,
				   2,  0,  0,  6,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  7,  9,
				   2,  9,  6,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  9,  7,
				   2,  6,  9,  0,  0,  0,  0,  0,  0,  3,  3,  3,  3,  3,  3,  3,
			    /*144*/0,  4,  4,  4,  4,  4,  4,  4,  0,  0,  0,  0,  0,  0,  9,  5,
				   1,  8,  9,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  5,  9,
				   1,  9,  8,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  5,  0,  0,
				   1,  0,  0,  8,  0,  0,  0,  0,  0,  0,  0,  0,  5,  0,  0,  0,
				   1,  0,  0,  0,  8,  0,  0,  0,  0,  0,  0,  5,  0,  0,  0,  0,
				   1,  0,  0,  0,  0,  8,  0,  0,  0,  0,  5,  0,  0,  0,  0,  0,
				   1,  0,  0,  0,  0,  0,  8,  0,  0,  5,  0,  0,  0,  0,  0,  0,
				   1,  0,  0,  0,  0,  0,  0,  8,  0,  0,  0,  0,  0,  0,  0,  0,
				   0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0};

int16 APILchess::connected(unsigned int8 from,unsigned int8 to,int16 piece)
 {
  int16 *hp;
  int16 *tofield;

  tofield = Board + to;
  switch(interfere[(int)from - (int)to + 144])
   {
    case 0: return 0;
    case 1: if (piece & (bQ | bR | wQ | wR)) {
             for (hp = Board + from - Linc;!(*hp) && (hp != tofield);hp -= Linc) ;
             if (hp == tofield) return(1);
             else               return(0);
            } else return(0);
    case 2: if (piece & (bQ | bR | wR | wQ)) {
             for (hp = Board + from + Linc;!(*hp) && (hp != tofield);hp += Linc) ;
             if (hp == tofield) return(1);
             else               return(0);
            } else return(0);
    case 3: if (piece & (bQ | bR | wR | wQ)) {
             for (hp = Board + from + Cinc;!(*hp) && (hp != tofield);hp+=Cinc) ;
             if (hp == tofield) return(1);
             else               return(0);
            } else return(0);
    case 4: if (piece & (bQ | bR | wR | wQ)) {
             for (hp = Board + from - Cinc;!(*hp) && (hp != tofield);hp-=Cinc) ;
             if (hp == tofield) return(1);
             else               return(0);
            } else return(0);
    case 5:if (piece  & (bQ | bB | wQ | wB)) {
             for (hp = Board + from - A1H8inc;!(*hp) && (hp != tofield);hp -= A1H8inc) ;
             if (hp == tofield) return(1);
             else               return(0);
            } else return(0);
    case 6: if (piece & (bQ | bB | wQ | wB)) {
             for (hp = Board + from + A1H8inc;!(*hp) && (hp != tofield);hp += A1H8inc) ;
             if (hp == tofield) return(1);
             else               return(0);
            } else return(0);
    case 7: if (piece & (bQ | bB | wQ | wB)) {
             for (hp = Board + from + H1A8inc;!(*hp) && (hp != tofield);hp += H1A8inc) ;
             if (hp == tofield) return(1);
             else               return(0);
            } else return(0);
    case 8: if (piece & (bQ | bB | wQ | wB)) {
             for (hp = Board + from - H1A8inc;!(*hp) && (hp != tofield);hp -= H1A8inc) ;
	     if (hp == tofield) return(1);
	     else               return(0);
            } else return(0);
    case 9: if (piece & (bN | wN)) return(1);
            else                   return(0);
    default: return(0);
   }
 }

int16 APILchess::FieldIsAttacked(unsigned int8 f, int8 lWTM)
{
  int k;
  
  if (lWTM) {
    // lWTM? -> look up whether black attacks f
    if ((Board[f-H1A8inc] | Board[f-A1H8inc]) & bP) return bP;
    if (abs(line(f)-line(Pieces[bKindex][0])) <= 1 && abs(column(f)-column(Pieces[bKindex][0])) <= 1) return bK;
    for (k=0;k<PieceCnt[bNindex];k++) if (connected(f,Pieces[bNindex][k],bN)) return bN;
    for (k=0;k<PieceCnt[bBindex];k++) if (connected(f,Pieces[bBindex][k],bB)) return bB;
    for (k=0;k<PieceCnt[bRindex];k++) if (connected(f,Pieces[bRindex][k],bR)) return bR;
    for (k=0;k<PieceCnt[bQindex];k++) if (connected(f,Pieces[bQindex][k],bQ)) return bQ;
  } else {
    if ((Board[f+H1A8inc] | Board[f+A1H8inc]) & wP) return wP;    
    if (abs(line(f)-line(Pieces[wKindex][0])) <= 1 && abs(column(f)-column(Pieces[wKindex][0])) <= 1) return wK;
    for (k=0;k<PieceCnt[wNindex];k++) if (connected(f,Pieces[wNindex][k],wN)) return wN;
    for (k=0;k<PieceCnt[wBindex];k++) if (connected(f,Pieces[wBindex][k],wB)) return wB;
    for (k=0;k<PieceCnt[wRindex];k++) if (connected(f,Pieces[wRindex][k],wR)) return wR;
    for (k=0;k<PieceCnt[wQindex];k++) if (connected(f,Pieces[wQindex][k],wQ)) return wQ;
  }
  return 0;
}

#ifdef LINUX
#define ADD2LIST(m_list,m_np,m_f,m_t,m_flag) (m_list)[(*(m_np))++] = ((Move){(m_f),(m_t),(m_flag)});
#endif
#ifdef WIN32
#define ADD2LIST(m_list,m_np,m_f,m_t,m_flag) \
{                                            \
  (m_list)[(*(m_np))].from = (m_f);          \
  (m_list)[(*(m_np))].to = (m_t);            \
  (m_list)[(*(m_np))].flag = (m_flag);       \
  (*(m_np))++;                               \
}
#endif

void APILchess::RookMoves(Move* list, Move *Xlist, unsigned int8 from, int8 lWTM, int *np, int *xnp)
{
  int to;
  int i;
  static const int incs[] = {Linc,-Linc,Cinc,-Cinc};
  
  for (i=0;i<4;i++) {
    for (to=from+incs[i];!Board[to];to+=incs[i]) ADD2LIST(list,np,from,to,0)
    if (Board[to] & (lWTM?BLACK:WHITE)) ADD2LIST(Xlist,xnp,from,to,CAPTURE)
  }
}

void APILchess::BishopMoves(Move* list, Move *Xlist, unsigned int8 from, int8 lWTM, int *np, int *xnp)
{
  int to;
  int n=0,i;
  static const int incs[] = {A1H8inc,-A1H8inc,H1A8inc,-H1A8inc};
  
  for (i=0;i<4;i++) {
    for (to=from+incs[i];!Board[to];to+=incs[i]) ADD2LIST(list,np,from,to,0)
    if (Board[to] & (lWTM?BLACK:WHITE)) ADD2LIST(Xlist,xnp,from,to,CAPTURE)
  }
}

void APILchess::KingMoves(Move* list, Move *Xlist, unsigned int8 from, int8 lWTM, int *np, int *xnp)
{
  int to;
  int n=0,i;
  static const int incs[] = {Linc,-Linc,Cinc,-Cinc,A1H8inc,-A1H8inc,H1A8inc,-H1A8inc};
  
  for (i=0;i<8;i++) {
    to = from+incs[i];
    if (!Board[to]) ADD2LIST(list,np,from,to,0)
    else if (Board[to] & (lWTM?BLACK:WHITE)) ADD2LIST(Xlist,xnp,from,to,CAPTURE)
  }

  if ((castle_state & (lWTM?W_SHORT:B_SHORT)) &&
      !FieldIsAttacked(from, lWTM) && !FieldIsAttacked(from+Cinc, lWTM) && !FieldIsAttacked(from+Cinc+Cinc, lWTM) &&
      !Board[from+Cinc] && !Board[from+Cinc+Cinc]) 
    ADD2LIST(list,np,from,from+Cinc+Cinc,CASTLE)
  if ((castle_state & (lWTM?W_LONG:B_LONG)) &&
      !FieldIsAttacked(from, lWTM) && !FieldIsAttacked(from-Cinc, lWTM) && !FieldIsAttacked(from-Cinc-Cinc, lWTM) &&
      !Board[from-Cinc] && !Board[from-Cinc-Cinc] && !Board[from-Cinc-Cinc-Cinc])
    ADD2LIST(list,np,from,from-Cinc-Cinc,CASTLE) 
}

void APILchess::KnightMoves(Move* list, Move *Xlist, unsigned int8 from, int8 lWTM, int *np, int *xnp)
{
  int to;
  int n=0,i;
  static const int incs[] = {Linc+A1H8inc,Linc+H1A8inc,   -Linc-A1H8inc,-Linc-H1A8inc, 
                             Cinc-A1H8inc,Cinc+H1A8inc,   -Cinc+A1H8inc,-Cinc-H1A8inc};
  
  for (i=0;i<8;i++) {
    to = from+incs[i];
    if (!Board[to]) ADD2LIST(list,np,from,to,0)
    else if (Board[to] & (lWTM?BLACK:WHITE)) ADD2LIST(Xlist,xnp,from,to,CAPTURE)
  }
}

void APILchess::PawnMoves(Move* list, Move *Xlist, unsigned int8 from, int8 lWTM, int *np, int *xnp)
{
  int to, epf;
  int n=0;
  int PromLine = (lWTM?line(A8):line(A1));
  int Opp=(lWTM?BLACK:WHITE);

  to = from+(lWTM?-Linc:Linc);
  if (!Board[to]) {
    if (line(to) == PromLine) {
      ADD2LIST(list,np,from,to,PROM_Q|PAWNMOVE)
      ADD2LIST(list,np,from,to,PROM_N|PAWNMOVE)
      ADD2LIST(list,np,from,to,PROM_R|PAWNMOVE)
      ADD2LIST(list,np,from,to,PROM_B|PAWNMOVE)
    } else ADD2LIST(list,np,from,to,PAWNMOVE)
    to += (lWTM?-Linc:Linc);
    if (line(from) == line(lWTM?A2:A7) && !Board[to]) ADD2LIST(list,np,from,to,PAWNMOVE)
  }
  to = from+(lWTM?-A1H8inc:A1H8inc);
  if (Board[to] & Opp) {
    if (line(to) == PromLine) {
      ADD2LIST(Xlist,xnp,from,to,CAPTURE|PROM_Q|PAWNMOVE)
      ADD2LIST(Xlist,xnp,from,to,CAPTURE|PROM_N|PAWNMOVE)
      ADD2LIST(Xlist,xnp,from,to,CAPTURE|PROM_R|PAWNMOVE)
      ADD2LIST(Xlist,xnp,from,to,CAPTURE|PROM_B|PAWNMOVE)
    } else ADD2LIST(Xlist,xnp,from,to,CAPTURE|PAWNMOVE)
  }
  to = from+(lWTM?-H1A8inc:H1A8inc);
  if (Board[to] & Opp) {
    if (line(to) == PromLine) {
      ADD2LIST(Xlist,xnp,from,to,CAPTURE|PROM_Q|PAWNMOVE)
      ADD2LIST(Xlist,xnp,from,to,CAPTURE|PROM_N|PAWNMOVE)
      ADD2LIST(Xlist,xnp,from,to,CAPTURE|PROM_R|PAWNMOVE)
      ADD2LIST(Xlist,xnp,from,to,CAPTURE|PROM_B|PAWNMOVE)
    } else ADD2LIST(Xlist,xnp,from,to,CAPTURE|PAWNMOVE)
  }

  if (en_passent) {
    if (lWTM) {
      epf = (line(A5)*16) + en_passent - 'a';
      if (from == epf-Cinc || from == epf+Cinc) ADD2LIST(Xlist,xnp,from,epf-Linc,CAPTURE|EN_PASSENT|PAWNMOVE) 
    } else {
      epf = (line(A4)*16) + en_passent - 'a';    
      if (from == epf-Cinc || from == epf+Cinc) ADD2LIST(Xlist,xnp,from,epf+Linc,CAPTURE|EN_PASSENT|PAWNMOVE) 
    }
  }
}

void APILchess::GenerateMoves(Move* list, Move* Xlist, int8 lWTM, int *np, int *xnp)
{
  int ofs=lWTM?0:6;
  int i,k;
  
  Move *mp,*mp2;
  Move buf;

  *np = *xnp = 0;
  
  for (k=0,i=wPindex+ofs;k<PieceCnt[i];k++) PawnMoves(list,Xlist,Pieces[i][k],lWTM,np,xnp);
  for (k=0,i=wNindex+ofs;k<PieceCnt[i];k++) KnightMoves(list,Xlist,Pieces[i][k],lWTM,np,xnp);
  for (k=0,i=wBindex+ofs;k<PieceCnt[i];k++) BishopMoves(list,Xlist,Pieces[i][k],lWTM,np,xnp);
  for (k=0,i=wRindex+ofs;k<PieceCnt[i];k++) RookMoves(list,Xlist,Pieces[i][k],lWTM,np,xnp);
  for (k=0,i=wQindex+ofs;k<PieceCnt[i];k++){
           RookMoves(list,Xlist,Pieces[i][k],lWTM,np,xnp);
           BishopMoves(list,Xlist,Pieces[i][k],lWTM,np,xnp);
  }
  for (k=0,i=wKindex+ofs;k<PieceCnt[i];k++) KingMoves(list,Xlist,Pieces[i][k],lWTM, np,xnp);
  
  for (mp = Xlist;mp < Xlist+5 && mp < Xlist+*xnp-1;mp++) //sort captures to front
    for (mp2 = Xlist+*xnp-2;mp2 >= Xlist;mp2--) {
      if (Board[mp2->to] < Board[(mp2+1)->to]) {
	buf = *mp2;
	*mp2 = *(mp2+1);
	*(mp2+1) = buf;
      }
    }
}

void APILchess::ExtractLegalMoves(Move *list, Move *Xlist, int8 lWTM , int* n, int* xn)
{
  Move *l;
  int legals,legal,i,j;
  int16 xp;
  int8 save_casp;
  int8 save_ep;
  
  //if (xn > 0 && (Board[Xlist[0].to] & (wK|bK))) return INFTY;

  legals=0;
  for (i=0;i<*xn;i++) {
    l = Xlist;
    save_casp = castle_state;
    save_ep = en_passent;
    DoMove(&l[i], &xp, &castle_state, &en_passent, lWTM, false);
    lWTM = 1 - lWTM;
    if (lWTM) {
      if(FieldIsAttacked(Pieces[PieceIndex[bK]][0],1-lWTM)) legal = false;
      else legal = true;
    } else {
      if(FieldIsAttacked(Pieces[PieceIndex[wK]][0],1-lWTM)) legal = false;
      else legal = true;
    }
    lWTM = 1 - lWTM;
    UndoMove(&l[i], xp, &en_passent, save_ep , &castle_state, save_casp, lWTM, false);

    if (!legal) {
      for (j = i;j < (*xn)-1;j++) l[j] = l[j+1];
      (*xn)--;
      i--;
    }
  }
  for (i=0;i<*n;i++) {
    l = list;
    save_casp = castle_state;
    save_ep = en_passent;
    DoMove(&l[i], &xp, &castle_state, &en_passent, lWTM, false);
    lWTM = 1 - lWTM;
    if (lWTM) {
      if(FieldIsAttacked(Pieces[PieceIndex[bK]][0],1-lWTM)) legal = false;
      else legal = true;
    } else {
      if(FieldIsAttacked(Pieces[PieceIndex[wK]][0],1-lWTM)) legal = false;
      else legal = true;
    }
    lWTM = 1 - lWTM;
    UndoMove(&l[i], xp, &en_passent, save_ep , &castle_state, save_casp, lWTM, false);

    if (!legal) {
      for (j = i;j < (*n)-1;j++) l[j] = l[j+1];
      (*n)--;
      i--;
    }
  }
}


void APILchess::ClearNodes(void)
{
  nodes = 0;
  t1_n=t2_n=t3_n=t4_n=t5_n=0;
}

int64 APILchess::GetNodes(void)
{
  return nodes;
}

void APILchess::PrintTypeCnt(void)
{
  char nodestr[1000];
  char nodes[100];
  strcpy(nodestr,"info string ");
  if (t1_n/1000000 > 0) sprintf(nodes,"%d%d",(int)(t1_n/1000000),(int)(t1_n%1000000));
  else sprintf(nodes,"%d",(int)(t1_n%1000000));
  strcat(nodestr,"Type I: ");
  strcat(nodestr,nodes);
  strcat(nodestr,", ");
  if (t2_n/1000000 > 0) sprintf(nodes,"%d%d",(int)(t2_n/1000000),(int)(t2_n%1000000));
  else sprintf(nodes,"%d",(int)(t2_n%1000000));
  strcat(nodestr,"Type II: ");
  strcat(nodestr,nodes);
  strcat(nodestr,", ");
  if (t3_n/1000000 > 0) sprintf(nodes,"%d%d",(int)(t3_n/1000000),(int)(t3_n%1000000));
  else sprintf(nodes,"%d",(int)(t3_n%1000000));
  strcat(nodestr,"Type III: ");
  strcat(nodestr,nodes);
  strcat(nodestr,", ");
  if (t4_n/1000000 > 0) sprintf(nodes,"%d%d",(int)(t4_n/1000000),(int)(t4_n%1000000));
  else sprintf(nodes,"%d",(int)(t4_n%1000000));
  strcat(nodestr,"Type IV: ");
  strcat(nodestr,nodes);
  strcat(nodestr,", ");
  if (t5_n/1000000 > 0) sprintf(nodes,"%d%d",(int)(t5_n/1000000),(int)(t5_n%1000000));
  else sprintf(nodes,"%d",(int)(t5_n%1000000));
  strcat(nodestr,"Type V: ");
  strcat(nodestr,nodes);
  printf("%s\n",nodestr);
  fflush(stdout);
}

void APILchess::PrintNodeCnt(void)
{
  char nodestr[1000];
  char lnodes[100];
  strcpy(nodestr,"info string ");
  if ((nodes)/1000000 > 0) sprintf(lnodes,"%d%d",(int)((nodes)/1000000),(int)((nodes)%1000000));
  else sprintf(lnodes,"%d",(int)((nodes)%1000000));

  strcat(nodestr,"all: ");
  strcat(nodestr,lnodes);
  printf("%s\n",nodestr);
  fflush(stdout);
}

int APILchess::Eval(int16 a, int16 b, int8 lWTM)
{
  typedef struct MSentry_t {
    int32 lock;
    int val;
  } MSentry;
  static MSentry MStab[1024];
  static const int mat[]={0,100,300,300,500,900,0,-100,-300,-300,-500,-900,0,0,0,0};
  int s=0,i;
  //if (lWTM) return 300;
  //else return -300;
  MSentry *mse=&MStab[MaterialSignatur & 1023];
  if (mse->lock != MaterialSignatur) {
    for(i = 1;i <= 12;i++)
      s+=(mat[i]*PieceCnt[i]);
    mse->val = s;
    mse->lock = MaterialSignatur;
  }
  
  s = mse->val;
  if (lWTM) return s;
  else return -s;
}

static int NODE_ID=0;
int APILchess::ComputeNodeID()
{
  return NODE_ID++;
}

int APILchess::ProblemOnTour(LocalVariables* LV)
{
  for (int i=0;i < LV->n+LV->xn;i++) {
    if (LV->IsRemote[i] != 0 && LV->IsRemote[i] != -1) return true;
  }
  return false;
}

#define StepRETURN(s,r) \
{\
   *(r) = -(s);\
   LocalVariables *LV = ParSt->Pop();\
   for(int k=0;k<LV->n;k++) (*LV->counter)+=LV->ncount[k];\
   (*LV->counter)+=LV->nmcount;                  \
   if (LV->d == 0) for(int k=0;k<LV->n;k++) LV->counter[k]=LV->ncount[k];\
   if (W) W->Deliver(LV,C,IterationCnt); else if (M) M->Deliver(LV,C,IterationCnt);\
   delete LV;\
   return 0;\
}

int APILchess::AlphabetaStep(ParStack<LocalVariables> *ParSt, Hashtable *H)
{
  LocalVariables *LV = ParSt->GetLstStEl();

  switch (LV->status) {
    case START      : goto STlabel;
    case REKURSION_1: goto RE1label;    
    case REKURSION_2: goto RE2label;    
    case REKURSION_4: goto RE4label;    
    case SYNC_1: goto Sy1label;    
    case SYNC_5: goto Sy5label;    
  }

 STlabel:

  LV->store_a = LV->a;
  LV->store_b = LV->b;  
  LV->n = 0;
  LV->hashvalue = hashvalue;
  LV->nmcount=0;
  NodeCounting(LV->node_type,LV->counter);

  if (-MATE_VAL+LV->d>=LV->b) StepRETURN(-MATE_VAL+LV->d,LV->result)
  if (LV->d>0 && Draw(hashvalue,castle_state,en_passent,LV->WTM)) StepRETURN(0,LV->result)

  if (LV->WTM ? FieldIsAttacked(Pieces[6][0],LV->WTM) : FieldIsAttacked(Pieces[12][0],LV->WTM)) LV->ExtType|=EXT_CHECK;

  if (IsNullmove(*LV->pMv)) LV->ExtType=EXT_NMV;
  if (LV->ExtType&EXT_CHECK) LV->rd++;

  if (LV->a == LV->b-1 && !(LV->ExtType&EXT_CHECK) && !IsNullmove(*LV->pMv)) LV->donull = true;
  else LV->donull=false;
 
  LV->nodeID = ComputeNodeID();
  LV->s=-INFTY;
  LV->u=LV->a;LV->o=LV->b;

  if(LV->d > 0 && (LV->rd <= gran_con || LV->rd <= 0 || LV->d >= MAX_SEARCH_DEPTH)) { 
    // perform a fast sequential search without any interrupt
    LV->v = Alphabeta(LV->a,LV->b,LV->rd,LV->d,LV->pMv,LV->WTM,LV->node_type,LV->counter,LV->oppext,LV->ownext,&(LV->bMv),H);
    if (LV->bMv.from != 255 && LV->bMv.from != LV->bMv.to && (/*LV->rd>0 ||*/ LV->v>LV->a)) {
      *(LV->pbMv) = LV->bMv;
      //H->PushHash(LV->pbMv,LV->v<=LV->a?FAILL:(LV->v>=LV->b?FAILH:EXACT), 
      //                      LV->v<=LV->a?LV->a:(LV->v>=LV->b?LV->b:LV->v), LV->rd, true, hashvalue,castle_state, en_passent, LV->WTM);
      InsertKiller(LV->d,LV->pbMv);
      InsertHistory(LV->rd,LV->pbMv);
    }
    StepRETURN(LV->v,LV->result)
  }

  // What follows serves sorting
  // Initiate a Hashtable enquiry, asynchronously
  LV->hashcodeID = 
      H->SendQuery(hashvalue,castle_state, en_passent, LV->WTM, true, LV->nodeID, &LV->hv, &LV->hrd, &LV->hf, &LV->bMv, &LV->Xflgs, &LV->extMv, &LV->Xhrd,LV->rd);

  GenerateMoves(LV->list,LV->Xlist,LV->WTM,&LV->n,&LV->xn);
  if (LV->xn > 0 && (Board[LV->Xlist[0].to] & (wK|bK))) StepRETURN(INFTY,LV->result)
  for (int k=0;k<LV->n+LV->xn;k++) LV->ncount[k]=0;
  for (int k=0;k<LV->n+LV->xn;k++) LV->IsRemote[k]=0;

  LV->status = SYNC_1;
  return 0; Sy1label:;
  
  // exploit the hashtable answer, if available
  if (LV->hf != NO_ENTRY) {
    if (LV->hrd>=LV->rd && LV->d > 0) {
      if (LV->hf == EXACT || (LV->hf == FAILH && LV->hv>=LV->b) || (LV->hf == FAILL && LV->hv<=LV->a )) {
	InsertKiller(LV->d,&LV->bMv);	
        if (LV->hf == EXACT) StepRETURN(LV->hv,LV->result)
        else if (LV->hf == FAILL) StepRETURN(LV->hv/*a*/,LV->result)
	else if (LV->hf == FAILH) StepRETURN(LV->hv/*b*/,LV->result)
      }
    }
    if (LV->hrd>=LV->rd-3 && (LV->hf == FAILL || LV->hf == EXACT) && LV->hv<=LV->a) 
      LV->donull=false;
  }
  
  //do Nullmove
  if (LV->donull) {
    LV->s=-INFTY;
    LV->nd = LV->rd-3-(LV->rd>6);

    LV->save_casp = castle_state;
    LV->save_ep = en_passent;
    LV->curMv = LV->nullmove;
    en_passent=0;
    DoMove(&LV->nullmove, &LV->xp, &castle_state, &en_passent, LV->WTM, true);
    LV->status = REKURSION_4;
    ParSt->Push(new LocalVariables(-LV->b,-LV->b+1,LV->nd,LV->d+1,&LV->nullmove,1-LV->WTM,&LV->v,START,5,&LV->nmcount,LV->oppext,LV->ownext,&(LV->dummyMv),LV->PExtType,LV->ExtType,0));
    return 0;
    RE4label:
    en_passent=LV->save_ep;
    UndoMove(&LV->nullmove, LV->xp, &en_passent, LV->save_ep , &castle_state, LV->save_casp, LV->WTM, true);
    if (LV->v >= LV->b) {
      StepRETURN(LV->v/*b*/,LV->result)
    }
  }
  // end of nullmove section
  
  // 1st attempt to guess a good move: Old PV
  // by exploited hashtable

  if (LV->d==0) ExtractLegalMoves(LV->list,LV->Xlist,LV->WTM,&LV->n,&LV->xn);
  // Now merge the two move lists 
  MergeMoves(LV->list,&LV->n,LV->Xlist,&LV->xn);
  // Sort the moves and put a nice move to front
  SortMoves(LV->list,&LV->n,&LV->bMv,LV->d,LV->rd,LV->a,LV->b);

  // Negascout-Search
  LV->s=-INFTY;
  LV->u=LV->a;LV->o=LV->b;
  LV->legals=0;
  
  for (LV->i=0,LV->l=LV->list;LV->i<LV->n;LV->i++) {
    if (LV->IsRemote[0] || LV->IsRemote[1]) { printf("illegal remote work\n");fflush(stdout);}
    if (LV->IsRemote[LV->i]) continue;
    AddVar(LV->d,&LV->l[LV->i]);
    LV->save_casp = castle_state;
    LV->save_ep = en_passent;
    LV->curMv = LV->l[LV->i];
    DoMove(&LV->l[LV->i], &LV->xp, &castle_state, &en_passent, LV->WTM, true);
   
    LV->status = REKURSION_1;
    ParSt->Push(new LocalVariables(-LV->o,-LV->u,LV->rd-1,LV->d+1,&LV->l[LV->i],1-LV->WTM,&LV->v, START,NodeType(LV->node_type,LV->i),&LV->ncount[LV->i],
                                    LV->oppext,
                                    LV->ownext+((LV->extfound && LV->curMv.from==LV->extMv.from && LV->curMv.to==LV->extMv.to)?LV->ext:0),
                                    &(LV->dummyMv),LV->PExtType,LV->ExtType,LV->xp));
    //AlphabetaStep(ParSt,H);
    return 0;
     RE1label:
    //LV = ParSt->GetLstStEl();

    if (LV->v > LV->u && LV->v < LV->b && LV->i > 0) {
      LV->status = REKURSION_2;
      ParSt->Push(new LocalVariables(-LV->b,-LV->v,LV->rd-1,LV->d+1,&LV->l[LV->i],1-LV->WTM,&LV->v, START,NodeType(LV->node_type,LV->i),&LV->ncount[LV->i],
                                      LV->oppext,
				      LV->ownext+((LV->extfound && LV->curMv.from==LV->extMv.from && LV->curMv.to==LV->extMv.to)?LV->ext:0),
                                      &(LV->dummyMv),LV->PExtType,LV->ExtType,LV->xp));
      //AlphabetaStep(ParSt,H);
      return 0;
    }
    RE2label:
    //LV = ParSt->GetLstStEl();

    UndoMove(&LV->l[LV->i], LV->xp, &en_passent, LV->save_ep , &castle_state, LV->save_casp, LV->WTM, true);
    if (LV->v > -INFTY) LV->legals++;
    if (LV->v > LV->s) {
      VarImproved(LV->d);
      *(LV->pbMv) = LV->l[LV->i];
      LV->bMcnt = LV->ncount[LV->i];
      LV->s = LV->v;
      if (LV->s >= LV->b) {
        H->PushHash(LV->pbMv,FAILH, LV->b, LV->rd, true, hashvalue,castle_state, en_passent, LV->WTM);
	if (LV->ext>0) H->PushExt(LV->rd,true, hashvalue,castle_state, en_passent, LV->WTM,LV->pbMv,LV->ExtType);
        InsertKiller(LV->d,LV->pbMv);      
	InsertHistory(LV->bMcnt,LV->pbMv);
	StepRETURN(LV->s/*b*/,LV->result)
      }
    }
    if (LV->s > LV->u) LV->u = LV->s;
    LV->o = LV->u+1;
  }

  Sy5label:;
  LV->status = SYNC_5;
  if (ProblemOnTour(LV)) return 0; 
  //for (int k=0;k<LV->n+LV->xn;k++) LV->IsRemote[k]=-1;

  if (LV->legals == 0) {
    if((LV->ExtType&EXT_CHECK)) StepRETURN(-MATE_VAL+LV->d,LV->result)
    else StepRETURN(0,LV->result)
  }
  
  H->PushHash(LV->pbMv,LV->s>LV->a?EXACT:FAILL, LV->s, LV->rd, true, hashvalue,castle_state, en_passent, LV->WTM);
  if (LV->s>LV->a) 
     if (LV->ext>0) H->PushExt(LV->rd,true, hashvalue,castle_state, en_passent, LV->WTM,LV->pbMv,LV->ExtType);
  //  int64 bMcnt;
  if (LV->s > LV->a) InsertKiller(LV->d,LV->pbMv);      
  if (LV->s > LV->a) InsertHistory(LV->bMcnt,LV->pbMv);
  StepRETURN(LV->s,LV->result)
    
}

int APILchess::Alphabeta(int16 a, int16 b, int16 rd, int16 d, Move* pMv, int8 lWTM, int8 ntype, int64 *counter, int ownext, int oppext, Move* pbMv, Hashtable *H)
{
  Move list[250];
  Move Xlist[50];
  Move *l;
  Move bMv;bMv.from = 255;
  Move extMv;extMv.from = 255;
  Move nullmove;nullmove.from = NULLMOVE_SQ;
  
  int n,xn,i,legals,j,InCheck,donull;
  int16 s=-INFTY,v,u=a,o=b;
  int16 hv,hrd,hf=NO_ENTRY,xhf=NO_ENTRY,xhrd;
  int nodeID = ComputeNodeID();

  int16 xp;
  int8 save_casp;
  int8 save_ep;
  
  InCheck = lWTM ? FieldIsAttacked(Pieces[6][0],lWTM) : FieldIsAttacked(Pieces[12][0],lWTM);
  if (InCheck) rd++;
  if (a == b-1 && !InCheck && !IsNullmove(*pMv)) donull = true;
  else donull=false;
  
  if(rd <= 0) {
    v = Eval(a,b,lWTM);
    if(v>=s) {
      s = v;
      if (s >= b) return b;
    }
  }

  GenerateMoves(list,Xlist,lWTM,&n,&xn);
  
  if (xn > 0 && (Board[Xlist[0].to] & (wK|bK))) return INFTY;

  MergeMoves(list,&n,Xlist,&xn);

  if (hf != NO_ENTRY) {
    if (hrd>=rd && d > 1) {
      if (hf == EXACT || (hf == FAILH && hv>=b) || (hf == FAILL && hv<=a )) {
        InsertKiller(d,&bMv);      
        if (hf == EXACT)      return hv;
	else if (hf == FAILL) return hv;
	else if (hf == FAILH) return hv;
      }
    }
    if (hrd>=rd-3 && (hf == FAILL || hf == EXACT) && hv<=a) 
      donull=false;
  }

  legals=0;
  for (i=0;i<xn+n;i++) {
    if (i < xn) {
      l = Xlist;
      j = i;
    } else {
      l = list;
      j = i-xn;
    }
    if (rd <= 0 && !(l[j].flag & CAPTURE)) break;
    if (rd > 0) AddVar(d,&l[j]);
    save_casp = castle_state;
    save_ep = en_passent;
    DoMove(&l[j], &xp, &castle_state, &en_passent, lWTM, true);
    v = -Alphabeta(-o,-u,rd-1,d+1, &l[j],1-lWTM,NodeType(ntype,i),counter,oppext,ownext,&bMv,H);
    if (v > -INFTY) legals++;
    if (v > u && v < b && i > 0)  v = -Alphabeta(-b,-v,rd-1,d+1, &l[j],1-lWTM,NodeType(ntype,i),counter,oppext,ownext,&bMv,H);
    UndoMove(&l[j], xp, &en_passent, save_ep , &castle_state, save_casp, lWTM, true);
    if (v > u) u = v;
    o = u+1;
    if (v > s) {
      if (rd > 0) VarImproved(d);
      bMv = l[j];
      s = v;
      if (s >= b) {
        InsertKiller(d,&bMv);      
	H->PushHash(&bMv,FAILH, b, rd, false, hashvalue,castle_state, en_passent, lWTM);
	return s;
      }
    }
  }

  if (legals == 0 && rd > 0) {
    if (InCheck) return -MATE_VAL+d;
    else return 0;
  }

  if (bMv.from != 255) InsertKiller(d,&bMv);      
  if (bMv.from != 255) H->PushHash(&bMv,s>a?EXACT:FAILL, b, rd, false, hashvalue,castle_state, en_passent, lWTM);
  return s;
}

void APILchess::MergeMoves(Move* list, int* n, Move* Xlist, int* xn)
{
  int i;
  
  for (i = (*n)+(*xn)-1;i >= (*xn);i--) list[i] = list[i-(*xn)];
  for (i = (*xn)-1;i>=0;i--) list[i] = Xlist[i];
  (*n)  = (*n)+(*xn);
  (*xn) = 0;
}

void APILchess::SortMoves(Move* list, int* n, Move* bMv, int d, int rd, int a, int b)
{
  int i,ofs=0;
  int dummy=0;
  Move z;
  
  // Put the bMv (usually the hashtable move to fron)
  for (i = 0;i < (*n);i++) 
    if (list[i].from == bMv->from && list[i].to == bMv->to && (list[i].flag & PROMOTION)== (bMv->flag & PROMOTION))
      break;
  if (i == (*n)) {
    if (bMv->from != 255) {
      printf("info string Error in SortMoves\n");
      fflush(stdout);
    }
  } else {
    ofs++;
    z = list[i];
    for (;i > 0;i--) list[i] = list[i-1];
    list[0] = z;
  }

  // Killer and History-Sorting are not implemented
}

int APILchess::IsLegalMove(Move* list, int* n, Move* Xlist, int* xn, Move* Mv)
{
  int i;
  for (i = 0;i < *n;i++)  if (Mv->from ==  list[i].from && Mv->to ==  list[i].to) return true;
  for (i = 0;i < *xn;i++) if (Mv->from == Xlist[i].from && Mv->to == Xlist[i].to) return true;
  return false;
}


int APILchess::ComputeVIndex(int d)
{
  return MAX_PVL + MAX_PVL*d - (d*(d-1))/2;
}


void APILchess::AddVar(int16 d, Move* m)
{
  int ix;
  
  if (d >= MAX_PVL-1) return;
  ix = ComputeVIndex(d);
  PVtbl[ix] = *m;
  PVtbl[ix+1].from = 255;
}

void APILchess::VarImproved(int16 d)
{
  int i,ix,iy;

  if (d >= MAX_PVL-1) return;
  ix = ComputeVIndex(d);
  if (d > 0) iy = ComputeVIndex(d-1)+1;
  else iy = 0;
  
  for (i = 0;PVtbl[ix+i].from != 255;i++)
    PVtbl[iy+i] = PVtbl[ix+i];
  PVtbl[iy+i].from = 255;
}


void APILchess::ClearPVLine()
{
   PVtbl[0].from = 255;
}

int APILchess::PVLineIsEmpty()
{
   if (PVtbl[0].from == 255) return true;
   else return false;
}

int APILchess::CntPVLine()
{  
  int i;
  for (i = 0;PVtbl[i].from != 255;i++)
    ;
  if (i > 100) {
   printf("info string fatal error in CntPVLine\n");
   fflush(stdout);
   return 0;
  }
  return i;
}

char *APILchess::PVline2Str(void)
{
  char pf;
  int i;
  
  strcpy(pvstr,"");
  for (i = 0;PVtbl[i].from != 255;i++) {
    pf = 0;
    if((PVtbl[i].flag & PROMOTION) == PROM_Q) pf = 'Q';
    if((PVtbl[i].flag & PROMOTION) == PROM_R) pf = 'R';
    if((PVtbl[i].flag & PROMOTION) == PROM_N) pf = 'N';
    if((PVtbl[i].flag & PROMOTION) == PROM_B) pf = 'B';
    if (pf == 0) sprintf(mvstr,"%c%c%c%c ",(PVtbl[i].from % 16) + 'a',7 - (PVtbl[i].from / 16) + '1',
			 (PVtbl[i].to % 16)+'a',7 - (PVtbl[i].to / 16)+'1');
    else sprintf(mvstr,"%c%c%c%c%c ",(PVtbl[i].from % 16) + 'a',7 - (PVtbl[i].from / 16) + '1',
		 (PVtbl[i].to % 16)+'a',7 - (PVtbl[i].to / 16)+'1',pf);
    strcat(pvstr,mvstr);
  }
  return pvstr;
}


void APILchess::ClearKillers(void) {
  for (int i = 0;i < MAX_KILLER_DEPTH;i++) 
    Killer0[i].from = Killer0[i].to = Killer0[i].flag =
    Killer1[i].from = Killer1[i].to = Killer1[i].flag =
    Killer2[i].from = Killer2[i].to = Killer2[i].flag =
    Killer3[i].from = Killer3[i].to = Killer3[i].flag = 0;
}


void APILchess::InsertKiller(int depth,Move *bestmv) {
  if (depth >= MAX_KILLER_DEPTH-2) return;
  if(Board[bestmv->to] != 0) return; // Do not enter takeing moves
  if(bestmv->from == 255 || bestmv->from == bestmv->to) return; // Do not enter invalid moves
  
  if(bestmv->from!=Killer0[depth].from || bestmv->to!=Killer0[depth].to) { 
    // else: if the current killer is the youngest killer
    // nothing needs to be done.
    if(bestmv->from==Killer1[depth].from && bestmv->to==Killer1[depth].to) { 
      // If the current killer is the second-killer
      Killer1[depth] = Killer0[depth]; // in the FIFO, simply switch places
      Killer0[depth] = *bestmv;
    }
    else { // Normal FIFO operation. Remove oldest killer, put in new killer.
      // Newest killer can be Killer2 or Killer3. One could handle this like
      // above. No performance difference could be measured, so the simpler solution was chosen.
      Killer3[depth] = Killer2[depth];
      Killer2[depth] = Killer1[depth];
      Killer1[depth] = Killer0[depth];
      Killer0[depth] = *bestmv;
    }
  }
}

void APILchess::ClearHistory(void) {
  for (int i = 0;i < 255;i++) 
    for (int j = 0;j < 255;j++)
      History[i][j] = 0;
}


void APILchess::InsertHistory(int64 amount,Move *bestmv) {
  History[bestmv->from][bestmv->to] += amount;
}

int APILchess::NodeType(int type, int nf)
{
  switch(type) {
    case 1:if (nf == 0) return 1;
           else return 2;
    case 2:if (nf == 0) return 3;
           else return 4;
    case 3:return 2;
    case 4:return 4;
    case 5:return 5;
  }
  return 5;
}

void APILchess::NodeCounting(int8 ntype, int64 *counter)
{
  (*counter)++;
  nodes++;
  switch(ntype) {
    case 1:t1_n++;return;
    case 2:t2_n++;return;
    case 3:t3_n++;return;
    case 4:t4_n++;return;
    case 5:t5_n++;return;
  }
  printf("info string Wrong NodeType!\n");
  fflush(stdout);
}

void APILchess::InitBasics()
{
  Board = BoardData+33;

  PieceIndex = StaticPieceIndex;
  PieceIndex[wP] = 1;PieceIndex[wN] = 2;PieceIndex[wB] = 3;
  PieceIndex[wR] = 4;PieceIndex[wQ] = 5;PieceIndex[wK] = 6;
  PieceIndex[bP] = 7;PieceIndex[bN] = 8;PieceIndex[bB] = 9;
  PieceIndex[bR] =10;PieceIndex[bQ] =11;PieceIndex[bK] =12;
  PieceIndex[0] = 0;
}


APILchess::APILchess()
{
  InitBasics();
  search_history_length = game_history_length = 0;
}

