#ifndef WORKER
#define WORKER
#include "commprint.h"
#include "communicator.h"
#ifdef LINUX
#include <iostream.h>
#endif
#ifdef WIN32
#include <iostream>
#endif
/**
*/

class Worker : public CommPrint 
{
 private: int testsUnterwegs;
          int online;
 
 public:  Worker();
         ~Worker();
	 
	  int status;
	  void Run(Communicator*);
	  void MessageAuswerten(Communicator*, class Communicator::Message*);
	  virtual void UserMessage(Communicator*, class Communicator::Message*){}
	  virtual void DoStep(Communicator*){}
	  virtual void PingEcho(class Communicator::Message* mess){}
};

#define TESTANTWORT 4096
#define TEST 8192
#define ENDE 12288
#define ALIVECHECK 16384

#endif
