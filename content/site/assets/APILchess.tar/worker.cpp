#include "worker.h"

Worker::Worker(){}


Worker::~Worker(){}

void Worker::Run(Communicator* C)
{ 
  int n;
  class Communicator::Message *message;
  class Communicator::Message Nachricht;
  online=true;

  Nachricht.mh.srce=C->GetID();
  Nachricht.data=NULL;
  Nachricht.mh.size=0;
  
  n = C->GetN();
  
  mefprint(C->GetID(), "Start Worker!!!\n");    
  
  while (online) {
    C->HiddenRecv();
    
    while (C->GetNextMessage(&(C->Qu_list), &message)!=0)
      MessageAuswerten(C, message);

    DoStep(C);
  }
}


void Worker::MessageAuswerten(Communicator* C, class Communicator::Message* mess)
{
 int id = C->GetID();
 int n = C->GetN();
 class Communicator::Message Nachricht;
 
 Nachricht.mh.srce=C->GetID();
 Nachricht.data=NULL;
 Nachricht.mh.size=0;
  
 if (mess->mh.cmd == ENDE) online = false;
 else if(n==2 && mess->mh.cmd == TEST){
    Nachricht.mh.dest=0;
    Nachricht.mh.cmd=TESTANTWORT;
    C->Send(&Nachricht);
 } else if (mess->mh.cmd == TEST) {
   if(mess->mh.srce==0){ 
     testsUnterwegs=(n-2)*1000; 
     Nachricht.mh.cmd=TEST;
     for(int i=1; i<n; i++){
       if (i != id)
	 for(int j=0; j<1000; j++){
	   Nachricht.mh.dest=i;
	   C->Send(&Nachricht);
	 }
     }
   } else{
     Nachricht.mh.dest=mess->mh.srce;
     Nachricht.mh.cmd=TESTANTWORT;
     C->Send(&Nachricht);
   } 
 } else if(mess->mh.cmd==TESTANTWORT){
   testsUnterwegs--;
   if(!testsUnterwegs) {
     Nachricht.mh.cmd=TESTANTWORT;
     Nachricht.mh.dest=0;
     C->Send(&Nachricht);
   }
 } else if(mess->mh.cmd==ALIVECHECK){
     mess->mh.dest=(id+1)%n;
     PingEcho(mess);
     C->Send(mess);
 } else
   UserMessage(C, mess);
   
 C->FreeMess(mess); 
}

