#ifndef HASH
#define HASH

#include "basic_types.h"
#include "move.h"

#define NO_ENTRY  0
#define EXACT     1
#define FAILH     2
#define FAILL     3
#define FLAGS     7
#define OLD_ENTRY 8

#define XFLAGS    0xff

class TableEntry 
{
  public:
    unsigned int64 Key;
    unsigned int64 XKey;
    Move Mv;
    int16 Val;
    int8  rDepth;
    int8  Flgs;
    int8  XrDepth;
    Move XMv;
    int8 XFlgs;
};


class Hashtable 
{
  public:
    void *C;
    TableEntry *table;
    int Ts;
    Hashtable(int size, void *cC) {
      //delete table;
      table = new TableEntry[size];
      for (int i=0;i<size;i++) {
	table[i].Key = 0;
	table[i].rDepth = 0;
	table[i].Flgs = 0;
      }
      Ts = size;
      C = cC;
    }
    ~Hashtable() { }
    unsigned int32 SendQuery(int64 hashvalue,int8 castle_state, int8 en_passent, int8 WTM, int distributed, int nodeID, int16* hv, int16* hrd, int8 *hf, Move* hMv, int8 *xhf, Move* XMv, int16*, int16);
    void PushHash(Move *,int8, int16, int16, int, int64,int8, int8, int8);
    void PushExt(int16, int, int64,int8, int8, int8, Move*, int8);
    void ClearHash(int);
};

#endif
