/* >>> tboper.c: advanced file operations for the tablebase generator */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

#include <stdio.h>
#include <stdlib.h>

#include "tbdefs.h"
#include "tbvars.h"

#include "tbfile.h"
#include "tbmake.h"
#include "tboper.h"
#include "tbsort.h"
#include "tbutil.h"

/**** Locals */

/* current unsorted merge information index entry count and limit */

static indexT cumi_count;
static indexT cumi_limit;

/* current sorted merge information index count */

static indexT csmi_count;

/* temporary file name and file pointer for current unsorted merge information */

static charptrT cumi_fnptr;
static fptrT cumi_ffptr;

/* temproary file name and file pointer for current sorted merge information */

static charptrT csmi_fnptr;
static fptrT csmi_ffptr;

/*--> TBLookUp: generate a look-up file */
void TBLookUp(charptrT fn0, charptrT fn1, charptrT fn2)
{
  sr0T sr0;
  sr1T sr1;
  fptrT fptr0, fptr1, fptr2;
  indexT index;
  bevT bev;

  /* open reference file */

  fptr0 = TBCodeFileOpenRead(fn0);
  TBSetBiggerBuffer(fptr0);

  fptr1 = TBCodeFileOpenRead(fn1);
  TBSetBigBuffer(fptr1);

  fptr2 = TBCodeFileOpenWrite(fn2);
  TBSetBigBuffer(fptr2);

  /* clear reference file scanning index (current item) */

  index = -1;
  bev = bev_broken;

  /* scan directive file */

  while (fread(&sr0, 1, sizeof(sr0T), fptr1) == sizeof(sr0T))
  {
    /* check */

    if (index > sr0.sr0_index1)
      TBFatal("TBLookUp: reference sequence error");

    /* skip forward in reference file */

    while (index < sr0.sr0_index1)
    {
      if (fread(&bev, 1, sizeof(bevT), fptr0) != sizeof(bevT))
        TBFatal("TBLookUp: reference file read fault");
      index++;
    };

    /* form and output look-up record */

    sr1.sr1_index = sr0.sr0_index0;
    sr1.sr1_bev = bev;
    if (fwrite(&sr1, 1, sizeof(sr1T), fptr2) != sizeof(sr1T))
      TBFatal("TBLookUp: look-up file write fault");
  };

  /* close files */

  TBCodeFileClose(fptr0);
  TBCodeFileClose(fptr1);
  TBCodeFileClose(fptr2);
}

/*--> TBApplyMate: apply a mate value according to mating file to target file */
void TBApplyMate(
  cT c, indexT length, bevT mate_bev, charptrT mate_fn, charptrT target_fn)
{
  charptrT tfnptr1;
  fptrT tffptr1;
  fptrT target_fp, mate_fp;
  indexT index;
  sr2T sr2;
  siT eof;
  bevT input_bev, output_bev;

  /* open and prime the sorted mate file */

  mate_fp = TBCodeFileOpenRead(mate_fn);
  TBSetBigBuffer(mate_fp);
  if (fread(&sr2, 1, sizeof(sr2T), mate_fp) != sizeof(sr2T))
    eof = 1;
  else
    eof = 0;

  /* set up the temporary version of the target file */

  tfnptr1 = TBTempFileName();
  tffptr1 = TBCodeFileOpenWrite(tfnptr1);
  TBSetBiggerBuffer(tffptr1);

  /* open the original target file for input */

  target_fp = TBCodeFileOpenRead(target_fn);
  TBSetBiggerBuffer(target_fp);

  /* process the sorted mate file to create temporary version of target file */

  for (index = 0; index < length; index++)
    {
    /* read the input BEV */

    input_bev = fgetc(target_fp);

    /* set the default output BEV */

    output_bev = input_bev;

    /* check for modifications */

    while (!eof && (sr2.sr2_index == index))
      {
      if ((output_bev == bev_unknown) || (output_bev < mate_bev))
        {
        /* assign and update */

        output_bev = mate_bev;
        TBAdjustHWM(c, mate_bev);
        };

      /* reload from the sorted mate file */

      if (fread(&sr2, 1, sizeof(sr2T), mate_fp) != sizeof(sr2T))
        eof = 1;
      else
        eof = 0;
      };

    /* write the output BEV */

    fputc(output_bev, tffptr1);
    };

  /* close the temporary version of the target file */

  TBCodeFileClose(tffptr1);

  /* close and delete the original target file */

  TBCodeFileClose(target_fp);
  TBCodeFileRemove(target_fn);

  /* close and delete the sorted mate file */

  TBCodeFileClose(mate_fp);
  TBCodeFileRemove(mate_fn);

  /* rename the updated target file back to the original target file */

  TBCodeFileRename(tfnptr1, target_fn);

  /* release the temporary target file name */

  TBStringFree(tfnptr1);
}

/*--> TBIndexMergeStart: start index merge operations */
void TBIndexMergeStart(indexT class_length)
{
  /* set the current unsorted merge index entry limit and clear the count */

  cumi_limit = class_length / 8;
  cumi_count = 0;

  /* set the current sorted merge index entry count */

  csmi_count = 0;

  /* handle the current unsorted merge index file */

  cumi_fnptr = TBTempFileName();
  cumi_ffptr = TBCodeFileOpenWrite(cumi_fnptr);
  TBSetBigBuffer(cumi_ffptr);

  /* handle the initial current sorted merge index file */

  csmi_fnptr = TBTempFileName();
  csmi_ffptr = TBCodeFileOpenWrite(csmi_fnptr);
  TBCodeFileClose(csmi_ffptr);
}

/*--> TBIndexMergeFlush: flush, sort, and merge current index data */
static
void
TBIndexMergeFlush(charptrT fn)
{
  fptrT fptr;
  fptrT tffptr;
  charptrT tfnptr;
  sr2T sr2a, sr2b;
  siT eof_a, eof_b, write_a, write_b, reload_a, reload_b;

  /* sort/unique the unsorted current merge file */

  TBCodeFileClose(cumi_ffptr);
  tfnptr = TBTempFileName();
  TBSortFile(cumi_fnptr, tfnptr, sizeof(sr2T), 1, (void *) TBCompSR2);
  TBStringFree(cumi_fnptr);

  /* set up a new, empty unsorted merge file */

  cumi_fnptr = TBTempFileName();
  cumi_ffptr = TBCodeFileOpenWrite(cumi_fnptr);
  TBSetBigBuffer(cumi_ffptr);
  cumi_count = 0;

  /* open the old sorted merge index file */

  csmi_ffptr = TBCodeFileOpenRead(csmi_fnptr);
  TBSetBiggerBuffer(csmi_ffptr);

  /* open the newly sorted chunk file */

  tffptr = TBCodeFileOpenRead(tfnptr);
  TBSetBigBuffer(tffptr);

  /* set up the designated new output file */

  fptr = TBCodeFileOpenWrite(fn);
  TBSetBiggerBuffer(cumi_ffptr);

  /* prime the input files */

  if (fread(&sr2a, 1, sizeof(sr2T), csmi_ffptr) != sizeof(sr2T))
    eof_a = 1;
  else
    eof_a = 0;

  if (fread(&sr2b, 1, sizeof(sr2T), tffptr) != sizeof(sr2T))
    eof_b = 1;
  else
    eof_b = 0;

  /* perform the merge */

  csmi_count = 0;
  while (!eof_a || !eof_b)
    {
    write_a = write_b = 0;
    reload_a = reload_b = 0;

    if (eof_a || eof_b)
      if (eof_a)
        {
        write_b = 1;
        reload_b = 1;
        }
      else
        {
        write_a = 1;
        reload_a = 1;
        }
    else
      if (sr2a.sr2_index == sr2b.sr2_index)
        reload_a = 1;
      else
        if (sr2a.sr2_index < sr2b.sr2_index)
          {
          write_a = 1;
          reload_a = 1;
          }
        else
          {
          write_b = 1;
          reload_b = 1;
          };

    if (write_a)
      {
      if (fwrite(&sr2a, 1, sizeof(sr2T), fptr) != sizeof(sr2T))
        TBFatal("TBIndexMergeFlush: Can't write to output file");
      csmi_count++;
      };

    if (write_b)
      {
      if (fwrite(&sr2b, 1, sizeof(sr2T), fptr) != sizeof(sr2T))
        TBFatal("TBIndexMergeFlush: Can't write to output file");
      csmi_count++;
      };

    if (reload_a)
      {
      if (fread(&sr2a, 1, sizeof(sr2T), csmi_ffptr) != sizeof(sr2T))
        eof_a = 1;
      else
        eof_a = 0;
      };

    if (reload_b)
      {
      if (fread(&sr2b, 1, sizeof(sr2T), tffptr) != sizeof(sr2T))
        eof_b = 1;
      else
        eof_b = 0;
      };
    };

  /* close down files */

  TBCodeFileClose(fptr);
  TBCodeFileClose(tffptr);
  TBCodeFileClose(csmi_ffptr);

  /* remove old files */

  TBCodeFileRemove(tfnptr);
  TBCodeFileRemove(csmi_fnptr);

  /* clean up names */

  TBStringFree(tfnptr);
  TBStringFree(csmi_fnptr);

  /* set the name of the current sorted merge file */

  csmi_fnptr = TBStringGrab(fn);
}

/*--> TBIndexMergeInsert: insert an index into the current index data */
void TBIndexMergeInsert(indexT index)
{
  charptrT tfnptr;
  sr2T sr2;

  /* check for overflow */

  if (cumi_count == cumi_limit)
    {
    tfnptr = TBTempFileName();
    TBIndexMergeFlush(tfnptr);
    TBStringFree(tfnptr);
    };

  /* output the index to the current unsorted index file */

  sr2.sr2_index = index;
  if (fwrite(&sr2, 1, sizeof(sr2T), cumi_ffptr) != sizeof(sr2T))
    TBFatal("TBIndexMergeInsert: Can't write index record");

  /* increment current unsorted merge index count */

  cumi_count++;
}

/*--> TBIndexMergeFinish: finish index merge processing and write result */
indexT TBIndexMergeFinish(charptrT fn)
{
  /* merge/flush to designated file */

  TBIndexMergeFlush(fn);

  /* close and delete the unsorted temporary file */

  TBCodeFileClose(cumi_ffptr);
  TBCodeFileRemove(cumi_fnptr);

  /* deallcate temporary file names */

  TBStringFree(cumi_fnptr);
  TBStringFree(csmi_fnptr);

  return csmi_count;
}
