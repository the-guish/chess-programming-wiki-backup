/* >>> main.c: main program for tablebase generator */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#include "tbdefs.h"
#include "tbvars.h"

#include "tbcntl.h"
#include "tbfile.h"
#include "tbmake.h"
#include "tbmisc.h"
#include "tbsort.h"
#include "tbutil.h"

/*--> main: main driver for the tablebase generator */
int main(int argc, char *argv[])
{
  char tv[tL];
  liT i, length;
  liT t0, t1;

  /* sign on */

  printf("tbgen: tablebase generator revision 2004.09.03\n");
  printf("Written by S. J. Edwards (chessnotation@mac.com)\n");
  printf("*** Developer version; not for general audiences ***\n");

  /* handle command line arguments */

  if (argc == 0)
  {
    /* Macintosh mode */

    printf("Enter class name: ");
    scanf("%s", tv);
    class_str = TBStringGrab(tv);

    printf("Enter WTM target directory name: ");
    scanf("%s", tv);
    targetdir_strv[c_w] = TBStringGrab(tv);

    printf("Enter BTM target directory name: ");
    scanf("%s", tv);
    targetdir_strv[c_b] = TBStringGrab(tv);

    printf("Enter temporary directory name: ");
    scanf("%s", tv);
    tmpdir_str = TBStringGrab(tv);

    printf("Enter reference directory name: ");
    scanf("%s", tv);
    refdir_str = TBStringGrab(tv);
  }
  else
  {
    if (argc != 6)
    {
      fprintf(stderr, "usage: %s class WTMdir BTMdir tmpdir refdir\n",
        argv[0]);
      fprintf(stderr, "      class: class to be generated (e.g., KBNK)\n");
      fprintf(stderr, "      WTMdir: directory to receive the WTM file\n");
      fprintf(stderr, "      BTMdir: directory to receive the BTM file\n");
      fprintf(stderr, "      tmpdir: directory for temporary files\n");
      fprintf(stderr, "      refdir: directory for reference files\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "Note: on some systems, the WTM and BTM target dirs\n");
      fprintf(stderr, "have to be on the same filesystem as the directory\n");
      fprintf(stderr, "chosen to hold the temporary files.\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "Note: the program needs reference tablebases for\n");
      fprintf(stderr, "every class except the KK class (start there).\n");
      fprintf(stderr, "The program issmart enough to tell the user which\n");
      fprintf(stderr, "reference tablebases areare needed if they aren't\n");
      fprintf(stderr, "all present.\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "Example: tbgen KK . . . .\n");
      fprintf(stderr, "Example: tbgen KRBKR TB TB /tmp TB\n");
      exit(1);
    }
    else
    {
      class_str = TBStringGrab(argv[1]);
      targetdir_strv[c_w] = TBStringGrab(argv[2]);
      targetdir_strv[c_b] = TBStringGrab(argv[3]);
      tmpdir_str = TBStringGrab(argv[4]);
      refdir_str = TBStringGrab(argv[5]);
    };
  };

  /* set up */

  TBInit();

  /* process class name parameter */

  length = strlen(class_str);
  for (i = 0; i < length; i++)
    if (islower(*(class_str + i)))
      *(class_str + i) = toupper(*(class_str + i));

  class_tbid = TBClassFromString(class_str);
  if (class_tbid == tbid_nil)
    TBFatal("Can't identify class name");

  /* test code */

  #if (false)
  {
    TBPrintGenerationList("genlist");
    return 0;
  }
  #endif

  /* test code */

  #if (false)
  {
    TBPrintDependencyFile("depend");
    TBPrintRecursiveDependencyFile("rdepend");
    return 0;
  }
  #endif

  /* make */

  t0 = time(NULL);
  TBMake();
  t1 = time(NULL);

  /* report */

  printf("Temporary file count: %ld\n", tf_ordinal);

  /* shut down */

  TBTerm();

  printf("Construction time: %ld seconds\n", (t1 - t0));
  printf("Program concluded.\n");

  /* "Wanna see my sprocket collection?" */

  return 0;
}
