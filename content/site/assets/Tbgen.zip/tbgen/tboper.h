/* >>> tboper.h: function prototypes for tablebase generator file tboper.c */
/* Revised: 2004.09.03 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

void TBLookUp(charptrT fn0, charptrT fn1, charptrT fn2);
void TBApplyMate(
  cT c, indexT length, bevT mate_bev, charptrT mate_fn, charptrT target_fn);
void TBIndexMergeStart(indexT class_length);
void TBIndexMergeInsert(indexT index);

indexT TBIndexMergeFinish(charptrT fn);
