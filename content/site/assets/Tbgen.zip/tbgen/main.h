 /* >>> main.h: function prototypes for tablebase generator file main.c */  /* Revised: 1996.05.09 */ 	/* Copyright (C) 1996 by
														 * S. J. Edwards
														 * (sje@mv.mv.com)  All
    rights reserved */ int main(int argc, char *argv[]);
				/* <<< main.h: EOF */
