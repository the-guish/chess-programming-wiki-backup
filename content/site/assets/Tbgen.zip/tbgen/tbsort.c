/* >>> tbsort.c: file sorting routines for the tablebase generator */
/* Revised: 2004.09.03 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tbdefs.h"
#include "tbvars.h"

#include "tbfile.h"
#include "tbsort.h"
#include "tbutil.h"

#define recbufL sizeof(sr0T) /* the biggest sort record structure type */

#define flowL 2

#define splitL (1 << 6)

#define blockL (1 << 12)

static charptrT sort_fn0, sort_fn1;
static fptrT sort_fp0, sort_fp1;

static charptrT tfnv[flowL][splitL];
static fptrT tfpv[flowL][splitL];

static siT sort_done;
static siT sort_pass;
static liT runlen0, runlen1;

static liT rec_count;
static liT rec_length;

static indexT output_count;

/*--> TBCompSR0: compare records, format 0 */
int TBCompSR0(sr0ptrT sr0ptr0, sr0ptrT sr0ptr1)
{
  siT result;

  if (sr0ptr0->sr0_index1 == sr0ptr1->sr0_index1)
    if (sr0ptr0->sr0_index0 == sr0ptr1->sr0_index0)
      result = 0;
    else
      if (sr0ptr0->sr0_index0 < sr0ptr1->sr0_index0)
        result = -1;
      else
        result = 1;
  else
    if (sr0ptr0->sr0_index1 < sr0ptr1->sr0_index1)
      result = -1;
    else
      result = 1;

  return result;
}

/*--> TBCompSR1: compare records, format 1 */
int TBCompSR1(sr1ptrT sr1ptr0, sr1ptrT sr1ptr1)
{
  siT result;

  if (sr1ptr0->sr1_index == sr1ptr1->sr1_index)
    if (sr1ptr0->sr1_bev == sr1ptr1->sr1_bev)
      result = 0;
    else
      if (sr1ptr0->sr1_bev < sr1ptr1->sr1_bev)
        result = -1;
      else
        result = 1;
  else
    if (sr1ptr0->sr1_index < sr1ptr1->sr1_index)
      result = -1;
    else
      result = 1;

  return result;
}

/*--> TBCompSR2: compare records, format 2 */
int TBCompSR2(sr2ptrT sr2ptr0, sr2ptrT sr2ptr1)
{
  siT result;

  if (sr2ptr0->sr2_index == sr2ptr1->sr2_index)
    result = 0;
  else
    if (sr2ptr0->sr2_index < sr2ptr1->sr2_index)
      result = -1;
    else
      result = 1;

  return result;
}

/*--> TBCompSR3: compare records, format 3 */
int TBCompSR3(sr3ptrT sr3ptr0, sr3ptrT sr3ptr1)
{
  siT result;

  if (sr3ptr0->sr3_index1 == sr3ptr1->sr3_index1)
    if (sr3ptr0->sr3_index0 == sr3ptr1->sr3_index0)
      result = 0;
    else
      if (sr3ptr0->sr3_index0 < sr3ptr1->sr3_index0)
        result = -1;
      else
        result = 1;
  else
    if (sr3ptr0->sr3_index1 < sr3ptr1->sr3_index1)
      result = -1;
    else
      result = 1;

  return result;
}

/*--> TBSortSplit: perform initial load and split */
static
void
TBSortSplit(cfiptrT cfiptr)
{
  siT i, j;
  siT count;
  liT blocks;
  char bvv[blockL][recbufL];

  /* clear record count */

  rec_count = 0;

  /* open original input file */

  sort_fp0 = TBCodeFileOpenRead(sort_fn0);
  TBSetBiggerBuffer(sort_fp0);

  /* open output files */

  for (j = 0; j < splitL; j++)
    {
    tfpv[0][j] = TBCodeFileOpenWrite(tfnv[0][j]);
    TBSetBigBuffer(tfpv[0][j]);
    };

  /* load records */

  blocks = 0;
  while (!feof(sort_fp0))
    {
    /* read a block */

    count = 0;
    while (!feof(sort_fp0) && !ferror(sort_fp0) && (count < blockL))
      if (fread(bvv[count], 1, rec_length, sort_fp0) == rec_length)
        count++;

    /* sort the block */

    if (count > 1)
      qsort(bvv, count, recbufL, (voidptrT) *cfiptr);

    /* write the block */

    for (i = 0; i < count; i++)
      if (fwrite(bvv[i], 1, rec_length, tfpv[0][blocks % splitL]) != rec_length)
        TBFatal("TBSortSplit: can't write to temporary file");

    /* next block */

    if (count > 0)
      {
      blocks++;
      rec_count += count;
      };
    };

  /* close and DELETE original input file */

  TBCodeFileClose(sort_fp0);
  TBCodeFileRemove(sort_fn0);

  /* close output files */

  for (j = 0; j < splitL; j++)
    TBCodeFileClose(tfpv[0][j]);
}

/*--> TBTestFlagVector: test if any elements are active in flag vector */
static siT TBTestFlagVector(siT bfv[splitL])
{
  siT flag;
  siT i;

  flag = 0;
  i = 0;
  while (!flag && (i < splitL))
    if (bfv[i])
      flag = 1;
    else
      i++;

  return flag;
}

/*--> TBSortScan: perform a single scan */
static
void
TBSortScan(siT unique, cfiptrT cfiptr)
{
siT i, j;
siT pick;
siT ri, wi;
siT eofv[splitL];
siT bfv[splitL];
liT rcv[splitL];
char bv[splitL][recbufL];
liT index;

/* set indices according to pass count */

ri = sort_pass % flowL;
wi = (sort_pass + 1) % flowL;

/* open input files */

for (i = 0; i < splitL; i++)
	{
	tfpv[ri][i] = TBCodeFileOpenRead(tfnv[ri][i]);
	TBSetBigBuffer(tfpv[ri][i]);
	};

/* open output files */

for (j = 0; j < splitL; j++)
	{
	tfpv[wi][j] = TBCodeFileOpenWrite(tfnv[wi][j]);
	TBSetBigBuffer(tfpv[wi][j]);
	};

/* clear eof markers  */

for (i = 0; i < splitL; i++)
	eofv[i] = 0;

/* generate output data */

j = 0;
index = 0;
while (index < rec_count)
	{
	/* clear buffer flags and run counts */

	for (i = 0; i < splitL; i++)
		{
		bfv[i] = 0;
		rcv[i] = 0;
		};

	/* preload buffers */

	for (i = 0; i < splitL; i++)
		if (!eofv[i])
			if (fread(bv[i], 1, rec_length, tfpv[ri][i]) != rec_length)
				{
				eofv[i] = 1;
				}
			else
				{
				index++;
				bfv[i] = 1;
				rcv[i]++;
				};

	while (TBTestFlagVector(bfv))
		{
		/* determine the least valued buffer */

		pick = -1;
		for (i = 0; i < splitL; i++)
			if (bfv[i])
				if (pick == -1)
					pick = i;
				else
					if ((*cfiptr)(bv[i], bv[pick]) <= 0)
						pick = i;

		/* dump the least valued buffer */

		if (pick != -1)
			{
			if (fwrite(bv[pick], 1, rec_length, tfpv[wi][j]) != rec_length)
				TBFatal("TBSortScan: can't write to temporary file");
			bfv[pick] = 0;
			};

		/* reload */

		if (pick != -1)
			if (rcv[pick] < runlen0)
				if (fread(bv[pick], 1, rec_length, tfpv[ri][pick]) != rec_length)
					{
					eofv[pick] = 1;
					}
				else
					{
					index++;
					bfv[pick] = 1;
					rcv[pick]++;
					};
		};

	j = (j + 1) % splitL;
	};

/* close and delete input files */

for (i = 0; i < splitL; i++)
	{
	TBCodeFileClose(tfpv[ri][i]);
	TBCodeFileRemove(tfnv[ri][i]);
	};

/* close output files */

for (j = 0; j < splitL; j++)
	TBCodeFileClose(tfpv[wi][j]);

/* test for completion */

if (runlen1 >= rec_count)
	sort_done = 1;

/* form output file contents if done */

if (sort_done)
	{
	/* clear the output record count */

	output_count = 0;

	/* process according to unique status */

	if (unique)
		{
		/* open original output file */

		sort_fp1 = TBCodeFileOpenWrite(sort_fn1);
		TBSetBiggerBuffer(sort_fp1);

		/* open temporary output file zero */

		tfpv[wi][0] = TBCodeFileOpenRead(tfnv[wi][0]);
		TBSetBiggerBuffer(tfpv[wi][0]);

		/* copy to original output file */

		while (fread(bv[0], 1, rec_length, tfpv[wi][0]) == rec_length)
			{
			if (!unique || (output_count == 0) || ((*cfiptr)(bv[0], bv[1]) != 0))
				{
				if (fwrite(bv[0], 1, rec_length, sort_fp1) != rec_length)
					TBFatal("TBSortScan: can't write to sort output file");
				if (unique)
					for (i = 0; i < rec_length; i++)
						bv[1][i] = bv[0][i];
				output_count++;
				};
			};

		/* close files */

		TBCodeFileClose(sort_fp1);
		TBCodeFileClose(tfpv[wi][0]);

		/* remove copied file */

		TBCodeFileRemove(tfnv[wi][0]);
		}
	else
		TBCodeFileRename(tfnv[wi][0], sort_fn1);

	/* delete temporary output files (first one already deleted) */

	for (j = 1; j < splitL; j++)
		TBCodeFileRemove(tfnv[wi][j]);
	};
}

/*--> TBSortFile: sort input file and write to output file */
indexT TBSortFile(
  charptrT fn0, charptrT fn1, liT entrysize, siT unique, cfiptrT cfiptr)
{
  siT i, j;

  /* set up */

  sort_fn0 = fn0;
  sort_fn1 = fn1;
  sort_fp0 = sort_fp1 = NULL;
  sort_pass = 0;
  sort_done = 0;
  runlen0 = blockL;
  runlen1 = splitL * blockL;

  rec_length = entrysize;

  for (j = 0; j < flowL; j++)
    for (i = 0; i < splitL; i++)
      tfnv[j][i] = NULL;

  /* set up temporary file names */

  for (j = 0; j < flowL; j++)
    for (i = 0; i < splitL; i++)
      tfnv[j][i] = TBTempFileName();

  /* perform initial split */

  TBSortSplit(cfiptr);

  /* loop until complete */

  while (!sort_done)
  {
    TBSortScan(unique, cfiptr);
    if (!sort_done)
    {
      sort_pass++;
      runlen0 = runlen1;
      runlen1 = runlen0 * splitL;
    };
  };

  return output_count;
}
