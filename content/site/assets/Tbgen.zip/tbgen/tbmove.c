/* >>> tbmove.c: generate, retrogen, execute, and retract for tablebase */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

#include <stdio.h>
#include <stdlib.h>

#include "tbdefs.h"
#include "tbvars.h"

#include "tbmove.h"
#include "tbspin.h"
#include "tbutil.h"

/* the current working class and current working class pointer */

static tbidT cw_tbid;
static tbptrT cw_classptr;

/* the current working class man count vector */

static siT cw_mcv[rcL];

/* the current working class color-piece vector */

static cpT cw_cpv[rcL][tbmecL];

/* the current working class fold/pivot information */

static foldT cw_fold;
static cT cw_pivot_c;
static siT cw_pivot_slot;

/* the current position vector */

static posvT q_posv;

/* the current active and passive colors */

static cT q_actc;
static cT q_pasc;

/* the current active and passive man counts */

static siT q_actc_mc;
static siT q_pasc_mc;

/* the internal board */

static rbT q_rb;

/* the slot index board vector */

static siT q_siv[sqL];

/* the normal ep target, captured color-piece, capture square, and slot index */

static sqT norm_epsq;
static cpT norm_capt_cp;
static sqT norm_capt_sq;
static siT norm_capt_si;

/* the saved ep target, captured color-piece, capture square, and slot index */

static sqT save_epsq;
static cpT save_capt_cp;
static sqT save_capt_sq;
static siT save_capt_si;

/*--> TBSetCurrentClass: set the current working class for move operations */
void TBSetCurrentClass(tbidT current_class)
{
  cT c;
  siT i;

  cw_tbid = current_class;
  cw_classptr = tbbaseptr + current_class;

  for (c = c_w; c <= c_b; c++)
  {
    cw_mcv[c] = cw_classptr->tb_mcv[c];
    for (i = 0; i < cw_mcv[c]; i++)
      cw_cpv[c][i] = cw_classptr->tb_cpv[c][i];
  };

  cw_fold = cw_classptr->tb_fold;
  cw_pivot_c = cw_classptr->tb_pivot_c;
  cw_pivot_slot = cw_classptr->tb_pivot_slot;
}

/*--> TBSetCurrentActive: set current active/passive colors for move ops */
void TBSetCurrentActive(cT actc)
{
  q_actc = actc;
  q_pasc = inv_cv[actc];

  q_actc_mc = cw_mcv[q_actc];
  q_pasc_mc = cw_mcv[q_pasc];
}

/*--> TBClearBoard: clear the internal board and related items */
void TBClearBoard(void)
{
  sqT sq;

  for (sq = sq_a1; sq <= sq_h8; sq++)
  {
    q_rb.rbv[sq] = cp_v0;
    q_siv[sq] = -1;
  };

  save_epsq = norm_epsq = sq_nil;
  save_capt_cp = norm_capt_cp = cp_nil;
  save_capt_sq = norm_capt_sq = sq_nil;
  save_capt_si = norm_capt_si = -1;
}

/*--> TBSetBoard: set up the internal board and related items */
void TBSetBoard(sqT epsq, posvT posv)
{
  siT i;
  cpT cp;
  sqT sq;

  /* clear out the board items */

  TBClearBoard();

  /* set active pieces first */

  for (i = 0; i < q_actc_mc; i++)
  {
    sq = q_posv[q_actc][i] = posv[q_actc][i];
    q_rb.rbv[sq] = cw_cpv[q_actc][i];
    q_siv[sq] = i;
  };

  /* set passive pieces second */

  for (i = 0; i < q_pasc_mc; i++)
  {
    sq = q_posv[q_pasc][i] = posv[q_pasc][i];
    if ((cp = q_rb.rbv[sq]) != cp_v0)
    {
      /* capture the active color piece */

      save_capt_cp = norm_capt_cp = cp;
      save_capt_sq = norm_capt_sq = sq;
      save_capt_si = norm_capt_si = q_siv[sq];
    };
    q_rb.rbv[sq] = cw_cpv[q_pasc][i];
    q_siv[sq] = i;
  };

  /* set the en passant capture square */

  save_epsq = norm_epsq = epsq;
}

/*--> TBAttacks: determine if a color attacks a square */
siT TBAttacks(cT c, sqT sq)
{
  siT flag, stop;
  dxT dx;
  dvT dv;
  xdvT xdv;
  sqT rsq;
  xbsqT xbsq, xbrsq;
  cpT rcp;
  pT rp;

  flag = 0;
  xbsq = trn_xbsq(sq);

  /* ortho directions */

  if (!flag)
  {
    dx = dx_0;
    while (!flag && (dx <= dx_3))
    {
      dv = dvv[dx];
      xdv = xdvv[dx];
      xbrsq = xbsq + xdv;
      if (xb.xbv[xbrsq] == cp_v0)
      {
        rsq = sq + dv;
        if ((rcp = q_rb.rbv[rsq]) != cp_v0)
        {
          if (cnv_cv[rcp] == c)
          {
            rp = cnv_pv[rcp];
            if ((rp == p_r) || (rp == p_q) || (rp == p_k))
              flag = 1;
          };
        }
        else
        {
          stop = 0;
          while (!stop)
          {
            xbrsq += xdv;
            if (xb.xbv[xbrsq] != cp_v0)
              stop = 1;
            else
            {
              rsq += dv;
              rcp = q_rb.rbv[rsq];
              if (rcp != cp_v0)
              {
                stop = 1;
                if (cnv_cv[rcp] == c)
                {
                  rp = cnv_pv[rcp];
                  if ((rp == p_r) || (rp == p_q))
                    flag = 1;
                };
              };
            };
          };
        };
      };

      dx++;
    };
  };

  /* diag directions */

  if (!flag)
  {
    dx = dx_4;
    while (!flag && (dx <= dx_7))
    {
      dv = dvv[dx];
      xdv = xdvv[dx];
      xbrsq = xbsq + xdv;
      if (xb.xbv[xbrsq] == cp_v0)
      {
        rsq = sq + dv;
        if ((rcp = q_rb.rbv[rsq]) != cp_v0)
        {
          if (cnv_cv[rcp] == c)
          {
            rp = cnv_pv[rcp];
            if ((rp == p_b) || (rp == p_q) || (rp == p_k))
              flag = 1;
            else
              if (rp == p_p)
                if (c == c_w)
                {
                  if ((dx == dx_6) || (dx == dx_7))
                    flag = 1;
                }
                else
                {
                  if ((dx == dx_4) || (dx == dx_5))
                    flag = 1;
                };
          };
        }
        else
        {
          stop = 0;
          while (!stop)
          {
            xbrsq += xdv;
            if (xb.xbv[xbrsq] != cp_v0)
              stop = 1;
            else
            {
              rsq += dv;
              rcp = q_rb.rbv[rsq];
              if (rcp != cp_v0)
              {
                stop = 1;
                if (cnv_cv[rcp] == c)
                {
                  rp = cnv_pv[rcp];
                  if ((rp == p_b) || (rp == p_q))
                    flag = 1;
                };
              };
            };
          };
        };
      };

      dx++;
    };
  };

  /* knight moves */

  if (!flag)
  {
    dx = dx_8;
    while (!flag && (dx <= dx_f))
    {
      if (xb.xbv[xbsq + xdvv[dx]] == cp_v0)
      {
        rcp = q_rb.rbv[sq + dvv[dx]];
        if ((cnv_cv[rcp] == c) && (cnv_pv[rcp] == p_n))
          flag = 1;
      };
      dx++;
    };
  };

  return flag;
}

/*--> TBKingInCheck: determine if the indicated king is in check */
siT TBKingInCheck(cT c)
{
  siT flag;

  if (c == c_w)
    flag = TBAttacks(c_b, q_posv[c_w][0]);
  else
    flag = TBAttacks(c_w, q_posv[c_b][0]);

  return flag;
}

/*--> TBGenerate: generate prograde moves for the current position */
void TBGenerate(void)
{
  tbmptrT tbmptr;
  siT count;
  siT pi;
  sqT frsq, tosq;
  cpT frcp, tocp;
  dxT dx;
  dvT dv;
  xbsqT xbfrsq, xbtosq;
  xdvT xdv;

  /* prograde moves are generated for the active color */

  tbmptr = tbgmbaseptrv[q_actc];
  count = 0;

  /* scan though active piece vector */

  for (pi = 0; pi < q_actc_mc; pi++)
    {
    frsq = q_posv[q_actc][pi];
    frcp = q_rb.rbv[frsq];
    xbfrsq = trn_xbsq(frsq);
    switch (frcp)
      {
      case cp_wp:
        tosq = frsq + dv_1;
        tocp = q_rb.rbv[tosq];
        if (tocp == cp_v0)
          {
          tbmptr->tbm_frsq = frsq;
          tbmptr->tbm_tosq = tosq;
          tbmptr->tbm_frcp = frcp;
          tbmptr->tbm_tocp = tocp;
          tbmptr++;
          count++;
          if (map_rank(frsq) == rank_2)
            {
            tosq = frsq + (2 * dv_1);
            tocp = q_rb.rbv[tosq];
            if (tocp == cp_v0)
              {
              tbmptr->tbm_frsq = frsq;
              tbmptr->tbm_tosq = tosq;
              tbmptr->tbm_frcp = frcp;
              tbmptr->tbm_tocp = tocp;
              tbmptr++;
              count++;
              };
            };
          };

        if (map_file(frsq) > file_a)
          {
          tosq = frsq + dv_5;
          tocp = q_rb.rbv[tosq];
          if (cnv_cv[tocp] == c_b)
            {
            tbmptr->tbm_frsq = frsq;
            tbmptr->tbm_tosq = tosq;
            tbmptr->tbm_frcp = frcp;
            tbmptr->tbm_tocp = tocp;
            tbmptr++;
            count++;
            };
          };

        if (map_file(frsq) < file_h)
          {
          tosq = frsq + dv_4;
          tocp = q_rb.rbv[tosq];
          if (cnv_cv[tocp] == c_b)
            {
            tbmptr->tbm_frsq = frsq;
            tbmptr->tbm_tosq = tosq;
            tbmptr->tbm_frcp = frcp;
            tbmptr->tbm_tocp = tocp;
            tbmptr++;
            count++;
            };
          };
        break;

      case cp_bp:
        tosq = frsq + dv_3;
        tocp = q_rb.rbv[tosq];
        if (tocp == cp_v0)
          {
          tbmptr->tbm_frsq = frsq;
          tbmptr->tbm_tosq = tosq;
          tbmptr->tbm_frcp = frcp;
          tbmptr->tbm_tocp = tocp;
          tbmptr++;
          count++;
          if (map_rank(frsq) == rank_7)
            {
            tosq = frsq + (2 * dv_3);
            tocp = q_rb.rbv[tosq];
            if (tocp == cp_v0)
              {
              tbmptr->tbm_frsq = frsq;
              tbmptr->tbm_tosq = tosq;
              tbmptr->tbm_frcp = frcp;
              tbmptr->tbm_tocp = tocp;
              tbmptr++;
              count++;
              };
            };
          };

        if (map_file(frsq) > file_a)
          {
          tosq = frsq + dv_6;
          tocp = q_rb.rbv[tosq];
          if (cnv_cv[tocp] == c_w)
            {
            tbmptr->tbm_frsq = frsq;
            tbmptr->tbm_tosq = tosq;
            tbmptr->tbm_frcp = frcp;
            tbmptr->tbm_tocp = tocp;
            tbmptr++;
            count++;
            };
          };

        if (map_file(frsq) < file_h)
          {
          tosq = frsq + dv_7;
          tocp = q_rb.rbv[tosq];
          if (cnv_cv[tocp] == c_w)
            {
            tbmptr->tbm_frsq = frsq;
            tbmptr->tbm_tosq = tosq;
            tbmptr->tbm_frcp = frcp;
            tbmptr->tbm_tocp = tocp;
            tbmptr++;
            count++;
            };
          };
        break;

      case cp_wn:
      case cp_bn:
        for (dx = dx_8; dx <= dx_f; dx++)
          {
          if (xb.xbv[xbfrsq + xdvv[dx]] == cp_v0)
            {
            tosq = frsq + dvv[dx];
            tocp = q_rb.rbv[tosq];
            if (cnv_cv[tocp] != q_actc)
              {
              tbmptr->tbm_frsq = frsq;
              tbmptr->tbm_tosq = tosq;
              tbmptr->tbm_frcp = frcp;
              tbmptr->tbm_tocp = tocp;
              tbmptr++;
              count++;
              };
            };
          };
        break;

      case cp_wb:
      case cp_bb:
        for (dx = dx_4; dx <= dx_7; dx++)
          {
          dv = dvv[dx];
          xdv = xdvv[dx];
          tosq = frsq + dv;
          xbtosq = xbfrsq + xdv;
          while ((xb.xbv[xbtosq] == cp_v0) &&
            ((tocp = q_rb.rbv[tosq]) == cp_v0))
            {
            tbmptr->tbm_frsq = frsq;
            tbmptr->tbm_tosq = tosq;
            tbmptr->tbm_frcp = frcp;
            tbmptr->tbm_tocp = tocp;
            tbmptr++;
            count++;

            tosq += dv;
            xbtosq += xdv;
            };

          if ((xb.xbv[xbtosq] == cp_v0) &&
            (cnv_cv[tocp = q_rb.rbv[tosq]] == q_pasc))
            {
            tbmptr->tbm_frsq = frsq;
            tbmptr->tbm_tosq = tosq;
            tbmptr->tbm_frcp = frcp;
            tbmptr->tbm_tocp = tocp;
            tbmptr++;
            count++;
            };
          };
        break;

      case cp_wr:
      case cp_br:
        for (dx = dx_0; dx <= dx_3; dx++)
          {
          dv = dvv[dx];
          xdv = xdvv[dx];
          tosq = frsq + dv;
          xbtosq = xbfrsq + xdv;
          while ((xb.xbv[xbtosq] == cp_v0) &&
            ((tocp = q_rb.rbv[tosq]) == cp_v0))
            {
            tbmptr->tbm_frsq = frsq;
            tbmptr->tbm_tosq = tosq;
            tbmptr->tbm_frcp = frcp;
            tbmptr->tbm_tocp = tocp;
            tbmptr++;
            count++;

            tosq += dv;
            xbtosq += xdv;
            };

          if ((xb.xbv[xbtosq] == cp_v0) &&
            (cnv_cv[tocp = q_rb.rbv[tosq]] == q_pasc))
            {
            tbmptr->tbm_frsq = frsq;
            tbmptr->tbm_tosq = tosq;
            tbmptr->tbm_frcp = frcp;
            tbmptr->tbm_tocp = tocp;
            tbmptr++;
            count++;
            };
          };
        break;

      case cp_wq:
      case cp_bq:
        for (dx = dx_0; dx <= dx_7; dx++)
          {
          dv = dvv[dx];
          xdv = xdvv[dx];
          tosq = frsq + dv;
          xbtosq = xbfrsq + xdv;
          while ((xb.xbv[xbtosq] == cp_v0) &&
            ((tocp = q_rb.rbv[tosq]) == cp_v0))
            {
            tbmptr->tbm_frsq = frsq;
            tbmptr->tbm_tosq = tosq;
            tbmptr->tbm_frcp = frcp;
            tbmptr->tbm_tocp = tocp;
            tbmptr++;
            count++;

            tosq += dv;
            xbtosq += xdv;
            };

          if ((xb.xbv[xbtosq] == cp_v0) &&
            (cnv_cv[tocp = q_rb.rbv[tosq]] == q_pasc))
            {
            tbmptr->tbm_frsq = frsq;
            tbmptr->tbm_tosq = tosq;
            tbmptr->tbm_frcp = frcp;
            tbmptr->tbm_tocp = tocp;
            tbmptr++;
            count++;
            };
          };
        break;

      case cp_wk:
      case cp_bk:
        for (dx = dx_0; dx <= dx_7; dx++)
          {
          if (xb.xbv[xbfrsq + xdvv[dx]] == cp_v0)
            {
            tosq = frsq + dvv[dx];
            tocp = q_rb.rbv[tosq];
            if (cnv_cv[tocp] != q_actc)
              {
              tbmptr->tbm_frsq = frsq;
              tbmptr->tbm_tosq = tosq;
              tbmptr->tbm_frcp = frcp;
              tbmptr->tbm_tocp = tocp;
              tbmptr++;
              count++;
              };
            };
          };
        break;

      default:
        TBSwitchFault("TBGenerate");
        break;
      };
    };

  /* assign move count */

  tbgmcv[q_actc] = count;
}

/*--> TBRetrogen: generate retrograde moves for the current position */
void TBRetrogen(void)
{
siT count;
tbmptrT tbmptr;
siT pi;
sqT frsq, tosq;
cpT frcp, tocp;
dxT dx;
dvT dv;
xbsqT xbfrsq, xbtosq;
xdvT xdv;
sqT prom_sq;

/* retrograde moves are generated for the passive color */

tbmptr = tbrgmbaseptrv[q_pasc];
count = 0;

/* scan piece vector for passive promoted pawns */

prom_sq = sq_nil;
pi = 1;
while ((pi < q_pasc_mc) && (prom_sq == sq_nil))
	{
	tosq = q_posv[q_pasc][pi];
	frcp = q_rb.rbv[tosq];
	if (cnv_pv[frcp] == p_p)
		switch (frcp)
			{
			case cp_wp:
				if (map_rank(tosq) == rank_8)
					prom_sq = tosq;
				break;

			case cp_bp:
				if (map_rank(tosq) == rank_1)
					prom_sq = tosq;
				break;
			};
	pi++;
	};

/* scan passive piece vector */

for (pi = 0; pi < q_pasc_mc; pi++)
	{
	tosq = q_posv[q_pasc][pi];
	frcp = q_rb.rbv[tosq];
	xbtosq = trn_xbsq(tosq);

	if (norm_capt_sq == tosq)
		tocp = norm_capt_cp;
	else
		tocp = cp_v0;

	if (((norm_capt_sq == sq_nil) || (norm_capt_sq == tosq)) &&
		((prom_sq == sq_nil) || (prom_sq == tosq)))
		{
		switch (frcp)
			{
			case cp_wp:
				if (map_rank(tosq) > rank_2)
					{
					if (norm_capt_sq == sq_nil)
						{
						frsq = tosq - dv_1;
						if (q_rb.rbv[frsq] == cp_v0)
							{
							tbmptr->tbm_frsq = frsq;
							tbmptr->tbm_tosq = tosq;
							tbmptr->tbm_frcp = frcp;
							tbmptr->tbm_tocp = tocp;
							tbmptr++;
							count++;
							if (map_rank(tosq) == rank_4)
								{
								frsq = tosq - (2 * dv_1);
								if (q_rb.rbv[frsq] == cp_v0)
									{
									tbmptr->tbm_frsq = frsq;
									tbmptr->tbm_tosq = tosq;
									tbmptr->tbm_frcp = frcp;
									tbmptr->tbm_tocp = tocp;
									tbmptr++;
									count++;
									};
								};
							};
						}
					else
						{
						if (map_file(tosq) > file_a)
							{
							frsq = tosq - dv_4;
							if (q_rb.rbv[frsq] == cp_v0)
								{
								tbmptr->tbm_frsq = frsq;
								tbmptr->tbm_tosq = tosq;
								tbmptr->tbm_frcp = frcp;
								tbmptr->tbm_tocp = tocp;
								tbmptr++;
								count++;
								};
							};

						if (map_file(tosq) < file_h)
							{
							frsq = tosq - dv_5;
							if (q_rb.rbv[frsq] == cp_v0)
								{
								tbmptr->tbm_frsq = frsq;
								tbmptr->tbm_tosq = tosq;
								tbmptr->tbm_frcp = frcp;
								tbmptr->tbm_tocp = tocp;
								tbmptr++;
								count++;
								};
							};
						};
					};
				break;

			case cp_bp:
				if (map_rank(tosq) < rank_7)
					{
					if (norm_capt_sq == sq_nil)
						{
						frsq = tosq - dv_3;
						if (q_rb.rbv[frsq] == cp_v0)
							{
							tbmptr->tbm_frsq = frsq;
							tbmptr->tbm_tosq = tosq;
							tbmptr->tbm_frcp = frcp;
							tbmptr->tbm_tocp = tocp;
							tbmptr++;
							count++;
							if (map_rank(tosq) == rank_5)
								{
								frsq = tosq - (2 * dv_3);
								if (q_rb.rbv[frsq] == cp_v0)
									{
									tbmptr->tbm_frsq = frsq;
									tbmptr->tbm_tosq = tosq;
									tbmptr->tbm_frcp = frcp;
									tbmptr->tbm_tocp = tocp;
									tbmptr++;
									count++;
									};
								};
							};
						}
					else
						{
						if (map_file(tosq) > file_a)
							{
							frsq = tosq - dv_7;
							if (q_rb.rbv[frsq] == cp_v0)
								{
								tbmptr->tbm_frsq = frsq;
								tbmptr->tbm_tosq = tosq;
								tbmptr->tbm_frcp = frcp;
								tbmptr->tbm_tocp = tocp;
								tbmptr++;
								count++;
								};
							};

						if (map_file(tosq) < file_h)
							{
							frsq = tosq - dv_6;
							if (q_rb.rbv[frsq] == cp_v0)
								{
								tbmptr->tbm_frsq = frsq;
								tbmptr->tbm_tosq = tosq;
								tbmptr->tbm_frcp = frcp;
								tbmptr->tbm_tocp = tocp;
								tbmptr++;
								count++;
								};
							};
						};
					};
				break;

			case cp_wn:
			case cp_bn:
				for (dx = dx_8; dx <= dx_f; dx++)
					{
					if (xb.xbv[xbtosq - xdvv[dx]] == cp_v0)
						{
						frsq = tosq - dvv[dx];
						if (q_rb.rbv[frsq] == cp_v0)
							{
							tbmptr->tbm_frsq = frsq;
							tbmptr->tbm_tosq = tosq;
							tbmptr->tbm_frcp = frcp;
							tbmptr->tbm_tocp = tocp;
							tbmptr++;
							count++;
							};
						};
					};
				break;

			case cp_wb:
			case cp_bb:
				for (dx = dx_4; dx <= dx_7; dx++)
					{
					dv = -dvv[dx];
					xdv = -xdvv[dx];
					frsq = tosq + dv;
					xbfrsq = xbtosq + xdv;
					while ((xb.xbv[xbfrsq] == cp_v0) &&
						(q_rb.rbv[frsq] == cp_v0))
						{
						tbmptr->tbm_frsq = frsq;
						tbmptr->tbm_tosq = tosq;
						tbmptr->tbm_frcp = frcp;
						tbmptr->tbm_tocp = tocp;
						tbmptr++;
						count++;

						frsq += dv;
						xbfrsq += xdv;
						};
					};
				break;

			case cp_wr:
			case cp_br:
				for (dx = dx_0; dx <= dx_3; dx++)
					{
					dv = -dvv[dx];
					xdv = -xdvv[dx];
					frsq = tosq + dv;
					xbfrsq = xbtosq + xdv;
					while ((xb.xbv[xbfrsq] == cp_v0) &&
						(q_rb.rbv[frsq] == cp_v0))
						{
						tbmptr->tbm_frsq = frsq;
						tbmptr->tbm_tosq = tosq;
						tbmptr->tbm_frcp = frcp;
						tbmptr->tbm_tocp = tocp;
						tbmptr++;
						count++;

						frsq += dv;
						xbfrsq += xdv;
						};
					};
				break;

			case cp_wq:
			case cp_bq:
				for (dx = dx_0; dx <= dx_7; dx++)
					{
					dv = -dvv[dx];
					xdv = -xdvv[dx];
					frsq = tosq + dv;
					xbfrsq = xbtosq + xdv;
					while ((xb.xbv[xbfrsq] == cp_v0) &&
						(q_rb.rbv[frsq] == cp_v0))
						{
						tbmptr->tbm_frsq = frsq;
						tbmptr->tbm_tosq = tosq;
						tbmptr->tbm_frcp = frcp;
						tbmptr->tbm_tocp = tocp;
						tbmptr++;
						count++;

						frsq += dv;
						xbfrsq += xdv;
						};
					};
				break;

			case cp_wk:
			case cp_bk:
				for (dx = dx_0; dx <= dx_7; dx++)
					{
					if (xb.xbv[xbtosq - xdvv[dx]] == cp_v0)
						{
						frsq = tosq - dvv[dx];
						if (q_rb.rbv[frsq] == cp_v0)
							{
							tbmptr->tbm_frsq = frsq;
							tbmptr->tbm_tosq = tosq;
							tbmptr->tbm_frcp = frcp;
							tbmptr->tbm_tocp = tocp;
							tbmptr++;
							count++;
							};
						};
					};
				break;

			default:
				TBSwitchFault("TBRetrogen");
				break;
			};
		};
	};

/* assign move count */

tbrgmcv[q_pasc] = count;
}

/*--> TBSaveCaptureEP: save current capture/ep information */
static
void
TBSaveCaptureEP(void)
{
save_epsq = norm_epsq;
save_capt_cp = norm_capt_cp;
save_capt_sq = norm_capt_sq;
save_capt_si = norm_capt_si;
}

/*--> TBRestoreCaptureEP: restore current capture/ep information */
static
void
TBRestoreCaptureEP(void)
{
norm_epsq = save_epsq;
norm_capt_cp = save_capt_cp;
norm_capt_sq = save_capt_sq;
norm_capt_si = save_capt_si;
}

/*--> TBExecute: execute a move */
void TBExecute(tbmptrT tbmptr)
{
siT actc_si, pasc_si;

TBSaveCaptureEP();

actc_si = q_siv[tbmptr->tbm_frsq];
pasc_si = q_siv[tbmptr->tbm_tosq];

q_rb.rbv[tbmptr->tbm_frsq] = cp_v0;
q_siv[tbmptr->tbm_frsq] = -1;

q_rb.rbv[tbmptr->tbm_tosq] = tbmptr->tbm_frcp;
q_siv[tbmptr->tbm_tosq] = actc_si;

q_posv[q_actc][actc_si] = tbmptr->tbm_tosq;

if (pasc_si == -1)
	{
	norm_capt_cp = cp_nil;
	norm_capt_sq = sq_nil;
	norm_capt_si = -1;
	}
else
	{
	norm_capt_cp = tbmptr->tbm_tocp;
	norm_capt_sq = tbmptr->tbm_tosq;
	norm_capt_si = pasc_si;
	};

TBSetCurrentActive(q_pasc);
}

/*--> TBRetract: retract a move */
void TBRetract(tbmptrT tbmptr)
{
  siT actc_si;

  TBSetCurrentActive(q_pasc);

  actc_si = q_siv[tbmptr->tbm_tosq];

  q_rb.rbv[tbmptr->tbm_frsq] = tbmptr->tbm_frcp;
  q_siv[tbmptr->tbm_frsq] = actc_si;

  q_posv[q_actc][actc_si] = tbmptr->tbm_frsq;

  if (tbmptr->tbm_tocp == cp_v0)
  {
    q_rb.rbv[tbmptr->tbm_tosq] = cp_v0;
    q_siv[tbmptr->tbm_tosq] = -1;
  }
  else
  {
    q_rb.rbv[tbmptr->tbm_tosq] = norm_capt_cp;
    q_siv[tbmptr->tbm_tosq] = norm_capt_si;
  };

  TBRestoreCaptureEP();
}

/*--> TBPositionIndex: generate index for the current position */
indexT TBPositionIndex(void)
{
indexT index = TBGenIndex(cw_classptr, q_posv);

return index;
}

/*--> TBPositionIndexDual: generate index for the current position dual */
indexT TBPositionIndexDual(void)
{
  indexT index = TBGenIndexDual(cw_classptr, q_posv);

  return index;
}

/*--> TBHasDual: does the current position have a dual? */
siT TBHasDual(void)
{
  siT flag;

  if ((cw_fold == fold_triangle) &&
    diagonalv[q_posv[cw_pivot_c][cw_pivot_slot]])
    flag = 1;
  else
    flag = 0;

  return flag;
}
