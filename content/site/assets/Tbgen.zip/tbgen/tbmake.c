/* >>> tbmake.c: central construction supervisor for tablebase generator */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "tbdefs.h"
#include "tbvars.h"

#include "tbfile.h"
#include "tbmake.h"
#include "tbmisc.h"
#include "tbmove.h"
#include "tboper.h"
#include "tbsort.h"
#include "tbspin.h"
#include "tbutil.h"

/*--> TBMutate: determine new position/dist vector after capture/promotion */
static tbptrT TBMutate(
  tbptrT classptr, cT c, posvT posv, sqT capt_sq, sqT prom_sq, pT prom_p,
	posvT nposv, distvT ndistv, siptrT invertptr)
{
  cT auxc, invc, swapc;
  sqT sq;
  siT i, capt_si;
  tbidT new_class;
  tbptrT new_classptr;
  pT psqv[rcL][sqL];

  /* set the inverse color */

  invc = inv_cv[c];

  /* set up the old position */

  for (sq = sq_a1; sq <= sq_h8; sq++)
    for (auxc = c_w; auxc <= c_b; auxc++)
      psqv[auxc][sq] = p_v;

  for (auxc = c_w; auxc <= c_b; auxc++)
    for (i = 0; i < classptr->tb_mcv[auxc]; i++)
    {
      /* locate the square */

      sq = posv[auxc][i];

      /* avoid placing captured piece */

      if ((capt_sq != sq) || (auxc == invc))
      {
        if (prom_sq != sq)
          psqv[auxc][sq] = classptr->tb_pv[auxc][i];
        else
          psqv[auxc][sq] = prom_p;
      };
    };

  /* copy from old distribution vector */

  TBCopyDistribution(classptr->tb_distv, ndistv);

  /* if a piece was captured, decrement the corresponding count in the dist */

  if (capt_sq != sq_nil)
  {
    /* locate the capture slot in the active piece array */

    capt_si = 1;
    while (posv[c][capt_si] != capt_sq)
      capt_si++;

    /* decrement the corresponding piece slot in the distribution */

    ndistv[c][classptr->tb_pv[c][capt_si]]--;
  };

  /* adjust distribution if a promotion occurred */

  if (prom_sq != sq_nil)
  {
    ndistv[invc][p_p]--;
    ndistv[invc][prom_p]++;
  };

  /* get the new class */

  new_class = TBLocateClass(ndistv, invertptr);
  new_classptr = tbbaseptr + new_class;

  /* generate the new position vector */

  for (auxc = c_w; auxc <= c_b; auxc++)
  {
    /* set the swap color */

    if (*invertptr)
      swapc = inv_cv[auxc];
    else
      swapc = auxc;

    /* scan the pieces in the new class */

    for (i = 0; i < new_classptr->tb_mcv[auxc]; i++)
    {
      /* scan the board, clear one square per board scan */

      sq = sq_a1;
      nposv[swapc][i] = sq_nil;
      while (nposv[swapc][i] == sq_nil)
      {
        if (psqv[swapc][sq] == new_classptr->tb_pv[auxc][i])
        {
          nposv[swapc][i] = sq;
          psqv[swapc][sq] = p_v;
        }
        else
          sq++;
      };
    };
  };

  return new_classptr;
}

/*--> TBAdjustHWM: adjust high water marks for a color and distance */
void TBAdjustHWM(cT c, bevT bev)
{
  siT distance;

  switch (bev)
  {
  case bev_unknown:
  case bev_broken:
  case bev_reserved:
    TBFatal("TBAdjustHWM: bad BEV input");
    break;
  case bev_draw:
    break;
  default:
    if (bev > bev_draw)
    {
      distance = bev_mi1 - bev + 1;
      if (distance > maxmatev[c])
        maxmatev[c] = distance;
    }
    else
    {
      distance = bev - bev_li0;
      if (distance > maxlosev[c])
        maxlosev[c] = distance;
    };
    break;
  };
}

/*--> TBMake: make a tablebase pair */
void TBMake(void)
{
  indexT index;
  cT c, invc, auxc;
  pT p;
  tbidT tbid;
  siT flag, i, count;
  siT at_least_one;
  siT mi, rmi;
  tbptrT classptr;
  charptrT class_name;
  indexT class_length;
  siT class_count;
  cT class_pivot_c;
  siT class_pivot_slot;
  foldT class_fold;
  siT class_flags;
  siT class_mcv[rcL];
  distvT class_distv, dir_distv;
  pT class_pv[rcL][tbmecL];
  siT class_has_pawns, class_has_white_pawn, class_has_black_pawn;
  siT class_depcountv[rcL];
  depvT class_depv[rcL];
  fptrT class_depfptrv[rcL][tbidL][rcL];
  charptrT dtfnptrv[rcL][tbidL][rcL];
  fptrT dtffptrv[rcL][tbidL][rcL];
  charptrT target_fnv[rcL];
  fptrT target_fptrv[rcL];
  posvT posv, posnkv;
  siT broken;
  bevT input_bev, output_bev;
  rankT wk_rank, bk_rank;
  fileT wk_file, bk_file;
  sqT sq, pair_sq, capt_sq, prom_sq;
  siT c_mate, s_mate;
  pT prom_p;
  cT dir_c;
  tbidT dir_tbid;
  indexT dir_index;
  sr0T dir_sr0;
  siT dir_invert;
  posvT dir_posv;
  tbptrT dir_classptr;
  siT dir_eofv[tbidL][rcL];
  sr1T dir_sr1v[tbidL][rcL];
  indexT dir_target;
  charptrT reffn;
  tbmptrT tbmptr, tbrmptr;
  siT tbgmc, tbrgmc;
  siT sqcountv[sqL];
  charptrT tfnptr0, tfnptr1, tfnptr2;
  fptrT tffptr0, tffptr1, tffptr2;
  siT distance;
  liT mate_count, lose_count, candidate_count;
  sr2T sr2;
  sr3T sr3;
  siT ordinal;
  indexT retro_index, retro_dual_index;
  bevT assign_mate_bev, assign_lose_bev;
  bevT match_mate_bev, match_lose_bev;

  /* initialize local class scalars */

  classptr = tbbaseptr + class_tbid;
  class_flags = classptr->tb_flags;
  class_name = classptr->tb_name;
  class_length = classptr->tb_length;
  class_count = classptr->tb_count;
  class_pivot_c = classptr->tb_pivot_c;
  class_pivot_slot = classptr->tb_pivot_slot;
  class_fold = classptr->tb_fold;

  /* man counts, piece vectors, and distributions */

  for (c = c_w; c <= c_b; c++)
  {
    class_mcv[c] = classptr->tb_mcv[c];
    for (i = 0; i < class_mcv[c]; i++)
      class_pv[c][i] = classptr->tb_pv[c][i];
    for (p = p_p; p <= p_k; p++)
      class_distv[c][p] = classptr->tb_distv[c][p];
  };

  /* pawn specific items */

  if (class_flags & tbf_has_pawns)
    class_has_pawns = 1;
  else
    class_has_pawns = 0;

  if (class_flags & tbf_has_white_pawn)
    class_has_white_pawn = 1;
  else
    class_has_white_pawn = 0;

  if (class_flags & tbf_has_black_pawn)
    class_has_black_pawn = 1;
  else
    class_has_black_pawn = 0;

  /* establish the dependencies for this class */

  for (c = c_w; c <= c_b; c++)
  {
    TBSetDependencyVector(classptr, c, class_depv[c]);
    class_depcountv[c] = TBCountDependencies(class_depv[c]);
  };

  /* clear the dependency class data file pointers */

  for (c = c_w; c <= c_b; c++)
    for (tbid = 0; tbid < tbidL; tbid++)
      for (auxc = c_w; auxc <= c_b; auxc++)
        class_depfptrv[c][tbid][auxc] = NULL;

  /* set up transition directive file name pointers; clear file pointers */

  for (c = c_w; c <= c_b; c++)
  {
    for (tbid = 0; tbid < tbidL; tbid++)
    {
      for (auxc = c_w; auxc <= c_b; auxc++)
      {
        if (class_depv[c][tbid][auxc])
          dtfnptrv[c][tbid][auxc] = TBTempFileName();
        else
          dtfnptrv[c][tbid][auxc] = NULL;
        dtffptrv[c][tbid][auxc] = NULL;
      };
    };
  };

  /* initialize target file names */

  for (c = c_w; c <= c_b; c++)
    target_fnv[c] = TBClassFileName(targetdir_strv[c], class_tbid, c);

  /* initialize the move generation machinery */

  TBSetCurrentClass(class_tbid);

  /* report */

  for (c = c_w; c <= c_b; c++)
    printf("Target filename: %s: %s\n", ctm_strv[c], target_fnv[c]);

  printf("Target class length: %ld\n", class_length);
  printf("Target class count: %hd\n", class_count);
  printf("Target class white count: %hd\n", class_mcv[c_w]);
  printf("Target class black count: %hd\n", class_mcv[c_b]);
  printf("Target class fold mode: %hd\n", class_fold);
  printf("Target class pivot color: %hd\n", class_pivot_c);
  printf("Target class pivot slot: %hd\n", class_pivot_slot);
  printf("Target class flags: %04hx\n", class_flags);

  /* output dependency counts and subclasses */

  for (c = c_w; c <= c_b; c++)
  {
    printf("%s %s: Subclass dependency count: %hd\n",
      class_name, ctm_strv[c], class_depcountv[c]);
    for (tbid = 0; tbid < tbidL; tbid++)
    {
      for (auxc = c_w; auxc <= c_b; auxc++)
      {
        if (class_depv[c][tbid][auxc])
          printf("    %s %s\n", (tbbaseptr + tbid)->tb_name, ctm_strv[auxc]);
      };
    };
  };

  /* check subclass availability */

  flag = 1;
  for (c = c_w; c <= c_b; c++)
  {
    for (tbid = 0; tbid < tbidL; tbid++)
    {
      for (auxc = c_w; auxc <= c_b; auxc++)
      {
        if (class_depv[c][tbid][auxc])
        {
          tfnptr0 = TBClassFileName(refdir_str, tbid, auxc);
          tffptr0 = TBCodeFileOpenReadSF(tfnptr0);
          if (tffptr0 == NULL)
          {
            fprintf(stderr,
              "Can't open subclass file %s for reading\n", tfnptr0);
            flag = 0;
          }
          else
            TBCodeFileClose(tffptr0);
          TBStringFree(tfnptr0);
        };
      };
    };
  };

  if (!flag)
    TBFatal("Subclass file(s) unavailable");

  /* initialize file contents */

  for (c = c_w; c <= c_b; c++)
  {
    /* report */

    printf("%s %s: Initializing target file: %s\n",
      class_name, ctm_strv[c], target_fnv[c]);

    /* open the target file */

    target_fptrv[c] = TBCodeFileOpenWrite(target_fnv[c]);
    TBSetBiggerBuffer(target_fptrv[c]);

    /* scan */

    for (index = 0; index < class_length; index++)
      fputc(bev_unknown, target_fptrv[c]);

    /* close the target file */

    TBCodeFileClose(target_fptrv[c]);
  };

  /* mark broken positions */

  for (c = c_w; c <= c_b; c++)
  {
    /* report */

    printf("%s %s: Marking broken positions\n", class_name, ctm_strv[c]);

    /* set inverse color */

    invc = inv_cv[c];

    /* set the active color for the move machinery */

    TBSetCurrentActive(c);

    /* open the source file */

    target_fptrv[c] = TBCodeFileOpenRead(target_fnv[c]);
    TBSetBiggerBuffer(target_fptrv[c]);

    /* open the temporary file */

    tfnptr0 = TBTempFileName();
    tffptr0 = TBCodeFileOpenWrite(tfnptr0);
    TBSetBiggerBuffer(tffptr0);

    /* scan */

    for (index = 0; index < class_length; index++)
    {
      /* read the input BEV */

      input_bev = fgetc(target_fptrv[c]);

      /* clear broken flag */

      broken = 0;

      /* set up position vector */

      TBSetPosVector(classptr, index, posv);

      /* set up position vector (no ep kludge) */

      TBSetPosVectorNK(classptr, index, posnkv);

      /* first test: king adjacent or overlap */

      wk_rank = map_rank(posv[c_w][0]);
      bk_rank = map_rank(posv[c_b][0]);
      if (abs(wk_rank - bk_rank) < 2)
      {
        wk_file = map_file(posv[c_w][0]);
        bk_file = map_file(posv[c_b][0]);
        if (abs(wk_file - bk_file) < 2)
          broken = 1;
      };

      /* second test: active king captured */

      if (!broken)
      {
        i = 0;
        while (!broken && (i < class_mcv[invc]))
        {
          if (posv[c][0] == posv[invc][i])
            broken = 1;
          else
            i++;
        };
      };

      /* third test: active pawn promoted */

      if (!broken && class_has_pawns)
      {
        if (c == c_w)
        {
          if (class_has_white_pawn)
          {
            i = 1;
            while (!broken && (i < class_mcv[c_w]))
            {
              if (class_pv[c_w][i] == p_p)
                if (map_rank(posv[c_w][i]) == rank_8)
                  broken = 1;
              i++;
            };
          };
        }
        else
        {
          if (class_has_black_pawn)
          {
            i = 1;
            while (!broken && (i < class_mcv[c_b]))
            {
              if (class_pv[c_b][i] == p_p)
                if (map_rank(posv[c_b][i]) == rank_1)
                  broken = 1;
              i++;
            };
          };
        };
      };

      /* fourth test: white pawn on home square */

      if (!broken && class_has_white_pawn)
      {
        i = 1;
        while (!broken && (i < class_mcv[c_w]))
        {
          if (class_pv[c_w][i] == p_p)
          {
            if (map_rank(posv[c_w][i]) == rank_1)
              broken = 1;
          };
          i++;
        };
      };

      /* fifth test: black pawn on home square */

      if (!broken && class_has_black_pawn)
      {
        i = 1;
        while (!broken && (i < class_mcv[c_b]))
        {
          if (class_pv[c_b][i] == p_p)
          {
            if (map_rank(posv[c_b][i]) == rank_8)
              broken = 1;
          };
          i++;
        };
      };

      /* sixth test: more than one white man on any square */

      if (!broken && (class_mcv[c_w] > 1))
      {
        for (sq = sq_a1; sq <= sq_h8; sq++)
          sqcountv[sq] = 0;
        i = 0;
        while (!broken && (i < class_mcv[c_w]))
        {
          sq = posv[c_w][i];
          if (sqcountv[sq] == 1)
            broken = 1;
          else
            sqcountv[sq] = 1;
          i++;
        };
      };

      /* seventh test: more than one black man on any square */

      if (!broken && (class_mcv[c_b] > 1))
      {
        for (sq = sq_a1; sq <= sq_h8; sq++)
          sqcountv[sq] = 0;
        i = 0;
        while (!broken && (i < class_mcv[c_b]))
        {
          sq = posv[c_b][i];
          if (sqcountv[sq] == 1)
            broken = 1;
          else
            sqcountv[sq] = 1;
          i++;
        };
      };

      /* eighth test: more than one pair square */

      if (!broken && (class_count > 3))
      {
        for (sq = sq_a1; sq <= sq_h8; sq++)
          sqcountv[sq] = 0;
        for (auxc = c_w; auxc <= c_b; auxc++)
        {
          for (i = 0; i < class_mcv[auxc]; i++)
            sqcountv[posv[auxc][i]]++;
        };
        pair_sq = sq_nil;
        sq = sq_a1;
        while (!broken && (sq <= sq_h8))
        {
          if (sqcountv[sq] == 2)
            if (pair_sq == sq_nil)
              pair_sq = sq;
            else
              broken = 1;
          sq++;
        };
      };

      /* ninth test: more than one promoted white pawn */

      if (!broken && (classptr->tb_distv[c_w][p_p] > 1))
      {
        prom_sq = sq_nil;
        i = 1;
        while (!broken && (i < class_mcv[c_w]))
        {
          if (class_pv[c_w][i] == p_p)
          {
            if (map_rank(posv[c_w][i]) == rank_8)
            {
              if (prom_sq == sq_nil)
                prom_sq = posv[c_w][i];
              else
                broken = 1;
            };
          };
          i++;
        };
      };

      /* tenth test: more than one promoted black pawn */

      if (!broken && (classptr->tb_distv[c_b][p_p] > 1))
      {
        prom_sq = sq_nil;
        i = 1;
        while (!broken && (i < class_mcv[c_b]))
        {
          if (class_pv[c_b][i] == p_p)
          {
            if (map_rank(posv[c_b][i]) == rank_1)
            {
              if (prom_sq == sq_nil)
                prom_sq = posv[c_b][i];
              else
                broken = 1;
            };
          };
          i++;
        };
      };

      /* eleventh test: pair and prom exist, but are different */

      if (!broken && (classptr->tb_distv[invc][p_p] > 0))
      {
        /* locate the pair square */

        for (sq = sq_a1; sq <= sq_h8; sq++)
          sqcountv[sq] = 0;
        for (auxc = c_w; auxc <= c_b; auxc++)
        {
          for (i = 0; i < class_mcv[auxc]; i++)
            sqcountv[posv[auxc][i]]++;
        };
        pair_sq = sq_nil;
        sq = sq_a1;
        while ((pair_sq == sq_nil) && (sq <= sq_h8))
        {
          if (sqcountv[sq] == 2)
            pair_sq = sq;
          else
            sq++;
        };

        /* if a capture exists, check for a promotion square */

        if (pair_sq != sq_nil)
        {
          /* look for a promotion square */

          prom_sq = sq_nil;
          i = 1;
          while ((prom_sq == sq_nil) && (i < class_mcv[invc]))
          {
            if (class_pv[invc][i] == p_p)
            {
              if ((invc == c_w) && (map_rank(posv[c_w][i]) == rank_8))
                prom_sq = posv[c_w][i];
              if ((invc == c_b) && (map_rank(posv[c_b][i]) == rank_1))
                prom_sq = posv[c_b][i];
            };
            i++;
          };

          /* check for fault mismatch */

          if ((prom_sq != sq_nil) && (pair_sq != prom_sq))
            broken = 1;
        };
      };

      /* twelveth test: active ep target */

      if (!broken && (class_pv[c][p_p] > 0))
      {
        if (c == c_w)
        {
          i = 1;
          while (!broken && (i < class_mcv[c_w]))
            {
            if (class_pv[c_w][i] == p_p)
            {
              if (map_rank(posnkv[c_w][i]) == rank_1)
                broken = 1;
            };
            i++;
            };
        }
        else
        {
          i = 1;
          while (!broken && (i < class_mcv[c_b]))
          {
            if (class_pv[c_b][i] == p_p)
            {
              if (map_rank(posnkv[c_b][i]) == rank_8)
                broken = 1;
            };
            i++;
          };
        };
      };

      /* thirteenth test: multiple ep targets */

      if (!broken && (class_pv[invc][p_p] > 1))
      {
        count = 0;
        if (invc == c_w)
        {
          i = 1;
          while (!broken && (i < class_mcv[c_w]))
          {
            if (class_pv[c_w][i] == p_p)
            {
              if (map_rank(posnkv[c_w][i]) == rank_1)
              {
                count++;
                if (count > 1)
                  broken = 1;
              };
            };
            i++;
          };
        }
        else
        {
          i = 1;
          while (!broken && (i < class_mcv[c_b]))
          {
            if (class_pv[c_b][i] == p_p)
            {
              if (map_rank(posnkv[c_b][i]) == rank_8)
              {
                count++;
                if (count > 1)
                  broken = 1;
              };
            };
            i++;
          };
        };
      };

      /* fourteenth test: bogus ep target */

      if (!broken && (class_pv[invc][p_p] > 0))
      {
        sq = TBGetEPSQ(classptr, c, index);
        if (sq != sq_nil)
        {
          if (c == c_w)
          {
            /* check for bad black target */

            if (TBOccupied(sq, classptr, posv) ||
              TBOccupied((sq + fileL), classptr, posv) ||
              TBOccupied((sq + (fileL * 2)), classptr, posv))
              broken = 1;
          }
          else
          {
            /* check for bad white target */

            if (TBOccupied(sq, classptr, posv) ||
              TBOccupied((sq - fileL), classptr, posv) ||
              TBOccupied((sq - (fileL * 2)), classptr, posv))
              broken = 1;
          };
        };
      };

      /* fifteenth test: ep target in capture transition position */

      if (!broken && class_has_pawns)
      {
        if (TBGetEPSQ(classptr, c, index) != sq_nil)
        {
          /* locate the pair square */

          for (sq = sq_a1; sq <= sq_h8; sq++)
            sqcountv[sq] = 0;
          for (auxc = c_w; auxc <= c_b; auxc++)
          {
            for (i = 0; i < class_mcv[auxc]; i++)
              sqcountv[posv[auxc][i]]++;
          };
          pair_sq = sq_nil;
          sq = sq_a1;
          while ((pair_sq == sq_nil) && (sq <= sq_h8))
          {
            if (sqcountv[sq] == 2)
              pair_sq = sq;
            else
              sq++;
          };

          /* was there a capture? */

          if (pair_sq != sq_nil)
            broken = 1;
        };
      };

      /* sixteenth test: ep target in promotion transition position */

      if (!broken && class_has_pawns)
      {
        if (TBGetEPSQ(classptr, c, index) != sq_nil)
        {
          /* locate the promotion square */

          prom_sq = sq_nil;
          i = 1;
          while ((prom_sq == sq_nil) && (i < class_mcv[invc]))
          {
            if (class_pv[invc][i] == p_p)
            {
              if ((invc == c_w) && (map_rank(posv[c_w][i]) == rank_8))
                prom_sq = posv[c_w][i];
              if ((invc == c_b) && (map_rank(posv[c_b][i]) == rank_1))
                prom_sq = posv[c_b][i];
            };
            i++;
          };

          /* was there a promotion? */

          if (prom_sq != sq_nil)
            broken = 1;
        };
      };

      /* seventeenth test: passive king in check */

      if (!broken)
      {
        /* set up the position */

        TBSetBoard(TBGetEPSQ(classptr, c, index), posv);

        /* if the passive king is in check, the position is busted */

        if (TBKingInCheck(invc))
          broken = 1;
      };

      /* set output BEV */

      if (broken)
        output_bev = bev_broken;
      else
        output_bev = input_bev;

      /* write output BEV */

      fputc(output_bev, tffptr0);
    };

    /* close the temporary file */

    TBCodeFileClose(tffptr0);

    /* close the target file */

    TBCodeFileClose(target_fptrv[c]);

    /* copy the temporary file to the target file */

    TBCodeFileRename(tfnptr0, target_fnv[c]);

    /* release the temporary file name */

    TBStringFree(tfnptr0);
	};

  /* mark transition positions */

  for (c = c_w; c <= c_b; c++)
  {
    /* report */

    printf("%s %s: Marking transition positions\n", class_name, ctm_strv[c]);

    /* set inverse color */

    invc = inv_cv[c];

    /* open transition directive files for output */

    for (tbid = 0; tbid < tbidL; tbid++)
    {
      for (auxc = c_w; auxc <= c_b; auxc++)
      {
        if (class_depv[c][tbid][auxc])
        {
          dtffptrv[c][tbid][auxc] =
            TBCodeFileOpenWrite(dtfnptrv[c][tbid][auxc]);
          TBSetBigBuffer(dtffptrv[c][tbid][auxc]);
        };
      };
    };

    /* open the target file */

    target_fptrv[c] = TBCodeFileOpenRead(target_fnv[c]);
    TBSetBiggerBuffer(target_fptrv[c]);

    /* scan */

    for (index = 0; index < class_length; index++)
    {
      /* get the input BEV */

      input_bev = fgetc(target_fptrv[c]);

      /* continue if unknown BEV */

      if (input_bev == bev_unknown)
      {
        /* set up the position vector */

        TBSetPosVector(classptr, index, posv);

        /* locate the capture square */

        capt_sq = sq_nil;
        if (class_mcv[c] > 1)
        {
          for (sq = sq_a1; sq <= sq_h8; sq++)
            sqcountv[sq] = 0;
          for (auxc = c_w; auxc <= c_b; auxc++)
          {
            for (i = 0; i < class_mcv[auxc]; i++)
              sqcountv[posv[auxc][i]]++;
          };
          sq = sq_a1;
          while ((capt_sq == sq_nil) && (sq <= sq_h8))
          {
            if (sqcountv[sq] == 2)
              capt_sq = sq;
            else
              sq++;
          };
        };

        /* locate the prom square */

        prom_sq = sq_nil;
        if (class_distv[invc][p_p] > 0)
        {
          i = 1;
          while ((prom_sq == sq_nil) && (i < class_mcv[invc]))
          {
            if (class_pv[invc][i] == p_p)
              if (map_rank(posv[invc][i]) == prom_rankv[invc])
                prom_sq = posv[invc][i];
            i++;
          };
        };

        /* was there a capture without a promotion? */

        if ((capt_sq != sq_nil) && (prom_sq == sq_nil))
        {
          /* get new class pointer, position vector, dist and invert flag */

          dir_classptr =
            TBMutate(classptr, c, posv, capt_sq, sq_nil, p_nil,
              dir_posv, dir_distv, &dir_invert);

          if (dir_classptr == NULL)
            TBFatal("Can't locate directive class");

          /* get the directive class and color */

          dir_tbid = dir_classptr - tbbaseptr;
          if (dir_invert)
            dir_c = invc;
          else
            dir_c = c;

          /* check if temporary directive file was opened */

          if ((tffptr0 = dtffptrv[c][dir_tbid][dir_c]) == NULL)
            TBFatal("Unopened directive file");

          /* calculate directive index */

          if (dir_invert)
            dir_index = TBGenInvertIndex(dir_classptr, dir_posv);
          else
            dir_index = TBGenIndex(dir_classptr, dir_posv);

          /* form and output directive record */

          dir_sr0.sr0_index0 = index;
          dir_sr0.sr0_index1 = dir_index;
          if (fwrite(&dir_sr0, 1, sizeof(sr0T), tffptr0) != sizeof(sr0T))
            TBFatal("Can't write to directive file");
        }
        else
        {
          if (prom_sq != sq_nil)
          {
            /* handle promotion sequence */

            for (prom_p = p_n; prom_p <= p_q; prom_p++)
            {
              /* get the new class pointer, position vector, dist and invert flag */

              dir_classptr =
                TBMutate(classptr, c, posv, capt_sq, prom_sq, prom_p,
                  dir_posv, dir_distv, &dir_invert);

              if (dir_classptr == NULL)
                TBFatal("Can't locate directive class");

              /* get the directive class and color */

              dir_tbid = dir_classptr - tbbaseptr;
              if (dir_invert)
                dir_c = invc;
              else
                dir_c = c;

              /* check if temporary directive file was opened */

              if ((tffptr0 = dtffptrv[c][dir_tbid][dir_c]) == NULL)
                TBFatal("Unopened directive file");

              /* calculate directive index */

              if (dir_invert)
                dir_index = TBGenInvertIndex(dir_classptr, dir_posv);
              else
                dir_index = TBGenIndex(dir_classptr, dir_posv);

              /* form and output directive record */

              dir_sr0.sr0_index0 = index;
              dir_sr0.sr0_index1 = dir_index;
              if (fwrite(&dir_sr0, 1, sizeof(sr0T), tffptr0) != sizeof(sr0T))
                TBFatal("Can't write to directive file");
            };
          };
        };
      };
    };

    /* close the target file */

    TBCodeFileClose(target_fptrv[c]);

    /* close transition directive files for this color */

    for (tbid = 0; tbid < tbidL; tbid++)
    {
      for (auxc = c_w; auxc <= c_b; auxc++)
      {
        if (class_depv[c][tbid][auxc])
        {
          TBCodeFileClose(dtffptrv[c][tbid][auxc]);
          dtffptrv[c][tbid][auxc] = NULL;
        };
      };
    };
  };

  /* sort transition directive files */

  for (c = c_w; c <= c_b; c++)
  {
    /* report */

    printf("%s %s: Sorting transition directive set\n",
      class_name, ctm_strv[c]);

    /* scan transition directive array */

    for (tbid = 0; tbid < tbidL; tbid++)
    {
      for (auxc = c_w; auxc <= c_b; auxc++)
      {
        if (class_depv[c][tbid][auxc])
        {
          dir_classptr = tbbaseptr + tbid;
          printf("%s %s: ", class_name, ctm_strv[c]);
          printf("Sorting transition directives for successor class: %s %s\n",
            dir_classptr->tb_name, ctm_strv[auxc]);
          tfnptr0 = TBTempFileName();
          TBSortFile(
            dtfnptrv[c][tbid][auxc],
            tfnptr0, sizeof(sr0T), 0, (void *)TBCompSR0);
          TBStringFree(dtfnptrv[c][tbid][auxc]);
          dtfnptrv[c][tbid][auxc] = tfnptr0;
        };
      };
    };
  };

  /* generate transition directive look-up set files */

  for (c = c_w; c <= c_b; c++)
  {
    /* report */

    printf("%s %s: Generating transition directive look-up set files\n",
      class_name, ctm_strv[c]);

    /* scan transition directive array */

    for (tbid = 0; tbid < tbidL; tbid++)
    {
      for (auxc = c_w; auxc <= c_b; auxc++)
      {
        if (class_depv[c][tbid][auxc])
        {
          dir_classptr = tbbaseptr + tbid;
          printf("%s %s: ", class_name, ctm_strv[c]);
          printf("Generating look-up set file successor class: %s %s\n",
            dir_classptr->tb_name, ctm_strv[auxc]);
          tfnptr0 = TBTempFileName();
          reffn = TBClassFileName(refdir_str, tbid, auxc);
          TBLookUp(reffn, dtfnptrv[c][tbid][auxc], tfnptr0);
          TBStringFree(reffn);
          TBCodeFileRemove(dtfnptrv[c][tbid][auxc]);
          TBStringFree(dtfnptrv[c][tbid][auxc]);
          dtfnptrv[c][tbid][auxc] = tfnptr0;
        };
      };
    };
  };

  /* sort transition look-up files */

  for (c = c_w; c <= c_b; c++)
  {
    /* report */

    printf("%s %s: Sorting transition look-up set\n",
      class_name, ctm_strv[c]);

    /* scan transition look-up array */

    for (tbid = 0; tbid < tbidL; tbid++)
    {
      for (auxc = c_w; auxc <= c_b; auxc++)
      {
        if (class_depv[c][tbid][auxc])
        {
          dir_classptr = tbbaseptr + tbid;
          printf("%s %s: ", class_name, ctm_strv[c]);
          printf("Sorting transition look-up for successor class: %s %s\n",
            dir_classptr->tb_name, ctm_strv[auxc]);
          tfnptr0 = TBTempFileName();
          TBSortFile(
            dtfnptrv[c][tbid][auxc],
            tfnptr0, sizeof(sr1T), 0, (void *)TBCompSR1);
          TBStringFree(dtfnptrv[c][tbid][auxc]);
          dtfnptrv[c][tbid][auxc] = tfnptr0;
        };
      };
    };
  };

  /* apply transition directive look-up set files */

  for (c = c_w; c <= c_b; c++)
  {
    /* report */

    printf("%s %s: Applying transition directive look-up set files\n",
      class_name, ctm_strv[c]);

    /* open the target file */

    target_fptrv[c] = TBCodeFileOpenRead(target_fnv[c]);
    TBSetBigBuffer(target_fptrv[c]);

    /* open the temporary file */

    tfnptr0 = TBTempFileName();
    tffptr0 = TBCodeFileOpenWrite(tfnptr0);
    TBSetBigBuffer(tffptr0);

    /* open the transition directive look-up set files for reading */

    for (dir_tbid = 0; dir_tbid < tbidL; dir_tbid++)
    {
      dir_classptr = tbbaseptr + dir_tbid;
      for (auxc = c_w; auxc <= c_b; auxc++)
      {
        /* clear the eof vector entry */

        dir_eofv[dir_tbid][auxc] = 0;

        /* is the slot in use? */

        if (class_depv[c][dir_tbid][auxc])
        {
          /* open the file */

          dtffptrv[c][dir_tbid][auxc] =
            TBCodeFileOpenRead(dtfnptrv[c][dir_tbid][auxc]);
          TBSetBigBuffer(dtffptrv[c][dir_tbid][auxc]);

          /* preload the first record; set EOF if none exists */

          if (fread(&dir_sr1v[dir_tbid][auxc], 1, sizeof(sr1T),
            dtffptrv[c][dir_tbid][auxc]) != sizeof(sr1T))
            dir_eofv[dir_tbid][auxc] = 1;
        };
      };
    };

    /* set the next directive target index default */

    dir_target = class_length;

    /* adjust the next directive target index based on file entries */

    for (dir_tbid = 0; dir_tbid < tbidL; dir_tbid++)
    {
      for (auxc = c_w; auxc <= c_b; auxc++)
      {
        if (class_depv[c][dir_tbid][auxc] && !dir_eofv[dir_tbid][auxc])
        {
          if (dir_sr1v[dir_tbid][auxc].sr1_index < dir_target)
            dir_target = dir_sr1v[dir_tbid][auxc].sr1_index;
        };
      };
    };

    /* scan the target input file */

    for (index = 0; index < class_length; index++)
    {
      /* read BEV of interest */

      input_bev = fgetc(target_fptrv[c]);

      /* set default output BEV */

      output_bev = input_bev;

      /* handle adjustment if target index match */

      if (index == dir_target)
      {
        /* set unknown BEV */

        output_bev = bev_unknown;

        /* search for improvements */

        for (dir_tbid = 0; dir_tbid < tbidL; dir_tbid++)
        {
          for (auxc = c_w; auxc <= c_b; auxc++)
          {
            if (class_depv[c][dir_tbid][auxc] && !dir_eofv[dir_tbid][auxc])
            {
              if (dir_sr1v[dir_tbid][auxc].sr1_index == index)
              {
                /* minimize the assigned BEV */

                if ((output_bev == bev_unknown) ||
                  (dir_sr1v[dir_tbid][auxc].sr1_bev < output_bev))
                {
                  output_bev = dir_sr1v[dir_tbid][auxc].sr1_bev;
                  TBAdjustHWM(c, output_bev);
                };

                /* advance the file because it had a matching index */

                if (fread(&dir_sr1v[dir_tbid][auxc], 1, sizeof(sr1T),
                  dtffptrv[c][dir_tbid][auxc]) != sizeof(sr1T))
                  dir_eofv[dir_tbid][auxc] = 1;
              };
            };
          };
        };

        /* fault check */

        if (output_bev == bev_unknown)
          TBFatal("Trouble located transition value directive");

        /* set the next directive target index default */

        dir_target = class_length;

        /* adjust the next directive target index based on file entries */

        for (dir_tbid = 0; dir_tbid < tbidL; dir_tbid++)
        {
          for (auxc = c_w; auxc <= c_b; auxc++)
          {
            if (class_depv[c][dir_tbid][auxc] && !dir_eofv[dir_tbid][auxc])
            {
              if (dir_sr1v[dir_tbid][auxc].sr1_index < dir_target)
                dir_target = dir_sr1v[dir_tbid][auxc].sr1_index;
            };
          };
        };
      };

      /* write the output BEV */

      fputc(output_bev, tffptr0);
    };

    /* close and delete the transition directive look-up set files */

    for (dir_tbid = 0; dir_tbid < tbidL; dir_tbid++)
    {
      for (auxc = c_w; auxc <= c_b; auxc++)
      {
        if (class_depv[c][dir_tbid][auxc])
        {
          TBCodeFileClose(dtffptrv[c][dir_tbid][auxc]);
          TBCodeFileRemove(dtfnptrv[c][dir_tbid][auxc]);
          TBStringFree(dtfnptrv[c][dir_tbid][auxc]);
        };
      };
    };

    /* close the temporary file */

    TBCodeFileClose(tffptr0);

    /* close the target file */

    TBCodeFileClose(target_fptrv[c]);

    /* rename the temporary file to the target file */

    TBCodeFileRename(tfnptr0, target_fnv[c]);

    /* release the temporary file name */

    TBStringFree(tfnptr0);
  };

  /* mark checkmates and stalemates */

  for (c = c_w; c <= c_b; c++)
  {
    /* report */

    printf("%s %s: Determining checkmates/stalemates\n",
      class_name, ctm_strv[c]);

    /* set inverse color */

    invc = inv_cv[c];

    /* set the active color for the move machinery */

    TBSetCurrentActive(c);

    /* open the target file */

    target_fptrv[c] = TBCodeFileOpenRead(target_fnv[c]);
    TBSetBiggerBuffer(target_fptrv[c]);

    /* open the temporary file */

    tfnptr0 = TBTempFileName();
    tffptr0 = TBCodeFileOpenWrite(tfnptr0);
    TBSetBiggerBuffer(tffptr0);

    /* scan */

    for (index = 0; index < class_length; index++)
    {
      /* read BEV of interest */

      input_bev = fgetc(target_fptrv[c]);

      /* set default output BEV */

      output_bev = input_bev;

      /* was the BEV an unknown? */

      if (input_bev == bev_unknown)
      {
        /* set default status */

        c_mate = s_mate = 0;

        /* set up position vector */

        TBSetPosVector(classptr, index, posv);

        /* set up position */

        TBSetBoard(TBGetEPSQ(classptr, c, index), posv);

        /* determine mate status */

        TBGenerate();
        tbmptr = tbgmbaseptrv[c];
        tbgmc = tbgmcv[c];

        mi = 0;
        at_least_one = 0;
        while (!at_least_one && (mi < tbgmc))
        {
          TBExecute(tbmptr);
          if (!TBKingInCheck(c))
            at_least_one = 1;
          TBRetract(tbmptr);
          tbmptr++;
          mi++;
        };

        /* was a mate detected? */

        if (!at_least_one)
          if (TBKingInCheck(c))
            c_mate = 1;
          else
            s_mate = 1;

        /* update if mate detected */

        if (c_mate || s_mate)
        {
          /* set output BEV accordingly */

          if (c_mate)
          {
            TBAdjustHWM(c, bev_li0);
            output_bev = bev_li0;
          }
          else
            output_bev = bev_draw;
        };
      };

      /* write the output BEV */

      fputc(output_bev, tffptr0);
    };

    /* close the temporary file */

    TBCodeFileClose(tffptr0);

    /* close the target file */

    TBCodeFileClose(target_fptrv[c]);

    /* rename the temporary file to the target file */

    TBCodeFileRename(tfnptr0, target_fnv[c]);

    /* release the temporary file name */

    TBStringFree(tfnptr0);
  };

  /* announce high water marks */

  for (c = c_w; c <= c_b; c++)
  {
    printf("%s %s: Maximum mating distance after transitions: %hd\n",
      class_name, ctm_strv[c], maxmatev[c]);
    printf("%s %s: Maximum losing distance after transitions: %hd\n",
      class_name, ctm_strv[c], maxlosev[c]);
  };

  /* set the initial distance to mate/lose indicator */

  distance = 1;

  /* perform iteration sequence */

  printf("%s: Iteration sequence start\n", class_name);

  /* loop based on high water marks */

  while ((distance <= tbbe_ssL) &&
    (((maxlosev[c_b] + 1) >= distance) || ((maxlosev[c_w] + 1) >= distance) ||
    (maxmatev[c_b] >= distance) || (maxmatev[c_w] >= distance)))
  {
    /* report */

    printf("%s: Starting major iteration %hd\n", class_name, distance);

    /* set assignment BEVs */

    assign_mate_bev = bev_mi1 + 1 - distance;
    assign_lose_bev = bev_li0 - 0 + distance;

    /* set match BEVs */

    match_mate_bev = bev_mi1 + 1 - distance;
    match_lose_bev = bev_li0 - 1 + distance;

    /* process mate phase color loop */

    for (c = c_w; c <= c_b; c++)
    {
      /* set inverse color */

      invc = inv_cv[c];

      /* set the active color for the move machinery */

      TBSetCurrentActive(invc);

      /* test for current color */

      if ((maxlosev[invc] + 1) >= distance)
      {
        /* report */

        printf("%s %s: Searching for mate in %hd positions\n",
          class_name, ctm_strv[c], distance);

        /* open target file for input */

        target_fptrv[invc] = TBCodeFileOpenRead(target_fnv[invc]);
        TBSetBiggerBuffer(target_fptrv[invc]);

        /* start up the index merge operations */

        TBIndexMergeStart(class_length);

        /* clear the lose detection count */

        lose_count = 0;

        /* scan target file for matching BEV */

        for (index = 0; index < class_length; index++)
        {
          /* read BEV of interest */

          input_bev = fgetc(target_fptrv[invc]);

          /* continue if matching lose */

          if (input_bev == match_lose_bev)
          {
            /* increment the matching lose count */

            lose_count++;

            /* set up position vector */

            TBSetPosVector(classptr, index, posv);

            /* set up position */

            TBSetBoard(TBGetEPSQ(classptr, invc, index), posv);

            /* perform retrogeneration */

            TBRetrogen();
            tbrmptr = tbrgmbaseptrv[c];
            tbrgmc = tbrgmcv[c];

            /* run through retro move list */

            for (rmi = 0; rmi < tbrgmc; rmi++)
            {
              /* retract the move */

              TBRetract(tbrmptr);

              /* process according to legality */

              if (!TBKingInCheck(invc))
              {
                /* generate/output the index for the candidate position */

                retro_index = TBPositionIndex();
                TBIndexMergeInsert(retro_index);

                /* does the position have a dual? */

                if (TBHasDual())
                {
                  /* generate the index for the candidate position dual */

                  retro_dual_index = TBPositionIndexDual();

                  /* output the index of the candidate position dual */

                  if (retro_index != retro_dual_index)
                    TBIndexMergeInsert(retro_dual_index);
                };
              };

              /* execute the move */

              TBExecute(tbrmptr);

              /* next retro move */

              tbrmptr++;
            };
          };
        };

        /* close target file */

        TBCodeFileClose(target_fptrv[invc]);

        /* construct sorted candidate index file from candidate index file */

        tfnptr2 = TBTempFileName();
        TBIndexMergeFinish(tfnptr2);

        /* conditionally apply mating values to target */

        if (lose_count > 0)
          TBApplyMate(c, class_length, assign_mate_bev, tfnptr2, target_fnv[c]);
        else
          TBCodeFileRemove(tfnptr2);

        /* delete temporary mating file name */

        TBStringFree(tfnptr2);
      };
    };

    /* process lose phase color loop */

    for (c = c_w; c <= c_b; c++)
    {
      /* set inverse color */

      invc = inv_cv[c];

      /* test for current color */

      if (maxmatev[invc] >= distance)
      {
        /* report */

        printf("%s %s: Searching for lose in %hd positions\n",
          class_name, ctm_strv[c], distance);

        /* set the active color for the move machinery */

        TBSetCurrentActive(invc);

        /* set up the verified candidate index file */

        tfnptr0 = TBTempFileName();
        tffptr0 = TBCodeFileOpenWrite(tfnptr0);
        TBSetBigBuffer(tffptr0);

        /* open the other color target file for mate-in-n scan */

        target_fptrv[invc] = TBCodeFileOpenRead(target_fnv[invc]);
        TBSetBiggerBuffer(target_fptrv[invc]);

        /* start up the index merge operations */

        TBIndexMergeStart(class_length);

        /* generate the initial candidate index file */

        for (index = 0; index < class_length; index++)
        {
          input_bev = fgetc(target_fptrv[invc]);
          if (input_bev == match_mate_bev)
          {
            /* set up position vector */

            TBSetPosVector(classptr, index, posv);

            /* set up position */

            TBSetBoard(TBGetEPSQ(classptr, invc, index), posv);

            /* perform retrogeneration */

            TBRetrogen();
            tbrmptr = tbrgmbaseptrv[c];
            tbrgmc = tbrgmcv[c];

            /* loop through retro moves to get candidate indices */

            for (rmi = 0; rmi < tbrgmc; rmi++)
            {
              /* retract the move */

              TBRetract(tbrmptr);

              /* a legal retroposition? */

              if (!TBKingInCheck(invc))
              {
                /* generate and output the candidate index */

                retro_index = TBPositionIndex();
                TBIndexMergeInsert(retro_index);

                /* handle dual */

                if (TBHasDual())
                {
                  retro_dual_index = TBPositionIndexDual();
                  if (retro_index != retro_dual_index)
                    TBIndexMergeInsert(retro_dual_index);
                };
              };

              /* execute the move */

              TBExecute(tbrmptr);

              /* next retro move */

              tbrmptr++;
            };
          };
        };

        /* close the other color target file */

        TBCodeFileClose(target_fptrv[invc]);

        /* create the sorted candidate index file name */

        tfnptr2 = TBTempFileName();

        /* sort the candidate index file and set the initial candidate count */

        candidate_count = TBIndexMergeFinish(tfnptr2);

        /* iterate on escape move generation ordinal */

        ordinal = 0;
        mate_count = 0;
        while (candidate_count > 0)
        {
          /* set the move machinery for the active color */

          TBSetCurrentActive(c);

          /* open the candidate index file for reading */

          tffptr2 = TBCodeFileOpenRead(tfnptr2);
          TBSetBigBuffer(tffptr2);

          /* open the retro/prograde pair file for writing */

          tfnptr1 = TBTempFileName();
          tffptr1 = TBCodeFileOpenWrite(tfnptr1);
          TBSetBigBuffer(tffptr1);

          /* scan through the candidate index file to produce the retro pair file */

          while (fread(&sr2, 1, sizeof(sr2T), tffptr2) == sizeof(sr2T))
          {
            /* assign the index */

            index = sr2.sr2_index;

            /* set up position vector */

            TBSetPosVector(classptr, index, posv);

            /* set up position */

            TBSetBoard(TBGetEPSQ(classptr, c, index), posv);

            /* perform generation */

            TBGenerate();

            /* does the Nth escape move exist? */

            if (tbgmcv[c] > ordinal)
            {
              /* a possible escape move exists */

              TBExecute(tbgmbaseptrv[c] + ordinal);

              sr3.sr3_index0 = index;
              sr3.sr3_index1 = TBPositionIndex();

              if (fwrite(&sr3, 1, sizeof(sr3T), tffptr1) != sizeof(sr3T))
                TBFatal("TBMake: Can't write to retro pair file");

              TBRetract(tbgmbaseptrv[c] + ordinal);
            }
            else
            {
              /* no escape, the candidate is now verified */

              if (fwrite(&sr2, 1, sizeof(sr2T), tffptr0) != sizeof(sr2T))
                TBFatal("TBMake: Can't write to verified candidate file");
              TBAdjustHWM(c, assign_lose_bev);
              mate_count++;
            };
          };

          /* close and delete the candidate index file */

          TBCodeFileClose(tffptr2);
          TBCodeFileRemove(tfnptr2);
          TBStringFree(tfnptr2);

          /* close the retro pair file */

          TBCodeFileClose(tffptr1);

          /* sort the retro pair file on prograde index */

          tfnptr2 = TBTempFileName();
          TBSortFile(tfnptr1, tfnptr2, sizeof(sr3T), 0, (void *)TBCompSR3);
          TBStringFree(tfnptr1);

          /* open and prime the sorted retro pair file for reading */

          tffptr2 = TBCodeFileOpenRead(tfnptr2);
          TBSetBigBuffer(tffptr2);
          if (fread(&sr3, 1, sizeof(sr3T), tffptr2) != sizeof(sr3T))
            sr3.sr3_index1 = -1;

          /* open the updated candidate index file for writing */

          tfnptr1 = TBTempFileName();
          tffptr1 = TBCodeFileOpenWrite(tfnptr1);
          TBSetBigBuffer(tffptr1);

          /* open the other color BEV file */

          target_fptrv[invc] = TBCodeFileOpenRead(target_fnv[invc]);
          TBSetBigBuffer(target_fptrv[invc]);

          /* scan the retro pair file to re-create the candidate index file */

          candidate_count = 0;
          for (index = 0; index < class_length; index++)
          {
            input_bev = fgetc(target_fptrv[invc]);

            while (index == sr3.sr3_index1)
            {
              /* look for an escape move */

              if ((input_bev == bev_broken) ||
                (input_bev >= match_mate_bev))
              {
                /* no escape yet */

                sr2.sr2_index = sr3.sr3_index0;
                if (fwrite(&sr2, 1, sizeof(sr2T), tffptr1) != sizeof(sr2T))
                  TBFatal("TBMake: Can't write to candidate file");

                /* increment next iteration candidate count */

                candidate_count++;
              };

              /* reload from the retro pair file */

              if (fread(&sr3, 1, sizeof(sr3T), tffptr2) != sizeof(sr3T))
                sr3.sr3_index1 = -1;
            };
          };

          /* close the other color BEV file */

          TBCodeFileClose(target_fptrv[invc]);

          /* close and delete the retro pair file */

          TBCodeFileClose(tffptr2);
          TBCodeFileRemove(tfnptr2);
          TBStringFree(tfnptr2);

          /* close the updated candidate file */

          TBCodeFileClose(tffptr1);

          /* set the name of the candidate file for the next iteration */

          tfnptr2 = tfnptr1;

          /* next escape move ordinal */

          ordinal++;
        };

        /* remove the updated candidate index file (it should be empty) */

        TBCodeFileRemove(tfnptr2);
        TBStringFree(tfnptr2);

        /* close the completed verified candidate index file */

        TBCodeFileClose(tffptr0);

        /* sort the completed verified candidate index file */

        tfnptr1 = TBTempFileName();
        TBSortFile(tfnptr0, tfnptr1, sizeof(sr2T), 0, (void *)TBCompSR2);
        TBStringFree(tfnptr0);

        /* apply the verified candidate index file to the target BEV file */

        tfnptr2 = TBTempFileName();
        tffptr2 = TBCodeFileOpenWrite(tfnptr2);
        TBSetBiggerBuffer(tffptr2);

        tffptr1 = TBCodeFileOpenRead(tfnptr1);
        TBSetBigBuffer(tffptr1);
        if (fread(&sr2, 1, sizeof(sr2T), tffptr1) != sizeof(sr2T))
          sr2.sr2_index = -1;

        target_fptrv[c] = TBCodeFileOpenRead(target_fnv[c]);
        TBSetBiggerBuffer(target_fptrv[c]);

        /* scan and update */

        for (index = 0; index < class_length; index++)
        {
          input_bev = fgetc(target_fptrv[c]);
          output_bev = input_bev;

          while (index == sr2.sr2_index)
          {
            assert(input_bev == bev_unknown);
            output_bev = assign_lose_bev;
            if (fread(&sr2, 1, sizeof(sr2T), tffptr1) != sizeof(sr2T))
              sr2.sr2_index = -1;
          };

          fputc(output_bev, tffptr2);
        };

        /* close the temporary target file */

        TBCodeFileClose(tffptr2);

        /* close the old target file */

        TBCodeFileClose(target_fptrv[c]);

        /* close down the sorted verified candidate index file */

        TBCodeFileClose(tffptr1);
        TBCodeFileRemove(tfnptr1);
        TBStringFree(tfnptr1);

        /* rename to the new target file */

        TBCodeFileRename(tfnptr2, target_fnv[c]);
        TBStringFree(tfnptr2);
      };
    };

    /* next major iteration */

    distance++;
  };

  printf("%s: Iteration sequence end\n", class_name);

  /* mark unknowns as draws */

  for (c = c_w; c <= c_b; c++)
  {
    /* report */

    printf("%s %s: Changing unknowns to draws\n", class_name, ctm_strv[c]);

    /* open the target file */

    target_fptrv[c] = TBCodeFileOpenRead(target_fnv[c]);
    TBSetBiggerBuffer(target_fptrv[c]);

    /* open the temporary file */

    tfnptr0 = TBTempFileName();
    tffptr0 = TBCodeFileOpenWrite(tfnptr0);
    TBSetBiggerBuffer(tffptr0);

    /* scan */

    for (index = 0; index < class_length; index++)
    {
      /* read BEV of interest */

      input_bev = fgetc(target_fptrv[c]);

      /* was the BEV an unknown? */

      if (input_bev == bev_unknown)
        output_bev = bev_draw;
      else
        output_bev = input_bev;

      /* write output BEV */

      fputc(output_bev, tffptr0);
    };

    /* close the temporary file */

    TBCodeFileClose(tffptr0);

    /* close the target file */

    TBCodeFileClose(target_fptrv[c]);

    /* rename the temporary file to the target file */

    TBCodeFileRename(tfnptr0, target_fnv[c]);

    /* release the temporary file name */

    TBStringFree(tfnptr0);
  };

  /* deallocate target file names */

  for (c = c_w; c <= c_b; c++)
    TBStringFree(target_fnv[c]);
}
