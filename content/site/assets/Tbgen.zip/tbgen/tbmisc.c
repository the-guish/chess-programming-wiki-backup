/* >>> tbmisc.c: miscellaneous routines for tablebase generator */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tbdefs.h"
#include "tbvars.h"

#include "tbfile.h"
#include "tbmisc.h"
#include "tbutil.h"

/*--> TBPrintPosition: print a position */
void TBPrintPosition(tbptrT classptr, posvT posv)
{
  cT c;
  siT i;
  siT count, limit;

  count = 0;
  limit = classptr->tb_count;
  for (c = c_w; c <= c_b; c++)
  {
    for (i = 0; i < classptr->tb_mcv[c]; i++)
    {
      printf("%c", asccv[c]);
      printf("%c", ascpv[classptr->tb_pv[c][i]]);
      printf("%c", ascfv[map_file(posv[c][i])]);
      printf("%c", ascrv[map_rank(posv[c][i])]);
      count++;
      if (count != limit)
        printf(" ");
    };
  };
}

/*--> TBGetSignature: get the signature for a distribution */
liT TBGetSignature(distvT distv)
{
  liT sig;
  cT c;
  pT p;

  sig = 0;
  for (c = c_w; c <= c_b; c++)
    for (p = p_p; p <= p_q; p++)
      sig = (sig << 3) | distv[c][p];

  return sig;
}

/*--> TBGetInvertedSignature: get the inverted signature for a distribution */
liT TBGetInvertedSignature(distvT distv)
{
  liT sig;
  cT c;
  pT p;

  sig = 0;
  for (c = c_w; c <= c_b; c++)
    for (p = p_p; p <= p_q; p++)
      sig = (sig << 3) | distv[inv_cv[c]][p];

  return sig;
}

/*--> TBLocateClass: locate a class for a piece distribution */
tbidT TBLocateClass(distvT distv, siptrT invertptr)
{
  tbidT tbid;
  siT flag;
  tbptrT classptr;
  liT sig;

  /* set "not found" */

  flag = 0;

  /* get the piece distribution signature */

  sig = TBGetSignature(distv);

  /* search for signature match */

  classptr = tbbaseptr;
  tbid = 0;
  while (!flag && (tbid < tbidL))
  if (sig == classptr->tb_sig0)
  {
    flag = 1;
    *invertptr = 0;
  }
  else
  {
    if (sig == classptr->tb_sig1)
    {
      flag = 1;
      *invertptr = 1;
    }
    else
    {
      classptr++;
      tbid++;
    };
  };

  /* if not found, set return to nil */

  if (!flag)
    tbid = tbid_nil;

  return tbid;
}

/*--> TBClassFromString: determine class ID from name */
tbidT
TBClassFromString(charptrT s)
{
  tbidT tbid;
  siT flag;

  flag = 0;
  tbid = 0;

  while (!flag && (tbid < tbidL))
  {
    if (strcmp(s, (tbbaseptr + tbid)->tb_name) == 0)
      flag = 1;
    else
      tbid++;
  };

  if (!flag)
    tbid = tbid_nil;

  return tbid;
}

/*--> TBCopyDistribution: copy a distribution vector */
void TBCopyDistribution(distvT distv0, distvT distv1)
{
  cT c;
  pT p;

  for (c = c_w; c <= c_b; c++)
    for (p = p_p; p <= p_k; p++)
      distv1[c][p] = distv0[c][p];
}

/*--> TBCopyPosition: copy a position vector */
void TBCopyPosition(posvT posv0, posvT posv1)
{
  cT c;
  siT i;

  for (c = c_w; c <= c_b; c++)
    for (i = 0; i < tbmecL; i++)
      posv1[c][i] = posv0[c][i];
}

/*--> TBDumpDependencyVector: diagnostic output for a dependency vector */
void TBDumpDependencyVector(fptrT fptr, depvT depv, siT indent)
{
  tbidT tbid;
  cT c;
  siT i;
  tbptrT classptr;

  classptr = tbbaseptr;
  for (tbid = 0; tbid < tbidL; tbid++)
  {
    for (c = c_w; c <= c_b; c++)
    {
      if (depv[tbid][c])
      {
        for (i = 0; i < indent; i++)
          fputc(' ', fptr);
        fprintf(fptr, "%s %s\n", classptr->tb_name, ctm_strv[c]);
      };
    };
    classptr++;
  };
}

/*--> TBSetDependencyVector: set the dependency vector for a class and color */
void TBSetDependencyVector(tbptrT classptr, cT c, depvT depv)
{
  tbidT rtbid;
  siT invert;
  cT rc, invc;
  pT p, pp;
  distvT distv0, distv1;

  /* clear the result vector */

  for (rtbid = 0; rtbid < tbidL; rtbid++)
    for (rc = c_w; rc <= c_b; rc++)
      depv[rtbid][rc] = 0;

  /* set the basic distribution */

  for (rc = c_w; rc <= c_b; rc++)
    for (p = p_p; p <= p_k; p++)
      distv0[rc][p] = classptr->tb_distv[rc][p];

  /* set the passive color */

  invc = inv_cv[c];

  /* add simple captures by the passive color */

  if (classptr->tb_mcv[c] > 1)
  {
    /* active men exist to be captured */

    for (p = p_p; p < p_k; p++)
    {
      if (distv0[c][p] > 0)
      {
        TBCopyDistribution(distv0, distv1);
        distv1[c][p]--;
        rtbid = TBLocateClass(distv1, &invert);
        if (!invert)
          depv[rtbid][c] = 1;
        else
          depv[rtbid][invc] = 1;
      };
    };
  };

  /* add simple promotions by the passive color */

  if (classptr->tb_distv[invc][p_p] > 0)
  {
    /* passive pawns exist to be promoted */

    for (pp = p_n; pp <= p_q; pp++)
    {
      TBCopyDistribution(distv0, distv1);
      distv1[invc][p_p]--;
      distv1[invc][pp]++;
      rtbid = TBLocateClass(distv1, &invert);
      if (!invert)
        depv[rtbid][c] = 1;
      else
        depv[rtbid][invc] = 1;
    };
  };

  /* add capturing promotions by the passive color */

  if ((classptr->tb_mcv[c] > 1) && (classptr->tb_distv[invc][p_p] > 0))
  {
    /* passive pawns exist to be promoted with capture */

    for (p = p_p; p < p_k; p++)
    {
      if (distv0[c][p] > 0)
      {
        for (pp = p_n; pp <= p_q; pp++)
        {
          TBCopyDistribution(distv0, distv1);
          distv1[c][p]--;
          distv1[invc][p_p]--;
          distv1[invc][pp]++;
          rtbid = TBLocateClass(distv1, &invert);
          if (!invert)
            depv[rtbid][c] = 1;
          else
            depv[rtbid][invc] = 1;
        };
      };
    };
  };
}

/*--> TBPrintDependencies: print dependencies for a class and color */
void TBPrintDependencies(fptrT fptr, tbptrT classptr, cT c, siT indent)
{
  depvT depv;

  TBSetDependencyVector(classptr, c, depv);
  TBDumpDependencyVector(fptr, depv, indent);
}

/*--> TBPrintDependencyFile: print all dependencies to a file */
void TBPrintDependencyFile(charptrT fn)
{
  tbidT tbid;
  cT c;
  fptrT fptr;
  tbptrT classptr;

  fptr = TBTextFileOpenWrite(fn);

  classptr = tbbaseptr;
  for (tbid = 0; tbid < tbidL; tbid++)
  {
    for (c = c_w; c <= c_b; c++)
    {
      fprintf(fptr, "%s %s\n", classptr->tb_name, ctm_strv[c]);
      TBPrintDependencies(fptr, classptr, c, 1);
    };
    classptr++;
  };

  TBTextFileClose(fptr);
}

/*--> TBPrintRecursiveDependencies: does what it says */
void TBPrintRecursiveDependencies(fptrT fptr, tbptrT classptr, cT c, siT indent)
{
  siT i;
  depvT depv;
  tbidT rtbid;
  cT rc;
  tbptrT auxclass_ptr;

  /* print the class name */

  for (i = 0; i < indent; i++)
    fputc(' ', fptr);
  fprintf(fptr, "%s %s\n", classptr->tb_name, ctm_strv[c]);

  /* print dependencies */

  TBSetDependencyVector(classptr, c, depv);
  auxclass_ptr = tbbaseptr;
  for (rtbid = 0; rtbid < tbidL; rtbid++)
  {
    for (rc = c_w; rc <= c_b; rc++)
      if (depv[rtbid][rc])
        TBPrintRecursiveDependencies(fptr, auxclass_ptr, rc, (indent + 1));
    auxclass_ptr++;
  };
}

/*--> TBPrintRecursiveDependencyFile: print all dependencies recursively to a file */
void TBPrintRecursiveDependencyFile(charptrT fn)
{
  tbidT tbid;
  cT c;
  fptrT fptr;
  tbptrT classptr;

  fptr = TBTextFileOpenWrite(fn);

  classptr = tbbaseptr;
  for (tbid = 0; tbid < tbidL; tbid++)
  {
    for (c = c_w; c <= c_b; c++)
      TBPrintRecursiveDependencies(fptr, classptr, c, 0);
    classptr++;
  };

  TBTextFileClose(fptr);
}

/*--> TBCountDependencies: return the entry count in a dependency vector */
siT TBCountDependencies(depvT depv)
{
  siT count;
  tbidT tbid;
  cT c;

  count = 0;
  for (tbid = 0; tbid < tbidL; tbid++)
    for (c = c_w; c <= c_b; c++)
      if (depv[tbid][c])
        count++;

  return count;
}

/*--> TBPrintGenerationList: print generation list */
void TBPrintGenerationList(charptrT fn)
{
  fptrT fptr;
  tbidT tbid, rtbid;
  cT c;
  tbptrT classptr;
  siT okay, change;
  siT count;
  siT donev[tbidL];
  depvT depcv[rcL];
  siT scv[tbidL];

  fptr = TBTextFileOpenWrite(fn);

  /* clear the generation vector and the completion count */

  for (tbid = 0; tbid < tbidL; tbid++)
    donev[tbid] = 0;

  /* output the class names in generation order for each man count */

  for (count = 2; count <= 5; count++)
  {
    change = 1;
    while (change)
    {
      change = 0;
      classptr = tbbaseptr;
      for (tbid = 0; tbid < tbidL; tbid++)
      {
        if ((classptr->tb_count == count) && !donev[tbid])
        {
          /* generate the dependency lists for this class */

          for (c = c_w; c <= c_b; c++)
            TBSetDependencyVector(classptr, c, depcv[c]);

          /* merge the dependency lists */

          for (rtbid = 0; rtbid < tbidL; rtbid++)
          {
            scv[rtbid] = 0;
            for (c = c_w; c <= c_b; c++)
              if (depcv[c][rtbid][c_w] || depcv[c][rtbid][c_b])
                scv[rtbid] = 1;
          };

          /* are there any ungenerated dependencies? */

          okay = 1;
          rtbid = 0;
          while (okay && (rtbid < tbidL))
            if (scv[rtbid] && !donev[rtbid])
              okay = 0;
            else
              rtbid++;

          /* output to list if there are no ungenerated dependencies */

          if (okay)
          {
            donev[tbid] = 1;
            change = 1;
            fprintf(fptr, "%s\n", classptr->tb_name);
          };
        };

        /* next class */

        classptr++;
      };
    };
  };

  TBTextFileClose(fptr);
}

/*--> TBSetPosVector: set up position vectors from an index */
void TBSetPosVector(tbptrT classptr, indexT index, posvT posv)
{
  indexT remainder;
  siT scale;
  cT c;
  siT i;

  remainder = index;

  for (c = c_w; c <= c_b; c++)
  {
    for (i = 0; i < classptr->tb_mcv[c]; i++)
    {
      /* get scale factor */

      scale = classptr->tb_scalev[c][i];

      /* set basic square and adjust remainder */

      switch (scale)
      {
      case ff_flankL:
        posv[c][i] = flank_unmapv[remainder % ff_flankL];
        remainder /= ff_flankL;
        break;
      case ff_triangleL:
        posv[c][i] = triangle_unmapv[remainder % ff_triangleL];
        remainder /= ff_triangleL;
        break;
      case sqL:
        posv[c][i] = remainder % sqL;
        remainder /= sqL;
        break;
      default:
        TBSwitchFault("TBSetPosVector");
        break;
      };

      /* apply en passant kludge */

      if (classptr->tb_pv[c][i] == p_p)
      {
        if (c == c_w)
        {
          if (map_rank(posv[c_w][i]) == rank_1)
            posv[c][i] += (fileL * 3);
        }
        else
        {
          if (map_rank(posv[c_b][i]) == rank_8)
            posv[c][i] -= (fileL * 3);
        };
      };
    };
  };
}

/*--> TBSetPosVectorNK: set up position vectors from an index (no en passant kludge) */
void TBSetPosVectorNK(tbptrT classptr, indexT index, posvT posv)
{
  indexT remainder;
  siT scale;
  cT c;
  siT i;

  remainder = index;

  for (c = c_w; c <= c_b; c++)
  {
    for (i = 0; i < classptr->tb_mcv[c]; i++)
    {
      /* get scale factor */

      scale = classptr->tb_scalev[c][i];

      /* set basic square and adjust remainder */

      switch (scale)
      {
      case ff_flankL:
        posv[c][i] = flank_unmapv[remainder % ff_flankL];
        remainder /= ff_flankL;
        break;
      case ff_triangleL:
        posv[c][i] = triangle_unmapv[remainder % ff_triangleL];
        remainder /= ff_triangleL;
        break;
      case sqL:
        posv[c][i] = remainder % sqL;
        remainder /= sqL;
        break;
      default:
        TBSwitchFault("TBSetPosVectorNK");
        break;
      };
    };
  };
}

/*--> TBGetEPSQ: get en passant target square from index */
sqT TBGetEPSQ(tbptrT classptr, cT c, indexT index)
{
  sqT sq;
  siT i;
  posvT posv;

  /* set default return value */

  sq = sq_nil;

  /* check for at least one pawn */

  if (classptr->tb_flags & tbf_has_pawns)
    if (c == c_w)
    {
      if (classptr->tb_flags & tbf_has_black_pawn)
        {
        TBSetPosVectorNK(classptr, index, posv);
        i = 1;
        while ((sq == sq_nil) && (i < classptr->tb_mcv[c_b]))
        {
          if (classptr->tb_pv[c_b][i] == p_p)
            if (map_rank(posv[c_b][i]) == rank_8)
              sq = posv[c_b][i] - (fileL * 2);
          i++;
        };
      };
    }
    else
    {
      if (classptr->tb_flags & tbf_has_white_pawn)
      {
        TBSetPosVectorNK(classptr, index, posv);
        i = 1;
        while ((sq == sq_nil) && (i < classptr->tb_mcv[c_w]))
        {
          if (classptr->tb_pv[c_w][i] == p_p)
            if (map_rank(posv[c_w][i]) == rank_1)
              sq = posv[c_w][i] + (fileL * 2);
          i++;
        };
      };
    };

  return sq;
}

/*--> TBOccupied: check if a square is occupied */
siT TBOccupied(sqT sq, tbptrT classptr, posvT posv)
{
  siT flag;
  cT c;
  siT i;

  /* set default return value */

  flag = 0;

  c = c_w;
  while (!flag && (c <= c_b))
  {
    i = 0;
    while (!flag && (i < classptr->tb_mcv[c]))
    {
      if (sq == posv[c][i])
        flag = 1;
      i++;
    };
    c++;
  };

  return flag;
}
