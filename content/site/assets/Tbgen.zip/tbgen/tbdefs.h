/* >>> tbdefs.h: common definitions for tablebase generator */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

/* useful types */

typedef void *voidptrT;
typedef unsigned char byteT, *byteptrT;
typedef char *charptrT;
typedef signed char tiT, *tiptrT;
typedef short int siT, *siptrT;
typedef long int liT, *liptrT;
typedef float srT, *srptrT;
typedef double lrT, *lrptrT;
typedef FILE *fptrT;

/* text I/O buffer length */

#define tL 256

/* big buffer length */

#define rlbL (1 << 20)

/* a bit */

#define bit 0x01

/* bit positions */

#define bit_00 (bit <<  0)
#define bit_01 (bit <<  1)
#define bit_02 (bit <<  2)
#define bit_03 (bit <<  3)
#define bit_04 (bit <<  4)
#define bit_05 (bit <<  5)
#define bit_06 (bit <<  6)
#define bit_07 (bit <<  7)
#define bit_08 (bit <<  8)
#define bit_09 (bit <<  9)
#define bit_10 (bit << 10)
#define bit_11 (bit << 11)
#define bit_12 (bit << 12)
#define bit_13 (bit << 13)
#define bit_14 (bit << 14)
#define bit_15 (bit << 15)

/* bit widths */

#define byteW 8

/* ASCII character constants */

#define ascii_nul ((char) 0x00)
#define ascii_soh ((char) 0x01)
#define ascii_stx ((char) 0x02)
#define ascii_etx ((char) 0x03)
#define ascii_eot ((char) 0x04)
#define ascii_enq ((char) 0x05)
#define ascii_ack ((char) 0x06)
#define ascii_bel ((char) 0x07)
#define ascii_bs  ((char) 0x08)
#define ascii_ht  ((char) 0x09)
#define ascii_lf  ((char) 0x0a)
#define ascii_vt  ((char) 0x0b)
#define ascii_ff  ((char) 0x0c)
#define ascii_cr  ((char) 0x0d)
#define ascii_so  ((char) 0x0e)
#define ascii_si  ((char) 0x0f)
#define ascii_dle ((char) 0x10)
#define ascii_dc1 ((char) 0x11)
#define ascii_dc2 ((char) 0x12)
#define ascii_dc3 ((char) 0x13)
#define ascii_dc4 ((char) 0x14)
#define ascii_nak ((char) 0x15)
#define ascii_syn ((char) 0x16)
#define ascii_etb ((char) 0x17)
#define ascii_can ((char) 0x18)
#define ascii_em  ((char) 0x19)
#define ascii_sub ((char) 0x1a)
#define ascii_esc ((char) 0x1b)
#define ascii_fs  ((char) 0x1c)
#define ascii_gs  ((char) 0x1d)
#define ascii_rs  ((char) 0x1e)
#define ascii_us  ((char) 0x1f)
#define ascii_sp  ((char) 0x20)
#define ascii_del ((char) 0x7f)

/* character case mapping */

#define map_lower(ch) (isupper((ch)) ? tolower((ch)) : (ch))
#define map_upper(ch) (islower((ch)) ? toupper((ch)) : (ch))

/* pointer to comparison function returning an int */

typedef int (*cfiptrT)(voidptrT ptr0, voidptrT ptr1);

/* colors (ordering is critical) */

typedef siT cT, *cptrT;
#define cQ 2
#define cL (bit << cQ)
#define rcQ 1
#define rcL (bit << rcQ)
#define c_nil (-1)

#define c_w 0 /* white */
#define c_b 1 /* black */
#define c_v 2 /* vacant */
#define c_x 3 /* extra */

/* pieces (ordering is critical) */

typedef siT pT, *pptrT;
#define pL 8
#define rpL 6
#define p_nil (-1)

#define p_p 0 /* pawn */
#define p_n 1 /* knight */
#define p_b 2 /* bishop */
#define p_r 3 /* rook */
#define p_q 4 /* queen */
#define p_k 5 /* king */
#define p_v 6 /* vacant */
#define p_x 7 /* extra */

/* color piece combinations (ordering is critical) */

typedef siT cpT;
#define cpL (rcL * pL)
#define rcpL (rcL * rpL)
#define cp_nil (-1)

#define cp_wp  0 /* white pawn */
#define cp_wn  1 /* white knight */
#define cp_wb  2 /* white bishop */
#define cp_wr  3 /* white rook */
#define cp_wq  4 /* white queen */
#define cp_wk  5 /* white king */
#define cp_bp  6 /* black pawn */
#define cp_bn  7 /* black knight */
#define cp_bb  8 /* black bishop */
#define cp_br  9 /* black rook */
#define cp_bq 10 /* black queen */
#define cp_bk 11 /* black king */
#define cp_v0 12 /* vacant */
#define cp_x0 13 /* extra 0 */
#define cp_x1 14 /* extra 1 */
#define cp_x2 15 /* extra 2 */

/* ranks */

typedef siT rankT;
#define rankM (0x0007)
#define rankQ 3
#define rankL (bit << rankQ)
#define rank_nil (-1)

#define rank_1 0
#define rank_2 1
#define rank_3 2
#define rank_4 3
#define rank_5 4
#define rank_6 5
#define rank_7 6
#define rank_8 7

/* files */

typedef siT fileT;
#define fileM (0x0007)
#define fileQ 3
#define fileL (bit << fileQ)
#define file_nil (-1)

#define file_a 0 /* QR */
#define file_b 1 /* QN */
#define file_c 2 /* QB */
#define file_d 3 /* Q */
#define file_e 4 /* K */
#define file_f 5 /* KB */
#define file_g 6 /* KN */
#define file_h 7 /* KR */

/* location mappings */

#define map_sq(r, f) (((r) << fileQ | (f)))
#define map_file(sq) ((sq) & 0x07)
#define map_rank(sq) ((sq) >> fileQ)

/* squares */

typedef siT sqT, *sqptrT;
#define sqM (0x003f)
#define sqQ (rankQ + fileQ)
#define sqL (bit << sqQ)
#define sq_nil (-1)

#define sq_a1 map_sq(rank_1, file_a)
#define sq_b1 map_sq(rank_1, file_b)
#define sq_c1 map_sq(rank_1, file_c)
#define sq_d1 map_sq(rank_1, file_d)
#define sq_e1 map_sq(rank_1, file_e)
#define sq_f1 map_sq(rank_1, file_f)
#define sq_g1 map_sq(rank_1, file_g)
#define sq_h1 map_sq(rank_1, file_h)
#define sq_a2 map_sq(rank_2, file_a)
#define sq_b2 map_sq(rank_2, file_b)
#define sq_c2 map_sq(rank_2, file_c)
#define sq_d2 map_sq(rank_2, file_d)
#define sq_e2 map_sq(rank_2, file_e)
#define sq_f2 map_sq(rank_2, file_f)
#define sq_g2 map_sq(rank_2, file_g)
#define sq_h2 map_sq(rank_2, file_h)
#define sq_a3 map_sq(rank_3, file_a)
#define sq_b3 map_sq(rank_3, file_b)
#define sq_c3 map_sq(rank_3, file_c)
#define sq_d3 map_sq(rank_3, file_d)
#define sq_e3 map_sq(rank_3, file_e)
#define sq_f3 map_sq(rank_3, file_f)
#define sq_g3 map_sq(rank_3, file_g)
#define sq_h3 map_sq(rank_3, file_h)
#define sq_a4 map_sq(rank_4, file_a)
#define sq_b4 map_sq(rank_4, file_b)
#define sq_c4 map_sq(rank_4, file_c)
#define sq_d4 map_sq(rank_4, file_d)
#define sq_e4 map_sq(rank_4, file_e)
#define sq_f4 map_sq(rank_4, file_f)
#define sq_g4 map_sq(rank_4, file_g)
#define sq_h4 map_sq(rank_4, file_h)
#define sq_a5 map_sq(rank_5, file_a)
#define sq_b5 map_sq(rank_5, file_b)
#define sq_c5 map_sq(rank_5, file_c)
#define sq_d5 map_sq(rank_5, file_d)
#define sq_e5 map_sq(rank_5, file_e)
#define sq_f5 map_sq(rank_5, file_f)
#define sq_g5 map_sq(rank_5, file_g)
#define sq_h5 map_sq(rank_5, file_h)
#define sq_a6 map_sq(rank_6, file_a)
#define sq_b6 map_sq(rank_6, file_b)
#define sq_c6 map_sq(rank_6, file_c)
#define sq_d6 map_sq(rank_6, file_d)
#define sq_e6 map_sq(rank_6, file_e)
#define sq_f6 map_sq(rank_6, file_f)
#define sq_g6 map_sq(rank_6, file_g)
#define sq_h6 map_sq(rank_6, file_h)
#define sq_a7 map_sq(rank_7, file_a)
#define sq_b7 map_sq(rank_7, file_b)
#define sq_c7 map_sq(rank_7, file_c)
#define sq_d7 map_sq(rank_7, file_d)
#define sq_e7 map_sq(rank_7, file_e)
#define sq_f7 map_sq(rank_7, file_f)
#define sq_g7 map_sq(rank_7, file_g)
#define sq_h7 map_sq(rank_7, file_h)
#define sq_a8 map_sq(rank_8, file_a)
#define sq_b8 map_sq(rank_8, file_b)
#define sq_c8 map_sq(rank_8, file_c)
#define sq_d8 map_sq(rank_8, file_d)
#define sq_e8 map_sq(rank_8, file_e)
#define sq_f8 map_sq(rank_8, file_f)
#define sq_g8 map_sq(rank_8, file_g)
#define sq_h8 map_sq(rank_8, file_h)

/* regular board */

typedef union rbU
{
  cpT rbm[rankL][fileL]; /* rank/file indexing */
  cpT rbv[sqL];          /* square indexing */
} rbT, *rbptrT;

/* direction indices */

typedef siT dxT, *dxptrT;
#define dxL 16
#define rdxL 8
#define dx_nil (-1)

#define dx_0  0
#define dx_1  1
#define dx_2  2
#define dx_3  3
#define dx_4  4
#define dx_5  5
#define dx_6  6
#define dx_7  7
#define dx_8  8
#define dx_9  9
#define dx_a 10
#define dx_b 11
#define dx_c 12
#define dx_d 13
#define dx_e 14
#define dx_f 15

/* direction vectors (file components) */

typedef siT dvfT;
#define dvf_nul 0

#define dvf_0 ( 1)
#define dvf_1 ( 0)
#define dvf_2 (-1)
#define dvf_3 ( 0)
#define dvf_4 ( 1)
#define dvf_5 (-1)
#define dvf_6 (-1)
#define dvf_7 ( 1)
#define dvf_8 ( 2)
#define dvf_9 ( 1)
#define dvf_a (-1)
#define dvf_b (-2)
#define dvf_c (-2)
#define dvf_d (-1)
#define dvf_e ( 1)
#define dvf_f ( 2)

/* direction vectors (rank components) */

typedef siT dvrT;
#define dvr_nul 0

#define dvr_0 ( 0)
#define dvr_1 ( 1)
#define dvr_2 ( 0)
#define dvr_3 (-1)
#define dvr_4 ( 1)
#define dvr_5 ( 1)
#define dvr_6 (-1)
#define dvr_7 (-1)
#define dvr_8 ( 1)
#define dvr_9 ( 2)
#define dvr_a ( 2)
#define dvr_b ( 1)
#define dvr_c (-1)
#define dvr_d (-2)
#define dvr_e (-2)
#define dvr_f (-1)

/* direction vectors */

typedef siT dvT;
#define dv_nul 0

#define dv_0 ((dvr_0 * fileL) + dvf_0)
#define dv_1 ((dvr_1 * fileL) + dvf_1)
#define dv_2 ((dvr_2 * fileL) + dvf_2)
#define dv_3 ((dvr_3 * fileL) + dvf_3)
#define dv_4 ((dvr_4 * fileL) + dvf_4)
#define dv_5 ((dvr_5 * fileL) + dvf_5)
#define dv_6 ((dvr_6 * fileL) + dvf_6)
#define dv_7 ((dvr_7 * fileL) + dvf_7)
#define dv_8 ((dvr_8 * fileL) + dvf_8)
#define dv_9 ((dvr_9 * fileL) + dvf_9)
#define dv_a ((dvr_a * fileL) + dvf_a)
#define dv_b ((dvr_b * fileL) + dvf_b)
#define dv_c ((dvr_c * fileL) + dvf_c)
#define dv_d ((dvr_d * fileL) + dvf_d)
#define dv_e ((dvr_e * fileL) + dvf_e)
#define dv_f ((dvr_f * fileL) + dvf_f)

/* extended board */

typedef siT xbrankT;
#define xbrankQ 4
#define xbrankL (bit << xbrankQ)

typedef siT xbfileT;
#define xbfileQ 4
#define xbfileL (bit << xbfileQ)

typedef siT xbsqT;
#define xbsqQ (xbrankQ + xbfileQ)
#define xbsqL (bit << xbsqQ)

typedef union xbU
{
  tiT xbm[xbrankL][xbfileL]; /* x-rank/x-file indexing */
  tiT xbv[xbsqL];            /* x-square indexing */
} xbT, *xbptrT;

/* extended board mappings */

#define map_xbsq(xbr, xbf) ((xbf) | ((xbr) << xbfileQ))
#define map_xbfile(xbsq) ((xbsq) & 0x0f)
#define map_xbrank(xbsq) ((xbsq) >> xbfileQ)

/* extended board translations */

#define trn_xbsq(sq) \
    (((((sq) & 0x38) << 1) + 0x40) | (((sq) & 0x07) + 0x04))
#define trn_xbrank(r) ((r) + 4)
#define trn_xbfile(f) ((f) + 4)

#define trn_sqxb(xbsq) \
    (((((xbsq) & 0xf0) - 0x40) >> 1) | (((xbsq) & 0x0f) - 4))
#define trn_rankxb(xbr) ((xbr) - 4)
#define trn_filexb(xbf) ((xbf) - 4)

/* extended direction vectors */

typedef siT xdvT;
#define xdv_nul (0x00)

#define xdv_0 (( 0 * xbfileL) + 1)
#define xdv_1 (( 1 * xbfileL) + 0)
#define xdv_2 (( 0 * xbfileL) - 1)
#define xdv_3 ((-1 * xbfileL) - 0)
#define xdv_4 (( 1 * xbfileL) + 1)
#define xdv_5 (( 1 * xbfileL) - 1)
#define xdv_6 ((-1 * xbfileL) - 1)
#define xdv_7 ((-1 * xbfileL) + 1)
#define xdv_8 (( 1 * xbfileL) + 2)
#define xdv_9 (( 2 * xbfileL) + 1)
#define xdv_a (( 2 * xbfileL) - 1)
#define xdv_b (( 1 * xbfileL) - 2)
#define xdv_c ((-1 * xbfileL) - 2)
#define xdv_d ((-2 * xbfileL) - 1)
#define xdv_e ((-2 * xbfileL) + 1)
#define xdv_f ((-1 * xbfileL) + 2)

/* tablebase index type */

typedef liT indexT, *indexptrT;

/* the tablebase move structure */

typedef struct tbmS
{
  sqT tbm_frsq; /* from square */
  sqT tbm_tosq; /* to square */
  cpT tbm_frcp; /* from color-piece */
  cpT tbm_tocp; /* to color-piece */
} tbmT, *tbmptrT;

/* tablebase move generation count limit */

#define tbgmcL 256

/* tablebase class identifiers */

typedef siT tbidT, *tbidptrT;
#define tbidL 146
#define tbid_nil (-1)

#define tbid_kk      0
#define tbid_kpk     1
#define tbid_knk     2
#define tbid_kbk     3
#define tbid_krk     4
#define tbid_kqk     5
#define tbid_kpkp    6
#define tbid_knkp    7
#define tbid_knkn    8
#define tbid_kbkp    9
#define tbid_kbkn   10
#define tbid_kbkb   11
#define tbid_krkp   12
#define tbid_krkn   13
#define tbid_krkb   14
#define tbid_krkr   15
#define tbid_kqkp   16
#define tbid_kqkn   17
#define tbid_kqkb   18
#define tbid_kqkr   19
#define tbid_kqkq   20
#define tbid_kppk   21
#define tbid_knpk   22
#define tbid_knnk   23
#define tbid_kbpk   24
#define tbid_kbnk   25
#define tbid_kbbk   26
#define tbid_krpk   27
#define tbid_krnk   28
#define tbid_krbk   29
#define tbid_krrk   30
#define tbid_kqpk   31
#define tbid_kqnk   32
#define tbid_kqbk   33
#define tbid_kqrk   34
#define tbid_kqqk   35
#define tbid_kppkp  36
#define tbid_kppkn  37
#define tbid_kppkb  38
#define tbid_kppkr  39
#define tbid_kppkq  40
#define tbid_knpkp  41
#define tbid_knpkn  42
#define tbid_knpkb  43
#define tbid_knpkr  44
#define tbid_knpkq  45
#define tbid_knnkp  46
#define tbid_knnkn  47
#define tbid_knnkb  48
#define tbid_knnkr  49
#define tbid_knnkq  50
#define tbid_kbpkp  51
#define tbid_kbpkn  52
#define tbid_kbpkb  53
#define tbid_kbpkr  54
#define tbid_kbpkq  55
#define tbid_kbnkp  56
#define tbid_kbnkn  57
#define tbid_kbnkb  58
#define tbid_kbnkr  59
#define tbid_kbnkq  60
#define tbid_kbbkp  61
#define tbid_kbbkn  62
#define tbid_kbbkb  63
#define tbid_kbbkr  64
#define tbid_kbbkq  65
#define tbid_krpkp  66
#define tbid_krpkn  67
#define tbid_krpkb  68
#define tbid_krpkr  69
#define tbid_krpkq  70
#define tbid_krnkp  71
#define tbid_krnkn  72
#define tbid_krnkb  73
#define tbid_krnkr  74
#define tbid_krnkq  75
#define tbid_krbkp  76
#define tbid_krbkn  77
#define tbid_krbkb  78
#define tbid_krbkr  79
#define tbid_krbkq  80
#define tbid_krrkp  81
#define tbid_krrkn  82
#define tbid_krrkb  83
#define tbid_krrkr  84
#define tbid_krrkq  85
#define tbid_kqpkp  86
#define tbid_kqpkn  87
#define tbid_kqpkb  88
#define tbid_kqpkr  89
#define tbid_kqpkq  90
#define tbid_kqnkp  91
#define tbid_kqnkn  92
#define tbid_kqnkb  93
#define tbid_kqnkr  94
#define tbid_kqnkq  95
#define tbid_kqbkp  96
#define tbid_kqbkn  97
#define tbid_kqbkb  98
#define tbid_kqbkr  99
#define tbid_kqbkq 100
#define tbid_kqrkp 101
#define tbid_kqrkn 102
#define tbid_kqrkb 103
#define tbid_kqrkr 104
#define tbid_kqrkq 105
#define tbid_kqqkp 106
#define tbid_kqqkn 107
#define tbid_kqqkb 108
#define tbid_kqqkr 109
#define tbid_kqqkq 110
#define tbid_kpppk 111
#define tbid_knppk 112
#define tbid_knnpk 113
#define tbid_knnnk 114
#define tbid_kbppk 115
#define tbid_kbnpk 116
#define tbid_kbnnk 117
#define tbid_kbbpk 118
#define tbid_kbbnk 119
#define tbid_kbbbk 120
#define tbid_krppk 121
#define tbid_krnpk 122
#define tbid_krnnk 123
#define tbid_krbpk 124
#define tbid_krbnk 125
#define tbid_krbbk 126
#define tbid_krrpk 127
#define tbid_krrnk 128
#define tbid_krrbk 129
#define tbid_krrrk 130
#define tbid_kqppk 131
#define tbid_kqnpk 132
#define tbid_kqnnk 133
#define tbid_kqbpk 134
#define tbid_kqbnk 135
#define tbid_kqbbk 136
#define tbid_kqrpk 137
#define tbid_kqrnk 138
#define tbid_kqrbk 139
#define tbid_kqrrk 140
#define tbid_kqqpk 141
#define tbid_kqqnk 142
#define tbid_kqqbk 143
#define tbid_kqqrk 144
#define tbid_kqqqk 145

/* tablebase piece limits */

#define tbmecL 4 /* either color by itself */
#define tbmbcL 5 /* both colors combined */

/* tablebase fold modes */

typedef siT foldT;
#define foldL 2
#define fold_nil (-1)

#define fold_flank    0
#define fold_triangle 1

#define ff_flankL    (sqL / 2)
#define ff_triangleL (((rankL * rankL) + (rankL * 2)) / 8)

/* tablebase flags */

#define tbf_has_pawns      bit_00
#define tbf_has_white_pawn bit_01
#define tbf_has_black_pawn bit_02
#define tbf_ep_captures    bit_03
#define tbf_fold_triangle  bit_04
#define tbf_fold_flank     bit_05

/* piece distribution type */

typedef siT distvT[rcL][rpL];

/* the tablebase master vector entry */

typedef struct tbS
{
	charptrT tb_name;                /* class name */
	siT      tb_flags;               /* flag bits */
	foldT    tb_fold;                /* fold mode */
	cT       tb_pivot_c;             /* pivot color */
	siT      tb_pivot_slot;          /* pivot slot within color */
	siT      tb_count;               /* man count */
	indexT   tb_length;              /* length of file */
	siT      tb_mcv[rcL];            /* man count per color */
	distvT   tb_distv;               /* piece distribution */
	liT      tb_sig0;                /* distribution signature */
	liT      tb_sig1;                /* inverted distribution signature */
	pT       tb_pv[rcL][tbmecL];     /* pieces */
	cpT      tb_cpv[rcL][tbmecL];    /* color-pieces */
	siT      tb_scalev[rcL][tbmecL]; /* scale factors */
	liT      tb_multv[rcL][tbmecL];  /* multipliers */
} tbT, *tbptrT;

/* tablebase byte entry semispan length */

#define tbbe_ssL (((bit << byteW) - 4) / 2)

/* the signed byte evaulation type */

typedef signed char bevT, *bevptrT;

/* tablebase signed byte entry values */

#define bev_broken   (tbbe_ssL + 1)  /* illegal or busted */

#define bev_mi1      tbbe_ssL        /* mate in 1 move */
#define bev_mimin    1               /* mate in 126 moves */

#define bev_draw     0               /* draw */

#define bev_limax    (-1)            /* mated in 125 moves */
#define bev_li0      (-tbbe_ssL)     /* mated in 0 moves */

#define bev_reserved (-tbbe_ssL - 1) /* reserved */
#define bev_unknown  (-tbbe_ssL - 2) /* unknown */

/* signed byte entry range testing macros */

#define tbe_mating(bev) \
	(((bev) >= bev_mimin) && ((bev) <= bev_mi1))

#define tbe_losing(bev) \
	(((bev) >= bev_li0) && ((bev) <= bev_limax))

#define tbe_wld(bev) \
	(((bev) >= bev_li0) && ((bev) <= bev_mi1))

#define tbe_special(bev) \
	(((bev) < bev_li0) || ((bev) > bev_mi1))

/* dependency vector type */

typedef siT depvT[tbidL][rcL];

/* position vector type */

typedef sqT posvT[rcL][tbmecL];

/* sort record formats */

typedef struct sr0S
{
	indexT sr0_index0; /* target file index */
	indexT sr0_index1; /* directive file index */
} sr0T, *sr0ptrT;

typedef struct sr1S
{
	indexT sr1_index; /* target file index */
	bevT   sr1_bev;   /* directive bev */
} sr1T, *sr1ptrT;

typedef struct sr2S
{
	indexT sr2_index; /* target file index */
} sr2T, *sr2ptrT;

typedef struct sr3S
{
	indexT sr3_index0; /* target file index */
	indexT sr3_index1; /* prograde file index */
} sr3T, *sr3ptrT;
