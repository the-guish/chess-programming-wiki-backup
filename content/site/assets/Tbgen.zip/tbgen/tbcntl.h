/* >>> tbcntl.h: function prototypes for tablebase generator file tbcntl.c */
/* Revised: 2004.09.03 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

void TBInit(void);
void TBTerm(void);
