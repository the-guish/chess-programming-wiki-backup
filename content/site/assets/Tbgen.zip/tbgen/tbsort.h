/* >>> tbsort.h: function prototypes for tablebase generator file tbsort.c */
/* Revised: 2004.09.03 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

int TBCompSR0(sr0ptrT sr0ptr0, sr0ptrT sr0ptr1);
int TBCompSR1(sr1ptrT sr1ptr0, sr1ptrT sr1ptr1);
int TBCompSR2(sr2ptrT sr2ptr0, sr2ptrT sr2ptr1);
int TBCompSR3(sr3ptrT sr3ptr0, sr3ptrT sr3ptr1);

indexT TBSortFile(
  charptrT fn0, charptrT fn1, liT entrysize, siT unique, cfiptrT cfiptr);
