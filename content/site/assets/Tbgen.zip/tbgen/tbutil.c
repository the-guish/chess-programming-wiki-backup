/* >>> tbutil.c: general utilities for tablebase generator */
/* Revised: 2004.09.03 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tbdefs.h"
#include "tbvars.h"

#include "tbutil.h"

/*--> TBCheckPoint: debugging checkpoint */
void TBCheckPoint(charptrT s)
{
  if (1)
  {
    printf("Check point: %s ", s);
    getchar();
    getchar();
    getchar();
    getchar();
  };
}

/*--> TBFatal: emit fatal error diagnostic */
void TBFatal(charptrT s)
{
  fprintf(stderr, "Fatal error: %s\n", s);
  exit(1);
}

/*--> TBSwitchFault: emit fatal switch fault diagnostic */
void TBSwitchFault(charptrT s)
{
  fprintf(stderr, "Switch fault: %s\n", s);
  TBFatal(s);
}

/*--> TBMemoryGrab: allocate memory */
voidptrT TBMemoryGrab(liT n)
{
  voidptrT ptr;

  if (n == 0)
    ptr = (voidptrT) malloc(1);
  else
    ptr = (voidptrT) malloc(n);

  if (ptr == NULL)
    TBFatal("TBMemoryGrab: out of memory");

  return ptr;
}

/*--> TBMemoryFree: free memory */
void TBMemoryFree(voidptrT ptr)
{
  if (ptr == NULL)
    TBFatal("TBMemoryFree: tried to free NULL pointer");
  else
    free(ptr);
}

/*--> TBStringGrab: allocate and copy a string */
charptrT TBStringGrab(charptrT s)
{
  charptrT ptr;
  liT length;

  if (s == NULL)
  {
    ptr = NULL;
    TBFatal("TBStringGrab: tried to allocate NULL string");
  }
  else
  {
    length = strlen(s);
    ptr = (charptrT) malloc(length + 1);
    if (ptr == NULL)
      TBFatal("TBStringGrab: out of memory");
    else
      strcpy(ptr, s);
  };

  return ptr;
}

/*--> TBStringFree: free an allocated string */
void TBStringFree(charptrT ptr)
{
  if (ptr == NULL)
    TBFatal("TBStringFree: tried to free a NULL string");
  else
    free(ptr);
}

/*--> TBStringAppendChar: append a character to a string */
charptrT TBStringAppendChar(charptrT s, char c)
{
  charptrT ptr;
  liT length;

  /* the first argument is deallocated */

  length = strlen(s);
  ptr = (charptrT) TBMemoryGrab(length + 2);
  strcpy(ptr, s);
  TBMemoryFree(s);
  *(ptr + length) = c;
  *(ptr + length + 1) = ascii_nul;

  return ptr;
}

/*--> TBStringAppendStr: append a string to a string */
charptrT TBStringAppendStr(charptrT s0, charptrT s1)
{
  charptrT ptr;
  liT length;

  /* the first argument is deallocated */

  length = strlen(s0) + strlen(s1);
  ptr = (charptrT) TBMemoryGrab(length + 1);
  strcpy(ptr, s0);
  strcat(ptr, s1);
  TBMemoryFree(s0);

  return ptr;
}
