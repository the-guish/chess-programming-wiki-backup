/* >>> tbfile.c: file operations for the tablebase generator */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tbdefs.h"
#include "tbvars.h"

#include "tbfile.h"
#include "tbutil.h"

#include <unistd.h>

/*--> TBMapFileName: map a file pathname from standard into local format */
static charptrT TBMapFileName(charptrT fn)
{
  static char fv[tL];

  if (strlen(fn) >= tL)
    TBFatal("MapFileName: filename too long");
  else
    (void) strcpy(fv, fn);

  return fv;
}

/*--> TBClassFileName: return an allocated class name */
charptrT TBClassFileName(charptrT dirstr, tbidT tbid, cT c)
{
  charptrT name;

  if (dirstr == NULL)
    name = TBStringGrab("");
  else
  {
    name = TBStringGrab(dirstr);
    name = TBStringAppendChar(name, '/');
  };

  name = TBStringAppendStr(name, (tbbaseptr + tbid)->tb_name);
  name = TBStringAppendStr(name, ctmext_strv[c]);

  return name;
}

/*--> TBTempFileName: return an allocated temporary file name */
charptrT TBTempFileName(void)
{
  charptrT name;
  char basev[13];

  sprintf(basev, "%04hx%08lx", ((siT) getpid()), tf_ordinal);

  name = TBStringGrab(tmpdir_str);
  name = TBStringAppendStr(name, "/t");
  name = TBStringAppendStr(name, basev);
  name = TBStringAppendStr(name, ".tbg");

  /* bump the ordinal */

  tf_ordinal++;

  return name;
}

/*--> TBSetBuffer: set a sized buffer for a newly opened file */
void TBSetBuffer(fptrT fptr, liT length)
{
  setvbuf(fptr, NULL, _IOFBF, length);
}

/*--> TBSetBigBuffer: set a big buffer for a newly opened file */
void TBSetBigBuffer(fptrT fptr)
{
  TBSetBuffer(fptr, rlbL);
}

/*--> TBSetBiggerBuffer: set a bigger buffer for a newly opened file */
void TBSetBiggerBuffer(fptrT fptr)
{
  TBSetBuffer(fptr, (16 * rlbL));
}

/*--> TBCodeFileRemove: remove a code file by name */
void TBCodeFileRemove(charptrT filename)
{
  char fn[tL];

  (void) strcpy(fn, TBMapFileName(filename));
  remove(fn);
}

/*--> TBCodeFileOpen: open a code file */
static fptrT TBCodeFileOpen(charptrT filename, charptrT filemode)
{
  fptrT fptr;
  char fn[tL];

  (void) strcpy(fn, TBMapFileName(filename));
  fptr = fopen(fn, filemode);

  return fptr;
}

/*--> TBCodeFileOpenRead: open a code file for reading */
fptrT TBCodeFileOpenRead(charptrT filename)
{
  fptrT fptr;

  fptr = TBCodeFileOpen(filename, "rb");
  if (fptr == NULL)
  {
    fprintf(stderr, "Can't open code file %s for reading\n", filename);
    TBFatal("open fault");
  };

  return fptr;
}

/*--> TBCodeFileOpenReadSF: open a code file for reading (soft fail) */
fptrT TBCodeFileOpenReadSF(charptrT filename)
{
  fptrT fptr;

  fptr = TBCodeFileOpen(filename, "rb");

  return fptr;
}

/*--> TBCodeFileOpenWrite: open a code file for writing */
fptrT TBCodeFileOpenWrite(charptrT filename)
{
  fptrT fptr;

  fptr = TBCodeFileOpen(filename, "wb");
  if (fptr == NULL)
  {
    fprintf(stderr, "Can't open code file %s for writing\n", filename);
    TBFatal("open fault");
  };

  return fptr;
}

/*--> TBCodeFileClose: close a code file */
siT TBCodeFileClose(fptrT fptr)
{
  siT result;

  result = fclose(fptr);
  if (result != 0)
  {
    fprintf(stderr, "Can't close code file\n");
    TBFatal("close fault");
  };

  return result;
}

/*-->TBCodeFileCopy: copy one code file to another */
void TBCodeFileCopy(charptrT fn_source, charptrT fn_target)
{
  fptrT fp_source, fp_target;
  siT c;

  /* open */

  fp_source = TBCodeFileOpen(fn_source, "rb");
  TBSetBiggerBuffer(fp_source);

  fp_target = TBCodeFileOpen(fn_target, "wb");
  TBSetBiggerBuffer(fp_target);

  /* copy */

  while ((c = fgetc(fp_source)) != EOF)
    fputc(c, fp_target);

  /* close */

  TBCodeFileClose(fp_source);
  TBCodeFileClose(fp_target);
}

/*-->TBCodeFileRename: rename a code file */
void TBCodeFileRename(charptrT fn_source, charptrT fn_target)
{
  int result;
  char fn_sv[tL], fn_tv[tL];

  (void) strcpy(fn_sv, TBMapFileName(fn_source));
  (void) strcpy(fn_tv, TBMapFileName(fn_target));

  result = rename(fn_sv, fn_tv);
  if (result != 0)
  {
    fprintf(stderr, "TBCodeFileRename: Can't rename %s to %s\n",
      fn_source, fn_target);
    TBFatal("Rename fault");
  };
}

/*--> TBTextFileRemove: remove a text file by name */
void TBTextFileRemove(charptrT filename)
{
  char fn[tL];

  (void) strcpy(fn, TBMapFileName(filename));
  remove(fn);
}

/*--> TBTextFileOpen: open a text file */
static fptrT TBTextFileOpen(charptrT filename, charptrT filemode)
{
  fptrT fptr;
  char fn[tL];

  (void) strcpy(fn, TBMapFileName(filename));
  fptr = fopen(fn, filemode);

  return fptr;
}

/*--> TBTextFileOpenRead: open a text file for reading */
fptrT TBTextFileOpenRead(charptrT filename)
{
  fptrT fptr;

  fptr = TBTextFileOpen(filename, "r");
  if (fptr == NULL)
  {
    fprintf(stderr, "Can't open text file %s for reading\n", filename);
    TBFatal("open fault");
  };

  return fptr;
}

/*--> TBTextFileOpenWrite: open a text file for writing */
fptrT TBTextFileOpenWrite(charptrT filename)
{
  fptrT fptr;

  fptr = TBTextFileOpen(filename, "w");
  if (fptr == NULL)
  {
    fprintf(stderr, "Can't open text file %s for writing\n", filename);
    TBFatal("open fault");
  };

  return fptr;
}

/*--> TBTextFileClose: close a text file */
siT TBTextFileClose(fptrT fptr)
{
  siT result;

  result = fclose(fptr);
  if (result != 0)
  {
    fprintf(stderr, "Can't close text file\n");
    TBFatal("close fault");
  };

  return result;
}

/*-->TBTextFileCopy: copy one text file to another */
void TBTextFileCopy(charptrT fn_source, charptrT fn_target)
{
  fptrT fp_source, fp_target;
  siT c;

  /* open */

  fp_source = TBTextFileOpen(fn_source, "r");
  TBSetBiggerBuffer(fp_source);

  fp_target = TBTextFileOpen(fn_target, "w");
  TBSetBiggerBuffer(fp_target);

  /* copy */

  while ((c = fgetc(fp_source)) != EOF)
    fputc(c, fp_target);

  /* close */

  TBTextFileClose(fp_source);
  TBTextFileClose(fp_target);
}

/*-->TBTextFileRename: rename a text file */
void TBTextFileRename(charptrT fn_source, charptrT fn_target)
{
  int result;
  char fn_sv[tL], fn_tv[tL];

  (void) strcpy(fn_sv, TBMapFileName(fn_source));
  (void) strcpy(fn_tv, TBMapFileName(fn_target));

  result = rename(fn_sv, fn_tv);
  if (result != 0)
  {
    fprintf(stderr, "TBTextFileRename: Can't rename %s to %s\n",
      fn_source, fn_target);
    TBFatal("Rename fault");
  };
}
