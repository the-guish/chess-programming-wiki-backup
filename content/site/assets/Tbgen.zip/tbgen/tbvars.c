/* >>> tbvars.c: common variables for tablebase generator */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

#include <stdio.h>
#include <stdlib.h>

#include "tbdefs.h"
#include "tbvars.h"

/* constant value vectors */

char asccv[cL];
char ascpv[pL];
char ascrv[rankL];
char ascfv[fileL];

cT inv_cv[cL];

cpT cnv_cpv[rcL][rpL];
cT cnv_cv[cpL];
pT cnv_pv[cpL];

charptrT ctm_strv[rcL];
charptrT ctmext_strv[rcL];

rankT prom_rankv[rcL];

dvT dvv[dxL];
xdvT xdvv[dxL];

xbT xb;

/* command argument strings */

charptrT class_str;
charptrT targetdir_strv[rcL];
charptrT tmpdir_str;
charptrT refdir_str;

/* the base pointer for the allocated main tablebase vector */

tbptrT tbbaseptr;

/* the base pointer vectors for generated and retrogenerated moves */

tbmptrT tbgmbaseptrv[rcL];
tbmptrT tbrgmbaseptrv[rcL];

/* generated and retrogenerated move count vectors */

siT tbgmcv[rcL];
siT tbrgmcv[rcL];

/* maps */

siT flank_mapv[sqL];
siT triangle_mapv[sqL];

/* unmaps */

sqT flank_unmapv[ff_flankL];
sqT triangle_unmapv[ff_triangleL];

/* the diagonal map (both long diagonals) */

siT diagonalv[sqL];

/* class under construction */

tbidT class_tbid;

/* temporary file ordinal */

liT tf_ordinal;

/* maximum mate/lose distances */

siT maxmatev[rcL];
siT maxlosev[rcL];
