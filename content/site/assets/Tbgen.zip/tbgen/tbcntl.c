/* >>> tbcntl.c: control routines for tablebase generator */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tbdefs.h"
#include "tbvars.h"

#include "tbcntl.h"
#include "tbmisc.h"
#include "tbutil.h"

/*--> TBInitTBID: initialize an entry in the tablebase vector */
static
void
TBInitTBID(tbidT tbid, charptrT name)
{
  cT c;
  pT p;
  siT i, slot;
  liT mult;
  char ch;
  tbptrT classptr;

  classptr = tbbaseptr + tbid;

  /* clear flags and set name items */

  classptr->tb_flags = 0;
  classptr->tb_name = TBStringGrab(name);
  classptr->tb_count = strlen(name);

  /* clear various vectors */

  for (c = c_w; c <= c_b; c++)
  {
    classptr->tb_mcv[c] = 0;
    for (p = p_p; p <= p_k; p++)
      classptr->tb_distv[c][p] = 0;
  };

  /* scan through pieces in class names */

  c = c_b;
  for (i = 0; i < classptr->tb_count; i++)
  {
    /* identify current piece */

    ch = *(name + i);
    switch (ch)
    {
    case 'P': p = p_p; break;
    case 'N': p = p_n; break;
    case 'B': p = p_b; break;
    case 'R': p = p_r; break;
    case 'Q': p = p_q; break;
    case 'K': p = p_k; break;
    default: TBSwitchFault("TBInitTBID"); break;
    };

    /* swap color if current piece is a king */

    if (p == p_k)
      c = inv_cv[c];

    /* set various flags if current piece is a pawn */

    if (p == p_p)
    {
      classptr->tb_flags |= tbf_has_pawns;
      if (c == c_w)
      {
        classptr->tb_flags |= tbf_has_white_pawn;
        if (classptr->tb_flags & tbf_has_black_pawn)
          classptr->tb_flags |= tbf_ep_captures;
      }
      else
      {
        classptr->tb_flags |= tbf_has_black_pawn;
        if (classptr->tb_flags & tbf_has_white_pawn)
          classptr->tb_flags |= tbf_ep_captures;
      };
    };

    /* adjust count and distribution for this color */

    classptr->tb_mcv[c]++;
    classptr->tb_distv[c][p]++;

    /* set piece and color-piece vector for this color */

    if (c == c_w)
      slot = i;
    else
      slot = i - classptr->tb_mcv[c_w];
    classptr->tb_pv[c][slot] = p;
    classptr->tb_cpv[c][slot] = cnv_cpv[c][p];
  };

  /* set the distribution signatures */

  classptr->tb_sig0 = TBGetSignature(classptr->tb_distv);
  classptr->tb_sig1 = TBGetInvertedSignature(classptr->tb_distv);

  /* set fold mode information */

  if (classptr->tb_flags & tbf_has_pawns)
  {
    classptr->tb_flags |= tbf_fold_flank;
    classptr->tb_fold = fold_flank;
  }
  else
  {
    classptr->tb_flags |= tbf_fold_triangle;
    classptr->tb_fold = fold_triangle;
  };

  /* calculate file length */

  classptr->tb_length = 1;
  for (i = 1; i < classptr->tb_count; i++)
    classptr->tb_length *= sqL;
  if (classptr->tb_fold == fold_flank)
    classptr->tb_length *= ff_flankL;
  else
    classptr->tb_length *= ff_triangleL;

  /* calculate pivot color and slot */

  if (classptr->tb_fold == fold_triangle)
  {
    classptr->tb_pivot_c = c_b;
    classptr->tb_pivot_slot = classptr->tb_mcv[c_b] - 1;
  }
  else
  {
    if (classptr->tb_flags & tbf_has_black_pawn)
    {
      classptr->tb_pivot_c = c_b;
      i = classptr->tb_count - 1;
      while (*(name + i) != ascpv[p_p])
        i--;
      classptr->tb_pivot_slot = i - classptr->tb_mcv[c_w];
    }
    else
    {
      classptr->tb_pivot_c = c_w;
      i = classptr->tb_mcv[c_w] - 1;
      while (*(name + i) != ascpv[p_p])
        i--;
      classptr->tb_pivot_slot = i;
    };
  };

  /* calculate scale factors */

  for (c = c_w; c <= c_b; c++)
  {
    for (i = 0; i < classptr->tb_mcv[c]; i++)
    {
      if ((c != classptr->tb_pivot_c) || (i != classptr->tb_pivot_slot))
        classptr->tb_scalev[c][i] = sqL;
      else
      {
        if (classptr->tb_fold == fold_triangle)
          classptr->tb_scalev[c][i] = ff_triangleL;
        else
          classptr->tb_scalev[c][i] = ff_flankL;
      };
    };
  };

  /* calculate multipliers */

  mult = 1;
  for (c = c_w; c <= c_b; c++)
  {
    for (i = 0; i < classptr->tb_mcv[c]; i++)
    {
      classptr->tb_multv[c][i] = mult;
      mult *= classptr->tb_scalev[c][i];
    };
  };
}

/*--> TBTermTBID: terminate an entry in the tablebase vector */
static void TBTermTBID(tbidT tbid)
{
  tbptrT classptr = tbbaseptr + tbid;

  TBStringFree(classptr->tb_name);
}

/*--> TBInit: one time initialization for the tablebase generator */
void TBInit(void)
{
  sqT sq;
  xbrankT xbrank;
  xbfileT xbfile;
  rankT rank;
  fileT file;
  cT c;

  /* initialize constant value vectors */

  asccv[c_w] = 'w';
  asccv[c_b] = 'b';
  asccv[c_v] = ' ';
  asccv[c_x] = '?';

  ascpv[p_p] = 'P';
  ascpv[p_n] = 'N';
  ascpv[p_b] = 'B';
  ascpv[p_r] = 'R';
  ascpv[p_q] = 'Q';
  ascpv[p_k] = 'K';
  ascpv[p_v] = ' ';
  ascpv[p_x] = '?';

  ascrv[rank_1] = '1';
  ascrv[rank_2] = '2';
  ascrv[rank_3] = '3';
  ascrv[rank_4] = '4';
  ascrv[rank_5] = '5';
  ascrv[rank_6] = '6';
  ascrv[rank_7] = '7';
  ascrv[rank_8] = '8';

  ascfv[file_a] = 'a';
  ascfv[file_b] = 'b';
  ascfv[file_c] = 'c';
  ascfv[file_d] = 'd';
  ascfv[file_e] = 'e';
  ascfv[file_f] = 'f';
  ascfv[file_g] = 'g';
  ascfv[file_h] = 'h';

  inv_cv[c_w] = c_b;
  inv_cv[c_b] = c_w;
  inv_cv[c_v] = c_v;
  inv_cv[c_x] = c_x;

  cnv_cpv[c_w][p_p] = cp_wp;
  cnv_cpv[c_w][p_n] = cp_wn;
  cnv_cpv[c_w][p_b] = cp_wb;
  cnv_cpv[c_w][p_r] = cp_wr;
  cnv_cpv[c_w][p_q] = cp_wq;
  cnv_cpv[c_w][p_k] = cp_wk;
  cnv_cpv[c_b][p_p] = cp_bp;
  cnv_cpv[c_b][p_n] = cp_bn;
  cnv_cpv[c_b][p_b] = cp_bb;
  cnv_cpv[c_b][p_r] = cp_br;
  cnv_cpv[c_b][p_q] = cp_bq;
  cnv_cpv[c_b][p_k] = cp_bk;

  cnv_cv[cp_wp] = c_w;
  cnv_cv[cp_wn] = c_w;
  cnv_cv[cp_wb] = c_w;
  cnv_cv[cp_wr] = c_w;
  cnv_cv[cp_wq] = c_w;
  cnv_cv[cp_wk] = c_w;
  cnv_cv[cp_bp] = c_b;
  cnv_cv[cp_bn] = c_b;
  cnv_cv[cp_bb] = c_b;
  cnv_cv[cp_br] = c_b;
  cnv_cv[cp_bq] = c_b;
  cnv_cv[cp_bk] = c_b;
  cnv_cv[cp_v0] = c_v;
  cnv_cv[cp_x0] = c_x;
  cnv_cv[cp_x1] = c_x;
  cnv_cv[cp_x2] = c_x;

  cnv_pv[cp_wp] = p_p;
  cnv_pv[cp_wn] = p_n;
  cnv_pv[cp_wb] = p_b;
  cnv_pv[cp_wr] = p_r;
  cnv_pv[cp_wq] = p_q;
  cnv_pv[cp_wk] = p_k;
  cnv_pv[cp_bp] = p_p;
  cnv_pv[cp_bn] = p_n;
  cnv_pv[cp_bb] = p_b;
  cnv_pv[cp_br] = p_r;
  cnv_pv[cp_bq] = p_q;
  cnv_pv[cp_bk] = p_k;
  cnv_pv[cp_v0] = p_v;
  cnv_pv[cp_x0] = p_x;
  cnv_pv[cp_x1] = p_x;
  cnv_pv[cp_x2] = p_x;

  ctm_strv[c_w] = "WTM";
  ctm_strv[c_b] = "BTM";

  ctmext_strv[c_w] = ".tbw";
  ctmext_strv[c_b] = ".tbb";

  prom_rankv[c_w] = rank_8;
  prom_rankv[c_b] = rank_1;

  /* initialize the board direction delta vector */

  dvv[dx_0] = dv_0;
  dvv[dx_1] = dv_1;
  dvv[dx_2] = dv_2;
  dvv[dx_3] = dv_3;
  dvv[dx_4] = dv_4;
  dvv[dx_5] = dv_5;
  dvv[dx_6] = dv_6;
  dvv[dx_7] = dv_7;
  dvv[dx_8] = dv_8;
  dvv[dx_9] = dv_9;
  dvv[dx_a] = dv_a;
  dvv[dx_b] = dv_b;
  dvv[dx_c] = dv_c;
  dvv[dx_d] = dv_d;
  dvv[dx_e] = dv_e;
  dvv[dx_f] = dv_f;

  /* initialize the extended board direction delta vector */

  xdvv[dx_0] = xdv_0;
  xdvv[dx_1] = xdv_1;
  xdvv[dx_2] = xdv_2;
  xdvv[dx_3] = xdv_3;
  xdvv[dx_4] = xdv_4;
  xdvv[dx_5] = xdv_5;
  xdvv[dx_6] = xdv_6;
  xdvv[dx_7] = xdv_7;
  xdvv[dx_8] = xdv_8;
  xdvv[dx_9] = xdv_9;
  xdvv[dx_a] = xdv_a;
  xdvv[dx_b] = xdv_b;
  xdvv[dx_c] = xdv_c;
  xdvv[dx_d] = xdv_d;
  xdvv[dx_e] = xdv_e;
  xdvv[dx_f] = xdv_f;

  /* initialize the extended board border values */

  for (xbrank = 0; xbrank < xbrankL; xbrank++)
    for (xbfile = 0; xbfile < xbfileL; xbfile++)
      xb.xbm[xbrank][xbfile] = cp_x0;

  /* initialize the extended board non-border values */

  for (rank = rank_1; rank <= rank_8; rank++)
    for (file = file_a; file <= file_h; file++)
      xb.xbm[trn_xbrank(rank)][trn_xbfile(file)] = cp_v0;

  /* allocate the tablebase vector */

  tbbaseptr = (tbptrT) TBMemoryGrab(sizeof(tbT) * tbidL);

  /* allocate the move generation vectors */

  for (c = c_w; c <= c_b; c++)
  {
    tbgmbaseptrv[c] = (tbmptrT) TBMemoryGrab(sizeof(tbmT) * tbgmcL);
    tbrgmbaseptrv[c] = (tbmptrT) TBMemoryGrab(sizeof(tbmT) * tbgmcL);
  };

  /* initialize the tablebase vector */

  TBInitTBID(tbid_kk,    "KK");
  TBInitTBID(tbid_kpk,   "KPK");
  TBInitTBID(tbid_knk,   "KNK");
  TBInitTBID(tbid_kbk,   "KBK");
  TBInitTBID(tbid_krk,   "KRK");
  TBInitTBID(tbid_kqk,   "KQK");
  TBInitTBID(tbid_kpkp,  "KPKP");
  TBInitTBID(tbid_knkp,  "KNKP");
  TBInitTBID(tbid_knkn,  "KNKN");
  TBInitTBID(tbid_kbkp,  "KBKP");
  TBInitTBID(tbid_kbkn,  "KBKN");
  TBInitTBID(tbid_kbkb,  "KBKB");
  TBInitTBID(tbid_krkp,  "KRKP");
  TBInitTBID(tbid_krkn,  "KRKN");
  TBInitTBID(tbid_krkb,  "KRKB");
  TBInitTBID(tbid_krkr,  "KRKR");
  TBInitTBID(tbid_kqkp,  "KQKP");
  TBInitTBID(tbid_kqkn,  "KQKN");
  TBInitTBID(tbid_kqkb,  "KQKB");
  TBInitTBID(tbid_kqkr,  "KQKR");
  TBInitTBID(tbid_kqkq,  "KQKQ");
  TBInitTBID(tbid_kppk,  "KPPK");
  TBInitTBID(tbid_knpk,  "KNPK");
  TBInitTBID(tbid_knnk,  "KNNK");
  TBInitTBID(tbid_kbpk,  "KBPK");
  TBInitTBID(tbid_kbnk,  "KBNK");
  TBInitTBID(tbid_kbbk,  "KBBK");
  TBInitTBID(tbid_krpk,  "KRPK");
  TBInitTBID(tbid_krnk,  "KRNK");
  TBInitTBID(tbid_krbk,  "KRBK");
  TBInitTBID(tbid_krrk,  "KRRK");
  TBInitTBID(tbid_kqpk,  "KQPK");
  TBInitTBID(tbid_kqnk,  "KQNK");
  TBInitTBID(tbid_kqbk,  "KQBK");
  TBInitTBID(tbid_kqrk,  "KQRK");
  TBInitTBID(tbid_kqqk,  "KQQK");
  TBInitTBID(tbid_kppkp, "KPPKP");
  TBInitTBID(tbid_kppkn, "KPPKN");
  TBInitTBID(tbid_kppkb, "KPPKB");
  TBInitTBID(tbid_kppkr, "KPPKR");
  TBInitTBID(tbid_kppkq, "KPPKQ");
  TBInitTBID(tbid_knpkp, "KNPKP");
  TBInitTBID(tbid_knpkn, "KNPKN");
  TBInitTBID(tbid_knpkb, "KNPKB");
  TBInitTBID(tbid_knpkr, "KNPKR");
  TBInitTBID(tbid_knpkq, "KNPKQ");
  TBInitTBID(tbid_knnkp, "KNNKP");
  TBInitTBID(tbid_knnkn, "KNNKN");
  TBInitTBID(tbid_knnkb, "KNNKB");
  TBInitTBID(tbid_knnkr, "KNNKR");
  TBInitTBID(tbid_knnkq, "KNNKQ");
  TBInitTBID(tbid_kbpkp, "KBPKP");
  TBInitTBID(tbid_kbpkn, "KBPKN");
  TBInitTBID(tbid_kbpkb, "KBPKB");
  TBInitTBID(tbid_kbpkr, "KBPKR");
  TBInitTBID(tbid_kbpkq, "KBPKQ");
  TBInitTBID(tbid_kbnkp, "KBNKP");
  TBInitTBID(tbid_kbnkn, "KBNKN");
  TBInitTBID(tbid_kbnkb, "KBNKB");
  TBInitTBID(tbid_kbnkr, "KBNKR");
  TBInitTBID(tbid_kbnkq, "KBNKQ");
  TBInitTBID(tbid_kbbkp, "KBBKP");
  TBInitTBID(tbid_kbbkn, "KBBKN");
  TBInitTBID(tbid_kbbkb, "KBBKB");
  TBInitTBID(tbid_kbbkr, "KBBKR");
  TBInitTBID(tbid_kbbkq, "KBBKQ");
  TBInitTBID(tbid_krpkp, "KRPKP");
  TBInitTBID(tbid_krpkn, "KRPKN");
  TBInitTBID(tbid_krpkb, "KRPKB");
  TBInitTBID(tbid_krpkr, "KRPKR");
  TBInitTBID(tbid_krpkq, "KRPKQ");
  TBInitTBID(tbid_krnkp, "KRNKP");
  TBInitTBID(tbid_krnkn, "KRNKN");
  TBInitTBID(tbid_krnkb, "KRNKB");
  TBInitTBID(tbid_krnkr, "KRNKR");
  TBInitTBID(tbid_krnkq, "KRNKQ");
  TBInitTBID(tbid_krbkp, "KRBKP");
  TBInitTBID(tbid_krbkn, "KRBKN");
  TBInitTBID(tbid_krbkb, "KRBKB");
  TBInitTBID(tbid_krbkr, "KRBKR");
  TBInitTBID(tbid_krbkq, "KRBKQ");
  TBInitTBID(tbid_krrkp, "KRRKP");
  TBInitTBID(tbid_krrkn, "KRRKN");
  TBInitTBID(tbid_krrkb, "KRRKB");
  TBInitTBID(tbid_krrkr, "KRRKR");
  TBInitTBID(tbid_krrkq, "KRRKQ");
  TBInitTBID(tbid_kqpkp, "KQPKP");
  TBInitTBID(tbid_kqpkn, "KQPKN");
  TBInitTBID(tbid_kqpkb, "KQPKB");
  TBInitTBID(tbid_kqpkr, "KQPKR");
  TBInitTBID(tbid_kqpkq, "KQPKQ");
  TBInitTBID(tbid_kqnkp, "KQNKP");
  TBInitTBID(tbid_kqnkn, "KQNKN");
  TBInitTBID(tbid_kqnkb, "KQNKB");
  TBInitTBID(tbid_kqnkr, "KQNKR");
  TBInitTBID(tbid_kqnkq, "KQNKQ");
  TBInitTBID(tbid_kqbkp, "KQBKP");
  TBInitTBID(tbid_kqbkn, "KQBKN");
  TBInitTBID(tbid_kqbkb, "KQBKB");
  TBInitTBID(tbid_kqbkr, "KQBKR");
  TBInitTBID(tbid_kqbkq, "KQBKQ");
  TBInitTBID(tbid_kqrkp, "KQRKP");
  TBInitTBID(tbid_kqrkn, "KQRKN");
  TBInitTBID(tbid_kqrkb, "KQRKB");
  TBInitTBID(tbid_kqrkr, "KQRKR");
  TBInitTBID(tbid_kqrkq, "KQRKQ");
  TBInitTBID(tbid_kqqkp, "KQQKP");
  TBInitTBID(tbid_kqqkn, "KQQKN");
  TBInitTBID(tbid_kqqkb, "KQQKB");
  TBInitTBID(tbid_kqqkr, "KQQKR");
  TBInitTBID(tbid_kqqkq, "KQQKQ");
  TBInitTBID(tbid_kpppk, "KPPPK");
  TBInitTBID(tbid_knppk, "KNPPK");
  TBInitTBID(tbid_knnpk, "KNNPK");
  TBInitTBID(tbid_knnnk, "KNNNK");
  TBInitTBID(tbid_kbppk, "KBPPK");
  TBInitTBID(tbid_kbnpk, "KBNPK");
  TBInitTBID(tbid_kbnnk, "KBNNK");
  TBInitTBID(tbid_kbbpk, "KBBPK");
  TBInitTBID(tbid_kbbnk, "KBBNK");
  TBInitTBID(tbid_kbbbk, "KBBBK");
  TBInitTBID(tbid_krppk, "KRPPK");
  TBInitTBID(tbid_krnpk, "KRNPK");
  TBInitTBID(tbid_krnnk, "KRNNK");
  TBInitTBID(tbid_krbpk, "KRBPK");
  TBInitTBID(tbid_krbnk, "KRBNK");
  TBInitTBID(tbid_krbbk, "KRBBK");
  TBInitTBID(tbid_krrpk, "KRRPK");
  TBInitTBID(tbid_krrnk, "KRRNK");
  TBInitTBID(tbid_krrbk, "KRRBK");
  TBInitTBID(tbid_krrrk, "KRRRK");
  TBInitTBID(tbid_kqppk, "KQPPK");
  TBInitTBID(tbid_kqnpk, "KQNPK");
  TBInitTBID(tbid_kqnnk, "KQNNK");
  TBInitTBID(tbid_kqbpk, "KQBPK");
  TBInitTBID(tbid_kqbnk, "KQBNK");
  TBInitTBID(tbid_kqbbk, "KQBBK");
  TBInitTBID(tbid_kqrpk, "KQRPK");
  TBInitTBID(tbid_kqrnk, "KQRNK");
  TBInitTBID(tbid_kqrbk, "KQRBK");
  TBInitTBID(tbid_kqrrk, "KQRRK");
  TBInitTBID(tbid_kqqpk, "KQQPK");
  TBInitTBID(tbid_kqqnk, "KQQNK");
  TBInitTBID(tbid_kqqbk, "KQQBK");
  TBInitTBID(tbid_kqqrk, "KQQRK");
  TBInitTBID(tbid_kqqqk, "KQQQK");

  /* initialize the flank map */

  for (sq = sq_a1; sq <= sq_h8; sq++)
    flank_mapv[sq] = -1;

  flank_mapv[sq_a1] =  0;
  flank_mapv[sq_b1] =  1;
  flank_mapv[sq_c1] =  2;
  flank_mapv[sq_d1] =  3;
  flank_mapv[sq_a2] =  4;
  flank_mapv[sq_b2] =  5;
  flank_mapv[sq_c2] =  6;
  flank_mapv[sq_d2] =  7;
  flank_mapv[sq_a3] =  8;
  flank_mapv[sq_b3] =  9;
  flank_mapv[sq_c3] = 10;
  flank_mapv[sq_d3] = 11;
  flank_mapv[sq_a4] = 12;
  flank_mapv[sq_b4] = 13;
  flank_mapv[sq_c4] = 14;
  flank_mapv[sq_d4] = 15;
  flank_mapv[sq_a5] = 16;
  flank_mapv[sq_b5] = 17;
  flank_mapv[sq_c5] = 18;
  flank_mapv[sq_d5] = 19;
  flank_mapv[sq_a6] = 20;
  flank_mapv[sq_b6] = 21;
  flank_mapv[sq_c6] = 22;
  flank_mapv[sq_d6] = 23;
  flank_mapv[sq_a7] = 24;
  flank_mapv[sq_b7] = 25;
  flank_mapv[sq_c7] = 26;
  flank_mapv[sq_d7] = 27;
  flank_mapv[sq_a8] = 28;
  flank_mapv[sq_b8] = 29;
  flank_mapv[sq_c8] = 30;
  flank_mapv[sq_d8] = 31;

  /* initialize the triangle map */

  for (sq = sq_a1; sq <= sq_h8; sq++)
    triangle_mapv[sq] = -1;

  triangle_mapv[sq_a1] = 0;
  triangle_mapv[sq_b1] = 1;
  triangle_mapv[sq_c1] = 2;
  triangle_mapv[sq_d1] = 3;
  triangle_mapv[sq_b2] = 4;
  triangle_mapv[sq_c2] = 5;
  triangle_mapv[sq_d2] = 6;
  triangle_mapv[sq_c3] = 7;
  triangle_mapv[sq_d3] = 8;
  triangle_mapv[sq_d4] = 9;

  /* initialize the flank unmap */

  flank_unmapv[ 0] = sq_a1;
  flank_unmapv[ 1] = sq_b1;
  flank_unmapv[ 2] = sq_c1;
  flank_unmapv[ 3] = sq_d1;
  flank_unmapv[ 4] = sq_a2;
  flank_unmapv[ 5] = sq_b2;
  flank_unmapv[ 6] = sq_c2;
  flank_unmapv[ 7] = sq_d2;
  flank_unmapv[ 8] = sq_a3;
  flank_unmapv[ 9] = sq_b3;
  flank_unmapv[10] = sq_c3;
  flank_unmapv[11] = sq_d3;
  flank_unmapv[12] = sq_a4;
  flank_unmapv[13] = sq_b4;
  flank_unmapv[14] = sq_c4;
  flank_unmapv[15] = sq_d4;
  flank_unmapv[16] = sq_a5;
  flank_unmapv[17] = sq_b5;
  flank_unmapv[18] = sq_c5;
  flank_unmapv[19] = sq_d5;
  flank_unmapv[20] = sq_a6;
  flank_unmapv[21] = sq_b6;
  flank_unmapv[22] = sq_c6;
  flank_unmapv[23] = sq_d6;
  flank_unmapv[24] = sq_a7;
  flank_unmapv[25] = sq_b7;
  flank_unmapv[26] = sq_c7;
  flank_unmapv[27] = sq_d7;
  flank_unmapv[28] = sq_a8;
  flank_unmapv[29] = sq_b8;
  flank_unmapv[30] = sq_c8;
  flank_unmapv[31] = sq_d8;

  /* initialize the triangle unmap */

  triangle_unmapv[0] = sq_a1;
  triangle_unmapv[1] = sq_b1;
  triangle_unmapv[2] = sq_c1;
  triangle_unmapv[3] = sq_d1;
  triangle_unmapv[4] = sq_b2;
  triangle_unmapv[5] = sq_c2;
  triangle_unmapv[6] = sq_d2;
  triangle_unmapv[7] = sq_c3;
  triangle_unmapv[8] = sq_d3;
  triangle_unmapv[9] = sq_d4;

  /* initialize the diagonal map (both long diagonals) */

  for (sq = sq_a1; sq <= sq_h8; sq++)
  {
    if ((map_rank(sq) == map_file(sq)) ||
      ((map_rank(sq) + map_file(sq)) == (fileL - 1)))
      diagonalv[sq] = 1;
    else
      diagonalv[sq] = 0;
  };

  /* reset the temporary file ordinal */

  tf_ordinal = 0;

  /* initialize the maximum mate/lose distances */

  for (c = c_w; c <= c_b; c++)
  {
    maxmatev[c] = 0;
    maxlosev[c] = -1;
  };
}

/*--> TBTerm: one time termination for the tablebase generator */
void TBTerm(void)
{
  tbidT tbid;
  cT c;

  /* release tablebase item storage */

  for (tbid = 0; tbid < tbidL; tbid++)
    TBTermTBID(tbid);

  /* deallocate the move generation vector */

  for (c = c_w; c <= c_b; c++)
  {
    TBMemoryFree(tbgmbaseptrv[c]);
    TBMemoryFree(tbrgmbaseptrv[c]);
  };

  /* deallocate the tablebase vector */

  TBMemoryFree(tbbaseptr);

  /* various deallocations */

  TBStringFree(class_str);
  TBStringFree(targetdir_strv[c_w]);
  TBStringFree(targetdir_strv[c_b]);
  TBStringFree(tmpdir_str);
  TBStringFree(refdir_str);
}
