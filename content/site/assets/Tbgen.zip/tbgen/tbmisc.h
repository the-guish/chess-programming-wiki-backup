/* >>> tbmisc.h: function prototypes for tablebase generator file tbmisc.c */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

void TBPrintPosition(tbptrT classptr, posvT posv);

liT TBGetSignature(distvT distv);
liT TBGetInvertedSignature(distvT distv);

tbidT TBLocateClass(distvT dist, siptrT invertptr);
tbidT TBClassFromString(charptrT s);

void TBCopyDistribution(distvT distv0, distvT distv1);
void TBCopyPosition(posvT posv0, posvT posv1);
void TBDumpDependencyVector(fptrT fptr, depvT depv, siT indent);
void TBSetDependencyVector(tbptrT class_ptr, cT c, depvT depv);
void TBPrintDependencies(fptrT fptr, tbptrT class_ptr, cT c, siT indent);
void TBPrintDependencyFile(charptrT fn);
void TBPrintRecursiveDependencies(
  fptrT fptr, tbptrT class_ptr, cT c, siT indent);
void TBPrintRecursiveDependencyFile(charptrT fn);

siT TBCountDependencies(depvT depv);

void TBPrintGenerationList(charptrT fn);
void TBSetPosVector(tbptrT class_ptr, indexT index, posvT posv);
void TBSetPosVectorNK(tbptrT class_ptr, indexT index, posvT posv);

sqT TBGetEPSQ(tbptrT class_ptr, cT c, indexT index);
siT TBOccupied(sqT sq, tbptrT class_ptr, posvT posv);
