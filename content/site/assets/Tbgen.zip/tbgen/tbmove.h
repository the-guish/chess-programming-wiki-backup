/* >>> tbmove.h: function prototypes for tablebase generator file tbmove.c */
/* Revised: 2004.09.03 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

void TBSetCurrentClass(tbidT current_class);
void TBSetCurrentActive(cT actc);
void TBClearBoard(void);
void TBSetBoard(sqT epsq, posvT posv);

siT TBAttacks(cT c, sqT sq);
siT TBKingInCheck(cT c);

void TBGenerate(void);
void TBRetrogen(void);
void TBExecute(tbmptrT tbmptr);
void TBRetract(tbmptrT tbmptr);

indexT TBPositionIndex(void);
indexT TBPositionIndexDual(void);

siT TBHasDual(void);
