/* >>> tbspin.c: position reflection and index generation for the generator */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

#include <stdio.h>
#include <stdlib.h>

#include "tbdefs.h"
#include "tbvars.h"

#include "tbmisc.h"
#include "tbspin.h"
#include "tbutil.h"

/*--> TBReflectX: reflect a position along the X axis */
void TBReflectX(tbptrT classptr, posvT posv)
{
	cT c;
	siT i;

	for (c = c_w; c <= c_b; c++)
		for (i = 0; i < classptr->tb_mcv[c]; i++)
			posv[c][i] ^= 0x38;
}

/*--> TBReflectY: reflect a position along the Y axis */
void TBReflectY(tbptrT classptr, posvT posv)
{
	cT c;
	siT i;

	for (c = c_w; c <= c_b; c++)
		for (i = 0; i < classptr->tb_mcv[c]; i++)
			posv[c][i] ^= 0x07;
}

/*--> TBReflectXY: reflect a position along the X=Y axis */
void TBReflectXY(tbptrT classptr, posvT posv)
{
	cT c;
	siT i;
	rankT rank;
	fileT file;

	for (c = c_w; c <= c_b; c++)
		for (i = 0; i < classptr->tb_mcv[c]; i++)
    {
			rank = map_rank(posv[c][i]);
			file = map_file(posv[c][i]);
			posv[c][i] = map_sq(file, rank);
		};
}

/*--> TBNormalize: normalize a position */
void TBNormalize(tbptrT classptr, posvT posv)
{
	sqT sq;
	cT pivot_c;
	siT pivot_slot;

	/* get pivot color and slot */

	pivot_c = classptr->tb_pivot_c;
	pivot_slot = classptr->tb_pivot_slot;

	/* determine normalization mode */

	if (classptr->tb_fold == fold_flank)
  {
		/* class has at least one pawn */

		sq = posv[pivot_c][pivot_slot];
		if (map_file(sq) > file_d)
			TBReflectY(classptr, posv);
	}
  else
  {
		/* class has no pawns */

		sq = posv[pivot_c][pivot_slot];
		if (map_rank(sq) > rank_4)
			TBReflectX(classptr, posv);

		sq = posv[pivot_c][pivot_slot];
		if (map_file(sq) > file_d)
			TBReflectY(classptr, posv);

		sq = posv[pivot_c][pivot_slot];
		if (map_rank(sq) > map_file(sq))
			TBReflectXY(classptr, posv);
	};
}

/*--> TBGenIndex: generate a file index for a class and position */
indexT TBGenIndex(tbptrT classptr, posvT posv)
{
	indexT index;
	liT factor = -1;
	posvT nposv;
	cT c;
	siT i;

	TBCopyPosition(posv, nposv);
	TBNormalize(classptr, nposv);

	index = 0;
	for (c = c_w; c <= c_b; c++)
		for (i = 0; i < classptr->tb_mcv[c]; i++)
    {
			switch (classptr->tb_scalev[c][i])
      {
			case sqL:
				factor = nposv[c][i];
				break;
			case ff_flankL:
				factor = flank_mapv[nposv[c][i]];
				break;
			case ff_triangleL:
				factor = triangle_mapv[nposv[c][i]];
				break;
			default:
				TBSwitchFault("TBGenIndex");
				break;
			};
			if (factor < 0)
      {
				printf("output: ");
				TBPrintPosition(classptr, nposv);
				printf("\n");
				TBFatal("TBGenIndex: negative factor");
			};
			index += factor * classptr->tb_multv[c][i];
		};

	return index;
}

/*--> TBGenIndexDual: generate a file dual index for a class and position */
indexT TBGenIndexDual(tbptrT classptr, posvT posv)
{
	indexT index;
	liT factor = -1;
	posvT nposv;
	cT c;
	siT i;

	TBCopyPosition(posv, nposv);
	TBNormalize(classptr, nposv);
	TBReflectXY(classptr, nposv);

	index = 0;
	for (c = c_w; c <= c_b; c++)
		for (i = 0; i < classptr->tb_mcv[c]; i++)
    {
			switch (classptr->tb_scalev[c][i])
      {
			case sqL:
				factor = nposv[c][i];
				break;
			case ff_flankL:
				factor = flank_mapv[nposv[c][i]];
				break;
			case ff_triangleL:
				factor = triangle_mapv[nposv[c][i]];
				break;
			default:
				TBSwitchFault("TBGenIndexDual");
				break;
			};
			if (factor < 0)
      {
				printf("output: ");
				TBPrintPosition(classptr, nposv);
				printf("\n");
				TBFatal("TBGenIndexDual: negative factor");
			};
			index += factor * classptr->tb_multv[c][i];
		};

	return index;
}

/*--> TBGenInvertIndex: generate a file index for a class and position (inverted) */
indexT TBGenInvertIndex(tbptrT classptr, posvT posv)
{
	indexT index;
	liT factor = -1;
	posvT nposv;
	cT c, invc;
	siT i;

	for (c = c_w; c <= c_b; c++)
  {
		invc = inv_cv[c];
		for (i = 0; i < classptr->tb_mcv[invc]; i++)
			nposv[invc][i] = posv[c][i];
	};

	if (classptr->tb_flags & tbf_has_pawns)
		TBReflectX(classptr, nposv);

	TBNormalize(classptr, nposv);

	index = 0;
	for (c = c_w; c <= c_b; c++)
  {
		for (i = 0; i < classptr->tb_mcv[c]; i++)
    {
			switch (classptr->tb_scalev[c][i])
      {
			case sqL:
				factor = nposv[c][i];
				break;
			case ff_flankL:
				factor = flank_mapv[nposv[c][i]];
				break;
			case ff_triangleL:
				factor = triangle_mapv[nposv[c][i]];
				break;
			default:
				TBSwitchFault("TBGenInvertIndex");
				break;
			};
			if (factor < 0)
      {
				printf("output: ");
				TBPrintPosition(classptr, nposv);
				printf("\n");
				TBFatal("TBGenInvertIndex: negative factor");
			};
			index += factor * classptr->tb_multv[c][i];
		};
	};

	return index;
}
