/* >>> tbvars.h: common variables for tablebase generator */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

/* constant value vectors */

extern char asccv[cL];
extern char ascpv[pL];
extern char ascrv[rankL];
extern char ascfv[fileL];

extern cT inv_cv[cL];

extern cpT cnv_cpv[rcL][rpL];
extern cT cnv_cv[cpL];
extern pT cnv_pv[cpL];

extern charptrT ctm_strv[rcL];
extern charptrT ctmext_strv[rcL];

extern rankT prom_rankv[rcL];

extern dvT dvv[dxL];
extern xdvT xdvv[dxL];

extern xbT xb;

 /* command argument strings */

extern charptrT class_str;
extern charptrT targetdir_strv[rcL];
extern charptrT tmpdir_str;
extern charptrT refdir_str;

/* the base pointer for the allocated main tablebase vector */

extern tbptrT tbbaseptr;

/* the base pointer vectors for generated and retrogenerated moves */

extern tbmptrT tbgmbaseptrv[rcL];
extern tbmptrT tbrgmbaseptrv[rcL];

/* generated and retrogenerated move count vectors */

extern siT tbgmcv[rcL];
extern siT tbrgmcv[rcL];

/* maps */

extern siT flank_mapv[sqL];
extern siT triangle_mapv[sqL];

/* unmaps */

extern sqT flank_unmapv[ff_flankL];
extern sqT triangle_unmapv[ff_triangleL];

/* the diagonal map (both long diagonals) */

extern siT diagonalv[sqL];

/* class under construction */

extern tbidT class_tbid;

/* temporary file ordinal */

extern liT tf_ordinal;

/* maximum mate/lose distances */

extern siT maxmatev[rcL];
extern siT maxlosev[rcL];
