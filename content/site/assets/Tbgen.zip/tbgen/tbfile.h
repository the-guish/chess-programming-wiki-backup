/* >>> tbfile.h: function prototypes for tablebase generator file tbfile.c */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

charptrT TBClassFileName(charptrT dirstr, tbidT tbid, cT c);
charptrT TBTempFileName(void);

void TBSetBuffer(fptrT fptr, liT length);
void TBSetBigBuffer(fptrT fptr);
void TBSetBiggerBuffer(fptrT fptr);
void TBCodeFileRemove(charptrT filename);

fptrT TBCodeFileOpenRead(charptrT filename);
fptrT TBCodeFileOpenReadSF(charptrT filename);
fptrT TBCodeFileOpenWrite(charptrT filename);

siT TBCodeFileClose(fptrT fptr);

void TBCodeFileCopy(charptrT fn_source, charptrT fn_target);
void TBCodeFileRename(charptrT fn_source, charptrT fn_target);
void TBTextFileRemove(charptrT filename);

fptrT TBTextFileOpenRead(charptrT filename);
fptrT TBTextFileOpenWrite(charptrT filename);

siT TBTextFileClose(fptrT fptr);

void TBTextFileCopy(charptrT fn_source, charptrT fn_target);
void TBTextFileRename(charptrT fn_source, charptrT fn_target);
