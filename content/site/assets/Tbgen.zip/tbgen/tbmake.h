/* >>> tbmake.h: function prototypes for tablebase generator file tbmake.c */
/* Revised: 2004.09.04 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

void TBAdjustHWM(cT c, bevT bev);
void TBMake(void);
