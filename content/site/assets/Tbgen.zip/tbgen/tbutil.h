/* >>> tbutil.h: function prototypes for tablebase generator file tbutil.c */
/* Revised: 2004.09.03 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

void TBCheckPoint(charptrT s);
void TBFatal(charptrT s);
void TBSwitchFault(charptrT s);

voidptrT TBMemoryGrab(liT n);
void TBMemoryFree(voidptrT ptr);

charptrT TBStringGrab(charptrT s);
void TBStringFree(charptrT ptr);

charptrT TBStringAppendChar(charptrT s, char c);
charptrT TBStringAppendStr(charptrT s0, charptrT s1);
