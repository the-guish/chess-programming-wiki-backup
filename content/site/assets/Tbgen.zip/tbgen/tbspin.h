/* >>> tbspin.h: function prototypes for tablebase generator file tbspin.c */
/* Revised: 2004.09.03 */
/* Copyright (C) 2004 by S. J. Edwards (chessnotation@mac.com) */
/* All rights reserved */

void TBReflectX(tbptrT classptr, posvT posv);
void TBReflectY(tbptrT classptr, posvT posv);
void TBReflectXY(tbptrT classptr, posvT posv);
void TBNormalize(tbptrT classptr, posvT posv);

indexT TBGenIndex(tbptrT classptr, posvT posv);
indexT TBGenIndexDual(tbptrT classptr, posvT posv);
indexT TBGenInvertIndex(tbptrT classptr, posvT posv);
