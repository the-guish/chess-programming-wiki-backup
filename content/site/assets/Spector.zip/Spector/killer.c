/*>>> killer.c: killer response move routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "killer.h"
#include "mu.h"
#include "predvar.h"
#include "sysutil.h"

/**** Locals */

/* return slot for counter killer move */

static smT counter_sm;

/*--> KillerTrioUpdate: update the kill trio */
nonstatic
void
KillerTrioUpdate(sqT frsq, sqT tosq)
{
gkmptrT gkmptr;
kmT km;

/* descale */

gkmptr = gkm_base + ply;
if (gkmptr->gkm_m0.km_usage == cpev_mate)
	{
	gkmptr->gkm_m0.km_usage /= 2;
	gkmptr->gkm_m1.km_usage /= 2;
	gkmptr->gkm_m1.km_usage /= 2;
	};

/* update */

if (gkmptr->gkm_m0.km_frsq == sq_nil)
	{
	gkmptr->gkm_m0.km_frsq = frsq;
	gkmptr->gkm_m0.km_tosq = tosq;
	gkmptr->gkm_m0.km_usage = 1;
	}
else
	{
	if ((gkmptr->gkm_m0.km_frsq == frsq) &&
		(gkmptr->gkm_m0.km_tosq == tosq))
		gkmptr->gkm_m0.km_usage++;
	else
		{
		if (gkmptr->gkm_m1.km_frsq == sq_nil)
			{
			gkmptr->gkm_m1.km_frsq = frsq;
			gkmptr->gkm_m1.km_tosq = tosq;
			gkmptr->gkm_m1.km_usage = 1;
			}
		else
			{
			if ((gkmptr->gkm_m1.km_frsq == frsq) &&
				(gkmptr->gkm_m1.km_tosq == tosq))
				{
				gkmptr->gkm_m1.km_usage++;
				if (gkmptr->gkm_m1.km_usage >
					gkmptr->gkm_m0.km_usage)
					{
					km = gkmptr->gkm_m0;
					gkmptr->gkm_m0 = gkmptr->gkm_m1;
					gkmptr->gkm_m1 = km;
					};
				}
			else
				{
				if (gkmptr->gkm_m2.km_frsq == sq_nil)
					{
					gkmptr->gkm_m2.km_frsq = frsq;
					gkmptr->gkm_m2.km_tosq = tosq;
					gkmptr->gkm_m2.km_usage = 1;
					}
				else
					{
					if ((gkmptr->gkm_m2.km_frsq == frsq) &&
						(gkmptr->gkm_m2.km_tosq == tosq))
						{
						gkmptr->gkm_m2.km_usage++;
						if (gkmptr->gkm_m2.km_usage >
							gkmptr->gkm_m1.km_usage)
							{
							km = gkmptr->gkm_m1;
							gkmptr->gkm_m1 = gkmptr->gkm_m2;
							gkmptr->gkm_m2 = km;
							if (gkmptr->gkm_m1.km_usage >
								gkmptr->gkm_m0.km_usage)
								{
								km = gkmptr->gkm_m0;
								gkmptr->gkm_m0 = gkmptr->gkm_m1;
								gkmptr->gkm_m1 = km;
								};
							};
						}
					else
						{
						gkmptr->gkm_m2.km_frsq = frsq;
						gkmptr->gkm_m2.km_tosq = tosq;
						gkmptr->gkm_m2.km_usage = 1;
						};
					};
				};
			};
		};
	};

return;
}

/*--> KillerBumpPop: increment killer move popularity */
nonstatic
void
KillerBumpPop(sqT frsq, sqT tosq)
{
siptrT siptr, rsiptr;
siT i;
siT pop;

siptr = killer_pop_base + offset_rcsqsq(actc, frsq, tosq);
if (*siptr == cpev_mate)
	{
	rsiptr = killer_pop_base + offset_rcsqsq(actc, sq_a1, sq_a1);
	for (i = 0; i < sqsqL; i++)
		{
		pop = (*rsiptr >> 1);
		*rsiptr++ = pop;
		};
	};

(*siptr)++;

return;
}

/*--> KillerSetCounter: set a counter move for a two move sequence */
nonstatic
void
KillerSetCounter(mptrT mptr0, mptrT mptr1, mptrT mptr2)
{
siT hash;
smptrT smptr;

if (!null_move_ref(mptr0) && !null_move_ref(mptr1) &&
	!null_move_ref(mptr2))
	{
	hash = (((mptr0->m_frsq ^ mptr0->m_tosq) << sqQ) |
		(mptr1->m_frsq ^ mptr1->m_tosq));

	smptr = counter_killer_base + (actc * sqsqL) + hash;

	smptr->sm_frsq = mptr2->m_frsq;
	smptr->sm_tosq = mptr2->m_tosq;
	};

return;
}

/*--> KillerGetCounter: set a counter move for a two move sequence */
nonstatic
smptrT
KillerGetCounter(mptrT mptr0, mptrT mptr1)
{
siT hash;
smptrT smptr;

if (!null_move_ref(mptr0) && !null_move_ref(mptr1))
	{
	hash = (((mptr0->m_frsq ^ mptr0->m_tosq) << sqQ) |
		(mptr1->m_frsq ^ mptr1->m_tosq));

	counter_sm = *(counter_killer_base + (actc * sqsqL) + hash);

	if (counter_sm.sm_frsq == sq_nil)
		smptr = NULL;
	else
		smptr = &counter_sm;
	}
else
	smptr = NULL;

return (smptr);
}

/*--> KillerReset: clear the killer move information */
nonstatic
void
KillerReset(void)
{
siT i;
gkmptrT gkmptr;
smptrT smptr0, smptr1;
siptrT siptr;

/* clear the ply indexed killer stuff */

gkmptr = gkm_base;
for (i = 0; i < plyL; i++)
	{
	/* clear the primary, secondary, and tertiary killer information */

	gkmptr->gkm_m0 = gkmptr->gkm_m1 = gkmptr->gkm_m2 = null_km;
	gkmptr++;
	};

/* clear the killer response and the killer popularity information */

smptr0 = killer_response_base;
smptr1 = counter_killer_base;
siptr = killer_pop_base;

for (i = 0; i < (rcL * sqsqL); i++)
	{
	*smptr0++ = null_sm;
	*smptr1++ = null_sm;
	*siptr++ = 0;
	};

return;
}

/*--> KillerPresetRepsonse: set response entries using PV carryover */
nonstatic
void
KillerPresetResponse(void)
{
siT length, i;
cT c;
mT hist_m;
histptrT histptr;
mptrT mptr0, mptr1;
smptrT smptr;

length = PVarELength();

/* process historical response */

if ((length > 0) && (histn > 0))
	{
	histptr = histcurr - 1;
	mptr0 = &hist_m;
	ConvertFromLimitedMove(&histptr->hist_lm, mptr0);
	mptr1 = PVarEMoveRef(0);
	c = inv_cv[cv_c_cpv[mptr0->m_frcp]];
	smptr = killer_response_base +
		offset_rcsqsq(c, mptr0->m_frsq, mptr0->m_tosq);
	smptr->sm_frsq = mptr1->m_frsq;
	smptr->sm_tosq = mptr1->m_tosq;
	};

/* process predicted response */

if (length > 1)
	for (i = 0; i < (length - 1); i++)
		{
		mptr0 = PVarEMoveRef(i);
		mptr1 = PVarEMoveRef(i + 1);
		c = inv_cv[cv_c_cpv[mptr0->m_frcp]];
		smptr = killer_response_base +
			offset_rcsqsq(c, mptr0->m_frsq, mptr0->m_tosq);
		smptr->sm_frsq = mptr1->m_frsq;
		smptr->sm_tosq = mptr1->m_tosq;
		};

return;
}

/*<<< killer.c: EOF */
