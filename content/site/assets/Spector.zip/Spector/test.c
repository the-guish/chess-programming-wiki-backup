/*>>> test.c: testing routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "epddefs.h"
#include "tbdefs.h"

#include "bbmacs.h"

#include "bb.h"
#include "epd.h"
#include "file.h"
#include "memutil.h"
#include "pred.h"
#include "print.h"
#include "sysutil.h"
#include "sx.h"
#include "tb.h"
#include "test.h"
#include "ts.h"
#include "util.h"
#include "voice.h"

#if (0)
/*--> TestAlign: test labeled alignment */
static
void
TestAlign(voidptrT s, voidptrT p)
{
liT v;

PrTwoStrs(s, " [");
PrPointer(p);
PrStr("]: ");

v = (liT) p;
if (v & (bit << 0))
	PrStr("byte");
else
	if (v & (bit << 1))
		PrStr("word");
	else
		if (v & (bit << 2))
			PrStr("longword");
		else
			if (v & (bit << 3))
				PrStr("quadword");
			else
				if (v & (bit << 4))
					PrStr("octoword");
				else
					if (v & (bit << 5))
						PrStr("hexaword");
					else
						PrStr("ALIGNED!");
PrNL();

return;
}
#endif

/*--> Test: main test entry */
nonstatic
void
Test(void)
{
#if (0)
{
mptrT mptr;

mptr = TSMate(level);
if (mptr == NULL)
	PrLine("No mate located");
else
	{
	PrStrSI("Located mate in ", level);
	if (level == 1)
		PrStr(" move");
	else
		PrStr(" moves");
	PrStrSANNL(": ", mptr);
	};

}
#endif

#if (0)
{
cpevT cpev;

cpev = TSEval();
PrStrCentipawn("TSEval: ", cpev);
PrNL();
}
#endif

#if (0)
{
extern mT trans_table_m;

/* alignment test */

PrLine("Alignment test");
PrNL();

TestAlign("         root_sptr", (voidptrT) root_sptr);
TestAlign("            &gen_m", (voidptrT) &gen_m);
TestAlign("    &trans_table_m", (voidptrT) &trans_table_m);
TestAlign("           sqbbv[]", (voidptrT) sqbbv);
TestAlign("           nmbbv[]", (voidptrT) nmbbv);
TestAlign("         &opposing", (voidptrT) &opposing);
TestAlign("           c0bbv[]", (voidptrT) c0bbv);
TestAlign("           atbbv[]", (voidptrT) atbbv);
TestAlign("           afbbv[]", (voidptrT) afbbv);
TestAlign("            &local", (voidptrT) &local);
TestAlign("            &gp_bb", (voidptrT) &gp_bb);
TestAlign("           &gp_abb", (voidptrT) &gp_abb);
TestAlign("            &board", (voidptrT) &board);
}
#endif

#if (1)
{
/* TB test */

siT invert;
tbidT tbid;
cpevT score;

tbid = TBDetectLocal(&invert);
PrStrSI("TBDetect: ", tbid);
PrStrSINL("   invert: ", invert);

if (tbid != tbid_nil)
	{
	score = TBScoreLocal(tbid, invert);
	PrStrCentipawnNL("score: ", score);
	};
}
#endif

#if (0)
{
/* EPD test */

fptrT f0ptr, f1ptr;
char bv[epdL];
epdptrT epdptr;
eopptrT eopptr;
charptrT s;

PrTwoStrsNL("file 0: ", ipv[1].ip_str);
PrTwoStrsNL("file 1: ", ipv[2].ip_str);

f0ptr = TextFileOpen(ipv[1].ip_str, "r");
f1ptr = TextFileOpen(ipv[2].ip_str, "w");

while (fgets(bv, epdL, f0ptr) != NULL)
	{
	PrStr(bv);
	epdptr = EPDDecode(bv);
	if (epdptr != NULL)
		{
		eopptr = EPDLocateEOP(epdptr, "sm");
		if (eopptr != NULL)
			{
			s = eopptr->eop_headeov->eov_str;
			eopptr = EPDLocateEOP(epdptr, "bm");
			if (eopptr != NULL)
				if (!EPDLocateEOV(eopptr, s))
					{
					s = EPDEncode(epdptr);
					fprintf(f1ptr, "%s\n", s);
					MemoryFree(s);
					};
			};
		EPDReleaseEPD(epdptr);
		};
	};

TextFileClose(f0ptr);
TextFileClose(f1ptr);
}
#endif

#if (0)
{
cpevT score;

/* static exchange test */

PrLine("Exchange test");

score = SXEval();
PrStrCentipawnNL("SXEval: ", score);
}
#endif

#if (0)
{
/* lone king mate test */

PrLine("Lone king mate test");

PrStrSINL("LoneKingMate: ", LoneKingMate());
}
#endif

#if (0)
{
cpT cp;

/* census test */

PrLine("Census test");
PrNL();

PrStr("ap: ");
PrBitBoardVector(apmbb);
PrStrSINL("  n: ", bb_count(apmbb));

PrStr("cw: ");
PrBitBoardVector(c0bbv[c_w]);
PrStrSINL("  n: ", bb_count(c0bbv[c_w]));

PrStr("cb: ");
PrBitBoardVector(c0bbv[c_b]);
PrStrSINL("  n: ", bb_count(c0bbv[c_b]));

PrNL();

for (cp = cp_wp; cp <= cp_bk; cp++)
	{
	PrColorPiece(cp);
	PrStr(": ");
	PrBitBoardVector(cpbbv[cp]);
	PrStrSINL("  n: ", bb_count(cpbbv[cp]));
	};
}
#endif

#if (0)
{
siT flag;

/* voice test */

PrLine("Voice test");
PrNL();

flag = VSSpeakPhrase("This is a test.");
PrStrSINL("flag: ", flag);
}
#endif

#if (0)
{
/* pause test */

Pause("Command input");
}
#endif

return;
}

/*<<< test.c: EOF */
