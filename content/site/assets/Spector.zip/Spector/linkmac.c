/*>>> linkmac.c: external player linkage utilities (macintosh) */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "link.h"
#include "linkmac.h"
#include "print.h"
#include "sysutil.h"
#include "util.h"

#if (os_mac)
#include <string.h>
#include <Devices.h>
#include <Serial.h>
#endif

/**** Locals */

#if (os_mac)

/* Mac channel control type */

typedef struct mccS
	{
	charptrT mcc_name[dfdL];	/* I/O channel names */
	bcbT     mcc_bcbv[dfdL];	/* I/O buffers */
	siT      mcc_refnum[dfdL];	/* reference number */
	} mccT, *mccptrT;

/* the two Mac channels (serial ports: modem and printer) */

static mccT mccv[channelL];

#endif

/**** Functions */

#if (os_mac)
/*--> LinkMacStat: return pending input character available count */
nonstatic
liT
LinkMacStat(channelT channel)
{
liT count;
OSErr ec;

count = 0;
ec = SerGetBuf(mccv[channel].mcc_refnum[dfd_in], &count);
if (ec != noErr)
	{
	count = -1;
	PrWarning("LinkMacStat: can't access serial input");
	};

return (count);
}

/*--> LinkMacGet: read from the serial input */
nonstatic
siT
LinkMacGet(channelT channel, byteptrT bptr, liT length)
{
siT flag;
OSErr ec;
mccptrT mccptr;
bcbptrT bcbptr;
liT count, index;

/* set default running */

flag = 1;

/* set mcc and bcb pointers */

mccptr = &mccv[channel];
bcbptr = &mccptr->mcc_bcbv[dfd_in];

/* test for open channel */

if (flag)
	if (!scsv[channel].scs_open)
		{
		flag = 0;
		PrWarning("LinkMacGet: channel not in use");
		};

/* test for available input */

if (flag)
	if (LinkMacStat(channel) < length)
		{
		flag = 0;
		PrWarning("LinkMacGet: insufficient input available");
		};

/* perform the read */

if (flag)
	{
	count = length;
	ec = FSRead(mccptr->mcc_refnum[dfd_in], &count, bcbptr->bcb_base);
	if ((ec != noErr) || (count != length))
		{
		flag = 0;
		PrWarning("LinkMacGet: read failure");
		};
	};

/* copy into formal output buffer */

if (flag)
	for (index = 0; index < length; index++)
		*(bptr + index) = *(bcbptr->bcb_base + index);

return (flag);
}

/*--> LinkMacPut: write to the serial output */
nonstatic
siT
LinkMacPut(channelT channel, byteptrT bptr, liT length)
{
siT flag, i, n;
OSErr ec;
mccptrT mccptr;
bcbptrT bcbptr;
liT count, index, slen;
charptrT s;
char ch;

/* set default running */

flag = 1;

/* set mcc and bcb pointers */

mccptr = &mccv[channel];
bcbptr = &mccptr->mcc_bcbv[dfd_out];

/* test for open channel */

if (flag)
	if (!scsv[channel].scs_open)
		{
		flag = 0;
		PrWarning("LinkMacPut: channel not in use");
		};

/* check overflow */

if (flag)
	if (bcbptr->bcb_length < length)
		{
		flag = 0;
		PrWarning("LinkMacPut: overflow");
		};

/* copy from formal output buffer */

if (flag)
	for (index = 0; index < length; index++)
		 *(bcbptr->bcb_base + index) = *(bptr + index);

/* perform the write */

if (flag)
	{
	count = length;
	ec = FSWrite(mccptr->mcc_refnum[dfd_out], &count, bcbptr->bcb_base);
	if ((ec != noErr) || (count != length))
		{
		flag = 0;
		PrWarning("LinkMacPut: write failure");
		};
	};

/* check for MicroVox suffix processing */

if (flag)
	if (scsv[channel].scs_rsc == rsc_microvox)
		{
		/* output the sync sequence */

		s = "!K#\r";
		slen = strlen(s);
		count = slen;
		ec = FSWrite(mccptr->mcc_refnum[dfd_out], &count, (byteptrT) s);
		if ((ec != noErr) || (count != slen))
			{
			flag = 0;
			PrWarning("LinkMacPut: sync failure 0");
			};

		/* wait for comeback */

		i = 0;
		n = 100;
		while ((LinkStat(channel) == 0) && (i < n))
			{
			Sleep(1);
			i++;
			};

		/* check result */

		if (LinkStat(channel) != 1)
			{
			flag = 0;
			PrWarning("LinkMacPut: sync failure 1");
			}
		else
			{
			/* get result */

			count = 1;
			ch = ascii_nul;
			ec = FSRead(mccptr->mcc_refnum[dfd_in], &count, (byteptrT) &ch);
			if ((ec != noErr) || (count != 1))
				{
				flag = 0;
				PrWarning("LinkMacPut: sync failure 2");
				}
			else
				if (ch != '#')
					{
					flag = 0;
					PrWarning("LinkMacPut: sync failure 3");
					};
			};
		};

return (flag);
}

/*--> LinkMacOpen: open Mac channel */
nonstatic
siT
LinkMacOpen(channelT channel)
{
siT flag, setting;
dfdT dfd;
bcbptrT bcbptr;
mccptrT mccptr;
OSErr ec;
SerShk handshake;
byteT byte;

/* set running flag */

flag = 1;

/* set Mac control channel pointer */

mccptr = &mccv[channel];

/* open serial input and output drivers */

if (flag)
	for (dfd = 0; dfd < dfdL; dfd++)
		{
		ec = OpenDriver((unsigned char *) mccptr->mcc_name[dfd],
			&mccptr->mcc_refnum[dfd]);
		if (ec != noErr)
			{
			flag = 0;
			PrWarning("LinkMacOpen: can't open driver");
			};
		};

/* send the kill I/O requests */

if (flag)
	for (dfd = 0; dfd < dfdL; dfd++)
		{
		ec = KillIO(mccptr->mcc_refnum[dfd]);
		if (ec != noErr)
			{
			flag = 0;
			PrWarning("LinkMacOpen: can't kill I/O");
			};
		};

/* set external buffer space */

if (flag)
	for (dfd = 0; dfd < dfdL; dfd++)
		{
		/* allocation */

		bcbptr = &mccptr->mcc_bcbv[dfd];
		BCBGrab(bcbptr, 1024);

		/* registration */

		ec = SerSetBuf(mccptr->mcc_refnum[dfd],
			(charptrT) bcbptr->bcb_base, bcbptr->bcb_length);
		if (ec != noErr)
			{
			flag = 0;
			PrWarning("LinkMacOpen: can't set external buffer");
			};
		};

/* reset link */

if (flag)
	{
	setting = baud9600 + data8 + stop10 + noParity;
	for (dfd = 0; dfd < dfdL; dfd++)
		{
		ec = SerReset(mccptr->mcc_refnum[dfd], setting);
		if (ec != noErr)
			{
			flag = 0;
			PrWarning("LinkMacOpen: can't reset link");
			};
		};
	};

/* set link handshaking */

if (flag)
	{
	/* set handshake (hardware flow control) */

	handshake.fXOn = 0;
	handshake.fCTS = 1;
	handshake.xOn = 0x11;
	handshake.xOff = 0x13;
	handshake.errs = 0;
	handshake.evts = 0;
	handshake.fInX = 0;
	handshake.fDTR = 1;

	/* register */

	for (dfd = 0; dfd < dfdL; dfd++)
		{
		ec = Control(mccptr->mcc_refnum[dfd], 14, &handshake);
		if (ec != noErr)
			{
			flag = 0;
			PrWarning("LinkMacOpen: can't set handshake");
			};
		};
	}
/* purge input */

while (flag && (LinkMacStat(channel) > 0))
	{
	flag = LinkMacGet(channel, &byte, 1);
	if (!flag)
		PrWarning("LinkMacOpen: can't purge");
	};

return (flag);
}

/*--> LinkMacClose: close Mac channel */
nonstatic
siT
LinkMacClose(channelT channel)
{
siT flag;
dfdT dfd;
mccptrT mccptr;
byteT byte;

/* set running flag */

flag = 1;

/* set Mac control channel pointer */

mccptr = &mccv[channel];

/* purge input */

while (flag && (LinkMacStat(channel) > 0))
	{
	flag = LinkMacGet(channel, &byte, 1);
	if (!flag)
		PrWarning("LinkMacClose: can't purge");
	};

/* close the drivers */

if (flag)
	for (dfd = 0; dfd < dfdL; dfd++)
		(void) CloseDriver(mccptr->mcc_refnum[dfd]);

/* free buffer space */

if (flag)
	for (dfd = 0; dfd < dfdL; dfd++)
		BCBFree(&mccptr->mcc_bcbv[dfd]);

return (flag);
}

/*--> LinkMacInit: one time Mac link initialization */
nonstatic
void
LinkMacInit(void)
{
channelT channel;
dfdT dfd;
bcbptrT bcbptr;

/* assign the primary channel names (modem port) */

mccv[0].mcc_name[dfd_in] = (charptrT) "\p.Ain";
mccv[0].mcc_name[dfd_out] = (charptrT) "\p.Aout";

/* assign the secondary channel names (printer port) */

mccv[1].mcc_name[dfd_in] = (charptrT) "\p.Bin";
mccv[1].mcc_name[dfd_out] = (charptrT) "\p.Bout";

/* clear the Mac channel buffers */

for (channel = 0; channel < channelL; channel++)
	for (dfd = 0; dfd < dfdL; dfd++)
		{
		bcbptr = &mccv[channel].mcc_bcbv[dfd];
		bcbptr->bcb_base = NULL;
		bcbptr->bcb_count = 0;
		bcbptr->bcb_length = 0;
		};

return;
}

/*--> LinkMacTerm: one time Mac link termination */
nonstatic
void
LinkMacTerm(void)
{
channelT channel;
dfdT dfd;
bcbptrT bcbptr;

/* ensure buffer release */

for (channel = 0; channel < channelL; channel++)
	for (dfd = 0; dfd < dfdL; dfd++)
		{
		bcbptr = &mccv[channel].mcc_bcbv[dfd];
		if (bcbptr->bcb_base != NULL)
			BCBFree(bcbptr);
		};

return;
}
#endif

/*<<< linkmac.c: EOF */
