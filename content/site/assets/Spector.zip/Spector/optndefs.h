/*>>> optndefs.h: option definitions */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* option name length */

#define optnnameL 4

/* option flags */

typedef siT optnT;
#define optnL 54

#define optn_adcb  0 /* automatic display chess board after move */
#define optn_adps  1 /* automatic display program status after move */
#define optn_amet  2 /* automatic move entry time adjust */
#define optn_apps  3 /* automatic program ponder search */
#define optn_asgc  4 /* automatic save game checkpoints */
#define optn_brep  5 /* beep on program move reply */
#define optn_dbug  6 /* general debugging */
#define optn_dwob  7 /* display is white on black background */
#define optn_echo  8 /* enable command input echo to dribble file */
#define optn_emde  9 /* extraordinary move disambiguation efforts */
#define optn_expn 10 /* expanded notation */
#define optn_flsh 11 /* force output file flushing */
#define optn_freq 12 /* report move execution frequency */
#define optn_nafm 13 /* no announcement of forced mates */
#define optn_napr 14 /* no auto program move reply */
#define optn_nbms 15 /* no opening book move search */
#define optn_ndpm 16 /* no display played move */
#define optn_nhtm 17 /* no hash table moves */
#define optn_nmde 18 /* no move disambiguation efforts */
#define optn_nocm 19 /* no oracular consultation moves */
#define optn_nqmr 20 /* no quick move response */
#define optn_obep 21 /* opening book compile: exp. position descriptions */
#define optn_obfc 22 /* opening book compile: file correction */
#define optn_obmp 23 /* opening book compile: write move path file */
#define optn_obrt 24 /* opening book compile: retain move tree */
#define optn_osnr 25 /* use ordinal string numeric representation */
#define optn_pbmp 26 /* packed book output: write move path file */
#define optn_pbtx 27 /* packed book output: write move tree file */
#define optn_poor 28 /* consider even poor book moves */
#define optn_rsgn 29 /* resignation offers/suggestions */
#define optn_spin 30 /* rotate board display by pi radians */
#define optn_temp 31 /* temporary usage development flag */
#define optn_teps 32 /* trace enable during ponder search */
#define optn_test 33 /* developer testing active */
#define optn_trab 34 /* trace: alpha beta search */
#define optn_trbc 35 /* trace: book compilation */
#define optn_trcs 36 /* trace: concept search */
#define optn_trel 37 /* trace: external link activity */
#define optn_tren 38 /* trace: descendant enumeration */
#define optn_trev 39 /* trace: position evaluation */
#define optn_trfd 40 /* trace: first time down tree search */
#define optn_trmp 41 /* trace: move path */
#define optn_trpm 42 /* trace: predicted move */
#define optn_trpt 43 /* trace: command processing time */
#define optn_trpv 44 /* trace: predicted variation */
#define optn_trpz 45 /* trace: ply zero move pick */
#define optn_trrs 46 /* trace: refutation sequences */
#define optn_trst 47 /* trace: search termination reason */
#define optn_trts 48 /* trace: timestamp trace */
#define optn_trtt 49 /* trace: transposition table subsystem */
#define optn_verb 50 /* verbose mode */
#define optn_vsyn 51 /* voice synthesizer */
#define optn_wump 52 /* announce opponent's forced mates */
#define optn_xtra 53 /* extra option */

/*<<< optndefs.h: EOF */
