/*>>> sysutil.h: subprogram prototypes for sysutil.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

liT GetProcessID(void);
void Pause(charptrT s);
void Acknowledge(charptrT s);
void Diagnose(charptrT s);
void DiagnoseTwo(charptrT s0, charptrT s1);
void Overflow(charptrT s);
void SwitchFault(charptrT s);
void Fault(charptrT s);
void Noop(void);
void Beep(siT n);
void TimeStampAt(time_t tval, stampT stamp);
void TimeStamp(stampT stamp);
void SyncSecond(void);
void Sleep(siT n);
void EncodeTimeRecord(liT t, timerecptrT trptr);
siT PsuedoRandomByte(void);
void Transfer(void);

/*<<< util.h: EOF */
