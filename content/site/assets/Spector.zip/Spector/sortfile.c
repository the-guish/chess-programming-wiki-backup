/*>>> sortfile.c: sort text file */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <ctype.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "file.h"
#include "memutil.h"
#include "print.h"
#include "sortfile.h"
#include "sysutil.h"

#define buf1L 4096
#define buf2L (256 * 1024L)

/**** Locals */

static fptrT i_fp, o_fp;

static charptrT tfnv[2][2];
static fptrT tfpv[2][2];

static siT done;
static siT pass;
static liT runlen0, runlen1;

static liT count;

/*--> Split: perform initial load and split */
static
void
Split(void)
{
siT j;
char bv[buf1L];

/* clear total record count */

count = 0;

/* open output files */

for (j = 0; j < 2; j++)
	{
	tfpv[0][j] = TextFileOpen(tfnv[0][j], "w");
	if (tfpv[0][j] == NULL)
		Diagnose("Can't open temporary file for writing");
	SetBuffer(tfpv[0][j], buf2L);
	};

/* load records */

while (fgets(bv, buf1L, i_fp) != NULL)
	{
	fprintf(tfpv[0][count % 2], "%s", bv);
	count++;
	};

/* close output files */

for (j = 0; j < 2; j++)
	TextFileClose(tfpv[0][j]);

return;
}

/*--> Scan: perform a single scan */
static
void
Scan(void)
{
siT i, j;
siT ri, wi;
siT eofv[2];
siT bfv[2];
liT rcv[2];
char bv[2][buf1L];
liT index;
liT length;

/* set indices according to pass count */

ri = pass % 2;
wi = (pass + 1) % 2;

/* open input files */

for (i = 0; i < 2; i++)
	{
	tfpv[ri][i] = TextFileOpen(tfnv[ri][i], "r");
	if (tfpv[ri][i] == NULL)
		Diagnose("Can't open temporary file for reading");
	SetBuffer(tfpv[ri][i], buf2L);
	};

/* open output files */

for (j = 0; j < 2; j++)
	{
	tfpv[wi][j] = TextFileOpen(tfnv[wi][j], "w");
	if (tfpv[wi][j] == NULL)
		Diagnose("Can't open temporary file for writing");
	SetBuffer(tfpv[wi][j], buf2L);
	};

/* clear eof markers  */

for (i = 0; i < 2; i++)
	eofv[i] = 0;

/* generate output data */

j = 0;
index = 0;
while (index < count)
	{
	/* clear buffer flags and run counts */

	for (i = 0; i < 2; i++)
		{
		bfv[i] = 0;
		rcv[i] = 0;
		};

	/* preload buffers */

	for (i = 0; i < 2; i++)
		if (!eofv[i])
			if (fgets(bv[i], buf1L, tfpv[ri][i]) == NULL)
				eofv[i] = 1;
			else
				{
				index++;
				bfv[i] = 1;
				rcv[i]++;
				length = strlen(bv[i]);
				if ((length > 0) && (bv[i][length - 1] == '\n'))
					bv[i][length - 1] = '\0';
				};

	while (bfv[0] || bfv[1])
		{
		/* dump the lesser valued buffer */

		if (bfv[0])
			{
			if (bfv[1])
				{
				if (strcmp(bv[0], bv[1]) <= 0)
					{
					fprintf(tfpv[wi][j], "%s\n", bv[0]);
					bfv[0] = 0;
					}
				else
					{
					fprintf(tfpv[wi][j], "%s\n", bv[1]);
					bfv[1] = 0;
					}
				}
			else
				{
				fprintf(tfpv[wi][j], "%s\n", bv[0]);
				bfv[0] = 0;
				}
			}
		else
			{
			if (bfv[1])
				{
				fprintf(tfpv[wi][j], "%s\n", bv[1]);
				bfv[1] = 0;
				};
			};

		/* reload buffers as needed */

		for (i = 0; i < 2; i++)
			if (!eofv[i] && !bfv[i] && (rcv[i] < runlen0))
				if (fgets(bv[i], buf1L, tfpv[ri][i]) == NULL)
					eofv[i] = 1;
				else
					{
					index++;
					bfv[i] = 1;
					rcv[i]++;
					length = strlen(bv[i]);
					if ((length > 0) && (bv[i][length - 1] == '\n'))
						bv[i][length - 1] = '\0';
					};
		};

	j ^= 1;
	};

/* close input files */

for (i = 0; i < 2; i++)
	TextFileClose(tfpv[ri][i]);

/* close output files */

for (j = 0; j < 2; j++)
	TextFileClose(tfpv[wi][j]);

/* test for completion */

if (runlen1 >= count)
	done = 1;

/* delete input files if done */

if (done)
	for (i = 0; i < 2; i++)
		remove(tfnv[ri][i]);

/* form output file contents if done */

if (done)
	{
	if ((tfpv[wi][0] = TextFileOpen(tfnv[wi][0], "r")) == NULL)
		Diagnose("Can't open temp file for transcription");
	SetBuffer(tfpv[wi][0], buf2L);
	while (fgets(bv[0], buf1L, tfpv[wi][0]) != NULL)
		fputs(bv[0], o_fp);

	TextFileClose(tfpv[wi][0]);
	};

return;
}

/*--> SortTextFile: sort text file; input to output */
nonstatic
void
SortTextFile(charptrT i_fn, charptrT o_fn)
{
siT flag, i, j, pid;
char tv[tL];

/* set up */

flag = 1;
i_fp = o_fp = NULL;
pass = 0;
done = 0;
runlen0 = 1;
runlen1 = runlen0 * 2;

for (j = 0; j < 2; j++)
	for (i = 0; i < 2; i++)
		tfnv[j][i] = NULL;

/* open input file */

if (flag)
	if ((i_fp = TextFileOpen(i_fn, "r")) == NULL)
		{
		PrErr("Can't open input file");
		flag = 0;
		};

/* open output file */

if (flag)
	if ((o_fp = TextFileOpen(o_fn, "w")) == NULL)
		{
		PrErr("Can't open output file");
		flag = 0;
		};

/* set up temporary file names */

if (flag)
	{
	pid = GetProcessID();
	for (j = 0; j < 2; j++)
		for (i = 0; i < 2; i++)
			{
			sprintf(tv, "tmp%04hx.%hd%hd.ms", pid, j, i);
			tfnv[j][i] = StringGrab(tv);
			};
	};

/* sort */

if (flag)
	{
	/* perform initial split */

	Split();

	/* loop until complete */

	while (!done)
		{
		if (optnv[optn_verb])
			PrStrSINL("pass: ", pass);
		Scan();
		if (!done)
			{
			pass++;
			runlen0 = runlen1;
			runlen1 = runlen0 * 2;
			};
		};
	};

/* clean up temporary files */

for (j = 0; j < 2; j++)
	for (i = 0; i < 2; i++)
		if (tfnv[j][i] != NULL)
			{
			remove(tfnv[j][i]);
			MemoryFree(tfnv[j][i]);
			};

/* close files */

if (i_fp != NULL)
	TextFileClose(i_fp);
if (o_fp != NULL)
	TextFileClose(o_fp);

return;
}

/*<<< sortfile.c: EOF */
