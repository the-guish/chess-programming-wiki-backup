/*>>> refute.c: refutation sequence processing routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "draw.h"
#include "exec.h"
#include "memutil.h"
#include "moveset.h"
#include "mu.h"
#include "predvar.h"
#include "print.h"
#include "refute.h"
#include "tt.h"

/**** Macros */

/* macro to reference a refutation sequence length */

#define refute_length(n) *(refute_length_base + (n))

/* macro to reference a refutation move via pointer */

#define refute_move_ref(index, ply) \
	(refute_move_base + ((index) * plyL) + (ply))

/**** Statics */

/* pointer to refutation sequence length vector */

static siptrT refute_length_base;

/* pointer to refutation move matrix */

static lmptrT refute_move_base;

/* number of entries in refutation move matrix */

static siT refute_count;

/* storage for a move returned by reference */

static mT refute_move;

/*--> RefuteStart: set up refutation subsystem for the start of a search */
nonstatic
void
RefuteStart(void)
{
siT i;
lmT lm;

/* set the refutation sequence count */

refute_count = root_sptr->s_count * plyL;

/* allocate refutation length vector */

refute_length_base = (siptrT) MemoryGrab(root_sptr->s_count * sizeof(siT));

/* allocate refutation move matrix */

refute_move_base = (lmptrT) MemoryGrab(refute_count * sizeof(lmT));

/* process the refutation length vector */

for (i = 0; i < root_sptr->s_count; i++)
	{
	/* set the first move of the refutation sequence */

	ConvertToLimitedMove((root_sptr->s_mbase + i), &lm);
	*refute_move_ref(i, 0) = lm;

	/* set the sequence initial length */

	refute_length(i) = 1;
	};

return;
}

/*--> RefuteFinish: close refutation subsystem at the end of a search */
nonstatic
void
RefuteFinish(void)
{
/* free refutation length vector */

MemoryFree(refute_length_base);

/* free refutation move matrix */

MemoryFree(refute_move_base);

return;
}

/*--> RefuteDump: dump the entire contents of the refutation subsystem */
nonstatic
void
RefuteDump(void)
{
siT i, j, length;
mT m;

for (i = 0; i < root_sptr->s_count; i++)
	{
	length = refute_length(i);
	for (j = 0; j < length; j++)
		{
		ConvertFromLimitedMove(refute_move_ref(i, j), &m);
		PrSAN(&m);
		if (j < (length - 1))
			PrBlank();
		};
	PrNL();
	};

return;
}

/*--> RefuteShift: shift the nth sequence to the top of the matrix */
nonstatic
void
RefuteShift(siT offset)
{
siT i, j, length, save_length;
lmT save_lmv[plyL];

if (offset != 0)
	{
	/* make a copy of the indicated sequence */

	save_length = refute_length(offset);
	for (j = 0; j < save_length; j++)
		save_lmv[j] = *refute_move_ref(offset, j);

	/* move each interspace sequence down one step */

	for (i = offset; i > 0; i--)
		{
		length = refute_length(i) = refute_length(i - 1);
		for (j = 0; j < length; j++)
			*refute_move_ref(i, j) = *refute_move_ref((i - 1), j);
		};

	/* copy indicated sequence to first place */

	refute_length(0) = save_length;
	for (j = 0; j < save_length; j++)
		*refute_move_ref(0, j) = save_lmv[j];
	};

return;
}

/*--> RefuteExchange: exchange two refutation sequences */
nonstatic
void
RefuteExchange(siT i0, siT i1)
{
siT i;
siT length0, length1;
lmT save_lmv[plyL];

length0 = refute_length(i0);
length1 = refute_length(i1);

/* save the first sequence */

for (i = 0; i < length0; i++)
	save_lmv[i] = *refute_move_ref(i0, i);

/* copy the second sequence */

for (i = 0; i < length1; i++)
	*refute_move_ref(i0, i) = *refute_move_ref(i1, i);

/* restore the first sequence */

for (i = 0; i < length0; i++)
	*refute_move_ref(i1, i) = save_lmv[i];

return;
}

/*--> RefuteTraceSequence: print refutation sequence trace */
static
void
RefuteTraceSequence(siT offset)
{
siT i, length;
mT m;

/* process trace */

if (optnv[optn_trrs] && ponder_trace)
	{
	length = refute_length(offset);
	PrTrace("RS");
	PrStrSI("[", length);
	PrChar(']');
	for (i = 0; i < length; i++)
		{
		ConvertFromLimitedMove(refute_move_ref(offset, i), &m);
		PrStrSAN(" ", &m);
		};
	PrNL();
	};

return;
}

/*--> RefuteBindSequence: connect from ply 1 predicted variation */
nonstatic
void
RefuteBindSequence(void)
{
siT i, index, length;
mptrT mptr;
mT m;

/* calculate the move index from the root moveset */

index = CurrentPlyZeroMoveIndex();

/* calculate the length of the subsequence */

length = PVarWMSubLength();

/* set the new length in the refutation length vector */

refute_length(index) = length;

/* copy the subvariation starting at ply 1 */

for (i = 1; i < length; i++)
	*refute_move_ref(index, i) = *PVarWMSubRef(i);

/* extend the move sequence using the T-table */

for (i = 0; i < length; i++)
	{
	ConvertFromLimitedMove(refute_move_ref(index, i), &m);
	ExecuteMove(&m);
	};

/* T-table probe loop */

while ((ply < (plyL - 1)) && !DrawTestPartial() &&
	((mptr = TTFetchMoveExact()) != NULL))
	{
	ConvertToLimitedMove(mptr, refute_move_ref(index, ply));
	ExecuteMove(mptr);
	};
refute_length(index) = ply;

/* retract entire WM base PV */

while (ply > 0)
	{
	ConvertFromLimitedMove(refute_move_ref(index, (ply - 1)), &m);
	RetractMove(&m);
	};

/* process trace */

RefuteTraceSequence(index);

return;
}

/*--> RefuteFetchMoveRef: return a move pointer (if any) as a refutation */
nonstatic
mptrT
RefuteFetchMoveRef(void)
{
mptrT mptr;
siT index;

/* calculate the move index from the root moveset */

if (root_sptr->s_mcurr == NULL)
	mptr = NULL;
else
	{
	index = CurrentPlyZeroMoveIndex();

	/* test refutation sequence length */

	if (refute_length(index) <= ply)
		mptr = NULL;
	else
		{
		ConvertFromLimitedMove(refute_move_ref(index, ply), &refute_move);
		mptr = &refute_move;
		};
	};

return (mptr);
}

/*--> RefuteCurrentLength: return length of current refutation sequence */
nonstatic
siT
RefuteCurrentLength(void)
{

return (refute_length(CurrentPlyZeroMoveIndex()));
}

/*<<< refute.c: EOF */
