/*>>> pcmove.c: process move playing and move searching routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "commdefs.h"
#include "commvars.h"

#include "hist.h"
#include "memutil.h"
#include "mm.h"
#include "moveset.h"
#include "pcmove.h"
#include "play.h"
#include "ponder.h"
#include "print.h"
#include "san.h"
#include "select.h"
#include "stat.h"
#include "sysutil.h"
#include "tbplay.h"
#include "ts.h"
#include "voice.h"

/*--> ProcessGAME: process calculate and play to end of game */
nonstatic
void
ProcessGAME(void)
{
gsT gs;

if ((gs = GameStatus(root_sptr)) != gs_norm)
	PrStrGameStatusNL("Game is already over: ", gs);
else
	{
	stop_play = 0;
	do
		{
		SyncSecond();
		ProgramMove();
		}
	while (GameStatusNormal(root_sptr) && !stop_play);
	};

return;
}

/*--> ProcessMATE: process search for mate in -n- moves */
nonstatic
void
ProcessMATE(void)
{
siT n;
gsT gs;
mptrT mptr, rptr;

if ((gs = GameStatus(root_sptr)) != gs_norm)
	PrStrGameStatusNL("Can't find mate: ", gs);
else
	{
	n = ipv[1].ip_sint;
	if ((n < 1) || (n > (plyL >> 1)))
		PrErr("Mate search out of range");
	else
		{
		/* synchronize to the start of the next second */

		SyncSecond();

		/* search for a forced mate */

		mptr = TSTMate(n);
		if (mptr == NULL)
			PrLine("No mate located.");
		else
			{
			rptr = FindMoveNF(mptr, root_sptr, "ProcessMATE");
			PrStrSI("Located mate in ", n);
			if (n == 1)
				PrStr(" move.");
			else
				PrStr(" moves.");
			PrStrSANNL("  Key move: ", rptr);
			};

		if (optnv[optn_freq])
			PrFrequencyReport(fms_nodes, fms_seconds);
		};
	};

return;
}

/*--> ProcessPGOS: process play game oracular sequence */
nonstatic
void
ProcessPGOS(void)
{
TBPlay();

return;
}

/*--> ProcessPLAY: process calculate and play one or more moves */
nonstatic
void
ProcessPLAY(void)
{
gsT gs;
siT i, limit;

i = 0;
limit = ((tkn == 2) ? ipv[1].ip_sint : 1);
if ((gs = GameStatus(root_sptr)) != gs_norm)
	PrStrGameStatusNL("Can't play: ", gs);
else
	{
	/* select and play moves until game ends, limit expires, or interrupt */

	stop_play = 0;
	while (GameStatusNormal(root_sptr) && (i < limit) && !stop_play)
		{
		SyncSecond();
		ProgramMove();
		i++;
		};

	/* process ponder moves */

	if (GameStatusNormal(root_sptr) && !stop_play)
		{
		/* process ponder search check */

		if (optnv[optn_apps])
			do
				{
				PonderSearch();
				}
			while (ponder_match);
		};
	};

return;
}

/*--> ProcessPOND: process ponder search */
nonstatic
void
ProcessPOND(void)
{
PonderSearch();

return;
}

/*--> ProcessRTMV: process retract move */
nonstatic
void
ProcessRTMV(void)
{
siT i, limit;

if (PositionCensusOkay())
	{
	limit = ((tkn == 2) ? ipv[1].ip_sint : 1);
	if (limit > histn)
		{
		PrStr("Can only retract ");
		PrCondOrdSI(histn);
		PrStr(" move");
		if (histn != 1)
			PrChar('s');
		PrCharNL('.');
		limit = histn;
		};
	if (limit > 0)
		{
		for (i = 0; i < (limit - 1); i++)
			HistoryDrop();
		UnplayMove();
		};
	};

return;
}

/*--> ProcessSRCH: process search for a move from a target list */
nonstatic
void
ProcessSRCH(void)
{
gsT gs;
siT flag, i, smflag, fmflag;
mptrT mptr;
mlstptrT mlstptr, mlstptr1;
time_t mark_secs, used_secs;
liT mark_node, used_node;

/* examine game status */

if ((gs = GameStatus(root_sptr)) != gs_norm)
	PrStrGameStatusNL("Can't search: ", gs);
else
	{
	/* attempt to match all moves on target list */

	flag = 1;
	i = 1;
	while (flag && (i < tkn))
		if ((mptr = MatchMove(ipv[i].ip_str, root_sptr)) == NULL)
			{
			PrTwoStrsNL("Can't match designated move: ", ipv[i].ip_str);
			flag = 0;
			}
		else
			i++;

	/* construct movelist */

	if (flag)
		{
		mlstptr1 = NULL;

		for (i = 1; i < tkn; i++)
			{
			/* allocate and initialize */

			mlstptr = (mlstptrT) MemoryGrab(sizeof(mlstT));
			mlstptr->mlst_mptr = MemoryGrab(sizeof(mT));
			*mlstptr->mlst_mptr = *MatchMove(ipv[i].ip_str, root_sptr);
			mlstptr->mlst_next = NULL;

			/* thread */

			if (mlstptr1 == NULL)
				target_mlstptr = mlstptr;
			else
				mlstptr1->mlst_next = mlstptr;

			/* set up for next link */

			mlstptr1 = mlstptr;
			};
		};

	/* perform search */

	if (flag)
		{
		/* sort move list in place */

		SANSortMoveList(target_mlstptr);

		/* synchronize to the start of the next second */

		SyncSecond();

		/* set starting time and exec mark values */

		mark_secs = time(NULL);
		mark_node = count_node;

		/* search for a move */

		SelectMove();

		/* set used time and exec values */

		used_secs = time(NULL) - mark_secs;
		used_node = count_node - mark_node;

		/* insure time nonzero */

		if (used_secs == 0)
			used_secs = 1;

		/* test result */

		if (LocateListMoveEntry(root_sptr->s_mbest, target_mlstptr) == NULL)
			{
			smflag = 0;
			PrStrSAN("Target move unfound.  Result: ", root_sptr->s_mbest);
			PrStr("   Target set: {");
			mlstptr = target_mlstptr;
			while (mlstptr != NULL)
				{
				PrSAN(mlstptr->mlst_mptr);
				mlstptr = mlstptr->mlst_next;
				if (mlstptr != NULL)
					PrBlank();
				};
			PrCharNL('}');
			if (optnv[optn_vsyn])
				{
				(void) VSSpeakPhrase("Target move was not found.");
				(void) VSSpeakStringMove("Result: ", root_sptr->s_mbest);
				};
			}
		else
			{
			smflag = 1;
			PrStrSAN("Target move located.  Result: ", root_sptr->s_mbest);
			PrStr("   Target set: {");
			mlstptr = target_mlstptr;
			while (mlstptr != NULL)
				{
				PrSAN(mlstptr->mlst_mptr);
				mlstptr = mlstptr->mlst_next;
				if (mlstptr != NULL)
					PrBlank();
				};
			PrCharNL('}');
			if (optnv[optn_vsyn])
				{
				(void) VSSpeakPhrase("Target move was found.");
				(void) VSSpeakStringMove("Result: ", root_sptr->s_mbest);
				};
			};

		/* forced mate found? */

		if (ct_mate(expectation))
			fmflag = 1;
		else
			fmflag = 0;

		/* output data scan line */

		(void) sprintf(stv, "*srch: %hd   [%02hd/%1hd]",
			smflag, strc, fmflag);
		PrSTV();
		PrStrLI("   secs: ", used_secs);
		PrStrLINL("   node: ", used_node);
		};
	};

/* deallocate target movelist */

if (target_mlstptr != NULL)
	{
	FreeMoveList(target_mlstptr);
	target_mlstptr = NULL;
	};

return;
}

/*<<< pcmove.c: EOF */
