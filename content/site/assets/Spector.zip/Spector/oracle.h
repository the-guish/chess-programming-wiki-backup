/*>>> oracle.h: subprogram prototypes for oracle.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

cpevT OracularEvaluate(void);
siT OracularMark(sptrT sptr);
cpevT OracularScore(sptrT sptr);
mptrT OracularSearch(void);

/*<<< oracle.h: EOF */
