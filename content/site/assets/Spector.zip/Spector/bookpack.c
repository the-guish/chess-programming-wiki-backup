/*>>> bookpack.c: opening book pack file generation routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bookdefs.h"
#include "bookvars.h"

#include "bookpack.h"
#include "bookutil.h"
#include "exec.h"
#include "file.h"
#include "init.h"
#include "memutil.h"
#include "moveset.h"
#include "mu.h"
#include "notation.h"
#include "print.h"
#include "util.h"

/*--> ListBookPackpNodeSort: sort scan order for pobc node processing */
static
void
ListBookPackpNodeSort(siT count, sptrT sptr, obcptrT obcptr, siptrT ivec)
{
siT i0, i1, flag, pass, pair;
sanT san0, san1;

/* initialize the scanning order index vector */

for (i0 = 0; i0 < count; i0++)
	*(ivec + i0) = i0;

/* sort the index vector using SAN output of the sptr moveset for keys */

if (count > 1)
	{
	/* set up pass loop */

	flag = 1;
	pass = 0;
	while (flag && (pass < (count - 1)))
		{
		/* set up pair loop */

		flag = 0;
		pair = 0;
		while (pair < (count - pass - 1))
			{
			/* get key indices */

			i0 = *(ivec + pair);
			i1 = *(ivec + pair + 1);

			/* continue if second entry is not vacant */

			if ((obcptr + i1)->obc_count > 0)
				{
				/* check if first entry is vacant */

				if ((obcptr + i0)->obc_count == 0)
					{
					/* exchange entries */

					*(ivec + pair) = i1;
					*(ivec + pair + 1) = i0;
					flag = 1;
					}
				else
					{
					/* compare two non-vacant entries */

					ConstructNotation(global_nm, (sptr->s_mbase + i0), san0);
					ConstructNotation(global_nm, (sptr->s_mbase + i1), san1);
					if (strcmp(san0,  san1) > 0)
						{
						/* exchange entries */

						*(ivec + pair) = i1;
						*(ivec + pair + 1) = i0;
						flag = 1;
						}
					};
				};

			/* next pair */

			pair++;
			};

		/* next pass */

		if (flag)
			pass++;
		};
	};

return;
}

/*--> ListBookPackpNode: pack opening book code file node processing */
static
void
ListBookPackpNode(mptrT mptr)
{
siT count, i, j, iply, index, v;
obcptrT obcptr;
sptrT sptr, psptr;
siptrT ivec;

/* get generated moves for this level */

if ((sptr = mptr->m_dptr) == NULL)
	{
	MovesetGenerateConnect(mptr);
	sptr = mptr->m_dptr;
	MovesetFullExpand(sptr, 0);
	};

/* allocate the census vector storage */

count = sptr->s_count;
obcptr = ListBookNewOBC(sptr);

/* get book census on already opened code file */

(void) ListBookCensus((charptrT) NULL, sptr, obcptr);

/* count number of book moves for this position */

v = 0;
for (i = 0; i < count; i++)
	if ((obcptr + i)->obc_count > 0)
		v++;
booktmn += v;

/* need at least one variation for further recursion */

if (v == 0)
	{
	/* end of variation, move path print */

	if (optnv[optn_pbmp])
		{
		psptr = root_sptr;
		for (iply = 0; iply < ply; iply++)
			{
			if (iply != 0)
				(void) fputc(ascii_sp, fp_obmp);
			ConstructNotation(global_nm, psptr->s_mcurr, bookcsm);
			(void) fprintf(fp_obmp, "%s", bookcsm);
			if (psptr->s_mcurr->m_flag & mf_poor)
				(void) fputc(bkchar_poormv, fp_obmp);
			psptr = psptr->s_mcurr->m_dptr;
			};
		(void) fputc('\n', fp_obmp);
		};
	}
else
	{
	/* set up the scanning order index vector */

	ivec = (siptrT) MemoryGrab(sizeof(siT) * count);
	ListBookPackpNodeSort(count, sptr, obcptr, ivec);

	/* scan the first -v- moves using index vector order */

	for (index = 0; index < v; index++)
		{
		/* get the move generation ordinal */

		i = *(ivec + index);

		/* select the move */

		sptr->s_mcurr = sptr->s_mbase + i;

		/* opening parenthesis */

		if ((v > 1) || (ply == 0))
			{
			booktvn++;
			ListBookCodePutControl(bkcntl_bvar);

			if (optnv[optn_pbtx])
				{
				if (!bkcmt)
					(void) fputc('\n', fp_pctx);
				for (j = 0; j < ply; j++)
					(void) fputc(ascii_sp, fp_pctx);
				(void) fputc(bkchar_varbgn, fp_pctx);
				};

			if (optnv[optn_trbc])
				{
				if (!bkcmt)
					PrChar('\n');
				for (j = 0; j < ply; j++)
					PrChar(ascii_sp);
				PrChar(bkchar_varbgn);
				};

			/* clear the one shot formatting flag */

			bkcmt = 0;

			};

		/* output the move */

		if ((obcptr + i)->obc_pflag)
			ListBookCodePutAnnotatedMove(i, bkanno_poor);
		else
			ListBookCodePutMove(i);

		if (optnv[optn_pbtx])
			{
			if ((v == 1) && (ply != 0))
				(void) fputc(ascii_sp, fp_pctx);
			ConstructNotation(global_nm, sptr->s_mcurr, bookcsm);
			(void) fprintf(fp_pctx,"%s", bookcsm);
			if ((obcptr + i)->obc_pflag)
				(void) fputc(bkchar_poormv, fp_pctx);
			};

		if (optnv[optn_trbc])
			{
			if ((v == 1) && (ply != 0))
				PrChar(ascii_sp);
			ConstructNotation(global_nm, sptr->s_mcurr, bookcsm);
			PrStr(bookcsm);
			if ((obcptr + i)->obc_pflag)
				PrChar(bkchar_poormv);
			(void) TextFileFlush(stdout);
			};

		/* record, execute, recurse, and retract */

		*(cordbase + ply) = i;
		ExecuteMove(sptr->s_mcurr);
		ListBookPackpNode(sptr->s_mcurr);
		RetractMove(sptr->s_mcurr);
		sptr->s_mcurr = NULL;

		/* closing parenthesis */

		if ((v > 1) || (ply == 0))
			{
			booktln += ply;

			ListBookCodePutControl(bkcntl_evar);

			if (optnv[optn_pbtx])
				(void) fputc(bkchar_varend, fp_pctx);

			if (optnv[optn_trbc])
				PrChar(bkchar_varend);

			};
		};

	/* deallocate the scanning index vector */

	MemoryFree(ivec);
	};

/* deallocate census vector storage */

ListBookReleaseOBC(obcptr);

/* free the generated moves */

if (ply >= mtrdL)
	MovesetDisconnectRelease(mptr);

return;
}

/*--> ListBookPackp: pack opening book code file */
nonstatic
siT
ListBookPackp(charptrT fn_w_bkcd, charptrT fn_w_pccd, charptrT fn_w_pctx,
	charptrT fn_w_obmp)
{
siT flag;

/* return value */

flag = 1;

/* set up for a new game */

InitNewGame();

/* set up statistics */

booktmn = booktln = booktvn = 0;

/* set null file pointers */

fp_bkcd = fp_pccd = fp_pctx = fp_obmp = NULL;

/* set up root move */

SetUpRootMove();

/* open input code file */

if (flag)
	{
	fp_bkcd = CodeFileOpen(fn_w_bkcd, "rb");
	if (fp_bkcd == NULL)
		flag = 0;
	else
		fp_get_code = fp_bkcd;
	};

/* open output code file (packed) */

if (flag)
	{
	fp_pccd = CodeFileOpen(fn_w_pccd, "wb");
	if (fp_pccd == NULL)
		flag = 0;
	else
		fp_put_code = fp_pccd;
	};

/* open output text tree file */

if (flag)
	if (optnv[optn_pbtx])
		{
		fp_pctx = TextFileOpen(fn_w_pctx, "w");
		if (fp_pctx == NULL)
			flag = 0;
		};

/* open output text move path file */

if (flag)
	if (optnv[optn_pbmp])
		{
		fp_obmp = TextFileOpen(fn_w_obmp, "w");
		if (fp_obmp == NULL)
			flag = 0;
		};

/* play through book */

if (flag)
	{
	/* set the output SAN language */

	lang_san = lang_put;

	/* set the one shot indicator (used for newline formatting) */

	bkcmt = 1;

	/* recurse */

	ListBookPackpNode(&root_m);

	/* output the EOF marker to the packed code file */

	ListBookCodePutControl(bkcntl_stop);

	/* handle any pending newlines */

	if (!bkcmt)
		{
		if (optnv[optn_pbtx])
			(void) fputc('\n', fp_pctx);
		if (optnv[optn_trbc])
			(void) PrChar('\n');
		};
	};

/* close input code file */

if (fp_bkcd != NULL)
	(void) CodeFileClose(fp_bkcd);

/* close output code file */

if (fp_pccd != NULL)
	(void) CodeFileClose(fp_pccd);

/* close output text tree file */

if (fp_pctx != NULL)
	(void) TextFileClose(fp_pctx);

/* close output text move path file */

if (fp_obmp != NULL)
	(void) TextFileClose(fp_obmp);

/* remove output files in case of error(s) */

if (!flag)
	{
	(void) remove(fn_w_pccd);
	if (optnv[optn_pbtx])
		(void) remove(fn_w_pctx);
	if (optnv[optn_pbmp])
		(void) remove(fn_w_obmp);
	};

/* statistics */

if (flag)
	if (optnv[optn_trbc])
		{
		PrTrace("BC");
		PrStrCondOrdLINL("chessmoves: ", booktmn);

		PrTrace("BC");
		PrStrCondOrdLINL("variations: ", booktvn);

		if (booktvn > 0)
			{
			PrTrace("BC");
			PrStr("avg length: ");
			FormatSTVLQR(booktmn, booktvn);
			PrSTVNL();
			};
		};

return (flag);
}

/*<<< bookpack.c: EOF */
