/*>>> tbcache.c: tablebase file descriptor cache management */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "tbdefs.h"
#include "tbvars.h"

#include "file.h"
#include "memutil.h"
#include "print.h"
#include "sysutil.h"
#include "tb.h"
#include "tbcache.h"

/*--> TBCacheAppend: append a record to the cache list */
static
void
TBCacheAppend(tfcptrT tfcptr)
{
if (tail_tfcptr == NULL)
	{
	head_tfcptr = tfcptr;
	tfcptr->tfc_prev = NULL;
	}
else
	{
	tail_tfcptr->tfc_next = tfcptr;
	tfcptr->tfc_prev = tail_tfcptr;
	};

tfcptr->tfc_next = NULL;
tail_tfcptr = tfcptr;

return;
}

/*--> TBCacheDethread: dethread a record from the cache list */
static
void
TBCacheDethread(tfcptrT tfcptr)
{
if (tfcptr->tfc_prev == NULL)
	head_tfcptr = tfcptr->tfc_next;
else
	tfcptr->tfc_prev->tfc_next = tfcptr->tfc_next;

if (tfcptr->tfc_next == NULL)
	tail_tfcptr = tfcptr->tfc_prev;
else
	tfcptr->tfc_next->tfc_prev = tfcptr->tfc_prev;

return;
}

/*--> TBCacheNew: allocate a new cache record */
static
tfcptrT
TBCacheNew(void)
{
tfcptrT tfcptr;

tfcptr = (tfcptrT) MemoryGrab(sizeof(tfcT));

tfcptr->tfc_tbid = tbid_nil;
tfcptr->tfc_c = c_nil;
tfcptr->tfc_fptr = NULL;
tfcptr->tfc_prev = tfcptr->tfc_next = NULL;

return (tfcptr);
}

/*--> TBCacheRelease: deallocate a cache record */
static
void
TBCacheRelease(tfcptrT tfcptr)
{
if (tfcptr != NULL)
	MemoryFree(tfcptr);

return;
}

/*--> TBCCacheLocate: attempt to locate matching cache entry */
static
tfcptrT
TBCCacheLocate(tbidT tbid, cT c)
{
tfcptrT tfcptr;
tfcptrT rptr;

tfcptr = NULL;
rptr = head_tfcptr;

while ((rptr != NULL) && (tfcptr == NULL))
	if ((rptr->tfc_tbid == tbid) && (rptr->tfc_c == c))
		tfcptr = rptr;
	else
		rptr = rptr->tfc_next;

return (tfcptr);
}

/*--> TBCacheOpen: attempt to open a tablebase file */
static
tfcptrT
TBCacheOpen(tbidT tbid, cT c)
{
tfcptrT tfcptr;
char tv[tL];

tfcptr = TBCCacheLocate(tbid, c);
if (tfcptr == NULL)
	{
	tfcptr = TBCacheNew();
	tfcptr->tfc_tbid = tbid;
	tfcptr->tfc_c = c;
	TBFormFileNameTBID(tbid, c, tv);
	tfcptr->tfc_fptr = CodeFileOpen(tv, "rb");
	TBCacheAppend(tfcptr);
	};

return (tfcptr);
}

/*--> TBCacheClose: attempt to close a tablebase file */
static
void
TBCacheClose(tfcptrT tfcptr)
{
if (tfcptr != NULL)
	{
	if (tfcptr->tfc_fptr != NULL)
		CodeFileClose(tfcptr->tfc_fptr);
	TBCacheDethread(tfcptr);
	TBCacheRelease(tfcptr);
	};

return;
}

/*--> TBCacheReadCPEV: read from a tablebase thorugh the cache */
nonstatic
cpevT
TBCacheReadCPEV(tbidT tbid, cT c, liT offset)
{
cpevT cpev;
tfcptrT tfcptr;
siT code, distance, value;
tiT tval;

tfcptr = TBCacheOpen(tbid, c);
if (tfcptr->tfc_fptr == NULL)
	cpev = cpev_wrck;
else
	{
	code = fseek(tfcptr->tfc_fptr, offset, SEEK_SET);
	if (code != 0)
		Diagnose("TBCacheReadCPEV: fseek fault");

	tval = bev_unknown;
	code = fread(&tval, sizeof(tiT), 1, tfcptr->tfc_fptr);
	if (code != sizeof(tiT))
		Diagnose("TBCacheReadCPEV: fread fault");

	value = (siT) tval;
	switch (value)
		{
		case bev_broken:
			cpev = cpev_wrck;
			break;

		case bev_reserved:
		case bev_unknown:
			PrStrSINL("TBCacheReadCPEV: tbid: ", tbid);
			PrStrSINL("TBCacheReadCPEV: c: ", c);
			PrStrLINL("TBCacheReadCPEV: index: ", offset);
			PrStrSINL("TBCacheReadCPEV: value: ", value);
			Diagnose("TBCacheReadCPEV: unexpected value");
			break;

		case bev_draw:
			cpev = cpev_draw;
			break;

		default:
			if (tbe_mating(value))
				{
				distance = ((bev_mi1 - value) * 2) + 1;
				cpev = cpev_best - distance;
				}
			else
				{
				distance = -((bev_li0 - value) * 2);
				cpev = cpev_bust + distance;
				};
			break;
		};
	};

return (cpev);
}

/*--> TBCacheFlush: flush the tablebase cache subsystem */
nonstatic
void
TBCacheFlush(void)
{
while (head_tfcptr != NULL)
	TBCacheClose(head_tfcptr);

return;
}

/*--> TBCacheInit: initialize the tablebase cache subsystem */
nonstatic
void
TBCacheInit(void)
{
/* clear the anchor pointers */

head_tfcptr = tail_tfcptr = NULL;

return;
}

/*--> TBCacheTerm: terminate the tablebase cache subsystem */
nonstatic
void
TBCacheTerm(void)
{
TBCacheFlush();

return;
}


/*<<< tbcache.c: EOF */
