/*>>> sx.h: subprogram prototypes for sx.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

cpevT SXEval(void);

/*<<< sx.h: EOF */
