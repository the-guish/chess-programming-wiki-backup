/*>>> ts.c: tactical search move selection */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bbmacs.h"

#include "memutil.h"
#include "mu.h"
#include "print.h"
#include "san.h"
#include "ts.h"

/**** Locals */

/* tiny integer versions of color-pieces */

#define ti_cp_wp ((tiT) cp_wp)
#define ti_cp_wn ((tiT) cp_wn)
#define ti_cp_wb ((tiT) cp_wb)
#define ti_cp_wr ((tiT) cp_wr)
#define ti_cp_wq ((tiT) cp_wq)
#define ti_cp_wk ((tiT) cp_wk)

#define ti_cp_bp ((tiT) cp_bp)
#define ti_cp_bn ((tiT) cp_bn)
#define ti_cp_bb ((tiT) cp_bb)
#define ti_cp_br ((tiT) cp_br)
#define ti_cp_bq ((tiT) cp_bq)
#define ti_cp_bk ((tiT) cp_bk)

#define ti_cp_v0 ((tiT) cp_v0)
#define ti_cp_x0 ((tiT) cp_x0)

/* short pawn piece attack values */

#define tsppa_p  1
#define tsppa_n  3
#define tsppa_b  3
#define tsppa_r  5
#define tsppa_q  9
#define tsppa_k 20

/* short pawn piece victim values */

#define tsppv_p (tsppa_p << byteW)
#define tsppv_n (tsppa_n << byteW)
#define tsppv_b (tsppa_b << byteW)
#define tsppv_r (tsppa_r << byteW)
#define tsppv_q (tsppa_q << byteW)
#define tsppv_k (tsppa_k << byteW)

/* promotion preliminary psuedovictim values */

#define tspv_ppn (tsppv_n - tsppv_p)
#define tspv_ppb (tsppv_b - tsppv_p)
#define tspv_ppr (tsppv_r - tsppv_p)
#define tspv_ppq (tsppv_q - tsppv_p)

/* generation macro */

#define TSPush() \
	{ \
	*tsmcurrptr++ = gen_tsm; \
	}

/* generation macro (promotions) */

#define TSPushProm() \
	{ \
	gen_tsm.tsm_scmv = scmv_ppq; \
	TSPush(); \
	gen_tsm.tsm_scmv = scmv_ppr; \
	TSPush(); \
	gen_tsm.tsm_scmv = scmv_ppb; \
	TSPush(); \
	gen_tsm.tsm_scmv = scmv_ppn; \
	TSPush(); \
	gen_tsm.tsm_scmv = scmv_reg; \
	}

/* tactical search tree length */

#define treeL 4096

/* tactical search environment type */

typedef struct tseS
	{
	cT    tse_actc;      /* active color */
	cT    tse_pasc;      /* passive color */
	castT tse_cast;      /* castling availability */
	sqT   tse_epsq;      /* en passant target square */
	sqT   tse_ksqv[rcL]; /* king squares */
	cpevT tse_matv[rcL]; /* material */
	} tseT, *tseptrT;

/* tactical search generation record type */

typedef struct tsgS
	{
	tsmptrT tsg_base;  /* base pointer */
	tsmptrT tsg_curr;  /* current pointer */
	tsmptrT tsg_next;  /* base of next frame */
	siT     tsg_count; /* entry count */
	} tsgT, *tsgptrT;

/* tactical search hash flags */

#define tshf_cpev bit_00 /* has centipawn evaluation */
#define tshf_mat1 bit_01 /* mate in 1 */
#define tshf_mat2 bit_02 /* mate in 2 ACO */
#define tshf_nmt1 bit_03 /* no mate in 1 */
#define tshf_nmt2 bit_04 /* no mate in 2 ACO */

/* tactical search score hash table entry type */

typedef struct tshS
	{
	xhscT tsh_xhsc; /* signature */
	siT   tsh_flag; /* contents flags */
	cpevT tsh_cpev; /* evaluation */
	cmT   tsh_cm1;  /* compressed move for mate in 1 */
	cmT   tsh_cm2;  /* compressed move for mate in 2 ACO */
	} tshT, *tshptrT;

/* tactical search score hash table order (per color) */

#define tshorderL 13
#define tshL (bit << tshorderL)
#define tshmaskM (tshL - 1)

/* tactical search score hash table base pointers */

static tshptrT tshbasev[rcL];

/* move response table base pointers */

static smptrT tsmrbptrv[rcL];

/* killer move table base pointers */

static smptrT tskmbptrv[rcL];

/* tactical search environment base and current pointers */

static tseptrT tsebaseptr, tsecurrptr;

/* tactical generation base and current pointers */

static tsgptrT tsgbaseptr, tsgcurrptr;

/* tactical search move tree */

static tsmptrT tsmbaseptr, tsmcurrptr;

/* tactical search ply */

static siT ts_ply;

/* the current tactical environment */

static tseT ts_tse;

/* the tactical search board */

static tsbT ts_tsb;

/* the generation move template */

static tsmT gen_tsm;

/* the attacker and victim value components */

static siT ts_atkv[cpL];
static siT ts_vicv[cpL];

/* helper pointer and return value for the mate search */

static tsmptrT ts_hpmsptr;
static mT ts_ms;

/* forward declarations */

static siT TSLoseAux(tsmptrT prevptr, siT n);
static siT TSLoseACOAux(siT n);

/*--> TSClearHashTable: clear the scoring hash table */
static
void
TSClearHashTable(void)
{
liT index;
tshptrT tshptr;
cT c;

for (c = c_w; c <= c_b; c++)
	{
	tshptr = tshbasev[c];
	for (index = 0; index < tshL; index++)
		{
		tshptr->tsh_xhsc = 0;
		tshptr->tsh_cpev = cpev_bust;
		tshptr->tsh_cm1 = tshptr->tsh_cm2 = 0;
		tshptr->tsh_flag = 0;
		tshptr++;
		};
	};

return;
}

/*--> TSHashStashCPEV: stash a score for current position */
static
void
TSHashStashCPEV(cpevT cpev)
{
tshptrT tshptr;

tshptr = tshbasev[actc] + (envn.envn_mhac & tshmaskM);

if (tshptr->tsh_xhsc == envn.envn_mhsc)
	tshptr->tsh_flag |= tshf_cpev;
else
	{
	tshptr->tsh_xhsc = envn.envn_mhsc;
	tshptr->tsh_flag = tshf_cpev;
	};

tshptr->tsh_cpev = cpev;

return;
}

/*--> TSHashFetchCPEV: fetch a score for current position */
static
cpevT
TSHashFetchCPEV(void)
{
cpevT cpev;
tshptrT tshptr;

tshptr = tshbasev[actc] + (envn.envn_mhac & tshmaskM);

if ((tshptr->tsh_xhsc == envn.envn_mhsc) &&
	(tshptr->tsh_flag & tshf_cpev))
	cpev = tshptr->tsh_cpev;
else
	cpev = cpev_wrck;

return (cpev);
}

/*--> TSHashDenyM1: stash denial of mate in 1 for current position */
static
void
TSHashDenyM1(void)
{
tshptrT tshptr;

tshptr = tshbasev[actc] + (envn.envn_mhac & tshmaskM);

if (tshptr->tsh_xhsc == envn.envn_mhsc)
	{
	tshptr->tsh_flag |= tshf_nmt1;
	tshptr->tsh_flag &= ~tshf_mat1;
	}
else
	{
	tshptr->tsh_xhsc = envn.envn_mhsc;
	tshptr->tsh_flag = tshf_nmt1;
	};

return;
}

/*--> TSHashCheckDenyM1: check denial of mate in 1 for current position */
static
siT
TSHashCheckDenyM1(void)
{
siT flag;
tshptrT tshptr;

tshptr = tshbasev[actc] + (envn.envn_mhac & tshmaskM);

if ((tshptr->tsh_xhsc == envn.envn_mhsc) &&
	(tshptr->tsh_flag & tshf_nmt1))
	flag = 1;
else
	flag = 0;

return (flag);
}

/*--> TSHashStashM1: stash a mate in 1 for current position */
static
void
TSHashStashM1(cmT cm)
{
tshptrT tshptr;

tshptr = tshbasev[actc] + (envn.envn_mhac & tshmaskM);

if (tshptr->tsh_xhsc == envn.envn_mhsc)
	{
	tshptr->tsh_flag |= tshf_mat1;
	tshptr->tsh_flag &= ~tshf_nmt1;
	}
else
	{
	tshptr->tsh_xhsc = envn.envn_mhsc;
	tshptr->tsh_flag = tshf_mat1;
	};

tshptr->tsh_cm1 = cm;

return;
}

/*--> TSHashFetchM1: fetch a mate in 1 for current position */
static
cmT
TSHashFetchM1(void)
{
cmT cm;
tshptrT tshptr;

tshptr = tshbasev[actc] + (envn.envn_mhac & tshmaskM);

if ((tshptr->tsh_xhsc == envn.envn_mhsc) &&
	(tshptr->tsh_flag & tshf_mat1))
	cm = tshptr->tsh_cm1;
else
	cm = 0;

return (cm);
}

/*--> TSHashDenyM2: stash denial of mate in 2 for current position */
static
void
TSHashDenyM2(void)
{
tshptrT tshptr;

tshptr = tshbasev[actc] + (envn.envn_mhac & tshmaskM);

if (tshptr->tsh_xhsc == envn.envn_mhsc)
	{
	tshptr->tsh_flag |= tshf_nmt2;
	tshptr->tsh_flag &= ~tshf_mat2;
	}
else
	{
	tshptr->tsh_xhsc = envn.envn_mhsc;
	tshptr->tsh_flag = tshf_nmt2;
	};

return;
}

/*--> TSHashCheckDenyM2: check denial of mate in 2 for current position */
static
siT
TSHashCheckDenyM2(void)
{
siT flag;
tshptrT tshptr;

tshptr = tshbasev[actc] + (envn.envn_mhac & tshmaskM);

if ((tshptr->tsh_xhsc == envn.envn_mhsc) &&
	(tshptr->tsh_flag & tshf_nmt2))
	flag = 1;
else
	flag = 0;

return (flag);
}

/*--> TSHashStashM2: stash a mate in 2 for current position */
static
void
TSHashStashM2(cmT cm)
{
tshptrT tshptr;

tshptr = tshbasev[actc] + (envn.envn_mhac & tshmaskM);

if (tshptr->tsh_xhsc == envn.envn_mhsc)
	{
	tshptr->tsh_flag |= tshf_mat2;
	tshptr->tsh_flag &= ~tshf_nmt2;
	}
else
	{
	tshptr->tsh_xhsc = envn.envn_mhsc;
	tshptr->tsh_flag = tshf_mat2;
	};

tshptr->tsh_cm2 = cm;

return;
}

/*--> TSHashFetchM2: fetch a mate in 2 for current position */
static
cmT
TSHashFetchM2(void)
{
cmT cm;
tshptrT tshptr;

tshptr = tshbasev[actc] + (envn.envn_mhac & tshmaskM);

if ((tshptr->tsh_xhsc == envn.envn_mhsc) &&
	(tshptr->tsh_flag & tshf_mat2))
	cm = tshptr->tsh_cm2;
else
	cm = 0;

return (cm);
}

/*--> TSClearMoveResponse: clear move response information */
nonstatic
void
TSClearMoveResponse(void)
{
cT c;
siT i;
smptrT smptr;

/* clear the move response tables */

for (c = c_w; c <= c_b; c++)
	{
	smptr = tsmrbptrv[c];
	for (i = 0; i < sqsqL; i++)
		*smptr++ = null_sm;
	};

return;
}

/*--> TSClearKillerMoves: clear killer move information */
nonstatic
void
TSClearKillerMoves(void)
{
cT c;
siT i;
smptrT smptr;

/* clear the killer move tables */

for (c = c_w; c <= c_b; c++)
	{
	smptr = tskmbptrv[c];
	for (i = 0; i < (2 * plyL); i++)
		*smptr++ = null_sm;
	};

return;
}

/*--> TSInit: one time initialization for the tactical search module */
nonstatic
void
TSInit(void)
{
cT c;

/* allocate and clear the hash tables */

for (c = c_w; c <= c_b; c++)
	tshbasev[c] = (tshptrT) MemoryGrab(sizeof(tshT) * tshL);
TSClearHashTable();

/* allocate and clear the move response tables */

for (c = c_w; c <= c_b; c++)
	tsmrbptrv[c] = (smptrT) MemoryGrab(sizeof(smT) * sqsqL);
TSClearMoveResponse();

/* allocate and clear the killer move tables */

for (c = c_w; c <= c_b; c++)
	tskmbptrv[c] = (smptrT) MemoryGrab(sizeof(smT) * (2 * plyL));
TSClearKillerMoves();

/* allocate environment stack */

tsebaseptr = (tseptrT) MemoryGrab(sizeof(tseT) * plyL);
tsecurrptr = tsebaseptr;

/* allocate generation record stack */

tsgbaseptr = (tsgptrT) MemoryGrab(sizeof(tsgT) * plyL);
tsgcurrptr = tsgbaseptr;

/* allocate the tree */

tsmbaseptr = (tsmptrT) MemoryGrab(sizeof(tsmT) * treeL);
tsmcurrptr = tsmbaseptr;

/* initialize the generation move template */

gen_tsm.tsm_frsq = gen_tsm.tsm_tosq = sq_nil;
gen_tsm.tsm_frcp = gen_tsm.tsm_tocp = cp_v0;
gen_tsm.tsm_scmv = scmv_reg;
gen_tsm.tsm_flag = 0;
gen_tsm.tsm_prel = 0;

/* initialize the attacker value components */

ts_atkv[cp_wp] = ts_atkv[cp_bp] = tsppa_p;
ts_atkv[cp_wn] = ts_atkv[cp_bn] = tsppa_n;
ts_atkv[cp_wb] = ts_atkv[cp_bb] = tsppa_b;
ts_atkv[cp_wr] = ts_atkv[cp_br] = tsppa_r;
ts_atkv[cp_wq] = ts_atkv[cp_bq] = tsppa_q;
ts_atkv[cp_wk] = ts_atkv[cp_bk] = tsppa_k;
ts_atkv[cp_v0] = ts_atkv[cp_x0] = 0;

/* initialize the victim value components */

ts_vicv[cp_wp] = ts_vicv[cp_bp] = tsppv_p;
ts_vicv[cp_wn] = ts_vicv[cp_bn] = tsppv_n;
ts_vicv[cp_wb] = ts_vicv[cp_bb] = tsppv_b;
ts_vicv[cp_wr] = ts_vicv[cp_br] = tsppv_r;
ts_vicv[cp_wq] = ts_vicv[cp_bq] = tsppv_q;
ts_vicv[cp_wk] = ts_vicv[cp_bk] = tsppv_k;
ts_vicv[cp_v0] = ts_vicv[cp_x0] = 0;

/* initialize the ply */

ts_ply = 0;

return;
}

/*--> TSTerm: one time termination for the tactical search module */
nonstatic
void
TSTerm(void)
{
cT c;

/* deallocate the tree */

MemoryFree(tsmbaseptr);

/* deallocate the generation record stack */

MemoryFree(tsgbaseptr);

/* deallocate the environment stack */

MemoryFree(tsebaseptr);

/* deallocate the move response tables */

for (c = c_w; c <= c_b; c++)
	MemoryFree(tsmrbptrv[c]);

/* deallocate the killer move tables */

for (c = c_w; c <= c_b; c++)
	MemoryFree(tskmbptrv[c]);

/* deallocate the hash tables */

for (c = c_w; c <= c_b; c++)
	MemoryFree(tshbasev[c]);

return;
}

/*--> TSFormatMove: format a move */
static
void
TSFormatMove(tsmptrT tsmptr, charptrT p)
{
mT m;
sanT san;

m.m_flag = 0;

if (tsmptr->tsm_flag & tsmf_anfp)
	m.m_flag |= mf_anfp;

if (tsmptr->tsm_flag & tsmf_anrp)
	m.m_flag |= mf_anrp;

if (tsmptr->tsm_flag & tsmf_bust)
	m.m_flag |= mf_bust;

if (tsmptr->tsm_flag & tsmf_chec)
	m.m_flag |= mf_chec;

if (tsmptr->tsm_flag & tsmf_mate)
	m.m_flag |= mf_mate;

m.m_frsq = tsmptr->tsm_frsq;
m.m_tosq = tsmptr->tsm_tosq;
m.m_frcp = tsmptr->tsm_frcp;
m.m_tocp = tsmptr->tsm_tocp;
m.m_scmv = tsmptr->tsm_scmv;

SANMove(&m, san);
strcpy(p, ((charptrT) san));

return;
}

/*--> TSDumpMove: dump a move */
static
void
TSDumpMove(tsmptrT tsmptr)
{
char tv[tL];

TSFormatMove(tsmptr, tv);
PrStr(tv);

return;
}

/*--> TSStart: set up the tactical search */
static
void
TSStart(void)
{
sqT sq;
cpT cp;
cT c;

/* copy environment */

ts_tse.tse_actc = actc;
ts_tse.tse_pasc = pasc;
ts_tse.tse_cast = envn.envn_cast;
ts_tse.tse_epsq = envn.envn_epsq;
ts_tse.tse_ksqv[c_w] = bb_once(cpbbv[cp_wk]);
ts_tse.tse_ksqv[c_b] = bb_once(cpbbv[cp_bk]);

/* clear the material sums */

for (c = c_w; c <= c_b; c++)
	ts_tse.tse_matv[c] = 0;

/* copy pieces */

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	ts_tsb.tsbv[sq] = cp = local.rbv[sq];
	if (cp != cp_v0)
		ts_tse.tse_matv[cv_c_cpv[cp]] += cpvalv[cp];
	};

return;
}

/*--> TSFinish: finish the tactical search */
static
void
TSFinish(void)
{

return;
}

/*--> TSWhiteAttack: deterine if white attacks a square */
static
siT
TSWhiteAttack(sqT sq)
{
siT flag, stop;
tiptrT p0, p1, p2, p3;
dxT dx;
dvT dv;
xdvT xdv;
tiT ti_cp;

flag = 0;

p0 = &ts_tsb.tsbv[sq];
p1 = &xb.xbv[trn_xbsq(sq)];

/* check for orthogonal attacks */

if (!flag)
	{
	dx = dx_0;
	while (!flag && (dx <= dx_3))
		{
		if (*(p3 = (p1 + (xdv = xdvv[dx]))) == ti_cp_v0)
			{
			if ((ti_cp = *(p2 = (p0 + (dv = dvv[dx])))) != ti_cp_v0)
				{
				if ((ti_cp == ti_cp_wk) || (ti_cp == ti_cp_wq) ||
					(ti_cp == ti_cp_wr))
					flag = 1;
				}
			else
				{
				stop = 0;
				while (!stop)
					{
					if (*(p3 += xdv) == cp_x0)
						stop = 1;
					else
						if ((ti_cp = *(p2 += dv)) != cp_v0)
							{
							stop = 1;
							if ((ti_cp == ti_cp_wq) ||
								(ti_cp == ti_cp_wr))
								flag = 1;
							};
					};
				};
			};
		dx++;
		}
	};

/* check for diagonal attacks */

if (!flag)
	{
	dx = dx_4;
	while (!flag && (dx <= dx_7))
		{
		if (*(p3 = (p1 + (xdv = xdvv[dx]))) == ti_cp_v0)
			{
			if ((ti_cp = *(p2 = (p0 + (dv = dvv[dx])))) != ti_cp_v0)
				{
				if ((ti_cp == ti_cp_wk) || (ti_cp == ti_cp_wq) ||
					(ti_cp == ti_cp_wb))
					flag = 1;
				}
			else
				{
				stop = 0;
				while (!stop)
					{
					if (*(p3 += xdv) == cp_x0)
						stop = 1;
					else
						if ((ti_cp = *(p2 += dv)) != cp_v0)
							{
							stop = 1;
							if ((ti_cp == ti_cp_wq) ||
								(ti_cp == ti_cp_wb))
								flag = 1;
							};
					};
				};
			};
		dx++;
		}
	};

/* check for knight attacks */

if (!flag)
	{
	dx = dx_8;
	while (!flag && (dx <= dx_f))
		if ((*(p1 + xdvv[dx]) == ti_cp_v0) &&
			(*(p0 + dvv[dx]) == ti_cp_wn))
				flag = 1;
		else
			dx++;
	};

/* check for pawn attacks */

if (!flag)
	if (*(p1 + xdv_6) == ti_cp_v0)
		if (*(p0 + dv_6) == ti_cp_wp)
			flag = 1;

if (!flag)
	if (*(p1 + xdv_7) == ti_cp_v0)
		if (*(p0 + dv_7) == ti_cp_wp)
			flag = 1;

return (flag);
}

/*--> TSBlackAttack: deterine if black attacks a square */
static
siT
TSBlackAttack(sqT sq)
{
siT flag, stop;
tiptrT p0, p1, p2, p3;
dxT dx;
dvT dv;
xdvT xdv;
tiT ti_cp;

flag = 0;

p0 = &ts_tsb.tsbv[sq];
p1 = &xb.xbv[trn_xbsq(sq)];

/* check for orthogonal attacks */

if (!flag)
	{
	dx = dx_0;
	while (!flag && (dx <= dx_3))
		{
		if (*(p3 = (p1 + (xdv = xdvv[dx]))) == ti_cp_v0)
			{
			if ((ti_cp = *(p2 = (p0 + (dv = dvv[dx])))) != ti_cp_v0)
				{
				if ((ti_cp == ti_cp_bk) || (ti_cp == ti_cp_bq) ||
					(ti_cp == ti_cp_br))
					flag = 1;
				}
			else
				{
				stop = 0;
				while (!stop)
					{
					if (*(p3 += xdv) == cp_x0)
						stop = 1;
					else
						if ((ti_cp = *(p2 += dv)) != cp_v0)
							{
							stop = 1;
							if ((ti_cp == ti_cp_bq) ||
								(ti_cp == ti_cp_br))
								flag = 1;
							};
					};
				};
			};
		dx++;
		}
	};

/* check for diagonal attacks */

if (!flag)
	{
	dx = dx_4;
	while (!flag && (dx <= dx_7))
		{
		if (*(p3 = (p1 + (xdv = xdvv[dx]))) == ti_cp_v0)
			{
			if ((ti_cp = *(p2 = (p0 + (dv = dvv[dx])))) != ti_cp_v0)
				{
				if ((ti_cp == ti_cp_bk) || (ti_cp == ti_cp_bq) ||
					(ti_cp == ti_cp_bb))
					flag = 1;
				}
			else
				{
				stop = 0;
				while (!stop)
					{
					if (*(p3 += xdv) == cp_x0)
						stop = 1;
					else
						if ((ti_cp = *(p2 += dv)) != cp_v0)
							{
							stop = 1;
							if ((ti_cp == ti_cp_bq) ||
								(ti_cp == ti_cp_bb))
								flag = 1;
							};
					};
				};
			};
		dx++;
		}
	};

/* check for knight attacks */

if (!flag)
	{
	dx = dx_8;
	while (!flag && (dx <= dx_f))
		if ((*(p1 + xdvv[dx]) == ti_cp_v0) &&
			(*(p0 + dvv[dx]) == ti_cp_bn))
				flag = 1;
		else
			dx++;
	};

/* check for pawn attacks */

if (!flag)
	if (*(p1 + xdv_5) == ti_cp_v0)
		if (*(p0 + dv_5) == ti_cp_bp)
			flag = 1;

if (!flag)
	if (*(p1 + xdv_4) == ti_cp_v0)
		if (*(p0 + dv_4) == ti_cp_bp)
			flag = 1;

return (flag);
}

/*--> TSAttack: determine if a color attacks a square */
static
siT
TSAttack(cT c, sqT sq)
{
siT flag;

if (c == c_w)
	flag = TSWhiteAttack(sq);
else
	flag = TSBlackAttack(sq);

return (flag);
}

/*--> TSInCheck: determine if the active color is in check */
static
siT
TSInCheck(void)
{
siT flag;

if (ts_tse.tse_actc == c_w)
	flag = TSBlackAttack(ts_tse.tse_ksqv[c_w]);
else
	flag = TSWhiteAttack(ts_tse.tse_ksqv[c_b]);

return (flag);
}

/*--> TSIllegal: determine if the passive color is in check */
static
siT
TSIllegal(void)
{
siT flag;

if (ts_tse.tse_pasc == c_w)
	flag = TSBlackAttack(ts_tse.tse_ksqv[c_w]);
else
	flag = TSWhiteAttack(ts_tse.tse_ksqv[c_b]);

return (flag);
}

/*--> TSGenerateFull: generate psuedolegal moves */
static
void
TSGenerateFull(void)
{
sqT frsq, tosq;
cpT frcp, tocp;
tiptrT frsqptr, tosqptr;
tiptrT xfrsqptr, xtosqptr;
dxT dx;
dvT dv;
xdvT xdv;
siT count;
dxT dxlimit;
fileT frfile;
rankT frrank;
pT frp;

/* initialize the generation record at this ply */

tsgcurrptr->tsg_base = tsmcurrptr;

/* start the from square scan */

count = 0;
frsqptr = &ts_tsb.tsbv[sq_a1];
for (frsq = sq_a1; frsq <= sq_h8; frsq++)
	{
	frcp = *frsqptr;
	if ((frcp != cp_v0) && (cv_c_cpv[frcp] == ts_tse.tse_actc))
		{
		gen_tsm.tsm_frsq = frsq;
		gen_tsm.tsm_frcp = frcp;

		xfrsqptr = &xb.xbv[trn_xbsq(frsq)];

		switch (frcp)
			{
			case cp_wp:
				frfile = map_file(frsq);
				frrank = map_rank(frsq);

				if (*(frsqptr + dv_1) == ti_cp_v0)
					{
					gen_tsm.tsm_tosq = frsq + dv_1;
					gen_tsm.tsm_tocp = ti_cp_v0;
					if (frrank != rank_7)
						{
						TSPush();
						}
					else
						{
						TSPushProm();
						};

					if (frrank == rank_2)
						if (*(frsqptr + (2 * dv_1)) == ti_cp_v0)
							{
							gen_tsm.tsm_tosq = frsq + (2 * dv_1);
							gen_tsm.tsm_tocp = ti_cp_v0;
							TSPush();
							};
					};

				if (frfile < file_h)
					if (cv_c_cpv[tocp = *(frsqptr + dv_4)] == c_b)
						{
						gen_tsm.tsm_tosq = frsq + dv_4;
						gen_tsm.tsm_tocp = tocp;
						if (frrank != rank_7)
							{
							TSPush();
							}
						else
							{
							TSPushProm();
							};
						};

				if (frfile > file_a)
					if (cv_c_cpv[tocp = *(frsqptr + dv_5)] == c_b)
						{
						gen_tsm.tsm_tosq = frsq + dv_5;
						gen_tsm.tsm_tocp = tocp;
						if (frrank != rank_7)
							{
							TSPush();
							}
						else
							{
							TSPushProm();
							};
						};

				if ((ts_tse.tse_epsq != sq_nil) && (frrank == rank_5))
					{
					if ((frfile < file_h) &&
						(ts_tse.tse_epsq == (frsq + dv_4)))
						{
						gen_tsm.tsm_tosq = ts_tse.tse_epsq;
						gen_tsm.tsm_tocp = ti_cp_v0;
						gen_tsm.tsm_scmv = scmv_epc;
						TSPush();
						gen_tsm.tsm_scmv = scmv_reg;
						};

					if ((frfile > file_a) &&
						(ts_tse.tse_epsq == (frsq + dv_5)))
						{
						gen_tsm.tsm_tosq = ts_tse.tse_epsq;
						gen_tsm.tsm_tocp = ti_cp_v0;
						gen_tsm.tsm_scmv = scmv_epc;
						TSPush();
						gen_tsm.tsm_scmv = scmv_reg;
						};
					};
				break;

			case cp_bp:
				frfile = map_file(frsq);
				frrank = map_rank(frsq);

				if (*(frsqptr + dv_3) == ti_cp_v0)
					{
					gen_tsm.tsm_tosq = frsq + dv_3;
					gen_tsm.tsm_tocp = ti_cp_v0;
					if (frrank != rank_2)
						{
						TSPush();
						}
					else
						{
						TSPushProm();
						};

					if (frrank == rank_7)
						if (*(frsqptr + (2 * dv_3)) == ti_cp_v0)
							{
							gen_tsm.tsm_tosq = frsq + (2 * dv_3);
							gen_tsm.tsm_tocp = ti_cp_v0;
							TSPush();
							};
					};

				if (frfile < file_h)
					if (cv_c_cpv[tocp = *(frsqptr + dv_7)] == c_w)
						{
						gen_tsm.tsm_tosq = frsq + dv_7;
						gen_tsm.tsm_tocp = tocp;
						if (frrank != rank_2)
							{
							TSPush();
							}
						else
							{
							TSPushProm();
							};
						};

				if (frfile > file_a)
					if (cv_c_cpv[tocp = *(frsqptr + dv_6)] == c_w)
						{
						gen_tsm.tsm_tosq = frsq + dv_6;
						gen_tsm.tsm_tocp = tocp;
						if (frrank != rank_2)
							{
							TSPush();
							}
						else
							{
							TSPushProm();
							};
						};

				if ((ts_tse.tse_epsq != sq_nil) && (frrank == rank_4))
					{
					if ((frfile < file_h) &&
						(ts_tse.tse_epsq == (frsq + dv_7)))
						{
						gen_tsm.tsm_tosq = ts_tse.tse_epsq;
						gen_tsm.tsm_tocp = ti_cp_v0;
						gen_tsm.tsm_scmv = scmv_epc;
						TSPush();
						gen_tsm.tsm_scmv = scmv_reg;
						};

					if ((frfile > file_a) &&
						(ts_tse.tse_epsq == (frsq + dv_6)))
						{
						gen_tsm.tsm_tosq = ts_tse.tse_epsq;
						gen_tsm.tsm_tocp = ti_cp_v0;
						gen_tsm.tsm_scmv = scmv_epc;
						TSPush();
						gen_tsm.tsm_scmv = scmv_reg;
						};
					};
				break;

			case cp_wn:
			case cp_bn:
				for (dx = dx_8; dx <= dx_f; dx++)
					if (*(xfrsqptr + xdvv[dx]) == ti_cp_v0)
						{
						if (cv_c_cpv[tocp = *(frsqptr + (dv = dvv[dx]))] !=
							ts_tse.tse_actc)
							{
							gen_tsm.tsm_tosq = frsq + dv;
							gen_tsm.tsm_tocp = tocp;
							TSPush();
							};
						};
				break;

			case cp_wb:
			case cp_wr:
			case cp_wq:
			case cp_bb:
			case cp_br:
			case cp_bq:
				dxlimit = dx_sweep1v[frp = cv_p_cpv[frcp]];
				for (dx = dx_sweep0v[frp]; dx <= dxlimit; dx++)
					{
					dv = dvv[dx];
					xdv = xdvv[dx];
					tosqptr = frsqptr;
					xtosqptr = xfrsqptr;
					tosq = frsq;
					while ((*(xtosqptr += xdv) == ti_cp_v0) &&
						((tocp = *(tosqptr += dv)) == ti_cp_v0))
						{
						gen_tsm.tsm_tosq = tosq += dv;
						gen_tsm.tsm_tocp = ti_cp_v0;
						TSPush();
						};
					if ((*xtosqptr == ti_cp_v0) &&
						(cv_c_cpv[tocp] != ts_tse.tse_actc))
						{
						gen_tsm.tsm_tosq = tosq + dv;
						gen_tsm.tsm_tocp = tocp;
						TSPush();
						};
					};
				break;

			case cp_wk:
			case cp_bk:
				for (dx = dx_0; dx <= dx_7; dx++)
					if (*(xfrsqptr + xdvv[dx]) == ti_cp_v0)
						{
						if (cv_c_cpv[tocp = *(frsqptr + (dv = dvv[dx]))] !=
							ts_tse.tse_actc)
							{
							gen_tsm.tsm_tosq = frsq + dv;
							gen_tsm.tsm_tocp = tocp;
							TSPush();
							};
						};

				if (frcp == cp_wk)
					{
					if (ts_tse.tse_cast & cf_wk)
						{
						if ((ts_tsb.tsbv[sq_f1] == ti_cp_v0) &&
							(ts_tsb.tsbv[sq_g1] == ti_cp_v0) &&
							!TSBlackAttack(sq_e1) &&
							!TSBlackAttack(sq_f1) &&
							!TSBlackAttack(sq_g1))
							{
							gen_tsm.tsm_tosq = sq_g1;
							gen_tsm.tsm_tocp = ti_cp_v0;
							gen_tsm.tsm_scmv = scmv_cks;
							TSPush();
							gen_tsm.tsm_scmv = scmv_reg;
							};
						};

					if (ts_tse.tse_cast & cf_wq)
						{
						if ((ts_tsb.tsbv[sq_d1] == ti_cp_v0) &&
							(ts_tsb.tsbv[sq_c1] == ti_cp_v0) &&
							(ts_tsb.tsbv[sq_b1] == ti_cp_v0) &&
							!TSBlackAttack(sq_e1) &&
							!TSBlackAttack(sq_d1) &&
							!TSBlackAttack(sq_c1))
							{
							gen_tsm.tsm_tosq = sq_c1;
							gen_tsm.tsm_tocp = ti_cp_v0;
							gen_tsm.tsm_scmv = scmv_cqs;
							TSPush();
							gen_tsm.tsm_scmv = scmv_reg;
							};
						};
					}
				else
					{
					if (ts_tse.tse_cast & cf_bk)
						{
						if ((ts_tsb.tsbv[sq_f8] == ti_cp_v0) &&
							(ts_tsb.tsbv[sq_g8] == ti_cp_v0) &&
							!TSWhiteAttack(sq_e8) &&
							!TSWhiteAttack(sq_f8) &&
							!TSWhiteAttack(sq_g8))
							{
							gen_tsm.tsm_tosq = sq_g8;
							gen_tsm.tsm_tocp = ti_cp_v0;
							gen_tsm.tsm_scmv = scmv_cks;
							TSPush();
							gen_tsm.tsm_scmv = scmv_reg;
							};
						};

					if (ts_tse.tse_cast & cf_bq)
						{
						if ((ts_tsb.tsbv[sq_d8] == ti_cp_v0) &&
							(ts_tsb.tsbv[sq_c8] == ti_cp_v0) &&
							(ts_tsb.tsbv[sq_b8] == ti_cp_v0) &&
							!TSWhiteAttack(sq_e8) &&
							!TSWhiteAttack(sq_d8) &&
							!TSWhiteAttack(sq_c8))
							{
							gen_tsm.tsm_tosq = sq_c1;
							gen_tsm.tsm_tocp = ti_cp_v0;
							gen_tsm.tsm_scmv = scmv_cqs;
							TSPush();
							gen_tsm.tsm_scmv = scmv_reg;
							};
						};
					};
				break;
			};
		};
	frsqptr++;
	};

/* set the current generation stack count */

tsgcurrptr->tsg_count = tsmcurrptr - tsgcurrptr->tsg_base;
tsgcurrptr->tsg_next = tsmcurrptr;

/* reset the tree top */

tsmcurrptr = tsgcurrptr->tsg_base;

return;
}

/*--> TSGenerateCapt: generate psuedolegal capturing moves */
static
void
TSGenerateCapt(void)
{
sqT frsq, tosq;
cpT frcp, tocp;
tiptrT frsqptr, tosqptr;
tiptrT xfrsqptr, xtosqptr;
dxT dx;
dvT dv;
xdvT xdv;
siT count;
dxT dxlimit;
fileT frfile;
rankT frrank;
pT frp;

/* initialize the generation record at this ply */

tsgcurrptr->tsg_base = tsmcurrptr;

/* start the from square scan */

count = 0;
frsqptr = &ts_tsb.tsbv[sq_a1];
for (frsq = sq_a1; frsq <= sq_h8; frsq++)
	{
	frcp = *frsqptr;
	if ((frcp != cp_v0) && (cv_c_cpv[frcp] == ts_tse.tse_actc))
		{
		gen_tsm.tsm_frsq = frsq;
		gen_tsm.tsm_frcp = frcp;

		xfrsqptr = &xb.xbv[trn_xbsq(frsq)];

		switch (frcp)
			{
			case cp_wp:
				frfile = map_file(frsq);
				frrank = map_rank(frsq);

				if ((*(frsqptr + dv_1) == ti_cp_v0) && (frrank == rank_7))
					{
					gen_tsm.tsm_tosq = frsq + dv_1;
					gen_tsm.tsm_tocp = ti_cp_v0;
					TSPushProm();
					};

				if (frfile < file_h)
					if (cv_c_cpv[tocp = *(frsqptr + dv_4)] == c_b)
						{
						gen_tsm.tsm_tosq = frsq + dv_4;
						gen_tsm.tsm_tocp = tocp;
						if (frrank != rank_7)
							{
							TSPush();
							}
						else
							{
							TSPushProm();
							};
						};

				if (frfile > file_a)
					if (cv_c_cpv[tocp = *(frsqptr + dv_5)] == c_b)
						{
						gen_tsm.tsm_tosq = frsq + dv_5;
						gen_tsm.tsm_tocp = tocp;
						if (frrank != rank_7)
							{
							TSPush();
							}
						else
							{
							TSPushProm();
							};
						};

				if ((ts_tse.tse_epsq != sq_nil) && (frrank == rank_5))
					{
					if ((frfile < file_h) &&
						(ts_tse.tse_epsq == (frsq + dv_4)))
						{
						gen_tsm.tsm_tosq = ts_tse.tse_epsq;
						gen_tsm.tsm_tocp = ti_cp_v0;
						gen_tsm.tsm_scmv = scmv_epc;
						TSPush();
						gen_tsm.tsm_scmv = scmv_reg;
						};

					if ((frfile > file_a) &&
						(ts_tse.tse_epsq == (frsq + dv_5)))
						{
						gen_tsm.tsm_tosq = ts_tse.tse_epsq;
						gen_tsm.tsm_tocp = ti_cp_v0;
						gen_tsm.tsm_scmv = scmv_epc;
						TSPush();
						gen_tsm.tsm_scmv = scmv_reg;
						};
					};
				break;

			case cp_bp:
				frfile = map_file(frsq);
				frrank = map_rank(frsq);

				if ((*(frsqptr + dv_3) == ti_cp_v0) && (frrank == rank_2))
					{
					gen_tsm.tsm_tosq = frsq + dv_3;
					gen_tsm.tsm_tocp = ti_cp_v0;
					TSPushProm();
					};

				if (frfile < file_h)
					if (cv_c_cpv[tocp = *(frsqptr + dv_7)] == c_w)
						{
						gen_tsm.tsm_tosq = frsq + dv_7;
						gen_tsm.tsm_tocp = tocp;
						if (frrank != rank_2)
							{
							TSPush();
							}
						else
							{
							TSPushProm();
							};
						};

				if (frfile > file_a)
					if (cv_c_cpv[tocp = *(frsqptr + dv_6)] == c_w)
						{
						gen_tsm.tsm_tosq = frsq + dv_6;
						gen_tsm.tsm_tocp = tocp;
						if (frrank != rank_2)
							{
							TSPush();
							}
						else
							{
							TSPushProm();
							};
						};

				if ((ts_tse.tse_epsq != sq_nil) && (frrank == rank_4))
					{
					if ((frfile < file_h) &&
						(ts_tse.tse_epsq == (frsq + dv_7)))
						{
						gen_tsm.tsm_tosq = ts_tse.tse_epsq;
						gen_tsm.tsm_tocp = ti_cp_v0;
						gen_tsm.tsm_scmv = scmv_epc;
						TSPush();
						gen_tsm.tsm_scmv = scmv_reg;
						};

					if ((frfile > file_a) &&
						(ts_tse.tse_epsq == (frsq + dv_6)))
						{
						gen_tsm.tsm_tosq = ts_tse.tse_epsq;
						gen_tsm.tsm_tocp = ti_cp_v0;
						gen_tsm.tsm_scmv = scmv_epc;
						TSPush();
						gen_tsm.tsm_scmv = scmv_reg;
						};
					};
				break;

			case cp_wn:
			case cp_bn:
				for (dx = dx_8; dx <= dx_f; dx++)
					if (*(xfrsqptr + xdvv[dx]) == ti_cp_v0)
						{
						if (cv_c_cpv[tocp = *(frsqptr + (dv = dvv[dx]))] ==
							ts_tse.tse_pasc)
							{
							gen_tsm.tsm_tosq = frsq + dv;
							gen_tsm.tsm_tocp = tocp;
							TSPush();
							};
						};
				break;

			case cp_wb:
			case cp_wr:
			case cp_wq:
			case cp_bb:
			case cp_br:
			case cp_bq:
				dxlimit = dx_sweep1v[frp = cv_p_cpv[frcp]];
				for (dx = dx_sweep0v[frp]; dx <= dxlimit; dx++)
					{
					dv = dvv[dx];
					xdv = xdvv[dx];
					tosqptr = frsqptr;
					xtosqptr = xfrsqptr;
					tosq = frsq;
					while ((*(xtosqptr += xdv) == ti_cp_v0) &&
						((tocp = *(tosqptr += dv)) == ti_cp_v0))
						tosq += dv;
					if ((*xtosqptr == ti_cp_v0) &&
						(cv_c_cpv[tocp] == ts_tse.tse_pasc))
						{
						gen_tsm.tsm_tosq = tosq + dv;
						gen_tsm.tsm_tocp = tocp;
						TSPush();
						};
					};
				break;

			case cp_wk:
			case cp_bk:
				for (dx = dx_0; dx <= dx_7; dx++)
					if (*(xfrsqptr + xdvv[dx]) == ti_cp_v0)
						{
						if (cv_c_cpv[tocp = *(frsqptr + (dv = dvv[dx]))] ==
							ts_tse.tse_pasc)
							{
							gen_tsm.tsm_tosq = frsq + dv;
							gen_tsm.tsm_tocp = tocp;
							TSPush();
							};
						};
				break;
			};
		};
	frsqptr++;
	};

/* set the current generation stack count */

tsgcurrptr->tsg_count = tsmcurrptr - tsgcurrptr->tsg_base;
tsgcurrptr->tsg_next = tsmcurrptr;

/* reset the tree top */

tsmcurrptr = tsgcurrptr->tsg_base;

return;
}

/*--> TSBestCaptGainMove: return best capture gain for a move */
static
cpevT
TSBestCaptGainMove(tsmptrT tsmptr)
{
cpevT cpev;

switch (tsmptr->tsm_scmv)
	{
	case scmv_reg:
		cpev = cpvalv[tsmptr->tsm_tocp];
		break;

	case scmv_epc:
		cpev = pval_p;
		break;

	case scmv_ppn:
		cpev = cpvalv[tsmptr->tsm_tocp] + (pval_n - pval_p);
		break;

	case scmv_ppb:
		cpev = cpvalv[tsmptr->tsm_tocp] + (pval_b - pval_p);
		break;

	case scmv_ppr:
		cpev = cpvalv[tsmptr->tsm_tocp] + (pval_r - pval_p);
		break;

	case scmv_ppq:
		cpev = cpvalv[tsmptr->tsm_tocp] + (pval_q - pval_p);
		break;

	default:
		cpev = 0;
		break;
	};

return (cpev);
}

/*--> TSExecute: execute a move */
static
void
TSExecute(tsmptrT tsmptr)
{
siT nullmove;

/* check for null move */

if (tsmptr->tsm_flag & tsmf_null)
	nullmove = 1;
else
	nullmove = 0;

/* update generation */

if (!nullmove)
	{
	tsmcurrptr = tsgcurrptr->tsg_next;
	tsgcurrptr++;
	};

/* save environment */

*tsecurrptr++ = ts_tse;

/* process according to special case */

if (!nullmove)
	switch (tsmptr->tsm_scmv)
		{
		case scmv_reg:
			ts_tsb.tsbv[tsmptr->tsm_frsq] = ti_cp_v0;
			ts_tsb.tsbv[tsmptr->tsm_tosq] = tsmptr->tsm_frcp;
			if (tsmptr->tsm_tocp != ti_cp_v0)
				ts_tse.tse_matv[ts_tse.tse_pasc] -=
					cpvalv[tsmptr->tsm_tocp];
			break;

		case scmv_epc:
			ts_tsb.tsbv[tsmptr->tsm_frsq] = ti_cp_v0;
			ts_tsb.tsbv[tsmptr->tsm_tosq] = tsmptr->tsm_frcp;
			if (ts_tse.tse_actc == c_w)
				{
				ts_tsb.tsbv[ts_tse.tse_epsq + dv_3] = ti_cp_v0;
				ts_tse.tse_matv[c_b] -= pval_p;
				}
			else
				{
				ts_tsb.tsbv[ts_tse.tse_epsq + dv_1] = ti_cp_v0;
				ts_tse.tse_matv[c_w] -= pval_p;
				};
			break;

		case scmv_cks:
			if (ts_tse.tse_actc == c_w)
				{
				ts_tsb.tsbv[sq_e1] = ts_tsb.tsbv[sq_h1] = ti_cp_v0;
				ts_tsb.tsbv[sq_g1] = ti_cp_wk;
				ts_tsb.tsbv[sq_f1] = ti_cp_wr;
				}
			else
				{
				ts_tsb.tsbv[sq_e8] = ts_tsb.tsbv[sq_h8] = ti_cp_v0;
				ts_tsb.tsbv[sq_g8] = ti_cp_bk;
				ts_tsb.tsbv[sq_f8] = ti_cp_br;
				};
			break;

		case scmv_cqs:
			if (ts_tse.tse_actc == c_w)
				{
				ts_tsb.tsbv[sq_e1] = ts_tsb.tsbv[sq_a1] = ti_cp_v0;
				ts_tsb.tsbv[sq_c1] = ti_cp_wk;
				ts_tsb.tsbv[sq_d1] = ti_cp_wr;
				}
			else
				{
				ts_tsb.tsbv[sq_e8] = ts_tsb.tsbv[sq_a8] = ti_cp_v0;
				ts_tsb.tsbv[sq_c8] = ti_cp_bk;
				ts_tsb.tsbv[sq_d8] = ti_cp_br;
				};
			break;

		case scmv_ppn:
			ts_tsb.tsbv[tsmptr->tsm_frsq] = ti_cp_v0;
			if (ts_tse.tse_actc == c_w)
				{
				ts_tsb.tsbv[tsmptr->tsm_tosq] = ti_cp_wn;
				ts_tse.tse_matv[c_w] += (pval_n - pval_p);
				if (tsmptr->tsm_tocp != ti_cp_v0)
					ts_tse.tse_matv[c_b] -= cpvalv[tsmptr->tsm_tocp];
				}
			else
				{
				ts_tsb.tsbv[tsmptr->tsm_tosq] = ti_cp_bn;
				ts_tse.tse_matv[c_b] += (pval_n - pval_p);
				if (tsmptr->tsm_tocp != ti_cp_v0)
					ts_tse.tse_matv[c_w] -= cpvalv[tsmptr->tsm_tocp];
				};
			break;

		case scmv_ppb:
			ts_tsb.tsbv[tsmptr->tsm_frsq] = ti_cp_v0;
			if (ts_tse.tse_actc == c_w)
				{
				ts_tsb.tsbv[tsmptr->tsm_tosq] = ti_cp_wb;
				ts_tse.tse_matv[c_w] += (pval_b - pval_p);
				if (tsmptr->tsm_tocp != ti_cp_v0)
					ts_tse.tse_matv[c_b] -= cpvalv[tsmptr->tsm_tocp];
				}
			else
				{
				ts_tsb.tsbv[tsmptr->tsm_tosq] = ti_cp_bb;
				ts_tse.tse_matv[c_b] += (pval_b - pval_p);
				if (tsmptr->tsm_tocp != ti_cp_v0)
					ts_tse.tse_matv[c_w] -= cpvalv[tsmptr->tsm_tocp];
				};
			break;

		case scmv_ppr:
			ts_tsb.tsbv[tsmptr->tsm_frsq] = ti_cp_v0;
			if (ts_tse.tse_actc == c_w)
				{
				ts_tsb.tsbv[tsmptr->tsm_tosq] = ti_cp_wr;
				ts_tse.tse_matv[c_w] += (pval_r - pval_p);
				if (tsmptr->tsm_tocp != ti_cp_v0)
					ts_tse.tse_matv[c_b] -= cpvalv[tsmptr->tsm_tocp];
				}
			else
				{
				ts_tsb.tsbv[tsmptr->tsm_tosq] = ti_cp_br;
				ts_tse.tse_matv[c_b] += (pval_r - pval_p);
				if (tsmptr->tsm_tocp != ti_cp_v0)
					ts_tse.tse_matv[c_w] -= cpvalv[tsmptr->tsm_tocp];
				};
			break;

		case scmv_ppq:
			ts_tsb.tsbv[tsmptr->tsm_frsq] = ti_cp_v0;
			if (ts_tse.tse_actc == c_w)
				{
				ts_tsb.tsbv[tsmptr->tsm_tosq] = ti_cp_wq;
				ts_tse.tse_matv[c_w] += (pval_q - pval_p);
				if (tsmptr->tsm_tocp != ti_cp_v0)
					ts_tse.tse_matv[c_b] -= cpvalv[tsmptr->tsm_tocp];
				}
			else
				{
				ts_tsb.tsbv[tsmptr->tsm_tosq] = ti_cp_bq;
				ts_tse.tse_matv[c_b] += (pval_q - pval_p);
				if (tsmptr->tsm_tocp != ti_cp_v0)
					ts_tse.tse_matv[c_w] -= cpvalv[tsmptr->tsm_tocp];
				};
			break;
		};

/* set new environment colors */

if (ts_tse.tse_actc == c_w)
	{
	ts_tse.tse_actc = c_b;
	ts_tse.tse_pasc = c_w;
	}
else
	{
	ts_tse.tse_actc = c_w;
	ts_tse.tse_pasc = c_b;
	};

/* set new environment castling */

if (!nullmove && (ts_tse.tse_cast != 0))
	{
	if (ts_tse.tse_cast & cf_wk)
		if ((tsmptr->tsm_frsq == sq_e1) ||
			(tsmptr->tsm_tosq == sq_e1) ||
			(tsmptr->tsm_frsq == sq_h1) ||
			(tsmptr->tsm_tosq == sq_h1))
			ts_tse.tse_cast &= ~cf_wk;

	if (ts_tse.tse_cast & cf_wq)
		if ((tsmptr->tsm_frsq == sq_e1) ||
			(tsmptr->tsm_tosq == sq_e1) ||
			(tsmptr->tsm_frsq == sq_a1) ||
			(tsmptr->tsm_tosq == sq_a1))
			ts_tse.tse_cast &= ~cf_wq;

	if (ts_tse.tse_cast & cf_bk)
		if ((tsmptr->tsm_frsq == sq_e8) ||
			(tsmptr->tsm_tosq == sq_e8) ||
			(tsmptr->tsm_frsq == sq_h8) ||
			(tsmptr->tsm_tosq == sq_h8))
			ts_tse.tse_cast &= ~cf_bk;

	if (ts_tse.tse_cast & cf_bq)
		if ((tsmptr->tsm_frsq == sq_e8) ||
			(tsmptr->tsm_tosq == sq_e8) ||
			(tsmptr->tsm_frsq == sq_a8) ||
			(tsmptr->tsm_tosq == sq_a8))
			ts_tse.tse_cast &= ~cf_bq;
	};

/* set new environment ep target */

ts_tse.tse_epsq = sq_nil;

if (!nullmove)
	{
	if ((tsmptr->tsm_frcp == cp_wp) &&
		(map_rank(tsmptr->tsm_frsq) == rank_2) &&
		(map_rank(tsmptr->tsm_tosq) == rank_4))
		ts_tse.tse_epsq = tsmptr->tsm_frsq + dv_1;

	if ((tsmptr->tsm_frcp == cp_bp) &&
		(map_rank(tsmptr->tsm_frsq) == rank_7) &&
		(map_rank(tsmptr->tsm_tosq) == rank_5))
		ts_tse.tse_epsq = tsmptr->tsm_frsq + dv_3;
	};

/* set the environment king squares */

if (!nullmove)
	{
	if (tsmptr->tsm_frcp == cp_wk)
		ts_tse.tse_ksqv[c_w] = tsmptr->tsm_tosq;
	if (tsmptr->tsm_frcp == cp_bk)
		ts_tse.tse_ksqv[c_b] = tsmptr->tsm_tosq;
	};

/* increment ply */

ts_ply++;

/* check and bust flags */

if (TSInCheck())
	tsmptr->tsm_flag |= tsmf_chec;

if (TSIllegal())
	tsmptr->tsm_flag |= tsmf_bust;

return;
}

/*--> TSRetract: retract a move */
static
void
TSRetract(tsmptrT tsmptr)
{
siT nullmove;

/* check for null move */

if (tsmptr->tsm_flag & tsmf_null)
	nullmove = 1;
else
	nullmove = 0;

/* decrement ply */

ts_ply--;

/* drop generation */

if (!nullmove)
	{
	tsgcurrptr--;
	tsmcurrptr = tsgcurrptr->tsg_base;
	};

/* restore environment */

ts_tse = *--tsecurrptr;

/* process according to special case */

if (!nullmove)
	switch (tsmptr->tsm_scmv)
		{
		case scmv_reg:
			ts_tsb.tsbv[tsmptr->tsm_frsq] = tsmptr->tsm_frcp;
			ts_tsb.tsbv[tsmptr->tsm_tosq] = tsmptr->tsm_tocp;
			break;

		case scmv_epc:
			ts_tsb.tsbv[tsmptr->tsm_frsq] = tsmptr->tsm_frcp;
			ts_tsb.tsbv[tsmptr->tsm_tosq] = ti_cp_v0;
			if (ts_tse.tse_actc == c_w)
				ts_tsb.tsbv[ts_tse.tse_epsq + dv_3] = ti_cp_bp;
			else
				ts_tsb.tsbv[ts_tse.tse_epsq + dv_1] = ti_cp_wp;
			break;

		case scmv_cks:
			if (ts_tse.tse_actc == c_w)
				{
				ts_tsb.tsbv[sq_f1] = ts_tsb.tsbv[sq_g1] = ti_cp_v0;
				ts_tsb.tsbv[sq_e1] = ti_cp_wk;
				ts_tsb.tsbv[sq_h1] = ti_cp_wr;
				}
			else
				{
				ts_tsb.tsbv[sq_f8] = ts_tsb.tsbv[sq_g8] = ti_cp_v0;
				ts_tsb.tsbv[sq_e8] = ti_cp_bk;
				ts_tsb.tsbv[sq_h8] = ti_cp_br;
				};
			break;

		case scmv_cqs:
			if (ts_tse.tse_actc == c_w)
				{
				ts_tsb.tsbv[sq_c1] = ts_tsb.tsbv[sq_d1] = ti_cp_v0;
				ts_tsb.tsbv[sq_e1] = ti_cp_wk;
				ts_tsb.tsbv[sq_a1] = ti_cp_wr;
				}
			else
				{
				ts_tsb.tsbv[sq_c8] = ts_tsb.tsbv[sq_d8] = ti_cp_v0;
				ts_tsb.tsbv[sq_e8] = ti_cp_bk;
				ts_tsb.tsbv[sq_a8] = ti_cp_br;
				};
			break;

		case scmv_ppn:
		case scmv_ppb:
		case scmv_ppr:
		case scmv_ppq:
			ts_tsb.tsbv[tsmptr->tsm_frsq] = tsmptr->tsm_frcp;
			ts_tsb.tsbv[tsmptr->tsm_tosq] = tsmptr->tsm_tocp;
			break;
		};

return;
}

/*--> TSSetFlags: set check and bust flags in the current moveset */
static
void
TSSetFlags(void)
{
siT i, count;
tsmptrT tsmptr;

/* assume moves already generated */

tsmptr = tsgcurrptr->tsg_base;
count = tsgcurrptr->tsg_count;
i = 0;

while (i < count)
	{
	TSExecute(tsmptr);
	TSRetract(tsmptr);
	tsmptr++;
	i++;
	};

return;
}

/*--> TSCount: return count of legal moves */
static
siT
TSCount(void)
{
siT sum;
siT i, count;
tsmptrT tsmptr;

sum = 0;

/* generate moves */

TSGenerateFull();

/* count legal moves */

tsmptr = tsgcurrptr->tsg_base;
count = tsgcurrptr->tsg_count;
i = 0;

while (i < count)
	{
	TSExecute(tsmptr);
	if (!(tsmptr->tsm_flag & tsmf_bust))
		sum++;
	TSRetract(tsmptr);
	tsmptr++;
	i++;
	};

return (sum);
}

/*--> TSSetPrels: set preliminary scores in the current moveset */
static
void
TSSetPrels(tsmptrT prevptr)
{
siT i, count;
tsmptrT tsmptr;
cpevT atk_val;
cpT tocp;
smptrT smptr;
smT mr_best_sm, km_best_sm;

/* determine historical move response */

if (prevptr->tsm_frsq == sq_nil)
	mr_best_sm = null_sm;
else
	{
	smptr = tsmrbptrv[ts_tse.tse_actc] +
		prevptr->tsm_frsq + (sqL * prevptr->tsm_tosq);
	mr_best_sm.sm_frsq = smptr->sm_frsq;
	mr_best_sm.sm_tosq = smptr->sm_tosq;
	};

/* determine historical killer move */

smptr = tskmbptrv[ts_tse.tse_actc] + ply + ts_ply;
km_best_sm = *smptr;

/* assume moves already generated */

tsmptr = tsgcurrptr->tsg_base;
count = tsgcurrptr->tsg_count;
i = 0;

while (i < count)
	{
	atk_val = ts_atkv[tsmptr->tsm_frcp];
	tocp = tsmptr->tsm_tocp;
	switch ((scmvT) tsmptr->tsm_scmv)
		{
		case scmv_reg:
			if (tocp == cp_v0)
				tsmptr->tsm_prel = -atk_val;
			else
				tsmptr->tsm_prel = ts_vicv[tocp] - atk_val;
			break;

		case scmv_cks:
			tsmptr->tsm_prel = tsppv_p;
			break;

		case scmv_cqs:
			tsmptr->tsm_prel = tsppv_p;
			break;

		case scmv_epc:
			tsmptr->tsm_prel = tsppv_p;
			break;

		case scmv_ppn:
			if (tocp == cp_v0)
				tsmptr->tsm_prel = tspv_ppn;
			else
				tsmptr->tsm_prel = ts_vicv[tocp] + tspv_ppn;
			break;

		case scmv_ppb:
			if (tocp == cp_v0)
				tsmptr->tsm_prel = tspv_ppb;
			else
				tsmptr->tsm_prel = ts_vicv[tocp] + tspv_ppb;
			break;

		case scmv_ppr:
			if (tocp == cp_v0)
				tsmptr->tsm_prel = tspv_ppr;
			else
				tsmptr->tsm_prel = ts_vicv[tocp] + tspv_ppr;
			break;

		case scmv_ppq:
			if (tocp == cp_v0)
				tsmptr->tsm_prel = tspv_ppq;
			else
				tsmptr->tsm_prel = ts_vicv[tocp] + tspv_ppq;
			break;
		};

	/* apply move response bonus */

	if (tsmptr->tsm_tosq == mr_best_sm.sm_tosq)
		if (tsmptr->tsm_frsq == mr_best_sm.sm_frsq)
			tsmptr->tsm_prel += tsppv_q;

	/* apply killer move bonus */

	if (tsmptr->tsm_tosq == km_best_sm.sm_tosq)
		if (tsmptr->tsm_frsq == km_best_sm.sm_frsq)
			tsmptr->tsm_prel += tsppv_p;

	/* next move */

	tsmptr++;
	i++;
	};

return;
}

/*--> TSSetMateEvals: set flags/evals in the current moveset (mates) */
static
void
TSSetMateEvals(tsmptrT prevptr)
{
siT i, count;
tsmptrT tsmptr;
smptrT smptr;
smT mr_best_sm, km_best_sm;

/* determine historical move response */

if (prevptr->tsm_frsq == sq_nil)
	mr_best_sm = null_sm;
else
	{
	smptr = tsmrbptrv[ts_tse.tse_actc] +
		prevptr->tsm_frsq + (sqL * prevptr->tsm_tosq);
	mr_best_sm.sm_frsq = smptr->sm_frsq;
	mr_best_sm.sm_tosq = smptr->sm_tosq;
	};

/* determine historical killer move */

smptr = tskmbptrv[ts_tse.tse_actc] + ply + ts_ply;
km_best_sm = *smptr;

/* assume moves already generated */

tsmptr = tsgcurrptr->tsg_base;
count = tsgcurrptr->tsg_count;
i = 0;

while (i < count)
	{
	TSExecute(tsmptr);

	if (tsmptr->tsm_flag & tsmf_bust)
		tsmptr->tsm_prel = cpev_bust;
	else
		{
		tsmptr->tsm_prel =
			ts_tse.tse_matv[ts_tse.tse_pasc] -
			ts_tse.tse_matv[ts_tse.tse_actc];

		/* apply move response bonus */

		if (tsmptr->tsm_tosq == mr_best_sm.sm_tosq)
			if (tsmptr->tsm_frsq == mr_best_sm.sm_frsq)
				tsmptr->tsm_prel += tsppv_q;

		/* apply killer move bonus */

		if (tsmptr->tsm_tosq == km_best_sm.sm_tosq)
			if (tsmptr->tsm_frsq == km_best_sm.sm_frsq)
				tsmptr->tsm_prel += tsppv_p;
		};

	TSRetract(tsmptr);
	tsmptr++;
	i++;
	};

return;
}

/*--> TSSortCE: sort checks+evals in the current moveset */
static
void
TSSortCE(void)
{
siT count;
siT flag, swap, pass, pair;
siT cf0, cf1;
tsmptrT tsmptr0, tsmptr1;
tsmT tsm;

count = tsgcurrptr->tsg_count;
if (count > 1)
	{
	/* set up pass loop */

	flag = 1;
	pass = 0;
	while (flag && (pass < (count - 1)))
		{
		/* set up pair loop */

		flag = 0;
		pair = 0;

		/* set pointers */

		tsmptr0 = tsgcurrptr->tsg_base;
		tsmptr1 = tsgcurrptr->tsg_base + 1;

		while (pair < (count - pass - 1))
			{
			/* assign particulars */

			cf0 = tsmptr0->tsm_flag & tsmf_chec;
			cf1 = tsmptr1->tsm_flag & tsmf_chec;

			/* determine swap status */

			if (!cf0 && cf1)
				swap = 1;
			else
				if (cf0 == cf1)
					swap = (tsmptr1->tsm_prel > tsmptr0->tsm_prel);
				else
					swap = 0;

			/* test for swap */

			if (swap)
				{
				tsm = *tsmptr0;
				*tsmptr0 = *tsmptr1;
				*tsmptr1 = tsm;
				flag = 1;
				};

			/* next pair */

			tsmptr0++;
			tsmptr1++;
			pair++;
			};

		/* next pass */

		if (flag)
			pass++;
		};
	};

return;
}

/*--> TSSetMateOrder: set ordering for mate search */
static
void
TSSetMateOrder(tsmptrT prevptr)
{
/* assume moves already generated */

TSSetMateEvals(prevptr);
TSSortCE();

return;
}

/*--> TSPickLinear: pick a move, linear scan */
static
tsmptrT
TSPickLinear(void)
{
tsmptrT tsmptr;
tsmptrT rptr;
siT i, count;

tsmptr = NULL;

rptr = tsgcurrptr->tsg_base;
count = tsgcurrptr->tsg_count;
i = 0;
while ((tsmptr == NULL) && (i < count))
	if (!(rptr->tsm_flag & tsmf_srch))
		{
		tsmptr = rptr;
		tsmptr->tsm_flag |= tsmf_srch;
		}
	else
		{
		rptr++;
		i++;
		};

return (tsmptr);
}

/*--> TSPickByPrel: pick a move, capture value scan */
static
tsmptrT
TSPickByPrel(void)
{
tsmptrT tsmptr;
tsmptrT rptr;
siT i, count;

tsmptr = NULL;

rptr = tsgcurrptr->tsg_base;
count = tsgcurrptr->tsg_count;
i = 0;
while ((i < count))
	{
	if (!(rptr->tsm_flag & tsmf_srch))
		if ((tsmptr == NULL) || (rptr->tsm_prel > tsmptr->tsm_prel))
			tsmptr = rptr;
	rptr++;
	i++;
	};

if (tsmptr != NULL)
	tsmptr->tsm_flag |= tsmf_srch;

return (tsmptr);
}

/*--> TSSearch: attempt to select a move using a tactical search */
nonstatic
mptrT
TSSearch(void)
{
mptrT tsbestmptr;

/* set up */

TSStart();

/* initialize the result */

tsbestmptr = root_sptr->s_mbase;

/* close down */

TSFinish();

return (tsbestmptr);
}

/*--> TSMateInOne: look for a mate in one */
nonstatic
mptrT
TSMateInOne(void)
{
mptrT matemptr;
tsmptrT tsmptr0, tsmptr1;
siT i0, count0;
siT i1, count1;
siT mateflag, atleast1;
siT done;
cmT cm;
mptrT hmptr;

/* set up */

done = 0;
mateflag = 0;
matemptr = NULL;

/* probe */

if (TSHashCheckDenyM1())
	done = 1;
else
	{
	cm = TSHashFetchM1();
	if (cm != 0)
		{
		hmptr = ExpandCompactMove(cm);
		if (hmptr != NULL)
			{
			mateflag = 1;
			ts_ms.m_flag = mf_chec | mf_mate;
			ts_ms.m_frsq = hmptr->m_frsq;
			ts_ms.m_tosq = hmptr->m_tosq;
			ts_ms.m_frcp = hmptr->m_frcp;
			ts_ms.m_tocp = hmptr->m_tocp;
			ts_ms.m_scmv = hmptr->m_scmv;
			ts_ms.m_eval = synth_mate(1) - ply;
			done = 1;
			};
		};
	};

/* proceed with search */

if (!done)
	{
	/* set up for search */

	TSStart();

	/* ply zero scan */

	mateflag = 0;
	TSGenerateFull();
	tsmptr0 = tsgcurrptr->tsg_base;
	count0 = tsgcurrptr->tsg_count;
	i0 = 0;

	while (!mateflag && (i0 < count0))
		{
		TSExecute(tsmptr0);
		if ((tsmptr0->tsm_flag & tsmf_chec) &&
			!(tsmptr0->tsm_flag & tsmf_bust))
			{
			TSGenerateFull();
			tsmptr1 = tsgcurrptr->tsg_base;
			count1 = tsgcurrptr->tsg_count;
			i1 = 0;
			atleast1 = 0;

			while (!atleast1 && (i1 < count1))
				{
				TSExecute(tsmptr1);
				if (!(tsmptr1->tsm_flag & tsmf_bust))
					atleast1 = 1;
				TSRetract(tsmptr1);
				tsmptr1++;
				i1++;
				};

			if (!atleast1)
				{
				mateflag = 1;
				ts_ms.m_flag = mf_chec | mf_mate;
				ts_ms.m_frsq = tsmptr0->tsm_frsq;
				ts_ms.m_tosq = tsmptr0->tsm_tosq;
				ts_ms.m_frcp = tsmptr0->tsm_frcp;
				ts_ms.m_tocp = tsmptr0->tsm_tocp;
				ts_ms.m_scmv = tsmptr0->tsm_scmv;
				ts_ms.m_eval = synth_mate(1) - ply;
				};
			};
		TSRetract(tsmptr0);
		tsmptr0++;
		i0++;
		};

	/* close down */

	TSFinish();

	/* store result */

	if (mateflag)
		TSHashStashM1(make_cm(ts_ms.m_frsq, ts_ms.m_tosq, ts_ms.m_scmv));
	else
		TSHashDenyM1();
	};

/* set result */

if (mateflag)
	matemptr = &ts_ms;

return (matemptr);
}

/*--> TSMateACOAux: mate helper (active checks only) */
static
siT
TSMateACOAux(siT n)
{
siT flag;
siT i, count;
tsmptrT rptr;

flag = 0;
TSGenerateFull();

i = 0;
count = tsgcurrptr->tsg_count;
rptr = tsgcurrptr->tsg_base;
while (!flag && (i < count))
	{
	TSExecute(rptr);
	if ((rptr->tsm_flag & tsmf_chec) &&
		!(rptr->tsm_flag & tsmf_bust))
		if (!TSLoseACOAux(n - 1))
			{
			flag = 1;
			if (ts_ply == 1)
				ts_hpmsptr = rptr;
			};
	TSRetract(rptr);
	rptr++;
	i++;
	};

return (flag);
}

/*--> TSLoseACOAux: lose helper (active checks only) */
static
siT
TSLoseACOAux(siT n)
{
siT flag;
siT i, count;
tsmptrT rptr;

flag = 0;
TSGenerateFull();

i = 0;
count = tsgcurrptr->tsg_count;
rptr = tsgcurrptr->tsg_base;
while (!flag && (i < count))
	{
	TSExecute(rptr);
	if (!(rptr->tsm_flag & tsmf_bust))
		if ((n == 0) || !TSMateACOAux(n))
			flag = 1;
	TSRetract(rptr);
	rptr++;
	i++;
	};

return (flag);
}

/*--> TSMateACO: look for a mate in N (active checks only) */
nonstatic
mptrT
TSMateACO(siT n)
{
mptrT mptr;
siT done;
mptrT hmptr;
cmT cm;

/* set up */

done = 0;
mptr = NULL;

/* probe */

if (n == 2)
	if (TSHashCheckDenyM2())
		done = 1;
	else
		{
		cm = TSHashFetchM2();
		if (cm != 0)
			{
			hmptr = ExpandCompactMove(cm);
			if (hmptr != NULL)
				{
				ts_ms.m_flag = mf_chec;
				ts_ms.m_frsq = hmptr->m_frsq;
				ts_ms.m_tosq = hmptr->m_tosq;
				ts_ms.m_frcp = hmptr->m_frcp;
				ts_ms.m_tocp = hmptr->m_tocp;
				ts_ms.m_scmv = hmptr->m_scmv;
				ts_ms.m_eval = synth_mate(2) - ply;
				mptr = &ts_ms;
				done = 1;
				};
			};
		};

/* search */

if (!done)
	if ((n > 0) && (n < plyL))
		{
		TSStart();

		if (TSMateACOAux(n))
			{
			ts_ms.m_flag = 0;
			if (ts_hpmsptr->tsm_flag & tsmf_chec)
				ts_ms.m_flag |= mf_chec;
			if (ts_hpmsptr->tsm_flag & tsmf_mate)
				ts_ms.m_flag |= mf_mate;

			ts_ms.m_frsq = ts_hpmsptr->tsm_frsq;
			ts_ms.m_tosq = ts_hpmsptr->tsm_tosq;
			ts_ms.m_frcp = ts_hpmsptr->tsm_frcp;
			ts_ms.m_tocp = ts_hpmsptr->tsm_tocp;
			ts_ms.m_scmv = ts_hpmsptr->tsm_scmv;
			ts_ms.m_eval = synth_mate(n) - ply;

			mptr = &ts_ms;
			};

		TSFinish();

		/* store result */

		if (n == 2)
			if (mptr != NULL)
				TSHashStashM2(
					make_cm(ts_ms.m_frsq, ts_ms.m_tosq, ts_ms.m_scmv));
			else
				TSHashDenyM2();
		};

return (mptr);
}

/*--> TSMateAux: mate helper */
static
siT
TSMateAux(tsmptrT prevptr, siT n)
{
siT flag;
siT i, count;
tsmptrT rptr;
smptrT smptr;
smT best_sm;

flag = 0;
best_sm = null_sm;
TSGenerateFull();

if (n > 1)
	TSSetMateOrder(prevptr);

i = 0;
count = tsgcurrptr->tsg_count;
rptr = tsgcurrptr->tsg_base;
while (!flag && (i < count))
	{
	if (0 && (ts_ply == 0) && (!(rptr->tsm_flag & tsmf_bust)) &&
		optnv[optn_trab] && optnv[optn_test])
		{
		PrTrace("AB");
		PrStr("TBMateAux: ");
		TSDumpMove(rptr);
		PrNL();
		};

	TSExecute(rptr);
	fms_nodes++;

	if (!(rptr->tsm_flag & tsmf_bust))
		if ((n > 1) || (rptr->tsm_flag & tsmf_chec))
			if (!TSLoseAux(rptr, (n - 1)))
				{
				flag = 1;
				best_sm.sm_frsq = rptr->tsm_frsq;
				best_sm.sm_tosq = rptr->tsm_tosq;
				if (ts_ply == 1)
					ts_hpmsptr = rptr;
				};
	TSRetract(rptr);
	rptr++;
	i++;
	};

/* move ordering heuristic updates */

if (best_sm.sm_frsq != sq_nil)
	{
	/* update killer move table */

	smptr = tskmbptrv[ts_tse.tse_actc] + ts_ply + ply;
	smptr->sm_frsq = best_sm.sm_frsq;
	smptr->sm_tosq = best_sm.sm_tosq;

	/* update move response table */

	if (prevptr->tsm_frsq != sq_nil)
		{
		smptr = tsmrbptrv[ts_tse.tse_actc] +
			prevptr->tsm_frsq + (sqL * prevptr->tsm_tosq);
		smptr->sm_frsq = best_sm.sm_frsq;
		smptr->sm_tosq = best_sm.sm_tosq;
		};
	};

return (flag);
}

/*--> TSLoseAux: lose helper */
static
siT
TSLoseAux(tsmptrT prevptr, siT n)
{
siT flag;
siT i, count;
siT atleast1;
tsmptrT rptr;
smptrT smptr;
smT best_sm;

flag = 0;
best_sm = null_sm;
TSGenerateFull();

if (n > 0)
	TSSetMateOrder(prevptr);

atleast1 = 0;
i = 0;
count = tsgcurrptr->tsg_count;
rptr = tsgcurrptr->tsg_base;
while (!flag && (i < count))
	{
	TSExecute(rptr);
	fms_nodes++;
	if (!(rptr->tsm_flag & tsmf_bust))
		{
		if ((n == 0) || !TSMateAux(rptr, n))
			{
			flag = 1;
			best_sm.sm_frsq = rptr->tsm_frsq;
			best_sm.sm_tosq = rptr->tsm_tosq;
			};
		atleast1 = 1;
		};
	TSRetract(rptr);
	rptr++;
	i++;
	};

if (!flag && !atleast1 && !TSInCheck())
	flag = 1;

/* move ordering heuristic updates */

if (best_sm.sm_frsq != sq_nil)
	{
	/* update killer move table */

	smptr = tskmbptrv[ts_tse.tse_actc] + ts_ply + ply;
	smptr->sm_frsq = best_sm.sm_frsq;
	smptr->sm_tosq = best_sm.sm_tosq;

	/* update move response table */

	if (prevptr->tsm_frsq != sq_nil)
		{
		smptr = tsmrbptrv[ts_tse.tse_actc] +
			prevptr->tsm_frsq + (sqL * prevptr->tsm_tosq);
		smptr->sm_frsq = best_sm.sm_frsq;
		smptr->sm_tosq = best_sm.sm_tosq;
		};
	};

return (flag);
}

/*--> TSMate: look for a mate in N */
nonstatic
mptrT
TSMate(siT n)
{
mptrT mptr;
tsmT base_tsm;

mptr = NULL;

fms_nodes = 0;

if ((n > 0) && (n < plyL))
	{
	TSClearMoveResponse();
	TSClearKillerMoves();

	TSStart();
	base_tsm = null_tsm;
	if (TSInCheck())
		base_tsm.tsm_flag |= tsmf_chec;

	if (TSMateAux(&base_tsm, n))
		{
		ts_ms.m_flag = 0;
		if (ts_hpmsptr->tsm_flag & tsmf_chec)
			ts_ms.m_flag |= mf_chec;
		if (ts_hpmsptr->tsm_flag & tsmf_mate)
			ts_ms.m_flag |= mf_mate;

		ts_ms.m_frsq = ts_hpmsptr->tsm_frsq;
		ts_ms.m_tosq = ts_hpmsptr->tsm_tosq;
		ts_ms.m_frcp = ts_hpmsptr->tsm_frcp;
		ts_ms.m_tocp = ts_hpmsptr->tsm_tocp;
		ts_ms.m_scmv = ts_hpmsptr->tsm_scmv;
		ts_ms.m_eval = synth_mate(n) - ply;

		mptr = &ts_ms;
		};

	TSFinish();
	};

return (mptr);
}

/*--> TSTMate: timed mate search */
nonstatic
mptrT
TSTMate(siT n)
{
mptrT mptr;
liT start;

start = time(NULL);
mptr = TSMate(n);
fms_seconds = time(NULL) - start;

return (mptr);
}

/*--> TSEnumerateAux: enumeration helper */
static
liT
TSEnumerateAux(siT depth)
{
liT sum, count;
siT i;
tsmptrT tsmptr;

if (depth == 0)
	sum = 1;
else
	{
	sum = 0;
	TSGenerateFull();
	tsmptr = tsgcurrptr->tsg_base;
	for (i = 0; i < tsgcurrptr->tsg_count; i++)
		{
		TSExecute(tsmptr);
		if (!(tsmptr->tsm_flag & tsmf_bust))
			count = TSEnumerateAux(depth - 1);
		else
			count = 0;
		sum += count;
		TSRetract(tsmptr);

		if ((ts_ply == 0) && optnv[optn_tren])
			{
			PrTrace("EN");
			TSDumpMove(tsmptr);
			PrStr("   ");
			PrLI(count);
			PrNL();
			};

		tsmptr++;
		};
	};

return (sum);
}

/*--> TSEnumerate: enumeration test of tactical search generation */
nonstatic
liT
TSEnumerate(siT depth)
{
liT mastercount;
liT t0, t1, elapsed;

t0 = time(NULL);
TSStart();
mastercount = TSEnumerateAux(depth);
TSFinish();
t1 = time(NULL);

/* node visits */

PrStr("Nodes: ");
PrCondOrdLINL(mastercount);

/* elapsed time */

PrStr("Seconds: ");
if (t1 == t0)
	t1++;
elapsed = t1 - t0;
PrCondOrdLI(elapsed);
if (optnv[optn_osnr])
	PrNL();
PrBlankStr("(");
PrExpandedTime(elapsed);
PrCharNL(')');

/* node frequency */

PrStr("Frequency: ");
PrFrequencyLQ(mastercount, elapsed);
PrNL();

/* node period */

PrStr("Period: ");
PrIntervalLQ(elapsed, mastercount);
PrNL();

return (mastercount);
}

/*--> TSEvalNodeAux: tactical evaluation of a node */
static
cpevT
TSEvalNodeAux(tsmptrT prevptr, cpevT alpha, cpevT beta)
{
cpevT best, value, base;
tsmptrT dtsmptr;
smT best_sm;
smptrT smptr;

best_sm = null_sm;

base = ts_tse.tse_matv[ts_tse.tse_actc] -
	ts_tse.tse_matv[ts_tse.tse_pasc];

if (prevptr->tsm_flag & tsmf_chec)
	best = -cpev_mate + ts_ply + ply;
else
	best = base;

if (best < alpha)
	best = alpha;

if (best < beta)
	{
	if (prevptr->tsm_flag & tsmf_chec)
		TSGenerateFull();
	else
		TSGenerateCapt();
	TSSetPrels(prevptr);

	while ((best < beta) &&
		((dtsmptr = TSPickByPrel()) != NULL))
		{
		if ((base + TSBestCaptGainMove(dtsmptr)) > best)
			{
			TSExecute(dtsmptr);
			if (!(dtsmptr->tsm_flag & tsmf_bust))
				{
				value = -TSEvalNodeAux(dtsmptr, -beta, -best);
				if (value > best)
					{
					best = value;
					best_sm.sm_frsq = dtsmptr->tsm_frsq;
					best_sm.sm_tosq = dtsmptr->tsm_tosq;
					};
				};
			TSRetract(dtsmptr);
			};
		};
	};

/* move ordering heuristic updates */

if (best_sm.sm_frsq != sq_nil)
	{
	/* update killer move table */

	smptr = tskmbptrv[ts_tse.tse_actc] + ts_ply + ply;
	smptr->sm_frsq = best_sm.sm_frsq;
	smptr->sm_tosq = best_sm.sm_tosq;

	/* update move response table */

	if (prevptr->tsm_frsq != sq_nil)
		{
		smptr = tsmrbptrv[ts_tse.tse_actc] +
			prevptr->tsm_frsq + (sqL * prevptr->tsm_tosq);
		smptr->sm_frsq = best_sm.sm_frsq;
		smptr->sm_tosq = best_sm.sm_tosq;
		};
	};

return (best);
}

/*--> TSEvalNode: tactical evaluation of a node */
static
cpevT
TSEvalNode(tsmptrT prevptr, cpevT alpha, cpevT beta)
{
cpevT best, value, base;
tsmptrT dtsmptr;
tsmT tsm;
smT best_sm;
smptrT smptr;

best_sm = null_sm;

if (prevptr->tsm_flag & tsmf_chec)
	best = -cpev_mate + ts_ply + ply;
else
	{
	tsm = null_tsm;
	TSExecute(&tsm);
	best = -TSEvalNodeAux(&tsm, -beta, -alpha);
	TSRetract(&tsm);
	};

if (best < alpha)
	best = alpha;

if (best < beta)
	{
	base = ts_tse.tse_matv[ts_tse.tse_actc] -
		ts_tse.tse_matv[ts_tse.tse_pasc];

	if (prevptr->tsm_flag & tsmf_chec)
		TSGenerateFull();
	else
		TSGenerateCapt();
	TSSetPrels(prevptr);

	while ((best < beta) &&
		((dtsmptr = TSPickByPrel()) != NULL))
		{
		if ((base + TSBestCaptGainMove(dtsmptr)) > best)
			{
			TSExecute(dtsmptr);
			if (!(dtsmptr->tsm_flag & tsmf_bust))
				{
				value = -TSEvalNode(dtsmptr, -beta, -best);
				if (value > best)
					{
					best = value;
					best_sm.sm_frsq = dtsmptr->tsm_frsq;
					best_sm.sm_tosq = dtsmptr->tsm_tosq;
					};
				};
			TSRetract(dtsmptr);
			};
		};
	};

/* move ordering heuristic updates */

if (best_sm.sm_frsq != sq_nil)
	{
	/* update killer move table */

	smptr = tskmbptrv[ts_tse.tse_actc] + ts_ply + ply;
	smptr->sm_frsq = best_sm.sm_frsq;
	smptr->sm_tosq = best_sm.sm_tosq;

	/* update move response table */

	if (prevptr->tsm_frsq != sq_nil)
		{
		smptr = tsmrbptrv[ts_tse.tse_actc] +
			prevptr->tsm_frsq + (sqL * prevptr->tsm_tosq);
		smptr->sm_frsq = best_sm.sm_frsq;
		smptr->sm_tosq = best_sm.sm_tosq;
		};
	};

return (best);
}

/*--> TSEval: tactical evaluation (full window) */
nonstatic
cpevT
TSEval(void)
{
cpevT cpev;

/* try a probe */

cpev = TSHashFetchCPEV();
if (cpev == cpev_wrck)
	{
	cpev = TSEvalAB(cpev_bust, cpev_mate);
	TSHashStashCPEV(cpev);
	};

return (cpev);
}

/*--> TSEvalAB: tactical evaluation with bounds */
nonstatic
cpevT
TSEvalAB(cpevT alpha, cpevT beta)
{
cpevT cpev;
tsmT root_tsm;

TSStart();

root_tsm = null_tsm;
if (TSInCheck())
	root_tsm.tsm_flag |= tsmf_chec;

/* temporary bypass of TSEvalNode() */

cpev = TSEvalNodeAux(&root_tsm, alpha, beta);

TSFinish();

return (cpev);
}

/*<<< ts.c: EOF */
