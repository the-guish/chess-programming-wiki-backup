/*>>> vsan.h: subprogram prototypes for vsan.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void VSANMove(mptrT mptr, esanT esan);

/*<<< vsan.h: EOF */
