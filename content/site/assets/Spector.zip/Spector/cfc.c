/*>>> cfc.c: console formatting control (character viewport manager) */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <ctype.h>

#include "defs.h"
#include "vars.h"

#include "vpdefs.h"

#include "cfc.h"
#include "memutil.h"

/**** Locals */

#if (os_unix)
#define cds_ansi 1
#define cds_mac  0
#else
#define cds_ansi 0
#define cds_mac  1
#endif

/* border character glyphs */

#define bcg_ne '+'
#define bcg_nw '+'
#define bcg_se '+'
#define bcg_sw '+'
#define bcg_ns '|'
#define bcg_ew '-'

/* physical stuff: x and y cursor positioning */

static siT phys_x;
static siT phys_y;

/* physical stuff: default bold and flash attributes */

static siT phys_bold;
static siT phys_flash;

/* physical stuff: default background and foreground colors */

static ascT phys_bgc;
static ascT phys_fgc;

/* viewport chain */

static cvpptrT head_cvpptr;
static cvpptrT tail_cvpptr;

/*--> CFCSetXY: move cursor to indicated absolute position */
static
void
CFCSetXY(siT x, siT y)
{
if (cds_ansi)
	printf("%c[%hd;%hdf", ascii_esc, (y + 1), (x + 1));

phys_x = x;
phys_y = y;

return;
}

/*--> CFCQSetXY: move cursor to indicated absolute position (conditional) */
static
void
CFCQSetXY(siT x, siT y)
{
if ((phys_x != x) || (phys_y != y))
	CFCSetXY(x, y);

return;
}

/*--> CFCSetFGC: set foreground color */
static
void
CFCSetFGC(ascT asc)
{
if (cds_ansi)
	printf("%c[%hdm", ascii_esc, (30 + asc));

phys_fgc = asc;

return;
}

/*--> CFCQSetFGC: set foreground color (conditional) */
static
void
CFCQSetFGC(ascT asc)
{
if (phys_fgc != asc)
	CFCSetFGC(asc);

return;
}

/*--> CFCSetBGC: set background color */
static
void
CFCSetBGC(ascT asc)
{
if (cds_ansi)
	printf("%c[%hdm", ascii_esc, (40 + asc));

phys_bgc = asc;

return;
}

/*--> CFCQSetBGC: set background color (conditional) */
static
void
CFCQSetBGC(ascT asc)
{
if (phys_bgc != asc)
	CFCSetBGC(asc);

return;
}

/*--> CFCAttrBold: set attribute: bold */
static
void
CFCAttrBold(siT flag)
{
if (cds_ansi)
	{
	if (flag)
		printf("%c[1m", ascii_esc);
	else
		{
		printf("%c[0m", ascii_esc);
		if (phys_flash)
			printf("%c[5m", ascii_esc);
		};
	};

phys_bold = flag;

return;
}

/*--> CFCQAttrBold: set attribute: bold (conditional) */
static
void
CFCQAttrBold(siT flag)
{
if (phys_bold != flag)
	CFCAttrBold(flag);

return;
}

/*--> CFCAttrFlash: set attribute: flash */
static
void
CFCAttrFlash(siT flag)
{
if (cds_ansi)
	{
	if (flag)
		printf("%c[5m", ascii_esc);
	else
		{
		printf("%c[0m", ascii_esc);
		if (phys_bold)
			printf("%c[1m", ascii_esc);
		};
	};

phys_flash = flag;

return;
}

/*--> CFCQAttrFlash: set attribute: flash (conditional) */
static
void
CFCQAttrFlash(siT flag)
{
if (phys_flash != flag)
	CFCAttrFlash(flag);

return;
}

/*--> CFCClearAttr: clear attributes */
static
void
CFCClearAttr(void)
{
if (cds_ansi)
	printf("%c[0m", ascii_esc);

phys_bold = phys_flash = 0;

return;
}

/*--> CFCClearDisplay: clear display */
static
void
CFCClearDisplay(void)
{
if (cds_ansi)
	printf("%c[2J", ascii_esc);

phys_x = phys_y = 0;

return;
}

/*--> CFCWrapOn: turn on cursor wrap */
static
void
CFCWrapOn(void)
{
if (cds_ansi)
	printf("%c[?7h", ascii_esc);

return;
}

/*--> CFCWrapOff: turn off cursor wrap */
static
void
CFCWrapOff(void)
{
if (cds_ansi)
	printf("%c[?7l", ascii_esc);

return;
}

/*--> CFCCursorOn: turn on cursor */
nonstatic
void
CFCCursorOn(void)
{
if (cds_ansi)
	printf("%c[?25h", ascii_esc);

return;
}

/*--> CFCCursorOff: turn off cursor */
nonstatic
void
CFCCursorOff(void)
{
if (cds_ansi)
	printf("%c[?25l", ascii_esc);

return;
}

/*--> CFCSetXYCVP: set viewport video cursor position */
nonstatic
void
CFCSetXYCVP(cvpptrT cvpptr, siT x, siT y)
{
siT xa, ya;

xa = cvpptr->cvp_sir.sir_sip.sip_x + x;
ya = cvpptr->cvp_sir.sir_sip.sip_y + y;
CFCSetXY(xa, ya);

fflush(stdout);

return;
}

/*--> CFCPutCharCVP: put a character to the window buffer */
nonstatic
void
CFCPutCharCVP(cvpptrT cvpptr, siT x, siT y, siT c)
{
charptrT cptr;

if ((x >= 0) && (x < cvpptr->cvp_sir.sir_siq.siq_x) &&
	(y >= 0) && (y < cvpptr->cvp_sir.sir_siq.siq_y))
	{
	cptr = cvpptr->cvp_cptr + x + (y * cvpptr->cvp_sir.sir_siq.siq_x);
	if ((c < 0x20) || (c == 0x7f))
		*cptr = '?';
	else
		*cptr = c;
	};

return;
}

/*--> CFCPutStrCVP: put a string to the window buffer */
nonstatic
void
CFCPutStrCVP(cvpptrT cvpptr, siT x, siT y, charptrT s)
{
liT i, length;

length = strlen(s);
for (i = 0; i < length; i++)
	CFCPutCharCVP(cvpptr, (x + i), y, *(s + i));

return;
}

/*--> CFCPutVCACVP: put a vca to the window buffer */
nonstatic
void
CFCPutVCACVP(cvpptrT cvpptr, siT x, siT y, vcaT vca)
{
vcaptrT aptr;

if ((x >= 0) && (x < cvpptr->cvp_sir.sir_siq.siq_x) &&
	(y >= 0) && (y < cvpptr->cvp_sir.sir_siq.siq_y))
	{
	aptr = cvpptr->cvp_aptr + x + (y * cvpptr->cvp_sir.sir_siq.siq_x);
	*aptr = vca;
	};

return;
}

/*--> CFCPutBlanksCVP: put all blanks to a CVP data field */
nonstatic
void
CFCPutBlanksCVP(cvpptrT cvpptr)
{
siT i, size;
charptrT ptr;

size = cvpptr->cvp_sir.sir_siq.siq_x * cvpptr->cvp_sir.sir_siq.siq_y;
ptr = cvpptr->cvp_cptr;
for (i = 0; i < size; i++)
	*ptr++ = ascii_sp;

return;
}

/*--> CFCNewCVP: allocate, initialize, and thread a new viewport */
nonstatic
cvpptrT
CFCNewCVP(charptrT label, siT flags, siT x0, siT y0, siT xs, siT ys)
{
cvpptrT cvpptr;
siT size, i;
vcaptrT vcaptr;

cvpptr = MemoryGrab(sizeof(cvpT));

if (label == NULL)
	cvpptr->cvp_label = NULL;
else
	cvpptr->cvp_label = StringGrab(label);
cvpptr->cvp_flags = flags;

cvpptr->cvp_sir.sir_sip.sip_x = x0;
cvpptr->cvp_sir.sir_sip.sip_y = y0;

cvpptr->cvp_sir.sir_siq.siq_x = xs;
cvpptr->cvp_sir.sir_siq.siq_y = ys;

size = xs * ys;

cvpptr->cvp_cptr = (charptrT) MemoryGrab(size);
CFCPutBlanksCVP(cvpptr);

cvpptr->cvp_aptr = (vcaptrT) MemoryGrab(sizeof(vcaT) * size);
vcaptr = cvpptr->cvp_aptr;
for (i = 0; i < size; i++)
	*vcaptr++ = make_vca(0, 0, asc_black, asc_white);

cvpptr->cvp_prev = tail_cvpptr;
cvpptr->cvp_next = NULL;

if (tail_cvpptr == NULL)
	head_cvpptr = cvpptr;
else
	tail_cvpptr->cvp_next = cvpptr;
tail_cvpptr = cvpptr;

return (cvpptr);
}

/*--> CFCReleaseCVP: unthread and release viewport */
nonstatic
void
CFCReleaseCVP(cvpptrT cvpptr)
{
if (cvpptr->cvp_prev == NULL)
	head_cvpptr = cvpptr->cvp_next;
else
	cvpptr->cvp_prev->cvp_next = cvpptr->cvp_next;

if (cvpptr->cvp_next == NULL)
	tail_cvpptr = cvpptr->cvp_prev;
else
	cvpptr->cvp_next->cvp_prev = cvpptr->cvp_prev;

if (cvpptr->cvp_cptr != NULL)
	MemoryFree(cvpptr->cvp_cptr);
if (cvpptr->cvp_aptr != NULL)
	MemoryFree(cvpptr->cvp_aptr);

if (cvpptr->cvp_label != NULL)
	MemoryFree(cvpptr->cvp_label);

MemoryFree(cvpptr);

return;
}

/*--> CFCDrawChar: draw a character */
static
void
CFCDrawChar(siT x, siT y, siT ba, siT fa, ascT bgc, ascT fgc, siT c)
{
CFCQSetXY(x, y);

CFCQAttrBold(ba);
CFCQAttrFlash(fa);

CFCQSetBGC(bgc);
CFCQSetFGC(fgc);

if ((phys_x >= 0) && (phys_x < cspan_xL))
	if ((phys_y >= 0) && (phys_y < cspan_yL))
		{
		fputc(c, stdout);
		fflush(stdout);
		phys_x++;
		};

return;
}

/*--> CFCDrawCharNF: draw a character (no flush) */
static
void
CFCDrawCharNF(siT x, siT y, siT ba, siT fa, ascT bgc, ascT fgc, siT c)
{
CFCQSetXY(x, y);

CFCQAttrBold(ba);
CFCQAttrFlash(fa);

CFCQSetBGC(bgc);
CFCQSetFGC(fgc);

if ((phys_x >= 0) && (phys_x < cspan_xL))
	if ((phys_y >= 0) && (phys_y < cspan_yL))
		{
		fputc(c, stdout);
		phys_x++;
		};

return;
}

/*--> CFCDrawDataCVP: draw a viewport data region */
nonstatic
void
CFCDrawDataCVP(cvpptrT cvpptr)
{
siT x, y;
siT x0, x1, y0, y1;
charptrT cptr;
vcaptrT aptr;
vcaT vca;

x0 = cvpptr->cvp_sir.sir_sip.sip_x;
x1 = x0 + cvpptr->cvp_sir.sir_siq.siq_x;

y0 = cvpptr->cvp_sir.sir_sip.sip_y;
y1 = y0 + cvpptr->cvp_sir.sir_siq.siq_y;

cptr = cvpptr->cvp_cptr;
aptr = cvpptr->cvp_aptr;

for (y = y0; y < y1; y++)
	{
	for (x = x0; x < x1; x++)
		{
		vca = *aptr;

		CFCDrawCharNF(x, y,
			extract_bold(vca), extract_flash(vca),
			extract_bgc(vca), extract_fgc(vca),
			*cptr);

		cptr++;
		aptr++;
		};
	fflush(stdout);
	};

return;
}

/*--> CFCDrawBorderCVP: draw a viewport border */
nonstatic
void
CFCDrawBorderCVP(cvpptrT cvpptr)
{
siT x, y;
siT x0, x1, y0, y1;
liT i, length, margin, clen;

if (cvpptr->cvp_flags & (cvpf_b0 | cvpf_b1 | cvpf_b2 | cvpf_b3))
	{
	/* fetch bounds */

	x0 = cvpptr->cvp_sir.sir_sip.sip_x;
	x1 = x0 + cvpptr->cvp_sir.sir_siq.siq_x;

	y0 = cvpptr->cvp_sir.sir_sip.sip_y;
	y1 = y0 + cvpptr->cvp_sir.sir_siq.siq_y;

	/* draw corners */

	if ((cvpptr->cvp_flags & (cvpf_b0 | cvpf_b1)) == (cvpf_b0 | cvpf_b1))
		CFCDrawChar((x0 - 1), (y0 - 1), 1, 0, asc_black, asc_white, bcg_nw);

	if ((cvpptr->cvp_flags & (cvpf_b1 | cvpf_b2)) == (cvpf_b1 | cvpf_b2))
		CFCDrawChar((x0 - 1), y1      , 1, 0, asc_black, asc_white, bcg_sw);

	if ((cvpptr->cvp_flags & (cvpf_b2 | cvpf_b3)) == (cvpf_b2 | cvpf_b3))
		CFCDrawChar(x1,       y1,       1, 0, asc_black, asc_white, bcg_se);

	if ((cvpptr->cvp_flags & (cvpf_b3 | cvpf_b0)) == (cvpf_b3 | cvpf_b0))
		CFCDrawChar(x1,       (y0 - 1), 1, 0, asc_black, asc_white, bcg_ne);

	/* draw upper bar 0 */

	if (cvpptr->cvp_flags & cvpf_b0)
		for (x = x0; x < x1; x++)
			CFCDrawChar(x, (y0 - 1), 1, 0, asc_black, asc_white, bcg_ew);

	/* draw left bar 1 */

	if (cvpptr->cvp_flags & cvpf_b1)
		for (y = y0; y < y1; y++)
			CFCDrawChar((x0 - 1), y, 1, 0, asc_black, asc_white, bcg_ns);

	/* draw lower bar 2 */

	if (cvpptr->cvp_flags & cvpf_b2)
		for (x = x0; x < x1; x++)
			CFCDrawChar(x, y1, 1, 0, asc_black, asc_white, bcg_ew);

	/* draw right bar 3 */

	if (cvpptr->cvp_flags & cvpf_b3)
		for (y = y0; y < y1; y++)
			CFCDrawChar(x1, y, 1, 0, asc_black, asc_white, bcg_ns);

	/* draw label */

	if ((cvpptr->cvp_flags & cvpf_b0) && (cvpptr->cvp_label != NULL))
		{
		/* calculate copy length */

		length = strlen(cvpptr->cvp_label);
		margin = (x1 - x0) - 5;
		if (length > margin)
			clen = margin;
		else
			clen = length;

		/* copy */

		CFCDrawChar((x0 + 2), (y0 - 1), 1, 0, asc_black, asc_white,
			ascii_sp);

		for (i = 0; i < clen; i++)
			CFCDrawChar((x0 + 3 + i), (y0 - 1), 1, 0, asc_black, asc_white,
				*(cvpptr->cvp_label + i));

		CFCDrawChar((x0 + 3 + clen), (y0 - 1), 1, 0, asc_black, asc_white,
			ascii_sp);
		};
	};

fflush(stdout);

return;
}

/*--> CFCDrawWallpaper: draw background wallpaper */
nonstatic
void
CFCDrawWallpaper(void)
{
siT x, y;

for (y = 0; y < cspan_yL; y++)
	{
	for (x = 0; x < cspan_xL; x++)
		CFCDrawCharNF(x, y, 0, 0, asc_black, asc_white, ascii_sp);
	fflush(stdout);
	};

return;
}

/*--> CFCEnter: enter CFC management */
nonstatic
void
CFCEnter(void)
{
CFCSetBGC(asc_black);
CFCSetFGC(asc_white);

CFCClearAttr();
CFCClearDisplay();

CFCWrapOff();
CFCCursorOff();

CFCSetXY(0, 0);

fflush(stdout);

return;
}

/*--> CFCExit: exit CFC management */
nonstatic
void
CFCExit(void)
{
CFCSetBGC(asc_black);
CFCSetFGC(asc_white);

CFCClearAttr();
CFCClearDisplay();

CFCCursorOn();
CFCWrapOn();

CFCSetXY(0, 0);

fflush(stdout);

return;
}

/*--> CFCInit: one time console format control initialization */
nonstatic
void
CFCInit(void)
{
head_cvpptr = tail_cvpptr = NULL;

return;
}

/*--> CFCTerm: one time console format control termination */
nonstatic
void
CFCTerm(void)
{
while (head_cvpptr != NULL)
	CFCReleaseCVP(head_cvpptr);

return;
}

/*<<< cfc.c: EOF */
