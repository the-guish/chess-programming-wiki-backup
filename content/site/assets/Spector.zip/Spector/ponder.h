/*>>> ponder.h: subprogram prototypes for ponder.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void PonderSearchReset(void);
siT PonderTestPredictedMove(void);
void PonderSearch(void);

/*<<< ponder.h: EOF */
