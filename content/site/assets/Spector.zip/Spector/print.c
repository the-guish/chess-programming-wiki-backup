/*>>> print.c: scrolling output routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bbmacs.h"
#include "vpdefs.h"

#include "bb.h"
#include "clock.h"
#include "display.h"
#include "esan.h"
#include "file.h"
#include "memutil.h"
#include "notation.h"
#include "ordstr.h"
#include "print.h"
#include "san.h"
#include "sysutil.h"
#include "tags.h"
#include "util.h"

/*--> PrChar: put text character to output */
nonstatic
void
PrChar(char c)
{
if (disenv_scroll)
	{
	(void) fputc(c, stdout);
	if (optnv[optn_flsh])
		if (c == '\n')
			(void) TextFileFlush(stdout);
	}
else
	DpWriteChar(c);

if (drib_fptr != NULL)
	{
	(void) fputc(c, drib_fptr);
	if (optnv[optn_flsh])
		if (c == '\n')
			(void) TextFileFlush(drib_fptr);
	};

return;
}

/*--> PrCharFlush: put text character to output and flush */
nonstatic
void
PrCharFlush(char c)
{
if (disenv_scroll)
	{
	(void) fputc(c, stdout);
	(void) TextFileFlush(stdout);
	}
else
	DpWriteChar(c);

if (drib_fptr != NULL)
	{
	(void) fputc(c, drib_fptr);
	(void) TextFileFlush(drib_fptr);
	};

return;
}

/*--> PrCharNoDribble: put text character to output (no dribble) */
nonstatic
void
PrCharNoDribble(char c)
{
if (disenv_scroll)
	{
	(void) fputc(c, stdout);
	if (optnv[optn_flsh])
		if (c == '\n')
			(void) TextFileFlush(stdout);
	}
else
	DpWriteChar(c);

return;
}

/*--> PrCharSEO: put text character to standard error output */
nonstatic
void
PrCharSEO(char c)
{
fputc(c, stderr);

return;
}

/*--> PrStr: put text string to output */
nonstatic
void
PrStr(charptrT s)
{
siT n;

if (s != NULL)
	{
	n = strlen(s);

	if (disenv_scroll)
		{
		(void) fputs(s, stdout);
		if (optnv[optn_flsh])
			if (*(s + n - 1) == '\n')
				(void) TextFileFlush(stdout);
		}
	else
		DpWriteStr(s);

	if (drib_fptr != NULL)
		{
		(void) fputs(s, drib_fptr);
		if (optnv[optn_flsh])
			if (*(s + n - 1) == '\n')
				(void) TextFileFlush(drib_fptr);
		};
	};

return;
}

/*--> PrStrN: put text string first N characters to output */
nonstatic
void
PrStrN(charptrT s, siT n)
{
siT i;

for (i = 0; i < n; i++)
	PrChar(*(s + i));

return;
}

/*--> PrBlankStr: put a blank and a text string to output */
nonstatic
void
PrBlankStr(charptrT s)
{
PrBlank();
PrStr(s);

return;
}

/*--> PrBlanksStr: put N blanks and a text string to output */
nonstatic
void
PrBlanksStr(siT n, charptrT s)
{
PrBlanks(n);
PrStr(s);

return;
}

/*--> PrNTSStr: put nominal tab sep. blanks and a text string to output */
nonstatic
void
PrNTSStr(charptrT s)
{
PrBlanksStr(ntsL, s);

return;
}

/*--> PrStrNoDribble: put text string to output (no dribble) */
nonstatic
void
PrStrNoDribble(charptrT s)
{
if (s != NULL)
	{
	if (disenv_scroll)
		{
		(void) printf("%s", s);
		if (optnv[optn_flsh])
			if (*(s + strlen(s) - 1) == '\n')
				(void) TextFileFlush(stdout);
		}
	else
		DpWriteStr(s);
	};

return;
}

/*--> PrTwoStrs: put two text strings to output */
nonstatic
void
PrTwoStrs(charptrT s0, charptrT s1)
{
PrStr(s0);
PrStr(s1);

return;
}

/*--> PrThreeStrs: put three text strings to output */
nonstatic
void
PrThreeStrs(charptrT s0, charptrT s1, charptrT s2)
{
PrStr(s0);
PrStr(s1);
PrStr(s2);

return;
}

/*--> PrNL: print end of line */
nonstatic
void
PrNL(void)
{
PrChar('\n');

return;
}

/*--> PrNLNoDribble: print end of line (no dribble output) */
nonstatic
void
PrNLNoDribble(void)
{
PrCharNoDribble('\n');

return;
}

/*--> PrCharNL: print a character and a newline */
nonstatic
void
PrCharNL(char c)
{
PrChar(c);
PrChar('\n');

return;
}

/*--> PrTwoStrsNL: put two text strings and an eol to output */
nonstatic
void
PrTwoStrsNL(charptrT s0, charptrT s1)
{
PrTwoStrs(s0, s1);
PrNL();

return;
}

/*--> PrThreeStrsNL: put three text strings and an eol to output */
nonstatic
void
PrThreeStrsNL(charptrT s0, charptrT s1, charptrT s2)
{
PrThreeStrs(s0, s1, s2);
PrNL();

return;
}

/*--> PrSTV: put scratch text vector to output */
nonstatic
void
PrSTV(void)
{
PrStr(stv);

return;
}

/*--> PrSTVNL: put scratch text vector with a newline */
nonstatic
void
PrSTVNL(void)
{
PrSTV();
PrNL();

return;
}

/*--> PrLine: print a string and add a newline */
nonstatic
void
PrLine(charptrT s)
{
PrStr(s);
PrNL();

return;
}

/*--> PrErr: put error text string to output */
nonstatic
void
PrErr(charptrT s)
{
PrTwoStrsNL("-- Error: ", s);

return;
}

/*--> PrErrSTV: put error text string in stv to output */
nonstatic
void
PrErrSTV(void)
{
PrErr(stv);

return;
}

/*--> PrNote: put notification text string to output */
nonstatic
void
PrNote(charptrT s)
{
if (optnv[optn_verb])
	PrTwoStrsNL("-- Note: ", s);

return;
}

/*--> PrWarning: put warning text string to output */
nonstatic
void
PrWarning(charptrT s)
{
PrTwoStrsNL("-- Warning: ", s);

return;
}

/*--> PrTrace: print a trace label */
nonstatic
void
PrTrace(charptrT s)
{
stampT stamp;

if (optnv[optn_trts])
	{
	TimeStamp(stamp);
	PrTwoStrsNL("TS: ", stamp);
	};
PrTwoStrs(s, ": ");

return;
}

/*--> PrStrNoTrailingBlanks: print string with no trailing blanks */
nonstatic
void
PrStrNoTrailingBlanks(charptrT s)
{
siT i, n;

if (s != NULL)
	{
	n = strlen(s);
	while ((n > 0) && (*(s + n - 1) == ascii_sp))
		n--;
	for (i = 0; i < n; i++)
		PrChar(*(s + i));
	};

return;
}

/*--> PrBlank: print a single blank */
nonstatic
void
PrBlank(void)
{
PrChar(ascii_sp);

return;
}

/*--> PrBlanks: print multiple blanks */
nonstatic
void
PrBlanks(siT n)
{
siT i;

for (i = 0; i < n; i++)
	PrChar(ascii_sp);

return;
}

/*--> PrLineWithSixBlanks: print line with six space margin */
static
void
PrLineWithSixBlanks(charptrT s)
{
PrBlanks(6);
PrLine(s);

return;
}

/*--> PrNineLinesWithSixBlanks: logo helper */
static
void
PrNineLinesWithSixBlanks(charptrT s0, charptrT s1, charptrT s2, charptrT s3,
	charptrT s4, charptrT s5, charptrT s6, charptrT s7, charptrT s8)
{
PrLineWithSixBlanks(s0);
PrLineWithSixBlanks(s1);
PrLineWithSixBlanks(s2);
PrLineWithSixBlanks(s3);
PrLineWithSixBlanks(s4);
PrLineWithSixBlanks(s5);
PrLineWithSixBlanks(s6);
PrLineWithSixBlanks(s7);
PrLineWithSixBlanks(s8);

return;
}

/*--> PrLogoBanner: print the program logo */
nonstatic
void
PrLogoBanner(void)
{
PrNineLinesWithSixBlanks(
	("-------------------------------------------------------------------"),
	(" SSSSS    PPPPPP    EEEEEEE    CCCCC    TTTTTTT    OOOOO    RRRRRR "),
	("S     S   P     p   E         C     C      T      O     O   R     R"),
	("S         P     P   E         C            T      O     O   R     R"),
	(" SSSSS    PPPPPP    EEEEE     C            T      O     O   RRRRRR "),
	("      S   P         E         C            T      O     O   R   R  "),
	("S     S   P         E         C     C      T      O     O   R    R "),
	(" SSSSS    P         EEEEEEE    CCCCC       T       OOOOO    R     R"),
	("-------------------------------------------------------------------"));

return;
}

/*--> PrInformationBanner: print identification information */
nonstatic
void
PrInformationBanner(void)
{
charptrT title;

PrNL();

/* sign on information */

title = "A Chessplaying Program";
(void) sprintf(stv,
	"  ====================  %s: %s  ====================",
	progname, title);
PrSTVNL();

(void) sprintf(stv,
	"  =================  Version %s  Generated %s  =================",
	progvers, progdate);
PrSTVNL();

(void) sprintf(stv,
	"  ===========  USCF ID: %s  USCF Member through %s  ===========",
	proguscf, progexpr);
PrSTVNL();

(void) sprintf(stv,
	"  ===  Copyright (C) 1996 by %s.  All rights reserved.  ===",
	progauth);
PrSTVNL();

PrNL();

return;
}

/*--> PrTimestamp: print timestamp */
nonstatic
void
PrTimestamp(void)
{
stampT stamp;

TimeStamp(stamp);
PrLine(stamp);

return;
}

/*--> PrSI: print short integer */
nonstatic
void
PrSI(siT n)
{
(void) sprintf(stv, pfs_si, n);
PrSTV();

return;
}

/*--> PrHexDigitSI: print single hex digit */
static
void
PrHexDigitSI(siT n)
{
if ((n < 0) || (n >= 16))
	PrChar('?');
else
	PrChar(cv_ahc_iv[n]);

return;
}

/*--> PrHexByteSI: print hex digit pair */
static
void
PrHexByteSI(siT n)
{
if ((n < 0) || (n >= 256))
	PrStr("??");
else
	{
	PrHexDigitSI((n >> nybbW) & nybbM);
	PrHexDigitSI(n & nybbM);
	};

return;
}

/*--> PrHexWordLI: print hex digit quad */
static
void
PrHexWordLI(liT n)
{
if ((n < 0) || (n >= 65536L))
	PrStr("??");
else
	{
	PrHexByteSI((n >> byteW) & longbyteM);
	PrHexByteSI(n & longbyteM);
	};

return;
}

/*--> PrHexDWordLI: print hex digit double quad */
nonstatic
void
PrHexDWordLI(liT n)
{
PrHexWordLI((n >> wordW) & longwordM);
PrHexWordLI(n & longwordM);

return;
}

/*--> PrTwoDigitSI: print two digit short integer */
nonstatic
void
PrTwoDigitSI(siT n)
{
(void) sprintf(stv, "%02hd", n);
PrSTV();

return;
}

/*--> PrLI: print long integer */
nonstatic
void
PrLI(liT n)
{
(void) sprintf(stv, pfs_li, n);
PrSTV();

return;
}

/*--> PrStrLI: print a string and a long integer */
nonstatic
void
PrStrLI(charptrT s, liT n)
{
PrStr(s);
PrLI(n);

return;
}

/*--> PrStrLINL: print a string, a long integer, and newline */
nonstatic
void
PrStrLINL(charptrT s, liT n)
{
PrStrLI(s, n);
PrNL();

return;
}

/*--> PrPointer: print pointer value */
nonstatic
void
PrPointer(voidptrT s)
{
PrHexDWordLI((uliT) s);

return;
}

/*--> PrStrSI: print a string and a short integer */
nonstatic
void
PrStrSI(charptrT s, siT n)
{
PrStr(s);
PrSI(n);

return;
}

/*--> PrStrSINL: print a string, a short integer, and newline */
nonstatic
void
PrStrSINL(charptrT s, siT n)
{
PrStrSI(s, n);
PrNL();

return;
}

/*--> PrOrdSI: print ordinal string short integer */
static
void
PrOrdSI(siT n)
{
PrStr(OrdSIStr(n));

return;
}

/*--> PrOrdLI: print ordinal string long integer */
static
void
PrOrdLI(liT n)
{
PrStr(OrdLIStr(n));

return;
}

/*--> PrCondOrdSI: print conditional short integer */
nonstatic
void
PrCondOrdSI(siT n)
{
if (optnv[optn_osnr])
	PrOrdSI(n);
else
	PrSI(n);

return;
}

/*--> PrCondOrdSINL: print conditional short integer with newline */
nonstatic
void
PrCondOrdSINL(siT n)
{
PrCondOrdSI(n);
PrNL();

return;
}

/*--> PrCondOrdLI: print conditional long integer */
nonstatic
void
PrCondOrdLI(liT n)
{
if (optnv[optn_osnr])
	PrOrdLI(n);
else
	PrLI(n);

return;
}

/*--> PrCondOrdLINL: print cond long integer and newline */
nonstatic
void
PrCondOrdLINL(liT n)
{
PrCondOrdLI(n);
PrNL();

return;
}

/*--> PrStrCondOrdLINL: print s, cond long, and newline */
nonstatic
void
PrStrCondOrdLINL(charptrT s, liT n)
{
PrStr(s);
PrCondOrdLINL(n);

return;
}

/*--> PrNil: print a nil */
nonstatic
void
PrNil(void)
{
PrStr(nilstr);

return;
}

/*--> PrPlayer: print player string */
nonstatic
void
PrPlayer(cT c)
{
switch (c)
	{
	case c_w:
		PrStr(rsvtagv[rsvtag_white]);
		break;

	case c_b:
		PrStr(rsvtagv[rsvtag_black]);
		break;

	default:
		PrNil();
		break;
	};

return;
}

/*--> PrColor: print color string */
nonstatic
void
PrColor(cT c)
{
if (c == c_nil)
	PrNil();
else
	PrStr(cstrv[c]);

return;
}

/*--> PrPiece: print piece string */
nonstatic
void
PrPiece(pT p)
{
if (p == p_nil)
	PrNil();
else
	PrStr(pstrv[p]);

return;
}

/*--> PrColorChar: print a color */
nonstatic
void
PrColorChar(cT c)
{
PrChar(asccv[lang_san][c]);

return;
}

/*--> PrPieceChar: print a piece */
nonstatic
void
PrPieceChar(pT p)
{
PrChar(ascpv[lang_san][p]);

return;
}

/*--> PrColorPiece: print a color-piece */
nonstatic
void
PrColorPiece(cpT cp)
{
if (cp == cp_nil)
	PrNil();
else
	{
	PrColorChar(cv_c_cpv[cp]);
	PrPieceChar(cv_p_cpv[cp]);
	};

return;
}

/*--> PrBlankColorPiece: print a blank followed by a color-piece */
nonstatic
void
PrBlankColorPiece(cpT cp)
{
PrBlank();
PrColorPiece(cp);

return;
}

/*--> PrFileChar: print a file */
nonstatic
void
PrFileChar(fileT file)
{
PrChar(ascfv[file]);

return;
}

/*--> PrRankChar: print a rank */
nonstatic
void
PrRankChar(rankT rank)
{
PrChar(ascrv[rank]);

return;
}

/*--> PrSq: print a square */
nonstatic
void
PrSq(sqT sq)
{
if (sq == sq_nil)
	PrNil();
else
	{
	PrFileChar(map_file(sq));
	PrRankChar(map_rank(sq));
	};

return;
}

/*--> PrBlankSq: print a blank, then a square */
nonstatic
void
PrBlankSq(sqT sq)
{
PrBlank();
PrSq(sq);

return;
}

/*--> PrBlankColorPieceSq: print a blank, then a cp-square */
nonstatic
void
PrBlankColorPieceSq(cpT cp, sqT sq)
{
PrBlank();
PrColorPiece(cp);
PrSq(sq);

return;
}

/*--> PrSpecialCaseIndication: print a special case move indication */
nonstatic
void
PrSpecialCaseIndication(scmvT scmv)
{
if (scmv == scmv_nil)
	PrNil();
else
	PrStr(scmvstrv[scmv]);

return;
}

/*--> PrSqList: print square list from local board */
nonstatic
void
PrSqList(bbT bb)
{
sqT sq;

while (bb_next(bb, sq))
	{
	PrBlank();
	PrColorPiece(local.rbv[sq]);
	PrSq(sq);
	};

return;
}

/*--> PrBitBoard: print a bitboard */
nonstatic
void
PrBitBoard(bbT bb)
{
rankT rank;
fileT file;

/* this output may be spun */

if (!optnv[optn_spin])
	{
	for (rank = rank_8; rank >= rank_1; rank--)
		{
		for (file = file_a; file <= file_h; file++)
			{
			PrBlank();
			PrChar((bb_tstsqrf(bb, rank, file) ? '1' : ascii_zero));
			};
		PrNL();
		};
	}
else
	{
	for (rank = rank_1; rank <= rank_8; rank++)
		{
		for (file = file_h; file >= file_a; file--)
			{
			PrBlank();
			PrChar((bb_tstsqrf(bb, rank, file) ? '1' : ascii_zero));
			};
		PrNL();
		};
	};

return;
}

/*--> PrBitBoardVector: print a bitboard vector*/
nonstatic
void
PrBitBoardVector(bbT bb)
{
sqT sq;

for (sq = sq_a1; sq <= sq_h8; sq++)
	if (bb_tstsq(bb, sq))
		PrChar('1');
	else
		PrChar('0');

return;
}

/*--> PrBoard: print a regular board (compressed) */
nonstatic
void
PrBoard(rbptrT rbptr)
{
rankT rank;
fileT file;
cpT cp;
charptrT s_white, s_black;

/* assign white and black vacant square strings */

if (optnv[optn_dwob])
	{
	s_white = "::";
	s_black = "  ";
	}
else
	{
	s_white = "  ";
	s_black = "::";
	};

/* this output may be spun */

if (!optnv[optn_spin])
	{
	for (rank = rank_8; rank >= rank_1; rank--)
		{
		for (file = file_a; file <= file_h; file++)
			if ((cp = rbptr->rbm[rank][file]) == cp_v0)
				if (bb_tstsqrf(csbbv[c_b], rank, file))
					PrStr(s_black);
				else
					PrStr(s_white);
			else
				PrColorPiece(cp);
		PrNL();
		};
	}
else
	{
	for (rank = rank_1; rank <= rank_8; rank++)
		{
		for (file = file_h; file >= file_a; file--)
			if ((cp = rbptr->rbm[rank][file]) == cp_v0)
				if (bb_tstsqrf(csbbv[c_b], rank, file))
					PrStr(s_black);
				else
					PrStr(s_white);
			else
				PrColorPiece(cp);
		PrNL();
		};
	};

return;
}

/*--> PrCentipawn: print centipawn evaluation */
nonstatic
void
PrCentipawn(cpevT cpev)
{
char cpsign;
liT cpabs;

if (cpev >= 0)
	{
	cpsign = '+';
	cpabs = cpev;
	}
else
	{
	cpsign = '-';
	cpabs = -cpev;
	};

(void) sprintf(stv, "%c%ld.%02ld",
	cpsign, (cpabs / hundred), (cpabs % hundred));
PrSTV();

return;
}

/*--> PrStrCentipawn: print a string and a centipawn evaluation */
nonstatic
void
PrStrCentipawn(charptrT s, cpevT cpev)
{
PrStr(s);
PrCentipawn(cpev);

return;
}

/*--> PrStrCentipawnNL: print string, centipawn value, and newline */
nonstatic
void
PrStrCentipawnNL(charptrT s, cpevT cpev)
{
PrStrCentipawn(s, cpev);
PrNL();

return;
}

/*--> PrMillipawn: print millipawn evaluation */
nonstatic
void
PrMillipawn(mpevT mpev)
{
char mpsign;
liT mpabs;

if (mpev >= 0)
	{
	mpsign = '+';
	mpabs = mpev;
	}
else
	{
	mpsign = '-';
	mpabs = -mpev;
	};

(void) sprintf(stv, "%c%ld.%03ld",
	mpsign, (mpabs / thousand), (mpabs % thousand));
PrSTV();

return;
}

/*--> PrStrMillipawn: print a string and a millipawn evaluation */
nonstatic
void
PrStrMillipawn(charptrT s, mpevT mpev)
{
PrStr(s);
PrMillipawn(mpev);

return;
}

/*--> PrABS: print alpha, beta, and score */
nonstatic
void
PrABS(cpevT alpha, cpevT beta, cpevT score)
{
PrStrCentipawn("alpha: ", alpha);
PrStrCentipawn("   beta: ", beta);
PrStrCentipawn("   score: ", score);

return;
}

/*--> PrFrequencyLQ: print a frequency (long quotient) */
nonstatic
void
PrFrequencyLQ(liT num, liT den)
{
FormatSTVLQF(num, den);
PrSTV();

return;
}

/*--> PrIntervalLQ: print an interval (long quotient) */
nonstatic
void
PrIntervalLQ(liT num, liT den)
{
FormatSTVLQI(num, den);
PrSTV();

return;
}

/*--> PrFrequencyReport: print node frequency data */
nonstatic
void
PrFrequencyReport(liT dn, liT dt)
{
PrStrLI("Nodes: ", dn);
PrStrLI("   Seconds: ", dt);
if ((dn > 0) && (dt > 0))
	{
	PrStr("   Frequency: ");
	PrFrequencyLQ(dn, dt);
	PrStr("   Period: ");
	PrIntervalLQ(dt, dn);
	};
PrNL();

return;
}

/*--> PrExecFrequencyReport: print search node frequency data */
nonstatic
void
PrExecFrequencyReport(liT start_exec, time_t start_time)
{
PrFrequencyReport((count_exec - start_exec),
	((liT) (time(NULL) - start_time)));

return;
}

/*--> PrSearchFrequencyReport: print search node frequency data */
nonstatic
void
PrSearchFrequencyReport(liT start_node, time_t start_time)
{
PrFrequencyReport((count_node - start_node),
	((liT) (time(NULL) - start_time)));

return;
}

/*--> PrCompactMove: print a compact move */
nonstatic
void
PrCompactMove(cmT cm)
{
PrSq(cm_frsq(cm));
PrSq(cm_tosq(cm));
PrStr(scmvstrv[cm_scmv(cm)]);

return;
}

/*--> PrMovesetFlags: print moveset flag set */
nonstatic
void
PrMovesetFlags(sptrT sptr)
{
sfiT sfi;
siT flag;

flag = 0;
PrChar('[');
for (sfi = 0; sfi < sfiL; sfi++)
	if (sptr->s_sflag & (bit << sfi))
		if (flag)
			{
			PrBlank();
			PrStr(sflagstrv[sfi]);
			}
		else
			{
			PrStr(sflagstrv[sfi]);
			flag = 1;
			};
PrChar(']');

return;
}

/*--> PrMoveFlags: print move flag set */
nonstatic
void
PrMoveFlags(mptrT mptr)
{
mfiT mfi;
siT flag;

flag = 0;
PrChar('[');
for (mfi = 0; mfi < mfiL; mfi++)
	if (mptr->m_flag & (bit << mfi))
		if (flag)
			{
			PrBlank();
			PrStr(mflagstrv[mfi]);
			}
		else
			{
			PrStr(mflagstrv[mfi]);
			flag = 1;
			};
PrChar(']');

return;
}

/*--> PrTM: print a tiny move */
nonstatic
void
PrTM(tmptrT tmptr)
{
PrColorPiece(tmptr->tm_frcp);
PrSq(tmptr->tm_frsq);
PrChar('-');
PrColorPiece(tmptr->tm_tocp);
PrSq(tmptr->tm_tosq);

return;
}

/*--> PrPaddedSAN: print an algebraic move (with appended blanks) */
nonstatic
void
PrPaddedSAN(mptrT mptr)
{
sanT san;

ConstructNotation(global_nm, mptr, san);
(void) sprintf(stv, pfs_move, san);
PrSTV();

return;
}

/*--> PrSAN: print an algebraic move (without appended blanks) */
nonstatic
void
PrSAN(mptrT mptr)
{
sanT san;

ConstructNotation(global_nm, mptr, san);
PrStr(san);

return;
}

/*--> PrSANNL: print an algebraic move and a newline */
nonstatic
void
PrSANNL(mptrT mptr)
{
PrSAN(mptr);
PrNL();

return;
}

/*--> PrStrSANNL: print a string, an algebraic move, and a newline */
nonstatic
void
PrStrSANNL(charptrT s, mptrT mptr)
{
PrStr(s);
PrSANNL(mptr);

return;
}

/*--> PrStrSAN: print a string and an algebraic move */
nonstatic
void
PrStrSAN(charptrT s, mptrT mptr)
{
PrStr(s);
PrSAN(mptr);

return;
}

/*--> PrSANSortList: print a sorted list of algebraic moves */
nonstatic
void
PrSANSortList(sptrT sptr)
{
sanptrT sanptr0, sanptr1;
mptrT mptr;
siT i, j, count, n, len;
sanT san;

/* allocate for san moves */

count = sptr->s_count;
sanptr0 = (sanptrT) MemoryGrab(sizeof(sanT) * count);

/* generate and copy san moves */

mptr = sptr->s_mbase;
sanptr1 = sanptr0;
for (i = 0; i < count; i++)
	{
	ConstructNotation(global_nm, mptr, san);
	for (j = 0; j < sanL; j++)
		*(((charptrT) sanptr1) + j) = san[j];
	mptr++;
	sanptr1++;
	};

/* sort */

SANSortList(sanptr0, count);

/* print */

n = 0;
sanptr1 = sanptr0;
for (i = 0; i < count; i++)
	{
	len = strlen((charptrT) sanptr1);
	if ((n + 1 + len) >= souwL)
		{
		PrNL();
		n = 0;
		};
	if (n == 0)
		{
		n = 1;
		PrBlanks(n);
		};
	PrBlankStr((charptrT) sanptr1);
	n += len + 1;
	sanptr1++;
	};
PrNL();

/* free storage */

MemoryFree(sanptr0);

return;
}

/*--> PrExpandedSAN: print an expanded string algebraic move */
nonstatic
void
PrExpandedSAN(mptrT mptr)
{
esanT esan;

ESANMove(mptr, esan);
PrStr(esan);

return;
}

/*--> PrCondExpandedSAN: print a conditionally expanded SAN move */
nonstatic
void
PrCondExpandedSAN(mptrT mptr)
{
if (optnv[optn_expn])
	PrExpandedSAN(mptr);
else
	PrSAN(mptr);

return;
}

/*--> PrMovePath: print a move trace */
nonstatic
void
PrMovePath(sptrT sptr)
{
mptrT mptr;
sptrT sptr1;
siT p, flag;

p = 0;
flag = 0;
sptr1 = sptr;
while ((p < ply) && (sptr1 != NULL))
	if ((mptr = sptr1->s_mcurr) != NULL)
		{
		if (flag)
			PrBlank();
		PrSAN(mptr);
		flag = 1;
		sptr1 = mptr->m_dptr;
		p++;
		}
	else
		sptr1 = NULL;

return;
}

/*--> PrCurrentPath: print a move trace from the root */
nonstatic
void
PrCurrentPath(void)
{
PrMovePath(root_sptr);

return;
}

/*--> PrStrGameStatusNL: print string, game status, and a newline */
nonstatic
void
PrStrGameStatusNL(charptrT s, gsT gs)
{
PrStr(s);
PrLine(gsstrv[gs]);

return;
}

/*--> PrCurrentTimeControl: print current time control */
nonstatic
void
PrCurrentTimeControl(void)
{
liT current_mvc, current_sec;
siT period;

/* fetch current period and scalars */

period = TimeControlPeriod();
current_mvc = tcntlv[period].tcntl_mvc;
current_sec = tcntlv[period].tcntl_sec;

/* print */

if (current_sec == 0)
	PrLine("Instantaneous");
else
	if (current_mvc == 0)
		{
		PrStr("Game in ");
		PrCondOrdLI(current_sec);
		PrLine(" seconds");
		}
	else
		{
		PrCondOrdLI(current_mvc);
		PrStr(" moves in ");
		PrCondOrdLI(current_sec);
		PrStr(" seconds (");
		PrCondOrdLI(current_sec / current_mvc);
		PrLine(" sec/mv)");
		};

return;
}

/*--> PrExpandedTime: print elapsed time (long format) */
nonstatic
void
PrExpandedTime(liT t)
{
timerecT tr;

/* calculate time record */

EncodeTimeRecord(t, &tr);

/* print time values */

if (tr.timerec_day > 0)
	{
	PrCondOrdLI(tr.timerec_day);
	PrStr(" day");
	if (tr.timerec_day != 1)
		PrChar('s');
	PrStr(", ");
	};

if (tr.timerec_hour > 0)
	{
	PrCondOrdLI(tr.timerec_hour);
	PrStr(" hour");
	if (tr.timerec_hour != 1)
		PrChar('s');
	PrStr(", ");
	};

if (tr.timerec_minute > 0)
	{
	PrCondOrdLI(tr.timerec_minute);
	PrStr(" minute");
	if (tr.timerec_minute != 1)
		PrChar('s');
	PrStr(", ");
	};

PrCondOrdLI(tr.timerec_second);
PrStr(" second");
if (tr.timerec_second != 1)
	PrChar('s');

return;
}

/*<<< print.c: EOF */
