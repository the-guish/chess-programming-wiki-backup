/*>>> attack.h: subprogram prototypes for attack.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void AttackAdd(sqT sq);
void AttackDel(sqT sq);
void AttackPro(sqT sq);
void AttackCut(sqT sq);
void AttackSet(void);

/*<<< attack.h: EOF */
