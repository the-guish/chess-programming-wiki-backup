/*>>> test.h: subprogram prototypes for test.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void Test(void);

/*<<< test.h: EOF */
