/*>>> esan.c: expanded standard algebraic notation routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "esan.h"
#include "sysutil.h"

/**** Locals */

/* character insertion pointer and index */

static charptrT esan_ptr;
static siT esan_index;

/*--> ESANChar: insert a character  */
static
void
ESANChar(char ch)
{
if (esan_index < esanL)
	{
	*esan_ptr++ = ch;
	esan_index++;
	}
else
	Diagnose("ESANChar: fault");

return;
}

/*--> ESANBlank: insert a blank */
static
void
ESANBlank(void)
{
ESANChar(ascii_sp);

return;
}

/*--> ESANStr: insert a string  */
static
void
ESANStr(charptrT s)
{
siT i;
char ch;

i = 0;
while ((ch = *(s + i++)) != ascii_nul)
	ESANChar(ch);

return;
}

/*--> ESANColor: insert color from color-piece */
static
void
ESANColor(cpT cp)
{
ESANStr(cstrv[cv_c_cpv[cp]]);

return;
}

/*--> ESANPiece: insert piece from color-piece */
static
void
ESANPiece(cpT cp)
{
ESANStr(pstrv[cv_p_cpv[cp]]);

return;
}

/*--> ESANColorPiece: insert color piece string */
static
void
ESANColorPiece(cpT cp)
{
ESANColor(cp);
ESANBlank();
ESANPiece(cp);

return;
}

/*--> ESANRank: insert rank character from square */
static
void
ESANRank(sqT sq)
{
ESANChar(ascrv[map_rank(sq)]);

return;
}

/*--> ESANFile: insert file character from square */
static
void
ESANFile(sqT sq)
{
ESANChar(ascfv[map_file(sq)]);

return;
}

/*--> ESANSquare: insert square character pair */
static
void
ESANSquare(sqT sq)
{
ESANStr("square ");
ESANFile(sq);
ESANRank(sq);

return;
}

/*--> ESANMove: generate an extended SAN move string */
nonstatic
void
ESANMove(mptrT mptr, esanT esan)
{
/* initialize pointer and index */

esan_ptr = (charptrT) esan;
esan_index = 0;

/* check for null move */

if (mptr->m_flag & mf_null)
	ESANStr("<Null move>");
else
	{
	/* output color */

	ESANColor(mptr->m_frcp);

	/* process according to moving piece */

	ESANBlank();
	switch (cv_p_cpv[mptr->m_frcp])
		{
		case p_p:
			/* insert moving piece name */

			ESANPiece(mptr->m_frcp);

			/* move or capture */

			ESANBlank();
			if ((mptr->m_tocp == cp_v0) && (mptr->m_scmv != scmv_epc))
				{
				ESANStr("moves to ");
				ESANSquare(mptr->m_tosq);
				}
			else
				{
				ESANStr("at file ");
				ESANFile(mptr->m_frsq);
				ESANStr(" takes ");
				if (mptr->m_scmv != scmv_epc)
					ESANColorPiece(mptr->m_tocp);
				else
					{
					ESANStr(cstrv[inv_cv[cv_c_cpv[mptr->m_frcp]]]);
					ESANBlank();
					ESANStr(pstrv[p_p]);
					};
				ESANStr(" at ");
				ESANSquare(mptr->m_tosq);
				};

			/* special case suffixes */

			switch (mptr->m_scmv)
				{
				case scmv_reg:
					break;

				case scmv_epc:
					ESANStr(" en passant");
					break;

				case scmv_ppn:
				case scmv_ppb:
				case scmv_ppr:
				case scmv_ppq:
					ESANStr(" and promotes to ");
					ESANStr(pstrv[cv_p_scmvv[mptr->m_scmv]]);
					break;

				case scmv_cks:
				case scmv_cqs:
				default:
					SwitchFault("ESANMove");
					break;
				};
			break;

		case p_n:
		case p_b:
		case p_r:
		case p_q:
			/* insert moving piece name */

			ESANPiece(mptr->m_frcp);

			/* process disambiguation */

			if (mptr->m_flag & mf_anfp)
				{
				ESANStr(" at ");
				if (mptr->m_flag & mf_anrp)
					ESANSquare(mptr->m_frsq);
				else
					{
					ESANStr("file ");
					ESANFile(mptr->m_frsq);
					};
				}
			else
				if (mptr->m_flag & mf_anrp)
					{
					ESANStr(" at rank ");
					ESANRank(mptr->m_frsq);
					};

			/* move or capture ? */

			ESANBlank();
			if (mptr->m_tocp == cp_v0)
				ESANStr("moves to");
			else
				{
				ESANStr("takes ");
				ESANColorPiece(mptr->m_tocp);
				ESANStr(" at");
				};
			ESANBlank();
			ESANSquare(mptr->m_tosq);
			break;

		case p_k:
			switch (mptr->m_scmv)
				{
				case scmv_reg:
					ESANStr(pstrv[p_k]);
					ESANBlank();

					/* move or capture ? */

					if (mptr->m_tocp == cp_v0)
						ESANStr("moves to");
					else
						{
						ESANStr("takes ");
						ESANColorPiece(mptr->m_tocp);
						ESANStr(" at");
						};
					ESANBlank();
					ESANSquare(mptr->m_tosq);
					break;

				case scmv_cks:
					ESANStr("castles kingside");
					break;

				case scmv_cqs:
					ESANStr("castles queenside");
					break;

				case scmv_epc:
				case scmv_ppn:
				case scmv_ppb:
				case scmv_ppr:
				case scmv_ppq:
				default:
					SwitchFault("ESANMove");
					break;
				};
			break;

		default:
			SwitchFault("ESANMove");
			break;
		};
	};

/* indication: check */

if ((mptr->m_flag & mf_chec) && !(mptr->m_flag & mf_mate))
	ESANStr(" with check");

/* indication: checkmate */

if (mptr->m_flag & mf_mate)
	ESANStr(" with checkmate");

/* indication: draw */

if (mptr->m_flag & mf_draw)
	ESANStr(" with a draw");

/* indication: illegal */

if (mptr->m_flag & mf_bust)
	ESANStr(" <illegal>");

/* insert trailing NULs */

do
	{
	ESANChar(ascii_nul);
	}
while (esan_index < esanL);

return;
}

/*<<< esan.c: EOF */
