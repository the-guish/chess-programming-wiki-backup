/*>>> fen.c: chess move Forsyth-Edwards notation mode processing */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"

#include "commdefs.h"

#include "epddefs.h"

#include "epd.h"
#include "fen.h"
#include "memutil.h"
#include "parm.h"
#include "util.h"

/*--> FENGenerate: FEN EPD string allocation and generation (output only) */
nonstatic
charptrT
FENGenerate(void)
{
charptrT ptr;
charptrT ebptr;
siT bi;
char bv[tL], nv[tL];

/* generate EPD basic */

ebptr = EPDGenBasic(&local, actc, envn.envn_cast, envn.envn_epsq);
strcpy(bv, ebptr);
MemoryFree(ebptr);
bi = strlen(bv);
bv[bi++] = ' ';

/* output halfmove clock */

(void) sprintf(nv, "%hd", envn.envn_hmvc);
(void) sprintf(&bv[bi], "%s", nv);
bi += strlen(nv);
bv[bi++] = ' ';

/* output fullmove number (last field) */

(void) sprintf(nv, "%hd", envn.envn_fmvn);
(void) sprintf(&bv[bi], "%s", nv);
bi += strlen(nv);

/* NUL termination */

bv[bi++] = ascii_nul;

ptr = StringGrab(bv);

return (ptr);
}

/*--> FENParseBD: check and translate Forsyth-Edwards board description */
nonstatic
siT
FENParseBD(charptrT s, rbptrT rbptr)
{
siT flag, ch, i, j, d;
rankT rank;
fileT file;
cT c;
pT p;

flag = 1;
i = 0;
rank = rank_8;
file = file_a;

while (flag && ((ch = *(s + i++)) != ascii_nul))
	switch (ch)
		{
		case '/':
			if ((file != fileL) || (rank == rank_1))
				flag = 0;
			else
				{
				rank--;
				file = file_a;
				};
			break;

		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
			d = ch - '0';
			if ((file + d) > fileL)
				flag = 0;
			else
				for (j = 0; j < d; j++)
					rbptr->rbm[rank][file++] = cp_v0;
			break;

		default:
			if (!ParameterCheckPiece(ch) || (file >= fileL))
				flag = 0;
			else
				{
				p = ParameterEvalPiece(ch);
				if (isupper(ch))
					c = c_w;
				else
					c = c_b;
				rbptr->rbm[rank][file] = cv_cp_c_pv[c][p];
				file++;
				};
			break;
		};

if (flag)
	if ((file != fileL) || (rank != rank_1))
		flag = 0;

return (flag);
}

/*--> FENParseAC: check and translate Forsyth-Edwards active color */
nonstatic
siT
FENParseAC(charptrT s, cptrT cptr)
{
siT flag;

if ((strlen(s) == 1) && ParameterCheckColor(*s))
	{
	*cptr = ParameterEvalColor(*s),
	flag = 1;
	}
else
	flag = 0;

return (flag);
}

/*--> FENParseCA: check and translate Forsyth-Edwards castling available */
nonstatic
siT
FENParseCA(charptrT s, castptrT castptr)
{
siT flag, i, ch;
castT cast;

/* set default return value */

flag = 1;

if (strcmp(s, "-") == 0)
	*castptr = 0;
else
	if (strlen(s) > 4)
		flag = 0;
	else
		{
		*castptr = 0;
		i = 0;
		while (flag && ((ch = *(s + i++)) != ascii_nul))
			{
			cast = 0;
			if (isupper(ch))
				{
				if (CICharEqual(ch, ascpv[lang_san][p_k]))
					cast = cf_wk;
				else
					if (CICharEqual(ch, ascpv[lang_san][p_q]))
						cast = cf_wq;
					else
						flag = 0;
				}
			else
				{
				if (CICharEqual(ch, ascpv[lang_san][p_k]))
					cast = cf_bk;
				else
					if (CICharEqual(ch, ascpv[lang_san][p_q]))
						cast = cf_bq;
					else
						flag = 0;
				};
			if (flag)
				if (*castptr & cast)
					flag = 0;
				else
					*castptr |= cast;
			};
		};

return (flag);
}

/*--> FENParseEP: check and translate Forsyth-Edwards en passant target */
nonstatic
siT
FENParseEP(charptrT s, sqptrT sqptr)
{
siT flag;

if (strcmp(s, "-") == 0)
	{
	*sqptr = sq_nil;
	flag = 1;
	}
else
	if (ParameterCheckSquare(s))
		{
		*sqptr = ParameterEvalSquare(s);
		flag = 1;
		}
	else
		flag = 0;

return (flag);
}

/*--> FENParseHC: check and translate Forsyth-Edwards halfmove clock */
nonstatic
siT
FENParseHC(charptrT s, siptrT siptr)
{
siT flag;

if (ParameterCheckSI(s))
	{
	*siptr = ParameterEvalSI(s);
	flag = 1;
	}
else
	flag = 0;

return (flag);
}

/*--> FENParseFN: check and translate Forsyth-Edwards fullmove number */
nonstatic
siT
FENParseFN(charptrT s, siptrT siptr)
{
siT flag, fmn;

if (ParameterCheckSI(s))
	{
	fmn = ParameterEvalSI(s);
	if ((fmn > 0) && (fmn <= gscoreL))
		{
		flag = 1;
		*siptr = fmn;
		}
	else
		flag = 0;
	}
else
	flag = 0;

return (flag);
}

/*<<< fen.c: EOF */
