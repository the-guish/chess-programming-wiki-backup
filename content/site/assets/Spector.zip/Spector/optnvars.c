/*>>> optnvars.c: option variable declarations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>

#include "defs.h"

#include "optndefs.h"

/* option strings, helps, and values */

charptrT optnstrv[optnL];
charptrT optnhlpv[optnL];
siT optnv[optnL];

/*<<< optnvars.c: EOF */
