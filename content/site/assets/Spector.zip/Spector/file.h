/*>>> file.h: subprogram prototypes for file.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void SetBuffer(fptrT fptr, liT length);
void SetBigBuffer(fptrT fptr);
void SetBiggerBuffer(fptrT fptr);
fptrT CodeFileOpen(charptrT filename, charptrT filemode);
siT CodeFileClose(fptrT fptr);
fptrT TextFileOpen(charptrT filename, charptrT filemode);
siT TextFileClose(fptrT fptr);
siT TextFileFlush(fptrT fptr);
void GateChar(fptrT fptr, char ch);
void GateStr(fptrT fptr, charptrT s);

/*<<< file.h: EOF */
