/*>>> bookdefs.h: definitions for opening library operations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* list book directory name */

#define lbdn_book "OldBook"

/* book names */

#define fn_bcob "bcob.lvc" /* R/-/- book code openings [BTM] (code) */
#define fn_bcow "bcow.lvc" /* R/-/- book code openings [WTM] (code) */
#define fn_bkcd "book.lvc" /* R/W/- book moves [bicolor] (code) */

/* maximal policed move count in a moveset; range 0..127 */

#define bkgenL (bit << 7)

/* maximal variation nesting */

#define bkvarL bkmcdL

/* character constants of interest */

#define bkchar_varbgn '(' /* variation begin */
#define bkchar_varend ')' /* variation end */
#define bkchar_slcbgn ';' /* single line comment begin */
#define bkchar_nbcbgn '{' /* nested block comment begin */
#define bkchar_nbcend '}' /* nested block comment end */
#define bkchar_poormv '?' /* poor move suffix */

/* annotation ordinals; range 0..63 */

typedef siT bkannoT;
#define bkannoL 2

#define bkanno_none 0 /* no annotation */
#define bkanno_poor 1 /* poor move */

/* control ordinals; range 0..63 */

typedef siT bkcntlT;
#define bkcntlL 4

#define bkcntl_none 0 /* no control */
#define bkcntl_bvar 1 /* begin variation */
#define bkcntl_evar 2 /* end variation */
#define bkcntl_stop 3 /* stop (end of book) */

/* binary header bit mark/no mark mask bit (0: move; 1: mark) */

#define bkhbit_mark bit_07

/* binary header bit control/no control mask bit (0: anno; 1: cntl) */

#define bkhbit_cntl bit_06

/* move generation ordinal mask (low seven bits) */

#define bkmask_gord \
    (bit_06 | bit_05 | bit_04 | bit_03 | bit_02 | bit_01 | bit_00)

/* annotation ordinal mask (low six bits) */

#define bkmask_anno (bit_05 | bit_04 | bit_03 | bit_02 | bit_01 | bit_00)

/* control ordinal mask (low six bits) */

#define bkmask_cntl (bit_05 | bit_04 | bit_03 | bit_02 | bit_01 | bit_00)

/* opening library intermediate record type */

typedef struct olrS
    {
    siT olr_mflg; /* 0: no move; 1: has move */
    siT olr_gord; /* move generation ordinal (if move exists) */
    siT olr_anno; /* annotation ordinal */
    siT olr_cntl; /* control ordinal */
    } olrT, *olrptrT;

/* the book text file token classes */

typedef siT bktftcT;
#define bktftcL 5
#define bktftc_nil (-1)

#define bktftc_move 0
#define bktftc_bvar 1
#define bktftc_evar 2
#define bktftc_stop 3
#define bktftc_bust 4

/*<<< bookdefs.h: EOF */
