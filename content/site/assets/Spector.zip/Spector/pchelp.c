/*>>> pchelp.c: process help routine */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "commdefs.h"
#include "commvars.h"

#include "pchelp.h"
#include "print.h"

/*--> ProcessHELP: auxillary process help */
nonstatic
void
ProcessHELP(void)
{
commT comm;
optnT optn;
cT c;
pT p;
langT lang;
nmT nm;
gtomT gtom;
strtT strt;
fileT file;
rankT rank;

PrNL();
PrLine("Commands:");
for (comm = 0; comm < commL; comm++)
	{
	PrBlanks(ntsL);
	PrTwoStrs(crv[comm].cr_name, ": ");
	PrLine(crv[comm].cr_help);
	};

PrNL();
PrLine("Literals (used as command parameters):");

if (lang_get == lang_put)
	{
	/* color letters */

	PrNTSStr("Colors:");
	for (c = c_w; c <= c_b; c++)
		{
		PrBlank();
		PrColorChar(c);
		};
	PrNL();

	/* piece letters */

	PrNTSStr("Pieces:");
	for (p = p_k; p >= p_p; p--)
		{
		PrBlank();
		PrPieceChar(p);
		};
	PrNL();
	}
else
	{
	/* color letters */

	lang_san = lang_get;
	PrNTSStr("Colors (input):");
	for (c = c_w; c <= c_b; c++)
		{
		PrBlank();
		PrColorChar(c);
		};
	PrNL();

	lang_san = lang_put;
	PrNTSStr("Colors (output):");
	for (c = c_w; c <= c_b; c++)
		{
		PrBlank();
		PrColorChar(c);
		};
	PrNL();

	/* piece letters */

	lang_san = lang_get;
	PrNTSStr("Pieces (input):");
	for (p = p_k; p >= p_p; p--)
		{
		PrBlank();
		PrPieceChar(p);
		};
	PrNL();

	lang_san = lang_put;
	PrNTSStr("Pieces (output):");
	for (p = p_k; p >= p_p; p--)
		{
		PrBlank();
		PrPieceChar(p);
		};
	PrNL();
	};

PrNTSStr("Files:");
for (file = file_a; file <= file_h; file++)
	{
	PrBlank();
	PrFileChar(file);
	};
PrNL();

PrNTSStr("Ranks:");
for (rank = rank_1; rank <= rank_8; rank++)
	{
	PrBlank();
	PrRankChar(rank);
	};
PrNL();

PrNTSStr("Squares:");
PrBlankSq(sq_a1);
PrBlankSq(sq_a2);
PrBlankSq(sq_a3);
PrStr(" ...");
PrBlankSq(sq_a8);
PrBlankSq(sq_b1);
PrBlankSq(sq_b2);
PrStr(" ...");
PrBlankSq(sq_g8);
PrBlankSq(sq_h1);
PrBlankSq(sq_h2);
PrStr(" ...");
PrBlankSq(sq_h8);
PrNL();

if (lang_get == lang_put)
	{
	PrNTSStr("CP/Square:");
	PrBlankColorPieceSq(cp_wr, sq_a1);
	PrBlankColorPieceSq(cp_wn, sq_b1);
	PrBlankColorPieceSq(cp_wb, sq_c1);
	PrStr(" ...");
	PrBlankColorPieceSq(cp_wp, sq_h2);
	PrStr(" ...");
	PrBlankColorPieceSq(cp_bp, sq_a7);
	PrStr(" ...");
	PrBlankColorPieceSq(cp_bq, sq_d8);
	PrBlankColorPieceSq(cp_bk, sq_e8);
	PrNL();
	}
else
	{
	lang_san = lang_get;
	PrNTSStr("CP/Square (input):");
	PrBlankColorPieceSq(cp_wr, sq_a1);
	PrBlankColorPieceSq(cp_wn, sq_b1);
	PrBlankColorPieceSq(cp_wb, sq_c1);
	PrStr(" ...");
	PrBlankColorPieceSq(cp_wp, sq_h2);
	PrStr(" ...");
	PrBlankColorPieceSq(cp_bp, sq_a7);
	PrStr(" ...");
	PrBlankColorPieceSq(cp_bq, sq_d8);
	PrBlankColorPieceSq(cp_bk, sq_e8);
	PrNL();

	lang_san = lang_put;
	PrNTSStr("CP/Square (output):");
	PrBlankColorPieceSq(cp_wr, sq_a1);
	PrBlankColorPieceSq(cp_wn, sq_b1);
	PrBlankColorPieceSq(cp_wb, sq_c1);
	PrStr(" ...");
	PrBlankColorPieceSq(cp_wp, sq_h2);
	PrStr(" ...");
	PrBlankColorPieceSq(cp_bp, sq_a7);
	PrStr(" ...");
	PrBlankColorPieceSq(cp_bq, sq_d8);
	PrBlankColorPieceSq(cp_bk, sq_e8);
	PrNL();
	};

PrNTSStr("Integers: 0 1 2 ... 32767");
PrNL();
PrNTSStr("Strings: foo bar BananaBoat \"Big Game #96\" ...");
PrNL();

if (lang_get == lang_put)
	{
	PrNTSStr("Castling Availability Indicators:");
	PrBlankColorPiece(cp_wk);
	PrBlankColorPiece(cp_wq);
	PrBlankColorPiece(cp_bk);
	PrBlankColorPiece(cp_bq);
	PrNL();
	}
else
	{
	lang_san = lang_get;
	PrNTSStr("Castling Availability Indicators (input):");
	PrBlankColorPiece(cp_wk);
	PrBlankColorPiece(cp_wq);
	PrBlankColorPiece(cp_bk);
	PrBlankColorPiece(cp_bq);
	PrNL();

	lang_san = lang_put;
	PrNTSStr("Castling Availability Indicators (output):");
	PrBlankColorPiece(cp_wk);
	PrBlankColorPiece(cp_wq);
	PrBlankColorPiece(cp_bk);
	PrBlankColorPiece(cp_bq);
	PrNL();
	};

PrNTSStr("Languages:");
for (lang = 0; lang < langL; lang++)
	PrBlankStr(langstrv[lang]);
PrNL();

PrNTSStr("Notations:");
for (nm = 0; nm < nmL; nm++)
	PrBlankStr(nmstrv[nm]);
PrNL();

PrNTSStr("Search Strategies:");
for (strt = 0; strt < strtL; strt++)
	PrBlankStr(strtstrv[strt]);
PrNL();

PrNTSStr("Game Terminations:");
for (gtom = 0; gtom < gtomL; gtom++)
	if (strlen(gtimstrv[gtom]) != 0)
		PrBlankStr(gtomstrv[gtom]);
PrNL();

PrNL();
PrLine("Options (used as parameters to -cvop- and -svop- commands):");
for (optn = 0; optn < optnL; optn++)
	{
	PrBlanks(ntsL);
	PrStr(optnstrv[optn]);
	PrBlanks(nfsL);
	PrLine(optnhlpv[optn]);
	};

return;
}

/*<<< pchelp.c: EOF */
