/*>>> initcomm.c: initialize commands routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"

#include "commdefs.h"
#include "commvars.h"

#include "initcomm.h"
#include "pc.h"
#include "pcexec.h"
#include "pcfile.h"
#include "pchelp.h"
#include "pcmove.h"
#include "pcstat.h"
#include "pcvals.h"

/*--> InitCommandRecord: set up a command record */
static
void
InitCommandRecord(commT commid, charptrT name,
	frvptrT func, siT minc, siT maxc, parcT parc)
{
crT *ptr;

ptr = &crv[commid];

ptr->cr_func = func;
ptr->cr_minc = minc;
ptr->cr_maxc = maxc;
ptr->cr_name = name;
ptr->cr_parc = parc;

return;
}

/*--> InitCommandHelp: set up a command help record entry */
static
void
InitCommandHelp(commT commid, charptrT help)
{
crv[commid].cr_help = help;

return;
}

/*--> InitCommands: set up commands */
nonstatic
void
InitCommands(void)
{
/* set the command records */

InitCommandRecord(comm_afgs, "afgs", ProcessAFGS, 2,   2, parc_str );
InitCommandRecord(comm_beep, "beep", ProcessBEEP, 1,   1, parc_none);
InitCommandRecord(comm_call, "call", ProcessCALL, 2,   2, parc_str );
InitCommandRecord(comm_cfdo, "cfdo", ProcessCFDO, 1,   1, parc_none);
InitCommandRecord(comm_comm, "comm", ProcessCOMM, 2,   2, parc_str );
InitCommandRecord(comm_cpic, "cpic", ProcessCPIC, 2, itL, parc_str );
InitCommandRecord(comm_cplb, "cplb", ProcessCPLB, 2, itL, parc_str );
InitCommandRecord(comm_cpmb, "cpmb", ProcessCPMB, 2, itL, parc_str );
InitCommandRecord(comm_cptb, "cptb", ProcessCPTB, 3,   3, parc_str );
InitCommandRecord(comm_cvca, "cvca", ProcessCVCA, 1,   5, parc_cai );
InitCommandRecord(comm_cvcb, "cvcb", ProcessCVCB, 1,   1, parc_none);
InitCommandRecord(comm_cvcc, "cvcc", ProcessCVCC, 1,   1, parc_none);
InitCommandRecord(comm_cvcf, "cvcf", ProcessCVCF, 1,   1, parc_none);
InitCommandRecord(comm_cvep, "cvep", ProcessCVEP, 1,   1, parc_none);
InitCommandRecord(comm_cvgt, "cvgt", ProcessCVGT, 1,   1, parc_none);
InitCommandRecord(comm_cvop, "cvop", ProcessCVOP, 1, itL, parc_optn);
InitCommandRecord(comm_cvsq, "cvsq", ProcessCVSQ, 1, itL, parc_sq  );
InitCommandRecord(comm_cvtf, "cvtf", ProcessCVTF, 1, itL, parc_str );
InitCommandRecord(comm_desc, "desc", ProcessDESC, 1,   1, parc_none);
InitCommandRecord(comm_dvas, "dvas", ProcessDVAS, 1,   1, parc_none);
InitCommandRecord(comm_dvcb, "dvcb", ProcessDVCB, 1,   1, parc_none);
InitCommandRecord(comm_dvcr, "dvcr", ProcessDVCR, 1,   1, parc_none);
InitCommandRecord(comm_dvct, "dvct", ProcessDVCT, 1,   1, parc_none);
InitCommandRecord(comm_dver, "dver", ProcessDVER, 1,   1, parc_none);
InitCommandRecord(comm_dvfe, "dvfe", ProcessDVFE, 1,   1, parc_none);
InitCommandRecord(comm_dvlm, "dvlm", ProcessDVLM, 1,   1, parc_none);
InitCommandRecord(comm_dvnc, "dvnc", ProcessDVNC, 1,   1, parc_none);
InitCommandRecord(comm_dvpe, "dvpe", ProcessDVPE, 1,   1, parc_none);
InitCommandRecord(comm_dvpm, "dvpm", ProcessDVPM, 1,   1, parc_none);
InitCommandRecord(comm_dvpv, "dvpv", ProcessDVPV, 1,   1, parc_none);
InitCommandRecord(comm_dvss, "dvss", ProcessDVSS, 1,   1, parc_none);
InitCommandRecord(comm_dvtc, "dvtc", ProcessDVTC, 1,   1, parc_none);
InitCommandRecord(comm_dvte, "dvte", ProcessDVTE, 1,   1, parc_none);
InitCommandRecord(comm_dvtf, "dvtf", ProcessDVTF, 1, itL, parc_str );
InitCommandRecord(comm_dvts, "dvts", ProcessDVTS, 1,   1, parc_none);
InitCommandRecord(comm_dvtt, "dvtt", ProcessDVTT, 1,   1, parc_none);
InitCommandRecord(comm_echo, "echo", ProcessECHO, 1, itL, parc_str );
InitCommandRecord(comm_enum, "enum", ProcessENUM, 2,   2, parc_sint);
InitCommandRecord(comm_eval, "eval", ProcessEVAL, 1,   1, parc_none);
InitCommandRecord(comm_evca, "evca", ProcessEVCA, 1,   1, parc_none);
InitCommandRecord(comm_evte, "evte", ProcessEVTE, 1,   1, parc_none);
InitCommandRecord(comm_evtf, "evtf", ProcessEVTF, 1, itL, parc_str );
InitCommandRecord(comm_exit, "exit", ProcessEXIT, 1,   1, parc_none);
InitCommandRecord(comm_expm, "expm", ProcessEXPM, 1,   1, parc_none);
InitCommandRecord(comm_expv, "expv", ProcessEXPV, 1,   1, parc_none);
InitCommandRecord(comm_exsm, "exsm", ProcessEXSM, 2,   2, parc_str );
InitCommandRecord(comm_exsv, "exsv", ProcessEXSV, 1, itL, parc_str );
InitCommandRecord(comm_game, "game", ProcessGAME, 1,   1, parc_none);
InitCommandRecord(comm_help, "help", ProcessHELP, 1,   1, parc_none);
InitCommandRecord(comm_hint, "hint", ProcessHINT, 1,   1, parc_none);
InitCommandRecord(comm_info, "info", ProcessINFO, 1,   1, parc_none);
InitCommandRecord(comm_jump, "jump", ProcessJUMP, 2, itL, parc_str );
InitCommandRecord(comm_lfer, "lfer", ProcessLFER, 2,   2, parc_str );
InitCommandRecord(comm_lfgc, "lfgc", ProcessLFGC, 2,   2, parc_str );
InitCommandRecord(comm_lfkb, "lfkb", ProcessLFKB, 2,   2, parc_str );
InitCommandRecord(comm_lfms, "lfms", ProcessLFMS, 2,   2, parc_str );
InitCommandRecord(comm_lfpd, "lfpd", ProcessLFPD, 2,   2, parc_str );
InitCommandRecord(comm_logo, "logo", ProcessLOGO, 1,   1, parc_none);
InitCommandRecord(comm_mark, "mark", ProcessMARK, 1,   1, parc_none);
InitCommandRecord(comm_mate, "mate", ProcessMATE, 2,   2, parc_sint);
InitCommandRecord(comm_newg, "newg", ProcessNEWG, 1,   1, parc_none);
InitCommandRecord(comm_noop, "noop", ProcessNOOP, 1, itL, parc_str );
InitCommandRecord(comm_ofdo, "ofdo", ProcessOFDO, 2,   2, parc_str );
InitCommandRecord(comm_pfdn, "pfdn", ProcessPFDN, 3,   3, parc_str );
InitCommandRecord(comm_pflc, "pflc", ProcessPFLC, 2,   2, parc_str );
InitCommandRecord(comm_pfms, "pfms", ProcessPFMS, 3,   3, parc_str );
InitCommandRecord(comm_pfpa, "pfpa", ProcessPFPA, 3,   3, parc_str );
InitCommandRecord(comm_pfro, "pfro", ProcessPFRO, 3,   3, parc_str );
InitCommandRecord(comm_pfts, "pfts", ProcessPFTS, 3,   3, parc_str );
InitCommandRecord(comm_pgos, "pgos", ProcessPGOS, 1,   1, parc_none);
InitCommandRecord(comm_play, "play", ProcessPLAY, 1,   2, parc_sint);
InitCommandRecord(comm_pond, "pond", ProcessPOND, 1,   1, parc_none);
InitCommandRecord(comm_rtmv, "rtmv", ProcessRTMV, 1,   2, parc_sint);
InitCommandRecord(comm_rtrn, "rtrn", ProcessRTRN, 1,   1, parc_none);
InitCommandRecord(comm_rvca, "rvca", ProcessRVCA, 1,   1, parc_none);
InitCommandRecord(comm_rvcc, "rvcc", ProcessRVCC, 1,   1, parc_none);
InitCommandRecord(comm_rvct, "rvct", ProcessRVCT, 1,   1, parc_none);
InitCommandRecord(comm_rvht, "rvht", ProcessRVHT, 1,   1, parc_none);
InitCommandRecord(comm_rvnc, "rvnc", ProcessRVNC, 1,   1, parc_none);
InitCommandRecord(comm_rvop, "rvop", ProcessRVOP, 1,   1, parc_none);
InitCommandRecord(comm_rvss, "rvss", ProcessRVSS, 1,   1, parc_none);
InitCommandRecord(comm_rvtc, "rvtc", ProcessRVTC, 1,   1, parc_none);
InitCommandRecord(comm_scon, "scon", ProcessSCON, 1, itL, parc_str );
InitCommandRecord(comm_sfcr, "sfcr", ProcessSFCR, 2,   2, parc_str );
InitCommandRecord(comm_sfer, "sfer", ProcessSFER, 2,   2, parc_str );
InitCommandRecord(comm_sfgc, "sfgc", ProcessSFGC, 2,   2, parc_str );
InitCommandRecord(comm_sfkb, "sfkb", ProcessSFKB, 2,   2, parc_str );
InitCommandRecord(comm_sfms, "sfms", ProcessSFMS, 2,   2, parc_str );
InitCommandRecord(comm_sfpd, "sfpd", ProcessSFPD, 2,   2, parc_str );
InitCommandRecord(comm_sort, "sort", ProcessSORT, 3,   3, parc_str );
InitCommandRecord(comm_srch, "srch", ProcessSRCH, 2, itL, parc_str );
InitCommandRecord(comm_stat, "stat", ProcessSTAT, 1,   1, parc_none);
InitCommandRecord(comm_svac, "svac", ProcessSVAC, 2,   2, parc_c   );
InitCommandRecord(comm_svca, "svca", ProcessSVCA, 1,   5, parc_cai );
InitCommandRecord(comm_svcc, "svcc", ProcessSVCC, 2,   3, parc_lint);
InitCommandRecord(comm_svcf, "svcf", ProcessSVCF, 1,   1, parc_none);
InitCommandRecord(comm_svct, "svct", ProcessSVCT, 2,   2, parc_lint);
InitCommandRecord(comm_svep, "svep", ProcessSVEP, 2,   2, parc_sq  );
InitCommandRecord(comm_svfe, "svfe", ProcessSVFE, 1,   7, parc_str );
InitCommandRecord(comm_svhc, "svhc", ProcessSVHC, 2,   2, parc_sint);
InitCommandRecord(comm_svko, "svko", ProcessSVKO, 1,   1, parc_none);
InitCommandRecord(comm_svmn, "svmn", ProcessSVMN, 2,   2, parc_sint);
InitCommandRecord(comm_svnc, "svnc", ProcessSVNC, 2,   2, parc_lint);
InitCommandRecord(comm_svnl, "svnl", ProcessSVNL, 2,   3, parc_lang);
InitCommandRecord(comm_svnm, "svnm", ProcessSVNM, 2,   2, parc_nm  );
InitCommandRecord(comm_svop, "svop", ProcessSVOP, 1, itL, parc_optn);
InitCommandRecord(comm_svpl, "svpl", ProcessSVPL, 2,   2, parc_sint);
InitCommandRecord(comm_svsq, "svsq", ProcessSVSQ, 1, itL, parc_cpsq);
InitCommandRecord(comm_svss, "svss", ProcessSVSS, 2,   3, parc_strt);
InitCommandRecord(comm_svtc, "svtc", ProcessSVTC, 3,   4, parc_lint);
InitCommandRecord(comm_svtf, "svtf", ProcessSVTF, 2, itL, parc_str );
InitCommandRecord(comm_svtt, "svtt", ProcessSVTT, 2,   2, parc_lint);
InitCommandRecord(comm_swap, "swap", ProcessSWAP, 1,   1, parc_none);
InitCommandRecord(comm_syst, "syst", ProcessSYST, 2,   2, parc_str );
InitCommandRecord(comm_test, "test", ProcessTEST, 1,   3, parc_str );
InitCommandRecord(comm_tfgc, "tfgc", ProcessTFGC, 3,   3, parc_str );
InitCommandRecord(comm_tfge, "tfge", ProcessTFGE, 3,   3, parc_str );
InitCommandRecord(comm_tfgg, "tfgg", ProcessTFGG, 3,   3, parc_str );
InitCommandRecord(comm_tfgh, "tfgh", ProcessTFGH, 3,   3, parc_str );
InitCommandRecord(comm_tfgv, "tfgv", ProcessTFGV, 3,   3, parc_str );
InitCommandRecord(comm_trac, "trac", ProcessTRAC, 1,   1, parc_none);

/* set the help fields for the command records */

InitCommandHelp(comm_afgs, "append file: game status");
InitCommandHelp(comm_beep, "emit single beep");
InitCommandHelp(comm_call, "call command subfile");
InitCommandHelp(comm_cfdo, "close file: dribble output");
InitCommandHelp(comm_comm, "communicate with Duplex mediator");
InitCommandHelp(comm_cpic, "command processor: interprocess communication");
InitCommandHelp(comm_cplb, "command processor: legacy book");
InitCommandHelp(comm_cpmb, "command processor: multibook");
InitCommandHelp(comm_cptb, "command processor: tablebase subsystem");
InitCommandHelp(comm_cvca, "clear value: castling availability");
InitCommandHelp(comm_cvcb, "clear value: chessboard");
InitCommandHelp(comm_cvcc, "clear value: chess clock");
InitCommandHelp(comm_cvcf, "clear value: clock flag");
InitCommandHelp(comm_cvep, "clear value: en passant capture square");
InitCommandHelp(comm_cvgt, "clear value: game termination code");
InitCommandHelp(comm_cvop, "clear value: option");
InitCommandHelp(comm_cvsq, "clear value: squares");
InitCommandHelp(comm_cvtf, "clear value: tag fields");
InitCommandHelp(comm_desc, "describe position");
InitCommandHelp(comm_dvas, "display value: hash address and signature");
InitCommandHelp(comm_dvcb, "display value: chessboard");
InitCommandHelp(comm_dvcr, "display value: concise report");
InitCommandHelp(comm_dvct, "display value: countdown timer");
InitCommandHelp(comm_dver, "display value: event report");
InitCommandHelp(comm_dvfe, "display value: Forsyth-Edwards notation");
InitCommandHelp(comm_dvlm, "display value: legal moves");
InitCommandHelp(comm_dvnc, "display value: node countdown");
InitCommandHelp(comm_dvpe, "display value: preliminary evaluations");
InitCommandHelp(comm_dvpm, "display value: predicted move");
InitCommandHelp(comm_dvpv, "display value: predicted variation");
InitCommandHelp(comm_dvss, "display value: search strategies");
InitCommandHelp(comm_dvtc, "display value: time control");
InitCommandHelp(comm_dvte, "display value: tag environment");
InitCommandHelp(comm_dvtf, "display value: tag fields");
InitCommandHelp(comm_dvts, "display value: timestamp");
InitCommandHelp(comm_dvtt, "display value: transposition table order");
InitCommandHelp(comm_echo, "echo arguments");
InitCommandHelp(comm_enum, "enumerate ply descendants");
InitCommandHelp(comm_eval, "display evaluation of current position");
InitCommandHelp(comm_evca, "estimate value: castling availability");
InitCommandHelp(comm_evte, "estimate value: tag environment");
InitCommandHelp(comm_evtf, "estimate value: tag fields");
InitCommandHelp(comm_exit, "exit program");
InitCommandHelp(comm_expm, "execute predicted move");
InitCommandHelp(comm_expv, "execute predicted variation");
InitCommandHelp(comm_exsm, "execute supplied move");
InitCommandHelp(comm_exsv, "execute supplied variation");
InitCommandHelp(comm_game, "calculate and play to end of game");
InitCommandHelp(comm_help, "display help list");
InitCommandHelp(comm_hint, "offer hint");
InitCommandHelp(comm_info, "display program identification information");
InitCommandHelp(comm_jump, "exit/transfer");
InitCommandHelp(comm_lfer, "load file: event report");
InitCommandHelp(comm_lfgc, "load file: game code");
InitCommandHelp(comm_lfkb, "load file: knowledge base");
InitCommandHelp(comm_lfms, "load file: move sequence");
InitCommandHelp(comm_lfpd, "load file: position data");
InitCommandHelp(comm_logo, "display program logo");
InitCommandHelp(comm_mark, "report (and establish) a time mark");
InitCommandHelp(comm_mate, "search for mate in -n- moves");
InitCommandHelp(comm_newg, "new game");
InitCommandHelp(comm_noop, "no operation");
InitCommandHelp(comm_ofdo, "open file: dribble output");
InitCommandHelp(comm_pfdn, "process file: EPD data normalization");
InitCommandHelp(comm_pflc, "process file: EPD locate cooks");
InitCommandHelp(comm_pfms, "process file: EPD mate search");
InitCommandHelp(comm_pfpa, "process file: EPD position analysis");
InitCommandHelp(comm_pfro, "process file: EPD remove operations");
InitCommandHelp(comm_pfts, "process file: EPD target search");
InitCommandHelp(comm_pgos, "play game oracular sequence");
InitCommandHelp(comm_play, "calculate and play one or more moves");
InitCommandHelp(comm_pond, "ponder search");
InitCommandHelp(comm_rtmv, "retract one or more moves");
InitCommandHelp(comm_rtrn, "return from command subfile");
InitCommandHelp(comm_rvca, "reset value: castling availability");
InitCommandHelp(comm_rvcc, "reset value: chess clock");
InitCommandHelp(comm_rvct, "reset value: countdown timer");
InitCommandHelp(comm_rvht, "reset value: hash table information");
InitCommandHelp(comm_rvnc, "reset value: node countdown");
InitCommandHelp(comm_rvop, "reset value: option set");
InitCommandHelp(comm_rvss, "reset value: search strategies");
InitCommandHelp(comm_rvtc, "reset value: time control");
InitCommandHelp(comm_scon, "set console configuration");
InitCommandHelp(comm_sfcr, "save file: concise report");
InitCommandHelp(comm_sfer, "save file: event report");
InitCommandHelp(comm_sfgc, "save file: game code");
InitCommandHelp(comm_sfkb, "save file: knowledge base");
InitCommandHelp(comm_sfms, "save file: move sequence");
InitCommandHelp(comm_sfpd, "save file: position data");
InitCommandHelp(comm_sort, "sort text file");
InitCommandHelp(comm_srch, "search for a move from a target list");
InitCommandHelp(comm_stat, "status report");
InitCommandHelp(comm_svac, "set value: active color");
InitCommandHelp(comm_svca, "set value: castling availability");
InitCommandHelp(comm_svcc, "set value: chess clock");
InitCommandHelp(comm_svcf, "set value: clock flag");
InitCommandHelp(comm_svct, "set value: countdown timer");
InitCommandHelp(comm_svep, "set value: en passant capture square");
InitCommandHelp(comm_svfe, "set value: Forsyth-Edwards notation");
InitCommandHelp(comm_svhc, "set value: halfmove clock");
InitCommandHelp(comm_svko, "set value: kings only position");
InitCommandHelp(comm_svmn, "set value: move number");
InitCommandHelp(comm_svnc, "set value: node countdown");
InitCommandHelp(comm_svnl, "set value: notational language");
InitCommandHelp(comm_svnm, "set value: notation mode");
InitCommandHelp(comm_svop, "set value: option");
InitCommandHelp(comm_svpl, "set value: ply limit");
InitCommandHelp(comm_svsq, "set value: square");
InitCommandHelp(comm_svss, "set value: search strategies");
InitCommandHelp(comm_svtc, "set value: time control");
InitCommandHelp(comm_svtf, "set value: tag fields");
InitCommandHelp(comm_svtt, "set value: transposition table order");
InitCommandHelp(comm_swap, "swap colors");
InitCommandHelp(comm_syst, "execute system command");
InitCommandHelp(comm_test, "testing");
InitCommandHelp(comm_tfgc, "translate file: games to PGC");
InitCommandHelp(comm_tfge, "translate file: games to EPD");
InitCommandHelp(comm_tfgg, "translate file: games to PGN");
InitCommandHelp(comm_tfgh, "translate file: games to hex");
InitCommandHelp(comm_tfgv, "translate file: games to variations");
InitCommandHelp(comm_trac, "general trace (freq|trab|trpv|trst|trtt|verb)");

return;
}

/*<<< initcomm.c: EOF */
