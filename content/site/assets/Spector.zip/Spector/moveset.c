/*>>> moveset.c: moveset routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "csdefs.h"

#include "bbmacs.h"

#include "csutil.h"
#include "draw.h"
#include "exec.h"
#include "gen.h"
#include "memutil.h"
#include "moveset.h"
#include "mpool.h"
#include "mu.h"
#include "print.h"
#include "refute.h"
#include "san.h"
#include "stat.h"
#include "sysutil.h"

/*--> CurrentPlyZeroMoveIndex: fetch index of current ply zero descendent */
nonstatic
siT
CurrentPlyZeroMoveIndex(void)
{
siT n;

if (root_sptr == NULL)
	Diagnose("CurrentPlyZeroMoveIndex: root_sptr NULL");

if (root_sptr->s_mbase == NULL)
	Diagnose("CurrentPlyZeroMoveIndex: root_sptr->s_mbase NULL");

if (root_sptr->s_mcurr == NULL)
	Diagnose("CurrentPlyZeroMoveIndex: root_sptr->s_mcurr NULL");

n = root_sptr->s_mcurr - root_sptr->s_mbase;

return (n);
}

/*--> FindMove: locate a move in a moveset */
nonstatic
mptrT
FindMove(mptrT mptr, sptrT sptr)
{
siT i, count;
mptrT rmptr, fmptr;

/* scan */

i = 0;
count = sptr->s_count;
fmptr = NULL;
rmptr = sptr->s_mbase;
while ((i < count) && (fmptr == NULL))
	if (same_move_ref(rmptr, mptr))
		fmptr = rmptr;
	else
		{
		rmptr++;
		i++;
		};

return (fmptr);
}

/*--> FindMoveNF: locate a move in a moveset, no fail result */
nonstatic
mptrT
FindMoveNF(mptrT mptr, sptrT sptr, charptrT s)
{
siT i, count;
mptrT rmptr, fmptr;

/* scan */

i = 0;
count = sptr->s_count;
fmptr = NULL;
rmptr = sptr->s_mbase;
while ((i < count) && (fmptr == NULL))
	if (same_move_ref(rmptr, mptr))
		fmptr = rmptr;
	else
		{
		rmptr++;
		i++;
		};

/* no fail output error checking */

if (fmptr == NULL)
	{
	PrStrSANNL("FindMoveNF: ", mptr);
	sprintf(stv, "Called from: %s\n", s);
	PrSTVNL();
	Diagnose("FindMoveNF: null fmptr");
	};

return (fmptr);
}

/*--> FindMoveEC: locate a move in a moveset with full error checking */
nonstatic
mptrT
FindMoveEC(mptrT mptr, sptrT sptr)
{
siT i, count;
mptrT rmptr, fmptr;

/* full input error checking */

if (mptr == NULL)
	Diagnose("FindMoveEC: null mptr");

if (sptr == NULL)
	Diagnose("FindMoveEC: null sptr");

/* scan */

i = 0;
count = sptr->s_count;
fmptr = NULL;
rmptr = sptr->s_mbase;
while ((i < count) && (fmptr == NULL))
	if (same_move_ref(rmptr, mptr))
		fmptr = rmptr;
	else
		{
		rmptr++;
		i++;
		};

/* no fail output error checking */

if (fmptr == NULL)
	Diagnose("FindMoveEC: null fmptr");

return (fmptr);
}

/*--> FindMoveFSTS: locate a move in a moveset (frsq/tosq) */
nonstatic
mptrT
FindMoveFSTS(sqT frsq, sqT tosq, sptrT sptr)
{
siT i, count;
mptrT rmptr, fmptr;

/* scan */

i = 0;
count = sptr->s_count;
fmptr = NULL;
rmptr = sptr->s_mbase;
while ((i < count) && (fmptr == NULL))
	if ((rmptr->m_frsq == frsq) && (rmptr->m_tosq == tosq))
		fmptr = rmptr;
	else
		{
		rmptr++;
		i++;
		};

return (fmptr);
}

/*--> LocateListMoveEntry: locate a move list entry in a list of moves */
nonstatic
mlstptrT
LocateListMoveEntry(mptrT mptr, mlstptrT mlstptr)
{
siT flag;
mlstptrT ptr;

if ((mptr == NULL) || (mlstptr == NULL))
	ptr = NULL;
else
	{
	ptr = mlstptr;
	flag = 0;
	while (!flag && (ptr != NULL))
		if (SameMoveRef(mptr, ptr->mlst_mptr))
			flag = 1;
		else
			ptr = ptr->mlst_next;
	if (!flag)
		ptr = NULL;
	};

return (ptr);
}

/*--> FreeMoveList: deallocate storage for a move list */
nonstatic
void
FreeMoveList(mlstptrT mlstptr)
{
if (mlstptr != NULL)
	{
	if (mlstptr->mlst_mptr != NULL)
		MemoryFree(mlstptr->mlst_mptr);
	if (mlstptr->mlst_next != NULL)
		FreeMoveList(mlstptr->mlst_next);
	MemoryFree(mlstptr);
	};

return;
}

/*--> MovesetSortPreliminaries: sort moveset (descending prels) */
nonstatic
void
MovesetSortPreliminaries(sptrT sptr)
{
mptrT mptr0, mptr1;
siT count, flag, pass, pair;
mT m;

/* this routine clears the best and current move pointers */

sptr->s_mbest = sptr->s_mcurr = NULL;

count = sptr->s_count;
if (count > 1)
	{
	/* set up pass loop */

	flag = 1;
	pass = 0;
	while (flag && (pass < (count - 1)))
		{
		/* set up pair loop */

		flag = 0;
		pair = 0;

		/* set pointers */

		mptr0 = sptr->s_mbase;
		mptr1 = sptr->s_mbase + 1;

		while (pair < (count - pass - 1))
			{
			/* test for swap */

			if (mptr1->m_prel > mptr0->m_prel)
				{
				m = *mptr0;
				*mptr0 = *mptr1;
				*mptr1 = m;
				flag = 1;
				};

			/* next pair */

			mptr0++;
			mptr1++;
			pair++;
			};

		/* next pass */

		if (flag)
			pass++;
		};
	};

return;
}

/*--> MovesetSortEvaluations: sort moveset (descending evals) */
nonstatic
void
MovesetSortEvaluations(sptrT sptr)
{
mptrT mptr0, mptr1;
siT count, flag, pass, pair;
mT m;

/* this routine clears the best and current move pointers */

sptr->s_mbest = sptr->s_mcurr = NULL;

count = sptr->s_count;
if (count > 1)
	{
	/* set up pass loop */

	flag = 1;
	pass = 0;
	while (flag && (pass < (count - 1)))
		{
		/* set up pair loop */

		flag = 0;
		pair = 0;

		/* set pointers */

		mptr0 = sptr->s_mbase;
		mptr1 = sptr->s_mbase + 1;

		while (pair < (count - pass - 1))
			{
			/* test for swap */

			if (mptr1->m_eval > mptr0->m_eval)
				{
				m = *mptr0;
				*mptr0 = *mptr1;
				*mptr1 = m;
				flag = 1;
				};

			/* next pair */

			mptr0++;
			mptr1++;
			pair++;
			};

		/* next pass */

		if (flag)
			pass++;
		};
	};

return;
}

/*--> MovesetSortNodeCounts: sort moveset (descending mode counts) */
nonstatic
void
MovesetSortNodeCounts(void)
{
mptrT mptr0, mptr1;
liptrT liptr0, liptr1;
siT count, flag, pass, pair;
mT m;
liT nodes;

/* this routine clears the best and current move pointers */

root_sptr->s_mbest = root_sptr->s_mcurr = NULL;

/* called once after each iteration */

count = root_sptr->s_count;
if (count > 1)
	{
	/* set up pass loop */

	flag = 1;
	pass = 0;
	while (flag && (pass < (count - 1)))
		{
		/* set up pair loop */

		flag = 0;
		pair = 0;

		/* set pointers */

		liptr0 = pzsnc_base;
		liptr1 = pzsnc_base + 1;

		mptr0 = root_sptr->s_mbase;
		mptr1 = root_sptr->s_mbase + 1;

		while (pair < (count - pass - 1))
			{
			/* test for swap */

			if (*liptr1 > *liptr0)
				{
				nodes = *liptr0;
				*liptr0 = *liptr1;
				*liptr1 = nodes;

				m = *mptr0;
				*mptr0 = *mptr1;
				*mptr1 = m;

				RefuteExchange(pair, (pair + 1));

				flag = 1;
				};

			/* next pair */

			liptr0++;
			liptr1++;

			mptr0++;
			mptr1++;

			pair++;
			};

		/* next pass */

		if (flag)
			pass++;
		};
	};

return;
}

/*--> MovesetRethreadMove: rethread a descendant moveset for a single move */
nonstatic
void
MovesetRethreadMove(mptrT mptr)
{
if (mptr->m_dptr != NULL)
	mptr->m_dptr->s_mprev = mptr;

return;
}

/*--> MovesetRethread: rethread all moves for a given moveset */
nonstatic
void
MovesetRethread(sptrT sptr)
{
mptrT mptr;
siT i, count;

count = sptr->s_count;
mptr = sptr->s_mbase;
for (i = 0; i < count; i++)
	{
	MovesetRethreadMove(mptr);
	mptr++;
	};

return;
}

/*--> MovesetSearchReset: clear search flags */
nonstatic
void
MovesetSearchReset(sptrT sptr)
{
mptrT mptr;
siT i, count;
mfT mf;

/* scan */

mf = ~mf_srch;
mptr = sptr->s_mbase;
count = sptr->s_count;
for (i = 0; i < count; i++)
	{
	mptr->m_flag &= mf;
	mptr++;
	};

return;
}

/*--> MovesetPrecharge: set up the root moveset moveset with sorted evals */
nonstatic
void
MovesetPrecharge(void)
{
/* sort by node count, then rethread subtree */

MovesetSortNodeCounts();
MovesetRethread(root_sptr);

/* set the best pointer and clear the current pointer */

root_sptr->s_mbest = root_sptr->s_mbase;
root_sptr->s_mcurr = NULL;

/* reset the search flags */

MovesetSearchReset(root_sptr);

return;
}

/*--> MovesetNew: allocate and initialize a moveset record */
nonstatic
sptrT
MovesetNew(void)
{
sptrT sptr;

/* allocate memory for moveset record */

sptr = MPoolPickMoveset();

/* initialize the moveset fields */

sptr->s_count = sptr->s_sflag = 0;
sptr->s_cpebu = sptr->s_cpeq0 = sptr->s_cpeq1 = sptr->s_cpesp = cpev_bust;
sptr->s_mbase = sptr->s_mbest = sptr->s_mcurr = sptr->s_mprev = NULL;
sptr->s_cnptr = NULL;

return (sptr);
}

/*--> MovesetRelease: recursively release moveset storage */
nonstatic
void
MovesetRelease(sptrT sptr)
{
mptrT mptr;
siT i, count;

/* process for non-null pointer */

if (sptr != NULL)
	{
	/* release descendants */

	if ((sptr->s_mbase != NULL) && (sptr->s_sflag & sf_gcon))
		{
		mptr = sptr->s_mbase;
		count = sptr->s_count;
		for (i = 0; i < count; i++)
			{
			if (mptr->m_dptr != NULL)
				MovesetRelease(mptr->m_dptr);
			mptr++;
			};

		/* mark no generated moves connected */

		sptr->s_sflag &= ~sf_gcon;
		};

	/* release move storage */

	if (sptr->s_mbase != NULL)
		MemoryFree(sptr->s_mbase);

	/* release concept notation storage (not necessarily attached) */

	if (sptr->s_cnptr != NULL)
		CSConceptNotationRelease(sptr->s_cnptr);

	/* unthread parent */

	if (sptr->s_mprev != NULL)
		sptr->s_mprev->m_dptr = NULL;

	/* release moveset record storage */

	MPoolDropMoveset(sptr);
	};

return;
}

/*--> MovesetAllocate: allocate move storage for a moveset (full width) */
nonstatic
void
MovesetAllocate(sptrT sptr)
{
/* allocate storage for maximum move width; set the header's base pointer */

sptr->s_mbase = (mptrT) MemoryGrab(sizeof(mT) * gmL);

return;
}

/*--> MovesetAllocateSingleton: allocate singleton move moveset */
static
void
MovesetAllocateSingleton(sptrT sptr)
{
/* allocate storage for a single move; set the header's base pointer */

sptr->s_mbase = (mptrT) MemoryGrab(sizeof(mT));

return;
}

/*--> MovesetResize: resize (via reduction only) move storage for moveset */
nonstatic
void
MovesetResize(sptrT sptr)
{
mptrT mptr;

/* this routine clears the best and current move pointers */

sptr->s_mbest = sptr->s_mcurr = NULL;

mptr = (mptrT) MemoryResize(sptr->s_mbase, (sizeof(mT) * sptr->s_count));
if (mptr != sptr->s_mbase)
	{
	sptr->s_mbase = mptr;
	if (sptr->s_sflag & sf_gcon)
		MovesetRethread(sptr);
	};

return;
}

/*--> MovesetDisconnectRelease: disconnect and release moveset from a move */
nonstatic
void
MovesetDisconnectRelease(mptrT mptr)
{
if (mptr->m_dptr != NULL)
	{
	/* release storage */

	MovesetRelease(mptr->m_dptr);

	/* everything released, clear descendant ptr (no longer needed) */

	mptr->m_dptr = NULL;
	};

return;
}

/*--> MovesetGenerateConnect: generate and connect moveset (to a move) */
nonstatic
void
MovesetGenerateConnect(mptrT mptr)
{
/* is a moveset already connected? */

if (mptr->m_dptr == NULL)
	{
	/* no moveset present, generate and connect full moveset */

	mptr->m_dptr = Generate(1);

	/* set descendant back link */

	mptr->m_dptr->s_mprev = mptr;

	/* set parent moveset gen connect flag (may already be set) */

	if (mptr->m_cptr != NULL)
		mptr->m_cptr->s_sflag |= sf_gcon;
	}
else
	{
	/* a moveset is present, which kind? */

	if (mptr->m_dptr->s_sflag & sf_full)
		{
		/* right kind, reset search flags */

		MovesetSearchReset(mptr->m_dptr);

		/* reset the best and current pointers */

		mptr->m_dptr->s_mbest = mptr->m_dptr->s_mcurr = NULL;
		}
	else
		{
		/* wrong kind, release prior moveset */

		MovesetDisconnectRelease(mptr);

		/* no moveset present, generate and connect full moveset */

		mptr->m_dptr = Generate(1);

		/* set descendent back link */

		mptr->m_dptr->s_mprev = mptr;

		/* set parent moveset gen connect flag (may already be set) */

		if (mptr->m_cptr != NULL)
			mptr->m_cptr->s_sflag |= sf_gcon;
		};
	};

return;
}

/*--> MovesetGenerateCapturesConnect: generate/connect capture moveset */
nonstatic
void
MovesetGenerateCapturesConnect(mptrT mptr)
{
/* is a moveset already connected? */

if (mptr->m_dptr == NULL)
	{
	/* no moveset present, generate and connect captures */

	mptr->m_dptr = Generate(0);

	/* set descendant back link */

	mptr->m_dptr->s_mprev = mptr;

	/* set parent moveset gen connect flag (may already be set) */

	if (mptr->m_cptr != NULL)
		mptr->m_cptr->s_sflag |= sf_gcon;
	}
else
	{
	/* a moveset is present, which kind? */

	if (mptr->m_dptr->s_sflag & sf_capt)
		{
		/* right kind, reset search flags */

		MovesetSearchReset(mptr->m_dptr);

		/* reset the best and current pointers */

		mptr->m_dptr->s_mbest = mptr->m_dptr->s_mcurr = NULL;
		}
	else
		{
		/* wrong kind, release prior moveset */

		MovesetDisconnectRelease(mptr);

		/* no moveset present, generate and connect captures moveset */

		mptr->m_dptr = Generate(0);

		/* set descendant back link */

		mptr->m_dptr->s_mprev = mptr;

		/* set parent moveset gen connect flag (may already be set) */

		if (mptr->m_cptr != NULL)
			mptr->m_cptr->s_sflag |= sf_gcon;
		};
	};

return;
}

/*--> MovesetGenerateSingletonConnect: generate/connect singleton moveset */
nonstatic
void
MovesetGenerateSingletonConnect(mptrT mptr, mptrT tmptr)
{
sptrT dsptr;
mptrT dmptr;

/* is a moveset already connected? */

if (mptr->m_dptr != NULL)
	{
	/* unconditional disconnect of old moveset */

	MovesetDisconnectRelease(mptr);
	};

/* no moveset now present, generate and connect singleton move */

mptr->m_dptr = dsptr = MovesetNew();

/* set the singleton moveset flag to indicated suggested move only */

dsptr->s_sflag |= sf_sing;

/* only one move to be in this moveset; allocate space for move */

dsptr->s_count = 1;
MovesetAllocateSingleton(dsptr);

/* copy descendant move */

dmptr = dsptr->s_mbase;
*dmptr = *tmptr;

/* clear the singleton move search flag */

dmptr->m_flag &= ~mf_srch;

/* set descendant move backward pointer (note: only allocated copy set) */

dmptr->m_cptr = dsptr;

/* set descendant back link */

dsptr->s_mprev = mptr;

/* set parent moveset gen connect flag (may already be set) */

if (mptr->m_cptr != NULL)
	mptr->m_cptr->s_sflag |= sf_gcon;

return;
}

/*--> MovesetExecuteScan: execute/retract scan to set flags */
static
void
MovesetExecuteScan(sptrT sptr)
{
mptrT mptr;
siT i, count;

if (!(sptr->s_sflag & sf_exec))
	{
	mptr = sptr->s_mbase;
	count = sptr->s_count;
	for (i = 0; i < count; i++)
		{
		if (!(mptr->m_flag & mf_exec))
			{
			ExecuteMove(mptr);
			RetractMove(mptr);
			};
		mptr++;
		};
	sptr->s_sflag |= sf_exec;
	};

return;
}

/*--> CountLegalMoves: count number of legal moves in a moveset */
nonstatic
siT
CountLegalMoves(sptrT sptr)
{
siT count, i, n;
mptrT mptr;

count = 0;

MovesetExecuteScan(sptr);
mptr = sptr->s_mbase;
i = 0;
n = sptr->s_count;
for (i = 0; i < n; i++)
	{
	if (!(mptr->m_flag & mf_bust))
		count++;
	mptr++;
	};

return (count);
}

/*--> MovesetPolice: remove illegal moves in a moveset, then compact */
nonstatic
void
MovesetPolice(sptrT sptr)
{
mptrT mptr;
siT i, n, illegal, count;
mT m;

/* clear the best and current pointers */

sptr->s_mbest = sptr->s_mcurr = NULL;

if (!(sptr->s_sflag & sf_plcd))
	{
	MovesetExecuteScan(sptr);
	n = sptr->s_count;
	count = CountLegalMoves(sptr);
	if (count != n)
		{
		mptr = sptr->s_mbase;
		i = 0;
		illegal = n - count;
		while (i < illegal)
			{
			m = *mptr;
			if (m.m_flag & mf_bust)
				{
				/* one more illegal move found */

				i++;

				/* replace the current move with the last move in set */

				*mptr = *(sptr->s_mbase + (n - i));

				/* rethread descendant, if any */

				if (mptr->m_dptr != NULL)
					mptr->m_dptr->s_mprev = mptr;
				}
			else
				mptr++;
			};

		/* adjust count field and resize */

		if (illegal > 0)
			{
			sptr->s_count -= illegal;
			MovesetResize(sptr);
			};
		};
	sptr->s_sflag |= sf_plcd;
	};

return;
}

/*--> MovesetDrawScan: search for drawing moves in moveset (also 2nd rep) */
static
void
MovesetDrawScan(sptrT sptr)
{
mptrT dmptr, scmptr;
siT j, flag, i, count, dcount;

/* save the current move pointer */

scmptr = sptr->s_mcurr;

/* assume policed moveset on entry */

if (sptr->s_mbase != NULL)
	{
	sptr->s_mcurr = sptr->s_mbase;
	count = sptr->s_count;
	for (i = 0; i < count; i++)
		{
		/* process only legal moves */

		if (!(sptr->s_mcurr->m_flag & mf_bust))
			{
			/* set no draw and try a move */

			flag = 0;
			ExecuteMove(sptr->s_mcurr);

			/* test for nonstalemate immediate draws */

			if (DrawHalfMoveClock() ||
				DrawInsufficientMaterial() ||
				((ply <= 1) ?
					DrawRepeatThrice() : DrawHashRepeatThrice()))
				flag = 1;
			else

				/* test for a double repetition */

				if ((ply <= 1) ?
					DrawRepeatTwice() : DrawHashRepeatTwice())
					{
					sptr->s_mcurr->m_flag |= mf_pdrw;
					sptr->s_mcurr->m_eval = -cpev_draw;
					}
				else
					{
					/* test for stalemate */

					if (bb_tstnotand(cpbbv[actc_k], acbbv[pasc]))
						{
						/* generate */

						MovesetGenerateConnect(sptr->s_mcurr);

						/* assume stalemate */

						j = 0;
						flag = 1;
						dcount = sptr->s_mcurr->m_dptr->s_count;
						dmptr = sptr->s_mcurr->m_dptr->s_mbase;

						/* scan for secondary move existence */

						while (flag & (j < dcount))
							{
							if (!(dmptr->m_flag & mf_exec))
								{
								ExecuteMove(dmptr);
								RetractMove(dmptr);
								};
							if (dmptr->m_flag & mf_bust)
								{
								j++;
								dmptr++;
								}
							else
								{
								/* deny stalemate */

								flag = 0;
								};
							};

						/* release */

						MovesetDisconnectRelease(sptr->s_mcurr);
						};
					};

			/* set move flags if an immediate draw */

			if (flag)
				{
				sptr->s_mcurr->m_flag |= mf_draw;
				sptr->s_mcurr->m_eval = -cpev_draw;
				};

			/* retract move */

			RetractMove(sptr->s_mcurr);
			};

		/* next move in set */

		sptr->s_mcurr++;
		};
	};

/* restore the current move pointer */

sptr->s_mcurr = scmptr;

return;
}

/*--> MovesetMateScan: search for checkmating moves in a moveset */
static
void
MovesetMateScan(sptrT sptr)
{
mptrT dmptr, mptr, scmptr;
siT flag, j, i, count, dcount;

/* save the current move pointer */

scmptr = sptr->s_mcurr;

/* assume policed moveset on entry */

if (sptr->s_mbase != NULL)
	{
	mptr = sptr->s_mbase;
	count = sptr->s_count;
	for (i = 0; i < count; i++)
		{
		if (!(mptr->m_flag & mf_bust) && (mptr->m_flag & mf_chec))
			{
			ExecuteMove(mptr);
			MovesetGenerateConnect(mptr);
			flag = 1;
			j = 0;
			dcount = mptr->m_dptr->s_count;
			dmptr = mptr->m_dptr->s_mbase;
			while (flag & (j < dcount))
				{
				if (!(dmptr->m_flag & mf_exec))
					{
					ExecuteMove(dmptr);
					RetractMove(dmptr);
					};
				if (dmptr->m_flag & mf_bust)
					{
					j++;
					dmptr++;
					}
				else
					flag = 0;
				};
			if (flag)
				{
				mptr->m_flag |= mf_mate;
				mptr->m_eval = synth_mate(1) - ply;
				};
			MovesetDisconnectRelease(mptr);
			RetractMove(mptr);
			};
		mptr++;
		};
	};

/* restore the current move pointer */

sptr->s_mcurr = scmptr;

return;
}

/*--> MovesetDrawAndMateScan: search for drawing/mating moves in moveset */
nonstatic
void
MovesetDrawAndMateScan(sptrT sptr)
{
if (!(sptr->s_sflag & sf_cdmm))
	{
	sptr->s_sflag |= sf_cdmm;
	MovesetPolice(sptr);
	MovesetDrawScan(sptr);
	MovesetMateScan(sptr);
	};

return;
}

/*--> MovesetFlagsScan: set various flags of interest in a moveset */
nonstatic
void
MovesetFlagsScan(sptrT sptr)
{
MovesetDrawAndMateScan(sptr);
SANDisambiguate(sptr);

return;
}

/*--> MovesetAllBadButOneScan: attempt to set the "all-bad-but-one" bit */
nonstatic
void
MovesetAllBadButOneScan(sptrT sptr)
{
mptrT mptr;
siT i, count, notbad;

if (!(sptr->s_sflag & sf_abbo))
	{
	notbad = 0;
	i = 0;
	count = sptr->s_count;
	mptr = sptr->s_mbase;
	while ((notbad < 2) && (i < count))
		{
		if (!(mptr->m_flag & mf_bust))
			notbad++;
		mptr++;
		i++;
		};
	if (notbad == 1)
		sptr->s_sflag |= sf_abbo;
	};

return;
}

/*--> MovesetBestCertainScore: return best certain score */
nonstatic
cpevT
MovesetBestCertainScore(sptrT sptr)
{
cpevT cpev;
mptrT mptr;
siT i, count;

cpev = cpev_bust;

i = 0;
count = sptr->s_count;
mptr = sptr->s_mbase;

while (i < count)
	{
	if (!(mptr->m_flag & mf_bust) && (mptr->m_flag & mfm_certain))
		if (mptr->m_eval > cpev)
			cpev = mptr->m_eval;
	mptr++;
	i++;
	};

return (cpev);
}

/*--> MovesetCertaintyScan: attempt to set the "all-moves-certain" bit */
nonstatic
void
MovesetCertaintyScan(sptrT sptr)
{
mptrT mptr;
siT flag, i, count;

if (!(sptr->s_sflag & sf_cert))
	{
	flag = 1;
	i = 0;
	count = sptr->s_count;
	mptr = sptr->s_mbase;
	while (flag && (i < count))
		if (!(mptr->m_flag & mf_bust) && !(mptr->m_flag & mfm_certain))
			flag = 0;
		else
			{
			mptr++;
			i++;
			};
	if (flag)
		sptr->s_sflag |= sf_cert;
	};

return;
}

/*--> MovesetFullExpand: apply full processing, -n- plies deep */
nonstatic
void
MovesetFullExpand(sptrT sptr, siT n)
{
siT i, count;
mptrT mptr;

/* set drawing and mating flags; also notation disambiguation flags */

MovesetFlagsScan(sptr);

/* sort the moves in SAN order */

SANSort(sptr);

/* process descendants */

if (n > 0)
	{
	count = sptr->s_count;
	mptr = sptr->s_mbase;
	for (i = 0; i < count; i++)
		{
		MovesetGenerateConnect(mptr);
		MovesetFullExpand(mptr->m_dptr, (n - 1));
		mptr++;
		};
	};

return;
}

/*--> TreeNew: dispose old moveset tree and start a new one */
nonstatic
void
TreeNew(void)
{
/* this routine called only from CreateAll(), FMSearch(), and PlayMove() */

/* release the old tree */

if (root_sptr != NULL)
	{
	MovesetRelease(root_sptr);
	root_sptr = NULL;
	root_m.m_dptr = NULL;
	};

/* continue only for legal position */

if (PositionCensusOkay())
	{
	/* construct the base of the new tree */

	root_sptr = Generate(1);
	root_sptr->s_mprev = &root_m;
	root_m.m_dptr = root_sptr;

	/* process full expansion */

	MovesetFullExpand(root_sptr, 0);
	};

return;
}

/*<<< moveset.c: EOF */
