/*>>> ts.h: subprogram prototypes for ts.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void TSClearMoveResponse(void);
void TSClearKillerMoves(void);
void TSInit(void);
void TSTerm(void);
mptrT TSSearch(void);
mptrT TSMateInOne(void);
mptrT TSMateACO(siT n);
mptrT TSMate(siT n);
mptrT TSTMate(siT n);
liT TSEnumerate(siT depth);
cpevT TSEval(void);
cpevT TSEvalAB(cpevT alpha, cpevT beta);

/*<<< ts.h: EOF */
