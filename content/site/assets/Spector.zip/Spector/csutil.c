/*>>> csutil.c: concept search utility routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "csdefs.h"
#include "csvars.h"

#include "csprim.h"
#include "csutil.h"
#include "memutil.h"
#include "moveset.h"

/*--> CSInitPatternName: initialize a single basic pattern descriptor name */
static
void
CSInitPatternName(bpT bp, charptrT name)
{
bpdv[bp].bpd_name = name;

return;
}

/*--> CSInitPattern: initialize a single bp descriptor (except name) */
static
void
CSInitPattern(bpT bp, frvsptrptrT genf, bpmT bpm)
{
bpdv[bp].bpd_genf = genf;
bpdv[bp].bpd_bpm = bpm;

return;
}

/*--> CSInitPatternVector: initialize basic pattern descriptor vector */
static
void
CSInitPatternVector(void)
{
/* names */

CSInitPatternName(bp_none,			"none");
CSInitPatternName(bp_active,		"active");
CSInitPatternName(bp_activeking,	"activeking");
CSInitPatternName(bp_adverse,		"adverse");
CSInitPatternName(bp_attacked,		"attacked");
CSInitPatternName(bp_attacks,		"attacks");
CSInitPatternName(bp_checkmated,	"checkmated");
CSInitPatternName(bp_connected,		"connected");
CSInitPatternName(bp_defended,		"defended");
CSInitPatternName(bp_defends,		"defends");
CSInitPatternName(bp_discover,		"discover");
CSInitPatternName(bp_drawn,			"drawn");
CSInitPatternName(bp_exchangable,	"exchangable");
CSInitPatternName(bp_exists,		"exists");
CSInitPatternName(bp_fiftymove,		"fiftymove");
CSInitPatternName(bp_hung,			"hung");
CSInitPatternName(bp_indirect,		"indirect");
CSInitPatternName(bp_jeopardy,		"jeopardy");
CSInitPatternName(bp_move,			"move");
CSInitPatternName(bp_outofwood,		"outofwood");
CSInitPatternName(bp_passive,		"passive");
CSInitPatternName(bp_passiveking,	"passiveking");
CSInitPatternName(bp_protected,		"protected");
CSInitPatternName(bp_repeated,		"repeated");
CSInitPatternName(bp_stalemated,	"stalemated");
CSInitPatternName(bp_thirdrepeat,	"thirdrepeat");
CSInitPatternName(bp_unconnected,	"unconnected");

/* other */

CSInitPattern(bp_none,			CSPrimitiveNone,			bpm_none);
CSInitPattern(bp_active,		CSPrimitiveActive,			bpm_active);
CSInitPattern(bp_activeking,	CSPrimitiveActiveking,		bpm_activeking);
CSInitPattern(bp_adverse,		CSPrimitiveAdverse,			bpm_adverse);
CSInitPattern(bp_attacked,		CSPrimitiveAttacked,		bpm_attacked);
CSInitPattern(bp_attacks,		CSPrimitiveAttacks,			bpm_attacks);
CSInitPattern(bp_checkmated,	CSPrimitiveCheckmated,		bpm_checkmated);
CSInitPattern(bp_connected,		CSPrimitiveConnected,		bpm_connected);
CSInitPattern(bp_defended,		CSPrimitiveDefended,		bpm_defended);
CSInitPattern(bp_defends,		CSPrimitiveDefends,			bpm_defends);
CSInitPattern(bp_discover,		CSPrimitiveDiscover,		bpm_discover);
CSInitPattern(bp_drawn,			CSPrimitiveDrawn,			bpm_drawn);
CSInitPattern(bp_exchangable,	CSPrimitiveExchangable,		bpm_exchangable);
CSInitPattern(bp_exists,		CSPrimitiveExists,			bpm_exists);
CSInitPattern(bp_fiftymove,		CSPrimitiveFiftymove,		bpm_fiftymove);
CSInitPattern(bp_hung,			CSPrimitiveHung,			bpm_hung);
CSInitPattern(bp_indirect,		CSPrimitiveIndirect,		bpm_indirect);
CSInitPattern(bp_jeopardy,		CSPrimitiveJeopardy,		bpm_jeopardy);
CSInitPattern(bp_move,			CSPrimitiveMove,			bpm_move);
CSInitPattern(bp_outofwood,		CSPrimitiveOutofwood,		bpm_outofwood);
CSInitPattern(bp_passive,		CSPrimitivePassive,			bpm_passive);
CSInitPattern(bp_passiveking,	CSPrimitivePassiveking,		bpm_passiveking);
CSInitPattern(bp_protected,		CSPrimitiveProtected,		bpm_protected);
CSInitPattern(bp_repeated,		CSPrimitiveRepeated,		bpm_repeated);
CSInitPattern(bp_stalemated,	CSPrimitiveStalemated,		bpm_stalemated);
CSInitPattern(bp_thirdrepeat,	CSPrimitiveThirdrepeat,		bpm_thirdrepeat);
CSInitPattern(bp_unconnected,	CSPrimitiveUnconnected,		bpm_unconnected);

return;
}

/*--> CSInit: one time cs initialization (called from -init-) */
nonstatic
void
CSInit(void)
{
/* set up the null basic pattern frame */

null_bpf.bpf_bp = bp_nil;
null_bpf.bpf_cp0 = null_bpf.bpf_cp1 = null_bpf.bpf_cp2 = null_bpf.bpf_cp3 =
	cp_nil;
null_bpf.bpf_sq0 = null_bpf.bpf_sq1 = null_bpf.bpf_sq2 = null_bpf.bpf_sq3 =
	sq_nil;
null_bpf.bpf_scmv = scmv_nil;
null_bpf.bpf_next = null_bpf.bpf_prev = NULL;

/* initialize the basic pattern descriptor vector */

CSInitPatternVector();

return;
}

/*--> CSTerm: one time cs termination (called from -term-) */
nonstatic
void
CSTerm(void)
{

return;
}

/*--> CSConceptNotationNew: allocate and clear a concept notation record */
static
cnptrT
CSConceptNotationNew(void)
{
cnptrT cnptr;

cnptr = (cnptrT) MemoryGrab(sizeof(cnT));
cnptr->cn_bpfhead = cnptr->cn_bpftail = NULL;

return (cnptr);
}

/*--> CSConceptNotationRelease: release a concept notation record */
nonstatic
void
CSConceptNotationRelease(cnptrT cnptr)
{
bpfptrT bpfptr0, bpfptr1;

if (cnptr != NULL)
	{
	bpfptr0 = cnptr->cn_bpfhead;
	while (bpfptr0 != NULL)
		{
		bpfptr1 = bpfptr0->bpf_next;
		MemoryFree(bpfptr0);
		bpfptr0 = bpfptr1;
		};
	MemoryFree(cnptr);
	};

return;
}

/*--> CSGeneratePatternSet: generate basic pattern frames */
static
void
CSGeneratePatternSet(sptrT sptr)
{
bpT bp;
frvsptrptrT genf;

for (bp = bp_none; bp < bpL; bp++)
	{
	genf = bpdv[bp].bpd_genf;
	(*genf)(sptr);
	};

return;
}

/*--> CSExpandNode: expand a node in the CS */
nonstatic
void
CSExpandNode(sptrT sptr)
{
if (!(sptr->s_sflag & sf_cnpd))
	{
	/* mark concept expansion */

	sptr->s_sflag |= sf_cnpd;

	/* process full expansion */

	MovesetFullExpand(sptr, 0);

	/* allocate, connect, and initialize concept notation record */

	if (sptr->s_cnptr == NULL)
		{
		/* allocate concept notation record */

		sptr->s_cnptr = CSConceptNotationNew();

		/* generate and post basic pattern frames */

		CSGeneratePatternSet(sptr);
		};
	};

return;
}

/*<<< csutil.c: EOF */
