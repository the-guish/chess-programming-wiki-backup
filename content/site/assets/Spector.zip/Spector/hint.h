/*>>> hint.h: subprogram prototypes for hint.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

mptrT FindHint(void);
void InteractiveHint(void);

/*<<< hint.h: EOF */
