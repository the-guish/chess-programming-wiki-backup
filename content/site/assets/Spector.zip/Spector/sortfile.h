/*>>> sortfile.h: subprogram prototypes for sortfile.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void SortTextFile(charptrT i_fn, charptrT o_fn);

/*<<< sortfile.h: EOF */
