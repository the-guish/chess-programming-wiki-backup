/*>>> term.h: subprogram prototypes for term.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void Term(void);

/*<<< term.h: EOF */
