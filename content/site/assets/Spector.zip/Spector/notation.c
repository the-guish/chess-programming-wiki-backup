/*>>> notation.c: chess move notation mode processing */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "notation.h"
#include "san.h"
#include "sysutil.h"

/**** Locals */

/* construction san vector and index */

static sanT ln_san;
static siT ln_i;

/*--> InsertChar: insert character */
static
void
InsertChar(char ch)
{
if (ln_i < sanL)
	ln_san[ln_i++] = ch;
else
	Diagnose("InsertChar: notation overflow");

return;
}

/*--> InsertSS: insert simple string */
static
void
InsertSS(charptrT sptr)
{
charptrT p;

for (p = sptr; *p != ascii_nul; p++)
	InsertChar(*p);

return;
}

/*--> InsertCCPL: insert color cased piece letter */
static
void
InsertCCPL(cpT cp)
{
if (cp_tstw(cp))
	InsertChar(map_lower(ascpv[lang_san][cv_p_cpv[cp]]));
else
	InsertChar(map_upper(ascpv[lang_san][cv_p_cpv[cp]]));

return;
}

/*--> InsertPP: insert promotion piece */
static
void
InsertPP(mptrT mptr)
{
switch (mptr->m_scmv)
	{
	case scmv_ppn:
	case scmv_ppb:
	case scmv_ppr:
	case scmv_ppq:
		InsertChar(ascpv[lang_san][cv_p_scmvv[mptr->m_scmv]]);
		break;

	default:
		SwitchFault("InsertPP");
		break;
	};

return;
}

/*--> InsertSPP: insert a slash and a promotion piece */
static
void
InsertSPP(mptrT mptr)
{
InsertChar('/');
InsertPP(mptr);

return;
}

/*--> InsertMCI: insert move/capture indicator */
static
void
InsertMCI(mptrT mptr)
{
if ((mptr->m_tocp == cp_v0) && (mptr->m_scmv != scmv_epc))
	InsertChar('-');
else
	InsertChar('x');

return;
}

/*--> InsertFrSq: insert "from" square algebraic label */
static
void
InsertFrSq(mptrT mptr)
{
InsertChar(ascfv[map_file(mptr->m_frsq)]);
InsertChar(ascrv[map_rank(mptr->m_frsq)]);

return;
}

/*--> InsertToSq: insert "to" square algebraic label */
static
void
InsertToSq(mptrT mptr)
{
InsertChar(ascfv[map_file(mptr->m_tosq)]);
InsertChar(ascrv[map_rank(mptr->m_tosq)]);

return;
}

/*--> InsertFrToSq: insert "from" and "to" square algebraic labels */
static
void
InsertFrToSq(mptrT mptr)
{
InsertFrSq(mptr);
InsertToSq(mptr);

return;
}

/*--> InsertFIT: insert "from", indicator, and "to" square labels */
static
void
InsertFIT(mptrT mptr)
{
InsertFrSq(mptr);
InsertMCI(mptr);
InsertToSq(mptr);

return;
}

/*--> SetupLocal: setup local items and handle illegal move */
static
void
SetupLocal(mptrT mptr)
{
ln_i = 0;

if (mptr->m_flag & mf_bust)
	InsertChar('*');

return;
}

/*--> PadSANCopy: pad san with trailing NULs */
static
void
PadSANCopy(sanT san)
{
siT i;

while (ln_i < sanL)
	InsertChar(ascii_nul);

for (i = 0; i < sanL; i++)
	san[i] = ln_san[i];

return;
}

/*--> CoordinateMove: construct a coordinate notation move */
nonstatic
void
CoordinateMove(mptrT mptr, sanT san)
{
SetupLocal(mptr);

InsertChar('1' + map_file(mptr->m_frsq));
InsertChar('1' + map_rank(mptr->m_frsq));
InsertChar('1' + map_file(mptr->m_tosq));
InsertChar('1' + map_rank(mptr->m_tosq));

switch (mptr->m_scmv)
	{
	case scmv_reg:
	case scmv_epc:
	case scmv_cks:
	case scmv_cqs:
		break;

	case scmv_ppn:
		InsertChar('4');
		break;

	case scmv_ppb:
		InsertChar('3');
		break;

	case scmv_ppr:
		InsertChar('2');
		break;

	case scmv_ppq:
		InsertChar('1');
		break;

	default:
		SwitchFault("CoordinateMove");
		break;
	};

PadSANCopy(san);

return;
}

/*--> Exp0Move: construct an experimental notation move (type 0) */
nonstatic
void
Exp0Move(mptrT mptr, sanT san)
{
SetupLocal(mptr);

switch (mptr->m_scmv)
	{
	case scmv_reg:
	case scmv_epc:
		InsertFIT(mptr);
		break;

	case scmv_cks:
		InsertSS("O-O");
		break;

	case scmv_cqs:
		InsertSS("O-O-O");
		break;

	case scmv_ppn:
	case scmv_ppb:
	case scmv_ppr:
	case scmv_ppq:
		InsertFIT(mptr);
		InsertSPP(mptr);
		break;

	default:
		SwitchFault("Exp0Move");
		break;
	};

PadSANCopy(san);

return;
}

/*--> Exp1Move: construct an experimental notation move (type 1) */
nonstatic
void
Exp1Move(mptrT mptr, sanT san)
{
SetupLocal(mptr);

switch (mptr->m_scmv)
	{
	case scmv_reg:
	case scmv_epc:
	case scmv_cks:
	case scmv_cqs:
		InsertFrToSq(mptr);
		break;

	case scmv_ppn:
	case scmv_ppb:
	case scmv_ppr:
	case scmv_ppq:
		InsertFrToSq(mptr);
		InsertPP(mptr);
		break;

	default:
		SwitchFault("Exp1Move");
		break;
	};

PadSANCopy(san);

return;
}

/*--> Exp2Move: construct an experimental notation move (type 2) */
nonstatic
void
Exp2Move(mptrT mptr, sanT san)
{
SetupLocal(mptr);

switch (mptr->m_scmv)
	{
	case scmv_reg:
	case scmv_epc:
		InsertFIT(mptr);
		break;

	case scmv_cks:
		InsertSS("O-O");
		break;

	case scmv_cqs:
		InsertSS("O-O-O");
		break;

	case scmv_ppn:
	case scmv_ppb:
	case scmv_ppr:
	case scmv_ppq:
		InsertFIT(mptr);
		InsertSPP(mptr);
		break;

	default:
		SwitchFault("Exp2Move");
		break;
	};

PadSANCopy(san);

return;
}

/*--> Exp3Move: construct an experimental notation move (type 3) */
nonstatic
void
Exp3Move(mptrT mptr, sanT san)
{
SetupLocal(mptr);

switch (mptr->m_scmv)
	{
	case scmv_reg:
	case scmv_epc:
		InsertFrToSq(mptr);
		break;

	case scmv_cks:
		InsertSS("o-o");
		break;

	case scmv_cqs:
		InsertSS("o-o-o");
		break;

	case scmv_ppn:
	case scmv_ppb:
	case scmv_ppr:
	case scmv_ppq:
		InsertFrToSq(mptr);
		InsertSPP(mptr);
		break;

	default:
		SwitchFault("Exp3Move");
		break;
	};

PadSANCopy(san);

return;
}

/*--> Exp4Move: construct an experimental notation move (type 4) */
nonstatic
void
Exp4Move(mptrT mptr, sanT san)
{
SetupLocal(mptr);

switch (mptr->m_scmv)
	{
	case scmv_reg:
		InsertCCPL(mptr->m_frcp);
		InsertFrToSq(mptr);
		if (mptr->m_tocp != cp_v0)
			InsertCCPL(mptr->m_tocp);
		break;

	case scmv_epc:
		InsertCCPL(mptr->m_frcp);
		InsertFrToSq(mptr);
		if (cp_tstw(mptr->m_frcp))
			InsertChar(map_upper(ascpv[lang_san][p_p]));
		else
			InsertChar(map_lower(ascpv[lang_san][p_p]));
		break;

	case scmv_cks:
		if (cp_tstw(mptr->m_frcp))
			InsertSS("o-o");
		else
			InsertSS("O-O");
		break;

	case scmv_cqs:
		if (cp_tstw(mptr->m_frcp))
			InsertSS("o-o-o");
		else
			InsertSS("O-O-O");
		break;

	case scmv_ppn:
	case scmv_ppb:
	case scmv_ppr:
	case scmv_ppq:
		InsertCCPL(mptr->m_frcp);
		InsertFrToSq(mptr);
		if (mptr->m_tocp != cp_v0)
			InsertCCPL(mptr->m_tocp);
		InsertSPP(mptr);
		break;

	default:
		SwitchFault("Exp4Move");
		break;
	};

PadSANCopy(san);

return;
}

/*--> Exp5Move: construct an experimental notation move (type 5) */
nonstatic
void
Exp5Move(mptrT mptr, sanT san)
{
SetupLocal(mptr);

switch (mptr->m_scmv)
	{
	case scmv_reg:
		InsertCCPL(mptr->m_frcp);
		InsertFrToSq(mptr);
		if (mptr->m_tocp != cp_v0)
			InsertCCPL(mptr->m_tocp);
		break;

	case scmv_epc:
		InsertCCPL(mptr->m_frcp);
		InsertFrToSq(mptr);
		if (cp_tstw(mptr->m_frcp))
			InsertChar(map_upper(ascpv[lang_san][p_p]));
		else
			InsertChar(map_lower(ascpv[lang_san][p_p]));
		break;

	case scmv_cks:
		InsertSS("O-O");
		break;

	case scmv_cqs:
		InsertSS("O-O-O");
		break;

	case scmv_ppn:
	case scmv_ppb:
	case scmv_ppr:
	case scmv_ppq:
		InsertCCPL(mptr->m_frcp);
		InsertFrToSq(mptr);
		if (mptr->m_tocp != cp_v0)
			InsertCCPL(mptr->m_tocp);
		InsertSPP(mptr);
		break;

	default:
		SwitchFault("Exp5Move");
		break;
	};

PadSANCopy(san);

return;
}

/*--> ConstructNotation: construct notation from move and mode */
nonstatic
void
ConstructNotation(nmT nm, mptrT mptr, sanT san)
{
switch (nm)
	{
	case nm_algebraic:
		SANMove(mptr, san);
		break;

	case nm_coordinate:
		CoordinateMove(mptr, san);
		break;

	case nm_exp0:
		Exp0Move(mptr, san);
		break;

	case nm_exp1:
		Exp1Move(mptr, san);
		break;

	case nm_exp2:
		Exp2Move(mptr, san);
		break;

	case nm_exp3:
		Exp3Move(mptr, san);
		break;

	case nm_exp4:
		Exp4Move(mptr, san);
		break;

	case nm_exp5:
		Exp5Move(mptr, san);
		break;

	default:
		SwitchFault("ConstructNotation");
		break;
	};

return;
}

/*<<< notation.c: EOF */
