/*>>> systimer.h: subprogram prototypes for systimer.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/*<<< systimer.h: EOF */
