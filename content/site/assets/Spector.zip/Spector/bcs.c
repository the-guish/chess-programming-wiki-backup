/*>>> bcs.c: best candidate services */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "assist.h"
#include "bcs.h"
#include "killer.h"
#include "moveset.h"
#include "mu.h"
#include "predvar.h"
#include "refute.h"
#include "tt.h"

/**** Locals */

/* return value for best move synthesis */

static mT bmsynth_m;

/*--> SynthBestMove: attempt to synthesize a best move */
nonstatic
mptrT
SynthBestMove(mptrT pmptr)
{
mptrT mptr;
mptrT synth_mptr, bmptr;

/* set default value */

mptr = NULL;

/* try: predicted variation */

if (mptr == NULL)
	if (FTDIteration)
		if ((bmptr = PVarEMoveRef(ply)) != NULL)
			{
			synth_mptr = SynthesizeMove(bmptr->m_frsq, bmptr->m_tosq);
			if (synth_mptr != NULL)
				{
				bmsynth_m = *synth_mptr;
				mptr = &bmsynth_m;
				};
			};

/* try: refutation sequence */

if (mptr == NULL)
	if (FTDPlyZeroMove && (ply > 0))
		if ((bmptr = RefuteFetchMoveRef()) != NULL)
			{
			synth_mptr = SynthesizeMove(bmptr->m_frsq, bmptr->m_tosq);
			if (synth_mptr != NULL)
				{
				bmsynth_m = *synth_mptr;
				mptr = &bmsynth_m;
				};
			};

/* try: obvious capture response */

if (mptr == NULL)
	if (!null_move_ref(pmptr))
		if ((bmptr = ObviousCaptureResponse(pmptr)) != NULL)
			{
			synth_mptr = SynthesizeMove(bmptr->m_frsq, bmptr->m_tosq);
			if (synth_mptr != NULL)
				{
				bmsynth_m = *synth_mptr;
				mptr = &bmsynth_m;
				};
			};

return (mptr);
}

/*--> SetBestMovePointer: set best move pointer from table data */
nonstatic
void
SetBestMovePointer(sptrT sptr)
{
mptrT mptr;
mptrT pmptr, bmptr;

/* set default result */

mptr = NULL;

/* try: only one move */

if (mptr == NULL)
	if (sptr->s_count == 1)
		mptr = sptr->s_mbase;

/* try: predicted variation */

if (mptr == NULL)
	if (FTDIteration)
		if ((bmptr = PVarEMoveRef(ply)) != NULL)
			mptr = FindMove(bmptr, sptr);

/* try: refutation sequence */

if (mptr == NULL)
	if (FTDPlyZeroMove && (ply > 0))
		if ((bmptr = RefuteFetchMoveRef()) != NULL)
			mptr = FindMove(bmptr, sptr);

/* try: obvious capture response */

if (mptr == NULL)
	{
	pmptr = sptr->s_mprev;
	if ((pmptr != NULL) && !null_move_ref(pmptr))
		if ((bmptr = ObviousCaptureResponse(pmptr)) != NULL)
			mptr = FindMove(bmptr, sptr);
	};

/* set result */

sptr->s_mbest = mptr;

return;
}

/*--> SetBestMovePointer2: set BM pointer from table with avoidance */
nonstatic
void
SetBestMovePointer2(sptrT sptr, mptrT amptr)
{
mptrT mptr;
mptrT pmptr, bmptr;

/* set default result */

mptr = NULL;

/* try: only one move */

if (mptr == NULL)
	if (sptr->s_count == 1)
		if (!same_move_ref(amptr, sptr->s_mbase))
			mptr = sptr->s_mbase;

/* try: predicted variation */

if (mptr == NULL)
	if (FTDIteration)
		if ((bmptr = PVarEMoveRef(ply)) != NULL)
			if (!same_move_ref(amptr, bmptr))
				mptr = FindMove(bmptr, sptr);

/* try: refutation sequence */

if (mptr == NULL)
	if (FTDPlyZeroMove && (ply > 0))
		if ((bmptr = RefuteFetchMoveRef()) != NULL)
			if (!same_move_ref(amptr, bmptr))
				mptr = FindMove(bmptr, sptr);

/* try: obvious capture response */

if (mptr == NULL)
	{
	pmptr = sptr->s_mprev;
	if ((pmptr != NULL) && !null_move_ref(pmptr))
		if ((bmptr = ObviousCaptureResponse(pmptr)) != NULL)
			if (!same_move_ref(amptr, bmptr))
				mptr = FindMove(bmptr, sptr);
	};

/* set result */

sptr->s_mbest = mptr;

return;
}

/*<<< bcs.c: EOF */
