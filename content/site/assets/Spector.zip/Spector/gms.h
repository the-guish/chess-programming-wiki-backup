/*>>> gms.h: subprogram prototypes for gms.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void GMSCR(fptrT fptr);
void GMSER(fptrT fptr);

/*<<< gms.h: EOF */
