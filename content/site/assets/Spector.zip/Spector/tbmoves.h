/*>>> tbmoves.h: subprogram prototypes for tbmoves.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void TBOcSetUp(void);
siT TBOcMax(void);
sqT TBOcPairSq(void);
void TBOcSetPair(sqT sq);
void TBEraseBoard(void);
void TBSetSquare(cpT cp, sqT sq);
siT TBActiveKIC(void);
siT TBPassiveKIC(void);
void TBExecute(tmptrT tmptr);
void TBRetract(tmptrT tmptr);
void TBGenDirect(void);
void TBGenRetro(void);
void TBInitMG(void);
void TBTermMG(void);

/*<<< tbmoves.h: EOF */
