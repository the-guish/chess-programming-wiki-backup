/*>>> commvars.h: command variable references */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* command records */

extern crT crv[commL];

/**** tokens and parameters */

/* count of input tokens */

extern siT tkn;

/* array of pointers to tokens */

extern charptrT tkv[itL];

/* input parameter values */

extern ipT ipv[ipL];

/*<<< commvars.h: EOF */
