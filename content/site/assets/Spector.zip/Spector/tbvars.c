/*>>> tbvars.c: tablebase variable declarations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "tbdefs.h"

/* generated moves (direct) */

siT tb_dtmnv[rcL];
tmptrT tb_dtmv[rcL];

/* generated moves (retro) */

siT tb_rtmnv[rcL];
tmptrT tb_rtmv[rcL];

/* tablebase active/passive colors */

cT tb_actc, tb_pasc;

/* tablebase local board (color-piece) */

tiT tb_cpv[sqL];

/* tablebase local board (piece indexes) */

tiT tb_piv[sqL];

/* tablebase move generation piece vector */

siT tb_mgpnv[rcL];
sqT tb_mgpv[rcL][pmaxL];

/* captured piece kind, last square, and index */

cpT tb_capt_cp;
sqT tb_capt_sq;
siT tb_capt_index;

/* master color-piece number vector */

siT tb_mcpnv[rcL];

/* master scanning pattern vector */

tbspidT tb_mspv[rcL][pmaxL];

/* master color piece vector */

cpT tb_mcpv[rcL][pmaxL];

/* occupancy calculations */

siT tb_ocsqv[sqL];
cpT tb_occpv[rcL];

/* current scanning pattern index vector */

siT tb_cspiv[rcL][pmaxL];

/* current square vector (always post-retraction) */

siT tb_csqv[rcL][pmaxL];

/* anchor pointers for the tablebase file cache list */

tfcptrT head_tfcptr;
tfcptrT tail_tfcptr;

/*<<< tbvars.c: EOF */
