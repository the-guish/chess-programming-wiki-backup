/*>>> cpic.h: subprogram prototypes for cpic.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CPICCommand(void);

/*<<< cpic.h: EOF */
