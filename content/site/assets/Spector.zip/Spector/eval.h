/*>>> eval.h: subprogram prototypes for eval.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

cpevT EvaluateMaterial(void);
cpevT Evaluate(void);
cpevT EvaluateAB(cpevT alpha, cpevT beta);

/*<<< eval.h: EOF */
