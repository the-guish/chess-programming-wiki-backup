/*>>> csprim.c: concept search primitive routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "csdefs.h"
#include "csvars.h"

#include "bbmacs.h"

#include "bb.h"
#include "cspatt.h"
#include "csprim.h"
#include "draw.h"
#include "sysutil.h"

/*--> CSPrimitiveNone: CS basic pattern generator: none */
nonstatic
void
CSPrimitiveNone(sptrT sptr)
{
if (sptr == NULL)
	Diagnose("CSPrimitiveNone: fault");

return;
}

/*--> CSPrimitiveActive: CS basic pattern generator: active piece */
nonstatic
void
CSPrimitiveActive(sptrT sptr)
{
bpfT bpf;
bbT bb;
sqT sq;

bpf = null_bpf;
bpf.bpf_bp = bp_active;

bb = c0bbv[actc];
while (bb_next(bb, sq))
	{
	bpf.bpf_cp0 = local.rbv[sq];
	bpf.bpf_sq0 = sq;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitiveActiveking: CS basic pattern generator: activeking */
nonstatic
void
CSPrimitiveActiveking(sptrT sptr)
{
bpfT bpf;

bpf = null_bpf;
bpf.bpf_bp = bp_activeking;
bpf.bpf_cp0 = actc_k;
bpf.bpf_sq0 = bb_once(cpbbv[bpf.bpf_cp0]);
CSPatternPost(sptr, bpf);

return;
}

/*--> CSPrimitiveAdverse: CS basic pattern generator: adverse */
nonstatic
void
CSPrimitiveAdverse(sptrT sptr)
{
bpfT bpf;
bbT bb0, bb1;
sqT sq0, sq1;
cT c0, c1;

bpf = null_bpf;
bpf.bpf_bp = bp_adverse;

for (c0 = c_w; c0 <= c_b; c0++)
	{
	c1 = inv_cv[c0];
	bb_and3(c0bbv[c0], acbbv[c1], bb0);
	while (bb_next(bb0, sq0))
		{
		bpf.bpf_sq0 = sq0;
		bpf.bpf_cp0 = local.rbv[sq0];
		bb_and3(afbbv[sq0], c0bbv[c1], bb1);
		while (bb_next(bb1, sq1))
			if (bb_tstsq(afbbv[sq1], sq0))
				{
				bpf.bpf_sq1 = sq1;
				bpf.bpf_cp1 = local.rbv[sq1];
				CSPatternPost(sptr, bpf);
				};
		};
	};

return;
}

/*--> CSPrimitiveAttacked: CS basic pattern generator: attacked */
nonstatic
void
CSPrimitiveAttacked(sptrT sptr)
{
bpfT bpf;
bbT bb, atkd_w_bb, atkd_b_bb;
sqT sq;

bpf = null_bpf;
bpf.bpf_bp = bp_attacked;

bb_and3(acbbv[c_b], c0bbv[c_w], atkd_w_bb);
bb_and3(acbbv[c_w], c0bbv[c_b], atkd_b_bb);
bb_ior3(atkd_w_bb, atkd_b_bb, bb);

while (bb_next(bb, sq))
	{
	bpf.bpf_cp0 = local.rbv[sq];
	bpf.bpf_sq0 = sq;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitiveAttacks: CS basic pattern generator: attacks */
nonstatic
void
CSPrimitiveAttacks(sptrT sptr)
{
bpfT bpf;
bbT bb0, bb1;
sqT sq0, sq1;
cpT cp0, cp1;
cT c0, c1;

bpf = null_bpf;
bpf.bpf_bp = bp_attacks;

bb0 = apmbb;
while (bb_next(bb0, sq0))
	{
	bpf.bpf_sq0 = sq0;
	cp0 = local.rbv[sq0];
	bpf.bpf_cp0 = cp0;
	c0 = cv_c_cpv[cp0];
	c1 = inv_cv[c0];
	bb_and3(afbbv[sq0], c0bbv[c1], bb1);
	while (bb_next(bb1, sq1))
		{
		bpf.bpf_sq1 = sq1;
		cp1 = local.rbv[sq1];
		bpf.bpf_cp1 = cp1;
		CSPatternPost(sptr, bpf);
		};
	};

return;
}

/*--> CSPrimitiveCheckmated: CS basic pattern generator: checkmated */
nonstatic
void
CSPrimitiveCheckmated(sptrT sptr)
{
bpfT bpf;
sqT sq;
cpT cp;

if (sptr != NULL)
	{
	/* assume moveset fully expanded */

	if (sptr->s_count == 0)
		{
		bpf = null_bpf;
		cp = actc_k;
		sq = bb_once(cpbbv[cp]);
		if (bb_tstsq(acbbv[pasc], sq))
			{
			bpf.bpf_bp = bp_checkmated;
			CSPatternPost(sptr, bpf);
			};
		};
	};

return;
}

/*--> CSPrimitiveConnected: CS basic pattern generator: connected */
nonstatic
void
CSPrimitiveConnected(sptrT sptr)
{
bpfT bpf;
bbT bb0, bb1;
sqT sq0, sq1;
cT c;

bpf = null_bpf;
bpf.bpf_bp = bp_connected;

for (c = c_w; c <= c_b; c++)
	{
	bb_and3(c0bbv[c], acbbv[c], bb0);
	while (bb_next(bb0, sq0))
		{
		bpf.bpf_sq0 = sq0;
		bpf.bpf_cp0 = local.rbv[sq0];
		bb_and3(afbbv[sq0], c0bbv[c], bb1);
		while (bb_next(bb1, sq1))
			if (bb_tstsq(afbbv[sq1], sq0))
				{
				bpf.bpf_sq1 = sq1;
				bpf.bpf_cp1 = local.rbv[sq1];
				CSPatternPost(sptr, bpf);
				};
		};
	};

return;
}

/*--> CSPrimitiveDefended: CS basic pattern generator: defended */
nonstatic
void
CSPrimitiveDefended(sptrT sptr)
{
bpfT bpf;
bbT bb, dfnd_w_bb, dfnd_b_bb;
sqT sq;

bpf = null_bpf;
bpf.bpf_bp = bp_defended;

bb_and3(acbbv[c_w], c0bbv[c_w], dfnd_w_bb);
bb_and3(acbbv[c_b], c0bbv[c_b], dfnd_b_bb);

bb_ior3(dfnd_w_bb, dfnd_b_bb, bb);
while (bb_next(bb, sq))
	{
	bpf.bpf_cp0 = local.rbv[sq];
	bpf.bpf_sq0 = sq;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitiveDefends: CS basic pattern generator: defends */
nonstatic
void
CSPrimitiveDefends(sptrT sptr)
{
bpfT bpf;
bbT bb0, bb1;
sqT sq0, sq1;
cpT cp0, cp1;
cT c;

bpf = null_bpf;
bpf.bpf_bp = bp_defends;

bb0 = apmbb;
while (bb_next(bb0, sq0))
	{
	bpf.bpf_sq0 = sq0;
	cp0 = local.rbv[sq0];
	bpf.bpf_cp0 = cp0;
	c = cv_c_cpv[cp0];
	bb_and3(afbbv[sq0], c0bbv[c], bb1);
	while (bb_next(bb1, sq1))
		{
		bpf.bpf_sq1 = sq1;
		cp1 = local.rbv[sq1];
		bpf.bpf_cp1 = cp1;
		CSPatternPost(sptr, bpf);
		};
	};

return;
}

/*--> CSPrimitiveDiscover: CS basic pattern generator: discover */
nonstatic
void
CSPrimitiveDiscover(sptrT sptr)
{
bpfT bpf;
cT c0, c1;
sqT sq0, sq1, sq2;
cpT cp0, cp1, cp2;
bbT bb_b, bb_r, bb_q, bb0, bb1, bb2;
dxT dx;
dvT dv;

bpf = null_bpf;
bpf.bpf_bp = bp_discover;
for (c0 = c_w; c0 <= c_b; c0++)
	{
	c1 = inv_cv[c0];
	bb_b = cpbbv[cv_cp_c_pv[c0][p_b]];
	bb_r = cpbbv[cv_cp_c_pv[c0][p_r]];
	bb_q = cpbbv[cv_cp_c_pv[c0][p_q]];
	bb_ior4(bb_b, bb_r, bb_q, bb0);
	while (bb_next(bb0, sq0))
		{
		bpf.bpf_sq0 = sq0;
		cp0 = local.rbv[sq0];
		bpf.bpf_cp0 = cp0;
		bb_and3(afbbv[sq0], c0bbv[c0], bb1);
		while (bb_next(bb1, sq1))
			{
			bpf.bpf_sq1 = sq1;
			cp1 = local.rbv[sq1];
			bpf.bpf_cp1 = cp1;
			bb2 = *(beyond_raster_base + offset_sqsq(sq0, sq1));
			if (bb_tstand(c0bbv[c1], bb2))
				{
				dx = *(dx_table_base + offset_sqsq(sq0, sq1));
				dv = dvv[dx];
				sq2 = sq1 + dv;
				cp2 = local.rbv[sq2];
				while (cp2 == cp_v0)
					{
					sq2 += dv;
					cp2 = local.rbv[sq2];
					};
				if (cv_c_cpv[cp2] == c1)
					{
					bpf.bpf_sq2 = sq2;
					bpf.bpf_cp2 = cp2;
					CSPatternPost(sptr, bpf);
					};
				};
			};
		};
	};

return;
}

/*--> CSPrimitiveDrawn: CS basic pattern generator: drawn */
nonstatic
void
CSPrimitiveDrawn(sptrT sptr)
{
bpfT bpf;

if (DrawTestPartial())
	{
	bpf = null_bpf;
	bpf.bpf_bp = bp_drawn;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitiveExchangable: CS basic pattern generator: exchangable */
nonstatic
void
CSPrimitiveExchangable(sptrT sptr)
{
bpfT bpf;
bbT bb, xchg_w_bb, xchg_b_bb;
sqT sq;

bpf = null_bpf;
bpf.bpf_bp = bp_exchangable;

bb_and3(acbbv[c_w], c0bbv[c_w], xchg_w_bb);
bb_and2(acbbv[c_b], xchg_w_bb);

bb_and3(acbbv[c_b], c0bbv[c_b], xchg_b_bb);
bb_and2(acbbv[c_w], xchg_b_bb);

bb_ior3(xchg_w_bb, xchg_b_bb, bb);
while (bb_next(bb, sq))
	{
	bpf.bpf_cp0 = local.rbv[sq];
	bpf.bpf_sq0 = sq;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitiveExists: CS basic pattern generator: exists */
nonstatic
void
CSPrimitiveExists(sptrT sptr)
{
bpfT bpf;
bbT bb;
sqT sq;

bpf = null_bpf;
bpf.bpf_bp = bp_exists;

bb = apmbb;
while (bb_next(bb, sq))
	{
	bpf.bpf_cp0 = local.rbv[sq];
	bpf.bpf_sq0 = sq;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitiveFiftymove: CS basic pattern generator: fiftymove */
nonstatic
void
CSPrimitiveFiftymove(sptrT sptr)
{
bpfT bpf;

if (DrawHalfMoveClock())
	{
	bpf = null_bpf;
	bpf.bpf_bp = bp_fiftymove;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitiveHung: CS basic pattern generator: hung */
nonstatic
void
CSPrimitiveHung(sptrT sptr)
{
bpfT bpf;
bbT bb, hung_w_bb, hung_b_bb;
sqT sq;

bpf = null_bpf;
bpf.bpf_bp = bp_hung;

bb_and3(acbbv[c_b], c0bbv[c_w], hung_w_bb);
bb_mask2(acbbv[c_w], hung_w_bb);

bb_and3(acbbv[c_w], c0bbv[c_b], hung_b_bb);
bb_mask2(acbbv[c_b], hung_b_bb);

bb_ior3(hung_w_bb, hung_b_bb, bb);
while (bb_next(bb, sq))
	{
	bpf.bpf_cp0 = local.rbv[sq];
	bpf.bpf_sq0 = sq;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitiveIndirect: CS basic pattern generator: indirect */
nonstatic
void
CSPrimitiveIndirect(sptrT sptr)
{
bpfT bpf;
cT c0, c1;
sqT sq0, sq1, sq2;
cpT cp0, cp1, cp2;
bbT bb_b, bb_r, bb_q, bb0, bb1, bb2;
dxT dx;
dvT dv;

bpf = null_bpf;
bpf.bpf_bp = bp_indirect;
for (c0 = c_w; c0 <= c_b; c0++)
	{
	c1 = inv_cv[c0];
	bb_b = cpbbv[cv_cp_c_pv[c0][p_b]];
	bb_r = cpbbv[cv_cp_c_pv[c0][p_r]];
	bb_q = cpbbv[cv_cp_c_pv[c0][p_q]];
	bb_ior4(bb_b, bb_r, bb_q, bb0);
	while (bb_next(bb0, sq0))
		{
		bpf.bpf_sq0 = sq0;
		cp0 = local.rbv[sq0];
		bpf.bpf_cp0 = cp0;
		bb_and3(afbbv[sq0], c0bbv[c1], bb1);
		while (bb_next(bb1, sq1))
			{
			bpf.bpf_sq1 = sq1;
			cp1 = local.rbv[sq1];
			bpf.bpf_cp1 = cp1;
			bb2 = *(beyond_raster_base + offset_sqsq(sq0, sq1));
			if (bb_tstand(c0bbv[c1], bb2))
				{
				dx = *(dx_table_base + offset_sqsq(sq0, sq1));
				dv = dvv[dx];
				sq2 = sq1 + dv;
				cp2 = local.rbv[sq2];
				while (cp2 == cp_v0)
					{
					sq2 += dv;
					cp2 = local.rbv[sq2];
					};
				if (cv_c_cpv[cp2] == c1)
					{
					bpf.bpf_sq2 = sq2;
					bpf.bpf_cp2 = cp2;
					CSPatternPost(sptr, bpf);
					};
				};
			};
		};
	};

return;
}

/*--> CSPrimitiveJeopardy: CS basic pattern generator: jeopardy */
nonstatic
void
CSPrimitiveJeopardy(sptrT sptr)
{
bpfT bpf;
cT c0, c1;
sqT sq0, sq1;
cpT cp0, cp1;
bbT bb0, bb1;
cpevT cpev0, cpev1;
siT hung;

cpev0 = cpev_bust;
bpf = null_bpf;
bpf.bpf_bp = bp_jeopardy;
for (c0 = c_w; c0 <= c_b; c0++)
	{
	c1 = inv_cv[c0];
	bb_and3(c0bbv[c0], acbbv[c1], bb0);
	while (bb_next(bb0, sq0))
		{
		cp0 = local.rbv[sq0];
		if (bb_tstsq(acbbv[c0], sq0))
			{
			hung = 0;
			cpev0 = cpvalv[cp0];
			}
		else
			hung = 1;
		bb_and3(atbbv[sq0], c0bbv[c1], bb1);
		while (bb_next(bb1, sq1))
			{
			cp1 = local.rbv[sq1];
			if (!hung)
				cpev1 = cpvalv[cp1];
			if (hung || (cpev0 > cpev1))
				{
				bpf.bpf_cp0 = cp0;
				bpf.bpf_sq0 = sq0;
				bpf.bpf_cp1 = cp1;
				bpf.bpf_sq1 = sq1;
				CSPatternPost(sptr, bpf);
				};
			};
		};
	};

return;
}

/*--> CSPrimitiveMove: CS basic pattern generator: move */
nonstatic
void
CSPrimitiveMove(sptrT sptr)
{
bpfT bpf;
mptrT mptr;
siT i;

if (sptr != NULL)
	{
	bpf = null_bpf;
	bpf.bpf_bp = bp_move;

	/* assume moveset fully expanded */

	mptr = sptr->s_mbase;
	for (i = 0; i < sptr->s_count; i++)
		{
		bpf.bpf_cp0 = mptr->m_frcp;
		bpf.bpf_sq0 = mptr->m_frsq;
		bpf.bpf_cp1 = mptr->m_tocp;
		bpf.bpf_sq1 = mptr->m_tosq;
		bpf.bpf_scmv = mptr->m_scmv;
		CSPatternPost(sptr, bpf);
		mptr++;
		};
	};

return;
}

/*--> CSPrimitiveOutofwood: CS basic pattern generator: outofwood */
nonstatic
void
CSPrimitiveOutofwood(sptrT sptr)
{
bpfT bpf;

if (DrawInsufficientMaterial())
	{
	bpf = null_bpf;
	bpf.bpf_bp = bp_outofwood;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitivePassive: CS basic pattern generator: passive piece */
nonstatic
void
CSPrimitivePassive(sptrT sptr)
{
bpfT bpf;
bbT bb;
sqT sq;

bpf = null_bpf;
bpf.bpf_bp = bp_passive;

bb = c0bbv[pasc];
while (bb_next(bb, sq))
	{
	bpf.bpf_cp0 = local.rbv[sq];
	bpf.bpf_sq0 = sq;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitivePassiveking: CS basic pattern generator: passiveking */
nonstatic
void
CSPrimitivePassiveking(sptrT sptr)
{
bpfT bpf;

bpf = null_bpf;
bpf.bpf_bp = bp_passiveking;
bpf.bpf_cp0 = pasc_k;
bpf.bpf_sq0 = bb_once(cpbbv[bpf.bpf_cp0]);
CSPatternPost(sptr, bpf);

return;
}

/*--> CSPrimitiveProtected: CS basic pattern generator: protected */
nonstatic
void
CSPrimitiveProtected(sptrT sptr)
{
bpfT bpf;
bbT bb, prot_w_bb, prot_b_bb;
sqT sq;

bpf = null_bpf;
bpf.bpf_bp = bp_protected;

bb_and3(c0bbv[c_w], acbbv[c_w], prot_w_bb);
bb_mask2(acbbv[c_b], prot_w_bb);

bb_and3(c0bbv[c_b], acbbv[c_b], prot_b_bb);
bb_mask2(acbbv[c_w], prot_b_bb);

bb_ior3(prot_w_bb, prot_b_bb, bb);

while (bb_next(bb, sq))
	{
	bpf.bpf_cp0 = local.rbv[sq];
	bpf.bpf_sq0 = sq;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitiveRepeated: CS basic pattern generator: repeated */
nonstatic
void
CSPrimitiveRepeated(sptrT sptr)
{
bpfT bpf;

if (DrawHashRepeatTwice())
	{
	bpf = null_bpf;
	bpf.bpf_bp = bp_repeated;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitiveStalemated: CS basic pattern generator: stalemated */
nonstatic
void
CSPrimitiveStalemated(sptrT sptr)
{
bpfT bpf;
sqT sq;
cpT cp;

if (sptr != NULL)
	{
	/* assume moveset fully expanded */

	if (sptr->s_count == 0)
		{
		bpf = null_bpf;
		cp = actc_k;
		sq = bb_once(cpbbv[cp]);
		if (bb_tstnotsq(acbbv[pasc], sq))
			{
			bpf.bpf_bp = bp_stalemated;
			CSPatternPost(sptr, bpf);
			};
		};
	};

return;
}

/*--> CSPrimitiveThirdrepeat: CS basic pattern generator: thirdrepeat */
nonstatic
void
CSPrimitiveThirdrepeat(sptrT sptr)
{
bpfT bpf;

if (DrawHashRepeatThrice())
	{
	bpf = null_bpf;
	bpf.bpf_bp = bp_thirdrepeat;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*--> CSPrimitiveUnconnected: CS basic pattern generator: unconnected */
nonstatic
void
CSPrimitiveUnconnected(sptrT sptr)
{
bpfT bpf;
bbT bb, ucon_w_bb, ucon_b_bb;
sqT sq;

bpf = null_bpf;
bpf.bpf_bp = bp_unconnected;

bb_mask3(acbbv[c_w], c0bbv[c_w], ucon_w_bb);
bb_mask2(acbbv[c_b], ucon_w_bb);

bb_mask3(acbbv[c_b], c0bbv[c_b], ucon_b_bb);
bb_mask2(acbbv[c_w], ucon_b_bb);

bb_ior3(ucon_w_bb, ucon_b_bb, bb);

while (bb_next(bb, sq))
	{
	bpf.bpf_cp0 = local.rbv[sq];
	bpf.bpf_sq0 = sq;
	CSPatternPost(sptr, bpf);
	};

return;
}

/*<<< csprim.c: EOF */
