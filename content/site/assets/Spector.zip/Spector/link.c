/*>>> link.c: external player linkage utilities */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "link.h"
#include "linkmac.h"
#include "linkunix.h"
#include "memutil.h"
#include "print.h"

/**** Locals */

/* link capability */

#define link_capable (os_unix || os_mac)

/*--> LinkGet: get bytes from input channel */
nonstatic
siT
LinkGet(channelT channel, byteptrT bptr, liT length)
{
siT code;

if (!scsv[channel].scs_open || (LinkStat(channel) < length))
	code = -1;
else
	{
#if (os_mac)
	code = LinkMacGet(channel, bptr, length);
#endif
#if (os_unix)
	code = LinkUnixGet(channel, bptr, length);
#endif
	};

return (code);
}

/*--> LinkPut: put bytes from input channel */
nonstatic
siT
LinkPut(channelT channel, byteptrT bptr, liT length)
{
siT code;

if (!scsv[channel].scs_open)
	code = -1;
else
	{
#if (os_mac)
	code = LinkMacPut(channel, bptr, length);
#endif
#if (os_unix)
	code = LinkUnixPut(channel, bptr, length);
#endif
	};

return (code);
}

/*--> LinkStat: return pending input character count */
nonstatic
liT
LinkStat(channelT channel)
{
liT count;

if (!scsv[channel].scs_open)
	count = -1;
else
	{
#if (os_mac)
	count = LinkMacStat(channel);
#endif
#if (os_unix)
	count = LinkUnixStat(channel);
#endif
	};

return (count);
}

/*--> LinkOpen: open a channel */
nonstatic
siT
LinkOpen(channelT channel, ccpT ccp, rscT rsc)
{
int flag;

/* trace */

if (optnv[optn_trel])
	{
	PrTrace("EL");
	PrStrSINL("opening channel ", channel);
	};

if (!link_capable || scsv[channel].scs_open)
	flag = 0;
else
	{
	scsv[channel].scs_open = 1;
	scsv[channel].scs_ccp = ccp;
	scsv[channel].scs_rsc = rsc;
#if (os_mac)
	flag = LinkMacOpen(channel);
#endif
#if (os_unix)
	flag = LinkUnixOpen(channel);
#endif
	};

return (flag);
}

/*--> LinkClose: close a channel */
nonstatic
siT
LinkClose(channelT channel)
{
int flag;

/* trace */

if (optnv[optn_trel])
	{
	PrTrace("EL");
	PrStrSINL("closing channel ", channel);
	};

if (!link_capable || !scsv[channel].scs_open)
	flag = 0;
else
	{
#if (os_mac)
	flag = LinkMacClose(channel);
#endif
#if (os_unix)
	flag = LinkUnixClose(channel);
#endif
	scsv[channel].scs_open = 0;
	scsv[channel].scs_ccp = ccp_nil;
	scsv[channel].scs_rsc = rsc_nil;
	};

return (flag);
}

/*--> LinkInit: one time call initialize linkage subsystem */
nonstatic
void
LinkInit(void)
{
channelT channel;

/* mark channels not in use */

for (channel = 0; channel < channelL; channel++)
	{
	scsv[channel].scs_open = 0;
	scsv[channel].scs_ccp = ccp_nil;
	scsv[channel].scs_rsc = rsc_nil;
	};

/* link initialize */

#if (os_mac)
LinkMacInit();
#endif
#if (os_unix)
LinkUnixInit();
#endif

return;
}

/*--> LinkTerm: one time call terminate linkage subsystem */
nonstatic
void
LinkTerm(void)
{
channelT channel;

/* ensure channels closed */

for (channel = 0; channel < channelL; channel++)
	if (scsv[channel].scs_open)
		LinkClose(channel);

/* specialized termination */

#if (os_mac)
LinkMacTerm();
#endif
#if (os_unix)
LinkUnixTerm();
#endif

return;
}

/*<<< link.c: EOF */
