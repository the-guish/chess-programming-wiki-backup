/*>>> tb.c: tablebase routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bbmacs.h"

#include "tbdefs.h"
#include "tbvars.h"

#include "vpdefs.h"

#include "bb.h"
#include "create.h"
#include "display.h"
#include "exec.h"
#include "file.h"
#include "init.h"
#include "memutil.h"
#include "print.h"
#include "sysutil.h"
#include "tb.h"
#include "tbcache.h"
#include "tbmoves.h"
#include "tbplay.h"

#if (os_mac)
#include <SIOUX.h>
#endif

/**** Locals */

/* paging buffer block length and page slot count */

#define tbpbL BUFSIZ
#define tbpsL ((8 * megaL) / tbpbL)

/* paging slot control */

typedef struct pscS
	{
	cT       psc_color; /* slot user: white/black/vacant */
	siT      psc_dirty; /* slot data needs to be written */
	liT      psc_index; /* page index */
	byteptrT psc_pdptr; /* page data pointer */
	} pscT, *pscptrT;

/* progress report display split count */

#if (disenv_scroll)
#define prdsL 64
#else
#define prdsL 1024
#endif

/* summary control and display  */

#define tbsdL 4

#define tbsd_all_unr  0 /* all posns */
#define tbsd_all_red  1 /* all posns, reduced */
#define tbsd_ncp_unr  2 /* no capt/prom posns */
#define tbsd_ncp_red  3 /* no capt/prom posns, reduced */

#define tbsdcL 16

#define tbsdc_okay_all_unr  0 /* unbroken, all posns */
#define tbsdc_okay_all_red  1 /* unbroken, all posns, reduced */
#define tbsdc_okay_ncp_unr  2 /* unbroken, no capt/prom posns */
#define tbsdc_okay_ncp_red  3 /* unbroken, no capt/prom posns, reduced */
#define tbsdc_mate_all_unr  4 /* mating, all posns */
#define tbsdc_mate_all_red  5 /* mating, all posns, reduced */
#define tbsdc_mate_ncp_unr  6 /* mating, no capt/prom posns */
#define tbsdc_mate_ncp_red  7 /* mating, no capt/prom posns, reduced */
#define tbsdc_lose_all_unr  8 /* losing, all posns */
#define tbsdc_lose_all_red  9 /* losing, all posns, reduced */
#define tbsdc_lose_ncp_unr 10 /* losing, no capt/prom posns */
#define tbsdc_lose_ncp_red 11 /* losing, no capt/prom posns, reduced */
#define tbsdc_draw_all_unr 12 /* drawing, all posns */
#define tbsdc_draw_all_red 13 /* drawing, all posns, reduced */
#define tbsdc_draw_ncp_unr 14 /* drawing, no capt/prom posns */
#define tbsdc_draw_ncp_red 15 /* drawing, no capt/prom posns, reduced */

/* tablebase data file reference vector element type */

typedef struct tbrS
	{
	siT   tbr_flag; /* in use indication */
	tbidT tbr_tbid; /* tablebase identification */
	cT    tbr_c;    /* side to move */
	fptrT tbr_fptr; /* file pointer */
	} tbrT, *tbrptrT;

/* tablebase data file reference vector storage */

#define tbrvL 8
static tbrT tbrv[tbrvL];

/* tbspid_tri index remap */

static tiT rmtriv[sqL] =
	{
	 0,  1,  2,  3, -1, -1, -1, -1,
	-1,  4,  5,  6, -1, -1, -1, -1,
	-1, -1,  7,  8, -1, -1, -1, -1,
	-1, -1, -1,  9, -1, -1, -1, -1,
	-1, -1, -1, -1, -1, -1, -1, -1,
	-1, -1, -1, -1, -1, -1, -1, -1,
	-1, -1, -1, -1, -1, -1, -1, -1,
	-1, -1, -1, -1, -1, -1, -1, -1
	};

/* tbspid_qsf index remap */

static tiT rmqsfv[sqL] =
	{
	 0,  1,  2,  3, -1, -1, -1, -1,
	 4,  5,  6,  7, -1, -1, -1, -1,
	 8,  9, 10, 11, -1, -1, -1, -1,
	12, 13, 14, 15, -1, -1, -1, -1,
	16, 17, 18, 19, -1, -1, -1, -1,
	20, 21, 22, 23, -1, -1, -1, -1,
	24, 25, 26, 27, -1, -1, -1, -1,
	28, 29, 30, 31, -1, -1, -1, -1
	};

/* main diagonal squares */

static tiT maindiagv[sqL] =
	{
	1, 0, 0, 0, 0, 0, 0, 0,
	0, 1, 0, 0, 0, 0, 0, 0,
	0, 0, 1, 0, 0, 0, 0, 0,
	0, 0, 0, 1, 0, 0, 0, 0,
	0, 0, 0, 0, 1, 0, 0, 0,
	0, 0, 0, 0, 0, 1, 0, 0,
	0, 0, 0, 0, 0, 0, 1, 0,
	0, 0, 0, 0, 0, 0, 0, 1
	};

/* tablebase command table */

static charptrT tb_cstrv[tbcL];

/* tablebase scanning pattern limit vector */

static tiT tb_splv[tbspidL];

/* tablebase scanning pattern offset vector */

static tiT tb_spov[tbspidL];

/* tablebase index generation vector */

static sqT tb_igv[tbigvL];

/* tablebase file suffixes */

static charptrT tb_fsptrv[rcL];

/* side to move strings */

static charptrT tb_stmstrv[rcL];

/* tablebase action return values */

static liT tb_actflag;
static liT tb_actresult;

/* tablebase master base pointer */

static tbsptrT tb_baseptr;

/* census vectors for tablebase detection */

static siT tb_cnv[rcL];
static siT tb_pnv[pL];
static siT tb_cpnv[cpL];

/* progress report display */

static time_t prd_start;
static liT prd_limit;
static liT prd_increment;
static liT prd_trigger;
static liT prd_count;

/* paging files (TBGetByte/TBPutByte) */

static fptrT tb_pg_fptrv[rcL];

/* paging slot control vector base */

static pscptrT tb_pscbase;

/*--> TBPRDInit: initialize progress report display */
static
void
TBPRDInit(liT limit, liT split)
{
prd_start = time(NULL);
prd_limit = limit;
prd_increment = prd_limit / split;
prd_trigger = 0;
prd_count = 0;

if (disenv_scroll)
	if (optnv[optn_verb])
		fputc('[', stderr);

di_completion = 0.0;
di_prediction = 0;

DpUpdate(winid_clock);
DpUpdate(winid_search);
DpUpdate(winid_time);

return;
}

/*--> TBPRDTerm: terminate progress report display */
static
void
TBPRDTerm(void)
{
if (disenv_scroll)
	if (optnv[optn_verb])
		{
		fputc(']', stderr);
		fputc('\n', stderr);
		};

di_completion = 0.0;
di_prediction = 0;

DpUpdate(winid_clock);
DpUpdate(winid_search);
DpUpdate(winid_time);

return;
}

/*--> TBPRDUpdate: update progress report display */
static
void
TBPRDUpdate(liT index)
{
liT delta;
liT range;

if (index == prd_trigger)
	{
	if (disenv_scroll)
		if (optnv[optn_verb])
			fputc(('0' + (prd_count % ten)), stderr);

	if (index > 0)
		{
		delta = time(NULL) - prd_start;
		di_completion = index / ((lrT) prd_limit);
		range = delta / di_completion;
		di_prediction = prd_start + range;
		};

	DpUpdate(winid_clock);
	DpUpdate(winid_search);
	DpUpdate(winid_time);

	prd_trigger += prd_increment;
	prd_count++;
	};

return;
}

/*--> TBFormFileName: form a file name */
static
void
TBFormFileName(tbsptrT tbsptr, cT c, charptrT s)
{
sprintf(s, "%s/%s%s", tbdn, tbsptr->tbs_name, tb_fsptrv[c]);

return;
}

/*--> TBFormFileNameTBID: form a file name from tbid */
nonstatic
void
TBFormFileNameTBID(tbidT tbid, cT c, charptrT s)
{
tbsptrT tbsptr;

tbsptr = tb_baseptr + tbid;
sprintf(s, "%s/%s%s", tbdn, tbsptr->tbs_name, tb_fsptrv[c]);

return;
}

/*--> TBRecover: recover piece squares */
static
void
TBRecover(tbsptrT tbsptr, liT index, sqT sqv[tbmctL])
{
siT i;
liT n, m, d;
sqT sq;

i = 0;
n = index;

sq = sq_nil;
while (i < tbsptr->tbs_tmn)
	{
	d = tbsptr->tbs_spanv[i];
	m = n % d;
	n = n / d;
	switch (tbsptr->tbs_spidv[i])
		{
		case tbspid_all:
			sq = m;
			break;

		case tbspid_qsf:
			sq = tb_igv[tb_spov[tbspid_qsf] + m];
			break;

		case tbspid_tri:
			sq = tb_igv[tb_spov[tbspid_tri] + m];
			break;

		default:
			SwitchFault("TBRecover");
			break;
		};
	sqv[i] = sq;
	i++;
	};

return;
}

/*--> TBDetectCaptProm: detect capture/promotion */
static
siT
TBDetectCaptProm(tbsptrT tbsptr, liT index)
{
siT flag;
sqT sqv[tbmctL];
siT i, j;
cT c;

TBRecover(tbsptr, index, sqv);

flag = 0;
i = 0;
while (!flag && (i < (tbsptr->tbs_tmn - 1)))
	{
	j = i + 1;
	while (!flag && (j < tbsptr->tbs_tmn))
		if (sqv[i] == sqv[j])
			flag = 1;
		else
			j++;
	i++;
	};

j = 0;
if (!flag && (tbsptr->tbs_flag & tbf_scap))
	{
	c = c_w;
	while (!flag && (c <= c_b))
		{
		i = 0;
		while (!flag && (i < tbsptr->tbs_mnv[c]))
			{
			switch (tbsptr->tbs_cpv[c][i])
				{
				case cp_wp:
					if (map_rank(sqv[j]) == rank_8)
						flag = 1;
					break;

				case cp_bp:
					if (map_rank(sqv[j]) == rank_1)
						flag = 1;
					break;

				default:
					break;
				};
			i++;
			j++;
			};
		c++;
		};
	};

return (flag);
}

/*--> TBExhibit: exhibit pieces and squares from index */
static
void
TBExhibit(tbsptrT tbsptr, liT index)
{
siT i, wc;
sqT sqv[tbmctL];

TBRecover(tbsptr, index, sqv);

wc = tbsptr->tbs_mnv[c_w];
for (i = 0; i < tbsptr->tbs_tmn; i++)
	{
	if (i != 0)
		PrBlank();

	if (i < wc)
		PrColorPiece(tbsptr->tbs_cpv[c_w][i]);
	else
		PrColorPiece(tbsptr->tbs_cpv[c_b][i - wc]);

	PrSq(sqv[i]);
	};
PrNL();

return;
}

/*--> TBClearTREntry: clear transition reference table entry */
static
void
TBClearTREntry(siT n)
{
tbrv[n].tbr_flag = 0;
tbrv[n].tbr_tbid = tbid_nil;
tbrv[n].tbr_c = c_nil;
tbrv[n].tbr_fptr = NULL;

return;
}

/*--> TBInitTR: initialize transition reference table */
static
void
TBInitTR(void)
{
siT i;

for (i = 0; i < tbrvL; i++)
	TBClearTREntry(i);

return;
}

/*--> TBTermTR: terminate transition reference table */
static
void
TBTermTR(void)
{
siT i;

for (i = 0; i < tbrvL; i++)
	{
	if (tbrv[i].tbr_flag && (tbrv[i].tbr_fptr != NULL))
		CodeFileClose(tbrv[i].tbr_fptr);
	TBClearTREntry(i);
	};

return;
}

/*--> TBFindFreeTR: find free reference table entry */
static
siT
TBFindFreeTR(void)
{
siT i, n;

n = -1;
i = 0;
while ((n == -1) && (i < tbrvL))
	if (!tbrv[i].tbr_flag)
		n = i;
	else
		i++;

return (n);
}

/*--> TBFindMatchTR: find matching reference table entry */
static
siT
TBFindMatchTR(tbidT tbid, cT c)
{
siT i, n;

n = -1;
i = 0;
while ((n == -1) && (i < tbrvL))
	if (tbrv[i].tbr_flag &&
		(tbrv[i].tbr_tbid == tbid) && (tbrv[i].tbr_c == c))
		n = i;
	else
		i++;

return (n);
}

/*--> TBAssignTR: assign reference table entry */
static
void
TBAssignTR(siT n, tbidT tbid, cT c)
{
fptrT fptr;
char tv[tL];

TBClearTREntry(n);
TBFormFileName((tb_baseptr + tbid), c, tv);
fptr = CodeFileOpen(tv, "rb");
if (fptr != NULL)
	{
	tbrv[n].tbr_flag = 1;
	tbrv[n].tbr_tbid = tbid;
	tbrv[n].tbr_c = c;
	tbrv[n].tbr_fptr = fptr;
	};

return;
}

/*--> TBLocateTR: locate/assign reference table entry */
static
siT
TBLocateTR(tbidT tbid, cT c)
{
siT n;

n = TBFindMatchTR(tbid, c);
if (n == -1)
	{
	n = TBFindFreeTR();
	if (n != -1)
		{
		TBAssignTR(n, tbid, c);
		if (!tbrv[n].tbr_flag)
			n = -1;
		};
	};

return (n);
}

/*--> TBFetchTR: fetch reference table entry */
static
bevT
TBFetchTR(tbidT tbid, cT c, liT index)
{
bevT bev;
siT n;
siT code;

n = TBLocateTR(tbid, c);
if (n == -1)
	Diagnose("TBFetchTR: locate fault");

code = fseek(tbrv[n].tbr_fptr, index, SEEK_SET);
if (code != 0)
	Diagnose("TBFetchTR: fseek fault");

bev = bev_unknown;
code = fread(&bev, sizeof(tiT), 1, tbrv[n].tbr_fptr);
if (code != sizeof(tiT))
	Diagnose("TBFetchTR: fread fault");

return (bev);
}

/*--> TBDetect: determine tablebase from census vectors */
static
tbidT
TBDetect(siptrT invertptr)
{
tbidT tbid;
tbidT scid;
tbsptrT tbsptr;
siT match;
cpT cp;
siT done;
siT pn;
sqT wpsq, bpsq;
fileT wpfile, bpfile;
rankT wprank, bprank;
siT delta;

/* set default return values */

*invertptr = 0;
tbid = tbid_nil;

/* set running */

done = 0;

/* check upper limits */

pn = tb_cnv[c_w] + tb_cnv[c_b];
if ((pn > tbmctL) || (tb_cnv[c_w] > tbmcsL) || (tb_cnv[c_b] > tbmcsL))
	done = 1;

/* KPKP ep kickout */

if (!done)
	if ((pn == 4) && (tb_cpnv[cp_wp] == 1) && (tb_cpnv[cp_bp] == 1))
		{
		wpsq = bb_once(cpbbv[cp_wp]);
		bpsq = bb_once(cpbbv[cp_bp]);
		wpfile = map_file(wpsq);
		bpfile = map_file(bpsq);
		if (wpfile != bpfile)
			{
			delta = wpfile - bpfile;
			if (abs(delta) == 1)
				{
				wprank = map_rank(wpsq);
				bprank = map_rank(bpsq);
				switch (wprank)
					{
					case rank_2:
						if (bprank > rank_3)
							done = 1;
						break;

					case rank_3:
						if (bprank == rank_7)
							done = 1;
						break;

					case rank_4:
						if (bprank == rank_7)
							done = 1;
						else
							if (bprank == rank_4)
								if (envn.envn_epsq != sq_nil)
									done = 1;
						break;

					case rank_5:
						if (bprank == rank_7)
							done = 1;
						else
							if (bprank == rank_5)
								if (envn.envn_epsq != sq_nil)
									done = 1;
						break;

					case rank_6:
						/* okay */
						break;

					case rank_7:
						/* okay */
						break;
					};
				};
			};
		};

/* process non-inversion scan match */

if (!done)
	{
	scid = 0;
	tbsptr = tb_baseptr;
	while (!done && (scid < tbidL))
		{
		/* test side counts */

		if ((tbsptr->tbs_mnv[c_w] == tb_cnv[c_w]) &&
			(tbsptr->tbs_mnv[c_b] == tb_cnv[c_b]))
			{
			/* check cp count match */

			match = 1;
			cp = cp_wp;
			while (match && (cp <= cp_bk))
				if (tb_cpnv[cp] == tbsptr->tbs_cpnv[cp])
					cp++;
				else
					match = 0;

			if (match)
				tbid = scid;
			};

		/* next trip */

		if (tbid != tbid_nil)
			done = 1;
		else
			{
			tbsptr++;
			scid++;
			};
		};
	};

/* process inversion scan match */

if (!done)
	{
	scid = 0;
	tbsptr = tb_baseptr;
	while (!done && (scid < tbidL))
		{
		/* test side counts */

		if ((tbsptr->tbs_mnv[c_w] == tb_cnv[c_b]) &&
			(tbsptr->tbs_mnv[c_b] == tb_cnv[c_w]))
			{
			/* check cp count match */

			match = 1;
			cp = cp_wp;
			while (match && (cp <= cp_bk))
				if (tb_cpnv[inv_cpv[cp]] == tbsptr->tbs_cpnv[cp])
					cp++;
				else
					match = 0;

			if (match)
				{
				tbid = scid;
				*invertptr = 1;
				};
			};

		/* next trip */

		if (tbid != tbid_nil)
			done = 1;
		else
			{
			tbsptr++;
			scid++;
			};
		};
	};

return (tbid);
}

/*--> TBClearDetect: clear the detection census vectors */
static
void
TBClearDetect(void)
{
cT c;
pT p;
cpT cp;

for (c = 0; c < rcL; c++)
	tb_cnv[c] = 0;

for (p = 0; p < pL; p++)
	tb_pnv[p] = 0;

for (cp = 0; cp < cpL; cp++)
	tb_cpnv[cp] = 0;

return;
}

/*--> TBDetectLocal: determine tablebase of local board position */
nonstatic
tbidT
TBDetectLocal(siptrT invertptr)
{
tbidT tbid;
cpT cp;
sqT sq;

TBClearDetect();

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	if ((cp = local.rbv[sq]) != cp_v0)
		{
		tb_cnv[cv_c_cpv[cp]]++;
		tb_pnv[cv_p_cpv[cp]]++;
		tb_cpnv[cp]++;
		};
	};

tbid = TBDetect(invertptr);

return (tbid);
}

/*--> TBTestDual: check if position is a dual */
static
siT
TBTestDual(tbsptrT tbsptr, liT index)
{
siT flag;

switch (tbsptr->tbs_tbcsig)
	{
	case tbcsig_a21:
		flag = maindiagv[tb_igv[tb_spov[tbspid_tri] +
			(index / tbsp_all2L)]];
		break;

	case tbcsig_a22:
	case tbcsig_a31:
		flag = maindiagv[tb_igv[tb_spov[tbspid_tri] +
			(index / tbsp_all3L)]];
		break;

	case tbcsig_a32:
	case tbcsig_a41:
		flag = maindiagv[tb_igv[tb_spov[tbspid_tri] +
			(index / tbsp_all4L)]];
		break;

	default:
		flag = 0;
		break;
	};

return (flag);
}

/*--> TBReflectXRef: reflect along X axis (reference) */
static
void
TBReflectXRef(sqptrT sqptr)
{
*sqptr = reflect_x(*sqptr);

return;
}

/*--> TBReflectXRef3: reflect trio along X axis (reference) */
static
void
TBReflectXRef3(sqptrT ptr0, sqptrT ptr1, sqptrT ptr2)
{
*ptr0 ^= 0x38;
*ptr1 ^= 0x38;
*ptr2 ^= 0x38;

return;
}

/*--> TBReflectXRef4: reflect quad along X axis (reference) */
static
void
TBReflectXRef4(sqptrT ptr0, sqptrT ptr1, sqptrT ptr2, sqptrT ptr3)
{
*ptr0 ^= 0x38;
*ptr1 ^= 0x38;
*ptr2 ^= 0x38;
*ptr3 ^= 0x38;

return;
}

/*--> TBReflectXRef5: reflect quint along X axis (reference) */
static
void
TBReflectXRef5(
	sqptrT ptr0, sqptrT ptr1, sqptrT ptr2, sqptrT ptr3, sqptrT ptr4)
{
*ptr0 ^= 0x38;
*ptr1 ^= 0x38;
*ptr2 ^= 0x38;
*ptr3 ^= 0x38;
*ptr4 ^= 0x38;

return;
}

/*--> TBReflectYRef3: reflect trio along Y axis (reference) */
static
void
TBReflectYRef3(sqptrT ptr0, sqptrT ptr1, sqptrT ptr2)
{
*ptr0 ^= 0x07;
*ptr1 ^= 0x07;
*ptr2 ^= 0x07;

return;
}

/*--> TBReflectYRef4: reflect quad along Y axis (reference) */
static
void
TBReflectYRef4(sqptrT ptr0, sqptrT ptr1, sqptrT ptr2, sqptrT ptr3)
{
*ptr0 ^= 0x07;
*ptr1 ^= 0x07;
*ptr2 ^= 0x07;
*ptr3 ^= 0x07;

return;
}

/*--> TBReflectYRef5: reflect quint along Y axis (reference) */
static
void
TBReflectYRef5(
	sqptrT ptr0, sqptrT ptr1, sqptrT ptr2, sqptrT ptr3, sqptrT ptr4)
{
*ptr0 ^= 0x07;
*ptr1 ^= 0x07;
*ptr2 ^= 0x07;
*ptr3 ^= 0x07;
*ptr4 ^= 0x07;

return;
}

/*--> TBReflectXYRef: reflect along XY axis (reference) */
static
void
TBReflectXYRef(sqptrT sqptr)
{
*sqptr = reflect_xy(*sqptr);

return;
}

/*--> TBReflectXYRef3: reflect trio along XY axis (reference) */
static
void
TBReflectXYRef3(sqptrT ptr0, sqptrT ptr1, sqptrT ptr2)
{
*ptr0 = reflect_xy(*ptr0);
*ptr1 = reflect_xy(*ptr1);
*ptr2 = reflect_xy(*ptr2);

return;
}

/*--> TBReflectXYRef4: reflect quad along XY axis (reference) */
static
void
TBReflectXYRef4(sqptrT ptr0, sqptrT ptr1, sqptrT ptr2, sqptrT ptr3)
{
*ptr0 = reflect_xy(*ptr0);
*ptr1 = reflect_xy(*ptr1);
*ptr2 = reflect_xy(*ptr2);
*ptr3 = reflect_xy(*ptr3);

return;
}

/*--> TBReflectXYRef5: reflect quint along XY axis (reference) */
static
void
TBReflectXYRef5(
	sqptrT ptr0, sqptrT ptr1, sqptrT ptr2, sqptrT ptr3, sqptrT ptr4)
{
*ptr0 = reflect_xy(*ptr0);
*ptr1 = reflect_xy(*ptr1);
*ptr2 = reflect_xy(*ptr2);
*ptr3 = reflect_xy(*ptr3);
*ptr4 = reflect_xy(*ptr4);

return;
}

/*--> TBNormRef3A: normalize a trio, mode A */
static
void
TBNormRef3A(sqptrT ptr0, sqptrT ptr1, sqptrT ptr2)
{
if (map_rank(*ptr2) > rank_4)
	TBReflectXRef3(ptr0, ptr1, ptr2);

if (map_file(*ptr2) > file_d)
	TBReflectYRef3(ptr0, ptr1, ptr2);

if (map_rank(*ptr2) > map_file(*ptr2))
	TBReflectXYRef3(ptr0, ptr1, ptr2);

return;
}

/*--> TBNormRef3B: normalize a trio, mode B */
static
void
TBNormRef3B(sqptrT ptr0, sqptrT ptr1, sqptrT ptr2)
{
if (map_file(*ptr1) > file_d)
	TBReflectYRef3(ptr0, ptr1, ptr2);

return;
}

/*--> TBNormRef4A: normalize a quad, mode A */
static
void
TBNormRef4A(sqptrT ptr0, sqptrT ptr1, sqptrT ptr2, sqptrT ptr3)
{
if (map_rank(*ptr3) > rank_4)
	TBReflectXRef4(ptr0, ptr1, ptr2, ptr3);

if (map_file(*ptr3) > file_d)
	TBReflectYRef4(ptr0, ptr1, ptr2, ptr3);

if (map_rank(*ptr3) > map_file(*ptr3))
	TBReflectXYRef4(ptr0, ptr1, ptr2, ptr3);

return;
}

/*--> TBNormRef4B: normalize a quad, mode B */
static
void
TBNormRef4B(sqptrT ptr0, sqptrT ptr1, sqptrT ptr2, sqptrT ptr3)
{
if (map_file(*ptr3) > file_d)
	TBReflectYRef4(ptr0, ptr1, ptr2, ptr3);

return;
}

/*--> TBNormRef4C: normalize a quad, mode C */
static
void
TBNormRef4C(sqptrT ptr0, sqptrT ptr1, sqptrT ptr2, sqptrT ptr3)
{
if (map_file(*ptr2) > file_d)
	TBReflectYRef4(ptr0, ptr1, ptr2, ptr3);

return;
}

/*--> TBNormRef5A: normalize a quint, mode A */
static
void
TBNormRef5A(
	sqptrT ptr0, sqptrT ptr1, sqptrT ptr2, sqptrT ptr3, sqptrT ptr4)
{
if (map_rank(*ptr4) > rank_4)
	TBReflectXRef5(ptr0, ptr1, ptr2, ptr3, ptr4);

if (map_file(*ptr4) > file_d)
	TBReflectYRef5(ptr0, ptr1, ptr2, ptr3, ptr4);

if (map_rank(*ptr4) > map_file(*ptr4))
	TBReflectXYRef5(ptr0, ptr1, ptr2, ptr3, ptr4);

return;
}

/*--> TBIndex3A: generate an index for a trio, mode A */
static
liT
TBIndex3A(sqT sq0, sqT sq1, sqT sq2)
{
liT index;

index = ((liT) sq0) +
	(((liT) sq1) * tbsp_allL) +
	(((liT) rmtriv[sq2]) * tbsp_all2L);

return (index);
}

/*--> TBIndex3B: generate an index for a trio, mode B */
static
liT
TBIndex3B(sqT sq0, sqT sq1, sqT sq2)
{
liT index;

index = ((liT) sq0) +
	(((liT) rmqsfv[sq1]) * tbsp_allL) +
	(((liT) sq2) * tbsp_qsfL * tbsp_allL);

return (index);
}

/*--> TBIndex4A: generate an index for a quad, mode A */
static
liT
TBIndex4A(sqT sq0, sqT sq1, sqT sq2, sqT sq3)
{
liT index;

index = ((liT) sq0) +
	(((liT) sq1) * tbsp_allL) +
	(((liT) sq2) * tbsp_all2L) +
	(((liT) rmtriv[sq3]) * tbsp_all3L);

return (index);
}

/*--> TBIndex4B: generate an index for a quad, mode B */
static
liT
TBIndex4B(sqT sq0, sqT sq1, sqT sq2, sqT sq3)
{
liT index;

index = ((liT) sq0) +
	(((liT) sq1) * tbsp_allL) +
	(((liT) sq2) * tbsp_all2L) +
	(((liT) rmqsfv[sq3]) * tbsp_all3L);

return (index);
}

/*--> TBIndex4C: generate an index for a quad, mode C */
static
liT
TBIndex4C(sqT sq0, sqT sq1, sqT sq2, sqT sq3)
{
liT index;

index = ((liT) sq0) +
	(((liT) sq1) * tbsp_allL) +
	(((liT) rmqsfv[sq2]) * tbsp_all2L) +
	(((liT) sq3) * tbsp_qsfL * tbsp_all2L);

return (index);
}

/*--> TBIndex5A: generate an index for a quint, mode A */
static
liT
TBIndex5A(sqT sq0, sqT sq1, sqT sq2, sqT sq3, sqT sq4)
{
liT index;

index = ((liT) sq0) +
	(((liT) sq1) * tbsp_allL) +
	(((liT) sq2) * tbsp_all2L) +
	(((liT) sq3) * tbsp_all3L) +
	(((liT) rmtriv[sq4]) * tbsp_all4L);

return (index);
}

/*--> TBSynIndex3A: synthesize index trio, mode A */
static
liT
TBSynIndex3A(sqT sq0, sqT sq1, sqT sq2)
{
liT index;
sqT tsq0, tsq1, tsq2;

tsq0 = sq0;
tsq1 = sq1;
tsq2 = sq2;

TBNormRef3A(&tsq0, &tsq1, &tsq2);
index = TBIndex3A(tsq0, tsq1, tsq2);

return (index);
}

/*--> TBSynIndex3B: synthesize index trio, mode B */
static
liT
TBSynIndex3B(sqT sq0, sqT sq1, sqT sq2)
{
liT index;
sqT tsq0, tsq1, tsq2;

tsq0 = sq0;
tsq1 = sq1;
tsq2 = sq2;

TBNormRef3B(&tsq0, &tsq1, &tsq2);
index = TBIndex3B(tsq0, tsq1, tsq2);

return (index);
}

/*--> TBSynIndex4A: synthesize index quad, mode A */
static
liT
TBSynIndex4A(sqT sq0, sqT sq1, sqT sq2, sqT sq3)
{
liT index;
sqT tsq0, tsq1, tsq2, tsq3;

tsq0 = sq0;
tsq1 = sq1;
tsq2 = sq2;
tsq3 = sq3;

TBNormRef4A(&tsq0, &tsq1, &tsq2, &tsq3);
index = TBIndex4A(tsq0, tsq1, tsq2, tsq3);

return (index);
}

/*--> TBSynIndex4B: synthesize index quad, mode B */
static
liT
TBSynIndex4B(sqT sq0, sqT sq1, sqT sq2, sqT sq3)
{
liT index;
sqT tsq0, tsq1, tsq2, tsq3;

tsq0 = sq0;
tsq1 = sq1;
tsq2 = sq2;
tsq3 = sq3;

TBNormRef4B(&tsq0, &tsq1, &tsq2, &tsq3);
index = TBIndex4B(tsq0, tsq1, tsq2, tsq3);

return (index);
}

/*--> TBSynIndex4C: synthesize index quad, mode C */
static
liT
TBSynIndex4C(sqT sq0, sqT sq1, sqT sq2, sqT sq3)
{
liT index;
sqT tsq0, tsq1, tsq2, tsq3;

tsq0 = sq0;
tsq1 = sq1;
tsq2 = sq2;
tsq3 = sq3;

TBNormRef4C(&tsq0, &tsq1, &tsq2, &tsq3);
index = TBIndex4C(tsq0, tsq1, tsq2, tsq3);

return (index);
}

/*--> TBSynIndex5A: synthesize index quint, mode A */
static
liT
TBSynIndex5A(sqT sq0, sqT sq1, sqT sq2, sqT sq3, sqT sq4)
{
liT index;
sqT tsq0, tsq1, tsq2, tsq3, tsq4;

tsq0 = sq0;
tsq1 = sq1;
tsq2 = sq2;
tsq3 = sq3;
tsq4 = sq4;

TBNormRef5A(&tsq0, &tsq1, &tsq2, &tsq3, &tsq4);
index = TBIndex5A(tsq0, tsq1, tsq2, tsq3, tsq4);

return (index);
}

/*--> TBScoreLocal: return a score for the local board position */
nonstatic
cpevT
TBScoreLocal(tbidT tbid, siT invert)
{
cpevT cpev;
cT probe_c;
liT index;
cpT cp;
siT sqn, i;
sqT sqv[tbmctL];
tbsptrT tbsptr;

cpev = cpev_draw;
index = 0;
tbsptr = tb_baseptr + tbid;

/* select squares according to color inversion */

sqn = 0;
if (!invert)
	{
	/* select squares of white pieces */

	for (cp = cp_wk; cp >= cp_wp; cp--)
		for (i = 0; i < tbsptr->tbs_cpnv[cp]; i++)
			sqv[sqn++] = BitBoardNthRef(i, &cpbbv[cp]);

	/* select squares of black pieces */

	for (cp = cp_bk; cp >= cp_bp; cp--)
		for (i = 0; i < tbsptr->tbs_cpnv[cp]; i++)
			sqv[sqn++] = BitBoardNthRef(i, &cpbbv[cp]);
	}
else
	{
	/* select squares of black pieces */

	for (cp = cp_wk; cp >= cp_wp; cp--)
		for (i = 0; i < tbsptr->tbs_cpnv[cp]; i++)
			sqv[sqn++] = BitBoardNthRef(i, &cpbbv[inv_cpv[cp]]);

	/* select squares of white pieces */

	for (cp = cp_bk; cp >= cp_bp; cp--)
		for (i = 0; i < tbsptr->tbs_cpnv[cp]; i++)
			sqv[sqn++] = BitBoardNthRef(i, &cpbbv[inv_cpv[cp]]);
	};

/* en passant target indexing kludge */
#if (0)
siT flag;
if (envn.envn_epsq != sq_nil)
	{
	flag = 0;
	i = 0;
	if (actc == c_w)
		{
		while (!flag)
			if (sqv[i] == (envn.envn_epsq + dv_3))
				{
				sqv[i] = (envn.envn_epsq + (dv_1 * 2));
				flag = 1;
				}
			else
				i++;
		}
	else
		{
		while (!flag)
			if (sqv[i] == (envn.envn_epsq + dv_1))
				{
				sqv[i] = (envn.envn_epsq + (dv_3 * 2));
				flag = 1;
				}
			else
				i++;
		};
	};
#endif
/* pawn inversion processing */

if (invert)
	if (tbsptr->tbs_flag & tbf_scap)
		for (i = 0; i < sqn; i++)
			TBReflectXRef(&sqv[i]);

/* calculate index */

switch (tbsptr->tbs_tbcsig)
	{
	case tbcsig_a21:
		index = TBSynIndex3A(sqv[0], sqv[1], sqv[2]);
		break;

	case tbcsig_a22:
	case tbcsig_a31:
		index = TBSynIndex4A(sqv[0], sqv[1], sqv[2], sqv[3]);
		break;

	case tbcsig_a32:
	case tbcsig_a41:
		index = TBSynIndex5A(sqv[0], sqv[1], sqv[2], sqv[3], sqv[4]);
		break;

	case tbcsig_b21:
		index = TBSynIndex3B(sqv[0], sqv[1], sqv[2]);
		break;

	case tbcsig_b22:
	case tbcsig_d22:
		index = TBSynIndex4B(sqv[0], sqv[1], sqv[2], sqv[3]);
		break;

	case tbcsig_c31:
		index = TBSynIndex4C(sqv[0], sqv[1], sqv[2], sqv[3]);
		break;

	default:
		SwitchFault("TBScoreLocal");
		break;
	};

/* calculate probe color */

if (!invert)
	probe_c = actc;
else
	probe_c = pasc;

/* attempt file probe */

cpev = TBCacheReadCPEV(tbid, probe_c, index);

return (cpev);
}

/*--> TBSampleGame: play a sample game from the tablebases */
static
void
TBSampleGame(tbsptrT tbsptr, cT c, liT index)
{
siT i;
siT wc;
sqT sqv[tbmctL];

/* set up general items */

InitNewGame();
ClearBoard();
envn.envn_cast = 0;
envn.envn_epsq = sq_nil;
envn.envn_hmvc = 0;
CreateSetUp();

/* set up position from index */

TBRecover(tbsptr, index, sqv);

wc = tbsptr->tbs_mnv[c_w];
for (i = 0; i < tbsptr->tbs_tmn; i++)
	{
	if (i < wc)
		InitSq(tbsptr->tbs_cpv[c_w][i], sqv[i]);
	else
		InitSq(tbsptr->tbs_cpv[c_b][i - wc], sqv[i]);
	};

actc = c;
pasc = inv_cv[c];

CreateSetUp();

/* play */

TBPlay();

/* reset */

InitNewGame();

return;
}

/*--> TBSummaryAux: helper routine for TBSummary */
static
void
TBSummaryAux(cT c, liT sdv[tbsdL], charptrT bevstr)
{
if (sdv[tbsd_all_unr] > 0)
	{
	sprintf(stv, "  %s %s:  %10ld  %10ld  %10ld  %10ld",
		tb_stmstrv[c], bevstr,
		sdv[tbsd_all_unr],
		sdv[tbsd_all_red],
		sdv[tbsd_ncp_unr],
		sdv[tbsd_ncp_red]);

	PrSTVNL();
	};

return;
}

/*--> TBSummary: produce a summary on the standard output */
static
void
TBSummary(tbsptrT tbsptr, cT c)
{
liT index, count, factor, code;
fptrT tb_wfv[rcL];
bevT bev;
char tv[tL];
siT selector;
siT i;
sqT sq;
siT ncpflag;
siT dist_mate, dist_lose;
siT max_mate, max_lose;
liT max_mate_index, max_lose_index;
siT draw_flag;
liT draw_index;
lrT sum_mate_dist, sum_lose_dist;
liT sumv[tbsdL][pageL];
liT totalv[tbsdL];
liT totalcv[tbsdcL];
liT repv[tbsdL];

sprintf(stv, "##### Tablebase Summary Report: %s %s",
	tbsptr->tbs_name, tb_stmstrv[c]);
PrSTVNL();
PrNL();

TBFormFileName(tbsptr, c, tv);
tb_wfv[c] = CodeFileOpen(tv, "rb");

if (tb_wfv[c] == NULL)
	PrLine("*** tablebase unavailable ***");
else
	{
	SetBiggerBuffer(tb_wfv[c]);

	for (i = 0; i < tbsdL; i++)
		{
		totalv[i] = 0;
		for (selector = 0; selector < pageL; selector++)
			sumv[i][selector] = 0;
		};

	for (i = 0; i < tbsdcL; i++)
		totalcv[i] = 0;

	max_mate = max_lose = -1;
	draw_flag = 0;
	max_mate_index = max_lose_index = draw_index = -1;

	count = tbsptr->tbs_size;
	TBPRDInit(count, prdsL);
	for (index = 0; index < count; index++)
		{
		TBPRDUpdate(index);
		code = fread(&bev, sizeof(tiT), 1, tb_wfv[c]);
		if (code != sizeof(tiT))
			Diagnose("TBSummary: fread fault");

		selector = bev + (pageL / 2);
		factor = 1;
		ncpflag = !TBDetectCaptProm(tbsptr, index);
		switch (tbsptr->tbs_tbcsig)
			{
			case tbcsig_a21:
				sq = tb_igv[tb_spov[tbspid_tri] + (index / tbsp_all2L)];
				if (maindiagv[sq])
					factor = 4;
				else
					factor = 8;
				break;

			case tbcsig_a22:
			case tbcsig_a31:
				sq = tb_igv[tb_spov[tbspid_tri] + (index / tbsp_all3L)];
				if (maindiagv[sq])
					factor = 4;
				else
					factor = 8;
				break;

			case tbcsig_a32:
			case tbcsig_a41:
				sq = tb_igv[tb_spov[tbspid_tri] + (index / tbsp_all4L)];
				if (maindiagv[sq])
					factor = 4;
				else
					factor = 8;
				break;

			case tbcsig_b21:
			case tbcsig_b22:
			case tbcsig_c31:
			case tbcsig_d22:
				factor = 2;
				break;

			default:
				SwitchFault("TBSummary");
				break;
			};

		sumv[tbsd_all_red][selector]++;
		sumv[tbsd_all_unr][selector] += factor;
		if (ncpflag)
			{
			sumv[tbsd_ncp_red][selector]++;
			sumv[tbsd_ncp_unr][selector] += factor;
			};

		if (bev != bev_broken)
			{
			totalcv[tbsdc_okay_all_red]++;
			totalcv[tbsdc_okay_all_unr] += factor;
			if (ncpflag)
				{
				totalcv[tbsdc_okay_ncp_red]++;
				totalcv[tbsdc_okay_ncp_unr] += factor;
				};
			};

		if (tbe_mating(bev))
			{
			totalcv[tbsdc_mate_all_red]++;
			totalcv[tbsdc_mate_all_unr] += factor;
			if (ncpflag)
				{
				totalcv[tbsdc_mate_ncp_red]++;
				totalcv[tbsdc_mate_ncp_unr] += factor;
				dist_mate = (bev_mi1 - bev) + 1;
				if ((max_mate == -1) || (max_mate < dist_mate))
					{
					max_mate = dist_mate;
					max_mate_index = index;
					};
				};
			}
		else
			if (tbe_losing(bev))
				{
				totalcv[tbsdc_lose_all_red]++;
				totalcv[tbsdc_lose_all_unr] += factor;
				if (ncpflag)
					{
					totalcv[tbsdc_lose_ncp_red]++;
					totalcv[tbsdc_lose_ncp_unr] += factor;
					dist_lose = bev - bev_li0;
					if ((max_lose == -1) || (max_lose < dist_lose))
						{
						max_lose = dist_lose;
						max_lose_index = index;
						};
					};
				}
			else
				if (bev == bev_draw)
					{
					totalcv[tbsdc_draw_all_red]++;
					totalcv[tbsdc_draw_all_unr] += factor;
					if (ncpflag)
						{
						totalcv[tbsdc_draw_ncp_red]++;
						totalcv[tbsdc_draw_ncp_unr] += factor;
						if (!draw_flag)
							{
							draw_flag = 1;
							draw_index = index;
							};
						};
					};
		};
	TBPRDTerm();

	CodeFileClose(tb_wfv[c]);
	tb_wfv[c] = NULL;

	for (i = 0; i < tbsdL; i++)
		for (selector = 0; selector < pageL; selector++)
			totalv[i] += sumv[i][selector];

	sum_mate_dist = sum_lose_dist = 0.0;
	for (selector = 0; selector < pageL; selector++)
		{
		bev = selector - (pageL / 2);
		if (tbe_mating(bev))
			sum_mate_dist += ((lrT) ((bev_mi1 - bev) + 1)) *
				sumv[tbsd_ncp_unr][selector];
		else
			if (tbe_losing(bev))
				sum_lose_dist += ((lrT) (bev - bev_li0)) *
					sumv[tbsd_ncp_unr][selector];
		};

	PrStr("  Evaluation      ");
	PrStr("  All         All reduce  NCP         NCP reduce");
	PrNL();
	PrStr("  ----------------");
	PrStr("  ----------  ----------  ----------  ----------");
	PrNL();

	for (selector = 0; selector < pageL; selector++)
		{
		for (i = 0; i < tbsdL; i++)
			repv[i] = sumv[i][selector];

		i = selector - (pageL / 2);
		switch (i)
			{
			case bev_broken:
				TBSummaryAux(c, repv, "broken     ");
				break;

			case bev_draw:
				TBSummaryAux(c, repv, "draw       ");
				break;

			case bev_reserved:
				TBSummaryAux(c, repv, "reserved   ");
				break;

			case bev_unknown:
				TBSummaryAux(c, repv, "unknown    ");
				break;

			default:
				if (tbe_mating(i))
					sprintf(tv, "mate in %3hd", ((bev_mi1 - i) + 1));
				else
					sprintf(tv, "lost in %3hd", (i - bev_li0));
				TBSummaryAux(c, repv, tv);
				break;
			};
		};
	PrNL();

	PrLine("Totals:");
	PrNL();

	sprintf(stv, "%10ld   %s all positions",
		totalv[tbsd_all_unr], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s all positions, reduced",
		totalv[tbsd_all_red], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s no captures or promotions",
		totalv[tbsd_ncp_unr], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s no captures or promotions, reduced",
		totalv[tbsd_ncp_red], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s unbroken, all positions",
		totalcv[tbsdc_okay_all_unr], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s unbroken, all positions, reduced",
		totalcv[tbsdc_okay_all_red], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s unbroken, no captures or promotions",
		totalcv[tbsdc_okay_ncp_unr], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s unbroken, no captures or promotions, reduced",
		totalcv[tbsdc_okay_ncp_red], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s mating, all positions",
		totalcv[tbsdc_mate_all_unr], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s mating, all positions, reduced",
		totalcv[tbsdc_mate_all_red], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s mating, no captures or promotions",
		totalcv[tbsdc_mate_ncp_unr], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s mating, no captures or promotions, reduced",
		totalcv[tbsdc_mate_ncp_red], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s losing, all positions",
		totalcv[tbsdc_lose_all_unr], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s losing, all positions, reduced",
		totalcv[tbsdc_lose_all_red], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s losing, no captures or promotions",
		totalcv[tbsdc_lose_ncp_unr], tb_stmstrv[c]);
	PrSTVNL();

	sprintf(stv, "%10ld   %s losing, no captures or promotions, reduced",
		totalcv[tbsdc_lose_ncp_red], tb_stmstrv[c]);
	PrSTVNL();
	PrNL();

	sprintf(stv, "Probabilties %s %s (unbroken, unreduced, no capt/prom):",
		 tbsptr->tbs_name, tb_stmstrv[c]);
	PrSTVNL();
	PrNL();

	sprintf(stv, "  P(%s, %s, mate): %16.14f",
		tbsptr->tbs_name, tb_stmstrv[c],
		(((lrT) totalcv[tbsdc_mate_ncp_unr]) /
		((lrT) totalcv[tbsdc_okay_ncp_unr])));
	PrSTVNL();

	sprintf(stv, "  P(%s, %s, lose): %16.14f",
		tbsptr->tbs_name, tb_stmstrv[c],
		(((lrT) totalcv[tbsdc_lose_ncp_unr]) /
		((lrT) totalcv[tbsdc_okay_ncp_unr])));
	PrSTVNL();

	sprintf(stv, "  P(%s, %s, draw): %16.14f",
		tbsptr->tbs_name, tb_stmstrv[c],
		(((lrT) totalcv[tbsdc_draw_ncp_unr]) /
		((lrT) totalcv[tbsdc_okay_ncp_unr])));
	PrSTVNL();
	PrNL();

	sprintf(stv, "  Average %s %s NCP distance to mate: ",
		tbsptr->tbs_name, tb_stmstrv[c]);
	PrSTV();
	if (max_mate == -1)
		PrLine("no NCP mates exist");
	else
		{
		sprintf(stv, "%.14f",
			(sum_mate_dist / totalcv[tbsdc_mate_ncp_unr]));
		PrSTVNL();
		};

	sprintf(stv, "  Average %s %s NCP distance to lose: ",
		tbsptr->tbs_name, tb_stmstrv[c]);
	PrSTV();
	if (max_lose == -1)
		PrLine("no NCP losses exist");
	else
		{
		sprintf(stv, "%.14f",
			(sum_lose_dist / totalcv[tbsdc_lose_ncp_unr]));
		PrSTVNL();
		};
	PrNL();

	PrLine("Example positions and optimax move limits:");
	PrNL();

	if (!draw_flag)
		{
		sprintf(stv, "  There are no %s %s NCP draws",
			tbsptr->tbs_name, tb_stmstrv[c]);
		PrSTVNL();
		}
	else
		{
		sprintf(stv, "  Example %s %s draw: ",
			tbsptr->tbs_name, tb_stmstrv[c]);
		PrSTV();
		TBExhibit(tbsptr, draw_index);
		};
	PrNL();

	sprintf(stv, "  Maximum %s %s NCP distance to mate: ",
		tbsptr->tbs_name, tb_stmstrv[c]);
	PrSTV();
	if (max_mate == -1)
		PrLine("no examples exist");
	else
		{
		PrSI(max_mate);
		PrNL();
		sprintf(stv, "  Example %s %s mate in %hd: ",
			tbsptr->tbs_name, tb_stmstrv[c], max_mate);
		PrSTV();
		TBExhibit(tbsptr, max_mate_index);
		};
	PrNL();

	sprintf(stv, "  Maximum %s %s NCP distance to lose: ",
		tbsptr->tbs_name, tb_stmstrv[c]);
	PrSTV();
	if (max_lose == -1)
		PrLine("no examples exist");
	else
		{
		PrSI(max_lose);
		PrNL();
		sprintf(stv, "  Example %s %s lose in %hd: ",
			tbsptr->tbs_name, tb_stmstrv[c], max_lose);
		PrSTV();
		TBExhibit(tbsptr, max_lose_index);
		};
	PrNL();

	/* sample games */

	sprintf(stv, "Example optimax %s %s (mate) game: ",
		tbsptr->tbs_name, tb_stmstrv[c]);
	PrSTV();
	if (max_mate == -1)
		{
		PrLine("no examples exist");
		PrNL();
		}
	else
		{
		TBExhibit(tbsptr, max_mate_index);
		PrNL();
		TBSampleGame(tbsptr, c, max_mate_index);
		};

	sprintf(stv, "Example optimax %s %s (lose) game: ",
		tbsptr->tbs_name, tb_stmstrv[c]);
	PrSTV();
	if (max_lose == -1)
		{
		PrLine("no examples exist");
		PrNL();
		}
	else
		{
		TBExhibit(tbsptr, max_lose_index);
		PrNL();
		TBSampleGame(tbsptr, c, max_lose_index);
		};
	};

return;
}

/*--> TBClrCSPIV: clear current scanning indexing */
static
void
TBClrCSPIV(void)
{
cT c;
siT i;

for (c = c_w; c <= c_b; c++)
	for (i = 0; i < tb_mcpnv[c]; i++)
		{
		tb_cspiv[c][i] = 0;
		tb_csqv[c][i] = tb_igv[tb_spov[tb_mspv[c][i]]];
		};

return;
}

/*--> TBIncCSPIV: increment current scanning pattern index vector */
static
void
TBIncCSPIV(void)
{
siT flag;
cT c;
siT i;

c = c_w;
i = 0;
flag = 1;
while (flag && (c <= c_b) && (i < tb_mcpnv[c]))
	{
	tb_cspiv[c][i]++;
	if (tb_cspiv[c][i] < tb_splv[tb_mspv[c][i]])
		{
		tb_csqv[c][i] = tb_igv[tb_spov[tb_mspv[c][i]] + tb_cspiv[c][i]];
		flag = 0;
		}
	else
		{
		tb_cspiv[c][i] = 0;
		tb_csqv[c][i] = tb_igv[tb_spov[tb_mspv[c][i]]];
		i++;
		if (i == tb_mcpnv[c])
			{
			i = 0;
			c++;
			};
		};
	};

return;
}

/*--> TBInitTB: initialize a TB table record */
static
void
TBInitTB(tbidT tbid, tbcsigT csig, charptrT s, charptrT name)
{
tbsptrT tbsptr;
cT c;
pT p;
cpT cp;
siT i;
charptrT ptr;

tbsptr = tb_baseptr + tbid;

tbsptr->tbs_tbid = tbid;
tbsptr->tbs_flag = 0;
tbsptr->tbs_name = name;
tbsptr->tbs_size = 1;
tbsptr->tbs_tbcsig = csig;
tbsptr->tbs_tmn = strlen(name);

for (i = 0; i < tbmctL; i++)
	{
	tbsptr->tbs_spidv[i] = tbspid_nil;
	tbsptr->tbs_spanv[i] = 0;
	};

for (c = c_w; c <= c_b; c++)
	{
	tbsptr->tbs_mnv[c] = 0;
	for (i = 0; i < tbmcsL; i++)
		tbsptr->tbs_cpv[c][i] = cp_v0;
	};

for (cp = 0; cp < cpL; cp++)
	tbsptr->tbs_cpnv[cp] = 0;

ptr = s;
i = 0;
while (*ptr != ascii_nul)
	{
	switch (*ptr)
		{
		case 'a':
			tbsptr->tbs_spidv[i] = tbspid_all;
			tbsptr->tbs_spanv[i] = tbsp_allL;
			tbsptr->tbs_size *= tbsp_allL;
			break;

		case 'q':
			tbsptr->tbs_spidv[i] = tbspid_qsf;
			tbsptr->tbs_spanv[i] = tbsp_qsfL;
			tbsptr->tbs_size *= tbsp_qsfL;
			break;

		case 't':
			tbsptr->tbs_spidv[i] = tbspid_tri;
			tbsptr->tbs_spanv[i] = tbsp_triL;
			tbsptr->tbs_size *= tbsp_triL;
			break;

		default:
			SwitchFault("TBInitTB");
			break;
		};
	ptr++;
	i++;
	};

ptr = name;
c = c_b;
while (*ptr != ascii_nul)
	{
	p = p_nil;
	switch (*ptr)
		{
		case 'P':
			p = p_p;
			break;

		case 'N':
			p = p_n;
			break;

		case 'B':
			p = p_b;
			break;

		case 'R':
			p = p_r;
			break;

		case 'Q':
			p = p_q;
			break;

		case 'K':
			p = p_k;
			break;

		default:
			SwitchFault("TBInitTB");
			break;
		};

	if (p == p_k)
		c = inv_cv[c];

	if (p == p_p)
		{
		tbsptr->tbs_flag |= tbf_scap;
		if (c == c_w)
			tbsptr->tbs_flag |= tbf_scwp;
		else
			tbsptr->tbs_flag |= tbf_scbp;
		if ((tbsptr->tbs_flag & tbf_scwp) && (tbsptr->tbs_flag & tbf_scbp))
			tbsptr->tbs_flag |= tbf_scpp;
		};

	cp = cv_cp_c_pv[c][p];
	tbsptr->tbs_cpnv[cp]++;
	tbsptr->tbs_cpv[c][tbsptr->tbs_mnv[c]++] = cp;

	ptr++;
	};

return;
}

/*--> TBGenIndex: generate index */
nonstatic
liT
TBGenIndex(tbsptrT tbsptr)
{
liT index;

index = -1;

switch (tbsptr->tbs_tbcsig)
	{
	case tbcsig_a21:
		index = TBSynIndex3A(
			tb_mgpv[c_w][0],
			tb_mgpv[c_w][1],
			tb_mgpv[c_b][0]);
		break;

	case tbcsig_a22:
		index = TBSynIndex4A(
			tb_mgpv[c_w][0],
			tb_mgpv[c_w][1],
			tb_mgpv[c_b][0],
			tb_mgpv[c_b][1]);
		break;

	case tbcsig_a31:
		index = TBSynIndex4A(
			tb_mgpv[c_w][0],
			tb_mgpv[c_w][1],
			tb_mgpv[c_w][2],
			tb_mgpv[c_b][0]);
		break;

	case tbcsig_a32:
		index = TBSynIndex5A(
			tb_mgpv[c_w][0],
			tb_mgpv[c_w][1],
			tb_mgpv[c_w][2],
			tb_mgpv[c_b][0],
			tb_mgpv[c_b][1]);
		break;

	case tbcsig_a41:
		index = TBSynIndex5A(
			tb_mgpv[c_w][0],
			tb_mgpv[c_w][1],
			tb_mgpv[c_w][2],
			tb_mgpv[c_w][3],
			tb_mgpv[c_b][0]);
		break;

	case tbcsig_b21:
		index = TBSynIndex3B(
			tb_mgpv[c_w][0],
			tb_mgpv[c_w][1],
			tb_mgpv[c_b][0]);
		break;

	case tbcsig_b22:
	case tbcsig_d22:
		index = TBSynIndex4B(
			tb_mgpv[c_w][0],
			tb_mgpv[c_w][1],
			tb_mgpv[c_b][0],
			tb_mgpv[c_b][1]);
		break;

	case tbcsig_c31:
		index = TBSynIndex4C(
			tb_mgpv[c_w][0],
			tb_mgpv[c_w][1],
			tb_mgpv[c_w][2],
			tb_mgpv[c_b][0]);
		break;

	default:
		SwitchFault("TBGenIndex");
		break;
	};

return (index);
}

/*--> TBGenAltIndex: generate alternate index */
static
liT
TBGenAltIndex(tbsptrT tbsptr)
{
liT index;
sqT sq0, sq1, sq2, sq3, sq4;

index = -1;

switch (tbsptr->tbs_tbcsig)
	{
	case tbcsig_a21:
		sq0 = tb_mgpv[c_w][0];
		sq1 = tb_mgpv[c_w][1];
		sq2 = tb_mgpv[c_b][0];

		TBNormRef3A(&sq0, &sq1, &sq2);
		if (maindiagv[sq2])
			{
			TBReflectXYRef(&sq0);
			TBReflectXYRef(&sq1);
			};
		index = TBIndex3A(sq0, sq1, sq2);
		break;

	case tbcsig_a22:
		sq0 = tb_mgpv[c_w][0];
		sq1 = tb_mgpv[c_w][1];
		sq2 = tb_mgpv[c_b][0];
		sq3 = tb_mgpv[c_b][1];

		TBNormRef4A(&sq0, &sq1, &sq2, &sq3);
		if (maindiagv[sq3])
			TBReflectXYRef3(&sq0, &sq1, &sq2);
		index = TBIndex4A(sq0, sq1, sq2, sq3);
		break;

	case tbcsig_a31:
		sq0 = tb_mgpv[c_w][0];
		sq1 = tb_mgpv[c_w][1];
		sq2 = tb_mgpv[c_w][2];
		sq3 = tb_mgpv[c_b][0];

		TBNormRef4A(&sq0, &sq1, &sq2, &sq3);
		if (maindiagv[sq3])
			TBReflectXYRef3(&sq0, &sq1, &sq2);
		index = TBIndex4A(sq0, sq1, sq2, sq3);
		break;

	case tbcsig_a32:
		sq0 = tb_mgpv[c_w][0];
		sq1 = tb_mgpv[c_w][1];
		sq2 = tb_mgpv[c_w][2];
		sq3 = tb_mgpv[c_b][0];
		sq4 = tb_mgpv[c_b][1];

		TBNormRef5A(&sq0, &sq1, &sq2, &sq3, &sq4);
		if (maindiagv[sq4])
			TBReflectXYRef4(&sq0, &sq1, &sq2, &sq3);
		index = TBIndex5A(sq0, sq1, sq2, sq3, sq4);
		break;

	case tbcsig_a41:
		sq0 = tb_mgpv[c_w][0];
		sq1 = tb_mgpv[c_w][1];
		sq2 = tb_mgpv[c_w][2];
		sq3 = tb_mgpv[c_w][3];
		sq4 = tb_mgpv[c_b][0];

		TBNormRef5A(&sq0, &sq1, &sq2, &sq3, &sq4);
		if (maindiagv[sq4])
			TBReflectXYRef4(&sq0, &sq1, &sq2, &sq3);
		index = TBIndex5A(sq0, sq1, sq2, sq3, sq4);
		break;

	case tbcsig_b21:
		index = TBSynIndex3B(
			tb_mgpv[c_w][0],
			tb_mgpv[c_w][1],
			tb_mgpv[c_b][0]);
		break;

	case tbcsig_b22:
	case tbcsig_d22:
		index = TBSynIndex4B(
			tb_mgpv[c_w][0],
			tb_mgpv[c_w][1],
			tb_mgpv[c_b][0],
			tb_mgpv[c_b][1]);
		break;

	case tbcsig_c31:
		index = TBSynIndex4C(
			tb_mgpv[c_w][0],
			tb_mgpv[c_w][1],
			tb_mgpv[c_w][2],
			tb_mgpv[c_b][0]);
		break;

	default:
		SwitchFault("TBGenAltIndex");
		break;
	};

return (index);
}

/*--> TBSetUpFromCSQV: set up the board from tb_csqv values */
static
void
TBSetUpFromCSQV(cT active)
{
cT c;
siT index, limit;

tb_actc = active;
tb_pasc = inv_cv[active];

for (c = c_w; c <= c_b; c++)
	{
	limit = tb_mcpnv[c];
	for (index = 0; index < limit; index++)
		TBSetSquare(tb_mcpv[c][index], tb_csqv[c][index]);
	};

tb_capt_cp = cp_v0;
tb_capt_sq = sq_nil;
tb_capt_index = -1;

return;
}

/*--> TBSetUpFromCSQVPair: set up the board from tb_csqv/pair values */
static
void
TBSetUpFromCSQVPair(cT active, sqT sq)
{
cT c;
siT index, limit;

tb_actc = active;
tb_pasc = inv_cv[active];

for (c = c_w; c <= c_b; c++)
	{
	limit = tb_mcpnv[c];
	for (index = 0; index < limit; index++)
		{
		if ((tb_csqv[c][index] == sq) && (c == active))
			{
			tb_capt_cp = tb_mcpv[c][index];
			tb_capt_sq = tb_csqv[c][index];
			tb_capt_index = index;
			};
		TBSetSquare(tb_mcpv[c][index], tb_csqv[c][index]);
		};
	};

return;
}

/*--> TBPromSq: locate promotion square */
static
sqT
TBPromSq(cT c)
{
sqT sq;
siT i;

sq = sq_nil;
i = 1;
while ((sq == sq_nil) && (i < tb_mcpnv[c]))
	if ((cv_p_cpv[tb_mcpv[c][i]] == p_p) &&
		(map_rank(tb_csqv[c][i]) == promrankv[c]))
		sq = tb_csqv[c][i];
	else
		i++;

return (sq);
}

/*--> TBGetPage: get a page */
static
void
TBGetPage(cT c, liT slot, liT page)
{
pscptrT pscptr;

pscptr = tb_pscbase + slot;

if (fseek(tb_pg_fptrv[c], (page * tbpbL), SEEK_SET) != 0)
	Diagnose("TBGetPage: fseek fault");

if (fread(pscptr->psc_pdptr, sizeof(byteT), tbpbL,
	tb_pg_fptrv[c]) != tbpbL)
	Diagnose("TBGetPage: fread fault");

pscptr->psc_color = c;
pscptr->psc_dirty = 0;
pscptr->psc_index = page;

return;
}

/*--> TBPutPage: put a page */
static
void
TBPutPage(liT slot)
{
pscptrT pscptr;
cT c;

pscptr = tb_pscbase + slot;
c = pscptr->psc_color;

if (c != c_v)
	{
	if (fseek(tb_pg_fptrv[c], (pscptr->psc_index * tbpbL),
		SEEK_SET) != 0)
		Diagnose("TBPutPage: fseek fault");

	if (fwrite(pscptr->psc_pdptr, sizeof(byteT), tbpbL,
		tb_pg_fptrv[c]) != tbpbL)
		Diagnose("TBPutPage: fwrite fault");
	};
pscptr->psc_dirty = 0;

return;
}

/*--> TBGetByte: get a byte to a file from the given location */
static
siT
TBGetByte(cT c, liT index)
{
siT value;
liT page;
liT slot;
pscptrT pscptr;

page = index / tbpbL;
slot = page % tbpsL;
pscptr = tb_pscbase + slot;

if ((pscptr->psc_color != c) || (pscptr->psc_index != page))
	{
	if (pscptr->psc_dirty)
		TBPutPage(slot);
	TBGetPage(c, slot, page);
	};

value = *(pscptr->psc_pdptr + (index - (page * tbpbL)));

if (value >= (pageL / 2))
	value -= pageL;

return (value);
}

/*--> TBPutByte: put a byte to a file at the given location */
static
void
TBPutByte(cT c, liT index, byteT byte)
{
liT page;
liT slot;
pscptrT pscptr;

page = index / tbpbL;
slot = page % tbpsL;
pscptr = tb_pscbase + slot;

if ((pscptr->psc_color != c) || (pscptr->psc_index != page))
	{
	if (pscptr->psc_dirty)
		TBPutPage(slot);
	TBGetPage(c, slot, page);
	};

*(pscptr->psc_pdptr + (index - (page * tbpbL))) = byte;

pscptr->psc_dirty = 1;

return;
}

/*--> TBInitPaging: initialize paging */
static
void
TBInitPaging(charptrT wfn, charptrT bfn, charptrT mode)
{
cT c;
liT slot;
liT i;
charptrT fnv[rcL];
pscptrT pscptr;

fnv[c_w] = wfn;
fnv[c_b] = bfn;

pscptr = tb_pscbase = (pscptrT) MemoryGrab(tbpsL * sizeof(pscT));

for (slot = 0; slot < tbpsL; slot++)
	{
	pscptr->psc_color = c_v;
	pscptr->psc_dirty = 0;
	pscptr->psc_index = 0;
	pscptr->psc_pdptr = (byteptrT) MemoryGrab(tbpbL);
	for (i = 0; i < tbpbL; i++)
		*(pscptr->psc_pdptr + i) = 0;
	pscptr++;
	};

for (c = c_w; c <= c_b; c++)
	{
	tb_pg_fptrv[c] = CodeFileOpen(fnv[c], mode);
	if (tb_pg_fptrv[c] == NULL)
		Diagnose("TBInitPaging: open fault");
	};

return;
}

/*--> TBTermPaging: terminate paging */
static
void
TBTermPaging(void)
{
cT c;
liT slot;
pscptrT pscptr;

pscptr = tb_pscbase;
for (slot = 0; slot < tbpsL; slot++)
	{
	if ((pscptr->psc_color != c_v) && pscptr->psc_dirty)
		TBPutPage(slot);
	MemoryFree(pscptr->psc_pdptr);
	pscptr++;
	};
MemoryFree(tb_pscbase);

for (c = c_w; c <= c_b; c++)
	CodeFileClose(tb_pg_fptrv[c]);

return;
}

/*--> TBMake: build tablebase pair */
static
void
TBMake(tbsptrT tbsptr)
{
charptrT namestr;
fptrT fptr;
liT index, count, altdex0, altdex1, altdex2;
cT c, invc;
tbidT tbid;
siT delta_rank, delta_file;
sqT pairsq, promsq;
siT m0index, m0count, m1index, m1count;
siT mateflag, maxp, level, nextlevel;
siT hwm_mv[rcL], hwm_lv[rcL];
bevT b0bev, b1bev, b2bev, b3bev;
tmptrT tmptr, tmptr1;
bevT basebev, beatbev, lossbev;
sqT sq0, sq1, sq2;
siT pawnflag, bumpflag;
siT sbp_broken, sbp_done, sbp_pi;
cT sbp_c;
sqT sbp_sq;
cpT sbp_cp;
cpT sbp_cpv[rcL][sqL];
siT sbp_ppcv[rcL];
char fncv[rcL][tL];
stampT stamp;

/* assign tablebase index for transition pass use */

tbid = tbsptr->tbs_tbid;

/* assign tablebase name string for progress reporting */

namestr = tbsptr->tbs_name;

if (optnv[optn_verb])
	{
	TimeStamp(stamp);
	sprintf(stv, "TBMake: %s %s: start", stamp, namestr);
	PrSTVNL();
	};
DpUpdate(winid_time);

/* set up the pawns-present flag */

if (tbsptr->tbs_flag & tbf_scap)
	pawnflag = 1;
else
	pawnflag = 0;

/* initialize local move generation and file table */

TBInitMG();
TBInitTR();

/* set up count and high water marks */

count = tbsptr->tbs_size;

for (c = c_w; c <= c_b; c++)
	hwm_mv[c] = hwm_lv[c] = -1;

/* form file name pair */

for (c = c_w; c <= c_b; c++)
	TBFormFileName(tbsptr, c, fncv[c]);

/* create initial file pair */

for (c = c_w; c <= c_b; c++)
	{
	if (optnv[optn_verb])
		{
		TimeStamp(stamp);
		sprintf(stv, "TBMake: %s %s: initialize file %s",
			stamp, namestr, fncv[c]);
		PrSTVNL();
		};
	DpUpdate(winid_time);

	fptr = CodeFileOpen(fncv[c], "wb");
	if (fptr == NULL)
		Diagnose("TBMake: can't create file");

	SetBigBuffer(fptr);

	TBPRDInit(count, prdsL);
	for (index = 0; index < count; index++)
		{
		TBPRDUpdate(index);
		fputc(bev_unknown, fptr);
		};
	TBPRDTerm();

	CodeFileClose(fptr);
	};

/* activate paging subsystem */

if (optnv[optn_verb])
	{
	TimeStamp(stamp);
	sprintf(stv, "TBMake: %s %s: activating paging",
		stamp, namestr);
	PrSTVNL();
	};
DpUpdate(winid_time);

TBInitPaging(fncv[c_w], fncv[c_b], "r+b");

/* determine simple broken positions */

for (c = c_w; c <= c_b; c++)
	{
	if (optnv[optn_verb])
		{
		TimeStamp(stamp);
		sprintf(stv,
			"TBMake: %s %s: determine %s simple broken positions",
			stamp, namestr, tb_stmstrv[c]);
		PrSTVNL();
		};
	DpUpdate(winid_time);

	invc = inv_cv[c];

	TBClrCSPIV();
	TBPRDInit(count, prdsL);
	for (index = 0; index < count; index++)
		{
		TBPRDUpdate(index);

		/* set up for scan */

		sbp_broken = 0;
		sbp_done = 0;

		/* test for kings on same or adjacent squares */

		delta_rank =
			map_rank(tb_csqv[c_w][0]) - map_rank(tb_csqv[c_b][0]);
		if (abs(delta_rank) < 2)
			{
			delta_file =
				map_file(tb_csqv[c_w][0]) - map_file(tb_csqv[c_b][0]);
			if (abs(delta_file) < 2)
				{
				sbp_broken = 1;
				sbp_done = 1;
				};
			};

		/* handle piece placement scan */

		if (!sbp_done)
			{
			/* clear the setup vector and promoted pawn counts */

			for (sbp_c = c_w; sbp_c <= c_b; sbp_c++)
				{
				sbp_ppcv[sbp_c] = 0;
				for (sbp_sq = sq_a1; sbp_sq <= sq_h8; sbp_sq++)
					sbp_cpv[sbp_c][sbp_sq] = cp_v0;
				};

			/* loop through pieces */

			sbp_c = c_w;
			while (!sbp_done && (sbp_c <= c_b))
				{
				sbp_pi = 0;
				while (!sbp_done && (sbp_pi < tb_mcpnv[sbp_c]))
					{
					/* fetch piece and square */

					sbp_cp = tb_mcpv[sbp_c][sbp_pi];
					sbp_sq = tb_csqv[sbp_c][sbp_pi];

					/* remap square according to piece type */

					/* extra checking according to piece type */

					switch (sbp_cp)
						{
						case cp_wp:
							/* check for bad rank placement */

							if ((map_rank(sbp_sq) == rank_1) ||
								((map_rank(sbp_sq) == rank_8) && (c == c_w)))
								{
								sbp_broken = 1;
								sbp_done = 1;
								}
							else
								{
								/* check for multiple passive promotions */

								if ((invc == c_w) &&
									(map_rank(sbp_sq) == rank_8))
									{
									sbp_ppcv[c_w]++;
									if (sbp_ppcv[c_w] > 1)
										{
										sbp_broken = 1;
										sbp_done = 1;
										};
									};
								};
							break;

						case cp_bp:
							/* check for bad rank placement */

							if ((map_rank(sbp_sq) == rank_8) ||
								((map_rank(sbp_sq) == rank_1) && (c == c_b)))
								{
								sbp_broken = 1;
								sbp_done = 1;
								}
							else
								{
								/* check for multiple passive promotions */

								if ((invc == c_b) &&
									(map_rank(sbp_sq) == rank_1))
									{
									sbp_ppcv[c_b]++;
									if (sbp_ppcv[c_b] > 1)
										{
										sbp_broken = 1;
										sbp_done = 1;
										};
									};
								};
							break;

						default:
							break;
						};

					/* check for double occupancy by same color */

					if (!sbp_done)
						if (sbp_cpv[sbp_c][sbp_sq] != cp_v0)
							{
							sbp_broken = 1;
							sbp_done = 1;
							};

					/* place piece */

					if (!sbp_done)
						sbp_cpv[sbp_c][sbp_sq] = sbp_cp;

					/* check for capture of active king */

					if (!sbp_done)
						if (cv_p_cpv[sbp_cpv[c][sbp_sq]] == p_k)
							if (sbp_cpv[invc][sbp_sq] != cp_v0)
							{
							sbp_broken = 1;
							sbp_done = 1;
							};

					/* next piece */

					sbp_pi++;
					};

				/* next color */

				sbp_c++;
				};
			};

		/* assign */

		if (sbp_broken)
			TBPutByte(c, index, bev_broken);

		/* next position */

		TBIncCSPIV();
		};
	TBPRDTerm();
	};

/* determine transition scores */

for (c = c_w; c <= c_b; c++)
	{
	invc = inv_cv[c];
	if (optnv[optn_verb])
		{
		TimeStamp(stamp);
		sprintf(stv, "TBMake: %s %s: determine %s transition scores",
			stamp, namestr, tb_stmstrv[c]);
		PrSTVNL();
		};
	DpUpdate(winid_time);

	TBClrCSPIV();
	TBPRDInit(count, prdsL);
	for (index = 0; index < count; index++)
		{
		TBPRDUpdate(index);
		if (TBGetByte(c, index) == bev_unknown)
			{
			/* set unknown evaluation */

			basebev = bev_unknown;

			/* perform occupancy analysis */

			TBOcSetUp();
			maxp = TBOcMax();

			/* assign pair square */

			if (maxp == 2)
				pairsq = TBOcPairSq();
			else
				pairsq = sq_nil;

			/* check for promotions */

			if (pawnflag)
				promsq = TBPromSq(invc);
			else
				promsq = sq_nil;

			/* handle promotion capture conflict */

			if ((promsq != sq_nil) && (pairsq != sq_nil) &&
				(promsq != pairsq))
				basebev = bev_broken;
			else
				{
				/* handle position setup */

				if (pairsq == sq_nil)
					TBSetUpFromCSQV(c);
				else
					{
					TBOcSetPair(pairsq);
					TBSetUpFromCSQVPair(c, pairsq);
					};

				/* PKIC test */

				if (TBPassiveKIC())
					basebev = bev_broken;
				};

			/* process according to tablebase (refined as needed) */

			if ((basebev == bev_unknown) &&
				((pairsq != sq_nil) || (promsq != sq_nil)))
				switch (tbid)
					{
					case tbid_kbbk:
					case tbid_kbkb:
					case tbid_kbkn:
					case tbid_kbnk:
					case tbid_knkn:
					case tbid_knnk:
					case tbid_kqk:
					case tbid_krk:
						basebev = bev_draw;
						break;

					case tbid_kbbkn:
						if (c == c_w)
							{
							if (pairsq == tb_csqv[c_w][1])
								{
								altdex0 = TBSynIndex4A(
									tb_csqv[c_w][0],
									tb_csqv[c_w][2],
									tb_csqv[c_b][0],
									tb_csqv[c_b][1]);
								basebev =
									TBFetchTR(tbid_kbkn, c_w, altdex0);
								}
							else
								{
								altdex0 = TBSynIndex4A(
									tb_csqv[c_w][0],
									tb_csqv[c_w][1],
									tb_csqv[c_b][0],
									tb_csqv[c_b][1]);
								basebev =
									TBFetchTR(tbid_kbkn, c_w, altdex0);
								};
							}
						else
							{
							altdex0 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_w][2],
								tb_csqv[c_b][0]);
							basebev =
								TBFetchTR(tbid_kbbk, c_b, altdex0);
							};
						break;

					case tbid_kbkp:
						if (pairsq == sq_nil)
							{
							/* promotion only */

							altdex0 = TBSynIndex4A(
								tb_csqv[c_b][0],
								tb_csqv[c_b][1],
								tb_csqv[c_w][0],
								tb_csqv[c_w][1]);

							altdex1 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0],
								tb_csqv[c_b][1]);

							b0bev = TBFetchTR(tbid_kbkb, c_b, altdex0);
							b1bev = TBFetchTR(tbid_kbkn, c_w, altdex1);
							b2bev = TBFetchTR(tbid_kqkb, c_b, altdex0);
							b3bev = TBFetchTR(tbid_krkb, c_b, altdex0);

							basebev = min(b0bev, b1bev);
							if (basebev > b2bev)
								basebev = b2bev;
							if (basebev > b3bev)
								basebev = b3bev;
							}
						else
							{
							/* capture, possible promotion */

							if (c == c_w)
								{
								altdex0 = TBSynIndex3B(
									reflect_x(tb_csqv[c_b][0]),
									reflect_x(tb_csqv[c_b][1]),
									reflect_x(tb_csqv[c_w][0]));
								basebev =
									TBFetchTR(tbid_kpk, c_b, altdex0);
								}
							else
								basebev = bev_draw;
							};
						break;

					case tbid_kbnkn:
						if (c == c_w)
							{
							if (pairsq == tb_csqv[c_w][1])
								{
								altdex0 = TBSynIndex4A(
									tb_csqv[c_w][0],
									tb_csqv[c_w][2],
									tb_csqv[c_b][0],
									tb_csqv[c_b][1]);
								basebev =
									TBFetchTR(tbid_knkn, c_w, altdex0);
								}
							else
								{
								altdex0 = TBSynIndex4A(
									tb_csqv[c_w][0],
									tb_csqv[c_w][1],
									tb_csqv[c_b][0],
									tb_csqv[c_b][1]);
								basebev =
									TBFetchTR(tbid_kbkn, c_w, altdex0);
								};
							}
						else
							{
							altdex0 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_w][2],
								tb_csqv[c_b][0]);
							basebev =
								TBFetchTR(tbid_kbnk, c_b, altdex0);
							};
						break;

					case tbid_kbpk:
						if (pairsq == sq_nil)
							{
							altdex0 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_w][2],
								tb_csqv[c_b][0]);

							altdex1 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][2],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0]);

							b0bev = TBFetchTR(tbid_kbnk, c_b, altdex0);
							b1bev = TBFetchTR(tbid_kbbk, c_b, altdex0);
							b2bev = TBFetchTR(tbid_kqbk, c_b, altdex1);
							b3bev = TBFetchTR(tbid_krbk, c_b, altdex1);

							basebev = min(b0bev, b1bev);
							if (basebev > b2bev)
								basebev = b2bev;
							if (basebev > b3bev)
								basebev = b3bev;
							}
						else
							if (pairsq == tb_csqv[c_w][1])
								{
								altdex0 = TBSynIndex3B(
									tb_csqv[c_w][0],
									tb_csqv[c_w][2],
									tb_csqv[c_b][0]);
								basebev = TBFetchTR(tbid_kpk, c_w, altdex0);
								}
							else
								basebev = bev_draw;
						break;

					case tbid_knkp:
						if (pairsq == sq_nil)
							{
							/* promotion only */

							altdex0 = TBSynIndex4A(
								tb_csqv[c_b][0],
								tb_csqv[c_b][1],
								tb_csqv[c_w][0],
								tb_csqv[c_w][1]);

							b0bev = TBFetchTR(tbid_kbkn, c_b, altdex0);
							b1bev = TBFetchTR(tbid_knkn, c_b, altdex0);
							b2bev = TBFetchTR(tbid_kqkn, c_b, altdex0);
							b3bev = TBFetchTR(tbid_krkn, c_b, altdex0);

							basebev = min(b0bev, b1bev);
							if (basebev > b2bev)
								basebev = b2bev;
							if (basebev > b3bev)
								basebev = b3bev;
							}
						else
							{
							/* capture, possible promotion */

							if (c == c_w)
								{
								altdex0 = TBSynIndex3B(
									reflect_x(tb_csqv[c_b][0]),
									reflect_x(tb_csqv[c_b][1]),
									reflect_x(tb_csqv[c_w][0]));
								basebev =
									TBFetchTR(tbid_kpk, c_b, altdex0);
								}
							else
								basebev = bev_draw;
							};
						break;

					case tbid_knpk:
						if (pairsq == sq_nil)
							{
							altdex0 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][2],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0]);

							b0bev = TBFetchTR(tbid_kbnk, c_b, altdex0);
							b1bev = TBFetchTR(tbid_knnk, c_b, altdex0);
							b2bev = TBFetchTR(tbid_kqnk, c_b, altdex0);
							b3bev = TBFetchTR(tbid_krnk, c_b, altdex0);

							basebev = min(b0bev, b1bev);
							if (basebev > b2bev)
								basebev = b2bev;
							if (basebev > b3bev)
								basebev = b3bev;
							}
						else
							if (pairsq == tb_csqv[c_w][1])
								{
								altdex0 = TBSynIndex3B(
									tb_csqv[c_w][0],
									tb_csqv[c_w][2],
									tb_csqv[c_b][0]);
								basebev = TBFetchTR(tbid_kpk, c_w, altdex0);
								}
							else
								basebev = bev_draw;
						break;

					case tbid_kpk:
						if (c == c_w)
							basebev = bev_draw;
						else
							{
							/* determine subgraph index */

							altdex0 = TBSynIndex3A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0]);

							b0bev = TBFetchTR(tbid_kqk, c_b, altdex0);
							b1bev = TBFetchTR(tbid_krk, c_b, altdex0);
							basebev = min(b0bev, b1bev);
							}
						break;

					case tbid_kpkp:
						if (c == c_w)
							{
							if (pairsq == sq_nil)
								{
								altdex0 = TBSynIndex4B(
									reflect_x(tb_csqv[c_b][0]),
									reflect_x(tb_csqv[c_b][1]),
									reflect_x(tb_csqv[c_w][0]),
									reflect_x(tb_csqv[c_w][1]));

								b0bev = TBFetchTR(tbid_knkp, c_b, altdex0);
								b1bev = TBFetchTR(tbid_kbkp, c_b, altdex0);
								b2bev = TBFetchTR(tbid_krkp, c_b, altdex0);
								b3bev = TBFetchTR(tbid_kqkp, c_b, altdex0);

								basebev = min(b0bev, b1bev);
								if (basebev > b2bev)
									basebev = b2bev;
								if (basebev > b3bev)
									basebev = b3bev;
								}
							else
								{
								altdex0 = TBSynIndex3B(
									reflect_x(tb_csqv[c_b][0]),
									reflect_x(tb_csqv[c_b][1]),
									reflect_x(tb_csqv[c_w][0]));
								basebev = TBFetchTR(tbid_kpk, c_b, altdex0);
								};
							}
						else
							{
							if (pairsq == sq_nil)
								{
								altdex0 = TBSynIndex4B(
									tb_csqv[c_w][0],
									tb_csqv[c_w][1],
									tb_csqv[c_b][0],
									tb_csqv[c_b][1]);

								b0bev = TBFetchTR(tbid_knkp, c_b, altdex0);
								b1bev = TBFetchTR(tbid_kbkp, c_b, altdex0);
								b2bev = TBFetchTR(tbid_krkp, c_b, altdex0);
								b3bev = TBFetchTR(tbid_kqkp, c_b, altdex0);

								basebev = min(b0bev, b1bev);
								if (basebev > b2bev)
									basebev = b2bev;
								if (basebev > b3bev)
									basebev = b3bev;
								}
							else
								{
								altdex0 = TBSynIndex3B(
									tb_csqv[c_w][0],
									tb_csqv[c_w][1],
									tb_csqv[c_b][0]);
								basebev = TBFetchTR(tbid_kpk, c_b, altdex0);
								};
							};
						break;

					case tbid_kppk:
						if (pairsq == sq_nil)
							{
							if (promsq == tb_csqv[c_w][1])
								{
								altdex0 = TBSynIndex4C(
									tb_csqv[c_w][0],
									tb_csqv[c_w][1],
									tb_csqv[c_w][2],
									tb_csqv[c_b][0]);
								}
							else
								{
								altdex0 = TBSynIndex4C(
									tb_csqv[c_w][0],
									tb_csqv[c_w][2],
									tb_csqv[c_w][1],
									tb_csqv[c_b][0]);
								};

							b0bev = TBFetchTR(tbid_knpk, c_b, altdex0);
							b1bev = TBFetchTR(tbid_kbpk, c_b, altdex0);
							b2bev = TBFetchTR(tbid_krpk, c_b, altdex0);
							b3bev = TBFetchTR(tbid_kqpk, c_b, altdex0);

							basebev = min(b0bev, b1bev);
							if (basebev > b2bev)
								basebev = b2bev;
							if (basebev > b3bev)
								basebev = b3bev;
							}
						else
							{
							if (pairsq == tb_csqv[c_w][1])
								{
								altdex0 = TBSynIndex3B(
									tb_csqv[c_w][0],
									tb_csqv[c_w][2],
									tb_csqv[c_b][0]);
								}
							else
								{
								altdex0 = TBSynIndex3B(
									tb_csqv[c_w][0],
									tb_csqv[c_w][1],
									tb_csqv[c_b][0]);
								};
							basebev = TBFetchTR(tbid_kpk, c_w, altdex0);
							};
						break;

					case tbid_kqbk:
					case tbid_kqnk:
						if (pairsq == tb_csqv[c_w][1])
							basebev = bev_draw;
						else
							{
							altdex0 = TBSynIndex3A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0]);
							basebev = TBFetchTR(tbid_kqk, c_w, altdex0);
							};
						break;

					case tbid_kqkb:
					case tbid_kqkn:
						if (c == c_w)
							basebev = bev_draw;
						else
							{
							altdex0 = TBSynIndex3A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0]);
							basebev = TBFetchTR(tbid_kqk, c_b, altdex0);
							};
						break;

					case tbid_kqkp:
						if (pairsq == sq_nil)
							{
							/* promotion only */

							altdex1 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0],
								tb_csqv[c_b][1]);

							b0bev = TBFetchTR(tbid_kqkb, c_w, altdex1);
							b1bev = TBFetchTR(tbid_kqkn, c_w, altdex1);
							b2bev = TBFetchTR(tbid_kqkq, c_w, altdex1);
							b3bev = TBFetchTR(tbid_kqkr, c_w, altdex1);

							basebev = min(b0bev, b1bev);
							if (basebev > b2bev)
								basebev = b2bev;
							if (basebev > b3bev)
								basebev = b3bev;
							}
						else
							{
							/* capture, possible promotion */

							if (c == c_w)
								{
								altdex0 = TBSynIndex3B(
									reflect_x(tb_csqv[c_b][0]),
									reflect_x(tb_csqv[c_b][1]),
									reflect_x(tb_csqv[c_w][0]));
								basebev =
									TBFetchTR(tbid_kpk, c_b, altdex0);
								}
							else
								{
								altdex0 = TBSynIndex3A(
									tb_csqv[c_w][0],
									tb_csqv[c_w][1],
									tb_csqv[c_b][0]);
								basebev =
									TBFetchTR(tbid_kqk, c_b, altdex0);
								};
							};
						break;

					case tbid_kqkq:
						if (c == c_w)
							altdex0 = TBSynIndex3A(
								tb_csqv[c_b][0],
								tb_csqv[c_b][1],
								tb_csqv[c_w][0]);
						else
							altdex0 = TBSynIndex3A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0]);
						basebev = TBFetchTR(tbid_kqk, c_b, altdex0);
						break;

					case tbid_kqkr:
						if (c == c_w)
							{
							altdex0 = TBSynIndex3A(
								tb_csqv[c_b][0],
								tb_csqv[c_b][1],
								tb_csqv[c_w][0]);
							basebev = TBFetchTR(tbid_krk, c_b, altdex0);
							}
						else
							{
							altdex0 = TBSynIndex3A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0]);
							basebev = TBFetchTR(tbid_kqk, c_b, altdex0);
							};
						break;

					case tbid_kqpk:
						if (pairsq == sq_nil)
							{
							altdex0 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_w][2],
								tb_csqv[c_b][0]);

							b0bev = TBFetchTR(tbid_kqnk, c_b, altdex0);
							b1bev = TBFetchTR(tbid_kqbk, c_b, altdex0);
							b2bev = TBFetchTR(tbid_kqrk, c_b, altdex0);
							b3bev = TBFetchTR(tbid_kqqk, c_b, altdex0);

							basebev = min(b0bev, b1bev);
							if (basebev > b2bev)
								basebev = b2bev;
							if (basebev > b3bev)
								basebev = b3bev;
							}
						else
							if (pairsq == tb_csqv[c_w][1])
								{
								altdex0 = TBSynIndex3B(
									tb_csqv[c_w][0],
									tb_csqv[c_w][2],
									tb_csqv[c_b][0]);
								basebev = TBFetchTR(tbid_kpk, c_w, altdex0);
								}
							else
								{
								altdex0 = TBSynIndex3A(
									tb_csqv[c_w][0],
									tb_csqv[c_w][1],
									tb_csqv[c_b][0]);
								basebev = TBFetchTR(tbid_kqk, c_w, altdex0);
								};
						break;

					case tbid_kqqk:
						sq0 = tb_csqv[c_w][0];
						if (pairsq != tb_csqv[c_w][1])
							sq1 = tb_csqv[c_w][1];
						else
							sq1 = tb_csqv[c_w][2];
						sq2 = tb_csqv[c_b][0];
						altdex0 = TBSynIndex3A(sq0, sq1, sq2);
						basebev = TBFetchTR(tbid_kqk, c_w, altdex0);
						break;

					case tbid_kqrk:
						sq0 = tb_csqv[c_w][0];
						sq2 = tb_csqv[c_b][0];
						if (pairsq != tb_csqv[c_w][1])
							{
							sq1 = tb_csqv[c_w][1];
							altdex0 = TBSynIndex3A(sq0, sq1, sq2);
							basebev = TBFetchTR(tbid_kqk, c_w, altdex0);
							}
						else
							{
							sq1 = tb_csqv[c_w][2];
							altdex0 = TBSynIndex3A(sq0, sq1, sq2);
							basebev = TBFetchTR(tbid_krk, c_w, altdex0);
							};
						break;

					case tbid_krbk:
					case tbid_krnk:
						if (pairsq == tb_csqv[c_w][1])
							basebev = bev_draw;
						else
							{
							altdex0 = TBSynIndex3A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0]);
							basebev = TBFetchTR(tbid_krk, c_w, altdex0);
							};
						break;

					case tbid_krbkr:
						if (c == c_w)
							if (pairsq == tb_csqv[c_w][1])
								{
								altdex0 = TBSynIndex4A(
									tb_csqv[c_b][0],
									tb_csqv[c_b][1],
									tb_csqv[c_w][0],
									tb_csqv[c_w][2]);
								basebev = TBFetchTR(tbid_krkb, c_b, altdex0);
								}
							else
								{
								altdex0 = TBSynIndex4A(
									tb_csqv[c_w][0],
									tb_csqv[c_w][1],
									tb_csqv[c_b][0],
									tb_csqv[c_b][1]);
								basebev = TBFetchTR(tbid_krkr, c_w, altdex0);
								}
						else
							{
							altdex0 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_w][2],
								tb_csqv[c_b][0]);
							basebev = TBFetchTR(tbid_krbk, c_b, altdex0);
							};
						break;

					case tbid_krkb:
					case tbid_krkn:
						if (c == c_w)
							basebev = bev_draw;
						else
							{
							altdex0 = TBSynIndex3A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0]);
							basebev = TBFetchTR(tbid_krk, c_b, altdex0);
							};
						break;

					case tbid_krkp:
						if (pairsq == sq_nil)
							{
							/* promotion only */

							altdex0 = TBSynIndex4A(
								tb_csqv[c_b][0],
								tb_csqv[c_b][1],
								tb_csqv[c_w][0],
								tb_csqv[c_w][1]);

							altdex1 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0],
								tb_csqv[c_b][1]);

							b0bev = TBFetchTR(tbid_krkb, c_w, altdex1);
							b1bev = TBFetchTR(tbid_krkn, c_w, altdex1);
							b2bev = TBFetchTR(tbid_kqkr, c_b, altdex0);
							b3bev = TBFetchTR(tbid_krkr, c_b, altdex0);

							basebev = min(b0bev, b1bev);
							if (basebev > b2bev)
								basebev = b2bev;
							if (basebev > b3bev)
								basebev = b3bev;
							}
						else
							{
							/* capture, possible promotion */

							if (c == c_w)
								{
								altdex0 = TBSynIndex3B(
									reflect_x(tb_csqv[c_b][0]),
									reflect_x(tb_csqv[c_b][1]),
									reflect_x(tb_csqv[c_w][0]));
								basebev =
									TBFetchTR(tbid_kpk, c_b, altdex0);
								}
							else
								{
								altdex0 = TBSynIndex3A(
									tb_csqv[c_w][0],
									tb_csqv[c_w][1],
									tb_csqv[c_b][0]);
								basebev =
									TBFetchTR(tbid_krk, c_b, altdex0);
								};
							};
						break;

					case tbid_krkr:
						if (c == c_w)
							altdex0 = TBSynIndex3A(
								tb_csqv[c_b][0],
								tb_csqv[c_b][1],
								tb_csqv[c_w][0]);
						else
							altdex0 = TBSynIndex3A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0]);
						basebev = TBFetchTR(tbid_krk, c_b, altdex0);
						break;

					case tbid_krnkr:
						if (pairsq == tb_csqv[c_b][1])
							{
							altdex0 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_w][2],
								tb_csqv[c_b][0]);
							basebev = TBFetchTR(tbid_krnk, c_b, altdex0);
							}
						else
							if (pairsq == tb_csqv[c_w][1])
								{
								altdex0 = TBSynIndex4A(
									tb_csqv[c_b][0],
									tb_csqv[c_b][1],
									tb_csqv[c_w][0],
									tb_csqv[c_w][2]);
								basebev = TBFetchTR(tbid_krkn, c_b, altdex0);
								}
							else
								{
								altdex0 = TBSynIndex4A(
									tb_csqv[c_b][0],
									tb_csqv[c_b][1],
									tb_csqv[c_w][0],
									tb_csqv[c_w][1]);
								basebev = TBFetchTR(tbid_krkr, c_b, altdex0);
								};
						break;

					case tbid_krpk:
						if (pairsq == sq_nil)
							{
							altdex0 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_w][2],
								tb_csqv[c_b][0]);

							altdex1 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][2],
								tb_csqv[c_w][1],
								tb_csqv[c_b][0]);

							b0bev = TBFetchTR(tbid_krnk, c_b, altdex0);
							b1bev = TBFetchTR(tbid_krbk, c_b, altdex0);
							b2bev = TBFetchTR(tbid_kqrk, c_b, altdex1);
							b3bev = TBFetchTR(tbid_krrk, c_b, altdex1);

							basebev = min(b0bev, b1bev);
							if (basebev > b2bev)
								basebev = b2bev;
							if (basebev > b3bev)
								basebev = b3bev;
							}
						else
							if (pairsq == tb_csqv[c_w][1])
								{
								altdex0 = TBSynIndex3B(
									tb_csqv[c_w][0],
									tb_csqv[c_w][2],
									tb_csqv[c_b][0]);
								basebev = TBFetchTR(tbid_kpk, c_w, altdex0);
								}
							else
								{
								altdex0 = TBSynIndex3A(
									tb_csqv[c_w][0],
									tb_csqv[c_w][1],
									tb_csqv[c_b][0]);
								basebev = TBFetchTR(tbid_krk, c_w, altdex0);
								};
						break;

					case tbid_krrk:
						sq0 = tb_csqv[c_w][0];
						if (pairsq != tb_csqv[c_w][1])
							sq1 = tb_csqv[c_w][1];
						else
							sq1 = tb_csqv[c_w][2];
						sq2 = tb_csqv[c_b][0];
						altdex0 = TBSynIndex3A(sq0, sq1, sq2);
						basebev = TBFetchTR(tbid_krk, c_w, altdex0);
						break;

					case tbid_krrkq:
						if (c == c_w)
							{
							if (pairsq == tb_csqv[c_w][1])
								altdex0 = TBSynIndex4A(
									tb_csqv[c_b][0],
									tb_csqv[c_b][1],
									tb_csqv[c_w][0],
									tb_csqv[c_w][2]);
							else
								altdex0 = TBSynIndex4A(
									tb_csqv[c_b][0],
									tb_csqv[c_b][1],
									tb_csqv[c_w][0],
									tb_csqv[c_w][1]);
							basebev = TBFetchTR(tbid_kqkr, c_b, altdex0);
							}
						else
							{
							altdex0 = TBSynIndex4A(
								tb_csqv[c_w][0],
								tb_csqv[c_w][1],
								tb_csqv[c_w][2],
								tb_csqv[c_b][0]);
							basebev = TBFetchTR(tbid_krrk, c_b, altdex0);
							};
						break;

					default:
						SwitchFault("TBMake: score trans");
						break;
					};

			/* handle assignment and high water ratchet */

			if (basebev != bev_unknown)
				{
				/* assign main index entry */

				TBPutByte(c, index, basebev);

				/* handle alternative index */

				if (!pawnflag && TBTestDual(tbsptr, index))
					{
					altdex0 = TBGenAltIndex(tbsptr);
					if (altdex0 > index)
						TBPutByte(c, altdex0, basebev);
					};

				/* ratchet */

				if (tbe_mating(basebev))
					{
					level = bev_mi1 - basebev;
					if (level > hwm_mv[c])
						hwm_mv[c] = level;
					}
				else
					if (tbe_losing(basebev))
						{
						level = basebev - bev_li0;
						if (level > hwm_lv[c])
							hwm_lv[c] = level;
						};
				};

			/* clean up */

			TBEraseBoard();
			};

		/* next position */

		TBIncCSPIV();
		};
	TBPRDTerm();
	};

/* determine checkmate/stalemate positions */

for (c = c_w; c <= c_b; c++)
	{
	if (optnv[optn_verb])
		{
		TimeStamp(stamp);
		sprintf(stv, "TBMake: %s %s: determine %s checkmates/stalemates",
			stamp, namestr, tb_stmstrv[c]);
		PrSTVNL();
		};
	DpUpdate(winid_time);

	TBClrCSPIV();
	TBPRDInit(count, prdsL);
	for (index = 0; index < count; index++)
		{
		TBPRDUpdate(index);
		if (TBGetByte(c, index) == bev_unknown)
			{
			/* set result */

			basebev = bev_unknown;

			/* set up position (no transition postitions) */

			TBSetUpFromCSQV(c);

			/* generate moves */

			TBGenDirect();

			/* determine if at least one legal move */

			mateflag = 1;
			m1index = 0;
			m1count = tb_dtmnv[c];
			tmptr = tb_dtmv[c];
			while ((m1index < m1count) && mateflag)
				{
				TBExecute(tmptr);
				if (!TBPassiveKIC())
					mateflag = 0;
				TBRetract(tmptr);
				tmptr++;
				m1index++;
				};

			/* check for a mate */

			if (mateflag)
				if (TBActiveKIC())
					{
					basebev = bev_li0;
					if (hwm_lv[c] < 0)
						hwm_lv[c] = 0;
					}
				else
					basebev = bev_draw;

			/* store result */

			if (basebev != bev_unknown)
				{
				TBPutByte(c, index, basebev);
				if (!pawnflag && TBTestDual(tbsptr, index))
					{
					altdex0 = TBGenAltIndex(tbsptr);
					if (altdex0 > index)
						TBPutByte(c, altdex0, basebev);
					};
				};

			/* erase position */

			TBEraseBoard();
			};

		/* next position */

		TBIncCSPIV();
		};

	TBPRDTerm();
	};

/* perform iteration sequence */

level = 0;
while (((hwm_lv[c_w] >= level) || (hwm_lv[c_b] >= level) ||
	(hwm_mv[c_w] >= level) || (hwm_mv[c_b] >= level)) &&
 	(level < tbbe_ssL))
	{
	/* set the next level */

	nextlevel = level + 1;

	/* set base and loss evaluations for the first of the two parts */

	basebev = bev_mi1 - level;
	lossbev = bev_li0 + level;

	/* search for mate in N for each color */

	for (c = c_w; c <= c_b; c++)
		{
		invc = inv_cv[c];
		if (hwm_lv[invc] >= level)
			{
			if (optnv[optn_verb])
				{
				TimeStamp(stamp);
				sprintf(stv, "TBMake: %s %s: determine %s mate in %hd",
					stamp, namestr, tb_stmstrv[c], nextlevel);
				PrSTVNL();
				};
			DpUpdate(winid_time);

			/* clear the level bump flag  */

			bumpflag = 0;

			/* set up for scan */

			TBClrCSPIV();

			/* scan */

			TBPRDInit(count, prdsL);
			for (index = 0; index < count; index++)
				{
				TBPRDUpdate(index);

				/* test for loss entry of interest */

				if (TBGetByte(invc, index) == lossbev)
					{
					/* check occupancy */

					TBOcSetUp();
					maxp = TBOcMax();

					/* test for pair square status */

					if (maxp == 2)
						{
						/* locate pair square */

						pairsq = TBOcPairSq();
						TBOcSetPair(pairsq);

						/* set up with pair */

						TBSetUpFromCSQVPair(invc, pairsq);
						}
					else
						TBSetUpFromCSQV(invc);

					/* generate retrograde */

					TBGenRetro();

					/* scan retro moves */

					m0count = tb_rtmnv[c];
					tmptr = tb_rtmv[c];
					for (m0index = 0; m0index < m0count; m0index++)
						{
						TBRetract(tmptr);
						if (!TBPassiveKIC())
							{
							altdex0 = TBGenIndex(tbsptr);
							b0bev = TBGetByte(c, altdex0);
							if ((b0bev == bev_unknown) ||
								(b0bev < basebev))
								{
								TBPutByte(c, altdex0, basebev);
								bumpflag = 1;
								};

							if (!pawnflag && TBTestDual(tbsptr, altdex0))
								{
								altdex1 = TBGenAltIndex(tbsptr);
								if (altdex0 != altdex1)
									{
									b1bev = TBGetByte(c, altdex1);
									if ((b1bev == bev_unknown) ||
										(b1bev < basebev))
										{
										TBPutByte(c, altdex1, basebev);
										bumpflag = 1;
										};
									};
								};
							};
						TBExecute(tmptr);
						tmptr++;
						};

					/* erase position */

					TBEraseBoard();
					};

				/* next position */

				TBIncCSPIV();
				};

			TBPRDTerm();

			/* update high water mark if needed */

			if (bumpflag && (hwm_mv[c] < level))
				hwm_mv[c] = level;
			};
		};

	/* set the base evaluation for the second of the two parts */

	basebev = bev_li0 + nextlevel;

	/* search for lose in N for each color */

	for (c = c_w; c <= c_b; c++)
		{
		invc = inv_cv[c];
		if (hwm_mv[c] >= level)
			{
			if (optnv[optn_verb])
				{
				TimeStamp(stamp);
				sprintf(stv, "TBMake: %s %s: determine %s lose in %hd",
					stamp, namestr, tb_stmstrv[invc], nextlevel);
				PrSTVNL();
				};
			DpUpdate(winid_time);

			/* clear the level bump flag */

			bumpflag = 0;

			/* set the bev-to-beat value */

			beatbev = bev_mi1 - level;

			/* set up for scan */

			TBClrCSPIV();

			/* scan */

			TBPRDInit(count, prdsL);
			for (index = 0; index < count; index++)
				{
				TBPRDUpdate(index);

				/* test for mate of interest */

				if (TBGetByte(c, index) == beatbev)
					{
					/* check occupancy */

					TBOcSetUp();
					maxp = TBOcMax();

					/* test for pair square status */

					if (maxp == 2)
						{
						/* locate pair square */

						pairsq = TBOcPairSq();
						TBOcSetPair(pairsq);

						/* set up with pair */

						TBSetUpFromCSQVPair(c, pairsq);
						}
					else
						TBSetUpFromCSQV(c);

					/* generate retrograde */

					TBGenRetro();

					/* scan retro moves */

					m0count = tb_rtmnv[invc];
					tmptr = tb_rtmv[invc];
					for (m0index = 0; m0index < m0count; m0index++)
						{
						TBRetract(tmptr);
						if (!TBPassiveKIC())
							{
							/* check for an undetermined precursor */

							altdex0 = TBGenIndex(tbsptr);
							b0bev = TBGetByte(invc, altdex0);

							if (b0bev == bev_unknown)
								{
								/* prepare to scan forward */

								TBGenDirect();
								m1count = tb_dtmnv[invc];
								mateflag = 1;
								m1index = 0;
								tmptr1 = tb_dtmv[tb_actc];

								/* scan looking for any non-losing moves */

								while (mateflag && (m1index < m1count))
									{
									TBExecute(tmptr1);
									if (!TBPassiveKIC())
										{
										/* check for non-winning status */

										b1bev =
											TBGetByte(c, TBGenIndex(tbsptr));

										if (!tbe_mating(b1bev))
											mateflag = 0;
										else
											if (b1bev < beatbev)
												mateflag = 0;
										};
									TBRetract(tmptr1);
									tmptr1++;
									m1index++;
									};

								/* process change if forced loss */

								if (mateflag)
									{
									/* set the primary loss marker */

									TBPutByte(invc, altdex0, basebev);
									bumpflag = 1;

									if (!pawnflag &&
										TBTestDual(tbsptr, altdex0))
										{
										/* handle secondary loss pointer */

										altdex2 = TBGenAltIndex(tbsptr);
										if (altdex2 != altdex0)
											{
											b2bev =
												TBGetByte(invc, altdex2);
											if ((b2bev == bev_unknown) ||
												(b2bev > basebev))
												{
												TBPutByte(
													invc, altdex2, basebev);
												bumpflag = 1;
												};
											};
										};
									};
								};
							};
						TBExecute(tmptr);
						tmptr++;
						};

					/* erase position */

					TBEraseBoard();
					};

				/* next position */

				TBIncCSPIV();
				};

			TBPRDTerm();

			/* update high water mark if needed */

			if (bumpflag && (hwm_lv[invc] < nextlevel))
				hwm_lv[invc] = nextlevel;
			};
		};

	/* next level */

	level = nextlevel;
	};

/* set unknowns to draws */

for (c = c_w; c <= c_b; c++)
	{
	if (optnv[optn_verb])
		{
		TimeStamp(stamp);
		sprintf(stv, "TBMake: %s %s: set %s unknowns to draws",
			stamp, namestr, tb_stmstrv[c]);
		PrSTVNL();
		};
	DpUpdate(winid_time);

	TBPRDInit(count, prdsL);
	for (index = 0; index < count; index++)
		{
		TBPRDUpdate(index);
		if (TBGetByte(c, index) == bev_unknown)
			TBPutByte(c, index, bev_draw);
		};
	TBPRDTerm();
	};

/* deactivate paging subsystem */

if (optnv[optn_verb])
	{
	TimeStamp(stamp);
	sprintf(stv, "TBMake: %s %s: deactivating paging",
		stamp, namestr);
	PrSTVNL();
	};
DpUpdate(winid_time);

TBTermPaging();

/* terminate local file table and move generation */

TBTermMG();
TBTermTR();

if (optnv[optn_verb])
	{
	TimeStamp(stamp);
	sprintf(stv, "TBMake: %s %s: finish", stamp, namestr);
	PrSTVNL();
	};
DpUpdate(winid_time);

return;
}

/*--> TBVerifyDiagnose: reporting routine for TBVerify */
static
void
TBVerifyDiagnose(tbsptrT tbsptr, cT c, liT index, charptrT msg)
{
sprintf(stv, "verify fault: %s %s (%ld) %s: ",
	tbsptr->tbs_name, tb_stmstrv[c], index, msg);
PrSTV();
TBExhibit(tbsptr, index);

return;
}

/*--> TBVerify: verify a tablebase pair using forward playthough */
static
void
TBVerify(tbsptrT tbsptr)
{
liT index, count;
liT altdex0, altdex1;
siT m1index, m1count, legal;
tmptrT tmptr;
siT flag;
siT pawnflag;
cT c, invc;
bevT basebev, bev0, bev1, worstbev, fetchbev;
stampT stamp;
charptrT namestr;
char fncv[rcL][tL];

/* assign tablebase name string for progress reporting */

namestr = tbsptr->tbs_name;

/* set position count and pawn flag */

count = tbsptr->tbs_size;
if (tbsptr->tbs_flag & tbf_scap)
	pawnflag = 1;
else
	pawnflag = 0;

/* form file name pair */

for (c = c_w; c <= c_b; c++)
	TBFormFileName(tbsptr, c, fncv[c]);

if (optnv[optn_verb])
	{
	TimeStamp(stamp);
	sprintf(stv, "TBVerify: %s %s: start", stamp, namestr);
	PrSTVNL();
	};
DpUpdate(winid_time);

/* initialize move generation */

TBInitMG();

/* activate paging subsystem */

if (optnv[optn_verb])
	{
	TimeStamp(stamp);
	sprintf(stv, "TBVerify: %s %s: activating paging",
		stamp, namestr);
	PrSTVNL();
	};
DpUpdate(winid_time);

TBInitPaging(fncv[c_w], fncv[c_b], "rb");

/* full scan */

for (c = c_w; c <= c_b; c++)
	{
	if (optnv[optn_verb])
		{
		TimeStamp(stamp);
		sprintf(stv, "TBVerify: %s %s %s: scanning",
			stamp, namestr, tb_stmstrv[c]);
		PrSTVNL();
		};
	DpUpdate(winid_time);

	invc = inv_cv[c];
	TBClrCSPIV();
	TBPRDInit(count, prdsL);
	for (index = 0; index < count; index++)
		{
		TBPRDUpdate(index);

		/* fetch */

		basebev = TBGetByte(c, index);

		switch (basebev)
			{
			case bev_broken:
				break;

			case bev_draw:
				if (!TBDetectCaptProm(tbsptr, index))
					{
					/* set up position (no transition postitions) */

					TBSetUpFromCSQV(c);

					/* check primary dual for a match */

					if (!pawnflag && TBTestDual(tbsptr, index))
						{
						altdex0 = TBGenIndex(tbsptr);
						altdex1 = TBGenAltIndex(tbsptr);
						if ((altdex0 != index) && (altdex1 != index))
							TBVerifyDiagnose(tbsptr, c, index,
								"draw primary index fault");

						if (altdex0 != altdex1)
							{
							bev0 = TBGetByte(c, altdex0);
							bev1 = TBGetByte(c, altdex1);
							if (bev0 != bev1)
								TBVerifyDiagnose(tbsptr, c, index,
									"draw primary dual mismatch");
							};
						};

					/* generate moves */

					TBGenDirect();

					/* determine if draw is valid */

					flag = 1;
					legal = 0;
					worstbev = bev_unknown;
					m1index = 0;
					m1count = tb_dtmnv[c];
					tmptr = tb_dtmv[c];
					while ((m1index < m1count) && flag)
						{
						TBExecute(tmptr);
						if (!TBPassiveKIC())
							{
							legal++;
							altdex0 = TBGenIndex(tbsptr);
							fetchbev = TBGetByte(invc, altdex0);

							/* handle primary position */

							switch (fetchbev)
								{
								case bev_broken:
									TBVerifyDiagnose(tbsptr, c, index,
										"draw has broken successor");
									flag = 0;
									break;

								case bev_reserved:
									TBVerifyDiagnose(tbsptr, c, index,
										"draw has reserved successor");
									flag = 0;
									break;

								case bev_unknown:
									TBVerifyDiagnose(tbsptr, c, index,
										"draw has unknown successor");
									flag = 0;
									break;

								default:
									if ((worstbev == bev_unknown) ||
										(worstbev > fetchbev))
										worstbev = fetchbev;
									break;
								};
							};
						TBRetract(tmptr);
						tmptr++;
						m1index++;
						};

					/* reset */

					TBEraseBoard();

					/* test */

					if ((legal > 0) && (worstbev != bev_unknown))
						if (tbe_mating(worstbev))
							TBVerifyDiagnose(tbsptr, c, index,
								"draw has mating minimax");
						else
							if (tbe_losing(worstbev))
								TBVerifyDiagnose(tbsptr, c, index,
									"draw has losing minimax");
					};
				break;

			case bev_reserved:
				TBVerifyDiagnose(tbsptr, c, index, "Reserved");
				break;

			case bev_unknown:
				TBVerifyDiagnose(tbsptr, c, index, "Unknown");
				break;

			default:
				if (!TBDetectCaptProm(tbsptr, index))
					{
					/* set up position (no transition postitions) */

					TBSetUpFromCSQV(c);

					/* check primary dual for a match */

					if (!pawnflag && TBTestDual(tbsptr, index))
						{
						altdex0 = TBGenIndex(tbsptr);
						altdex1 = TBGenAltIndex(tbsptr);
						if ((altdex0 != index) && (altdex1 != index))
							TBVerifyDiagnose(tbsptr, c, index,
								"nondraw primary index fault");

						if (altdex0 != altdex1)
							{
							bev0 = TBGetByte(c, altdex0);
							bev1 = TBGetByte(c, altdex1);
							if (bev0 != bev1)
								TBVerifyDiagnose(tbsptr, c, index,
									"nondraw primary dual mismatch");
							}
						};

					/* generate moves */

					TBGenDirect();

					/* determine if win/loss is valid */

					flag = 1;
					legal = 0;
					worstbev = bev_unknown;
					m1index = 0;
					m1count = tb_dtmnv[c];
					tmptr = tb_dtmv[c];
					while ((m1index < m1count) && flag)
						{
						TBExecute(tmptr);
						if (!TBPassiveKIC())
							{
							legal++;
							altdex0 = TBGenIndex(tbsptr);
							fetchbev = TBGetByte(invc, altdex0);

							switch (fetchbev)
								{
								case bev_broken:
									TBVerifyDiagnose(tbsptr, c, index,
										"nondraw has broken successor");
									flag = 0;
									break;

								case bev_reserved:
									TBVerifyDiagnose(tbsptr, c, index,
										"nondraw has reserved successor");
									flag = 0;
									break;

								case bev_unknown:
									TBVerifyDiagnose(tbsptr, c, index,
										"nondraw has unknown successor");
									flag = 0;
									break;

								default:
									if ((worstbev == bev_unknown) ||
										(worstbev > fetchbev))
										worstbev = fetchbev;
									break;
								};
							};
						TBRetract(tmptr);
						tmptr++;
						m1index++;
						};

					/* test */

					if ((legal > 0) && (worstbev != bev_unknown))
						if (tbe_mating(basebev))
							{
							if (basebev != -worstbev)
								TBVerifyDiagnose(tbsptr, c, index,
									"mate has invalid minimax");
							}
						else
							{
							if (basebev != (-worstbev + 1))
								TBVerifyDiagnose(tbsptr, c, index,
									"loss has invalid minimax");
							};

					/* reset */

					TBEraseBoard();
					};
				break;
			};

		/* next position */

		TBIncCSPIV();
		};
	TBPRDTerm();
	};

/* deactivate paging subsystem */

if (optnv[optn_verb])
	{
	TimeStamp(stamp);
	sprintf(stv, "TBVerify: %s %s: deactivating paging",
		stamp, namestr);
	PrSTVNL();
	};
DpUpdate(winid_time);

TBTermPaging();

/* terminate move generation */

TBTermMG();

if (optnv[optn_verb])
	{
	TimeStamp(stamp);
	sprintf(stv, "TBVerify: %s %s: finish", stamp, namestr);
	PrSTVNL();
	};
DpUpdate(winid_time);

return;
}

/*--> TBAddMV: add a CP and scanning pattern to the master vector */
static
void
TBAddMV(cpT cp, tbspidT tbspid)
{
cT c;
siT i;

c = cv_c_cpv[cp];
i = tb_mcpnv[c]++;

tb_mcpv[c][i] = cp;
tb_mspv[c][i] = tbspid;

return;
}

/*--> TBApply: apply an action to a single TB */
static
void
TBApply(tbsptrT tbsptr, tbcT tbc)
{
cT c;
siT i, j;
tb_actflag = 1;
tb_actresult = 0;

/* initialize master color-piece vector */

i = 0;
tb_mcpnv[c_w] = tb_mcpnv[c_b] = 0;
for (c = c_w; c <= c_b; c++)
	for (j = 0; j < tbsptr->tbs_mnv[c]; j++)
		{
		TBAddMV(tbsptr->tbs_cpv[c][j],
			tbsptr->tbs_spidv[i]);
		i++;
		};

/* switch on verb */

switch (tbc)
	{
	case tbc_make:
		TBMake(tbsptr);
		break;

	case tbc_srpb:
		TBSummary(tbsptr, c_b);
		break;

	case tbc_srpw:
		TBSummary(tbsptr, c_w);
		break;

	case tbc_vrfy:
		TBVerify(tbsptr);
		break;

	default:
		SwitchFault("TBApply: tbc");
		break;
	};

return;
}

/*--> TBCommand: process an external command */
nonstatic
siT
TBCommand(charptrT tbidstr, charptrT tbcstr, liptrT resultptr)
{
siT flag;
siT match;
tbidT tbid;
tbcT tbc;
tbsptrT tbsptr;

flag = 1;
*resultptr = 0;

if (flag)
	{
	match = 0;
	tbid = 0;
	tbsptr = tb_baseptr;
	while (!match && (tbid < tbidL))
		if (strcmp(tbidstr, tbsptr->tbs_name) == 0)
			match = 1;
		else
			{
			tbsptr++;
			tbid++;
			};
	if (!match)
		flag = 0;
	};

if (flag)
	{
	match = 0;
	tbc = 0;
	while (!match && (tbc < tbcL))
		if (strcmp(tbcstr, tb_cstrv[tbc]) == 0)
			match = 1;
		else
			tbc++;
	if (!match)
		flag = 0;
	};

if (flag)
	{
	TBApply(tbsptr, tbc);
	flag = tb_actflag;
	*resultptr = tb_actresult;
	};

return (flag);
}

/*--> TBInit: initialize the TB subsystem (one time call) */
nonstatic
void
TBInit(void)
{
tbspidT tbspid;
siT offset;
rankT rank;
fileT file;
sqT sq;

/* allocate the master base storage */

tb_baseptr = (tbsptrT) MemoryGrab(tbidL * sizeof(tbsT));

/* set the tablebase file suffix strings */

tb_fsptrv[c_w] = ".tbw";
tb_fsptrv[c_b] = ".tbb";

/* set the side to move strings */

tb_stmstrv[c_w] = "WTM";
tb_stmstrv[c_b] = "BTM";

/* set up the tablebase scanning pattern limit vector */

tb_splv[tbspid_all] = tbsp_allL;
tb_splv[tbspid_tri] = tbsp_triL;
tb_splv[tbspid_qsf] = tbsp_qsfL;

/* set up the tablebase scanning pattern offset vector */

offset = 0;
for (tbspid = 0; tbspid < tbspidL; tbspid++)
	{
	tb_spov[tbspid] = offset;
	offset += tb_splv[tbspid];
	};

/* generate scanning pattern: tbspid_all */

offset = tb_spov[tbspid_all];
for (sq = sq_a1; sq <= sq_h8; sq++)
	tb_igv[offset++] = sq;

/* generate scanning pattern: tbspid_tri */

offset = tb_spov[tbspid_tri];
for (rank = rank_1; rank <= rank_4; rank++)
	for (file = file_a + (rank - rank_1); file <= file_d; file++)
		tb_igv[offset++] = map_sq(rank, file);

/* generate scanning pattern: tbspid_qsf */

offset = tb_spov[tbspid_qsf];
for (rank = rank_1; rank <= rank_8; rank++)
	for (file = file_a; file <= file_d; file++)
		tb_igv[offset++] = map_sq(rank, file);

/* initialize the tablebase command string vector */

tb_cstrv[tbc_make] = "make";
tb_cstrv[tbc_srpb] = "srpb";
tb_cstrv[tbc_srpw] = "srpw";
tb_cstrv[tbc_vrfy] = "vrfy";

/* initialize the tablebase vector */

TBInitTB(tbid_kbbk,  tbcsig_a31, "aaat",  "KBBK");
TBInitTB(tbid_kbbkb, tbcsig_a32, "aaaat", "KBBKB");
TBInitTB(tbid_kbbkn, tbcsig_a32, "aaaat", "KBBKN");
TBInitTB(tbid_kbbkq, tbcsig_a32, "aaaat", "KBBKQ");
TBInitTB(tbid_kbbkr, tbcsig_a32, "aaaat", "KBBKR");
TBInitTB(tbid_kbkb,  tbcsig_a22, "aaat",  "KBKB");
TBInitTB(tbid_kbkn,  tbcsig_a22, "aaat",  "KBKN");
TBInitTB(tbid_kbkp,  tbcsig_b22, "aaaq",  "KBKP");
TBInitTB(tbid_kbnk,  tbcsig_a31, "aaat",  "KBNK");
TBInitTB(tbid_kbnkb, tbcsig_a32, "aaaat", "KBNKB");
TBInitTB(tbid_kbnkn, tbcsig_a32, "aaaat", "KBNKN");
TBInitTB(tbid_kbnkq, tbcsig_a32, "aaaat", "KBNKQ");
TBInitTB(tbid_kbnkr, tbcsig_a32, "aaaat", "KBNKR");
TBInitTB(tbid_kbpk,  tbcsig_c31, "aaqa",  "KBPK");
TBInitTB(tbid_knkn,  tbcsig_a22, "aaat",  "KNKN");
TBInitTB(tbid_knkp,  tbcsig_b22, "aaaq",  "KNKP");
TBInitTB(tbid_knnk,  tbcsig_a31, "aaat",  "KNNK");
TBInitTB(tbid_knnkb, tbcsig_a32, "aaaat", "KNNKB");
TBInitTB(tbid_knnkn, tbcsig_a32, "aaaat", "KNNKN");
TBInitTB(tbid_knnkq, tbcsig_a32, "aaaat", "KNNKQ");
TBInitTB(tbid_knnkr, tbcsig_a32, "aaaat", "KNNKR");
TBInitTB(tbid_knpk,  tbcsig_c31, "aaqa",  "KNPK");
TBInitTB(tbid_kpk,   tbcsig_b21, "aqa",   "KPK");
TBInitTB(tbid_kpkp,  tbcsig_d22, "aaaq",  "KPKP");
TBInitTB(tbid_kppk,  tbcsig_c31, "aaqa",  "KPPK");
TBInitTB(tbid_kqbk,  tbcsig_a31, "aaat",  "KQBK");
TBInitTB(tbid_kqbkb, tbcsig_a32, "aaaat", "KQBKB");
TBInitTB(tbid_kqbkn, tbcsig_a32, "aaaat", "KQBKN");
TBInitTB(tbid_kqbkq, tbcsig_a32, "aaaat", "KQBKQ");
TBInitTB(tbid_kqbkr, tbcsig_a32, "aaaat", "KQBKR");
TBInitTB(tbid_kqk,   tbcsig_a21, "aat",   "KQK");
TBInitTB(tbid_kqkb,  tbcsig_a22, "aaat",  "KQKB");
TBInitTB(tbid_kqkn,  tbcsig_a22, "aaat",  "KQKN");
TBInitTB(tbid_kqkp,  tbcsig_b22, "aaaq",  "KQKP");
TBInitTB(tbid_kqkq,  tbcsig_a22, "aaat",  "KQKQ");
TBInitTB(tbid_kqkr,  tbcsig_a22, "aaat",  "KQKR");
TBInitTB(tbid_kqnk,  tbcsig_a31, "aaat",  "KQNK");
TBInitTB(tbid_kqnkb, tbcsig_a32, "aaaat", "KQNKB");
TBInitTB(tbid_kqnkn, tbcsig_a32, "aaaat", "KQNKN");
TBInitTB(tbid_kqnkq, tbcsig_a32, "aaaat", "KQNKQ");
TBInitTB(tbid_kqnkr, tbcsig_a32, "aaaat", "KQNKR");
TBInitTB(tbid_kqpk,  tbcsig_c31, "aaqa",  "KQPK");
TBInitTB(tbid_kqqk,  tbcsig_a31, "aaat",  "KQQK");
TBInitTB(tbid_kqqkb, tbcsig_a32, "aaaat", "KQQKB");
TBInitTB(tbid_kqqkn, tbcsig_a32, "aaaat", "KQQKN");
TBInitTB(tbid_kqqkq, tbcsig_a32, "aaaat", "KQQKQ");
TBInitTB(tbid_kqqkr, tbcsig_a32, "aaaat", "KQQKR");
TBInitTB(tbid_kqrk,  tbcsig_a31, "aaat",  "KQRK");
TBInitTB(tbid_kqrkb, tbcsig_a32, "aaaat", "KQRKB");
TBInitTB(tbid_kqrkn, tbcsig_a32, "aaaat", "KQRKN");
TBInitTB(tbid_kqrkq, tbcsig_a32, "aaaat", "KQRKQ");
TBInitTB(tbid_kqrkr, tbcsig_a32, "aaaat", "KQRKR");
TBInitTB(tbid_krbk,  tbcsig_a31, "aaat",  "KRBK");
TBInitTB(tbid_krbkb, tbcsig_a32, "aaaat", "KRBKB");
TBInitTB(tbid_krbkn, tbcsig_a32, "aaaat", "KRBKN");
TBInitTB(tbid_krbkq, tbcsig_a32, "aaaat", "KRBKQ");
TBInitTB(tbid_krbkr, tbcsig_a32, "aaaat", "KRBKR");
TBInitTB(tbid_krk,   tbcsig_a21, "aat",   "KRK");
TBInitTB(tbid_krkb,  tbcsig_a22, "aaat",  "KRKB");
TBInitTB(tbid_krkn,  tbcsig_a22, "aaat",  "KRKN");
TBInitTB(tbid_krkp,  tbcsig_b22, "aaaq",  "KRKP");
TBInitTB(tbid_krkr,  tbcsig_a22, "aaat",  "KRKR");
TBInitTB(tbid_krnk,  tbcsig_a31, "aaat",  "KRNK");
TBInitTB(tbid_krnkb, tbcsig_a32, "aaaat", "KRNKB");
TBInitTB(tbid_krnkn, tbcsig_a32, "aaaat", "KRNKN");
TBInitTB(tbid_krnkq, tbcsig_a32, "aaaat", "KRRKQ");
TBInitTB(tbid_krnkr, tbcsig_a32, "aaaat", "KRNKR");
TBInitTB(tbid_krpk,  tbcsig_c31, "aaqa",  "KRPK");
TBInitTB(tbid_krrk,  tbcsig_a31, "aaat",  "KRRK");
TBInitTB(tbid_krrkb, tbcsig_a32, "aaaat", "KRRKB");
TBInitTB(tbid_krrkn, tbcsig_a32, "aaaat", "KRRKN");
TBInitTB(tbid_krrkq, tbcsig_a32, "aaaat", "KRRKQ");
TBInitTB(tbid_krrkr, tbcsig_a32, "aaaat", "KRRKR");

/* initialize the tablebase file cache list */

TBCacheInit();

return;
}

/*--> TBTerm: terminate the TB subsystem (one time call) */
nonstatic
void
TBTerm(void)
{
/* terminate the tablebase file cache list */

TBCacheTerm();

/* release the master table storage */

MemoryFree(tb_baseptr);

return;
}

/*<<< tb.c: EOF */
