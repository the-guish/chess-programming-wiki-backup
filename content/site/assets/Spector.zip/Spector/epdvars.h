/*>>> epdvars.h: EPD variable external declarations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/*<<< epdvars.h: EOF */
