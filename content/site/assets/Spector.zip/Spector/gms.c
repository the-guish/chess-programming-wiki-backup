/*>>> gms.c: game move score routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "file.h"
#include "gms.h"
#include "mu.h"
#include "notation.h"
#include "tags.h"

/*** Locals */

/* the output file of interest */

static fptrT gms_fptr;

/* the current character column */

static siT col;

/*--> GMSSetup: setup game move score processing */
static
void
GMSSetup(fptrT fptr)
{
gms_fptr = fptr;
col = 0;

return;
}

/*--> GMSNL: produce newline */
static
void
GMSNL(void)
{
GateChar(gms_fptr, '\n');
col = 0;

return;
}

/*--> GMSRT: produce reserved tag output line */
static
void
GMSRT(rsvtagT rsvtag)
{
TagFilePrintReserved(gms_fptr, rsvtag);

return;
}

/*--> GMSWS: produce wrapped string with a possibly prepended space */
static
void
GMSWS(charptrT s)
{
siT length;

length = strlen(s);
if (col == 0)
	col = length;
else
	if ((col + 1 + length) < souwL)
		{
		GateChar(gms_fptr, ' ');
		col += (1 + length);
		}
	else
		{
		GMSNL();
		col = length;
		};
GateStr(gms_fptr, s);

return;
}

/*--> GMSGP: produce game paragraph */
static
void
GMSGP(void)
{
siT first, hcn;
histptrT hptr;
mT m;
sanT san;

first = 1;
hcn = 0;
hptr = histbase;

while (hcn < histn)
	{
	if (first || (hptr->hist_actc == c_w))
		{
		(void) sprintf(stv, "%hd.", hptr->hist_fmvn);
		GMSWS(stv);
		};

	if (first && (hptr->hist_actc == c_b))
		GMSWS("...");

	first = 0;

	ConvertFromLimitedMove(&hptr->hist_lm, &m);
	ConstructNotation(global_nm, &m, san);
	GMSWS(san);

	hcn++;
	hptr++;
	};

GMSWS(gtomstrv[cv_gtom_gtcv[gtc]]);

if (col != 0)
	GMSNL();

return;
}

/*--> GMSCR: produce concise report on indicated file */
nonstatic
void
GMSCR(fptrT fptr)
{
rankT rank;
fileT file;
cpT cp;

GMSSetup(fptr);

/* output color tags */

GMSRT(rsvtag_white);
GMSRT(rsvtag_black);
GMSNL();

/* output game paragraph */

GMSGP();
GMSNL();

/* output board */

for (rank = rank_8; rank >= rank_1; rank--)
	{
	for (file = file_a; file <= file_h; file++)
		if ((cp = board.rbm[rank][file]) == cp_v0)
			if (bb_tstsqrf(csbbv[c_b], rank, file))
				GateStr(gms_fptr, "::");
			else
				GateStr(gms_fptr, "  ");
		else
			{
			GateChar(gms_fptr, asccv[lang_san][cv_c_cpv[cp]]);
			GateChar(gms_fptr, ascpv[lang_san][cv_p_cpv[cp]]);
			};
	GMSNL();
	};
GMSNL();

return;
}

/*--> GMSER: produce event report on indicated file */
nonstatic
void
GMSER(fptrT fptr)
{
GMSSetup(fptr);

/* output event tags */

GMSRT(rsvtag_event);
GMSRT(rsvtag_site);
GMSRT(rsvtag_date);
GMSRT(rsvtag_round);
GMSRT(rsvtag_white);
GMSRT(rsvtag_black);
GMSRT(rsvtag_result);
GMSNL();

/* output game paragraph */

GMSGP();
GMSNL();

return;
}

/*<<< gms.c: EOF */
