/*>>> bbrotate.c: bitboard rotate */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bbrotate.h"
#include "sysutil.h"

#if (0)
/*--> BitBoardRotate: rotate bitboard 1 step in a direction */
nonstatic
void
BitBoardRotate(bbptrT ptr, dxT dx)
{
siT a;
bbT bb0, bb1;

bb0 = *ptr;
switch (dx)
	{
	case dx_0:
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_1] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_2] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_3] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_4] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_5] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_6] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_7] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_8] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		break;

	case dx_1:
		bb1.bbcv[rank_1] = bb0.bbcv[rank_8];
		bb1.bbcv[rank_2] = bb0.bbcv[rank_1];
		bb1.bbcv[rank_3] = bb0.bbcv[rank_2];
		bb1.bbcv[rank_4] = bb0.bbcv[rank_3];
		bb1.bbcv[rank_5] = bb0.bbcv[rank_4];
		bb1.bbcv[rank_6] = bb0.bbcv[rank_5];
		bb1.bbcv[rank_7] = bb0.bbcv[rank_6];
		bb1.bbcv[rank_8] = bb0.bbcv[rank_7];
		break;

	case dx_2:
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_1] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_2] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_3] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_4] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_5] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_6] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_7] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_8] = ((a >> 1) | ((a & bit) << 7));
		break;

	case dx_3:
		bb1.bbcv[rank_1] = bb0.bbcv[rank_2];
		bb1.bbcv[rank_2] = bb0.bbcv[rank_3];
		bb1.bbcv[rank_3] = bb0.bbcv[rank_4];
		bb1.bbcv[rank_4] = bb0.bbcv[rank_5];
		bb1.bbcv[rank_5] = bb0.bbcv[rank_6];
		bb1.bbcv[rank_6] = bb0.bbcv[rank_7];
		bb1.bbcv[rank_7] = bb0.bbcv[rank_8];
		bb1.bbcv[rank_8] = bb0.bbcv[rank_1];
		break;

	case dx_4:
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_1] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_2] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_3] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_4] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_5] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_6] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_7] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_8] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		break;

	case dx_5:
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_1] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_2] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_3] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_4] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_5] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_6] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_7] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_8] = ((a >> 1) | ((a & bit) << 7));
		break;

	case dx_6:
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_1] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_2] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_3] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_4] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_5] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_6] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_7] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_8] = ((a >> 1) | ((a & bit) << 7));
		break;

	case dx_7:
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_1] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_2] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_3] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_4] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_5] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_6] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_7] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_8] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		break;

	case dx_8:
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_1] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_2] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_3] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_4] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_5] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_6] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_7] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_8] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		break;

	case dx_9:
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_1] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_2] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_3] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_4] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_5] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_6] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_7] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_8] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		break;

	case dx_a:
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_1] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_2] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_3] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_4] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_5] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_6] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_7] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_8] = ((a >> 1) | ((a & bit) << 7));
		break;

	case dx_b:
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_1] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_2] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_3] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_4] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_5] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_6] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_7] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_8] = ((a >> 2) | ((a & 0x03) << 6));
		break;

	case dx_c:
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_1] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_2] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_3] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_4] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_5] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_6] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_7] = ((a >> 2) | ((a & 0x03) << 6));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_8] = ((a >> 2) | ((a & 0x03) << 6));
		break;

	case dx_d:
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_1] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_2] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_3] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_4] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_5] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_6] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_7] = ((a >> 1) | ((a & bit) << 7));
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_8] = ((a >> 1) | ((a & bit) << 7));
		break;

	case dx_e:
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_1] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_2] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_3] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_4] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_5] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_6] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_7] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_8] = (((a & 0x7f) << 1) | ((a >> 7) & bit));
		break;

	case dx_f:
		a = bb0.bbcv[rank_2];
		bb1.bbcv[rank_1] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_3];
		bb1.bbcv[rank_2] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_4];
		bb1.bbcv[rank_3] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_5];
		bb1.bbcv[rank_4] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_6];
		bb1.bbcv[rank_5] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_7];
		bb1.bbcv[rank_6] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_8];
		bb1.bbcv[rank_7] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		a = bb0.bbcv[rank_1];
		bb1.bbcv[rank_8] = (((a & 0x3f) << 2) | ((a >> 6) & 0x03));
		break;

	default:
		SwitchFault("BitBoardRotate");
		break;
	};
*ptr = bb1;

return;
}
#endif

/*<<< bbrotate.c: EOF */
