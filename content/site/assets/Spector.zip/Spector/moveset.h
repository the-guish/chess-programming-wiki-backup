/*>>> mset.h: subprogram prototypes for moveset.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT CurrentPlyZeroMoveIndex(void);
mptrT FindMove(mptrT mptr, sptrT sptr);
mptrT FindMoveFSTS(sqT frsq, sqT tosq, sptrT sptr);
mptrT FindMoveNF(mptrT mptr, sptrT sptr, charptrT s);
mptrT FindMoveEC(mptrT mptr, sptrT sptr);
mlstptrT LocateListMoveEntry(mptrT mptr, mlstptrT mlstptr);
void FreeMoveList(mlstptrT mlstptr);
void MovesetSortPreliminaries(sptrT sptr);
void MovesetSortEvaluations(sptrT sptr);
void MovesetSortNodeCounts(void);
void MovesetRethreadMove(mptrT mptr);
void MovesetRethread(sptrT sptr);
void MovesetSearchReset(sptrT sptr);
void MovesetPrecharge(void);
sptrT MovesetNew(void);
void MovesetRelease(sptrT sptr);
void MovesetAllocate(sptrT sptr);
void MovesetResize(sptrT sptr);
void MovesetDisconnectRelease(mptrT mptr);
void MovesetGenerateConnect(mptrT mptr);
void MovesetGenerateCapturesConnect(mptrT mptr);
void MovesetGenerateSingletonConnect(mptrT mptr, mptrT tmptr);
siT CountLegalMoves(sptrT sptr);
void MovesetPolice(sptrT sptr);
void MovesetDrawAndMateScan(sptrT sptr);
void MovesetFlagsScan(sptrT sptr);
void MovesetAllBadButOneScan(sptrT sptr);
cpevT MovesetBestCertainScore(sptrT sptr);
void MovesetCertaintyScan(sptrT sptr);
void MovesetFullExpand(sptrT sptr, siT n);
void TreeNew(void);

/*<<< mset.h: EOF */
