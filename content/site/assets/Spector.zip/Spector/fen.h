/*>>> fen.h: subprogram prototypes for fen.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

charptrT FENGenerate(void);
siT FENParseBD(charptrT s, rbptrT rbptr);
siT FENParseAC(charptrT s, cptrT cptr);
siT FENParseCA(charptrT s, castptrT castptr);
siT FENParseEP(charptrT s, sqptrT sqptr);
siT FENParseHC(charptrT s, siptrT siptr);
siT FENParseFN(charptrT s, siptrT siptr);

/*<<< fen.h: EOF */
