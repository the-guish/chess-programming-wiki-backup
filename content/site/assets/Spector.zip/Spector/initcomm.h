/*>>> initcomm.h: subprogram prototypes for initcomm.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void InitCommands(void);

/*<<< initcomm.h: EOF */
