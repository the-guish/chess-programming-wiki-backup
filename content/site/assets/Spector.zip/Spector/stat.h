/*>>> stat.h: subprogram prototypes for stat.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT PositionCensusOkay(void);
gsT GameStatus(sptrT sptr);
siT GameStatusNormal(sptrT sptr);

/*<<< stat.h: EOF */
