/*>>> pcexec.h: subprogram prototypes for pcexec.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void ProcessEXPM(void);
void ProcessEXPV(void);
void ProcessEXSM(void);
void ProcessEXSV(void);

/*<<< pcexec.h: EOF */
