/*>>> memutil.h: subprogram prototypes for memutil.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

voidptrT MemoryGrab(allocT n);
charptrT StringGrab(charptrT s);
charptrT StringAppendChar(charptrT s, char ch);
charptrT StringAppendStr(charptrT s0, charptrT s1);
voidptrT MemoryResize(voidptrT p, allocT n);
void MemoryFree(voidptrT p);

/*<<< memutil.h: EOF */
