/*>>> mu.h: subprogram prototypes for mu.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void SetUpRootMove(void);
siT SanityCheck(mptrT mptr);
siT ExtraSanityCheck(mptrT mptr);
void SetCertaintyScore(mptrT mptr);
siT SameMoveRef(mptrT mptr0, mptrT mptr1);
void ConvertFromLimitedMove(lmptrT lmptr, mptrT mptr);
void ConvertToLimitedMove(mptrT mptr, lmptrT lmptr);
void MergeMoveFlags(mptrT mptr0, mptrT mptr1);
mptrT ExpandCompactMove(cmT cm);
mptrT SynthesizeMove(sqT frsq, sqT tosq);

/*<<< mu.h: EOF */
