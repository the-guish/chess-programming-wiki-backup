/*>>> vars.h: common variable declarations (externals) */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/**** Constants */

/* program identification */

extern charptrT progname;
extern charptrT progauth;
extern charptrT proguscf;
extern charptrT progexpr;
extern charptrT progdate;
extern charptrT progvers;

/* major and minor version numbers */

extern siT version_major, version_minor;

/* the "nil" string */

extern charptrT nilstr;

/* language strings */

extern charptrT langstrv[langL];

/* color and piece strings */

extern charptrT cstrv[rcL], pstrv[pL];

/* special case move indication strings */

extern charptrT scmvstrv[scmvL];

/* moveset flag strings */

extern charptrT sflagstrv[sfiL];

/* move flag strings */

extern charptrT mflagstrv[mfiL];

/* search termination reason code strings */

extern charptrT strcstrv[strcL];

/* game status strings */

extern charptrT gsstrv[gsL];

/* short game status strings */

extern charptrT sgsstrv[gsL];

/* game termination input marker strings */

extern charptrT gtimstrv[gtimL];

/* game termination output strings */

extern charptrT gtomstrv[gtomL];

/* strategy name strings */

extern charptrT strtstrv[strtL];

/* notation mode strings */

extern charptrT nmstrv[nmL];

/* ordinal strings: unit/tens/teen */

extern charptrT ord_unitv[decadeL], ord_tensv[decadeL], ord_teenv[decadeL];

/* phonetic strings: color, piece, rank, file */

extern charptrT phs_cv[rcL], phs_pv[pL], phs_rv[rankL], phs_fv[fileL];

/* character translation vectors */

extern char asccv[langL][cL], ascpv[langL][pL];
extern char ascrv[rankL], ascfv[fileL];

/* conversion vectors: ASCII hexadecimal character from integer */

extern char cv_ahc_iv[16];

/* conversion vectors: color from color-piece */

extern cT cv_c_cpv[cpL];

/* conversion vectors: piece from color-piece */

extern pT cv_p_cpv[cpL];

/* conversion vectors: color-piece from restricted-color and piece */

extern cpT cv_cp_c_pv[rcL][pL];

/* conversion vectors: piece from special cased move indicator */

extern pT cv_p_scmvv[scmvL];

/* conversion vectors: color-piece bit field from color-piece */

extern cpbfT cv_cpbf_cpv[cpL];

/* conversion vectors: game termination code from gt input marker */

extern gtcT cv_gtc_gtimv[gtimL];

/* conversion vectors: game termination output marker from gt code */

extern gtomT cv_gtom_gtcv[gtcL];

/* the enumeration word table base (count of on bits) */

extern byteptrT bevbase;

/* the bit first table base (lowest of on bits) */

extern byteptrT bfvbase;

/* cancellation word vector */

extern siT canwv[wordW];

/* rank and file directional delta vectors */

extern dvrT dvrv[dxL];
extern dvfT dvfv[dxL];

/* board and extended board direction deltas */

extern dvT dvv[dxL];
extern xdvT xdvv[dxL];

/* complementary direction vector */

extern dxT compdxv[dxL];

/* the rank and file direction component offsets */

extern siT rdvv[dxL], fdvv[dxL];

/* the square bitboard vector */

extern bbT sqbbv[sqL];

/* rank and file bitboard vectors */

extern bbT r0bbv[rankL], f0bbv[fileL];

/* the file adjacent bitboard vector */

extern bbT fabbv[fileL];

/* the file triplet bitboard vector */

extern bbT ftbbv[fileL];

/* the reduced direction edge bitboard vector */

extern bbT debbv[rdxL];

/* the extended board */

extern xbT xb;

/* piece move bitboard vectors */

extern bbT nmbbv[sqL], bmbbv[sqL], rmbbv[sqL], qmbbv[sqL], kmbbv[sqL];

/* pawn move and pawn capture bitboard vectors */

extern bbT pmbbv[rcL][sqL], pcbbv[rcL][sqL];

/* the pawn forward tracking bitboard vector */

extern bbT ptbbv[rcL][sqL];

/* the pawn adjacency forward tracking bitboard vector */

extern bbT pabbv[rcL][sqL];

/* the passed pawn check tracking bitboard vector */

extern bbT ppbbv[rcL][sqL];

/* the pawn phalanx horizontal adjacency bitboard vector */

extern bbT pxbbv[sqL];

/* the king hustle bitboard vector */

extern bbT khbbv[sqL];

/* the castling attack square bitboards */

extern bbT wkabb, wqabb, bkabb, bqabb;

/* the castling occupancy square bitboards */

extern bbT wkobb, wqobb, bkobb, bqobb;

/* the castling terminal square bitboards */

extern bbT wktbb, wqtbb, bktbb, bqtbb;

/* color square bitboard vector */

extern bbT csbbv[rcL];

/* rank based pawn advancement scaling (mostly for passed pawns) */

extern siT rbpasv[rcL][rankL];

/* pawn general advancement credit board (millipawn units) */

extern sibT gpaibv[rcL];

/* the castling information vector */

extern ciT civ[rcL];

/* color inversion vector */

extern cT inv_cv[cL];

/* color piece inversion vector */

extern cpT inv_cpv[cpL];

/* color-piece sweep indicator vector */

extern siT cp_sweepv[cpL];

/* the directional sweep bounds vectors */

extern dxT dx_sweep0v[pL], dx_sweep1v[pL];

/* promotion ranks by color */

extern rankT promrankv[rcL];

/* the null move */

extern mT null_m;

/* the null killer move */

extern kmT null_km;

/* the null limited move */

extern lmT null_lm;

/* the null simple move */

extern smT null_sm;

/* the null tactical search move */

extern tsmT null_tsm;

/* piece values */

extern cpevT pvalv[pL], cpvalv[cpL], xcpvalv[cpL];
extern siT scpvalv[cpL];

/* central distances (ortho summation: 1 <-> 7) */

extern sibT centdist;

/* opposing positions bitboard for active king checkmates */

extern bbT opposing;

/* rim and center bitboards */

extern bbT ontherim, incenter;

/* halfboard bitboards */

extern bbT hbbb_kingside, hbbb_queenside, hbbb_whiteside, hbbb_blackside;

/* sanctuary and cramped bitboard vectors */

extern bbT sancspot[rcL], cramspot[rcL];

/**** table base pointers */

/* the direction connection sq/sq table */

extern dxptrT dx_table_base;

/* the taxi distance sq/sq table */

extern byteptrT taxi_table_base;

/* the mintaxi and maxtaxi distance sq/sq tables */

extern byteptrT mintaxi_table_base, maxtaxi_table_base;

/**** raster base pointers */

/* the intersquare, beyond, and ray pathway sq/sq rasters */

extern bbptrT path_raster_base, beyond_raster_base, ray_raster_base;

/**** database variables */

/* color and color-piece bitboard vectors */

extern bbT c0bbv[rcL], cpbbv[rcpL];

/* the all pieces merged bitboard */

extern bbT apmbb;

/* attack-to, attack-from, and combined attack bitboards */

extern bbT atbbv[sqL], afbbv[sqL], acbbv[rcL];

/* the local board */

extern rbT local;

/* the null move used for generation base */

extern mT genbase_m;

/* the generated move */

extern mT gen_m;

/**** global parameters */

/* the global bitboard and the global auxillary bitboard */

extern bbT gp_bb, gp_abb;

/**** ply */

/* the current ply */

extern siT ply;

/**** environment */

/* local copy of the environment */

extern envnT envn;

/* environmental pointers: base and current */

extern envnptrT envn_base, envn_curr;

/**** move tree */

/* the root for the entire move tree */

extern sptrT root_sptr;

/* the root move node, either null or last move played */

extern mT root_m;

/**** history full info push depth */

/* ply depth to copy full position information (always >= 1) */

extern siT history_full_push;

/**** search results */

/* the most recent search expectation score */

extern cpevT expectation;

/**** forced mate search: nodes and seconds */

extern liT fms_nodes, fms_seconds;

/**** statistics */

/* counting statistics */

extern liT count_exec, count_node, pre_count_node;

/* node count and time at start of a search */

extern liT search_start_node;
extern time_t search_start_time;

/**** tags (environment pairs) */

/* head and tail of tag list */

extern tagptrT head_tagptr, tail_tagptr;

/* default reserved tag names */

extern charptrT rsvtagv[rsvtagL];

/**** program status */

/* global termination flag */

extern siT progdone;

/* move/multimove stop flag */

extern siT stop_play;

/* pointer to transfer program command line */

extern charptrT xferline;

/* program transfer argument vector */

extern charptrT *xferargv;

/* notation mode indicator */

extern nmT global_nm;

/* notation language indices for input and output (set by command) */

extern langT lang_get;  /* input to program */
extern langT lang_put;  /* output from program */

/* notation language index for SAN (either get/put; set by program) */

extern langT lang_san;

/**** game status */

/* the position set-up flag */

extern siT setup;

/* the real board */

extern rbT board;

/* the active and passive colors at the current ply */

extern cT actc, pasc;

/* the active and passive colors at the ply zero */

extern cT p0actc, p0pasc;

/* game termination code */

extern gtcT gtc;

/**** files */

/* dribble file pointer */

extern fptrT drib_fptr;

/* command file list head and tail pointers */

extern commfileptrT head_commfile, tail_commfile;

/**** communication linkage */

/* serial channel status vector */

extern scsT scsv[channelL];

/**** text I/O */

/* read text input vector */

extern char rtv[tL];

/* scratch text vector */

extern char stv[tL];

/**** game score and history */

/* number of positions stacked in history/ordinal storage */

extern siT histn;

/* the base and current history pointers */

extern histptrT histbase, histcurr;

/**** canonical move ordinals */

/* the base and current canonical move ordinal pointers */

extern cordptrT cordbase, cordcurr;

/**** static exchange evaluation */

/* the directional attacker vector */

extern cpsqT sxv[dxL];

/**** search */

/* the strategies */

extern strtT strtv[rcL];

/* the playing level */

extern siT level;

/* the current alpha beta iteration */

extern siT iteration;

/* the forcing iteration completion indicator */

extern siT force_iteration;

/* the search abort and search interrupt indicators */

extern siT search_abort, search_interrupt;

/* first time descent flags: first time down per iteration/ply zero move */

extern siT FTDIteration, FTDPlyZeroMove;

/* the target move list (-srch- command) */

extern mlstptrT target_mlstptr;

/* the ply zero search node count storage base */

extern liptrT pzsnc_base;

/* search termination reason code */

extern strcT strc;

/**** ponder search  */

/* the ponder search indicator flag */

extern siT ponder_active;

/* the ponder search result success flag */

extern siT ponder_result;

/* the ponder search trace flag */

extern siT ponder_trace;

/* the ponder search manual stop flag */

extern siT ponder_manual_stop;

/* the ponder search match flag (true if ponder search succeeds) */

extern siT ponder_match;

/* the ponder search mismatch flag (true if ponder search fails) */

extern siT ponder_mismatch;

/* the predicted move */

extern mT ponder_m;

/**** evaluation */

/* position sums (millipawns) */

extern mpevT position_ev[rcL];

/**** killer moves */

/* group killer move vector storage base */

extern gkmptrT gkm_base;

/* killer response storage base */

extern smptrT killer_response_base;

/* killer popularity storage base */

extern siptrT killer_pop_base;

/* counter killer base pointer */

extern smptrT counter_killer_base;

/**** chess clocks */

/* the accumulated time (in seconds) for each color */

extern liT clockv[rcL];

/* mark time of last clock update */

extern time_t clockm;

/* clock running flag */

extern siT clockflag;

/**** search termination timers */

/* the countdown timer */

extern liT countdown_timer;

/* the node countdown */

extern liT node_countdown;

/**** time control */

/* the time control vector */

extern tcntlT tcntlv[tcntlL];

/* time control: per move basic allocation */

extern liT sec_alloc;

/* time control: elapsed time since start of game */

extern liT tcntl_et0;

/* time control: budgeted time (per move) for various checkpoints */

extern liT tcntl_obvious, tcntl_next_iteration;
extern liT tcntl_next_candidate, tcntl_mondo;

/**** time marks */

/* time marks: program start, commanded, and update (current) values */

extern liT tmark_pstart, tmark_mkcomm, tmark_update;

/* time of last clank probe */

extern liT tmark_clank;

/**** transposition table */

extern liT tt_hash_order;
extern liT tt_hash_span;
extern liT tt_hash_size;
extern liT tt_hash_mask;

/**** silent play control */

extern siT silent_play;

/**** fifty move draw deactivation */

extern siT no_50mvdraw;

/**** display items for input into presentation generation */

/* DI: search */

extern siT di_expectation;
extern siT di_iteration;
extern siT di_p0span;
extern siT di_p0pick;
extern mT di_p0m;
extern liT di_nodes;
extern liT di_seconds;
extern lrT di_completion;
extern liT di_prediction;

/*<<< vars.h: EOF */
