/*>>> tbplay.h: subprogram prototypes for tbplay.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void TBPlay(void);

/*<<< tbplay.h: EOF */
