/*>>> util.h: subprogram prototypes for util.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

liT ReverseLI(liT value);
siT ConvFrCSI(siT value);
siT ConvToCSI(siT value);
liT ConvFrCLI(liT value);
liT ConvToCLI(liT value);
void EncodeHexLong(liT val, charptrT ptr);
void FormatSTVLQF(liT num, liT den);
void FormatSTVLQI(liT num, liT den);
void FormatSTVLQR(liT num, liT den);
void ZapBytes(voidptrT p, allocT n);
siT ByteCmp(voidptrT p0, voidptrT p1, allocT n);
siT AbsSI(siT x);
liT MaxLI(liT i, liT j);
liT MinLI(liT i, liT j);
siT IdentChar(siT c);
siT CICharEqual(char c0, char c1);
siT CIStrEqual(charptrT s0, charptrT s1);
siT PsuedoRandomByte(void);
liT PsuedoRandomWord(void);
liT PsuedoRandomLongWord(void);
liT TBPsuedoRandomLI(void);
void BCBGrab(bcbptrT bcbptr, liT length);
void BCBFree(bcbptrT bcbptr);

/*<<< util.h: EOF */
