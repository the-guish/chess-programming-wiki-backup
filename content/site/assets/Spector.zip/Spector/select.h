/*>>> select.h: subprogram prototypes for select.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void SelectMove(void);
void ProgramMove(void);

/*<<< select.h: EOF */
