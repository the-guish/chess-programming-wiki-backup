/*>>> sx.c: static exchange routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "bb.h"
#include "print.h"
#include "sx.h"

/**** Locals */

/* sweep piece bitboard */

static bbT spbb;

/*--> SXInitSq: initialize the static exchange items for a square */
static
void
SXInitSq(sqT sq)
{
dxT dx;
sqT rsq;

/* clear output vector coordinates */

for (dx = 0; dx < dxL; dx++)
	sxv[dx].cpsq_sq = sq_nil;

/* locate all attacks to the square */

gp_bb = atbbv[sq];

/* process each attack */

while (bb_next_gp(rsq))
	{
	dx = *(dx_table_base + offset_sqsq(sq, rsq));
	sxv[dx].cpsq_cp = local.rbv[sxv[dx].cpsq_sq = rsq];
	};

return;
}

/*--> SXAdvanceSq: advance the static exchange items for a square */
static
void
SXAdvanceSq(dxT dx)
{
bbT erbb;
sqT tsq;

/* check for non-knight */

if (dx < rdxL)
	{
	gp_bb = atbbv[tsq = sxv[dx].cpsq_sq];
	erbb = *(ray_raster_base + offset_dxsq(dx, tsq));
	bb_and2(erbb, gp_bb);
	bb_and2(spbb, gp_bb);
	if (bb_tst(gp_bb))
		sxv[dx].cpsq_cp = local.rbv[sxv[dx].cpsq_sq = bb_once_gp()];
	else
		sxv[dx].cpsq_sq = sq_nil;
	}
else
	sxv[dx].cpsq_sq = sq_nil;

return;
}

/*--> SXMinColorDirection: return direction of minimal color attacker */
static
dxT
SXMinColorDirection(cT c)
{
dxT rdx, dx;
cpT rcp, cp;

rcp = cp_nil;
rdx = dx_nil;
for (dx = 0; dx < dxL; dx++)
	if (sxv[dx].cpsq_sq != sq_nil)
		if (cv_c_cpv[cp = sxv[dx].cpsq_cp] == c)
			if (rdx == dx_nil)
				{
				rdx = dx;
				rcp = cp;
				}
			else
				if (cp < rcp)
					{
					rdx = dx;
					rcp = cp;
					};

return (rdx);
}

/*--> SXNode: return the recursively defined node evaluation */
static
cpevT
SXNode(cpevT alpha, cpevT beta, cT a_c, cT p_c, cpevT bal, cpT target_cp)
{
cpevT best_score;
cpevT x_score;
dxT dx;
cpT attack_cp;

/* initialize */

best_score = alpha;

/* test non-capture bound */

if (bal > best_score)
	best_score = bal;

/* test against upper bound */

if (best_score < beta)
	{
	/* best_score is within window; get next attacker */

	dx = SXMinColorDirection(a_c);

	/* does an active attacker exist? */

	if (dx != dx_nil)
		{
		/* get the attacker */

		attack_cp = sxv[dx].cpsq_cp;

		/* advance direction vector */

		SXAdvanceSq(dx);

		/* try recursive evaluation */

		x_score = -SXNode(-beta, -best_score, p_c, a_c,
			-(bal + xcpvalv[target_cp]), attack_cp);

		/* compare search result with non-capture */

		if (x_score > best_score)
			best_score = x_score;
		};
	};

return (best_score);
}

/*--> SXEvalSquare: return exchange adjustment for the given square */
static
cpevT
SXEvalSquare(sqT sq)
{
cpevT cpev;
cpT target_cp;
cT target_c, attack_c;

/* assume occupied square; get target and attack colors */

attack_c = inv_cv[target_c = cv_c_cpv[target_cp = local.rbv[sq]]];

/* no hostile attackers? */

if (bb_tstnotsq(acbbv[attack_c], sq))
	cpev = 0;
else
	{
	/* at least one attacker; perform static exchange analysis */

	SXInitSq(sq);
	cpev = SXNode(-1, (xcpvalv[target_cp] + 1),
		attack_c, target_c, 0, target_cp);
	};

return (cpev);
}

/*--> SXEval: return exchange adjustment for the active color */
nonstatic
cpevT
SXEval(void)
{
sqT sq;
bbT xwbb, xbbb, exbb, txbb;
cpevT val;
cpevT ac0_cpev, ac1_cpev, pc0_cpev;
cpevT xcpv[sqL];

/* set the sweeper bitboard */

bb_clr(spbb);
bb_ior2(cpbbv[cp_wb], spbb);
bb_ior2(cpbbv[cp_bb], spbb);
bb_ior2(cpbbv[cp_wr], spbb);
bb_ior2(cpbbv[cp_br], spbb);
bb_ior2(cpbbv[cp_wq], spbb);
bb_ior2(cpbbv[cp_bq], spbb);

/* calculate the exchangable bitboard */

bb_and3(c0bbv[c_w], acbbv[c_b], xwbb);
bb_and3(c0bbv[c_b], acbbv[c_w], xbbb);
bb_ior3(xwbb, xbbb, exbb);

/* scan board */

bb_clr(txbb);
while (bb_next(exbb, sq))
	if ((xcpv[sq] = SXEvalSquare(sq)) > 0)
		bb_setsq(txbb, sq);

/* determine hazard triplet */

ac0_cpev = ac1_cpev = pc0_cpev = 0;

while (bb_next(txbb, sq))
	{
	val = xcpv[sq];
	if (cv_c_cpv[local.rbv[sq]] == actc)
		{
		if (val > ac1_cpev)
			if (val > ac0_cpev)
				{
				ac1_cpev = ac0_cpev;
				ac0_cpev = val;
				}
			else
				ac1_cpev = val;
		}
	else
		if (val > pc0_cpev)
			pc0_cpev = val;
	};

return (pc0_cpev - ac1_cpev);
}

/*<<< sx.c: EOF */
