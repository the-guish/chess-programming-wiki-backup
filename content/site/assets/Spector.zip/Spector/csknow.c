/*>>> csknow.c: concept search knowledge manipulation routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "csdefs.h"
#include "csvars.h"

#include "csknow.h"
#include "file.h"
#include "util.h"

/*--> CSLoadKnowledge: load knowledge database from file */
nonstatic
siT
CSLoadKnowledge(charptrT fn)
{
siT code;
fptrT fptr;

/* set default */

code = 1;

/* attempt open */

if ((fptr = TextFileOpen(fn, "r")) == NULL)
	code = 0;

/* process */

/* close */

if (fptr != NULL)
	(void) TextFileClose(fptr);

return (code);
}

/*--> CSSaveKnowledge: save knowledge database to file */
nonstatic
siT
CSSaveKnowledge(charptrT fn)
{
siT code;
fptrT fptr;

/* set default */

code = 1;

/* attempt open */

if ((fptr = TextFileOpen(fn, "w")) == NULL)
	code = 0;

/* process */

/* close */

if (fptr != NULL)
	(void) TextFileClose(fptr);

return (code);
}

/*<<< csknow.c: EOF */
