/*>>> csprnt.c: concept search printing routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "csdefs.h"
#include "csvars.h"

#include "csprnt.h"
#include "csutil.h"
#include "print.h"
#include "stat.h"

/*--> CSPrintPatternStr: print basic pattern string */
static
void
CSPrintPatternStr(bpT bp)
{
if (bp == bp_nil)
	PrNil();
else
	PrStr(bpdv[bp].bpd_name);

return;
}

/*--> CSPrintColorPiece: print color-piece, special for vacant */
static
void
CSPrintColorPiece(cpT cp)
{
if (cp == cp_v0)
	PrStr("--");
else
	PrColorPiece(cp);

return;
}

/*--> CSPrintPattern: print basic pattern frame */
static
void
CSPrintPattern(bpfT bpf)
{
bpmT bpm;
siT bflag;

bpm = bpdv[bpf.bpf_bp].bpd_bpm;
bflag = 0;

/* start */

PrChar('(');

/* mi_0: bp */

if (bpm & bpmb_bp)
	{
	if (bflag)
		PrBlank();
	CSPrintPatternStr(bpf.bpf_bp);
	bflag = 1;
	};

/* mi_1: iv0 */

if (bpm & bpmb_iv0)
	{
	if (bflag)
		PrBlank();
	PrSI(bpf.bpf_iv0);
	bflag = 1;
	};

/* mi_2: iv1 */

if (bpm & bpmb_iv1)
	{
	if (bflag)
		PrBlank();
	PrSI(bpf.bpf_iv1);
	bflag = 1;
	};

/* mi_3: cp0 */

if (bpm & bpmb_cp0)
	{
	if (bflag)
		PrBlank();
	CSPrintColorPiece(bpf.bpf_cp0);
	bflag = 1;
	};

/* mi_4: sq0 */

if (bpm & bpmb_sq0)
	{
	if (bflag)
		PrBlank();
	PrSq(bpf.bpf_sq0);
	bflag = 1;
	};

/* mi_5: cp1 */

if (bpm & bpmb_cp1)
	{
	if (bflag)
		PrBlank();
	CSPrintColorPiece(bpf.bpf_cp1);
	bflag = 1;
	};

/* mi_6: sq1 */

if (bpm & bpmb_sq1)
	{
	if (bflag)
		PrBlank();
	PrSq(bpf.bpf_sq1);
	bflag = 1;
	};

/* mi_7: cp2 */

if (bpm & bpmb_cp2)
	{
	if (bflag)
		PrBlank();
	CSPrintColorPiece(bpf.bpf_cp2);
	bflag = 1;
	};

/* mi_8: sq2 */

if (bpm & bpmb_sq2)
	{
	if (bflag)
		PrBlank();
	PrSq(bpf.bpf_sq2);
	bflag = 1;
	};

/* mi_9: cp3 */

if (bpm & bpmb_cp3)
	{
	if (bflag)
		PrBlank();
	CSPrintColorPiece(bpf.bpf_cp3);
	bflag = 1;
	};

/* mi_a: sq3 */

if (bpm & bpmb_sq3)
	{
	if (bflag)
		PrBlank();
	PrSq(bpf.bpf_sq3);
	bflag = 1;
	};

/* mi_b: scmv */

if (bpm & bpmb_scmv)
	{
	if (bflag)
		PrBlank();
	PrSpecialCaseIndication(bpf.bpf_scmv);
	bflag = 1;
	};

/* finish */

PrChar(')');

return;
}

/*--> CSPrintDescription: print moveset description */
nonstatic
void
CSPrintDescription(sptrT sptr)
{
cnptrT cnptr;
bpfptrT bpfptr;
gsT gs;

gs = GameStatus(sptr);
if ((gs != gs_bust) && (gs != gs_over))
	{
	CSExpandNode(sptr);
	cnptr = sptr->s_cnptr;
	bpfptr = cnptr->cn_bpfhead;
	while (bpfptr != NULL)
		{
		CSPrintPattern(*bpfptr);
		PrNL();
		bpfptr = bpfptr->bpf_next;
		};
	};

return;
}

/*<<< csprnt.c: EOF */
