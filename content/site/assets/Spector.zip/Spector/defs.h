/*>>> defs.h: global definitions */

/***************************************************************************/
/*                                                                         */
/*    SSSSS    PPPPPP    EEEEEEE    CCCCC    TTTTTTT    OOOOO    RRRRRR    */
/*   S     S   P     p   E         C     C      T      O     O   R     R   */
/*   S         P     P   E         C            T      O     O   R     R   */
/*    SSSSS    PPPPPP    EEEEE     C            T      O     O   RRRRRR    */
/*         S   P         E         C            T      O     O   R   R     */
/*   S     S   P         E         C     C      T      O     O   R    R    */
/*    SSSSS    P         EEEEEEE    CCCCC       T       OOOOO    R     R   */
/*                                                                         */
/***************************************************************************/

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* execution environment: operating system and processor */

#define os_unix 1 /* generic Unix */
#define os_mac  0 /* Macintosh */

/* execution environment: central processing unit (one choice nonzero) */

#define cpu_i80386  0 /* Intel iAPX80386+ */
#define cpu_mc68020 0 /* Motorola MC68020+ */
#define cpu_powerpc 1 /* PowerPC */


/* execution environment: interrupt and polling */

#define ips_interrupt 1 /* handle SIGINT signal search stop */
#define ips_mouse     1 /* poll for mouse button search stop */

/* display environment: presentation interface (one choice nonzero) */

#define disenv_scroll 1  /* simple scrolling output */
#define disenv_random 0  /* random access cursor control */

/* voice synthesis generation environment */

#define vsgenv_phonetic 0 /* use phonentic output */

/* byte reversals */

#if (cpu_i80386)
#define byte_rev 0
#else
#define byte_rev 1
#endif

/* length of the program name plus one */

#define prognameL 8

/* length of the version name plus one */

#define progversL 8

/* the true NULL definition */

#if (defined(NULL))
#undef NULL
#endif
#define NULL ((void *) 0)

/* subprogram storage class for non-statics (usually empty definition) */

#define nonstatic

/* character case mapping */

#define map_lower(ch) (isupper((ch)) ? tolower((ch)) : (ch))
#define map_upper(ch) (islower((ch)) ? toupper((ch)) : (ch))

/* the allocation size type */

typedef unsigned long int allocT;

/* IEEE standard integer typeshapes (unsigned versions) */

typedef unsigned short int ustdwiT;
typedef unsigned long int ustdsiT;

/* void typeshapes */

typedef void *voidptrT;

/* character pointer type */

typedef char *charptrT;

/* byte and tiny integers */

typedef unsigned char byteT;
typedef byteT *byteptrT;

typedef signed char tiT;
typedef tiT *tiptrT;

/* short integer types */

typedef short int siT, *siptrT;
typedef unsigned short int usiT, *usiptrT;

/* long integer types */

typedef long int liT, *liptrT;
typedef unsigned long int uliT, *uliptrT;

/* long real type */

typedef double lrT, *lrptrT;

/* storage files */

typedef FILE fT;
typedef fT *fptrT;

/* byte length constants */

#define byteL 1
#define wordL 2
#define dwrdL 4
#define qwrdL 8
#define paraL 16
#define pageL 256
#define kiloL 1024
#define megaL 1048576

/* bit width constants */

#define bit1W  1
#define nybbW  4
#define byteW  8
#define wordW 16
#define dwrdW 32
#define qwrdW 64

/* a single bit */

#define bit 0x01

/* bits */

#define bit_00 (bit <<  0)
#define bit_01 (bit <<  1)
#define bit_02 (bit <<  2)
#define bit_03 (bit <<  3)
#define bit_04 (bit <<  4)
#define bit_05 (bit <<  5)
#define bit_06 (bit <<  6)
#define bit_07 (bit <<  7)
#define bit_08 (bit <<  8)
#define bit_09 (bit <<  9)
#define bit_10 (bit << 10)
#define bit_11 (bit << 11)
#define bit_12 (bit << 12)
#define bit_13 (bit << 13)
#define bit_14 (bit << 14)
#define bit_15 (bit << 15)

/* simple masks */

#define nybbM 0x000f
#define byteM 0x00ff
#define longbyteM 0x000000ffL
#define longwordM 0x0000ffffL

/* ANSI screen colors */

typedef siT ascT;
#define ascL 8
#define asc_nil (-1)

#define asc_black   0
#define asc_red     1
#define asc_green   2
#define asc_brown   3
#define asc_blue    4
#define asc_magneta 5
#define asc_cyan    6
#define asc_white   7

/* self type */

typedef siT selfT;
#define selfL 2
#define self_nil (-1)

#define self_ext 0 /* extern (not self) */
#define self_int 1 /* intern (self) */

/* data flow direction */

typedef siT dfdT;
#define dfdL 2
#define dfd_nil (-1)

#define dfd_in  0 /* input */
#define dfd_out 1 /* output */

/* general I/O buffer control block */

typedef struct bcbS
    {
    byteptrT bcb_base;   /* base pointer to storage */
    liT      bcb_count;  /* count of bytes in buffer */
    liT      bcb_length; /* length of each buffer */
    } bcbT, *bcbptrT;

/* powers of ten */

#define one          1
#define ten          10
#define hundred      100
#define thousand     1000
#define ten_thousand 10000
#define million      1000000L
#define billion      1000000000L

/* ASCII definitions */

#define ascii_bel  '\x07'
#define ascii_bs   '\x08'
#define ascii_cr   '\x0d'
#define ascii_del  '\x7f'
#define ascii_esc  '\x1b'
#define ascii_etb  '\x17'
#define ascii_ht   '\x09'
#define ascii_nul  '\x00'
#define ascii_sp   '\x20'
#define ascii_zero '\x30'

/* languages */

typedef siT langT;
#define langL 8
#define lang_nil (-1)

#define lang_deutsch    0
#define lang_english    1
#define lang_espanol    2
#define lang_fide       3
#define lang_francais   4
#define lang_italiano   5
#define lang_nederlands 6
#define lang_svenska    7

/* time */

#define secondL 1L
#define minuteL (secondL * 60L)
#define hourL   (minuteL * 60L)
#define dayL    (hourL   * 24L)

/* time record */

typedef struct timerecS
    {
    liT timerec_day;    /* 0 - 999 */
    liT timerec_hour;   /* 0 -  23 */
    liT timerec_minute; /* 0 -  59 */
    liT timerec_second; /* 0 -  59 */
    } timerecT, *timerecptrT;

/* timestamp string */

#define stampL 20

typedef char stampT[stampL];

/* useful macros */

#if (defined(max))
#undef max
#endif
#define max(x, y) (((x) >= (y)) ? (x) : (y))

#if (defined(min))
#undef min
#endif
#define min(x, y) (((x) >= (y)) ? (y) : (x))

/* pointer to function returning void type */

typedef void (*frvptrT)(void);

/* tag flags */

typedef siT tagfT;

#define tagf_crep (bit << 0) /* concise report item */
#define tagf_estm (bit << 1) /* can be estimated */
#define tagf_perm (bit << 2) /* permanent, can't be cleared */
#define tagf_read (bit << 3) /* read only, can't be written */

/* tags (program environment pairs) */

typedef struct tagS
    {
    charptrT     tag_name;  /* tag identifier */
    charptrT     tag_value; /* string value */
    struct tagS *tag_prev;  /* the previous tag */
    struct tagS *tag_next;  /* the next tag */
    tagfT        tag_flag;  /* tag flag word */
    } tagT, *tagptrT;

/* reserved tags (note display order dependence) */

typedef siT rsvtagT;
#define rsvtagL 7
#define rsvtag_nil (-1)

#define rsvtag_event  0 /* competition event */
#define rsvtag_site   1 /* location */
#define rsvtag_date   2 /* competition date */
#define rsvtag_round  3 /* playing round ordinal */
#define rsvtag_white  4 /* white player */
#define rsvtag_black  5 /* black player */
#define rsvtag_result 6 /* game result */

/* file names */

#define fn_chkp "chkp.gc"  /* -/W/- checkpoint game save (code) */
#define fn_init "init.ci"  /* R/-/- command initialization (text) */

/* the channel index type for external intefacing */

typedef siT channelT;
#define channelL 2

/* communication channel purpose type */

typedef siT ccpT;
#define ccpL 3
#define ccp_nil (-1)

#define ccp_general   0 /* general */
#define ccp_interplay 1 /* move and command communication */
#define ccp_synthesis 2 /* voice synthesizer */

/* remote serial communicator type */

typedef siT rscT;
#define rscL 3
#define rsc_nil (-1)

#define rsc_generic  0 /* general */
#define rsc_microvox 1 /* MicroVox synthesizer */
#define rsc_player   2 /* machine opponent */

/* serial channel status type */

typedef struct scsS
    {
    siT  scs_open; /* open indicator */
    ccpT scs_ccp;  /* communication channel purpose */
    rscT scs_rsc;  /* remote serial communicator */
    } scsT, *scsptrT;

/* command file call list recrod */

typedef struct commfileS
    {
    charptrT          commfile_fn;   /* allocated name */
    fptrT             commfile_fptr; /* file pointer */
    struct commfileS *commfile_prev; /* previous record */
    } commfileT, *commfileptrT;

/* text I/O buffer length */

#define tL 256

/* EPD I/O buffer length */

#define epdL 4096

/* rather large buffer length */

#define rlbL 16384

/* game status */

typedef siT gsT;
#define gsL 13
#define gs_nil (-1)

#define gs_norm  0 /* normal, in progress */
#define gs_bust  1 /* illegal position */
#define gs_wkcm  2 /* white king checkmated */
#define gs_bkcm  3 /* black king checkmated */
#define gs_wksm  4 /* white king stalemated */
#define gs_bksm  5 /* black king stalemated */
#define gs_hmvc  6 /* halfmove clock draw */
#define gs_rep3  7 /* three time position repeat draw */
#define gs_imat  8 /* insufficient material draw */
#define gs_adrw  9 /* agreed draw */
#define gs_wres 10 /* white resigns */
#define gs_bres 11 /* black resigns */
#define gs_over 12 /* program overflow */

/* game termination codes (internal use only) */

typedef siT gtcT;
#define gtcL 4
#define gtc_nil (-1)

#define gtc_none 0 /* game still in progress */
#define gtc_draw 1 /* draw */
#define gtc_wwin 2 /* White wins */
#define gtc_bwin 3 /* Black wins */

/* game termination input markers */

typedef siT gtimT;
#define gtimL 14
#define gtim_nil (-1)

#define gtim_none  0 /* game still in progress: "*" */
#define gtim_drw0  1 /* draw: "1/2-1/2" */
#define gtim_drw1  2 /* draw: "1/2" */
#define gtim_drw2  3 /* draw: "1-2" */
#define gtim_drw3  4 /* draw: "draw" */
#define gtim_drw4  5 /* draw: "drawn" */
#define gtim_wwn0  6 /* White wins: "1-0" */
#define gtim_wwn1  7 /* White wins: "1/0" */
#define gtim_wwn2  8 /* White wins: "1:0" */
#define gtim_bwn0  9 /* Black wins: "0-1" */
#define gtim_bwn1 10 /* Black wins: "0/1" */
#define gtim_bwn2 11 /* Black wins: "0:1" */
#define gtim_res0 12 /* Active player resignation: "resign" */
#define gtim_res1 13 /* Active player resignation: "resigns" */

/* game termination output markers (from internal game termination code) */

typedef siT gtomT;
#define gtomL gtcL
#define gtom_nil (-1)

#define gtom_none 0 /* game still in progress: "*" */
#define gtom_draw 1 /* draw: "1/2-1/2" */
#define gtom_wwin 2 /* White wins: "1-0" */
#define gtom_bwin 3 /* Black wins: "0-1" */

/* pieces (ordering is critical) */

typedef siT pT, *pptrT;
#define pL 8
#define rpL 6
#define p_nil (-1)

#define p_p 0
#define p_n 1
#define p_b 2
#define p_r 3
#define p_q 4
#define p_k 5
#define p_v 6
#define p_x 7

/* colors (ordering is critical) */

typedef siT cT, *cptrT;

#define cQ 2
#define cL (bit << cQ)

#define rcQ 1
#define rcL (bit << rcQ)

#define c_nil (-1)

#define c_w 0
#define c_b 1
#define c_v 2
#define c_x 3

/* color piece combinations (ordering is critical) */

typedef siT cpT;
#define cpL 16
#define rcpL 12
#define cp_nil (-1)

#define cp_wp  0
#define cp_wn  1
#define cp_wb  2
#define cp_wr  3
#define cp_wq  4
#define cp_wk  5
#define cp_bp  6
#define cp_bn  7
#define cp_bb  8
#define cp_br  9
#define cp_bq 10
#define cp_bk 11
#define cp_v0 12
#define cp_x0 13
#define cp_x1 14
#define cp_x2 15

/* test for white cp macro */

#define cp_tstw(cp) ((cp) < cp_bp)

/* active cp mapping macros */

#define actc_p ((actc == c_w) ? cp_wp : cp_bp)
#define actc_n ((actc == c_w) ? cp_wn : cp_bn)
#define actc_b ((actc == c_w) ? cp_wb : cp_bb)
#define actc_r ((actc == c_w) ? cp_wr : cp_br)
#define actc_q ((actc == c_w) ? cp_wq : cp_bq)
#define actc_k ((actc == c_w) ? cp_wk : cp_bk)

/* passive cp mapping macros */

#define pasc_p ((pasc == c_w) ? cp_wp : cp_bp)
#define pasc_n ((pasc == c_w) ? cp_wn : cp_bn)
#define pasc_b ((pasc == c_w) ? cp_wb : cp_bb)
#define pasc_r ((pasc == c_w) ? cp_wr : cp_br)
#define pasc_q ((pasc == c_w) ? cp_wq : cp_bq)
#define pasc_k ((pasc == c_w) ? cp_wk : cp_bk)

/* color-piece bit field type */

typedef siT cpbfT;
#define cpbfL cpL

#define cpbf_wp (bit << cp_wp)
#define cpbf_wn (bit << cp_wn)
#define cpbf_wb (bit << cp_wb)
#define cpbf_wr (bit << cp_wr)
#define cpbf_wq (bit << cp_wq)
#define cpbf_wk (bit << cp_wk)
#define cpbf_bp (bit << cp_bp)
#define cpbf_bn (bit << cp_bn)
#define cpbf_bb (bit << cp_bb)
#define cpbf_br (bit << cp_br)
#define cpbf_bq (bit << cp_bq)
#define cpbf_bk (bit << cp_bk)
#define cpbf_v0 (bit << cp_v0)
#define cpbf_x0 (bit << cp_x0)
#define cpbf_x1 (bit << cp_x1)
#define cpbf_x2 (bit << cp_x2)

/* ranks */

typedef siT rankT;
#define rankM (0x0007)
#define rankQ 3
#define rankL (bit << rankQ)
#define rank_nil (-1)

#define rank_1 0
#define rank_2 1
#define rank_3 2
#define rank_4 3
#define rank_5 4
#define rank_6 5
#define rank_7 6
#define rank_8 7

/* files */

typedef siT fileT;
#define fileM (0x0007)
#define fileQ 3
#define fileL (bit << fileQ)
#define file_nil (-1)

#define file_a 0
#define file_b 1
#define file_c 2
#define file_d 3
#define file_e 4
#define file_f 5
#define file_g 6
#define file_h 7

/* location mappings */

#define map_sq(r, f) (((r) << fileQ | (f)))
#define map_file(sq) ((sq) & 0x07)
#define map_rank(sq) ((sq) >> fileQ)

/* squares */

typedef siT sqT, *sqptrT;
#define sqM (0x003f)
#define sqQ (rankQ + fileQ)
#define sqL (bit << sqQ)
#define sq_nil (-1)

#define sq_a1 map_sq(rank_1, file_a)
#define sq_b1 map_sq(rank_1, file_b)
#define sq_c1 map_sq(rank_1, file_c)
#define sq_d1 map_sq(rank_1, file_d)
#define sq_e1 map_sq(rank_1, file_e)
#define sq_f1 map_sq(rank_1, file_f)
#define sq_g1 map_sq(rank_1, file_g)
#define sq_h1 map_sq(rank_1, file_h)
#define sq_a2 map_sq(rank_2, file_a)
#define sq_b2 map_sq(rank_2, file_b)
#define sq_c2 map_sq(rank_2, file_c)
#define sq_d2 map_sq(rank_2, file_d)
#define sq_e2 map_sq(rank_2, file_e)
#define sq_f2 map_sq(rank_2, file_f)
#define sq_g2 map_sq(rank_2, file_g)
#define sq_h2 map_sq(rank_2, file_h)
#define sq_a3 map_sq(rank_3, file_a)
#define sq_b3 map_sq(rank_3, file_b)
#define sq_c3 map_sq(rank_3, file_c)
#define sq_d3 map_sq(rank_3, file_d)
#define sq_e3 map_sq(rank_3, file_e)
#define sq_f3 map_sq(rank_3, file_f)
#define sq_g3 map_sq(rank_3, file_g)
#define sq_h3 map_sq(rank_3, file_h)
#define sq_a4 map_sq(rank_4, file_a)
#define sq_b4 map_sq(rank_4, file_b)
#define sq_c4 map_sq(rank_4, file_c)
#define sq_d4 map_sq(rank_4, file_d)
#define sq_e4 map_sq(rank_4, file_e)
#define sq_f4 map_sq(rank_4, file_f)
#define sq_g4 map_sq(rank_4, file_g)
#define sq_h4 map_sq(rank_4, file_h)
#define sq_a5 map_sq(rank_5, file_a)
#define sq_b5 map_sq(rank_5, file_b)
#define sq_c5 map_sq(rank_5, file_c)
#define sq_d5 map_sq(rank_5, file_d)
#define sq_e5 map_sq(rank_5, file_e)
#define sq_f5 map_sq(rank_5, file_f)
#define sq_g5 map_sq(rank_5, file_g)
#define sq_h5 map_sq(rank_5, file_h)
#define sq_a6 map_sq(rank_6, file_a)
#define sq_b6 map_sq(rank_6, file_b)
#define sq_c6 map_sq(rank_6, file_c)
#define sq_d6 map_sq(rank_6, file_d)
#define sq_e6 map_sq(rank_6, file_e)
#define sq_f6 map_sq(rank_6, file_f)
#define sq_g6 map_sq(rank_6, file_g)
#define sq_h6 map_sq(rank_6, file_h)
#define sq_a7 map_sq(rank_7, file_a)
#define sq_b7 map_sq(rank_7, file_b)
#define sq_c7 map_sq(rank_7, file_c)
#define sq_d7 map_sq(rank_7, file_d)
#define sq_e7 map_sq(rank_7, file_e)
#define sq_f7 map_sq(rank_7, file_f)
#define sq_g7 map_sq(rank_7, file_g)
#define sq_h7 map_sq(rank_7, file_h)
#define sq_a8 map_sq(rank_8, file_a)
#define sq_b8 map_sq(rank_8, file_b)
#define sq_c8 map_sq(rank_8, file_c)
#define sq_d8 map_sq(rank_8, file_d)
#define sq_e8 map_sq(rank_8, file_e)
#define sq_f8 map_sq(rank_8, file_f)
#define sq_g8 map_sq(rank_8, file_g)
#define sq_h8 map_sq(rank_8, file_h)

/* squares of squares */

#define sqsqQ (sqQ + sqQ)
#define sqsqL (bit << sqsqQ)

/* powers of squares */

#define sqp0L 1
#define sqp1L (sqp0L * sqL)
#define sqp2L (sqp1L * sqL)
#define sqp3L (sqp2L * sqL)
#define sqp4L (sqp3L * sqL)

/* offset generation macros */

#define offset_dxsq(dx, sq) (((dx) << sqQ) + (sq))
#define offset_sqsq(sq0, sq1) (((sq0) << sqQ) + (sq1))
#define offset_rcsqsq(rc, sq0, sq1) \
    (((rc) << sqsqQ) + ((sq0) << sqQ) + (sq1))

/* maximum pieces per side and total */

#define pmaxL (2 * fileL)
#define tmaxL (rcL * pmaxL)

/* the color-piece-square combination */

typedef struct cpsqS
    {
    cpT cpsq_cp; /* the color-piece */
    sqT cpsq_sq; /* the square */
    } cpsqT, *cpsqptrT;

/* direction indices */

typedef siT dxT, *dxptrT;
#define dxL 16
#define rdxL 8
#define dx_nil (-1)

#define dx_0  0
#define dx_1  1
#define dx_2  2
#define dx_3  3
#define dx_4  4
#define dx_5  5
#define dx_6  6
#define dx_7  7
#define dx_8  8
#define dx_9  9
#define dx_a 10
#define dx_b 11
#define dx_c 12
#define dx_d 13
#define dx_e 14
#define dx_f 15

/* direction vectors (file components) */

typedef siT dvfT;
#define dvf_nul 0

#define dvf_0 ( 1)
#define dvf_1 ( 0)
#define dvf_2 (-1)
#define dvf_3 ( 0)
#define dvf_4 ( 1)
#define dvf_5 (-1)
#define dvf_6 (-1)
#define dvf_7 ( 1)
#define dvf_8 ( 2)
#define dvf_9 ( 1)
#define dvf_a (-1)
#define dvf_b (-2)
#define dvf_c (-2)
#define dvf_d (-1)
#define dvf_e ( 1)
#define dvf_f ( 2)

/* direction vectors (rank components) */

typedef siT dvrT;
#define dvr_nul 0

#define dvr_0 ( 0)
#define dvr_1 ( 1)
#define dvr_2 ( 0)
#define dvr_3 (-1)
#define dvr_4 ( 1)
#define dvr_5 ( 1)
#define dvr_6 (-1)
#define dvr_7 (-1)
#define dvr_8 ( 1)
#define dvr_9 ( 2)
#define dvr_a ( 2)
#define dvr_b ( 1)
#define dvr_c (-1)
#define dvr_d (-2)
#define dvr_e (-2)
#define dvr_f (-1)

/* direction vectors */

typedef siT dvT;
#define dv_nul 0

#define dv_0 ((dvr_0 * fileL) + dvf_0)
#define dv_1 ((dvr_1 * fileL) + dvf_1)
#define dv_2 ((dvr_2 * fileL) + dvf_2)
#define dv_3 ((dvr_3 * fileL) + dvf_3)
#define dv_4 ((dvr_4 * fileL) + dvf_4)
#define dv_5 ((dvr_5 * fileL) + dvf_5)
#define dv_6 ((dvr_6 * fileL) + dvf_6)
#define dv_7 ((dvr_7 * fileL) + dvf_7)
#define dv_8 ((dvr_8 * fileL) + dvf_8)
#define dv_9 ((dvr_9 * fileL) + dvf_9)
#define dv_a ((dvr_a * fileL) + dvf_a)
#define dv_b ((dvr_b * fileL) + dvf_b)
#define dv_c ((dvr_c * fileL) + dvf_c)
#define dv_d ((dvr_d * fileL) + dvf_d)
#define dv_e ((dvr_e * fileL) + dvf_e)
#define dv_f ((dvr_f * fileL) + dvf_f)

/* extended board */

typedef siT xbrankT;
#define xbrankQ 4
#define xbrankL (bit << xbrankQ)

typedef siT xbfileT;
#define xbfileQ 4
#define xbfileL (bit << xbfileQ)

typedef siT xbsqT;
#define xbsqQ (xbrankQ + xbfileQ)
#define xbsqL (bit << xbsqQ)

typedef union xbU
    {
    tiT xbm[xbrankL][xbfileL]; /* x-rank/x-file indexing */
    tiT xbv[xbsqL];            /* x-square indexing */
    } xbT, *xbptrT;

/* extended board mappings */

#define map_xbsq(xbr, xbf) ((xbf) | ((xbr) << xbfileQ))
#define map_xbfile(xbsq) ((xbsq) & 0x0f)
#define map_xbrank(xbsq) ((xbsq) >> xbfileQ)

/* extended board translations */

#define trn_xbsq(sq) \
    (((((sq) & 0x38) << 1) + 0x40) | (((sq) & 0x07) + 0x04))
#define trn_xbrank(r) ((r) + 4)
#define trn_xbfile(f) ((f) + 4)

#define trn_sqxb(xbsq) \
    (((((xbsq) & 0xf0) - 0x40) >> 1) | (((xbsq) & 0x0f) - 4))
#define trn_rankxb(xbr) ((xbr) - 4)
#define trn_filexb(xbf) ((xbf) - 4)

/* extended direction vectors */

typedef siT xdvT;
#define xdv_nul (0x00)

#define xdv_0 (( 0 * xbfileL) + 1)
#define xdv_1 (( 1 * xbfileL) + 0)
#define xdv_2 (( 0 * xbfileL) - 1)
#define xdv_3 ((-1 * xbfileL) - 0)
#define xdv_4 (( 1 * xbfileL) + 1)
#define xdv_5 (( 1 * xbfileL) - 1)
#define xdv_6 ((-1 * xbfileL) - 1)
#define xdv_7 ((-1 * xbfileL) + 1)
#define xdv_8 (( 1 * xbfileL) + 2)
#define xdv_9 (( 2 * xbfileL) + 1)
#define xdv_a (( 2 * xbfileL) - 1)
#define xdv_b (( 1 * xbfileL) - 2)
#define xdv_c ((-1 * xbfileL) - 2)
#define xdv_d ((-2 * xbfileL) - 1)
#define xdv_e ((-2 * xbfileL) + 1)
#define xdv_f ((-1 * xbfileL) + 2)

/* the bitboard */

#define bbcvL (qwrdL / byteL)
typedef byteT bbcvT[bbcvL];

#define bbwvL (qwrdL / wordL)
typedef ustdwiT bbwvT[bbwvL];

#define bbsvL (qwrdL / dwrdL)
typedef ustdsiT bbsvT[bbsvL];

typedef union bbU
    {
    bbcvT bbcv; /* unsigned characters/bytes (8 bits) */
    bbwvT bbwv; /* unsigned word integers (16 bits) */
    bbsvT bbsv; /* unsigned short integers (32 bits) */
    } bbT, *bbptrT;

/* regular board */

typedef union rbU
    {
    cpT rbm[rankL][fileL]; /* rank/file indexing */
    cpT rbv[sqL];          /* square indexing */
    } rbT, *rbptrT;

/* bitfield board */

typedef union fbU
    {
    cpbfT fbm[rankL][fileL]; /* rank/file indexing */
    cpbfT fbv[sqL];          /* square indexing */
    } fbT, *fbptrT;

/* nybble board vector */

#define nbL (sqL / (byteW / nybbW))
typedef byteT nbvT[nbL];

/* short integer value board type */

typedef union sibU
    {
    siT sibm[rankL][fileL]; /* rank/file indexing */
    siT sibv[sqL];          /* square indexing */
    } sibT, *sibptrT;

/* tactical search board type */

typedef union tsbU
	{
    tiT tsbm[rankL][fileL]; /* rank/file indexing */
    tiT tsbv[sqL];          /* square indexing */
	} tsbT, *tsbptrT;

/* the halfmove clock draw limit */

#define fifty 50
#define hmvcL (fifty * rcL)

/* flanks */

typedef siT flankT;
#define flankL 2
#define flank_nil (-1)

#define flank_k 0 /* kingside */
#define flank_q 1 /* queenside */

/* the evaluation types (centipawns and millipawns) */

typedef siT cpevT, *cpevptrT; /* centipawn */
typedef siT mpevT, *mpevptrT; /* millipawn */

/* evaluation conversion scaling factors */

#define ecsf_ctm ten      /* the centipawn to millipawn scale factor */
#define ecsf_utc hundred  /* the unipawn to centipawn scale factor */
#define ecsf_utm thousand /* the unipawn to millipawn scale factor */

/* positional evaluation limit and band */

#define cp_poslimit 80
#define mp_posband ((cp_poslimit * ecsf_ctm) / 4)

/* search node color classes */

typedef siT snccT;
#define snccL 3
#define sncc_nil (-1)

#define sncc_red   0 /* first time down in iteration */
#define sncc_green 1 /* null move searches permitted */
#define sncc_blue  2 /* move ordering less important */

/* moveset flag indices (all bits defined) */

typedef siT sfiT;
#define sfiL wordW

#define sfi_abbo  0 /* all moves bad (forced losses) but one */
#define sfi_capt  1 /* capture moveset (capture search) */
#define sfi_cdmm  2 /* checked for drawing/mating moves */
#define sfi_cert  3 /* all legal moves have certain evaluations */
#define sfi_cnpd  4 /* concept notation posted */
#define sfi_dsam  5 /* SAN diambiguated */
#define sfi_exec  6 /* executed */
#define sfi_full  7 /* full width moveset (all moves) */
#define sfi_gcon  8 /* second order generated moveset(s) attached */
#define sfi_mark  9 /* general usage marking bit */
#define sfi_plcd 10 /* policed */
#define sfi_sing 11 /* singleton moveset (suggested move only) */
#define sfi_vsq0 12 /* valid score: Q0 */
#define sfi_vsq1 13 /* valid score: Q1 */

/* moveset flags */

typedef usiT sfT;

#define sf_abbo ((sfT) (bit << sfi_abbo))
#define sf_capt ((sfT) (bit << sfi_capt))
#define sf_cdmm ((sfT) (bit << sfi_cdmm))
#define sf_cert ((sfT) (bit << sfi_cert))
#define sf_cnpd ((sfT) (bit << sfi_cnpd))
#define sf_dsam ((sfT) (bit << sfi_dsam))
#define sf_exec ((sfT) (bit << sfi_exec))
#define sf_full ((sfT) (bit << sfi_full))
#define sf_gcon ((sfT) (bit << sfi_gcon))
#define sf_mark ((sfT) (bit << sfi_mark))
#define sf_plcd ((sfT) (bit << sfi_plcd))
#define sf_sing ((sfT) (bit << sfi_sing))
#define sf_vsq0 ((sfT) (bit << sfi_vsq0))
#define sf_vsq1 ((sfT) (bit << sfi_vsq1))

/* the moveset type */

typedef struct sS
    {
    siT         s_count; /* number of move slots allocated */
    sfT         s_sflag; /* moveset flags */
    cpevT       s_cpebu; /* centipawn evaluation (backed up) */
    cpevT       s_cpeq0; /* centipawn evaluation (Q, zero order) */
    cpevT       s_cpeq1; /* centipawn evaluation (Q, first order) */
    cpevT       s_cpesp; /* centipawn evaluation (speculation) */
    struct mS  *s_mbase; /* pointer to base move in move vector */
    struct mS  *s_mbest; /* pointer to best move in move vector */
    struct mS  *s_mcurr; /* pointer to current move in move vector */
    struct mS  *s_mprev; /* pointer to parent move (other set) */
    struct cnS *s_cnptr; /* concept notation pointer (see -csdef.h-) */
    struct sS  *s_sprev; /* previous moveset header in allocation list */
    struct sS  *s_snext; /* next moveset header in allocation list */
    } sT, *sptrT;

/* special cased moves */

typedef siT scmvT;
#define scmvM (0x0007)
#define scmvQ 3
#define scmvL (bit << scmvQ)
#define scmv_nil (-1)

#define scmv_reg 0
#define scmv_epc 1
#define scmv_cks 2
#define scmv_cqs 3
#define scmv_ppn 4
#define scmv_ppb 5
#define scmv_ppr 6
#define scmv_ppq 7

/* castling availability indicators */

typedef siT caiT;
#define caiL (rcL * flankL)
#define cai_nil (-1)

#define cai_wk ((c_w * flankL) + flank_k)
#define cai_wq ((c_w * flankL) + flank_q)
#define cai_bk ((c_b * flankL) + flank_k)
#define cai_bq ((c_b * flankL) + flank_q)

/* castling index mapper */

#define castim(cai) (bit << (cai))

/* castling flags */

typedef siT castT;
typedef castT *castptrT;

#define cf_wk castim(cai_wk)
#define cf_wq castim(cai_wq)
#define cf_bk castim(cai_bk)
#define cf_bq castim(cai_bq)

/* castling information type */

typedef struct ciS
    {
    sqT ci_homesq; /* king home-square */
    sqT ci_krfrsq; /* king-rook from-square */
    sqT ci_krtosq; /* king-rook to-square */
    sqT ci_kstosq; /* king side castling to-square */
    sqT ci_qrfrsq; /* queen-rook from-square */
    sqT ci_qrtosq; /* queen-rook to-square */
    sqT ci_qstosq; /* queen side castling to-square */
    } ciT;

/* move flag indices (all bits defined) */

typedef siT mfiT;
#define mfiL wordW

#define mfi_anfp  0 /* SAN: file display */
#define mfi_anrp  1 /* SAN: rank display */
#define mfi_book  2 /* move found in opening book */
#define mfi_bust  3 /* illegal (also, san: illegal display) */
#define mfi_chec  4 /* checking (also, san: check display) */
#define mfi_draw  5 /* drawing (also, san: draw display) */
#define mfi_exec  6 /* executed (also, exec tested for checks) */
#define mfi_mark  7 /* general purpose marking bit */
#define mfi_mate  8 /* checkmating (also, san: checkmate display) */
#define mfi_null  9 /* null (empty) move */
#define mfi_orac 10 /* oracular move */
#define mfi_pdrw 11 /* probable draw (imat|hmvc|rep2 plus indirect) */
#define mfi_poor 12 /* poor move found in opening book */
#define mfi_pthr 13 /* pawn threat */
#define mfi_srch 14 /* searched */
#define mfi_xtra 15 /* extra */

/* move flags (all bits defined) */

typedef usiT mfT;

#define mf_anfp ((mfT) (bit << mfi_anfp))
#define mf_anrp ((mfT) (bit << mfi_anrp))
#define mf_book ((mfT) (bit << mfi_book))
#define mf_bust ((mfT) (bit << mfi_bust))
#define mf_chec ((mfT) (bit << mfi_chec))
#define mf_draw ((mfT) (bit << mfi_draw))
#define mf_exec ((mfT) (bit << mfi_exec))
#define mf_mark ((mfT) (bit << mfi_mark))
#define mf_mate ((mfT) (bit << mfi_mate))
#define mf_null ((mfT) (bit << mfi_null))
#define mf_orac ((mfT) (bit << mfi_orac))
#define mf_pdrw ((mfT) (bit << mfi_pdrw))
#define mf_poor ((mfT) (bit << mfi_poor))
#define mf_pthr ((mfT) (bit << mfi_pthr))
#define mf_srch ((mfT) (bit << mfi_srch))
#define mf_xtra ((mfT) (bit << mfi_xtra))

/* move flag mask: certain (node stopping) legal evaluation */

#define mfm_certain \
    (mf_draw | mf_mate | mf_orac | mf_pdrw)

/* move flag mask: notational markers */

#define mfm_notation \
    (mf_anfp | mf_anrp | mf_bust | mf_chec | mf_draw | mf_mate)

/* ply depth limit */

#define plyQ 6
#define plyL (bit << plyQ)

/* ply depth limit squared */

#define plyplyQ (plyQ + plyQ)
#define plyplyL (bit << plyplyQ)

/* maximal book construction depth (based on notational lookahead) */

#define bkmcdL (plyL - 2)

/* opening book code record type for census vector */

typedef struct obcS
	{
	liT obc_count; /* count subtree nodes */
	siT obc_pflag; /* poor move flag */
	} obcT, *obcptrT;

/* minimum and maximum (placeholder) evaluations */

#define cpev_bust (-32767)
#define cpev_best 32767

/* illegal evaluation */

#define cpev_wrck (-32768)

/* draw evaluation */

#define cpev_draw 0

/* mate evaluation (at ply 0; subract 1 per ply) */

#define cpev_mate cpev_best

/* resignation thresholds */

#define cpev_rsgn (-(pval_r + pval_p))
#define cpev_wham (2 * cpev_rsgn)

/* evaluation macros */

#define ct_bigl(cpev) ((-(cpev)) >= (cpev_mate - (2 * pageL)))
#define ct_bigw(cpev) ((cpev) >= (cpev_mate - (2 * pageL)))
#define ct_mate(cpev) ((cpev) >= (cpev_mate - pageL))
#define ct_wump(cpev) ((-(cpev)) >= (cpev_mate - pageL))

/* mate and loss synthesis macros */

#define synth_mate(n) (cpev_mate - ((n) * 2) + 1)
#define synth_loss(n) (cpev_bust + ((n) * 2))

/* piece values */

#define pval_p 100
#define pval_n 325
#define pval_b 333
#define pval_r 500
#define pval_q 900
#define pval_k   0 /* king value not generally used */
#define pval_v   0 /* vacant */
#define pval_x   0 /* border */

/* lone king macro */

#define lone_king(c) (envn.envn_mcpv[(c)] == pval_k)

/* the move type */

typedef struct mS
    {
    mfT   m_flag; /* move flags */
    sqT   m_frsq; /* from square */
    sqT   m_tosq; /* to square */
    cpT   m_frcp; /* from color-piece */
    cpT   m_tocp; /* to color-piece */
    scmvT m_scmv; /* special cased move indicator */
    cpevT m_prel; /* centipawn preliminary evaluation */
    cpevT m_eval; /* centipawn search result evaluation */
    sptrT m_cptr; /* pointer to containing moveset */
    sptrT m_dptr; /* pointer to descendant moveset */
    } mT, *mptrT;

/* the move list type */

typedef struct mlstS
    {
    mptrT         mlst_mptr; /* pointer to a copy of the move */
    struct mlstS *mlst_next; /* the next entry in this list */
    } mlstT, *mlstptrT;

/* null move testing macros */

#define null_move(m) ((m).m_flag & mf_null)
#define null_move_ref(mptr) ((mptr)->m_flag & mf_null)

/* the null limited testing macros */

#define null_limited_move(lm) ((lm).lm_flag & mf_null)
#define null_limited_move_ref(lmptr) ((lmptr)->lm_flag & mf_null)

/* same move testing macros */

#define same_move(m0, m1) \
    ( \
        (((m0).m_tosq == (m1).m_tosq) && \
        ((m0).m_frsq == (m1).m_frsq) && \
        ((m0).m_frcp == (m1).m_frcp) && \
        ((m0).m_tocp == (m1).m_tocp) && \
        ((m0).m_scmv == (m1).m_scmv)) \
    )

#define same_move_ref(m0ptr, m1ptr) \
    ( \
        (((m0ptr)->m_tosq == (m1ptr)->m_tosq) && \
        ((m0ptr)->m_frsq == (m1ptr)->m_frsq) && \
        ((m0ptr)->m_frcp == (m1ptr)->m_frcp) && \
        ((m0ptr)->m_tocp == (m1ptr)->m_tocp) && \
        ((m0ptr)->m_scmv == (m1ptr)->m_scmv)) \
    )

/* compressed move type and access macros */

typedef siT cmT, *cmptrT;

#define cm_frsq(cm) (((cm) >> (sqQ + scmvQ)) & sqM)
#define cm_tosq(cm) (((cm) >> scmvQ) & sqM)
#define cm_scmv(cm) ((cm) & scmvM)

#define make_cm(frsq, tosq, scmv) \
    (((frsq) << (sqQ + scmvQ)) | ((tosq) << scmvQ) | (scmv))

/* tiny move type */

typedef struct tmS
	{
	tiT tm_frsq; /* from square */
	tiT tm_tosq; /* to square */
	tiT tm_frcp; /* from color-piece */
	tiT tm_tocp; /* to color-piece */
	} tmT, *tmptrT;

/* tactical search move type */

#define tsmf_anfp (bit << 0) /* algebraic notation: file letter print */
#define tsmf_anrp (bit << 1) /* algebraic notation: rank digit print */
#define tsmf_bust (bit << 2) /* illegal */
#define tsmf_chec (bit << 3) /* checking move */
#define tsmf_draw (bit << 4) /* drawing evaluation */
#define tsmf_mate (bit << 5) /* checkmating move */
#define tsmf_null (bit << 6) /* checkmating move */
#define tsmf_srch (bit << 7) /* move searched */

typedef struct tsmS
	{
	tiT   tsm_frsq; /* from square */
	tiT   tsm_tosq; /* to square */
	tiT   tsm_frcp; /* from color-piece */
	tiT   tsm_tocp; /* to color-piece */
	tiT   tsm_scmv; /* special case move indication */
	byteT tsm_flag; /* flag byte */
	cpevT tsm_prel; /* preliminaty move ordering value */
	} tsmT, *tsmptrT;

/* killer move type */

typedef struct kmS
    {
    sqT km_frsq;  /* from square */
    sqT km_tosq;  /* to square */
    siT km_usage; /* number of references */
    } kmT, *kmptrT;

/* grouped killer move type */

typedef struct gkmS
    {
    kmT gkm_m0; /* primary */
    kmT gkm_m1; /* secondary */
    kmT gkm_m2; /* tertiary */
    } gkmT, *gkmptrT;

/* the limited move type */

typedef struct lmS
    {
    mfT   lm_flag; /* move flags */
    sqT   lm_frsq; /* from square */
    sqT   lm_tosq; /* to square */
    cpT   lm_frcp; /* from color-piece */
    cpT   lm_tocp; /* to color-piece */
    scmvT lm_scmv; /* special cased move indicator */
    } lmT, *lmptrT;

/* squares only move type */

typedef struct smS
    {
    tiT sm_frsq; /* from square */
    tiT sm_tosq; /* to square */
    } smT, *smptrT;

/* string version of algebraic notation (at least one trailing NUL) */

#define sanL 16

typedef char sanT[sanL];
typedef sanT *sanptrT;

/* extended string algebraic notation type */

#define esanL 128

typedef char esanT[esanL];
typedef esanT *esanptrT;

/* vocalized string algebraic notation type */

#define vsanL 512

typedef char vsanT[vsanL];
typedef vsanT *vsanptrT;

/* notation mode indication type */

typedef siT nmT;
#define nmL 8
#define nm_nil (-1) /* no notation mode */

#define nm_algebraic  0 /* standard algebraic */
#define nm_coordinate 1 /* international coordinate */
#define nm_exp0       2 /* experimental 0 */
#define nm_exp1       3 /* experimental 1 */
#define nm_exp2       4 /* experimental 2 */
#define nm_exp3       5 /* experimental 3 */
#define nm_exp4       6 /* experimental 4 */
#define nm_exp5       7 /* experimental 5 */

/* notation variant priority ordered index set (most variable first) */

typedef siT nvpT;
#define nvpL 14

#define nvp_case  0 /* character case sensitivity */
#define nvp_chec  1 /* checking indicators */
#define nvp_mate  2 /* mating indicators */
#define nvp_capt  3 /* capture indicators */
#define nvp_pcdr  4 /* pawn capture destination rank */
#define nvp_prom  5 /* promotion indicators */
#define nvp_cast  6 /* castling indicators */
#define nvp_epsq  7 /* en passant capture indicators */
#define nvp_extf  8 /* extra file letter */
#define nvp_extr  9 /* extra rank digit */
#define nvp_dash 10 /* source/destination separator */
#define nvp_pawn 11 /* pawn movement indicator */
#define nvp_cmpl 12 /* captured man piece leter */
#define nvp_anno 13 /* annotation markers */

typedef siT nvpcvT[nvpL];   /* count vector */

/* move generation limit */

#define gmL pageL

/* the last fullmove play number */

#define fmpL 200

/* game score (move list) limit */

#define gscoreL (fmpL * rcL)

/* hash table position address and signature types */

typedef uliT xhacT, *xhacptrT;
typedef uliT xhscT, *xhscptrT;

/* the hash table exclusive-or record type (constant values) */

typedef struct hxS
    {
    xhacT hx_hac; /* hash address code */
    xhscT hx_hsc; /* hash signature code */
    } hxT, *hxptrT;

/* main transposition table cache fold factor (subtables per color) */

#define ttcfL 4

/* main transposition table return indication type */

typedef siT ttriT, *ttriptrT;
#define ttriL 4
#define ttri_nil (-1)

#define ttri_lower 0 /* entry has lower bound */
#define ttri_exact 1 /* entry has exact bound */
#define ttri_upper 2 /* entry has upperm bound */
#define ttri_fault 3 /* entry not located */

/* canonical move ordinals */

typedef byteT cordT, *cordptrT;

/* environment record */

typedef struct envnS
    {
    castT envn_cast;      /* castling availability */
    sqT   envn_epsq;      /* en passant capture square */
    xhacT envn_mhac;      /* main hash code position address */
    xhacT envn_phac;      /* pawn hash code position address */
    xhscT envn_mhsc;      /* main hash code position signature */
    xhscT envn_phsc;      /* pawn hash code position signature */
    siT   envn_hmvc;      /* halfmove clock */
    siT   envn_fmvn;      /* fullmove number */
    cpevT envn_mcpv[rcL]; /* material centipawn score per side */
    } envnT, *envnptrT;

/* the move tree retained depth (critical: mtrdL >= 1) */

#define mtrdL 2

/* the history type */

#define histL (gscoreL + plyL)

typedef struct histS
    {
    cT    hist_actc; /* active color */
    castT hist_cast; /* castling availability */
    sqT   hist_epsq; /* ep capture square */
    siT   hist_fmvn; /* full move number */
    xhacT hist_mhac; /* main hash code address (rep chk ply > 1) */
    xhscT hist_mhsc; /* main hash code signature (rep chk ply > 1) */
    siT   hist_hmvc; /* halfmove clock */
    cT    hist_pasc; /* passive color */
    lmT   hist_lm;   /* move to be played */
    nbvT  hist_nbv;  /* stored nybble board vector */
    } histT, *histptrT;

/* search termination reason codes (primary reason) */

typedef siT strcT;
#define strcL 16

#define strc_none  0 /* no reason, or nonterminated search */
#define strc_bigl  1 /* big loss detected */
#define strc_bigw  2 /* big win detected */
#define strc_book  3 /* book move located */
#define strc_cert  4 /* certain move located */
#define strc_frcd  5 /* forced move located */
#define strc_full  6 /* full search completed */
#define strc_intr  7 /* interrupted and not resumed */
#define strc_iter  8 /* iteration level limit */
#define strc_mate  9 /* mating move located */
#define strc_node 10 /* node limit */
#define strc_obvs 11 /* obvious move located */
#define strc_save 12 /* saving drawing move located */
#define strc_sing 13 /* single move exists */
#define strc_targ 14 /* target move located */
#define strc_time 15 /* general time expiration */

/* strategies */

typedef siT strtT;
#define strtL 4
#define strt_nil (-1) /* no strategy */

#define strt_knowbs 0 /* knowledge based search */
#define strt_privar 1 /* principal variation search */
#define strt_random 2 /* random play */
#define strt_testds 3 /* test development search */

#define default_strt strt_privar

/* the game reader translation mode type */

typedef siT grtmT;
#define grtmL 6

#define grtm_none 0 /* no output */
#define grtm_epd  1 /* EPD output */
#define grtm_hex  2 /* hex output */
#define grtm_pgc  3 /* PGC output */
#define grtm_pgn  4 /* PGN output */
#define grtm_var  5 /* variation output */

/* PGN Seven Tag Roster names */

typedef siT pgnstrT, *pgnstrptrT;
#define pgnstrL 7
#define pgnstr_nil (-1)

#define pgnstr_event  0
#define pgnstr_site   1
#define pgnstr_date   2
#define pgnstr_round  3
#define pgnstr_white  4
#define pgnstr_black  5
#define pgnstr_result 6

/* clock display array length */

#define clks_dL 3
#define clks_hL 2
#define clks_mL 2
#define clks_sL 2
#define clksL (clks_dL + 1 + clks_hL + 1 + clks_mL + 1 + clks_sL + 1)

/* number of time control periods */

#define tcntlL 10

/* the time control type */

typedef struct tcntlS
    {
    liT tcntl_mvc; /* moves in period */
    liT tcntl_sec; /* seconds in period */
    } tcntlT, *tcntlptrT;

/* operator overhead time (seconds) */

#define operatorL 5

/* ordinal string vector length */

#define decadeL ten

/* printing format strings */

#define pfs_li          "%ld"
#define pfs_si          "%hd"
#define pfs_color_label "%-9.9s"
#define pfs_move        "%-10.10s"
#define pfs_mn          "%3hd "
#define pfs_mn_dot      "%3hd. "

/* scanning format strings */

#define sfs_li "%ld"
#define sfs_si "%hd"

/* general output: nominal field and tab separations */

#define nfsL 3
#define ntsL 2

/* general output: column count, right margin size, and usable width */

#define soccL 80
#define sormL 0
#define souwL (soccL - sormL)

/*<<< defs.h: EOF */
