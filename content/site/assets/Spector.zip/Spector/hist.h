/*>>> hist.h: subprogram prototypes for hist.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void HistoryPush(mptrT mptr);
void HistoryPop(void);
void HistoryDrop(void);
void HistoryClear(void);
void OrdinalSet(cordT cord);

/*<<< hist.h: EOF */
