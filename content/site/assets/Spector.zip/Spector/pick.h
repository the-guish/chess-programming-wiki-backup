/*>>> pick.h: subprogram prototypes for pick.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

mptrT PickBestPrel(sptrT sptr);
mptrT PickThisMove(sptrT sptr, mptrT mptr);
mptrT PickSingleton(sptrT sptr);
mptrT PickLinear(sptrT sptr);

/*<<< pick.h: EOF */
