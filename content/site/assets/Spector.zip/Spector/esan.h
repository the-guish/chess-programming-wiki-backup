/*>>> esan.h: subprogram prototypes for esan.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void ESANMove(mptrT mptr, esanT esan);

/*<<< esan.h: EOF */
