/*>>> csprnt.h: subprogram prototypes for csprnt.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CSPrintDescription(sptrT sptr);

/*<<< csprnt.h: EOF */
