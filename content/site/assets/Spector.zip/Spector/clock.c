/*>>> clock.c: clock access and time control routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "clock.h"
#include "print.h"
#include "sysutil.h"
#include "util.h"

/*--> ClockClear: clear the clock settings */
nonstatic
void
ClockClear(void)
{
clockv[c_w] = clockv[c_b] = 0;
clockm = time(NULL);
clockflag = 0;

return;
}

/*--> ClockUpdate: update the clock settings */
nonstatic
void
ClockUpdate(void)
{
liT t;

/* update only if the clock is running */

if (clockflag)
	{
	/* fetch the current time */

	t = time(NULL);

	/* update according to ponder search status */

	if (ponder_active)
		clockv[p0pasc] += (t - clockm);
	else
		clockv[p0actc] += (t - clockm);

	/* set mark for next update */

	clockm = t;
	};

return;
}

/*--> ClockStart: start stopped clocks */
nonstatic
void
ClockStart(void)
{
if (!clockflag)
	{
	clockflag = 1;
	clockm = time(NULL);
	};

return;
}

/*--> ClockStop: stop started clocks */
nonstatic
void
ClockStop(void)
{
if (clockflag)
	{
	ClockUpdate();
	clockflag = 0;
	};

return;
}

/*--> ClockAMET: adjust for move entry overhead time for the active color */
nonstatic
void
ClockAMET(void)
{
if (clockflag)
	{
	ClockUpdate();
	clockv[p0actc] += operatorL;
	if (clockv[p0pasc] < operatorL)
		clockv[p0pasc] = 0;
	else
		clockv[p0pasc] -= operatorL;
	ClockUpdate();
	};
return;
}

/*--> ClockDecode: decode a seconds count into an hms string */
nonstatic
void
ClockDecode(liT val, char clks[clksL])
{
timerecT tr;

EncodeTimeRecord(val, &tr);
(void) sprintf(clks, "%03ld.%02ld:%02ld:%02ld",
	tr.timerec_day, tr.timerec_hour, tr.timerec_minute, tr.timerec_second);

return;
}

/*--> ClockRecode: recode a liT dddhhmmss into seconds */
nonstatic
liT
ClockRecode(liT val)
{
liT secs, cval, td, th, tm;

secs = 0;
cval = val;
if (cval >= million)
	{
	td = (cval / million);
	secs += td * dayL;
	cval -= td * million;
	};
if (cval >= ten_thousand)
	{
	th = (cval / ten_thousand);
	secs += th * hourL;
	cval -= th * ten_thousand;
	};
if (cval >= hundred)
	{
	tm = (cval / hundred);
	secs += tm * minuteL;
	cval -= tm * hundred;
	};
secs += cval;

return (secs);
}

/*--> TimeControlReset: time control reset */
nonstatic
void
TimeControlReset(void)
{
siT i;

for (i = 0; i < (tcntlL - 1); i++)
	{
	tcntlv[i].tcntl_mvc = 60;
	tcntlv[i].tcntl_sec = 30 * minuteL;
	};
tcntlv[tcntlL - 1].tcntl_mvc = 0;
tcntlv[tcntlL - 1].tcntl_sec = 0;

return;
}

/*--> TimeControlPeriod: calculate current time control period */
nonstatic
siT
TimeControlPeriod(void)
{
siT period, flag;
liT current_mvc, current_sec, sigma_mvc;

period = 0;
flag = 0;
sigma_mvc = 0;
while (!flag)
	if (period == (tcntlL - 1))
		flag = 1;
	else
		{
		current_mvc = tcntlv[period].tcntl_mvc;
		current_sec = tcntlv[period].tcntl_sec;
		if ((current_mvc == 0) || (current_sec == 0))
			flag = 1;
		else
			{
			sigma_mvc += current_mvc;
			if (sigma_mvc >= envn.envn_fmvn)
				flag = 1;
			else
				period++;
			};
		};

return (period);
}

/*--> ClockSelectStart: start clocking for program move */
nonstatic
void
ClockSelectStart(void)
{
siT period, i;
liT sigma_mvc, sigma_sec, current_mvc, current_sec, remain_mvc, remain_sec;
liT limit_sec;

/* update clocks */

ClockUpdate();

/* fetch current period and scalars */

period = TimeControlPeriod();
current_mvc = tcntlv[period].tcntl_mvc;
current_sec = tcntlv[period].tcntl_sec;

/* calculate summations */

sigma_mvc = 0;
sigma_sec = 0;
for (i = 0; i <= period; i++)
	{
	sigma_mvc += tcntlv[i].tcntl_mvc;
	sigma_sec += tcntlv[i].tcntl_sec;
	};

/* determine total remaining seconds in current time control */

remain_sec = sigma_sec - clockv[p0actc];

/* determine maximum upper limit on allocated seconds */

limit_sec = remain_sec / 4;

/* check for instantaneous */

if (current_sec == 0)
	sec_alloc = 0;
else
	/* check for game limit */

	if (current_mvc == 0)
		sec_alloc = ((sigma_sec - clockv[p0actc]) / 20);
	else
		{
		/* determine count of remaining moves in the current time control */

		remain_mvc = sigma_mvc - (envn.envn_fmvn - 1);

		/* calculate seconds for current selection */

		sec_alloc = remain_sec / remain_mvc;
		};

/* don't use more that one quarter of remaining time */

if (sec_alloc > limit_sec)
	sec_alloc = limit_sec;

/* make sure initial allocated time is non-negative */

if (sec_alloc < 0)
	sec_alloc = 0;

/* set time control start time */

tcntl_et0 = clockv[p0actc];

/* set budgeted time (per move) for various checkpoints */

tcntl_obvious = tcntl_et0 + (sec_alloc / 3) - operatorL;
tcntl_next_iteration = tcntl_et0 + (sec_alloc / 2) - operatorL;
tcntl_next_candidate = tcntl_et0 + sec_alloc - operatorL;

/* set the mondo overflow limit */

tcntl_mondo = tcntl_et0 + MinLI((sec_alloc * 4), limit_sec) - operatorL;

/* report */

if (optnv[optn_verb] && ponder_trace)
	{
	/* seconds */

	if (clockflag)
		{
		PrStr("Seconds allocated for this move: ");
		PrCondOrdLINL(sec_alloc);
		if (countdown_timer != 0)
			{
			PrStr("Countdown timer setting: ");
			PrCondOrdLINL(countdown_timer);
			};
		}
	else
		{
		if (countdown_timer == 0)
			PrLine("Unlimited time allocated for this move.");
		else
			{
			PrStr("Countdown timer active; seconds allocated: ");
			PrCondOrdLINL(countdown_timer);
			};
		};

	/* nodes */

	if (node_countdown != 0)
		{
		PrStr("Node countdown active; nodes allocated: ");
		PrCondOrdLINL(node_countdown);
		};
	};

return;
}

/*--> ClockModifyPonderBudget: adjust for ponder transform */
nonstatic
void
ClockModifyPonderBudget(void)
{
liT t;

/* called immediately after the ponder search is transformed */

t = time(NULL) - search_start_time;
tcntl_obvious -= t;
tcntl_next_iteration -= t;
tcntl_next_candidate -= t;
tcntl_mondo -= t;

return;
}

/*--> ClockPastTime: return true if some budget exceeded */
static
siT
ClockPastTime(liT budget)
{
siT flag;

/* the clock must be running and the ponder search must be inactive */

if (clockflag && !ponder_active)
	{
	ClockUpdate();
	if (clockv[p0actc] > budget)
		flag = 1;
	else
		flag = 0;
	}
else
	flag = 0;

return (flag);
}

/*--> ClockPastObvious: check if obvious response budget exceeded */
nonstatic
siT
ClockPastObvious(void)
{

return (clockflag ? ClockPastTime(tcntl_obvious) : 0);
}

/*--> ClockPastNextIteration: check if next iteration budget exceeded */
nonstatic
siT
ClockPastNextIteration(void)
{

return (clockflag ? ClockPastTime(tcntl_next_iteration) : 0);
}

/*--> ClockPastNextCandidate: check if next candidate budget exceeded */
nonstatic
siT
ClockPastNextCandidate(void)
{

return (clockflag ? ClockPastTime(tcntl_next_candidate) : 0);
}

/*--> ClockPastMondo: check if mondo budget exceeded */
nonstatic
siT
ClockPastMondo(void)
{

return (clockflag ? ClockPastTime(tcntl_mondo) : 0);
}

/*--> CountdownTimerExpired: determine if countdown timer has expired */
nonstatic
siT
CountdownTimerExpired(void)
{
siT flag;

/* note the check for the ponder search to be inactive */

if ((countdown_timer > 0) && !ponder_active &&
	(countdown_timer <= (time(NULL) - search_start_time)))
	flag = 1;
else
	flag = 0;

return (flag);
}

/*--> NodeCountdownExpired: determine if node countdown has expired */
nonstatic
siT
NodeCountdownExpired(void)
{
siT flag;

/* note the check for the ponder search to be inactive */

if ((node_countdown > 0) && !ponder_active &&
	(node_countdown <= (count_node - search_start_node)))
	flag = 1;
else
	flag = 0;

return (flag);
}

/*<<< clock.c: EOF */
