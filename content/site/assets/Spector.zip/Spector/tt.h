/*>>> tt.h: subprogram prototypes for tt.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void TTPrintStatistics(void);
void TTResetStatistics(void);
void TTReportUsage(void);
void TTReset(void);
void TTSetOrder(liT order);
void TTInit(void);
void TTTerm(void);
void TTScrub(void);
void TTColorPieceSq(cpT cp, sqT sq);
void TTCastlingAvailability(caiT cai);
void TTEnPassantTargetFile(void);
void TTColorPieceSqSq(cpT cp, sqT sq0, sqT sq1);
void TTCreate(void);
void TTStashMove(mptrT mptr);
mptrT TTFetchMove(void);
mptrT TTFetchMoveExact(void);
void TTInsert(mptrT mptr, cpevT alpha, cpevT beta, cpevT score);
mptrT TTExtract(cpevptrT alphaptr, cpevptrT betaptr, cpevptrT scoreptr);

/*<<< tt.h: EOF */
