/*>>> cfc.h: subprogram prototypes for cfc.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CFCCursorOn(void);
void CFCCursorOff(void);
void CFCSetXYCVP(cvpptrT cvpptr, siT x, siT y);
void CFCPutCharCVP(cvpptrT cvpptr, siT x, siT y, siT c);
void CFCPutStrCVP(cvpptrT cvpptr, siT x, siT y, charptrT s);
void CFCPutVCACVP(cvpptrT cvpptr, siT x, siT y, vcaT vca);
void CFCPutBlanksCVP(cvpptrT cvpptr);
cvpptrT CFCNewCVP(charptrT label, siT flags, siT x0, siT y0, siT xs, siT ys);
void CFCReleaseCVP(cvpptrT cvpptr);
void CFCDrawDataCVP(cvpptrT cvpptr);
void CFCDrawBorderCVP(cvpptrT cvpptr);
void CFCDrawWallpaper(void);
void CFCEnter(void);
void CFCExit(void);
void CFCInit(void);
void CFCTerm(void);

/*<<< cfc.h: EOF */
