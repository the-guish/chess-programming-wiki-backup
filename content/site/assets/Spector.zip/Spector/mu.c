/*>>> mu.c: general move utility routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "mu.h"
#include "pred.h"
#include "sysutil.h"

/**** Statics */

/* synthesized move return storage */

static mT synth_m;

/* the move returned via reference after expansion */

static mT compact_m;

/*--> SetUpRootMove: set up the root move node */
nonstatic
void
SetUpRootMove(void)
{
histptrT histptr;

root_m = null_m;

if (histn == 0)
	{
	root_m.m_flag |= mf_exec;
	if (bb_tstand(acbbv[pasc], cpbbv[actc_k]))
		root_m.m_flag |= mf_chec;
	}
else
	{
	histptr = histcurr - 1;
	ConvertFromLimitedMove(&histptr->hist_lm, &root_m);
	};

root_m.m_dptr = root_sptr;
if (root_sptr != NULL)
	root_sptr->s_mprev = &root_m;

return;
}

/*--> SanityCheck: quick check determine if a move is pseudolegal */
nonstatic
siT
SanityCheck(mptrT mptr)
{
siT flag;

/* set default */

flag = 1;

/* basic placement test */

if ((mptr->m_frcp != local.rbv[mptr->m_frsq]) ||
	(mptr->m_tocp != local.rbv[mptr->m_tosq]))
	flag = 0;
else
	switch (mptr->m_frcp)
		{
		case cp_wp:
			if (mptr->m_scmv == scmv_reg)
				if (mptr->m_tocp == cp_v0)
					if (mptr->m_tosq == (mptr->m_frsq + dv_1))
						flag = 1;
					else
						flag = (local.rbv[mptr->m_frsq + dv_1] == cp_v0);
				else
					flag = bb_tstsq(afbbv[mptr->m_frsq], mptr->m_tosq);
			else
				if (mptr->m_scmv == scmv_epc)
					flag = (envn.envn_epsq == mptr->m_tosq);
				else
					if (mptr->m_tocp == cp_v0)
						flag = (local.rbv[mptr->m_tosq] == cp_v0);
					else
						flag = bb_tstsq(afbbv[mptr->m_frsq], mptr->m_tosq);
			break;

		case cp_bp:
			if (mptr->m_scmv == scmv_reg)
				if (mptr->m_tocp == cp_v0)
					if (mptr->m_tosq == (mptr->m_frsq + dv_3))
						flag = 1;
					else
						flag = (local.rbv[mptr->m_frsq + dv_3] == cp_v0);
				else
					flag = bb_tstsq(afbbv[mptr->m_frsq], mptr->m_tosq);
			else
				if (mptr->m_scmv == scmv_epc)
					flag = (envn.envn_epsq == mptr->m_tosq);
				else
					if (mptr->m_tocp == cp_v0)
						flag = (local.rbv[mptr->m_tosq] == cp_v0);
					else
						flag = bb_tstsq(afbbv[mptr->m_frsq], mptr->m_tosq);
			break;

		case cp_wn:
		case cp_bn:
		case cp_wb:
		case cp_bb:
		case cp_wr:
		case cp_br:
		case cp_wq:
		case cp_bq:
			flag = bb_tstsq(afbbv[mptr->m_frsq], mptr->m_tosq);
			break;

		case cp_wk:
		case cp_bk:
			if (mptr->m_scmv == scmv_reg)
				flag = bb_tstsq(afbbv[mptr->m_frsq], mptr->m_tosq);
			else
				if (mptr->m_scmv == scmv_cks)
					flag = CastlingFlankOkay(flank_k);
				else
					flag = CastlingFlankOkay(flank_q);
			break;

		default:
			SwitchFault("SanityCheck");
			break;
		};

return (flag);
}

/*--> ExtraSanityCheck: heavy duty check determine if move is pseudolegal */
nonstatic
siT
ExtraSanityCheck(mptrT mptr)
{
siT flag;

/* null test */

if ((mptr == NULL) || (mptr->m_flag & mf_null))
	flag = 0;
else

	/* square, piece, and special case bounds test */

	if ((mptr->m_frsq < sq_a1) || (mptr->m_frsq > sq_h8) ||
		(mptr->m_tosq < sq_a1) || (mptr->m_tosq > sq_h8) ||
		(mptr->m_frcp < cp_wp) || (mptr->m_frcp > cp_bk) ||
		(mptr->m_tocp < cp_wp) || (mptr->m_tocp > cp_v0) ||
		(mptr->m_scmv < scmv_reg) || (mptr->m_scmv > scmv_ppq))
		flag = 0;
	else
		flag = SanityCheck(mptr);

return (flag);
}

/*--> SetCertaintyScore: assign an evaluation for a certain move */
nonstatic
void
SetCertaintyScore(mptrT mptr)
{
if (mptr->m_flag & mfm_certain)
	if (mptr->m_flag & (mf_draw | mf_pdrw))
		mptr->m_eval = cpev_draw;
	else
		if (mptr->m_flag & mf_mate)
			mptr->m_eval = synth_mate(1) - ply;

return;
}

/*--> SameMoveRef: check if two move references indicate the same move */
nonstatic
siT
SameMoveRef(mptrT mptr0, mptrT mptr1)
{

return (same_move_ref(mptr0, mptr1));
}

/*--> ConvertFromLimitedMove: convert via reference lmT -> mT */
nonstatic
void
ConvertFromLimitedMove(lmptrT lmptr, mptrT mptr)
{
/* assign from limited components */

mptr->m_flag = lmptr->lm_flag;
mptr->m_frcp = lmptr->lm_frcp;
mptr->m_frsq = lmptr->lm_frsq;
mptr->m_tocp = lmptr->lm_tocp;
mptr->m_tosq = lmptr->lm_tosq;
mptr->m_scmv = lmptr->lm_scmv;

/* clear remainders */

mptr->m_eval = mptr->m_prel = cpev_bust;
mptr->m_cptr = mptr->m_dptr = NULL;

return;
}

/*--> ConvertToLimitedMove: convert via reference mT -> lmT */
nonstatic
void
ConvertToLimitedMove(mptrT mptr, lmptrT lmptr)
{
lmptr->lm_flag = mptr->m_flag;
lmptr->lm_frcp = mptr->m_frcp;
lmptr->lm_frsq = mptr->m_frsq;
lmptr->lm_tocp = mptr->m_tocp;
lmptr->lm_tosq = mptr->m_tosq;
lmptr->lm_scmv = mptr->m_scmv;

return;
}

/*--> MergeMoveFlags: merge interesting flags to first from second move */
nonstatic
void
MergeMoveFlags(mptrT mptr0, mptrT mptr1)
{
mptr0->m_flag |= (mptr1->m_flag & mfm_certain);

return;
}

/*--> ExpandCompactMove: construct a type mT from a type cmT move */
nonstatic
mptrT
ExpandCompactMove(cmT cm)
{
mptrT mptr;
siT flag;

/* set conversion default (okay) */

flag = 1;

/* assign all components */

compact_m.m_flag = 0;
compact_m.m_frcp = local.rbv[compact_m.m_frsq = cm_frsq(cm)];
compact_m.m_tocp = local.rbv[compact_m.m_tosq = cm_tosq(cm)];
compact_m.m_scmv = cm_scmv(cm);
compact_m.m_eval = compact_m.m_prel = cpev_bust;
compact_m.m_cptr = compact_m.m_dptr = NULL;

/* from square color test */

if (flag)
	if (cv_c_cpv[compact_m.m_frcp] != actc)
		flag = 0;

/* to square color test */

if (flag)
	if (cv_c_cpv[compact_m.m_tocp] == actc)
		flag = 0;

/* special case move test */

if (flag)
	switch (compact_m.m_scmv)
		{
		case scmv_reg:
			break;

		case scmv_epc:
			if (bb_tstnotsq(afbbv[compact_m.m_frsq],
					compact_m.m_tosq) ||
				(compact_m.m_frcp != actc_p) ||
				(compact_m.m_tosq != envn.envn_epsq))
				flag = 0;
			break;

		case scmv_cks:
			if (!CastlingFlankOkay(flank_k))
				flag = 0;
			break;

		case scmv_cqs:
			if (!CastlingFlankOkay(flank_q))
				flag = 0;
			break;

		case scmv_ppn:
		case scmv_ppb:
		case scmv_ppr:
		case scmv_ppq:
			if (compact_m.m_frcp != actc_p)
				flag = 0;
			else
				if (bb_tstsq(afbbv[compact_m.m_frsq],
					compact_m.m_tosq))
					{
					if (cv_c_cpv[local.rbv[compact_m.m_tosq]] != pasc)
						flag = 0;
					}
				else
					{
					if (cv_c_cpv[local.rbv[compact_m.m_tosq]] != c_v)
						flag = 0;
					};
			break;

		default:
			SwitchFault("ExpandCompactMove");
			break;
		};

/* return value */

if (flag)
	mptr = &compact_m;
else
	mptr = NULL;

return (mptr);
}

/*--> SynthesizeMove: attempt to construct a move using frsq/tosq */
nonstatic
mptrT
SynthesizeMove(sqT frsq, sqT tosq)
{
mptrT mptr;
siT flag, done;
scmvT scmv;

/* set up */

done = flag = 0;

/* from square color test */

if (!done)
	if (cv_c_cpv[local.rbv[frsq]] != actc)
		done = 1;

/* to square color test */

if (!done)
	if (cv_c_cpv[local.rbv[tosq]] == actc)
		done = 1;

/* process by moving piece */

if (!done)
	{
	switch (local.rbv[frsq])
		{
		case cp_wp:
			/* process straight motion */

			if (tosq == (frsq + dv_1))
				{
				/* one square ahead */

				if (local.rbv[tosq] == cp_v0)
					{
					/* forward to empty square */

					if (map_rank(tosq) != rank_8)
						scmv = scmv_reg;
					else
						scmv = scmv_ppq;
					flag = 1;
					};

				done = 1;
				};

			/* process straight motion two ahead */

			if (!done)
				if ((tosq == (frsq + (2 * dv_1))) &&
					(map_rank(frsq) == rank_2))
					{
					/* two squares ahead */

					if ((local.rbv[tosq - dv_1] == cp_v0) &&
						(local.rbv[tosq] == cp_v0))
						{
						/* forward twice to empty square */

						scmv = scmv_reg;
						flag = 1;
						};

					done = 1;
					};

			/* process capture to kingside */

			if (!done)
				if (tosq == (frsq + dv_4))
					{
					/* capture to kingside */

					if (cv_c_cpv[local.rbv[tosq]] == c_b)
						{
						/* forward kingside to occupied square */

						if (map_rank(tosq) != rank_8)
							scmv = scmv_reg;
						else
							scmv = scmv_ppq;
						flag = 1;
						};

					done = 1;
					};

			/* process capture to queenside */

			if (!done)
				if (tosq == (frsq + dv_5))
					{
					/* capture to queenside */

					if (cv_c_cpv[local.rbv[tosq]] == c_b)
						{
						/* forward kingside to occupied square */

						if (map_rank(tosq) != rank_8)
							scmv = scmv_reg;
						else
							scmv = scmv_ppq;
						flag = 1;
						};

					done = 1;
					};

			/* process en passant capture */

			if (!done)
				{
				if ((tosq == envn.envn_epsq) && bb_tstsq(atbbv[tosq], frsq))
					{
					scmv = scmv_epc;
					flag = 1;
					};
				done = 1;
				};
			break;

		case cp_bp:
			/* process straight motion */

			if (tosq == (frsq + dv_3))
				{
				/* one square ahead */

				if (local.rbv[tosq] == cp_v0)
					{
					/* forward to empty square */

					if (map_rank(tosq) != rank_1)
						scmv = scmv_reg;
					else
						scmv = scmv_ppq;
					flag = 1;
					};

				done = 1;
				};

			/* process straight motion two ahead */

			if (!done)
				if ((tosq == (frsq + (2 * dv_3))) &&
					(map_rank(frsq) == rank_7))
					{
					/* two squares ahead */

					if ((local.rbv[tosq - dv_3] == cp_v0) &&
						(local.rbv[tosq] == cp_v0))
						{
						/* forward twice to empty square */

						scmv = scmv_reg;
						flag = 1;
						};

					done = 1;
					};

			/* process capture to kingside */

			if (!done)
				if (tosq == (frsq + dv_7))
					{
					/* capture to kingside */

					if (cv_c_cpv[local.rbv[tosq]] == c_w)
						{
						/* forward kingside to occupied square */

						if (map_rank(tosq) != rank_1)
							scmv = scmv_reg;
						else
							scmv = scmv_ppq;
						flag = 1;
						};

					done = 1;
					};

			/* process capture to queenside */

			if (!done)
				if (tosq == (frsq + dv_6))
					{
					/* capture to queenside */

					if (cv_c_cpv[local.rbv[tosq]] == c_w)
						{
						/* forward kingside to occupied square */

						if (map_rank(tosq) != rank_1)
							scmv = scmv_reg;
						else
							scmv = scmv_ppq;
						flag = 1;
						};

					done = 1;
					};

			/* process en passant capture */

			if (!done)
				{
				if ((tosq == envn.envn_epsq) && bb_tstsq(atbbv[tosq], frsq))
					{
					scmv = scmv_epc;
					flag = 1;
					};
				done = 1;
				};
			break;

		case cp_wn:
		case cp_bn:
		case cp_wb:
		case cp_bb:
		case cp_wr:
		case cp_br:
		case cp_wq:
		case cp_bq:
			/* check attack validity */

			if (bb_tstsq(atbbv[tosq], frsq))
				{
				scmv = scmv_reg;
				flag = 1;
				};

			done = 1;
			break;

		case cp_wk:
			/* check for non-castling move */

			if (bb_tstsq(atbbv[tosq], frsq))
				{
				/* adjacent move; avoid moving into check */

				if (bb_tstnotsq(acbbv[c_b], tosq))
					{
					scmv = scmv_reg;
					flag = 1;
					};

				done = 1;
				};

			/* check for king side castling */

			if (!done)
				if (CastlingFlankOkay(flank_k))
					if (tosq == sq_g1)
						{
						scmv = scmv_cks;
						flag = 1;
						done = 1;
						};

			/* check for queen side castling */

			if (!done)
				if (CastlingFlankOkay(flank_q))
					if (tosq == sq_c1)
						{
						scmv = scmv_cqs;
						flag = 1;
						done = 1;
						};

			done = 1;
			break;

		case cp_bk:
			/* check for non-castling move */

			if (bb_tstsq(atbbv[tosq], frsq))
				{
				/* adjacent move; avoid moving into check */

				if (bb_tstnotsq(acbbv[c_w], tosq))
					{
					scmv = scmv_reg;
					flag = 1;
					};

				done = 1;
				};

			/* check for king side castling */

			if (!done)
				if (CastlingFlankOkay(flank_k))
					if (tosq == sq_g8)
						{
						scmv = scmv_cks;
						flag = 1;
						done = 1;
						};

			/* check for queen side castling */

			if (!done)
				if (CastlingFlankOkay(flank_q))
					if (tosq == sq_c8)
						{
						scmv = scmv_cqs;
						flag = 1;
						done = 1;
						};
			done = 1;
			break;
		};
	};

/* set result */

if (flag)
	{
	/* assign components */

	synth_m.m_flag = 0;
	synth_m.m_frsq = frsq;
	synth_m.m_tosq = tosq;
	synth_m.m_frcp = local.rbv[frsq];
	synth_m.m_tocp = local.rbv[tosq];
	synth_m.m_scmv = scmv;
	synth_m.m_eval = synth_m.m_prel = cpev_bust;
	synth_m.m_cptr = synth_m.m_dptr = NULL;

	mptr = &synth_m;
	}
else
	mptr = NULL;

return (mptr);
}

/*<<< mu.c: EOF */
