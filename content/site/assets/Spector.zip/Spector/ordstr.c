/*>>> ordstr.c: ordinal/string conversion routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "ordstr.h"
#include "sysutil.h"

#define ordvL 256

static char ordv[ordvL];
static siT ordn;

/*--> OrdBufferInsertChar: insert a char into the result buffer */
static
void
OrdBufferInsertChar(char ch)
{
if (ordn == (ordvL - 1))
	Overflow("OrdBufferInsertChar");
ordv[ordn++] = ch;

return;
}

/*--> OrdBufferInsertStr: insert a string into the result buffer */
static
void
OrdBufferInsertStr(charptrT s)
{
siT i;

if (s != NULL)
	{
	i = 0;
	while (*(s + i) != ascii_nul)
		{
		OrdBufferInsertChar(*(s + i));
		i++;
		};
	};

return;
}

/*--> OrdBufferCondInsertBlank: insert a blank conditionally */
static
void
OrdBufferCondInsertBlank(void)
{
if (ordn > 0)
	if (ordv[ordn - 1] != ascii_sp)
		OrdBufferInsertChar(' ');

return;
}

/*--> OrdBufferHandleTriplet: handle numbers in 1..999 */
static
void
OrdBufferHandleTriplet(siT n)
{
siT v, u;

v = n;

/* hundreds */

if (v >= hundred)
	{
	OrdBufferCondInsertBlank();
	u = v / hundred;
	v = v - (u * hundred);
	OrdBufferInsertStr(ord_unitv[u]);
	OrdBufferInsertStr(" hundred");
	};

/* process 1..99 */

if (v >= 20)
	{
	OrdBufferCondInsertBlank();
	u = v / ten;
	v = v - (u * ten);
	OrdBufferInsertStr(ord_tensv[u]);
	if (v >= 1)
		{
		OrdBufferInsertChar(' ');
		OrdBufferInsertStr(ord_unitv[v]);
		};
	}
else
	if (v >= ten)
		{
		OrdBufferCondInsertBlank();
		OrdBufferInsertStr(ord_teenv[v - ten]);
		}
	else
		if (v >= 1)
			{
			OrdBufferCondInsertBlank();
			OrdBufferInsertStr(ord_unitv[v]);
			};

return;
}

/*--> OrdLIStr: return the ordinal string for a long integer */
nonstatic
charptrT
OrdLIStr(liT n)
{
liT v;
siT u;

/* initilize the result buffer */

ordn = 0;

/* set up */

v = n;

/* handle minus sign */

if (v < 0)
	{
	OrdBufferInsertStr("minus");
	v = -v;
	};

/* handle zero */

if (v == 0)
	OrdBufferInsertStr(ord_unitv[0]);
else
	{
	/* handle billions */

	if (v >= billion)
		{
		OrdBufferCondInsertBlank();
		u = (siT) (v / billion);
		v = v - (billion * u);
		OrdBufferHandleTriplet(u);
		OrdBufferInsertStr(" billion");
		};

	/* handle millions */

	if (v >= million)
		{
		OrdBufferCondInsertBlank();
		u = (siT) (v / million);
		v = v - (million * u);
		OrdBufferHandleTriplet(u);
		OrdBufferInsertStr(" million");
		};

	/* handle thousands */

	if (v >= thousand)
		{
		OrdBufferCondInsertBlank();
		u = (siT) (v / thousand);
		v = v - (thousand * u);
		OrdBufferHandleTriplet(u);
		OrdBufferInsertStr(" thousand");
		};

	/* handle units */

	if (v >= one)
		{
		OrdBufferCondInsertBlank();
		u = (siT) v;
		OrdBufferHandleTriplet(u);
		};
	};

/* insert (directly) trailing NUL */

ordv[ordn++] = ascii_nul;

return (&ordv[0]);
}

/*--> OrdSIStr: return the ordinal string for a short integer */
nonstatic
charptrT
OrdSIStr(siT n)
{

return (OrdLIStr(n));
}

/*<<< ordstr.c: EOF */
