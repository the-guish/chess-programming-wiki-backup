/*>>> chkmrk.c: check move marking */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "chkmrk.h"

/*--> CheckMark: mark obvious checking moves in moveset */
nonstatic
void
CheckMark(sptrT sptr)
{
siT checkflag;
siT i, count;
mptrT mptr;
sqT frsq, tosq, asq, pask_sq;
dxT dir0, kdx;
bbT ispbb, act_c0bbv, act_acbbv, bb0, bb1;

if (pasc == c_w)
	{
	pask_sq = bb_once(cpbbv[cp_wk]);
	act_c0bbv = c0bbv[c_b];
	act_acbbv = acbbv[c_b];
	}
else
	{
	pask_sq = bb_once(cpbbv[cp_bk]);
	act_c0bbv = c0bbv[c_w];
	act_acbbv = acbbv[c_w];
	};

count = sptr->s_count;
mptr = sptr->s_mbase;

for (i = 0; i < count; i++)
	{
	checkflag = 0;

	frsq = mptr->m_frsq;
	tosq = mptr->m_tosq;

	dir0 = *(dx_table_base + offset_sqsq(tosq, pask_sq));
	switch (mptr->m_frcp)
		{
		case cp_wp:
			if (mptr->m_scmv == scmv_reg)
				{
				if (map_file(tosq) > file_a)
					if ((tosq + dv_5) == pask_sq)
						checkflag = 1;
				if (map_file(tosq) < file_h)
					if ((tosq + dv_4) == pask_sq)
						checkflag = 1;
				};
			break;

		case cp_bp:
			if (mptr->m_scmv == scmv_reg)
				{
				if (map_file(tosq) > file_a)
					if ((tosq + dv_6) == pask_sq)
						checkflag = 1;
				if (map_file(tosq) < file_h)
					if ((tosq + dv_7) == pask_sq)
						checkflag = 1;
				};
			break;

		case cp_wn:
		case cp_bn:
			if ((dir0 >= dx_8) && (dir0 <= dx_f))
				checkflag = 1;
			else
				{
				/* fetch direction from passive king */

				kdx = *(dx_table_base + offset_sqsq(pask_sq, frsq));
				if ((kdx >= dx_0) && (kdx <= dx_7))
					{
					/* moving piece is in line, check attacked status */

					if (bb_tstsq(act_acbbv, frsq))
						{
						/* piece is attacked; test for interpath vacancy */

						bb0 = *(path_raster_base +
							offset_sqsq(pask_sq, frsq));
						if (bb_tstnotand(bb0, apmbb))
							{
							/* piece is attacked; get attackers */

							bb_and3(atbbv[frsq], act_c0bbv, bb0);

							/* fetch only in line attacker, if any */

							bb1 = *(ray_raster_base +
								offset_dxsq(kdx, frsq));
							bb_and2(bb0, bb1);

							/* is there an in line attacker? */

							if (bb_tst(bb1))
								{
								/* in line attacker exists; get its square */

								asq = bb_once(bb1);

								/* is the attacker a sweep piece? */

								if (cp_sweepv[local.rbv[asq]])
									{
									/* yes, the move is a discovered check */

									checkflag = 1;
									};
								};
							};
						};
					};
				};
			break;

		case cp_wb:
		case cp_bb:
			if ((dir0 >= dx_4) && (dir0 <= dx_7))
				{
				ispbb = *(path_raster_base + offset_sqsq(tosq, pask_sq));
				if (bb_tstnotand(ispbb, apmbb))
					checkflag = 1;
				};
			if (!checkflag)
				{
				/* fetch direction from passive king */

				kdx = *(dx_table_base + offset_sqsq(pask_sq, frsq));
				if ((kdx >= dx_0) && (kdx <= dx_7))
					{
					/* moving piece is in line, check attacked status */

					if (bb_tstsq(act_acbbv, frsq))
						{
						/* piece is attacked; test for interpath vacancy */

						bb0 = *(path_raster_base +
							offset_sqsq(pask_sq, frsq));
						if (bb_tstnotand(bb0, apmbb))
							{
							/* piece is attacked; get attackers */

							bb_and3(atbbv[frsq], act_c0bbv, bb0);

							/* fetch only in line attacker, if any */

							bb1 = *(ray_raster_base +
								offset_dxsq(kdx, frsq));
							bb_and2(bb0, bb1);

							/* is there an in line attacker? */

							if (bb_tst(bb1))
								{
								/* in line attacker exists; get its square */

								asq = bb_once(bb1);

								/* is the attacker a sweep piece? */

								if (cp_sweepv[local.rbv[asq]])
									{
									/* yes, the move is a discovered check */

									checkflag = 1;
									};
								};
							};
						};
					};
				};
			break;

		case cp_wr:
		case cp_br:
			if ((dir0 >= dx_0) && (dir0 <= dx_3))
				{
				ispbb = *(path_raster_base + offset_sqsq(tosq, pask_sq));
				if (bb_tstnotand(ispbb, apmbb))
					checkflag = 1;
				};
			if (!checkflag)
				{
				/* fetch direction from passive king */

				kdx = *(dx_table_base + offset_sqsq(pask_sq, frsq));
				if ((kdx >= dx_0) && (kdx <= dx_7))
					{
					/* moving piece is in line, check attacked status */

					if (bb_tstsq(act_acbbv, frsq))
						{
						/* piece is attacked; test for interpath vacancy */

						bb0 = *(path_raster_base +
							offset_sqsq(pask_sq, frsq));
						if (bb_tstnotand(bb0, apmbb))
							{
							/* piece is attacked; get attackers */

							bb_and3(atbbv[frsq], act_c0bbv, bb0);

							/* fetch only in line attacker, if any */

							bb1 = *(ray_raster_base +
								offset_dxsq(kdx, frsq));
							bb_and2(bb0, bb1);

							/* is there an in line attacker? */

							if (bb_tst(bb1))
								{
								/* in line attacker exists; get its square */

								asq = bb_once(bb1);

								/* is the attacker a sweep piece? */

								if (cp_sweepv[local.rbv[asq]])
									{
									/* yes, the move is a discovered check */

									checkflag = 1;
									};
								};
							};
						};
					};
				};
			break;

		case cp_wq:
		case cp_bq:
			if ((dir0 >= dx_0) && (dir0 <= dx_7))
				{
				ispbb = *(path_raster_base + offset_sqsq(tosq, pask_sq));
				if (bb_tstnotand(ispbb, apmbb))
					checkflag = 1;
				};
			break;

		case cp_wk:
			break;

		case cp_bk:
			break;
		};

	if (checkflag)
		mptr->m_flag |= mf_chec;

	mptr++;
	};

return;
}

/*<<< chkmrk.c: EOF */
