/*>>> poll.c: polling and interrupt access */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "vpdefs.h"

#include "clock.h"
#include "display.h"
#include "poll.h"
#include "print.h"
#include "sysutil.h"

#if (os_mac)
#include <Menus.h>
#endif

#if (os_mac)
extern pascal Boolean Button(void);
extern pascal void SystemTask(void);
#endif

/*--> AbortSearch: set search abort indicator */
nonstatic
void
AbortSearch(void)
{
search_abort = 1;

return;
}

/*--> InterruptSearch: set search interrupt indicator */
nonstatic
void
InterruptSearch(int sig)
{
if (sig < 0)
	Diagnose("InterruptSearch: fault");

search_interrupt = 1;

return;
}

/*--> PollDefault: set default SIGINT processing */
static
void
PollDefault(void)
{
#if (ips_interrupt)
{
/* clear interrupt signal processing */

(void) signal(SIGINT, SIG_DFL);
}
#endif

return;
}

/*--> PollTrap: Trap SIGINT processing for search */
static
void
PollTrap(void)
{
#if (ips_interrupt)
{
/* set interrupt signal processing for search in progress */

(void) signal(SIGINT, InterruptSearch);
}
#endif

return;
}

/*--> PollSelectInit: initialize interrupt processing for move selection */
nonstatic
void
PollSelectInit(void)
{
search_interrupt = 0;
PollTrap();

return;
}

/*--> PollSelectTerm: terminate interrupt processing for move selection */
nonstatic
void
PollSelectTerm(void)
{
PollDefault();

return;
}

/*--> PollTestPonderTimeout: test timeout for interrupted ponder search */
static
siT
PollTestPonderTimeout(void)
{

return (ClockPastNextCandidate());
}

/*--> PollNode: poll/interrupt processing for a node */
nonstatic
void
PollNode(void)
{
siT code;
siT clank;
liT now;
char tv[tL];

/* determine if a clank (periodic timeout) occurred */

if (count_node & 0x00ffL)
	clank = 0;
else
	{
	now = time(NULL);
	if (now != tmark_clank)
		{
		tmark_clank = now;
		clank = 1;
		}
	else
		clank = 0;
	};

/* handle Macinstosh interval tasks */

#if (os_mac)
{
if (clank)
	SystemTask();
}
#endif

/* handle interval tasks */

if (clank)
	{
	/* display items update */

	di_expectation = expectation;
	di_nodes = count_node - search_start_node;
	di_seconds = time(NULL) - search_start_time;

	/* display update */

	DpUpdate(winid_clock);
	DpUpdate(winid_search);
	DpUpdate(winid_time);
	};

/* handle mouse interrupt */

#if (ips_mouse && os_mac)
{
/* mouse down test */

if (Button())
	{
	/* set search interrupted */

	InterruptSearch(SIGINT);

	/* flash button acknowledgement */

	while (Button())
		{
		FlashMenuBar(0);
		FlashMenuBar(0);
		};
	};
}
#endif

/* interrupt processing, independent of source */

if (search_interrupt)
	{
	/* deactivate signal catch */

	PollDefault();

	/* clear the interrupt indicator */

	search_interrupt = 0;

	/* check if ponder search is active */

	if (ponder_active)
		{
		/* process ponder search transformation */

		PrLine("*** ponder search interrupted");
		PrStrSANNL("The predicted move is: ", &ponder_m);

		/* get ponder search action confirmed interactively */

		code = -1;
		while (code == -1)
			{
			PrLine("Enter match code (0=no, 1=yes, 2=skip): ");
			tv[0] = ascii_nul;

			if (disenv_scroll)
				(void) fgets(tv, tL, stdin);
			else
				DpReadResponse(tv);

			if (sscanf(tv, sfs_si, &code) != 1)
				code = -1;
			else
				{
				switch (code)
					{
					case 0:
						/* incorrect prediction, abort search */

						PrLine("*** ponder search discarded");

						/* set the manual stop indicator */

						ponder_manual_stop = 1;

						/* set mismatch flag, clear match flag */

						ponder_mismatch = 1;
						ponder_match = 0;

						/* stop the search  */

						AbortSearch();

						/* set ponder trace default */

						ponder_trace = 1;

						break;

					case 1:
						/* correct prediction, transform to regular search */

						PrLine("*** ponder search transformed");

						/* set the manual stop (transform) indicator */

						ponder_manual_stop = 1;

						/* clear mismatch flag, set match flag */

						ponder_mismatch = 0;
						ponder_match = 1;

						/* update clock */

						ClockUpdate();

						/* indicate transformation to regular search */

						ponder_active = 0;

						/* set ponder trace default */

						ponder_trace = 1;

						/* subtract ponder time from budgets */

						ClockModifyPonderBudget();

						/* display update */

						DpUpdateAll();

						/* test for time based abort */

						if (PollTestPonderTimeout())
							{
							AbortSearch();
							if (optnv[optn_verb])
								PrLine("*** ponder search timed out");
							};

						break;

					case 2:
						/* skip */

						PrLine("*** ponder search continued");

						break;

					default:
						/* bad input */

						code = -1;

						break;
					};
				};
			};
		}
	else
		{
		/* simple interrupt */

		PrLine("*** normal search interrupted");

		/* conditional frequency statistics */

		if (optnv[optn_freq])
			PrSearchFrequencyReport(search_start_node, search_start_time);

		/* conditional print current move path */

		if (optnv[optn_trab])
			{
			PrTrace("AB");
			PrChar('[');
			PrTwoDigitSI(ply);
			PrStr("] ");
			PrCurrentPath();
			PrNL();
			};

		/* get abort confirmed interactively */

		code = -1;
		while (code == -1)
			{
			PrLine("Enter abort code (0=no, 1=yes): ");
			tv[0] = ascii_nul;

			if (disenv_scroll)
				(void) fgets(tv, tL, stdin);
			else
				DpReadResponse(tv);

			if (sscanf(tv, sfs_si, &code) != 1)
				code = -1;
			else
				{
				switch (code)
					{
					case 0:
						/* non-serious interrupt, continue search */

						PrLine("*** normal search continued");

						break;

					case 1:
						/* serious interrupt, abort search */

						PrLine("*** normal search terminated");

						/* abort the search */

						AbortSearch();

						/* set the search termination reason code */

						strc = strc_intr;

						/* set the move/multimove stop flag */

						stop_play = 1;

						break;

					default:
						/* bad input */

						code = -1;

						break;
					};
				};
			};
		};

	/* reactivate signal catch */

	PollTrap();
	};

/* timer checks */

if (clank && !search_abort)
	{
	/* countdown timer check */

	if ((countdown_timer > 0) && CountdownTimerExpired())
		{
		AbortSearch();
		strc = strc_time;
		if (optnv[optn_verb])
			PrLine("*** countdown timer expired");
		};

	/* mondo overflow budget check */

	if (ClockPastMondo())
		{
		AbortSearch();
		strc = strc_time;
		if (optnv[optn_verb])
			PrLine("*** mondo overflow timer expired");
		};
	};

/* node countdown check */

if (!search_abort &&
	(node_countdown > 0) && NodeCountdownExpired())
	{
	AbortSearch();
	strc = strc_node;
	if (optnv[optn_verb])
		PrLine("*** node countdown reached");
	};

return;
}

/*<<< poll.c: EOF */
