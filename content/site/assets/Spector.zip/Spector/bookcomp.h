/*>>> bookcomp.h: subprogram prototypes for bookcomp.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT ListBookTextComp(charptrT fn_bkfsrc, charptrT fn_bkfdst,
	charptrT fn_bkfcor, charptrT fn_bkfmpl, charptrT fn_bkfepd);

/*<<< bookcomp.h: EOF */
