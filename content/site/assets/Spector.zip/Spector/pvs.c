/*>>> pvs.c: principal variation search */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bbmacs.h"
#include "tbdefs.h"
#include "vpdefs.h"

#include "assist.h"
#include "bb.h"
#include "bcs.h"
#include "clock.h"
#include "display.h"
#include "draw.h"
#include "epos.h"
#include "eval.h"
#include "exec.h"
#include "killer.h"
#include "moveset.h"
#include "oracle.h"
#include "poll.h"
#include "pick.h"
#include "predvar.h"
#include "prelim.h"
#include "print.h"
#include "pvs.h"
#include "refute.h"
#include "sysutil.h"
#include "tact.h"
#include "ts.h"
#include "tt.h"
#include "util.h"

/**** Locals */

/* capture window vector length */

#define captwinL 4

/* macro for piece detection */

#define HasPiece(c) \
	((c == c_w) ? \
		(bb_tst(cpbbv[cp_wn]) || \
		bb_tst(cpbbv[cp_wb]) || \
		bb_tst(cpbbv[cp_wr]) || \
		bb_tst(cpbbv[cp_wq])) \
		: \
		(bb_tst(cpbbv[cp_bn]) || \
		bb_tst(cpbbv[cp_bb]) || \
		bb_tst(cpbbv[cp_br]) || \
		bb_tst(cpbbv[cp_bq])) \
	) \

/* macro for preliminary evaluation generation */

#define PrelimGen(dsptr) \
	{ \
	if (!prelim_flag) \
		{ \
		if (!top_flag) \
			if (parent_sncc == sncc_red) \
				if (depth >= 0) \
					PreliminaryEvaluationsPlain(dsptr); \
				else \
					PreliminaryEvaluationsQuick(dsptr); \
			else \
				if (!qs_flag) \
					PreliminaryEvaluationsQuick(dsptr); \
				else \
					PreliminaryEvaluationsCapture(dsptr); \
		prelim_flag = 1; \
		}; \
	}

/* macro for ply zero move search node count update */

#define PZSNCountUpdate() \
	{ \
	*(pzsnc_base + CurrentPlyZeroMoveIndex()) = \
		count_node - pz_node_count; \
	}

/* macro for top level pre-recursion */

#define TLPreRec(index, dsptr) \
	{ \
	FTDPlyZeroMove = 1; \
	di_p0pick = index; \
	di_p0m = *dsptr->s_mcurr; \
	SIDUpdate(); \
	PlyZeroTrace0(dsptr); \
	}

/* macro for top level post-recursion (best move located) */

#define TLPostRec(best, dsptr) \
	{ \
	if (!search_abort) \
		{ \
		expectation = best; \
		pvsbest_m = *dsptr->s_mbest; \
		PlyZeroTrace1(dsptr); \
		BestMoveTrace(); \
		RotatePlyZero(); \
		pv_flag = 1; \
		}; \
	}

/* macro to ensure positional evaluation available */

#define CCSPositional() \
	{ \
	if (!csfp_flag) \
		{ \
		positional_eval = EvaluatePositional(); \
		csfp_flag = 1; \
		}; \
	}

/* extension usage counts */

static siT ec_used_dbl; /* double check */
static siT ec_used_dis; /* discovered check */
static siT ec_used_p7r; /* pawn to seventh rank */
static siT ec_used_scr; /* singular check response */

/* extension usage flag */

static siT ec_used_rcp; /* recapture */

/* prior iteration expectation */

static cpevT prior_expectation;

/* the best move */

static mT pvsbest_m;

/* capture window vector */

static cpevT captwinv[captwinL] = { 1024, 256, 64, 16 };

/* auxiliary node statistics */

static liT ans_index_sum;
static liT ans_interior_nodes;
static liT ans_nullcount;
static liT ans_null_alpha_nodes;
static liT ans_null_beta_nodes;
static liT ans_oracular_nodes;
static liT ans_quiescence_nodes;
static liT ans_researches;
static liT ans_singleton_nodes;
static liT ans_terminal_nodes;

/* index and width statistics by color class */

static liT cc_countv[snccL]; /* count of nodes of a color class */
static liT cc_indexv[snccL]; /* moves tried */
static liT cc_widthv[snccL]; /* move width */

/*--> PVSAuxStatReport: auxiliary statistics report */
static
void
PVSAuxStatReport(void)
{
PrTrace("AB");
PrStr("Nodes:");
PrStrLI("   IN: ", ans_interior_nodes);
PrStrLI("   TN: ", ans_terminal_nodes);
PrStrLI("   QN: ", ans_quiescence_nodes);
PrStrLI("   SN: ", ans_singleton_nodes);
PrNL();

PrTrace("AB");
PrStr("Metrics:");
PrStr("   NM: ");
PrLI(ans_nullcount);
PrChar('/');
PrLI(ans_null_alpha_nodes);
PrChar('/');
PrLI(ans_null_beta_nodes);
PrStrLI("   ON: ", ans_oracular_nodes);
PrStrLI("   RS: ", ans_researches);
if (ans_interior_nodes != 0)
	{
	PrStr("   MI: ");
	FormatSTVLQR(ans_index_sum, ans_interior_nodes);
	PrSTV();
	};
PrNL();

#if (0)
if (cc_countv[sncc_red] > 0)
	{
	PrTrace("AB");
	PrStr("cc red:  index: ");
	FormatSTVLQR(cc_indexv[sncc_red], cc_countv[sncc_red]);
	PrSTV();
	PrStr("   width: ");
	FormatSTVLQR(cc_widthv[sncc_red], cc_countv[sncc_red]);
	PrSTV();
	PrStrLINL("   count: ", cc_countv[sncc_red]);
	};

if (cc_countv[sncc_green] > 0)
	{
	PrTrace("AB");
	PrStr("cc green:  index: ");
	FormatSTVLQR(cc_indexv[sncc_green], cc_countv[sncc_green]);
	PrSTV();
	PrStr("   width: ");
	FormatSTVLQR(cc_widthv[sncc_green], cc_countv[sncc_green]);
	PrSTV();
	PrStrLINL("   count: ", cc_countv[sncc_green]);
	};

if (cc_countv[sncc_blue] > 0)
	{
	PrTrace("AB");
	PrStr("cc blue:  index: ");
	FormatSTVLQR(cc_indexv[sncc_blue], cc_countv[sncc_blue]);
	PrSTV();
	PrStr("   width: ");
	FormatSTVLQR(cc_widthv[sncc_blue], cc_countv[sncc_blue]);
	PrSTV();
	PrStrLINL("   count: ", cc_countv[sncc_blue]);
	};
#endif

return;
}

/*--> PVSPickMove: pick the next move for the PV search */
static
mptrT
PVSPickMove(sptrT sptr)
{
mptrT mptr;

if (ply == 0)
	mptr = PickLinear(sptr);
else
	mptr = PickBestPrel(sptr);

return (mptr);
}

/*--> PVSNode: process a regular PVS node */
static
cpevT
PVSNode(mptrT mptr, cpevT alpha, cpevT beta, siT depth, snccT parent_sncc)
{
cpevT best, value;
sptrT dsptr, cptr;
mptrT dmptr;
siT scan_flag, done_flag, top_flag, qs_flag, check_flag;
siT pv_flag, csfp_flag, newbest_flag, prelim_flag;
siT weakcapt_flag, forcefull_flag;
siT extension, newdepth, d4, d8;
siT ew_flag, iter3_flag;
siT index, width;
siT ec_save_dbl, ec_save_dis, ec_save_p7r, ec_save_rcp, ec_save_scr;
siT saveFTDPlyZeroMove, saveFTDIteration;
smptrT smptr;
liT pz_node_count;
cpevT best_capt, cutoff, captwin, material_eval, positional_eval;
cpevT hash_alpha, hash_beta, retry_alpha, retry_beta;
sqT actk_sq, tosq;
snccT current_sncc;
ttriT ttri;
mptrT tt_mptr, ss_mptr, p1mptr;
liT this_node;
mT n_m, pvs_m, tt_m;

/* mark call count */

this_node = pre_count_node++;

/* set up */

done_flag = qs_flag = pv_flag = 0;
csfp_flag = newbest_flag = prelim_flag = 0;
weakcapt_flag = forcefull_flag = 0;
ttri = ttri_fault;
index = 0;
extension = 0;
best = cpev_bust;
retry_alpha = retry_beta = cpev_bust;
hash_alpha = alpha;
hash_beta = beta;
best_capt = 0;
captwin = 0;
tt_mptr = ss_mptr = NULL;
pvs_m = tt_m = null_m;
tosq = mptr->m_tosq;
cptr = mptr->m_cptr;

/* more set up */

if (ply == 0)
	top_flag = 1;
else
	top_flag = 0;

if (mptr->m_flag & mf_chec)
	check_flag = 1;
else
	check_flag = 0;

if (mptr->m_dptr != NULL)
	width = mptr->m_dptr->s_count;
else
	width = 0;

/* distance set up */

d4 = ply >> 2;
d8 = ply >> 3;
if (ply <= (iteration + iteration + iteration))
	iter3_flag = 1;
else
	iter3_flag = 0;

/* search node color class set up */

switch (parent_sncc)
	{
	case sncc_red:
		current_sncc = sncc_red;
		break;

	case sncc_green:
		current_sncc = sncc_blue;
		break;

	case sncc_blue:
		current_sncc = sncc_green;
		break;

	default:
		SwitchFault("PVSNode: sncc");
		break;
	};

/* initialize the PV working matrix for this node */

PVarWMCut();

/* material evaluation set up */

material_eval = EvaluateMaterial();

/* expectation window flag */

if (abs(material_eval - expectation) <= pval_q)
	ew_flag = 1;
else
	ew_flag = 0;

/* save values: extension usage counts */

ec_save_dbl = ec_used_dbl;
ec_save_dis = ec_used_dis;
ec_save_p7r = ec_used_p7r;
ec_save_scr = ec_used_scr;

/* save values: extension usage flags */

ec_save_rcp = ec_used_rcp;
ec_used_rcp = 0;

/* process trace: first time down tree search */

if (FTDPlyZeroMove && optnv[optn_trfd] && ponder_trace)
	{
	PrTrace("FT");
	PrCurrentPath();
	PrNL();
	};

/* move path trace output */

MovePathTrace();

/* poll/interrupt processing */

PollNode();

/* check for a search abort */

if (search_abort)
	{
	best = cpev_bust;
	done_flag = 1;
	};

/* terminal position (ply limit exceeded) */

if (!done_flag && (ply == (plyL - 1)))
	{
	best = TaperScore(Evaluate());
	done_flag = 1;
	};

/* certain evalution */

if (0 && !done_flag && (mptr->m_flag & mfm_certain) && !top_flag)
	{
	best = -(mptr->m_eval);
	done_flag = 1;
	};

/* check for (probable) draw */

if (!done_flag && !top_flag && DrawTestPartial())
	{
	mptr->m_flag |= mf_pdrw;
	best = cpev_draw;
	done_flag = 1;
	};

/* mate in one check */

if (!done_flag &&
	(FTDPlyZeroMove || ((beta - alpha) > 1)) && !top_flag)
	{
	tt_mptr = TSMateInOne();
	if (tt_mptr != NULL)
		{
		pvs_m = *tt_mptr;
		PVarWMSplice(&pvs_m);
		index = width = 1;
		best = pvs_m.m_eval;
		done_flag = 1;
		};
	};

/* mate in two check (active checks only) */

if (!done_flag && (FTDPlyZeroMove || ((beta - alpha) > 1)) &&
	(depth >= 0) && !top_flag)
	{
	tt_mptr = TSMateACO(2);
	if (tt_mptr != NULL)
		{
		pvs_m = *tt_mptr;
		PVarWMSplice(&pvs_m);
		index = width = 1;
		best = pvs_m.m_eval;
		done_flag = 1;
		};
	};

/* probe the tablebases */

if (!done_flag && !top_flag)
	if (!null_move_ref(mptr) && !optnv[optn_nocm] && (depth >= 0))
		if ((mptr->m_tocp != cp_v0) || (mptr->m_scmv != scmv_reg))
			if (bb_count(apmbb) <= tbmctL)
				{
				value = OracularEvaluate();
				if (value != cpev_wrck)
					{
					ans_oracular_nodes++;
					if (value != cpev_draw)
						if (value > 0)
							value -= ply;
						else
							value += ply;
					mptr->m_flag |= mf_orac;
					best = value;
					done_flag = 1;
					};
				};

/* probe the transposition table */

if (!done_flag && !top_flag && (depth >= 0))
	{
	tt_mptr = TTExtract(&alpha, &beta, &best);
	if (tt_mptr != NULL)
		{
		pvs_m = tt_m = *tt_mptr;
		PVarWMSplice(&pvs_m);
		if (best < alpha)
			best = alpha;
		if (best > beta)
			best = beta;
		if (alpha >= beta)
			done_flag = 1;
		};
	};

/* set active king square */

if (!done_flag)
	actk_sq = bb_once(cpbbv[actc_k]);

/* extension processing: active color in check */

if (!done_flag)
	if (check_flag)
		{
		extension++;
		forcefull_flag = 1;
		};

/* extension processing: double check */

if (!done_flag)
	if ((ec_used_dbl <= d8) && ew_flag && iter3_flag)
		if (check_flag)
			{
			bb_and3(atbbv[actk_sq], c0bbv[pasc], gp_bb);
			if (bb_count_gp() > 1)
				{
				ec_used_dbl++;
				extension++;
				};
			};

/* extension processing: discovered check (not double)  */

if (!done_flag)
	if ((ec_used_dis <= d8) && ew_flag && iter3_flag)
		if (check_flag)
			{
			bb_and3(atbbv[actk_sq], c0bbv[pasc], gp_bb);
			if (bb_count_gp() == 1)
				if (bb_tstnotsq(gp_bb, tosq))
					{
					ec_used_dis++;
					extension++;
					};
			};

/* extension processing: pawn to seventh rank */

if (!done_flag)
	if ((ec_used_p7r <= d8) && ew_flag && iter3_flag)
		if (actc == c_w)
			{
			if ((mptr->m_frcp == cp_bp) &&
				(map_rank(tosq) == rank_2) &&
				bb_tstnotsq(acbbv[c_w], tosq) &&
				bb_tstnotsq(acbbv[c_w], tosq + dv_3))
				{
				ec_used_p7r++;
				extension++;
				};
			}
		else
			{
			if ((mptr->m_frcp == cp_wp) &&
				(map_rank(tosq) == rank_7) &&
				bb_tstnotsq(acbbv[c_b], tosq) &&
				bb_tstnotsq(acbbv[c_b], tosq + dv_1))
				{
				ec_used_p7r++;
				extension++;
				};
			};

/* extension processing: equal recapture response */

if (!done_flag)
	if (!ec_save_rcp && ew_flag && iter3_flag &&
		((mptr->m_tocp != cp_v0) && (mptr->m_scmv == scmv_reg)))
		if ((cptr != NULL) &&
			((p1mptr = cptr->s_mprev) != NULL))
			if ((p1mptr->m_tosq == tosq) &&
				(p1mptr->m_scmv == scmv_reg))
				if (scpvalv[p1mptr->m_tocp] ==
					scpvalv[mptr->m_tocp])
					{
					ec_used_rcp = 1;
					extension++;
					};

/* extension processing: singular check response  */

if (!done_flag)
	if ((ec_used_scr <= d8) && iter3_flag)
		if (cptr != NULL)
			if (cptr->s_count == 1)
				if (cptr->s_sflag & sf_full)
					if (cptr->s_mprev != NULL)
						if (cptr->s_mprev->m_flag & mf_chec)
							{
							ec_used_scr++;
							extension++;
							};

/* set new depth */

if (!done_flag)
	newdepth = depth + extension - 1;

/* check for terminal position (depth exceeded) */

if (!done_flag)
	{
	/* set capture window */

	if ((newdepth <= 0) && (newdepth > -captwinL))
		captwin = captwinv[-newdepth];

	if (!check_flag && (newdepth < 0))
		{
		/* test for quiescence search transition */

		best_capt = BestCaptureGain();
		if (best_capt > 0)
			{
			/* check for beta cutoff */

			cutoff = TaperScore(material_eval - cp_poslimit);
			if (cutoff >= beta)
				{
				/* score is too good */

				best = cutoff;
				done_flag = 1;
				}
			else
				{
				/* check for alpha cutoff */

				cutoff = material_eval + cp_poslimit + best_capt;
				if (cutoff <= (alpha - captwin))
					{
					/* score is too bad */

					best = cutoff;
					done_flag = 1;
					}
				else
					{
					/* enter quiescence search */

					qs_flag = 1;
					};
				};
			};

		/* conclude processing if no quiescence search indicated */

		if (!done_flag && !qs_flag && !forcefull_flag)
			{
			/* no quiescence search */

			cutoff = TaperScore(material_eval + cp_poslimit);
			if (cutoff <= alpha)
				best = alpha;
			else
				{
				CCSPositional();
				best = TaperScore(material_eval + positional_eval);
				};
			done_flag = 1;
			};
		};
	};

/* try a null move */

if (!done_flag && !null_move_ref(mptr) && !check_flag &&
	(parent_sncc != sncc_red) && !top_flag &&
	(newdepth > 1) && HasPiece(actc))
	{
	ans_nullcount++;
	saveFTDIteration = FTDIteration;
	saveFTDPlyZeroMove = FTDPlyZeroMove;
	n_m = null_m;
	ExecuteMove(&n_m);
	value =
		-PVSNode(&n_m, -beta, -alpha, max((newdepth - 3), 0), current_sncc);
	RetractMove(&n_m);
	MovesetDisconnectRelease(&n_m);
	if (value > alpha)
		{
		alpha = value;
		ans_null_alpha_nodes++;
		if (alpha >= beta)
			{
			ans_null_beta_nodes++;
			best = alpha;
			done_flag = 1;
			};
		};
	FTDIteration = saveFTDIteration;
	FTDPlyZeroMove = saveFTDPlyZeroMove;
	};

/* move generation */

if (!done_flag)
	{
	/* ensure a connected moveset present */

	if (!top_flag)
		{
		if (!qs_flag)
			MovesetGenerateConnect(mptr);
		else
			MovesetGenerateCapturesConnect(mptr);
		width = mptr->m_dptr->s_count;
		};

	/* keep track of the descendent moveset pointer */

	dsptr = mptr->m_dptr;

	/* set the best move pointer */

	if (top_flag)
		if (PVarEFirstMoveRef() == NULL)
			dsptr->s_mbest = dsptr->s_mbase;
		else
			dsptr->s_mbest = FindMoveNF(PVarEFirstMoveRef(), dsptr,
			"PVSNode");
	else
		if (null_move(tt_m))
			SetBestMovePointer(dsptr);
		else
			{
			dsptr->s_mbest = FindMove(&tt_m, dsptr);
			if (dsptr->s_mbest == NULL)
				SetBestMovePointer(dsptr);
			};

	/* generate preliminary evaluations if no obvious best move */

	if (dsptr->s_mbest == NULL)
		PrelimGen(dsptr);
	};

/* process the first move */

if (!done_flag)
	{
	scan_flag = 1;
	while (scan_flag && !done_flag)
		{
		if (search_abort)
			{
			best = cpev_bust;
			done_flag = 1;
			}
		else
			{
			/* if second time through, ensure preliminary scores */

			if (index == 1)
				PrelimGen(dsptr);

			/* fetch the next candidate */

			dmptr = PVSPickMove(dsptr);

			/* process quiescence search quick discard */

			weakcapt_flag = 0;
			if (qs_flag && (dmptr != NULL) && !(dmptr->m_flag & mf_chec) &&
				(index > 0))
				{
				cutoff =
					material_eval + cp_poslimit +
					BestCaptureGainMove(dmptr);
				if (cutoff <= (alpha - captwin))
					weakcapt_flag = 1;
				};

			/* no more candidates? */

			if (dmptr == NULL)
				{
				/* no first move candidate; end scan */

				scan_flag = 0;

				/* check for quiescence search in progress */

				if (qs_flag)
					{
					/* quiescence search done, score position */

					cutoff = TaperScore(material_eval + cp_poslimit);
					if (cutoff <= alpha)
						best = cutoff;
					else
						{
						CCSPositional();
						best = TaperScore(material_eval + positional_eval);
						};
					}
				else
					{
					/* full width search done; score a mate */

					if (check_flag)
						{
						best = -(cpev_mate - ply);
						mptr->m_flag |= mf_mate;
						}
					else
						{
						best = cpev_draw;
						mptr->m_flag |= mf_draw;
						};
					};

				/* no more action at this node */

				done_flag = 1;
				}
			else
				{
				/* try the move if it isn't a weak capture */

				if (!weakcapt_flag)
					{
					/* a candidate first move is selected */

					ExecuteMove(dsptr->s_mcurr);

					/* was it legal? */

					if (!(dsptr->s_mcurr->m_flag & mf_bust))
						{
						/* scan completed */

						scan_flag = 0;

						/* handle ply zero (pre-recursion) */

						if (top_flag)
							{
							pz_node_count = count_node;
							TLPreRec(index, dsptr);
							};

						/* perform the full width PVS search */

						dsptr->s_mcurr->m_eval = value =
							-PVSNode(dsptr->s_mcurr, -beta, -alpha,
							newdepth, current_sncc);

						/* set awful score on abort */

						if (search_abort)
							dsptr->s_mcurr->m_eval = value = cpev_bust;

						/* process for non-abort */

						if (!search_abort)
							{
							/* update best score */

							if (best < value)
								{
								best = value;
								PVarWMMerge(dsptr->s_mcurr);
								};

							/* assign as best move */

							dsptr->s_mbest = dsptr->s_mcurr;

							/* handle ply zero (post-recursion) */

							if (top_flag)
								{
								TLPostRec(best, dsptr);
								PZSNCountUpdate();
								};

							/* update the best pvs move */

							pvs_m = *dsptr->s_mcurr;

							/* better than the initial lower bound? */

							if (value > alpha)
								{
								/* copy hash values used in search */

								hash_alpha = alpha;
								hash_beta = beta;

								/* update alpha */

								if (alpha < best)
									alpha = best;
								};
							};
						};

					/* undo */

					RetractMove(dsptr->s_mcurr);

					/* PV update */

					if (pv_flag)
						{
						pv_flag = 0;
						if (!search_abort)
							PVarPlyZeroProcess();
						};

					/* refutation sequence update */

					if (top_flag && !search_abort)
						RefuteBindSequence();

					/* deallocate moves */

					MovesetDisconnectRelease(dsptr->s_mcurr);
					};

				/* done with this candidate, bump selection index */

				index++;
				};
			};
		};
	};

/* test for beta cutoff */

if (!done_flag)
	if (best >= beta)
		done_flag = 1;

/* test for adequate mating move */

if (!done_flag)
	if (ct_mate(best))
		if ((best >= (cpev_mate - iteration)) || top_flag)
			done_flag = 1;

/* process the rest of the moves */

if (!done_flag)
	{
	/* conditionally change the current search node color class */

	if (current_sncc == sncc_red)
		current_sncc = sncc_green;

	/* ensure preliminary evaluations are present if multiple moves */

	if (dsptr->s_count > 1)
		PrelimGen(dsptr);

	/* start the general scan */

	scan_flag = 1;
	while (scan_flag && !done_flag)
		{
		/* time check for ply zero */

		if (top_flag && ClockPastNextCandidate())
			{
			/* possible search abort */

			if (!ct_wump(expectation) &&
				((expectation - prior_expectation) > -pval_p))
				AbortSearch();
			};

		/* get a candidate move */

		if (search_abort)
			{
			dmptr = NULL;
			best = cpev_bust;
			done_flag = 1;
			}
		else
			{
			/* get the next candidate */

			dmptr = PVSPickMove(dsptr);

			/* process quiescence search quick discard */

			weakcapt_flag = 0;
			if (qs_flag && (dmptr != NULL) && !(dmptr->m_flag & mf_chec))
				{
				cutoff =
					material_eval + cp_poslimit +
					BestCaptureGainMove(dmptr);
				if (cutoff <= (alpha - captwin))
					weakcapt_flag = 1;
				};

			/* all candidates processed? */

			if (dmptr == NULL)
				{
				/* mark scan completed */

				scan_flag = 0;

				/* additional processing for quiescence search */

				if (qs_flag)
					{
					/* update best score if no good capture */

					if (best < alpha)
						{
						best = alpha;
						PVarWMCut();
						}
					else
						{
						/* determine if "no capture" is best move */

						cutoff =
							TaperScore(material_eval + cp_poslimit);
						if (cutoff > alpha)
							{
							CCSPositional();
							cutoff =
								TaperScore(material_eval + positional_eval);

							if (cutoff > alpha)
								{
								best = cutoff;
								PVarWMCut();
								};
							};
						};
					};

				done_flag = 1;
				}
			else
				{
				/* proceed with the move if it isn't a weak capture */

				if (!weakcapt_flag)
					{
					/* try the candidate */

					ExecuteMove(dsptr->s_mcurr);
					if (!(dsptr->s_mcurr->m_flag & mf_bust))
						{
						/* handle ply zero (pre-recursion) */

						if (top_flag)
							{
							pz_node_count = count_node;
							TLPreRec(index, dsptr);
							};

						/* try narrow search */

						dsptr->s_mcurr->m_eval = value =
							-PVSNode(dsptr->s_mcurr,
							(-alpha - 1), -alpha,
							newdepth, current_sncc);

						/* set awful score on abort */

						if (search_abort)
							dsptr->s_mcurr->m_eval = value = cpev_bust;

						/* handle ply zero (post-recursion; unknown) */

						if (top_flag)
							{
							PlyZeroTrace1(dsptr);
							PZSNCountUpdate();
							};

						/* test for re-search if result is too good */

						if (value > best)
							{
							/* clear the new best move flag */

							newbest_flag = 0;

							/* test value inside unadjusted window */

							if ((value > alpha) && (value < beta))
								{
								/* handle ply zero (pre-recursion) */

								if (top_flag)
									{
									pz_node_count = count_node;
									TLPreRec(index, dsptr);
									};

								/* calculate lower bound for re-search */

								retry_alpha = value - 1;

								/* calculate upper bound for re-search */

								retry_beta = beta;

								/* re-search */

								dsptr->s_mcurr->m_eval = value =
									-PVSNode(dsptr->s_mcurr,
									-retry_beta, -retry_alpha,
									newdepth, current_sncc);

								/* set awful score on abort */

								if (search_abort)
									dsptr->s_mcurr->m_eval =
										value = cpev_bust;

								/* was it an improvement? */

								if (value > best)
									{
									hash_alpha = retry_alpha;
									hash_beta = retry_beta;
									best = value;
									newbest_flag = 1;
									};

								/* auxiliary statistics */

								ans_researches++;
								}
							else
								{
								hash_alpha = alpha;
								hash_beta = alpha + 1;
								best = value;
								newbest_flag = 1;
								};

							/* handle post recursion */

							if (newbest_flag)
								{
								/* insure alpha update */

								if (alpha < best)
									{
									alpha = best;
									PVarWMMerge(dsptr->s_mcurr);
									};

								/* assign as best move; merge the PV */

								dsptr->s_mbest = dsptr->s_mcurr;

								/* handle ply zero (postrec, best) */

								if (top_flag)
									{
									TLPostRec(best, dsptr);
									PZSNCountUpdate();
									};

								/* update the best pvs move */

								pvs_m = *dsptr->s_mcurr;
								}
							else
								{
								/* handle ply zero (postrec, not best) */

								if (top_flag)
									{
									PlyZeroTrace1(dsptr);
									PZSNCountUpdate();
									};
								};
							};

						/* test for beta cutoff */

						if (best >= beta)
							{
							scan_flag = 0;
							done_flag = 1;
							};

						/* test for adequate mating move */

						if (ct_mate(best))
							if ((best >= (cpev_mate - iteration)) ||
								top_flag)
								{
								scan_flag = 0;
								done_flag = 1;
								};
						};

					/* undo */

					RetractMove(dsptr->s_mcurr);

					/* PV update */

					if (pv_flag)
						{
						pv_flag = 0;
						if (!search_abort)
							PVarPlyZeroProcess();
						};

					/* refutation sequence update */

					if (top_flag && !search_abort)
						RefuteBindSequence();

					/* deallocate moves */

					MovesetDisconnectRelease(dsptr->s_mcurr);
					};

				/* bump move selection index */

				index++;
				};
			};
		};
	};

/* return value */

if (best > beta)
	value = beta;
else
	if (best < alpha)
		value = alpha;
	else
		value = best;

/* record killer information */

if (!null_move(pvs_m) && !search_abort)
	{
	/* set the transposition table entry */

	if (!qs_flag && (depth >= 0))
		TTInsert(&pvs_m, hash_alpha, hash_beta, value);

	/* set killer response entry */

	if (!null_move_ref(mptr))
		{
		smptr = killer_response_base +
			offset_rcsqsq(actc, mptr->m_frsq, tosq);
		smptr->sm_frsq = pvs_m.m_frsq;
		smptr->sm_tosq = pvs_m.m_tosq;
		};

	/* update the killer trio of moves for this ply */

	KillerTrioUpdate(pvs_m.m_frsq, pvs_m.m_tosq);

	/* update the counter killer value */

	if ((cptr != NULL) && (cptr->s_mprev != NULL))
		KillerSetCounter(cptr->s_mprev, mptr, &pvs_m);
	};

/* restore values: extension count usage */

ec_used_dbl = ec_save_dbl;
ec_used_dis = ec_save_dis;
ec_used_p7r = ec_save_p7r;
ec_used_scr = ec_save_scr;

/* restore values: extension count flags */

ec_used_rcp = ec_save_rcp;

/* clear the "first time down" flags */

FTDIteration = FTDPlyZeroMove = 0;

/* auxiliary statistics */

if (index == 0)
	ans_terminal_nodes++;
else
	{
	if (index == 1)
		ans_singleton_nodes++;
	ans_interior_nodes++;
	ans_index_sum += index;
	};

if (qs_flag)
	ans_quiescence_nodes++;

/* color class statistics */

if (!qs_flag && (index > 0))
	{
	cc_countv[parent_sncc]++;
	cc_indexv[parent_sncc] += index;
	cc_widthv[parent_sncc] += width;
	};

/* node count */

count_node++;

/* test trace */

if (optnv[optn_test])
	{
	PrStrCentipawn("EV: ", value);
	PrBlanks(3);
	PrCurrentPath();
	PrNL();
	};

return (value);
}

/*--> PVSSearch: select a move based on PVS algorithm */
nonstatic
mptrT
PVSSearch(void)
{
mptrT mptr;
siT stop_flag;
snccT sncc;
cpevT alpha, beta, score;

/* set default best move indication */

root_sptr->s_mbest = root_sptr->s_mcurr = root_sptr->s_mbase;
pvsbest_m = *root_sptr->s_mbase;

/* clear the extension usage counts */

ec_used_dbl = ec_used_dis = ec_used_p7r = ec_used_scr = 0;

/* clear the extension flags */

ec_used_rcp = 0;

/* clear the auxiliary node statistics */

ans_index_sum = 0;
ans_interior_nodes = 0;
ans_nullcount = 0;
ans_null_alpha_nodes = 0;
ans_null_beta_nodes = 0;
ans_oracular_nodes = 0;
ans_quiescence_nodes = 0;
ans_researches = 0;
ans_singleton_nodes = 0;
ans_terminal_nodes = 0;

/* clear the color class statistics */

for (sncc = 0; sncc < snccL; sncc++)
	cc_countv[sncc] = cc_indexv[sncc] = cc_widthv[sncc] = 0;

/* set up for iterations */

stop_flag = 0;
iteration = 1;

/* display items initialization */

di_p0span = root_sptr->s_count;
di_p0pick = root_sptr->s_mbest - root_sptr->s_mbase;
di_p0m = *root_sptr->s_mbest;

/* display items update */

SIDUpdate();

/* reset the search flags */

MovesetSearchReset(root_sptr);

/* perform iterations */

while (!stop_flag && !ClockPastNextIteration() && (iteration <= level))
	{
	/* save the prior expectation */

	prior_expectation = expectation;

	/* report */

	if (optnv[optn_trab] && ponder_trace)
		{
		PrTrace("AB");
		PrStr("PVS iteration: ");
		PrTwoDigitSI(iteration);
		PrStrLI("   time: ", (time(NULL) - search_start_time));
		PrStrCentipawn("   expectation: ", expectation);
		PrNL();
		};

	/* set the "first time down" flags for this iteration */

	FTDIteration = FTDPlyZeroMove = 1;

	/* set the search bounds */

	alpha = cpev_bust;
	beta = cpev_mate;

	/* perform search */

	score = PVSNode(&root_m, alpha, beta, iteration, sncc_red);

	/* process possible search abort */

	if (!search_abort)
		expectation = score;

	/* display items update */

	SIDUpdate();

	/* process the report exec frequency option */

	if (optnv[optn_trab] && optnv[optn_freq] && ponder_trace)
		PrSearchFrequencyReport(search_start_node, search_start_time);

	/* set stop_flag if a target move exists and is located */

	if (!stop_flag &&
		(LocateListMoveEntry(&pvsbest_m, target_mlstptr) != NULL))
		{
		stop_flag = 1;
		strc = strc_targ;
		};

	/* check for forced mate */

	if (!stop_flag)
		if (ct_mate(expectation))
			{
			stop_flag = 1;
			strc = strc_mate;
			};

	/* check for forced loss */

	if (!stop_flag)
		if (ct_wump(expectation))
			{
			stop_flag = 1;
			strc = strc_bigl;
			};

	/* check for fully certain evaluation */

	if (!stop_flag)
		{
		MovesetCertaintyScan(root_sptr);
		if (root_sptr->s_sflag & sf_cert)
			{
			stop_flag = 1;
			strc = strc_cert;
			};
		};

	/* check for all bad but one */

	if (!stop_flag)
		{
		MovesetAllBadButOneScan(root_sptr);
		if (root_sptr->s_sflag & sf_abbo)
			{
			stop_flag = 1;
			strc = strc_frcd;
			};
		};

	/* check for holding a forced draw for a lone king */

	if (!stop_flag)
		if ((expectation == cpev_draw) &&
			bb_equal(c0bbv[actc], cpbbv[actc_k]) &&
			(root_sptr->s_mbase->m_flag & mfm_certain))
			{
			stop_flag = 1;
			strc = strc_save;
			};

	/* check for search abort request */

	if (search_abort)
		stop_flag = 1;

	/* next iteration */

	if (!stop_flag)
		if (iteration < level)
			{
			iteration++;
			MovesetPrecharge();
			TTScrub();
			}
		else
			{
			stop_flag = 1;
			strc = strc_iter;
			};
	};

/* process the auxiliary statistics report */

if (optnv[optn_trab] && ponder_trace)
	PVSAuxStatReport();

/* process transposition table subsystem trace */

if (optnv[optn_trtt] && ponder_trace)
	TTPrintStatistics();

/* display items update */

SIDUpdate();

/* set best move pointer to final result */

root_sptr->s_mbest =
	FindMoveNF(&pvsbest_m, root_sptr, "PVSSearch");

/* return pointer to the best move in the moveset */

mptr = root_sptr->s_mbest;

return (mptr);
}

/*<<< pvs.c: EOF */
