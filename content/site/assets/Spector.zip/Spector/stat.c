/*>>> stat.c: position/game status routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "bb.h"
#include "draw.h"
#include "moveset.h"
#include "print.h"
#include "stat.h"

/*--> PositionCensusOkay: determine census legality of current database */
nonstatic
siT
PositionCensusOkay(void)
{
siT flag, wps, bps, cn[cpL];
cpT cp;
bbT bb0, bb1;

/* set up flag (default: okay) */

flag = 1;

/* set up counts */

for (cp = cp_wp; cp <= cp_bk; cp++)
	cn[cp] = bb_count(cpbbv[cp]);

/* king count */

if (flag)
	if ((cn[cp_wk] != 1) || (cn[cp_bk] != 1))
		flag = 0;

/* pawn count */

if (flag)
	if ((cn[cp_wp] > 8) || (cn[cp_bp] > 8))
		flag = 0;
	else
		{
		wps = 8 - cn[cp_wp];
		bps = 8 - cn[cp_bp];
		};

/* queen count */

if (flag)
	if ((cn[cp_wq] > (1 + wps)) || (cn[cp_bq] > (1 + bps)))
		flag = 0;
	else
		{
		if (cn[cp_wq] > 1)
			wps -= cn[cp_wq] - 1;
		if (cn[cp_bq] > 1)
			bps -= cn[cp_bq] - 1;
		};

/* rook count */

if (flag)
	if ((cn[cp_wr] > (2 + wps)) || (cn[cp_br] > (2 + bps)))
		flag = 0;
	else
		{
		if (cn[cp_wr] > 2)
			wps -= cn[cp_wr] - 2;
		if (cn[cp_br] > 2)
			bps -= cn[cp_br] - 2;
		};

/* bishop count */

if (flag)
	if ((cn[cp_wb] > (2 + wps)) || (cn[cp_bb] > (2 + bps)))
		flag = 0;
	else
		{
		if (cn[cp_wb] > 2)
			wps -= cn[cp_wb] - 2;
		if (cn[cp_bb] > 2)
			bps -= cn[cp_bb] - 2;
		};

/* knight count */

if (flag)
	if ((cn[cp_wn] > (2 + wps)) || (cn[cp_bn] > (2 + bps)))
		flag = 0;
	else
		{
		if (cn[cp_wn] > 2)
			wps -= cn[cp_wn] - 2;
		if (cn[cp_bn] > 2)
			bps -= cn[cp_bn] - 2;
		};

/* pawn placement */

if (flag)
	{
	bb_ior3(cpbbv[cp_wp], cpbbv[cp_bp], bb0);
	bb_ior3(r0bbv[rank_1], r0bbv[rank_8], bb1);
	if (bb_tstand(bb0, bb1))
		flag = 0;
	};

/* white kingside castling */

if (flag)
	if (envn.envn_cast & cf_wk)
		if ((local.rbv[civ[c_w].ci_homesq] != cp_wk) ||
			(local.rbv[civ[c_w].ci_krfrsq] != cp_wr))
				flag = 0;

/* black kingside castling */

if (flag)
	if (envn.envn_cast & cf_bk)
		if ((local.rbv[civ[c_b].ci_homesq] != cp_bk) ||
			(local.rbv[civ[c_b].ci_krfrsq] != cp_br))
				flag = 0;

/* white queenside castling */

if (flag)
	if (envn.envn_cast & cf_wq)
		if ((local.rbv[civ[c_w].ci_homesq] != cp_wk) ||
			(local.rbv[civ[c_w].ci_qrfrsq] != cp_wr))
				flag = 0;

/* black queenside castling */

if (flag)
	if (envn.envn_cast & cf_bq)
		if ((local.rbv[civ[c_b].ci_homesq] != cp_bk) ||
			(local.rbv[civ[c_b].ci_qrfrsq] != cp_br))
				flag = 0;

/* en passant square */

if (flag)
	if (envn.envn_epsq != sq_nil)
		if (actc == c_w)
			{
			if ((map_rank(envn.envn_epsq) != rank_6) ||
				(local.rbv[envn.envn_epsq + dv_3] != cp_bp))
				flag = 0;
			}
		else
			{
			if ((map_rank(envn.envn_epsq) != rank_3) ||
				(local.rbv[envn.envn_epsq + dv_1] != cp_wp))
				flag = 0;
			};

/* passive check status */

if (flag)
	if (actc == c_w)
		{
		if (bb_tstand(cpbbv[cp_bk], acbbv[c_w]))
			flag = 0;
		}
	else
		{
		if (bb_tstand(cpbbv[cp_wk], acbbv[c_b]))
			flag = 0;
		};

return (flag);
}

/*--> GameStatus: calculate game status */
nonstatic
gsT
GameStatus(sptrT sptr)
{
gsT gs;

/* set default value */

gs = gs_norm;

/* check for illegal position */

if (!PositionCensusOkay())
	gs = gs_bust;

/* look for various mates */

if (gs == gs_norm)
	if (CountLegalMoves(sptr) == 0)
		if (actc == c_w)
			if (bb_tstand(cpbbv[cp_wk], acbbv[c_b]))
				gs = gs_wkcm;
			else
				gs = gs_wksm;
		else
			if (bb_tstand(cpbbv[cp_bk], acbbv[c_w]))
				gs = gs_bkcm;
			else
				gs = gs_bksm;

/* check the halfmove clock draw */

if ((gs == gs_norm) && !no_50mvdraw)
	if (DrawHalfMoveClock())
		gs = gs_hmvc;

/* check for insufficient mating material */

if (gs == gs_norm)
	if (DrawInsufficientMaterial())
		gs = gs_imat;

/* check for third time repetition */

if (gs == gs_norm)
	if (DrawRepeatThrice())
		gs = gs_rep3;

/* check for resignations or agreed draw */

if (gs == gs_norm)
	if (gtc == gtc_wwin)
		gs = gs_bres;
	else
		if (gtc == gtc_bwin)
			gs = gs_wres;
		else
			if (gtc == gtc_draw)
				gs = gs_adrw;

/* check for game overflow */

if (gs == gs_norm)
	if (envn.envn_fmvn > fmpL)
		gs = gs_over;

return (gs);
}

/*--> GameStatusNormal: determine if game status is normal */
nonstatic
siT
GameStatusNormal(sptrT sptr)
{

return (GameStatus(sptr) == gs_norm);
}

/*<<< stat.c: EOF */
