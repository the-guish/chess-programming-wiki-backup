/*>>> gen.h: subprogram prototypes for gen.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

sptrT Generate(siT full);
void GenerateInit(void);

/*<<< gen.h: EOF */
