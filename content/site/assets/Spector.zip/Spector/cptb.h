/*>>> cptb.h: subprogram prototypes for cptb.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CPTBCommand(void);

/*<<< cptb.h: EOF */
