/*>>> prelim.h: subprogram prototypes for prelim.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CopyPreliminaries(sptrT sptr);
void PreliminaryEvaluationsPopular(sptrT sptr);
void PreliminaryEvaluationsPlain(sptrT sptr);
void PreliminaryEvaluationsDouble(sptrT sptr);
void PreliminaryEvaluationsBasic(sptrT sptr);
void PreliminaryEvaluationsQuick(sptrT sptr);
void PreliminaryEvaluationsCapture(sptrT sptr);
void PreliminaryEvaluationsSetUp(sptrT sptr);

/*<<< prelim.h: EOF */
