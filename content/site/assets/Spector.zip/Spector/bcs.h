/*>>> bcs.h: subprogram prototypes for bcs.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

mptrT SynthBestMove(mptrT pmptr);
void SetBestMovePointer(sptrT sptr);
void SetBestMovePointer2(sptrT sptr, mptrT amptr);

/*<<< bcs.h: EOF */
