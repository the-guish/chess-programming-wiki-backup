/*>>> pgc.c: PGC routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "pgc.h"
#include "tags.h"

/*--> PGNWriteInt1: write an int-1 to a file */
static
void
PGNWriteInt1(fptrT fptr, byteT int1)
{
fprintf(fptr, "%c", int1);

return;
}

/*--> PGNWriteInt2: write an int-2 to a file */
static
void
PGNWriteInt2(fptrT fptr, siT int2)
{
fprintf(fptr, "%c%c",
	(int2 & byteM),
	((int2 >> byteW) & byteM));

return;
}

#if (0)
/*--> PGNWriteInt4: write an int-4 to a file */
static
void
PGNWriteInt4(fptrT fptr, liT int4)
{
fprintf(fptr, "%c%c%c%c",
	(int4 & byteM),
	((int4 >> byteW) & byteM),
	((int4 >> (byteW * 2)) & byteM),
	((int4 >> (byteW * 3)) & byteM));

return;
}
#endif

/*--> PGNWriteString1: write a string-1 to a file */
static
void
PGNWriteString1(fptrT fptr, liT length, charptrT s)
{
liT i;

PGNWriteInt1(fptr, length);
for (i = 0; i < length; i++)
	PGNWriteInt1(fptr, *(s + i));

return;
}

#if (0)
/*--> PGNWriteString2: write a string-2 to a file */
static
void
PGNWriteString2(fptrT fptr, liT length, charptrT s)
{
liT i;

PGNWriteInt2(fptr, length);
for (i = 0; i < length; i++)
	PGNWriteInt1(fptr, *(s + i));

return;
}
#endif

#if (0)
/*--> PGNWriteString4: write a string-4 to a file */
static
void
PGNWriteString4(fptrT fptr, liT length, charptrT s)
{
liT i;

PGNWriteInt4(fptr, length);
for (i = 0; i < length; i++)
	PGNWriteInt1(fptr, *(s + i));

return;
}
#endif

/*--> PGCWriteRPGC: write the current game in (reduced) PGC to a file */
static
void
PGCWriteRPGC(fptrT fptr)
{
rsvtagT rsvtag;
tagptrT tagptr;
siT ccn;
cordptrT cordptr;

PGNWriteInt1(fptr, 0x01);

for (rsvtag = 0; rsvtag < rsvtagL; rsvtag++)
	{
	tagptr = TagLocate(rsvtagv[rsvtag]);
	PGNWriteString1(fptr, strlen(tagptr->tag_value), tagptr->tag_value);
	};

PGNWriteInt2(fptr, histn);
ccn = 0;
cordptr = cordbase;
while (ccn < histn)
	{
	PGNWriteInt1(fptr, *cordptr);
	ccn++;
	cordptr++;
	};

return;
}

/*--> PGCWriteCurrent: write the current game in PGC to a file */
nonstatic
void
PGCWriteCurrent(fptrT fptr)
{
PGCWriteRPGC(fptr);

return;
}

/*<<< pgc.c: EOF */
