/*>>> refute.h: subprogram prototypes for refute.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void RefuteStart(void);
void RefuteFinish(void);
void RefuteDump(void);
void RefuteShift(siT offset);
void RefuteExchange(siT i0, siT i1);
void RefuteBindSequence(void);
mptrT RefuteFetchMoveRef(void);
siT RefuteCurrentLength(void);

/*<<< refute.h: EOF */
