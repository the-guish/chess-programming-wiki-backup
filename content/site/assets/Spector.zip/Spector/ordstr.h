/*>>> ordstr.h: subprogram prototypes for ordstr.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

charptrT OrdLIStr(liT n);
charptrT OrdSIStr(siT n);

/*<<< ordstr.h: EOF */
