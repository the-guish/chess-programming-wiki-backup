/*>>> cspatt.h: subprogram prototypes for cspatt.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CSPatternPost(sptrT sptr, bpfT bpf);

/*<<< cspatt.h: EOF */
