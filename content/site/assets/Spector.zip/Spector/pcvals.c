/*>>> pcvals.c: process clear/display/reset/set value routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "commdefs.h"
#include "commvars.h"

#include "clock.h"
#include "create.h"
#include "fen.h"
#include "file.h"
#include "gms.h"
#include "gt.h"
#include "init.h"
#include "memutil.h"
#include "moveset.h"
#include "notation.h"
#include "pawn.h"
#include "pcvals.h"
#include "predvar.h"
#include "prelim.h"
#include "print.h"
#include "stat.h"
#include "tags.h"
#include "tt.h"
#include "util.h"

/*--> ProcessCVCA: process clear value: castling availability */
nonstatic
void
ProcessCVCA(void)
{
siT i;
castT vcast;

vcast = 0;
for (i = 1; i < tkn; i++)
	vcast |= ipv[i].ip_cai;

if ((envn.envn_cast & ~vcast) != envn.envn_cast)
	{
	envn.envn_cast &= ~vcast;
	CreateSetUp();
	};

return;
}

/*--> ProcessCVCB: process clear value: chessboard */
nonstatic
void
ProcessCVCB(void)
{
ClearBoard();
envn.envn_cast = 0;
envn.envn_epsq = sq_nil;
envn.envn_hmvc = 0;
CreateSetUp();

return;
}

/*--> ProcessCVCC: process clear value: chess clocks */
nonstatic
void
ProcessCVCC(void)
{
ClockClear();

return;
}

/*--> ProcessCVCF: process clear value: clock flag */
nonstatic
void
ProcessCVCF(void)
{
ClockStop();

return;
}

/*--> ProcessCVEP: process clear value: en passant capture square */
nonstatic
void
ProcessCVEP(void)
{
if (envn.envn_epsq != sq_nil)
	{
	envn.envn_epsq = sq_nil;
	CreateSetUp();
	};

return;
}

/*--> ProcessCVGT: process clear value: game termination code */
nonstatic
void
ProcessCVGT(void)
{
if (!GTCConsistent(gtc_none))
	PrErr("Can't clear game termination code");
else
	GTCSet(gtc_none);

return;
}

/*--> ProcessCVOP: process clear value: option */
nonstatic
void
ProcessCVOP(void)
{
siT i;

for (i = 1; i < tkn; i++)
	optnv[ipv[i].ip_optn] = 0;

return;
}

/*--> ProcessCVSQ: process clear value: squares */
nonstatic
void
ProcessCVSQ(void)
{
siT i, flag;

flag = 0;
i = 1;
while (!flag && (i < tkn))
	if (board.rbv[ipv[i].ip_sq] != cp_v0)
		flag = 1;
	else
		i++;

if (flag)
	{
	for (i = 1; i < tkn; i++)
		InitSq(cp_v0, ipv[i].ip_sq);
	CreateSetUp();
	};

return;
}

/*--> ProcessCVTF: process clear value: tag fields */
nonstatic
void
ProcessCVTF(void)
{
tagptrT tagptr;
siT flag, i;

flag = 1;
i = 1;
while (flag && (i < tkn))
	if ((tagptr = TagLocate(ipv[i].ip_str)) == NULL)
		{
		PrErr("Can't locate tag");
		flag = 0;
		}
	else
		if (tagptr->tag_flag & tagf_perm)
			{
			PrErr("Can't clear permanent tag");
			flag = 0;
			}
		else
			i++;

if (flag)
	for (i = 1; i < tkn; i++)
		TagDelete(TagLocate(ipv[i].ip_str));

return;
}

/*--> ProcessDVAS: process display value: hash address and signature */
nonstatic
void
ProcessDVAS(void)
{
PrStr("Hash address: ");
PrHexDWordLI(envn.envn_mhac);
PrStr("   Hash signature: ");
PrHexDWordLI(envn.envn_mhsc);
PrNL();

return;
}

/*--> ProcessDVCB: process display value: chessboard */
nonstatic
void
ProcessDVCB(void)
{
PrBoard(&board);

return;
}

/*--> ProcessDVCR: process display value: concise report */
nonstatic
void
ProcessDVCR(void)
{
GMSCR(stdout);

return;
}

/*--> ProcessDVCT: process display value: countdown timer */
nonstatic
void
ProcessDVCT(void)
{
PrStrLI("Countdown timer: ", countdown_timer);
PrStr(" (");
PrExpandedTime(countdown_timer);
PrChar(')');
if (countdown_timer == 0)
	PrStr(" (inactive)");
PrNL();

return;
}

/*--> ProcessDVER: process display value: event report */
nonstatic
void
ProcessDVER(void)
{
GMSER(stdout);

return;
}

/*--> ProcessDVFE: process display value: Forsyth-Edwards notation */
nonstatic
void
ProcessDVFE(void)
{
charptrT s;

s = FENGenerate();
PrLine(s);
MemoryFree(s);

return;
}

/*--> ProcessDVLM: process display value: legal moves */
nonstatic
void
ProcessDVLM(void)
{
gsT gs;

gs = GameStatus(root_sptr);
if (gs != gs_norm)
	PrStrGameStatusNL("No moves: ", gs);
else
	if (lang_get == lang_put)
		{
		PrStr("Available move count: ");
		PrCondOrdSINL(root_sptr->s_count);
		PrSANSortList(root_sptr);
		}
	else
		{
		PrStr("Available move count: ");
		PrCondOrdSI(root_sptr->s_count);
		(void) sprintf(stv, " [%s]", langstrv[lang_get]);
		PrSTVNL();
		lang_san = lang_get;
		PrSANSortList(root_sptr);

		PrStr("Available move count: ");
		PrCondOrdSI(root_sptr->s_count);
		(void) sprintf(stv, " [%s]", langstrv[lang_put]);
		PrSTVNL();
		lang_san = lang_put;
		PrSANSortList(root_sptr);
		};

return;
}

/*--> ProcessDVNC: process display value: node countdown */
nonstatic
void
ProcessDVNC(void)
{
PrStrLI("Node countdown: ", node_countdown);
PrStr(" nodes");
if (node_countdown == 0)
	PrStr(" (inactive)");
PrNL();

return;
}

/*--> ProcessDVPE: process display value: preliminary evaluations */
nonstatic
void
ProcessDVPE(void)
{
sptrT sptr;
mptrT mptr;
siT i, count;

sptr = root_sptr;
if (sptr == NULL)
	PrErr("No moves");
else
	{
	PreliminaryEvaluationsPlain(sptr);
	count = sptr->s_count;
	mptr = sptr->s_mbase;
	for (i = 0; i < count; i++)
		{
		PrPaddedSAN(mptr);
		PrStrCentipawn("   prel: ", mptr->m_prel);
		PrBlank();
		PrMoveFlags(mptr);
		if (mptr->m_dptr != NULL)
			{
			PrBlank();
			PrMovesetFlags(mptr->m_dptr);
			};
		PrNL();
		mptr++;
		};
	};

return;
}

/*--> ProcessDVPM: process display value: predicted move */
nonstatic
void
ProcessDVPM(void)
{
mptrT mptr;

/* test game status */

if (!GameStatusNormal(root_sptr))
	mptr = NULL;
else
	{
	/* check if a predicted variation exists */

	if (PVarELength() > 0)
		mptr = FindMoveNF(PVarEFirstMoveRef(), root_sptr,
			"ProcessDVPM");
	else
		mptr = NULL;
	};

if (mptr == NULL)
	PrLine("No predicted move exists.");
else
	PrSANNL(mptr);

return;
}

/*--> ProcessDVPV: process display value: predicted variation */
nonstatic
void
ProcessDVPV(void)
{
if (!PVarELength())
	PrLine("No predicted variation available.");
else
	PVarEPrint();

return;
}

/*--> ProcessDVSS: process display value: search strategies */
nonstatic
void
ProcessDVSS(void)
{
cT c;

for (c = c_w; c <= c_b; c++)
	{
	PrPlayer(c);
	PrTwoStrsNL(": ", strtstrv[strtv[c]]);
	};

return;
}

/*--> ProcessDVTC: process display value: time control */
nonstatic
void
ProcessDVTC(void)
{
siT i;
liT mvc, sec;

for (i = 0; i < tcntlL; i++)
	{
	PrStr("Period ");
	PrCondOrdSI((i + 1));
	PrStr(" is ");
	sec = tcntlv[i].tcntl_sec;
	if (sec == 0)
		PrStr("instantaneous");
	else
		{
		if ((mvc = tcntlv[i].tcntl_mvc) == 0)
			PrStr("game");
		else
			{
			PrCondOrdLI(mvc);
			PrStr(" moves");
			};
		PrStr(" in ");
		PrCondOrdLI(sec);
		PrStr(" seconds");
		}
	PrChar('.');
	PrNL();
	};

return;
}

/*--> ProcessDVTE: process display value: tag environment */
nonstatic
void
ProcessDVTE(void)
{
TagFilePrintAll(stdout);

return;
}

/*--> ProcessDVTF: process display value: tag fields */
nonstatic
void
ProcessDVTF(void)
{
tagptrT tagptr;
siT i, flag;

flag = 1;
i = 1;
while (flag && (i < tkn))
	if ((tagptr = TagLocate(ipv[i].ip_str)) == NULL)
		{
		PrErr("Can't locate tag");
		flag = 0;
		}
	else
		i++;;

if (flag)
	for (i = 1; i < tkn; i++)
		TagFilePrint(stdout, TagLocate(ipv[i].ip_str));

return;
}

/*--> ProcessDVTS: process display value: timestamp */
nonstatic
void
ProcessDVTS(void)
{
PrTimestamp();

return;
}

/*--> ProcessDVTT: process display value: transposition table order */
nonstatic
void
ProcessDVTT(void)
{
PrStrLINL("Transposition table order: ", tt_hash_order);
PrStrLINL("Transposition table entry count: ", tt_hash_size);

return;
}

/*--> ProcessEVCA: process estimate value: castling availability */
nonstatic
void
ProcessEVCA(void)
{
castT vcast;

vcast = 0;

/* white castling */

if (local.rbv[civ[c_w].ci_homesq] == cp_wk)
	{
	if (local.rbv[civ[c_w].ci_krfrsq] == cp_wr)
		vcast = vcast | cf_wk;
	if (local.rbv[civ[c_w].ci_qrfrsq] == cp_wr)
		vcast = vcast | cf_wq;
	};

/* black castling */

if (local.rbv[civ[c_b].ci_homesq] == cp_bk)
	{
	if (local.rbv[civ[c_b].ci_krfrsq] == cp_br)
		vcast = vcast | cf_bk;
	if (local.rbv[civ[c_b].ci_qrfrsq] == cp_br)
		vcast = vcast | cf_bq;
	};

/* update */

if (envn.envn_cast != vcast)
	{
	envn.envn_cast = vcast;
	CreateSetUp();
	};

return;
}

/*--> ProcessEVTE: process estimate value: tag environment */
nonstatic
void
ProcessEVTE(void)
{
PrErr("Not yet implemented");

return;
}

/*--> ProcessEVTF: process estimate value: tag fileds */
nonstatic
void
ProcessEVTF(void)
{
PrErr("Not yet implemented");

return;
}

/*--> ProcessRVCA: process reset value: castling availability */
nonstatic
void
ProcessRVCA(void)
{
if (envn.envn_cast != 0)
	{
	envn.envn_cast = 0;
	CreateSetUp();
	};

return;
}

/*--> ProcessRVCC: process reset value: chess clock */
nonstatic
void
ProcessRVCC(void)
{
ClockClear();
ClockStart();

return;
}

/*--> ProcessRVCT: process reset value: countdown timer */
nonstatic
void
ProcessRVCT(void)
{
countdown_timer = 0;

return;
}

/*--> ProcessRVHT: process reset value: hash tables */
nonstatic
void
ProcessRVHT(void)
{
TTReset();
PawnTTReset();

return;
}

/*--> ProcessRVNC: process reset value: node countdown */
nonstatic
void
ProcessRVNC(void)
{
node_countdown = 0;

return;
}

/*--> ProcessRVOP: process reset value: option set */
nonstatic
void
ProcessRVOP(void)
{
optnT optn;

for (optn = 0; optn < optnL; optn++)
	optnv[optn] = 0;

return;
}

/*--> ProcessRVSS: process reset value: search strategies */
nonstatic
void
ProcessRVSS(void)
{
/* set the default player strategies */

strtv[c_w] = strtv[c_b] = default_strt;

return;
}

/*--> ProcessRVTC: process reset value: time control */
nonstatic
void
ProcessRVTC(void)
{
/* reset the time control to the default values */

TimeControlReset();

return;
}

/*--> ProcessSVAC: process set value: active color */
nonstatic
void
ProcessSVAC(void)
{
if (actc != ipv[1].ip_c)
	{
	actc = ipv[1].ip_c;
	pasc = inv_cv[actc];
	CreateSetUp();
	};

return;
}

/*--> ProcessSVCA: process set value: castling availability */
nonstatic
void
ProcessSVCA(void)
{
siT i;
castT vcast;

vcast = 0;
for (i = 1; i < tkn; i++)
	vcast |= ipv[i].ip_cai;

if ((envn.envn_cast | vcast) != envn.envn_cast)
	{
	envn.envn_cast |= vcast;
	CreateSetUp();
	};

return;
}

/*--> ProcessSVCC: process set value: chess clock */
nonstatic
void
ProcessSVCC(void)
{
if (tkn == 2)
	clockv[c_w] = clockv[c_b] = ClockRecode(ipv[1].ip_lint);
else
	{
	clockv[c_w] = ClockRecode(ipv[1].ip_lint);
	clockv[c_b] = ClockRecode(ipv[2].ip_lint);
	};

return;
}

/*--> ProcessSVCF: process set value: clock flag */
nonstatic
void
ProcessSVCF(void)
{
ClockStart();

return;
}

/*--> ProcessSVCT: process set value: countdown timer */
nonstatic
void
ProcessSVCT(void)
{
countdown_timer = ipv[1].ip_lint;

return;
}

/*--> ProcessSVEP: process set value: en passant capture square */
nonstatic
void
ProcessSVEP(void)
{
if (envn.envn_epsq != ipv[1].ip_sq)
	{
	envn.envn_epsq = ipv[1].ip_sq;
	CreateSetUp();
	};

return;
}

/*--> ProcessSVFE: process set value: Forsyth-Edwards notation */
nonstatic
void
ProcessSVFE(void)
{
siT flag, change;
rbT new_board;
cT new_actc;
castT new_cast;
sqT new_epsq;
siT new_hmvc, new_fmvn;

/* set running flag */

flag = 1;

/* clear change flag */

change = 0;

/* set default values */

new_board = board;
new_actc = actc;
new_cast = envn.envn_cast;
new_epsq = envn.envn_epsq;
new_hmvc = envn.envn_hmvc;
new_fmvn = envn.envn_fmvn;

/* set SAN input mode (required for parameter handling) */

lang_san = lang_get;

/* process board */

if (flag && (tkn >= 2))
	{
	flag = FENParseBD(ipv[1].ip_str, &new_board);
	if (flag && (ByteCmp(&board, &new_board, sizeof(rbT)) != 0))
		change = 1;
	};

if (flag && (tkn >= 3))
	{
	flag = FENParseAC(ipv[2].ip_str, &new_actc);
	if (flag && (actc != new_actc))
		change = 1;
	};

if (flag && (tkn >= 4))
	{
	flag = FENParseCA(ipv[3].ip_str, &new_cast);
	if (flag && (envn.envn_cast != new_cast))
		change = 1;
	};

if (flag && (tkn >= 5))
	{
	flag = FENParseEP(ipv[4].ip_str, &new_epsq);
	if (flag && (envn.envn_epsq != new_epsq))
		change = 1;
	};

if (flag && (tkn >= 6))
	{
	flag = FENParseHC(ipv[5].ip_str, &new_hmvc);
	if (flag && (envn.envn_hmvc != new_hmvc))
		change = 1;
	};

if (flag && (tkn == 7))
	{
	flag = FENParseFN(ipv[6].ip_str, &new_fmvn);
	if (flag && (envn.envn_fmvn != new_fmvn))
		change = 1;
	};

/* set SAN output mode */

lang_san = lang_put;

/* process conversion */

if (!flag)
	PrErr("improper parameter form");
else
	if (change)
		{
		board = new_board;
		actc = new_actc;
		pasc = inv_cv[actc];
		envn.envn_cast = new_cast;
		envn.envn_epsq = new_epsq;
		envn.envn_hmvc = new_hmvc;
		envn.envn_fmvn = new_fmvn;
		CreateSetUp();
		};

return;
}

/*--> ProcessSVHC: process set value: halfmove clock */
nonstatic
void
ProcessSVHC(void)
{
if (envn.envn_hmvc != ipv[1].ip_sint)
	{
	envn.envn_hmvc = ipv[1].ip_sint;
	CreateSetUp();
	};

return;
}

/*--> ProcessSVKO: process set value: kings only position */
nonstatic
void
ProcessSVKO(void)
{
ClearBoard();
InitSq(cp_wk, sq_e1);
InitSq(cp_bk, sq_e8);
envn.envn_cast = 0;
envn.envn_epsq = sq_nil;
envn.envn_hmvc = 0;
CreateSetUp();

return;
}

/*--> ProcessSVMN: process set value: move number */
nonstatic
void
ProcessSVMN(void)
{
if (ipv[1].ip_sint == 0)
	PrErr("Move number must be positive");
else
	if (envn.envn_fmvn != ipv[1].ip_sint)
		{
		envn.envn_fmvn = ipv[1].ip_sint;
		CreateSetUp();
		};

return;
}

/*--> ProcessSVNC: process set value: node countdown */
nonstatic
void
ProcessSVNC(void)
{
node_countdown = ipv[1].ip_lint;

return;
}

/*--> ProcessSVNL: process set value: notational language */
nonstatic
void
ProcessSVNL(void)
{
if (tkn == 2)
	lang_get = lang_put = ipv[1].ip_lang;
else
	{
	lang_get = ipv[1].ip_lang;
	lang_put = ipv[2].ip_lang;
	};

return;
}

/*--> ProcessSVNM: process set value: notation mode */
nonstatic
void
ProcessSVNM(void)
{
global_nm = ipv[1].ip_nm;

return;
}

/*--> ProcessSVOP: process set value: option */
nonstatic
void
ProcessSVOP(void)
{
siT i;

for (i = 1; i < tkn; i++)
	optnv[ipv[i].ip_optn] = 1;

return;
}

/*--> ProcessSVPL: process set value: playing level */
nonstatic
void
ProcessSVPL(void)
{
siT val;

val = ipv[1].ip_sint;
if ((val < 0) || (val >= plyL))
	PrErr("Level out of range");
else
	level = val;

return;
}

/*--> ProcessSVSQ: process set value: square */
nonstatic
void
ProcessSVSQ(void)
{
siT i, flag;

flag = 0;
i = 1;
while (!flag && (i < tkn))
	if (board.rbv[ipv[i].ip_cpsq.cpsq_sq] != ipv[i].ip_cpsq.cpsq_cp)
		flag = 1;
	else
		i++;

if (flag)
	{
	for (i = 1; i < tkn; i++)
		InitSq(ipv[i].ip_cpsq.cpsq_cp, ipv[i].ip_cpsq.cpsq_sq);
	CreateSetUp();
	};

return;
}

/*--> ProcessSVSS: process set value: search strategies */
nonstatic
void
ProcessSVSS(void)
{
if (tkn == 2)
	strtv[c_w] = strtv[c_b] = ipv[1].ip_strt;
else
	{
	strtv[c_w] = ipv[1].ip_strt;
	strtv[c_b] = ipv[2].ip_strt;
	};

return;
}

/*--> ProcessSVTC: process set value: time control */
nonstatic
void
ProcessSVTC(void)
{
siT period;

if (tkn == 3)
	{
	for (period = 0; period < (tcntlL - 1); period++)
		{
		tcntlv[period].tcntl_mvc = ipv[1].ip_lint;
		tcntlv[period].tcntl_sec = ipv[2].ip_lint;
		};
	PrStr("Current time control: ");
	PrCurrentTimeControl();
	}
else
	{
	period = ((siT) ipv[3].ip_lint) - 1;
	if ((period < 0) || (period >= (tcntlL - 1)))
		PrErr("Time control period selection out of range");
	else
		{
		tcntlv[period].tcntl_mvc = ipv[1].ip_lint;
		tcntlv[period].tcntl_sec = ipv[2].ip_lint;
		PrStr("Current time control: ");
		PrCurrentTimeControl();
		};
	};

return;
}

/*--> ProcessSVTF: process set value: tag field */
nonstatic
void
ProcessSVTF(void)
{
tagptrT tagptr;

if ((tagptr = TagLocate(ipv[1].ip_str)) != NULL)
	if (tagptr->tag_flag & tagf_read)
		PrErr("Can't change read only tag value");
	else
		TagAssign(tagptr, ipv[2].ip_str);
else
	{
	tagptr = TagCreate(ipv[1].ip_str, 0);
	TagInsert(tagptr);
	TagAssign(tagptr, ipv[2].ip_str);
	};

return;
}

/*--> ProcessSVTT: process set value: transposition table order */
nonstatic
void
ProcessSVTT(void)
{
liT order;

order = ipv[1].ip_lint;
if (order < 0)
	PrErr("Value must be non-negative");
else
	TTSetOrder(order);

return;
}

/*<<< pcvals.c: EOF */
