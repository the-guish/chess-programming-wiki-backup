/*>>> prelude.c: general tree search prelude/postlude routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "tbdefs.h"

#include "assist.h"
#include "killer.h"
#include "memutil.h"
#include "prelim.h"
#include "predvar.h"
#include "prelude.h"
#include "print.h"
#include "refute.h"
#include "tbcache.h"
#include "ts.h"
#include "tt.h"

/*--> Prelude: perform common pre-search tasks */
nonstatic
void
Prelude(void)
{
siT i;
liptrT liptr;

/* killer repsonse move setup */

KillerReset();
KillerPresetResponse();

/* clear tactical search move response data */

TSClearMoveResponse();

/* clear tactical search killer move data */

TSClearKillerMoves();

/* initialize the transposition table subsystem for an updated position */

TTResetStatistics();
TTScrub();

/* reset the PV working matrix */

PVarWMReset();

/* set up preliminary scores and sort */

PreliminaryEvaluationsSetUp(root_sptr);

/* set initial values for evaluation components */

CopyPreliminaries(root_sptr);

/* set up the refutation subsystem */

RefuteStart();

/* allocate and clear the ply zero search node count storage */

pzsnc_base = (liptrT) MemoryGrab(sizeof(liT) * root_sptr->s_count);
liptr = pzsnc_base;
for (i = 0; i < root_sptr->s_count; i++)
	*liptr++ = 0;

/* calculate initial expectation as maximum of first level moveset */

expectation = root_sptr->s_mbest->m_eval = root_sptr->s_mbest->m_prel;

return;
}

/*--> Postlude: perform common post-search tasks */
nonstatic
void
Postlude(void)
{
/* clear the iteration index */

iteration = 0;

/* deallocate the ply zero search node count storage */

MemoryFree(pzsnc_base);

/* close the refutation subsystem */

RefuteFinish();

/* flush any tablebase cache storage */

TBCacheFlush();

/* transposition table usage report */

if (optnv[optn_trtt] && ponder_trace)
	TTReportUsage();

/* commentary */

if (optnv[optn_trab] && ponder_trace)
	{
	PrTrace("AB");
	PrStrCentipawnNL("expectation: ", expectation);
	};

/* wump evaluation */

if (optnv[optn_wump] && ponder_trace)
	if (ct_wump(expectation))
		PrLine("You have a forced mate.");

/* resignation offers */

if (optnv[optn_rsgn] && ponder_trace)
	if (expectation < cpev_wham)
		PrLine("Please, no more!  I give up already!");
	else
		if (expectation < cpev_rsgn)
			PrLine("Chungo Lungo!  I offer to resign the game.");

/* resignation requests */

if (optnv[optn_rsgn] && ponder_trace)
	if (expectation > -cpev_wham)
		PrLine("Why are you still playing?  RESIGN NOW!");
	else
		if (expectation > -cpev_rsgn)
			PrLine("You should resign the game.");

/* final search display update */

SIDUpdate();

return;
}

/*<<< prelude.c: EOF */
