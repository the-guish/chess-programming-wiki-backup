/*>>> eval.c: position evaluation */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "epos.h"
#include "eval.h"
#include "print.h"
#include "sx.h"
#include "ts.h"

/*--> EvaluateMaterial: evaluate material components */
nonstatic
cpevT
EvaluateMaterial(void)
{
cpevT material;

/* trace material */

if (optnv[optn_trev] && ponder_trace)
	{
	PrTrace("EV");
	PrStrCentipawnNL("w/mat: ", envn.envn_mcpv[c_w]);
	PrTrace("EV");
	PrStrCentipawnNL("b/mat: ", envn.envn_mcpv[c_b]);
	};

/* simple for now */

if (actc == c_w)
	material = envn.envn_mcpv[c_w] - envn.envn_mcpv[c_b];
else
	material = envn.envn_mcpv[c_b] - envn.envn_mcpv[c_w];

return (material);
}

/*--> Evaluate: evaluate position (all components) */
nonstatic
cpevT
Evaluate(void)
{
cpevT score;
cpevT t_score;

/* calculate components */

t_score = TSEval();
if (ct_bigl(t_score) || ct_bigw(t_score))
	score = t_score;
else
	score = t_score + EvaluatePositional();

return (score);
}

/*--> EvaluateAB: evaluate position (all components with bounds) */
nonstatic
cpevT
EvaluateAB(cpevT alpha, cpevT beta)
{
cpevT score;

/* calculate components */

score = TSEvalAB(alpha, beta) + EvaluatePositional();

return (score);
}

/*<<< eval.c: EOF */
