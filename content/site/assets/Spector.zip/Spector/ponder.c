/*>>> ponder.c: ponder search (search on opponent's time) */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "exec.h"
#include "hint.h"
#include "moveset.h"
#include "play.h"
#include "ponder.h"
#include "predvar.h"
#include "print.h"
#include "select.h"
#include "stat.h"

/*--> PonderSearchReset: reset ponder search items */
nonstatic
void
PonderSearchReset(void)
{
ponder_active = 0;
ponder_result = 0;
ponder_trace = 1;
ponder_manual_stop = 0;
ponder_match = 0;
ponder_mismatch = 0;
ponder_m = null_m;

return;
}

/*--> PonderTestPredictedMove: check for usuable predicted move */
nonstatic
siT
PonderTestPredictedMove(void)
{
siT flag;
mptrT mptr;
gsT gs;

/* clear result */

flag = 0;

/* Is a hint needed? */

if (PVarELength() == 0)
	(void) FindHint();

/* does a predicted move exist? */

if (PVarELength() > 0)
	{
	/* locate pointer to predicted move in the tree */

	mptr = FindMoveNF(PVarEFirstMoveRef(), root_sptr,
		"PonderTestPredictedMove");

	/* expand upon tree move to get post-move game status */

	ExecuteMove(mptr);
	MovesetGenerateConnect(mptr);
	gs = GameStatus(mptr->m_dptr);
	RetractMove(mptr);

	/* is the move non-terminating? */

	if (gs == gs_norm)
		flag = 1;
	};

return (flag);
}

/*--> PonderSetPredictedMove: process opponent's predicted move */
static
void
PonderSetPredictedMove(void)
{
/* does a predicted move exist? */

if (PonderTestPredictedMove())
	ponder_m = *PVarEFirstMoveRef();
else
	ponder_m = null_m;

return;
}

/*--> PonderSearch: perform ponder search */
nonstatic
void
PonderSearch(void)
{
siT code;
char tv[tL];

/* general reset */

PonderSearchReset();

/* adjust tracing flag */

ponder_trace = optnv[optn_teps];

/* notification */

if (optnv[optn_verb])
	PrLine("The ponder search has started.");

/* proceed if a predicted move is available */

if (!PonderTestPredictedMove())
	{
	/* report */

	if (optnv[optn_verb])
		PrLine("No predicted move available for ponder search.");
	}
else
	{
	/* set up predicted move */

	PonderSetPredictedMove();

	/* report */

	if (optnv[optn_verb])
		PrStrSANNL("Ponder search predicted move: ", &ponder_m);

	/* mark ponder active */

	ponder_active = 1;

	/* play predicted move */

	PlayMove(&ponder_m);

	/* search for program move */

	SelectMove();

	/* mark ponder search inactive (already inactive if transformed) */

	ponder_active = 0;

	/* handle interaction if no manual stop occurred */

	if (!ponder_manual_stop)
		{
		/* print notification */

		PrLine("The ponder search has concluded normally.");
		PrStrSANNL("Selected move: ", root_sptr->s_mbest);

		/* set mismatch indicator if required */

		PrStrSANNL("The predicted move was: ", &ponder_m);
		code = -1;
		while (code == -1)
			{
			PrLine("Was this correct (0=no, 1=yes)?");
			tv[0] = ascii_nul;
			(void) fgets(tv, tL, stdin);
			if (sscanf(tv, sfs_si, &code) != 1)
				code = -1;
			else
				switch (code)
					{
					case 0:
						ponder_match = 0;
						ponder_mismatch = 1;
						break;

					case 1:
						ponder_match = 1;
						ponder_mismatch = 0;
						break;

					default:
						code = -1;
						break;
					};
			};
		};

	/* check if search was successful */

	if (!ponder_mismatch)
		{
		/* report */

		if (optnv[optn_verb])
			PrStrSANNL("Move located by ponder search: ",
				root_sptr->s_mbest);

		/* set result flag */

		ponder_result = 1;

		/* play selected move (clears result flag) */

		ProgramMove();
		}
	else
		{
		/* unsuccessful ponder search, unplay incorrect prediction */

		UnplayMove();

		/* report */

		if (optnv[optn_verb])
			PrLine("No move located by ponder search.");
		};
	};

/* notification */

if (optnv[optn_verb])
	PrLine("The ponder search has concluded.");

/* set tracing flag */

ponder_trace = 1;

return;
}

/*<<< ponder.c: EOF */
