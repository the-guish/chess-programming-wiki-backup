/*>>> epos.h: subprogram prototypes for epos.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

cpevT EvaluatePositional(void);
void EvaluatePositionalInit(void);

/*<<< epos.h: EOF */
