/*>>> csdefs.h: concept search definitions */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/**** Basic Patterns */

/* The basic pattern type */

typedef siT bpT;

#define bpL 27

#define bp_nil (-1)

#define bp_none         0 /* () no basic pattern */
#define bp_active       1 /* (cp0/sq0) active piece */
#define bp_activeking   2 /* (cp0/sq0) active king */
#define bp_adverse      3 /* (cp0/sq0/cp1/sq1) enemy mutual attack */
#define bp_attacked     4 /* (cp0/sq0) attacked */
#define bp_attacks      5 /* (cp0/sq0/cp1/sq1) cpsq0 attacks cpsq1 */
#define bp_checkmated   6 /* () checkmated */
#define bp_connected    7 /* (cp0/sq0/cp1/sq1) friendly mutual defend */
#define bp_defended     8 /* (cp0/sq0) defended */
#define bp_defends      9 /* (cp0/sq0/cp1/sq1) cpsq0 defends cpsq1 */
#define bp_discover    10 /* (cp0/sq0/cp1/sq1/cp2/sq2) discover attack */
#define bp_drawn       11 /* () general draw */
#define bp_exchangable 12 /* (cp0/sq0) exchangable */
#define bp_exists      13 /* (cp0/sq0) exists */
#define bp_fiftymove   14 /* () drawn (fifty move rule) */
#define bp_hung        15 /* (cp0/sq0) hung */
#define bp_indirect    16 /* (cp0/sq0/cp1/sq1/cp2/sq2) indirect attack */
#define bp_jeopardy    17 /* (cp0/sq0/cp1/sq1) subject to losing capture */
#define bp_move        18 /* (cp0/sq0/cp1/sq1/scmv) any move */
#define bp_outofwood   19 /* () drawn (insufficient material) */
#define bp_passive     20 /* (cp0/sq0) passive piece */
#define bp_passiveking 21 /* (cp0/sq0) passive king */
#define bp_protected   22 /* (cp0/sq0) protected */
#define bp_repeated    23 /* () repeated position */
#define bp_stalemated  24 /* () drawn (stalemated) */
#define bp_thirdrepeat 25 /* () drawn (third repetition) */
#define bp_unconnected 26 /* (cp0/sq0) unconnected */

/* the basic pattern mask bits */

typedef siT bpmbT;

#define bpmb_bp   bit_00 /* basic pattern id */
#define bpmb_iv0  bit_01 /* general integer value 0 */
#define bpmb_iv1  bit_02 /* general integer value 1 */
#define bpmb_cp0  bit_03 /* primary color/piece */
#define bpmb_sq0  bit_04 /* primary square */
#define bpmb_cp1  bit_05 /* secondary color/piece */
#define bpmb_sq1  bit_06 /* secondary square */
#define bpmb_cp2  bit_07 /* tertiary color/piece */
#define bpmb_sq2  bit_08 /* tertiary square */
#define bpmb_cp3  bit_09 /* quartinary color/piece */
#define bpmb_sq3  bit_10 /* quartinary square */
#define bpmb_scmv bit_11 /* special case move indication */

/* the basic pattern mask type */

typedef siT bpmT;

/* useful basic pattern mask (bit fields) */

#define bpmbf_cpsq0 (bpmb_cp0 | bpmb_sq0)
#define bpmbf_sing  (bpmbf_cpsq0)
#define bpmbf_cpsq1 (bpmb_cp1 | bpmb_sq1)
#define bpmbf_pair  (bpmbf_sing | bpmbf_cpsq1)
#define bpmbf_cpsq2 (bpmb_cp2 | bpmb_sq2)
#define bpmbf_trip  (bpmbf_pair | bpmbf_cpsq2)
#define bpmbf_cpsq3 (bpmb_cp3 | bpmb_sq3)
#define bpmbf_quad  (bpmbf_trip | bpmbf_cpsq3)
#define bpmbf_move  (bpmbf_pair | bpmb_scmv)

/* basic pattern masks */

#define bpm_none        (bpmb_bp)
#define bpm_active      (bpmb_bp | bpmbf_sing)
#define bpm_activeking  (bpmb_bp | bpmbf_sing)
#define bpm_adverse     (bpmb_bp | bpmbf_pair)
#define bpm_attacked    (bpmb_bp | bpmbf_sing)
#define bpm_attacks     (bpmb_bp | bpmbf_pair)
#define bpm_checkmated  (bpmb_bp)
#define bpm_connected   (bpmb_bp | bpmbf_pair)
#define bpm_defended    (bpmb_bp | bpmbf_sing)
#define bpm_defends     (bpmb_bp | bpmbf_pair)
#define bpm_discover    (bpmb_bp | bpmbf_trip)
#define bpm_drawn       (bpmb_bp)
#define bpm_exchangable (bpmb_bp | bpmbf_sing)
#define bpm_exists      (bpmb_bp | bpmbf_sing)
#define bpm_fiftymove   (bpmb_bp)
#define bpm_hung        (bpmb_bp | bpmbf_sing)
#define bpm_indirect    (bpmb_bp | bpmbf_trip)
#define bpm_jeopardy    (bpmb_bp | bpmbf_pair)
#define bpm_move        (bpmb_bp | bpmbf_move)
#define bpm_outofwood   (bpmb_bp)
#define bpm_passive     (bpmb_bp | bpmbf_sing)
#define bpm_passiveking (bpmb_bp | bpmbf_sing)
#define bpm_protected   (bpmb_bp | bpmbf_sing)
#define bpm_repeated    (bpmb_bp)
#define bpm_stalemated  (bpmb_bp)
#define bpm_thirdrepeat (bpmb_bp)
#define bpm_unconnected (bpmb_bp | bpmbf_sing)

/* The basic pattern descriptor type */

typedef void (*frvsptrptrT)(sptrT sptr);

typedef struct bpdS
    {
    char        *bpd_name; /* basic pattern name */
    frvsptrptrT bpd_genf;  /* generation function */
    bpmT        bpd_bpm;   /* matchable items mask */
    } bpdT, bpdptrT;

/* The basic pattern frame type (mi_x components are matchable items) */

typedef struct bpfS
    {
    bpT     bpf_bp;        /* (mi_0) basic pattern id */
    siT     bpf_iv0;       /* (mi_1) general integer value 0 */
    siT     bpf_iv1;       /* (mi_2) general integer value 1 */
    cpT     bpf_cp0;       /* (mi_3) color piece 0 */
    sqT     bpf_sq0;       /* (mi_4) square 0 */
    cpT     bpf_cp1;       /* (mi_5) color piece 1 */
    sqT     bpf_sq1;       /* (mi_6) square 1 */
    cpT     bpf_cp2;       /* (mi_7) color piece 2 */
    sqT     bpf_sq2;       /* (mi_8) square 2 */
    cpT     bpf_cp3;       /* (mi_9) color piece 3 */
    sqT     bpf_sq3;       /* (mi_a) square 3 */
    scmvT   bpf_scmv;      /* (mi_b) special case move indication */
    struct bpfS *bpf_next; /* next bpf */
    struct bpfS *bpf_prev; /* prev bpf */
    } bpfT, *bpfptrT;

/* The concept notation type (attached to movesets; see s_cnptr in defs.h) */

typedef struct cnS
    {
    bpfptrT cn_bpfhead; /* head of bpf list */
    bpfptrT cn_bpftail; /* tail of bpf list */
    } cnT, *cnptrT;

/*<<< csdefs.h: EOF */
