/*>>> initbbcv.h: subprogram prototypes for initbbcv.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void InitBitBoardConstants(void);

/*<<< initbbcv.h: EOF */
