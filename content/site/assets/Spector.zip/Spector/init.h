/*>>> init.h: subprogram prototypes for init.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void InitSq(cpT cp, sqT sq);
void ClearBoard(void);
void ClearEnvironment(void);
void CopyBoard(void);
void InitNewGame(void);
void Init(void);

/*<<< init.h: EOF */
