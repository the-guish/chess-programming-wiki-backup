/*>>> saveload.c: save/load game routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "create.h"
#include "file.h"
#include "init.h"
#include "memutil.h"
#include "pawn.h"
#include "predvar.h"
#include "saveload.h"
#include "tags.h"
#include "tt.h"
#include "util.h"

/* flag for conversion in progress */

#define converting 0

/* The game code file format version (compatibility test) */

#define gcf_version 24

/* The history file pointer (created as needed) */

static fptrT fp_hist;

/*--> LoadGameCodeAux: auxillary game load */
static
siT
LoadGameCodeAux(voidptrT s, allocT n)
{
siT flag;

if (fread(s, 1, n, fp_hist) == n)
	flag = 1;
else
	flag = 0;

return (flag);
}

/*--> LoadGameStringRecord: load an allocated string record */
static
charptrT
LoadGameStringRecord(siptrT siptr)
{
charptrT s;
siT flag, length;

flag = LoadGameCodeAux(&length, sizeof(length));
if (!flag)
	s = NULL;
else
	if (length == 0)
		s = NULL;
	else
		{
		s = MemoryGrab(length);
		flag = LoadGameCodeAux(s, length);
		};

*siptr = flag;

return (s);
}

/*--> LoadGameCode: load the history from a file */
nonstatic
siT
LoadGameCode(charptrT s)
{
siT flag, i, gcf, count;
charptrT tnstr, tvstr;
char testname[prognameL];
tagptrT tagptr;

flag = 1;

/* initialize for a new game */

InitNewGame();

/* open the file */

if (flag)
	{
	fp_hist = CodeFileOpen(s, "rb");
	if (fp_hist == NULL)
		flag = 0;
	else
		SetBigBuffer(fp_hist);
	};

/* input program name (check) */

if (flag)
	{
	flag = LoadGameCodeAux(testname, sizeof(testname));
	if (flag && (strncmp(progname, testname, prognameL) != 0))
		flag = 0;
	};

/* input game code format (check) */

if (flag)
	{
	flag = LoadGameCodeAux(&gcf, sizeof(gcf));
	if (flag)
		if (gcf != (converting ? (gcf_version - 1) : gcf_version))
			flag = 0;
	};

/* input scalars */

if (flag)
	flag = LoadGameCodeAux(&lang_get, sizeof(lang_get));

if (flag)
	flag = LoadGameCodeAux(&lang_put, sizeof(lang_put));

if (flag)
	flag = LoadGameCodeAux(&global_nm, sizeof(global_nm));

if (flag)
	flag = LoadGameCodeAux(&actc, sizeof(actc));

if (flag)
	flag = LoadGameCodeAux(&pasc, sizeof(pasc));

if (flag)
	flag = LoadGameCodeAux(&envn.envn_cast, sizeof(envn.envn_cast));

if (flag)
	flag = LoadGameCodeAux(&envn.envn_epsq, sizeof(envn.envn_epsq));

if (flag)
	flag = LoadGameCodeAux(&envn.envn_hmvc, sizeof(envn.envn_hmvc));

if (flag)
	flag = LoadGameCodeAux(&envn.envn_fmvn, sizeof(envn.envn_fmvn));

if (flag)
	flag = LoadGameCodeAux(&gtc, sizeof(gtc));

if (flag)
	flag = LoadGameCodeAux(&setup, sizeof(setup));

if (flag)
	flag = LoadGameCodeAux(&histn, sizeof(histn));

if (flag)
	flag = LoadGameCodeAux(&clockflag, sizeof(clockflag));

/* input board */

if (flag)
	flag = LoadGameCodeAux(&board, sizeof(board));

/* input clocks */

if (flag)
	flag = LoadGameCodeAux(clockv, sizeof(clockv));

/* input time control vector */

if (flag)
	flag = LoadGameCodeAux(tcntlv, sizeof(tcntlv));

/* input search strategies */

if (flag)
	flag = LoadGameCodeAux(strtv, sizeof(strtv));

/* input tags */

if (flag)
	{
	/* fetch tag count */

	flag = LoadGameCodeAux(&count, sizeof(count));
	if (flag)
		{
		i = 0;
		while (flag && (i < count))
			{
			/* get tag name */

			tnstr = LoadGameStringRecord(&flag);
			if (flag)
				tvstr = LoadGameStringRecord(&flag);
			else
				tvstr = NULL;

			/* assign */

			if ((tagptr = TagLocate(tnstr)) != NULL)
				TagAssign(tagptr, tvstr);
			else
				{
				tagptr = TagCreate(tnstr, 0);
				TagInsert(tagptr);
				TagAssign(tagptr, tvstr);
				};

			/* deallocate */

			if (tnstr != NULL)
				MemoryFree(tnstr);
			if (tvstr != NULL)
				MemoryFree(tvstr);

			/* next tag */

			if (flag)
				i++;
			};
		};
	};

/* input options */

if (flag)
	flag = LoadGameCodeAux(optnv, sizeof(optnv));

/* input history */

if (flag)
	{
	flag = LoadGameCodeAux(histbase, (sizeof(histT) * histn));
	if (flag)
		histcurr = histbase + histn;
	};

/* input ordinals */

if (flag)
	{
	flag = LoadGameCodeAux(cordbase, (sizeof(cordT) * histn));
	if (flag)
		cordcurr = cordbase + histn;
	};

/* close the file */

if (fp_hist != NULL)
	(void) CodeFileClose(fp_hist);

/* create and update */

if (flag)
	{
	CreateAll();
	PVarEClear();
	TTReset();
	PawnTTReset();
	}
else
	InitNewGame();

return (flag);
}

/*--> SaveGameCodeAux: auxillary game save / file writer */
static
siT
SaveGameCodeAux(voidptrT s, allocT n)
{
siT flag;

if (fwrite(s, 1, n, fp_hist) == n)
	flag = 1;
else
	flag = 0;

return (flag);
}

/*--> SaveGameStringRecord: save a game string size and value */
static
siT
SaveGameStringRecord(charptrT s)
{
siT flag, length;

if (s == NULL)
	{
	length = 0;
	flag = SaveGameCodeAux(&length, sizeof(length));
	}
else
	{
	length = strlen(s) + 1;
	flag = SaveGameCodeAux(&length, sizeof(length));
	if (flag)
		flag = SaveGameCodeAux(s, length);
	};

return (flag);
}

/*--> SaveGameCode: save the history to a file */
nonstatic
siT
SaveGameCode(charptrT s)
{
siT flag, gcf, count;
tagptrT tagptr;

flag = 1;

/* open the file */

if (flag)
	{
	fp_hist = CodeFileOpen(s, "wb");
	if (fp_hist == NULL)
		flag = 0;
	else
		SetBigBuffer(fp_hist);
	};

/* output program name */

if (flag)
	flag = SaveGameCodeAux(progname, prognameL);

/* output game code format version */

if (flag)
	{
	gcf = gcf_version;
	flag = SaveGameCodeAux(&gcf, sizeof(gcf));
	};

/* output scalars */

if (flag)
	flag = SaveGameCodeAux(&lang_get, sizeof(lang_get));

if (flag)
	flag = SaveGameCodeAux(&lang_put, sizeof(lang_put));

if (flag)
	flag = SaveGameCodeAux(&global_nm, sizeof(global_nm));

if (flag)
	flag = SaveGameCodeAux(&actc, sizeof(actc));

if (flag)
	flag = SaveGameCodeAux(&pasc, sizeof(pasc));

if (flag)
	flag = SaveGameCodeAux(&envn.envn_cast, sizeof(envn.envn_cast));

if (flag)
	flag = SaveGameCodeAux(&envn.envn_epsq, sizeof(envn.envn_epsq));

if (flag)
	flag = SaveGameCodeAux(&envn.envn_hmvc, sizeof(envn.envn_hmvc));

if (flag)
	flag = SaveGameCodeAux(&envn.envn_fmvn, sizeof(envn.envn_fmvn));

if (flag)
	flag = SaveGameCodeAux(&gtc, sizeof(gtc));

if (flag)
	flag = SaveGameCodeAux(&setup, sizeof(setup));

if (flag)
	flag = SaveGameCodeAux(&histn, sizeof(histn));

if (flag)
	flag = SaveGameCodeAux(&clockflag, sizeof(clockflag));

/* output board */

if (flag)
	flag = SaveGameCodeAux(&board, sizeof(board));

/* output clocks */

if (flag)
	flag = SaveGameCodeAux(clockv, sizeof(clockv));

/* output time control vector */

if (flag)
	flag = SaveGameCodeAux(tcntlv, sizeof(tcntlv));

/* output search strategies */

if (flag)
	flag = SaveGameCodeAux(strtv, sizeof(strtv));

/* output tags */

if (flag)
	{
	/* write tag count */

	count = TagCount();
	flag = SaveGameCodeAux(&count, sizeof(count));
	if (flag)
		{
		tagptr = head_tagptr;
		while (flag && (tagptr != NULL))
			{
			/* write tag name and value */

			flag = SaveGameStringRecord(tagptr->tag_name);
			if (flag)
				flag = SaveGameStringRecord(tagptr->tag_value);

			/* next tag */

			if (flag)
				tagptr = tagptr->tag_next;
			};
		};
	};

/* output options */

if (flag)
	flag = SaveGameCodeAux(optnv, sizeof(optnv));

/* output history */

if (flag)
	flag = SaveGameCodeAux(histbase, (sizeof(histT) * histn));

/* output history */

if (flag)
	flag = SaveGameCodeAux(cordbase, (sizeof(cordT) * histn));

/* close the file */

if (fp_hist != NULL)
	(void) CodeFileClose(fp_hist);

return (flag);
}

/*<<< saveload.c: EOF */
