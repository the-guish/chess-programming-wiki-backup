/*>>> csvars.c: concept search variable declarations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"

#include "csdefs.h"

/**** Basic patterns */

/* the null basic pattern frame */

bpfT null_bpf;

/* the basic pattern descriptor vector */

bpdT bpdv[bpL];

/*<<< csvars.c: EOF */
