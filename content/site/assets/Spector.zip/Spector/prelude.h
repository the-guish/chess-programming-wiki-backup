/*>>> prelude.h: subprogram prototypes for prelude.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void Prelude(void);
void Postlude(void);

/*<<< prelude.h: EOF */
