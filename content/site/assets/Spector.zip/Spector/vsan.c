/*>>> vsan.c: vocalized standard algebraic notation routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "sysutil.h"
#include "vsan.h"

/**** Locals */

/* character insertion pointer and index */

static charptrT vsan_ptr;
static siT vsan_index;

/*--> VSANChar: insert a character  */
static
void
VSANChar(char ch)
{
if (vsan_index < vsanL)
	{
	*vsan_ptr++ = ch;
	vsan_index++;
	}
else
	Diagnose("VSANChar: fault");

return;
}

/*--> VSANBlank: insert a blank */
static
void
VSANBlank(void)
{
VSANChar(ascii_sp);

return;
}

/*--> VSANStr: insert a string  */
static
void
VSANStr(charptrT s)
{
siT i;
char ch;

i = 0;
while ((ch = *(s + i++)) != ascii_nul)
	VSANChar(ch);

return;
}

/*--> VSANDelay: insert short delay */
static
void
VSANDelay(void)
{
if (vsgenv_phonetic)
	VSANStr(" !C pa1 !T ");

return;
}

/*--> VSANColor: insert color from color-piece */
static
void
VSANColor(cpT cp)
{
VSANDelay();
if (vsgenv_phonetic)
	VSANStr(phs_cv[cv_c_cpv[cp]]);
else
	{
	VSANStr(" ");
	VSANStr(cstrv[cv_c_cpv[cp]]);
	};

return;
}

/*--> VSANPiece: insert piece from color-piece */
static
void
VSANPiece(cpT cp)
{
VSANDelay();
if (vsgenv_phonetic)
	VSANStr(phs_pv[cv_p_cpv[cp]]);
else
	{
	VSANStr(" ");
	VSANStr(pstrv[cv_p_cpv[cp]]);
	};

return;
}

/*--> VSANColorPiece: insert color piece string */
static
void
VSANColorPiece(cpT cp)
{
VSANColor(cp);
VSANPiece(cp);

return;
}

/*--> VSANRank: insert rank string from square */
static
void
VSANRank(sqT sq)
{
VSANDelay();
if (vsgenv_phonetic)
	VSANStr(phs_rv[map_rank(sq)]);
else
	{
	VSANStr(" ");
	VSANStr(ord_unitv[map_rank(sq) + 1]);
	};

return;
}

/*--> VSANFile: insert file string from square */
static
void
VSANFile(sqT sq)
{
char bv[3];

VSANDelay();
if (vsgenv_phonetic)
	VSANStr(phs_fv[map_file(sq)]);
else
	{
	sprintf(bv, " %c", ascfv[map_file(sq)]);
	VSANStr(bv);
	};

return;
}

/*--> VSANSquare: insert square character pair */
static
void
VSANSquare(sqT sq)
{
if (vsgenv_phonetic)
	VSANStr(" skwair");
else
	VSANStr(" square");

VSANFile(sq);
VSANRank(sq);

return;
}

/*--> VSANMove: generate an extended SAN move string */
nonstatic
void
VSANMove(mptrT mptr, vsanT vsan)
{
/* initialize pointer and index */

vsan_ptr = (charptrT) vsan;
vsan_index = 0;

/* check for null move */

if (mptr->m_flag & mf_null)
	VSANStr("Null move");
else
	{
	/* output color */

	VSANColor(mptr->m_frcp);

	/* process according to moving piece */

	VSANBlank();
	switch (cv_p_cpv[mptr->m_frcp])
		{
		case p_p:
			/* insert moving piece name */

			VSANPiece(mptr->m_frcp);

			/* move or capture */

			VSANBlank();
			if ((mptr->m_tocp == cp_v0) && (mptr->m_scmv != scmv_epc))
				{
				VSANStr(" moves to");
				VSANSquare(mptr->m_tosq);
				}
			else
				{
				VSANStr(" at file");
				VSANFile(mptr->m_frsq);
				VSANStr(" takes");
				if (mptr->m_scmv != scmv_epc)
					VSANColorPiece(mptr->m_tocp);
				else
					{
					VSANColor(inv_cv[cv_c_cpv[mptr->m_frcp]]);
					VSANBlank();
					VSANPiece(p_p);
					};
				VSANStr(" at");
				VSANSquare(mptr->m_tosq);
				};

			/* special case suffixes */

			switch (mptr->m_scmv)
				{
				case scmv_reg:
					break;

				case scmv_epc:
					VSANStr(" en passant");
					break;

				case scmv_ppn:
				case scmv_ppb:
				case scmv_ppr:
				case scmv_ppq:
					if (vsgenv_phonetic)
						VSANStr(" and pro moats to");
					else
						VSANStr(" and promotes to");
					VSANPiece(cv_p_scmvv[mptr->m_scmv]);
					break;

				case scmv_cks:
				case scmv_cqs:
				default:
					SwitchFault("VSANMove");
					break;
				};
			break;

		case p_n:
		case p_b:
		case p_r:
		case p_q:
			/* insert moving piece name */

			VSANPiece(mptr->m_frcp);

			/* process disambiguation */

			if (mptr->m_flag & mf_anfp)
				{
				VSANStr(" at ");
				if (mptr->m_flag & mf_anrp)
					VSANSquare(mptr->m_frsq);
				else
					{
					VSANStr("file ");
					VSANFile(mptr->m_frsq);
					};
				}
			else
				if (mptr->m_flag & mf_anrp)
					{
					VSANStr(" at rank");
					VSANRank(mptr->m_frsq);
					};

			/* move or capture ? */

			VSANBlank();
			if (mptr->m_tocp == cp_v0)
				VSANStr("moves to");
			else
				{
				VSANStr(" takes");
				VSANColorPiece(mptr->m_tocp);
				VSANStr(" at");
				};
			VSANBlank();
			VSANSquare(mptr->m_tosq);
			break;

		case p_k:
			switch (mptr->m_scmv)
				{
				case scmv_reg:
					VSANPiece(p_k);
					VSANBlank();

					/* move or capture ? */

					if (mptr->m_tocp == cp_v0)
						VSANStr("moves to");
					else
						{
						VSANStr(" takes");
						VSANColorPiece(mptr->m_tocp);
						VSANStr(" at");
						};
					VSANBlank();
					VSANSquare(mptr->m_tosq);
					break;

				case scmv_cks:
					VSANStr(" castles king side");
					break;

				case scmv_cqs:
					VSANStr(" castles queen side");
					break;

				case scmv_epc:
				case scmv_ppn:
				case scmv_ppb:
				case scmv_ppr:
				case scmv_ppq:
				default:
					SwitchFault("VSANMove");
					break;
				};
			break;

		default:
			SwitchFault("VSANMove");
			break;
		};
	};

/* indication: check */

if ((mptr->m_flag & mf_chec) && !(mptr->m_flag & mf_mate))
	VSANStr(" with check");

/* indication: checkmate */

if (mptr->m_flag & mf_mate)
	VSANStr(" with check mate");

/* indication: draw */

if (mptr->m_flag & mf_draw)
	VSANStr(" with a draw");

/* indication: illegal */

if (mptr->m_flag & mf_bust)
	VSANStr(" illegal");

/* insert trailing NULs */

do
	{
	VSANChar(ascii_nul);
	}
while (vsan_index < vsanL);

return;
}

/*<<< vsan.c: EOF */
