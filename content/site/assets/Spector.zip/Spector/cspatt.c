/*>>> cspatt.c: concept search pattern manipulation routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "csdefs.h"
#include "csvars.h"

#include "cspatt.h"
#include "memutil.h"

/*--> CSPatternPost: post a basic pattern frame */
nonstatic
void
CSPatternPost(sptrT sptr, bpfT bpf)
{
cnptrT cnptr;
bpfptrT bpfptr;

/* allocate and copy bpf */

bpfptr = (bpfptrT) MemoryGrab(sizeof(bpfT));
*bpfptr = bpf;

/* thread at tail */

cnptr = (cnptrT) sptr->s_cnptr;
if (cnptr->cn_bpfhead == NULL)
	cnptr->cn_bpfhead = bpfptr;
else
	{
	bpfptr->bpf_prev = cnptr->cn_bpftail;
	cnptr->cn_bpftail->bpf_next = bpfptr;
	};
cnptr->cn_bpftail = bpfptr;

return;
}

/*<<< cspatt.c: EOF */
