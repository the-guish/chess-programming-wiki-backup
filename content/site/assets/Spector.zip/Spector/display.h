/*>>> display.h: subprogram prototypes for display.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void DpWriteChar(siT c);
void DpWriteStr(charptrT s);
charptrT DpReadCommand(void);
void DpReadResponse(char tv[tL]);
void DpCommand(void);
void DpApply(winidT winid, winacT winac);
void DpApplyAll(winacT winac);
void DpUpdate(winidT winid);
void DpUpdateAll(void);
void DpInit(void);
void DpTerm(void);

/*<<< display.h: EOF */
