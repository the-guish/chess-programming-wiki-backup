/*>>> csknow.h: subprogram prototypes for csknow.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT CSLoadKnowledge(charptrT fn);
siT CSSaveKnowledge(charptrT fn);

/*<<< csknow.h: EOF */
