/*>>> cpic.c: command processor for interprocess communication */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "cpic.h"

/*--> CPICCommand: handle command token line from main command input */
nonstatic
void
CPICCommand(void)
{

return;
}

/*<<< cpic.c: EOF */
