/*>>> main.c: Spector main line */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/***************************************************************************/
/*                                                                         */
/*    SSSSS    PPPPPP    EEEEEEE    CCCCC    TTTTTTT    OOOOO    RRRRRR    */
/*   S     S   P     p   E         C     C      T      O     O   R     R   */
/*   S         P     P   E         C            T      O     O   R     R   */
/*    SSSSS    PPPPPP    EEEEE     C            T      O     O   RRRRRR    */
/*         S   P         E         C            T      O     O   R   R     */
/*   S     S   P         E         C     C      T      O     O   R    R    */
/*    SSSSS    P         EEEEEEE    CCCCC       T       OOOOO    R     R   */
/*                                                                         */
/***************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "command.h"
#include "init.h"
#include "main.h"
#include "print.h"
#include "sysutil.h"
#include "term.h"

/*--> main: main routine for the Spector Chessplayer */
nonstatic
int
main(void)
{
static char versionv[progversL];

/* program identification and revision data */

progname = "Spector";
progauth = "Steven James Edwards";
proguscf = "12516851";
progexpr = "1997.05.31";

version_major = 28;
version_minor = 22;

progdate = "1996.06.23";

(void) sprintf(versionv, "%02hd.%04hd", version_major, version_minor);
progvers = versionv;

/* initialize */

Init();
PrTwoStrsNL(progname, " ready.");

/* process commands */

while (!progdone)
	Command();

/* terminate */

PrTwoStrsNL(progname, " concluded.");
Term();
Transfer();

return (0);
}

/*<<< main.c: EOF */
