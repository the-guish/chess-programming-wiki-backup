/*>>> setsq.h: subprogram prototypes for setsq.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void SqClr(sqT sq);
void SqSet(cpT new_cp, sqT sq);

/*<<< setsq.h: EOF */
