/*>>>tbcache.h: subprogram prototypes for tbcache.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

cpevT TBCacheReadCPEV(tbidT tbid, cT c, liT offset);
void TBCacheFlush(void);
void TBCacheInit(void);
void TBCacheTerm(void);

/*<<< tbcache.h: EOF */
