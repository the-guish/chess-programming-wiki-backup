/*>>> initbbcv.c: initialize bitboard constant values */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "initbbcv.h"
#include "memutil.h"

/*--> InitBitBoardConstants: set up constant bitboard related values */
nonstatic
void
InitBitBoardConstants(void)
{
rankT rank, aux_rank;
fileT file;
sqT sq;
siT i, j;
liT s;
dxT dx;
xbsqT xbsq;
xbrankT xbrank;
xbfileT xbfile;
cT c;
bbT bb;
byteT fbval, ebv[pageL], fbv[pageL];

/* set up the enumeration byte table */

for (i = 0; i < pageL; i++)
	{
	ebv[i] = 0;
	for (j = 0; j < byteW; j++)
		ebv[i] += (i >> j) & bit;
	};

/* allocate and initialize the bit enumeration table */

bevbase = (byteptrT) MemoryGrab((1L << wordW) * sizeof(byteT));
for (s = 0; s < (1L << wordW); s++)
	*(bevbase + s) = ebv[(s >> byteW) & byteM] + ebv[s & byteM];

/* set up the first bit byte table */

for (i = 0; i < pageL; i++)
	{
	fbv[i] = byteW;
	j = 0;
	while ((j < byteW) && (fbv[i] == byteW))
		if (i & (bit << j))
			fbv[i] = (byteT) j;
		else
			j++;
	};

/* allocate the first bit word table */

bfvbase = (byteptrT) MemoryGrab((1L << wordW) * sizeof(byteT));

/* initialize the first bit word table */

for (s = 0; s < (1L << wordW); s++)
	{
	bb.bbwv[0] = (ustdwiT) s;
	if (bb.bbcv[0])
		fbval = fbv[bb.bbcv[0]];
	else
		if (bb.bbcv[1])
			fbval = fbv[bb.bbcv[1]] + (byteT) byteW;
		else
			fbval = wordW;
	*(bfvbase + s) = fbval;
	};

/* initialize the cancellation word vector */

for (i = 0; i < wordW; i++)
	{
	bb_clr(bb);
	bb_setsq(bb, i);
	canwv[i] = ~bb.bbwv[0];
	};

/* initialize the file directional delta vector */

dvfv[dx_0] = dvf_0;
dvfv[dx_1] = dvf_1;
dvfv[dx_2] = dvf_2;
dvfv[dx_3] = dvf_3;
dvfv[dx_4] = dvf_4;
dvfv[dx_5] = dvf_5;
dvfv[dx_6] = dvf_6;
dvfv[dx_7] = dvf_7;
dvfv[dx_8] = dvf_8;
dvfv[dx_9] = dvf_9;
dvfv[dx_a] = dvf_a;
dvfv[dx_b] = dvf_b;
dvfv[dx_c] = dvf_c;
dvfv[dx_d] = dvf_d;
dvfv[dx_e] = dvf_e;
dvfv[dx_f] = dvf_f;

/* initialize the rank directional delta vector */

dvrv[dx_0] = dvr_0;
dvrv[dx_1] = dvr_1;
dvrv[dx_2] = dvr_2;
dvrv[dx_3] = dvr_3;
dvrv[dx_4] = dvr_4;
dvrv[dx_5] = dvr_5;
dvrv[dx_6] = dvr_6;
dvrv[dx_7] = dvr_7;
dvrv[dx_8] = dvr_8;
dvrv[dx_9] = dvr_9;
dvrv[dx_a] = dvr_a;
dvrv[dx_b] = dvr_b;
dvrv[dx_c] = dvr_c;
dvrv[dx_d] = dvr_d;
dvrv[dx_e] = dvr_e;
dvrv[dx_f] = dvr_f;

/* initialize the complementary direction vector */

compdxv[dx_0] = dx_2;
compdxv[dx_1] = dx_3;
compdxv[dx_2] = dx_0;
compdxv[dx_3] = dx_1;
compdxv[dx_4] = dx_6;
compdxv[dx_5] = dx_7;
compdxv[dx_6] = dx_4;
compdxv[dx_7] = dx_5;
compdxv[dx_8] = dx_c;
compdxv[dx_9] = dx_d;
compdxv[dx_a] = dx_e;
compdxv[dx_b] = dx_f;
compdxv[dx_c] = dx_8;
compdxv[dx_d] = dx_9;
compdxv[dx_e] = dx_a;
compdxv[dx_f] = dx_b;

/* initialize the board direction delta vector */

dvv[dx_0] = dv_0;
dvv[dx_1] = dv_1;
dvv[dx_2] = dv_2;
dvv[dx_3] = dv_3;
dvv[dx_4] = dv_4;
dvv[dx_5] = dv_5;
dvv[dx_6] = dv_6;
dvv[dx_7] = dv_7;
dvv[dx_8] = dv_8;
dvv[dx_9] = dv_9;
dvv[dx_a] = dv_a;
dvv[dx_b] = dv_b;
dvv[dx_c] = dv_c;
dvv[dx_d] = dv_d;
dvv[dx_e] = dv_e;
dvv[dx_f] = dv_f;

/* initialize the extended board direction delta vector */

xdvv[dx_0] = xdv_0;
xdvv[dx_1] = xdv_1;
xdvv[dx_2] = xdv_2;
xdvv[dx_3] = xdv_3;
xdvv[dx_4] = xdv_4;
xdvv[dx_5] = xdv_5;
xdvv[dx_6] = xdv_6;
xdvv[dx_7] = xdv_7;
xdvv[dx_8] = xdv_8;
xdvv[dx_9] = xdv_9;
xdvv[dx_a] = xdv_a;
xdvv[dx_b] = xdv_b;
xdvv[dx_c] = xdv_c;
xdvv[dx_d] = xdv_d;
xdvv[dx_e] = xdv_e;
xdvv[dx_f] = xdv_f;

/* initialize the rank and file direction offset vectors */

rdvv[dx_0] =  0;   fdvv[dx_0] =  1;
rdvv[dx_1] =  1;   fdvv[dx_1] =  0;
rdvv[dx_2] =  0;   fdvv[dx_2] = -1;
rdvv[dx_3] = -1;   fdvv[dx_3] =  0;
rdvv[dx_4] =  1;   fdvv[dx_4] =  1;
rdvv[dx_5] =  1;   fdvv[dx_5] = -1;
rdvv[dx_6] = -1;   fdvv[dx_6] = -1;
rdvv[dx_7] = -1;   fdvv[dx_7] =  1;
rdvv[dx_8] =  1;   fdvv[dx_8] =  2;
rdvv[dx_9] =  2;   fdvv[dx_9] =  1;
rdvv[dx_a] =  2;   fdvv[dx_a] = -1;
rdvv[dx_b] =  1;   fdvv[dx_b] = -2;
rdvv[dx_c] = -1;   fdvv[dx_c] = -2;
rdvv[dx_d] = -2;   fdvv[dx_d] = -1;
rdvv[dx_e] = -2;   fdvv[dx_e] =  1;
rdvv[dx_f] = -1;   fdvv[dx_f] =  2;

/* initialize the extended board border values */

for (xbrank = 0; xbrank < xbrankL; xbrank++)
	for (xbfile = 0; xbfile < xbfileL; xbfile++)
		xb.xbm[xbrank][xbfile] = cp_x0;

/* initialize the extended board non-border values */

for (rank = rank_1; rank <= rank_8; rank++)
	for (file = file_a; file <= file_h; file++)
		xb.xbm[trn_xbrank(rank)][trn_xbfile(file)] = cp_v0;

/* initialize the square bitboard vector */

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	bb_clr(sqbbv[sq]);
	bb_setsq(sqbbv[sq], sq);
	};

/* initialize the rank bitboard vector */

for (rank = rank_1; rank <= rank_8; rank++)
	{
	bb_clr(r0bbv[rank]);
	for (file = file_a; file <= file_h; file++)
		bb_setsqrf(r0bbv[rank], rank, file);
	};

/* initialize the file bitboard vector */

for (file = file_a; file <= file_h; file++)
	{
	bb_clr(f0bbv[file]);
	for (rank = rank_1; rank <= rank_8; rank++)
		bb_setsqrf(f0bbv[file], rank, file);
	};

/* initialize the file adjacency bitboard vector */

for (file = file_a; file <= file_h; file++)
	{
	bb_clr(fabbv[file]);
	if (file > file_a)
		bb_ior2(f0bbv[file - 1], fabbv[file]);
	if (file < file_h)
		bb_ior2(f0bbv[file + 1], fabbv[file]);
	};

/* initialize the file triplet bitboard vector */

for (file = file_a; file <= file_h; file++)
	bb_ior3(f0bbv[file], fabbv[file], ftbbv[file]);

/* initialize the directional edge vectors */

debbv[dx_0] = f0bbv[file_h];
debbv[dx_1] = r0bbv[rank_8];
debbv[dx_2] = f0bbv[file_a];
debbv[dx_3] = r0bbv[rank_1];

bb_ior3(debbv[dx_0], debbv[dx_1], debbv[dx_4]);
bb_ior3(debbv[dx_1], debbv[dx_2], debbv[dx_5]);
bb_ior3(debbv[dx_2], debbv[dx_3], debbv[dx_6]);
bb_ior3(debbv[dx_3], debbv[dx_0], debbv[dx_7]);

/* initialize the knight moves bitboard vector */

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	bb_clr(nmbbv[sq]);
	xbsq = trn_xbsq(sq);
	for (dx = rdxL; dx <= dx_f; dx++)
		if (xb.xbv[xbsq + xdvv[dx]] == cp_v0)
			bb_ior2(sqbbv[sq + dvv[dx]], nmbbv[sq]);
	};

/* initialize the bishop moves bitboard vector */

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	bb_clr(bmbbv[sq]);
	xbsq = trn_xbsq(sq);
	for (dx = dx_4; dx <= dx_7; dx++)
		{
		i = 1;
		while (xb.xbv[xbsq + (i * xdvv[dx])] == cp_v0)
			{
			bb_ior2(sqbbv[sq + (i * dvv[dx])], bmbbv[sq]);
			i++;
			};
		};
	};

/* initialize the rook moves bitboard vector */

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	bb_clr(rmbbv[sq]);
	xbsq = trn_xbsq(sq);
	for (dx = dx_0; dx <= dx_3; dx++)
		{
		i = 1;
		while (xb.xbv[xbsq + (i * xdvv[dx])] == cp_v0)
			{
			bb_ior2(sqbbv[sq + (i * dvv[dx])], rmbbv[sq]);
			i++;
			};
		};
	};

/* initialize the queen moves bitboard vector */

for (sq = sq_a1; sq <= sq_h8; sq++)
	bb_ior3(bmbbv[sq], rmbbv[sq], qmbbv[sq]);

/* initialize the king moves bitboard vector */

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	bb_clr(kmbbv[sq]);
	xbsq = trn_xbsq(sq);
	for (dx = dx_0; dx <= dx_7; dx++)
		if (xb.xbv[xbsq + xdvv[dx]] == cp_v0)
			bb_ior2(sqbbv[sq + dvv[dx]], kmbbv[sq]);
	};

/* initialize the two-color pawn move and capture bitboard vectors */

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	for (c = c_w; c <= c_b; c++)
		{
		bb_clr(pmbbv[c][sq]);
		bb_clr(pcbbv[c][sq]);
		};
	rank = map_rank(sq);
	if ((rank >= rank_2) && (rank <= rank_7))
		{
		pmbbv[c_w][sq] = sqbbv[sq + dv_1];
		pmbbv[c_b][sq] = sqbbv[sq + dv_3];
		file = map_file(sq);
		if (file > file_a)
			{
			bb_ior2(sqbbv[sq + dv_5], pcbbv[c_w][sq]);
			bb_ior2(sqbbv[sq + dv_6], pcbbv[c_b][sq]);
			};
		if (file < file_h)
			{
			bb_ior2(sqbbv[sq + dv_4], pcbbv[c_w][sq]);
			bb_ior2(sqbbv[sq + dv_7], pcbbv[c_b][sq]);
			};
		};
	};

/* initialize the two color pawn forward track bitboard vector */

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	bb_clr(ptbbv[c_w][sq]);
	file = map_file(sq);
	rank = map_rank(sq);
	for (aux_rank = (rank + 1); aux_rank <= rank_8; aux_rank++)
		bb_setsqrf(ptbbv[c_w][sq], aux_rank, file);
	};

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	bb_clr(ptbbv[c_b][sq]);
	file = map_file(sq);
	rank = map_rank(sq);
	for (aux_rank = (rank - 1); aux_rank >= rank_1; aux_rank--)
		bb_setsqrf(ptbbv[c_b][sq], aux_rank, file);
	};

/* initialize the forward pawn track adjacency bitboard vector */

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	file = map_file(sq);
	for (c = c_w; c <= c_b; c++)
		{
		bb_clr(pabbv[c][sq]);
		if (file > file_a)
			bb_ior2(ptbbv[c][sq - dv_0], pabbv[c][sq]);
		if (file < file_h)
			bb_ior2(ptbbv[c][sq + dv_0], pabbv[c][sq]);
		};
	};

/* initialize the passed pawn forward track bitboard vector */

for (sq = sq_a1; sq <= sq_h8; sq++)
	for (c = c_w; c <= c_b; c++)
		{
		rank = map_rank(sq);
		file = map_file(sq);
		ppbbv[c][sq] = ptbbv[c][sq];
		if (file > file_a)
			{
			bb_ior2(ptbbv[c][map_sq(rank, (file - 1))], ppbbv[c][sq]);
			};
		if (file < file_h)
			{
			bb_ior2(ptbbv[c][map_sq(rank, (file + 1))], ppbbv[c][sq]);
			};
		};

/* initialize the pawn phalanx adjacency bitboard vector */

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	bb_clr(pxbbv[sq]);
	file = map_file(sq);
	if (file > file_a)
		bb_setsq(pxbbv[sq], (sq + dv_2));
	if (file < file_h)
		bb_setsq(pxbbv[sq], (sq + dv_0));
	};

/* initialize the king hustle bitboard vector (four quadrants) */

for (rank = rank_1; rank <= rank_4; rank++)
	for (file = file_a; file <= file_d; file++)
		{
		bb_clr(bb);
		bb_setsqrf(bb, (rank + 1), (file + 0));
		bb_setsqrf(bb, (rank + 1), (file + 1));
		bb_setsqrf(bb, (rank + 0), (file + 1));
		khbbv[map_sq(rank, file)] = bb;
		};

for (rank = rank_1; rank <= rank_4; rank++)
	for (file = file_e; file <= file_h; file++)
		{
		bb_clr(bb);
		bb_setsqrf(bb, (rank + 1), (file - 0));
		bb_setsqrf(bb, (rank + 1), (file - 1));
		bb_setsqrf(bb, (rank + 0), (file - 1));
		khbbv[map_sq(rank, file)] = bb;
		};

for (rank = rank_5; rank <= rank_8; rank++)
	for (file = file_a; file <= file_d; file++)
		{
		bb_clr(bb);
		bb_setsqrf(bb, (rank - 1), (file + 0));
		bb_setsqrf(bb, (rank - 1), (file + 1));
		bb_setsqrf(bb, (rank - 0), (file + 1));
		khbbv[map_sq(rank, file)] = bb;
		};

for (rank = rank_5; rank <= rank_8; rank++)
	for (file = file_e; file <= file_h; file++)
		{
		bb_clr(bb);
		bb_setsqrf(bb, (rank - 1), (file - 0));
		bb_setsqrf(bb, (rank - 1), (file - 1));
		bb_setsqrf(bb, (rank - 0), (file - 1));
		khbbv[map_sq(rank, file)] = bb;
		};

/* initialize the castling occupancy square bitboards */

bb_clr(wkobb);
bb_setsq(wkobb, sq_f1);
bb_setsq(wkobb, sq_g1);

bb_clr(wqobb);
bb_setsq(wqobb, sq_d1);
bb_setsq(wqobb, sq_c1);
bb_setsq(wqobb, sq_b1);

bb_clr(bkobb);
bb_setsq(bkobb, sq_f8);
bb_setsq(bkobb, sq_g8);

bb_clr(bqobb);
bb_setsq(bqobb, sq_d8);
bb_setsq(bqobb, sq_c8);
bb_setsq(bqobb, sq_b8);

/* initialize the castling attack square bitboards */

bb_clr(wkabb);
bb_setsq(wkabb, sq_f1);
bb_setsq(wkabb, sq_g1);

bb_clr(wqabb);
bb_setsq(wqabb, sq_d1);
bb_setsq(wqabb, sq_c1);

bb_clr(bkabb);
bb_setsq(bkabb, sq_f8);
bb_setsq(bkabb, sq_g8);

bb_clr(bqabb);
bb_setsq(bqabb, sq_d8);
bb_setsq(bqabb, sq_c8);

/* initialize the castling terminal square bitboards */

bb_clr(wktbb);
bb_setsq(wktbb, sq_e1);
bb_setsq(wktbb, sq_h1);

bb_clr(wqtbb);
bb_setsq(wqtbb, sq_e1);
bb_setsq(wqtbb, sq_a1);

bb_clr(bktbb);
bb_setsq(bktbb, sq_e8);
bb_setsq(bktbb, sq_h8);

bb_clr(bqtbb);
bb_setsq(bqtbb, sq_e8);
bb_setsq(bqtbb, sq_a8);

/* initialize the color square bitboard */

bb_clr(csbbv[c_w]);
bb_clr(csbbv[c_b]);
for (rank = rank_1; rank <= rank_8; rank++)
	for (file = file_a; file <= file_h; file++)
		if ((file & bit) != (rank & bit))
			bb_setsqrf(csbbv[c_w], rank, file);
		else
			bb_setsqrf(csbbv[c_b], rank, file);

/* initialize the castling information vector */

civ[c_w].ci_homesq = sq_e1;
civ[c_w].ci_kstosq = sq_g1;
civ[c_w].ci_qstosq = sq_c1;
civ[c_w].ci_krfrsq = sq_h1;
civ[c_w].ci_krtosq = sq_f1;
civ[c_w].ci_qrfrsq = sq_a1;
civ[c_w].ci_qrtosq = sq_d1;

civ[c_b].ci_homesq = sq_e8;
civ[c_b].ci_kstosq = sq_g8;
civ[c_b].ci_qstosq = sq_c8;
civ[c_b].ci_krfrsq = sq_h8;
civ[c_b].ci_krtosq = sq_f8;
civ[c_b].ci_qrfrsq = sq_a8;
civ[c_b].ci_qrtosq = sq_d8;

/* initialize the color-piece sweep vector */

cp_sweepv[cp_wp] = cp_sweepv[cp_bp] = 0;
cp_sweepv[cp_wn] = cp_sweepv[cp_bn] = 0;
cp_sweepv[cp_wb] = cp_sweepv[cp_bb] = 1;
cp_sweepv[cp_wr] = cp_sweepv[cp_br] = 1;
cp_sweepv[cp_wq] = cp_sweepv[cp_bq] = 1;
cp_sweepv[cp_wk] = cp_sweepv[cp_bk] = 0;

/* initialize the sweep piece directional bounds vectors */

dx_sweep0v[p_p] = dx_nil;
dx_sweep0v[p_n] = dx_nil;
dx_sweep0v[p_b] = dx_4;
dx_sweep0v[p_r] = dx_0;
dx_sweep0v[p_q] = dx_0;
dx_sweep0v[p_k] = dx_nil;

dx_sweep1v[p_p] = dx_nil;
dx_sweep1v[p_n] = dx_nil;
dx_sweep1v[p_b] = dx_7;
dx_sweep1v[p_r] = dx_3;
dx_sweep1v[p_q] = dx_7;
dx_sweep1v[p_k] = dx_nil;

/* set up the opposing position bitboard */

bb_clr(opposing);
bb_ior2(f0bbv[file_c], opposing);
bb_ior2(f0bbv[file_f], opposing);
bb_ior2(r0bbv[rank_3], opposing);
bb_ior2(r0bbv[rank_6], opposing);

/* set up the rim bitboard */

bb_clr(ontherim);
bb_ior2(f0bbv[file_a], ontherim);
bb_ior2(f0bbv[file_h], ontherim);
bb_ior2(r0bbv[rank_1], ontherim);
bb_ior2(r0bbv[rank_8], ontherim);

/* set up the center bitboard */

bb_clr(incenter);
for (rank = rank_3; rank <= rank_6; rank++)
	for (file = file_c; file <= file_f; file++)
		bb_setsq(incenter, map_sq(rank, file));

/* set up the four halfboard bitboards */

bb_clr(hbbb_kingside);
bb_ior2(f0bbv[file_e], hbbb_kingside);
bb_ior2(f0bbv[file_f], hbbb_kingside);
bb_ior2(f0bbv[file_g], hbbb_kingside);
bb_ior2(f0bbv[file_h], hbbb_kingside);

bb_clr(hbbb_queenside);
bb_ior2(f0bbv[file_a], hbbb_queenside);
bb_ior2(f0bbv[file_b], hbbb_queenside);
bb_ior2(f0bbv[file_c], hbbb_queenside);
bb_ior2(f0bbv[file_d], hbbb_queenside);

bb_clr(hbbb_whiteside);
bb_ior2(r0bbv[rank_1], hbbb_whiteside);
bb_ior2(r0bbv[rank_2], hbbb_whiteside);
bb_ior2(r0bbv[rank_3], hbbb_whiteside);
bb_ior2(r0bbv[rank_4], hbbb_whiteside);

bb_clr(hbbb_blackside);
bb_ior2(r0bbv[rank_5], hbbb_blackside);
bb_ior2(r0bbv[rank_6], hbbb_blackside);
bb_ior2(r0bbv[rank_7], hbbb_blackside);
bb_ior2(r0bbv[rank_8], hbbb_blackside);

/* set the sanctuary bitboard vector */

bb_clr(sancspot[c_w]);
bb_setsq(sancspot[c_w], sq_a1);
bb_setsq(sancspot[c_w], sq_b1);
bb_setsq(sancspot[c_w], sq_g1);
bb_setsq(sancspot[c_w], sq_h1);

bb_clr(sancspot[c_b]);
bb_setsq(sancspot[c_b], sq_a8);
bb_setsq(sancspot[c_b], sq_b8);
bb_setsq(sancspot[c_b], sq_g8);
bb_setsq(sancspot[c_b], sq_h8);

/* set the cramped bitboard vector */

bb_clr(cramspot[c_w]);
bb_setsq(cramspot[c_w], sq_a1);
bb_setsq(cramspot[c_w], sq_b1);
bb_setsq(cramspot[c_w], sq_g1);
bb_setsq(cramspot[c_w], sq_h1);

bb_clr(cramspot[c_b]);
bb_setsq(cramspot[c_b], sq_a8);
bb_setsq(cramspot[c_b], sq_b8);
bb_setsq(cramspot[c_b], sq_g8);
bb_setsq(cramspot[c_b], sq_h8);

return;
}

/*<<< initbbcv.c: EOF */
