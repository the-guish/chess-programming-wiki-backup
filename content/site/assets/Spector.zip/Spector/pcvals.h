/*>>> pcvals.h: subprogram prototypes for pcvals.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void ProcessCVCA(void);
void ProcessCVCB(void);
void ProcessCVCC(void);
void ProcessCVCF(void);
void ProcessCVEP(void);
void ProcessCVGT(void);
void ProcessCVOP(void);
void ProcessCVSQ(void);
void ProcessCVTF(void);
void ProcessDVAS(void);
void ProcessDVCB(void);
void ProcessDVCR(void);
void ProcessDVCT(void);
void ProcessDVER(void);
void ProcessDVFE(void);
void ProcessDVLM(void);
void ProcessDVNC(void);
void ProcessDVPE(void);
void ProcessDVPM(void);
void ProcessDVPV(void);
void ProcessDVSS(void);
void ProcessDVTC(void);
void ProcessDVTE(void);
void ProcessDVTF(void);
void ProcessDVTS(void);
void ProcessDVTT(void);
void ProcessEVCA(void);
void ProcessEVTE(void);
void ProcessEVTF(void);
void ProcessRVCA(void);
void ProcessRVCC(void);
void ProcessRVCT(void);
void ProcessRVHT(void);
void ProcessRVNC(void);
void ProcessRVOP(void);
void ProcessRVSS(void);
void ProcessRVTC(void);
void ProcessSVAC(void);
void ProcessSVCA(void);
void ProcessSVCC(void);
void ProcessSVCF(void);
void ProcessSVCT(void);
void ProcessSVEP(void);
void ProcessSVFE(void);
void ProcessSVHC(void);
void ProcessSVKO(void);
void ProcessSVMN(void);
void ProcessSVNC(void);
void ProcessSVNL(void);
void ProcessSVNM(void);
void ProcessSVOP(void);
void ProcessSVPL(void);
void ProcessSVSQ(void);
void ProcessSVSS(void);
void ProcessSVTC(void);
void ProcessSVTF(void);
void ProcessSVTT(void);

/*<<< pcvals.h: EOF */
