/*>>> play.c: play move routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "vpdefs.h"

#include "clock.h"
#include "create.h"
#include "display.h"
#include "draw.h"
#include "exec.h"
#include "gt.h"
#include "hist.h"
#include "init.h"
#include "moveset.h"
#include "mu.h"
#include "play.h"
#include "predvar.h"
#include "print.h"
#include "san.h"
#include "saveload.h"
#include "stat.h"
#include "voice.h"

/*--> UnplayMove: unplay a move for program or opponent (ply zero only) */
nonstatic
void
UnplayMove(void)
{
gtcT save_gtc;

/* called only at ply zero */

save_gtc = gtc;
HistoryPop();
PVarEClear();
CopyBoard();
CreateAll();
gtc = gtc_none;

/* restart clocks if retracting from a terminating position */

if (save_gtc != gtc_none)
	ClockStart();

return;
}

/*--> PlayMove: play a move for program or opponent (ply zero only) */
nonstatic
void
PlayMove(mptrT mptr)
{
gsT gs;
cordT cord;

/* process the display move option */

if (!optnv[optn_ndpm] && ponder_trace && !silent_play)
	{
	(void) sprintf(stv, pfs_mn_dot, envn.envn_fmvn);
	PrSTV();
	if (optnv[optn_expn])
		PrExpandedSAN(mptr);
	else
		{
		if (actc == c_b)
			PrStr("   ...    ");
		PrSAN(mptr);
		};
	PrNL();
	};

/* process the speak move option */

if (optnv[optn_vsyn] && ponder_trace && !silent_play)
	(void) VSSpeakMove(mptr);

/* copy generation ordinal */

cord = LocateOrdinal(mptr, root_sptr);

/* set the ordinal of the played move */

OrdinalSet(cord);

/* update clock for old moving player */

ClockUpdate();

/* execute the move on the local board */

ExecuteMove(mptr);

/* adjust ply zero colors for proper timing control, search, etc. */

p0actc = actc;
p0pasc = pasc;

/* update clock for new moving player */

ClockUpdate();

/* drop environmental pointer (due to unwanted update by ExecuteMove) */

envn_curr--;

/* adjust ply (due to unwanted update by -ExecuteMove-) */

ply--;

/* invert the expectation */

expectation = -expectation;

/* process mating expectation */

if (ct_mate(expectation))
	expectation++;
else
	if (ct_wump(expectation))
		expectation--;

/* conditionally shift predicted variation one step */

PVarEShift(mptr);

/* copy to playing board */

CopyBoard();

/* recreate moveset tree (database is already created) */

TreeNew();

/* set the root move as the last played move */

SetUpRootMove();

/* automatically set the notational game termination code */

GTCSet(gtc_none);
GTCAutoSet();

/* print terminating message if necessary */

if (((gs = GameStatus(root_sptr)) != gs_norm) && !silent_play)
	PrStrGameStatusNL("Game over: ", gs);

/* check for clock stoppage */

if (gs != gs_norm)
	ClockStop();

/* handle two-time repetition */

if ((gs == gs_norm) &&
	DrawRepeatTwice() && ponder_trace && !silent_play)
	PrNote("This is the second repetition for this position");

/* handle two-time repetition */

if ((gs == gs_norm) &&
	(root_sptr->s_count == 1) && ponder_trace && !silent_play)
	PrNote("Only one move is now available");

/* process auto save checkpoint option */

if (optnv[optn_asgc])
	if ((actc == c_w) && ((envn.envn_fmvn % ten) == 1))
		if (!SaveGameCode(fn_chkp))
			PrErr("Can't save game at checkpoint");

/* refresh */

if (!ponder_active)
	{
	DpUpdate(winid_board);
	DpUpdate(winid_status);
	};

DpUpdate(winid_clock);
DpUpdate(winid_search);
DpUpdate(winid_time);

return;
}

/*<<< play.c: EOF */
