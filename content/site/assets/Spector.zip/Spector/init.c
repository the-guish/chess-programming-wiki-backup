/*>>> init.c: initialization routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "bookdefs.h"
#include "csdefs.h"
#include "epddefs.h"
#include "tbdefs.h"
#include "vpdefs.h"

#include "bookutil.h"
#include "clock.h"
#include "command.h"
#include "cpmb.h"
#include "csutil.h"
#include "create.h"
#include "display.h"
#include "epd.h"
#include "epos.h"
#include "gen.h"
#include "init.h"
#include "initcons.h"
#include "link.h"
#include "memutil.h"
#include "mpool.h"
#include "pawn.h"
#include "ponder.h"
#include "predvar.h"
#include "print.h"
#include "sysutil.h"
#include "tags.h"
#include "tb.h"
#include "tt.h"
#include "ts.h"
#include "util.h"

#if (os_mac)
#include <SIOUX.h>
#include <Types.h>
#endif

/*--> InitGroundState: set up ground state values (called once only) */
static
void
InitGroundState(void)
{
/* initialize the clank time mark */

tmark_clank = time(NULL);

/* clear the silent play display flag */

silent_play = 0;

/* clear the no fifty move draw  flag */

no_50mvdraw = 0;

/* clear the search termination reason code */

strc = strc_none;

/* clear the move/multimove stop flag */

stop_play = 0;

/* move pool initialization */

MPoolInit();

/* allocate the history area */

histbase = (histptrT) MemoryGrab(sizeof(histT) * histL);

/* allocate the canonical ordinal area */

cordbase = (cordptrT) MemoryGrab(sizeof(cordT) * histL);

/* allocate the environmental area */

envn_base = (envnptrT) MemoryGrab(sizeof(envnT) * plyL);

/* allocate the group killer move vector area */

gkm_base = (gkmptrT) MemoryGrab(sizeof(gkmT) * plyL);

/* allocate the killer response area */

killer_response_base = (smptrT) MemoryGrab(sizeof(smT) * rcL * sqsqL);

/* allocate the killer popularity area */

killer_pop_base = (siptrT) MemoryGrab(sizeof(siT) * rcL * sqsqL);

/* allocate the counter killer move area */

counter_killer_base = (smptrT) MemoryGrab(sizeof(smT) * rcL * sqsqL);

/* initialize the standard ply depth for full information history push */

history_full_push = 1;

/* initialize the predicted variation subsystem */

PVarInit();

/* initialize the list book */

ListBookInit();

/* set up ground state default playing level */

level = plyL - 1;

/* set the ground state for the moveset root items */

root_sptr = NULL;
root_m = null_m;

/* clear the iteration index */

iteration = 0;

/* set the current ply */

ply = 0;

/* set the ground state for the environmental pointer */

envn_curr = envn_base;

/* set the ground state for the statistics */

count_exec = count_node = pre_count_node = 0;

/* set the ground state for the time control */

TimeControlReset();

/* clear the countdown timer and node countdown */

countdown_timer = 0;
node_countdown = 0;

/* clear the ponder search status */

PonderSearchReset();

/* clear the search target move list */

target_mlstptr = NULL;

/* assign inital values to display interface items */

di_expectation = cpev_draw;
di_p0span = di_p0pick = 0;
di_p0m = null_m;
di_iteration = 0;
di_nodes = di_seconds = 0;
di_completion = 0.0;
di_prediction = 0;

return;
}

/*--> InitSq: set a square on the playing board */
nonstatic
void
InitSq(cpT cp, sqT sq)
{
board.rbv[sq] = cp;

return;
}

/*--> ClearBoard: clear the playing board */
nonstatic
void
ClearBoard(void)
{
sqT sq;

for (sq = sq_a1; sq <= sq_h8; sq++)
	InitSq(cp_v0, sq);

return;
}

/*--> ClearEnvironment: clear the environment */
nonstatic
void
ClearEnvironment(void)
{
envn.envn_cast = 0;
envn.envn_epsq = sq_nil;
envn.envn_fmvn = 1;
envn.envn_hmvc = 0;
envn.envn_mhac = 0;
envn.envn_mhsc = 0;
envn.envn_phac = 0;
envn.envn_phsc = 0;

return;
}

/*--> CopyBoard: copy the local board into the playing board */
nonstatic
void
CopyBoard(void)
{
sqT sq;

for (sq = sq_a1; sq <= sq_h8; sq++)
	InitSq(local.rbv[sq], sq);

return;
}

/*--> InitStartingPosition: set up the initial position on the board */
static
void
InitStartingPosition(void)
{
/* clear the board */

ClearBoard();

/* set up white pieces */

InitSq(cp_wr, sq_a1);
InitSq(cp_wn, sq_b1);
InitSq(cp_wb, sq_c1);
InitSq(cp_wq, sq_d1);
InitSq(cp_wk, sq_e1);
InitSq(cp_wb, sq_f1);
InitSq(cp_wn, sq_g1);
InitSq(cp_wr, sq_h1);

/* set up white pawns */

InitSq(cp_wp, sq_a2);
InitSq(cp_wp, sq_b2);
InitSq(cp_wp, sq_c2);
InitSq(cp_wp, sq_d2);
InitSq(cp_wp, sq_e2);
InitSq(cp_wp, sq_f2);
InitSq(cp_wp, sq_g2);
InitSq(cp_wp, sq_h2);

/* set up black pieces */

InitSq(cp_br, sq_a8);
InitSq(cp_bn, sq_b8);
InitSq(cp_bb, sq_c8);
InitSq(cp_bq, sq_d8);
InitSq(cp_bk, sq_e8);
InitSq(cp_bb, sq_f8);
InitSq(cp_bn, sq_g8);
InitSq(cp_br, sq_h8);

/* set up black pawns */

InitSq(cp_bp, sq_a7);
InitSq(cp_bp, sq_b7);
InitSq(cp_bp, sq_c7);
InitSq(cp_bp, sq_d7);
InitSq(cp_bp, sq_e7);
InitSq(cp_bp, sq_f7);
InitSq(cp_bp, sq_g7);
InitSq(cp_bp, sq_h7);

return;
}

/*--> InitNewGame: reset for a new game */
nonstatic
void
InitNewGame(void)
{
/* re-seed the random number generator */

(void) srand(time(NULL));

/* set the game termination code */

gtc = gtc_none;

/* clear the set-up indicator */

setup = 0;

/* set up the initial position */

InitStartingPosition();

/* set the active/passive colors at the current ply */

actc = c_w;
pasc = c_b;

/* set the environmental status */

ClearEnvironment();
envn.envn_cast = (cf_wk | cf_wq | cf_bk | cf_bq);

/* create the environment */

CreateEnvironment();

/* reset the main hash and pawn structure hash subsystems */

TTReset();
PawnTTReset();

/* clear, then start the clocks */

ClockClear();
ClockStart();

return;
}

/*--> Init: main initializer */
nonstatic
void
Init(void)
{
#if (os_mac)
{
/* Set the stack space by pre-positioning the heap */

/*
SetApplLimit(GetApplLimit() - (32L * kiloL));
MaxApplZone();
*/
/* set the SIOUX console window options */

SIOUXSettings.autocloseonquit = 1;
SIOUXSettings.asktosaveonclose = 0;
}
#endif

/* set the "nil" string */

nilstr = "nil";

/* set the program start time mark */

tmark_pstart = time(NULL);

/* copy the program start time mark as the initial command time mark */

tmark_mkcomm = tmark_pstart;

/* initialize the display */

DpInit();

/* sign on information and timestamp */

PrLogoBanner();
PrInformationBanner();
PrTimestamp();

/* clear termination flag */

progdone = 0;

/* intialize the external linkage */

LinkInit();

/* initialize constants */

InitConstants();

/* Extended Position Description initilaization */

EPDInit();

/* tag subsystem initialization */

TagInit();

/* move generation system initialization */

GenerateInit();

/* tactical search module initialization */

TSInit();

/* positional evaluation system initialization */

EvaluatePositionalInit();

/* initialize concept search items */

CSInit();

/* initialize the main and the pawn structure transposition subsystems */

TTInit();
PawnTTInit();

/* initialize the command processor for multibook */

CPMBInit();

/* initialize the tablebase subsystem */

TBInit();

/* set the default notation mode */

global_nm = nm_algebraic;

/* set the default notation language indices */

lang_get = lang_put = lang_english;

/* initialize ground state */

InitGroundState();

/* initialize for a new game */

InitNewGame();

/* clear the dribble file pointer */

drib_fptr = NULL;

/* clear the transfer command line pointer */

xferline = NULL;

/* set up the command input file subsystem */

CommandFileInit();

/* initialize the strategies */

strtv[c_w] = strtv[c_b] = default_strt;

return;
}

/*<<< init.c: EOF */
