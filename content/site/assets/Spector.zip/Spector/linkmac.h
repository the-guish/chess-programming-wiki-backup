/*>>> linkmac.h: subprogram prototypes for linkmac.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT LinkMacGet(channelT channel, byteptrT bptr, liT length);
siT LinkMacPut(channelT channel, byteptrT bptr, liT length);
liT LinkMacStat(channelT channel);
siT LinkMacOpen(channelT channel);
siT LinkMacClose(channelT channel);
void LinkMacInit(void);
void LinkMacTerm(void);

/*<<< linkmac.h: EOF */
