/*>>> pc.h: subprogram prototypes for pc.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void ProcessBEEP(void);
void ProcessCALL(void);
void ProcessCOMM(void);
void ProcessCPIC(void);
void ProcessCPLB(void);
void ProcessCPMB(void);
void ProcessCPTB(void);
void ProcessDESC(void);
void ProcessDUMP(void);
void ProcessECHO(void);
void ProcessENUM(void);
void ProcessEVAL(void);
void ProcessEXIT(void);
void ProcessHINT(void);
void ProcessINFO(void);
void ProcessJUMP(void);
void ProcessLOGO(void);
void ProcessMARK(void);
void ProcessNEWG(void);
void ProcessNOOP(void);
void ProcessRTRN(void);
void ProcessSCON(void);
void ProcessSORT(void);
void ProcessSWAP(void);
void ProcessSYST(void);
void ProcessTEST(void);
void ProcessTRAC(void);

/*<<< pc.h: EOF */
