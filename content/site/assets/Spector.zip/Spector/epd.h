/*>>> epd.h: subprogram prototypes for epd.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

eovptrT EPDNewEOV(void);
void EPDReleaseEOV(eovptrT eovptr);
void EPDAppendEOV(eopptrT eopptr, eovptrT eovptr);
eovptrT EPDCreateEOVStr(charptrT str);
eovptrT EPDCreateEOVSym(charptrT sym);
eovptrT EPDCreateEOVInt(liT lval);
eovptrT EPDLocateEOV(eopptrT eopptr, charptrT strval);
siT EPDCountEOV(eopptrT eopptr);
void EPDReplaceEOVStr(eovptrT eovptr, charptrT str);
eopptrT EPDNewEOP(void);
void EPDReleaseEOP(eopptrT eopptr);
void EPDAppendEOP(epdptrT epdptr, eopptrT eopptr);
eopptrT EPDCreateEOP(charptrT opsym);
eopptrT EPDCreateEOPCode(epdsoT epdso);
eopptrT EPDLocateEOP(epdptrT epdptr, charptrT opsym);
eopptrT EPDLocateEOPCode(epdptrT epdptr, epdsoT epdso);
siT EPDCountEOP(epdptrT epdptr);
void EPDDropIfLocEOP(epdptrT epdptr, charptrT opsym);
void EPDDropIfLocEOPCode(epdptrT epdptr, epdsoT epdso);
void EPDAddOpSym(epdptrT epdptr, epdsoT epdso, charptrT s);
epdptrT EPDNewEPD(void);
void EPDReleaseOperations(epdptrT epdptr);
void EPDReleaseEPD(epdptrT epdptr);
charptrT EPDFetchOpsym(epdsoT epdso);
charptrT EPDFetchRefcomStr(refcomT refcom);
charptrT EPDFetchRefreqStr(refreqT refreq);
refcomT EPDFetchRefcomIndex(charptrT s);
refreqT EPDFetchRefreqIndex(charptrT s);
refcomT EPDExtractRefcomIndex(epdptrT epdptr);
refreqT EPDExtractRefreqIndex(epdptrT epdptr);
epdptrT EPDSet(rbptrT rbptr, cT actc, castT cast, sqT epsq);
epdptrT EPDSetCurrent(void);
charptrT EPDGenBasic(rbptrT rbptr, cT actc, castT cast, sqT epsq);
charptrT EPDGenBasicCurrent(void);
epdptrT EPDDecode(charptrT s);
charptrT EPDEncode(epdptrT epdptr);
void EPDRealize(epdptrT epdptr);
void EPDInit(void);
void EPDTerm(void);

/*<<< epd.h: EOF */
