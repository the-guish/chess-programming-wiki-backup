/*>>> main.h: subprogram prototypes for main.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

int main(void);

/*<<< main.h: EOF */
