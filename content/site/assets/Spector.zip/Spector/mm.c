/*>>> mm.c: move matching routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "mm.h"
#include "notation.h"
#include "print.h"
#include "san.h"
#include "sysutil.h"

/*--> MatchAlgebraicScan: scan selected mode algebraic moves */
static
mptrT
MatchAlgebraicScan(sptrT sptr, sanT san0, siptrT pflag, nvpcvT nvpcv)
{
mptrT mptr0, mptr1;
siT match, i, count;
sanT san1;

/* set up for scan */

match = 0;
mptr0 = NULL;
mptr1 = sptr->s_mbase;
count = sptr->s_count;

/* scan the (disambiguated) moveset */

for (i = 0; i < count; i++)
	{
	SANMoveAux(mptr1, san1, nvpcv);
	if (strcmp(san0, san1) == 0)
		{
		match++;
		mptr0 = mptr1;
		};
	mptr1++;
	};

/* fault if more than one match */

if (match > 1)
	{
	PrErr("Ambiguous move entered - type \"stat\" for list");
	*pflag = 0;
	mptr0 = NULL;
	};

return (mptr0);
}

/*--> MatchAlgebraicMove: attempt to match string move to algebraic move */
static
mptrT
MatchAlgebraicMove(charptrT s, sptrT sptr)
{
siT i, len, flag, count, nvpflag;
mptrT mptr, xptr;
nvpcvT nvpfv, nvplv;
nvpT nvp;
sanT san0, san1;

/* set up */

flag = 1;

/* set default */

mptr = NULL;

/* ensure length okay */

len = strlen(s);
if ((len < 2) || (len >= sanL))
	flag = 0;

/* copy and pad input */

if (flag)
	{
	for (i = 0; i < len; i++)
		san0[i] = *(s + i);
	while (i < sanL)
		san0[i++] = ascii_nul;
	};

/* construct lower case version */

if (flag)
	for (i = 0; i < sanL; i++)
		san1[i] = map_lower(san0[i]);

/* set count */

count = sptr->s_count;

/* set scan limit: case flag */

if (optnv[optn_nmde])
	nvplv[nvp_case] = 1;
else
	nvplv[nvp_case] = 2;

/* set scan limit: chec flag */

nvplv[nvp_chec] = 1;
if (!optnv[optn_nmde])
	{
	xptr = sptr->s_mbase;
	i = 0;
	while ((nvplv[nvp_chec] == 1) && (i < count))
		if (xptr->m_flag & mf_chec)
			nvplv[nvp_chec] = 3;
		else
			{
			xptr++;
			i++;
			};
	};

/* set scan limit: mate flag (includes draws) */

nvplv[nvp_mate] = 1;
if (!optnv[optn_nmde])
	{
	xptr = sptr->s_mbase;
	i = 0;
	while ((nvplv[nvp_mate] == 1) && (i < count))
		if ((xptr->m_flag & mf_mate) || (xptr->m_flag & mf_draw))
			nvplv[nvp_mate] = 4;
		else
			{
			xptr++;
			i++;
			};
	};

/* set scan limit: capt flag */

nvplv[nvp_capt] = 1;
if (!optnv[optn_nmde])
	{
	xptr = sptr->s_mbase;
	i = 0;
	while ((nvplv[nvp_capt] == 1) && (i < count))
		if ((xptr->m_tocp != cp_v0) || (xptr->m_scmv == scmv_epc))
			nvplv[nvp_capt] = 5;
		else
			{
			xptr++;
			i++;
			};
	};

/* set scan limit: pcdr flag */

nvplv[nvp_pcdr] = 1;
if (!optnv[optn_nmde])
	{
	xptr = sptr->s_mbase;
	i = 0;
	while ((nvplv[nvp_pcdr] == 1) && (i < count))
		if (((cv_p_cpv[xptr->m_frcp] == p_p) && (xptr->m_tocp != cp_v0)) ||
			(xptr->m_scmv == scmv_epc))
			nvplv[nvp_pcdr] = 2;
		else
			{
			xptr++;
			i++;
			};
	};

/* set scan limit: prom flag */

nvplv[nvp_prom] = 1;
if (!optnv[optn_nmde])
	{
	xptr = sptr->s_mbase;
	i = 0;
	while ((nvplv[nvp_prom] == 1) && (i < count))
		if (cv_p_scmvv[xptr->m_scmv] != p_v)
			nvplv[nvp_prom] = 4;
		else
			{
			xptr++;
			i++;
			};
	};

/* set scan limit: cast flag */

nvplv[nvp_cast] = 1;
if (!optnv[optn_nmde])
	{
	xptr = sptr->s_mbase;
	i = 0;
	while ((nvplv[nvp_cast] == 1) && (i < count))
		if ((xptr->m_scmv == scmv_cks) || (xptr->m_scmv == scmv_cqs))
			nvplv[nvp_cast] = 4;
		else
			{
			xptr++;
			i++;
			};
	};

/* set scan limit: epsq flag */

nvplv[nvp_epsq] = 1;
if (!optnv[optn_nmde])
	{
	xptr = sptr->s_mbase;
	i = 0;
	while ((nvplv[nvp_epsq] == 1) && (i < count))
		if (xptr->m_scmv == scmv_epc)
			nvplv[nvp_epsq] = 2;
		else
			{
			xptr++;
			i++;
			};
	};

/* set scan limit: extf flag */

if (optnv[optn_nmde] || !optnv[optn_emde])
	nvplv[nvp_extf] = 1;
else
	nvplv[nvp_extf] = 2;

/* set scan limit: extr flag */

if (optnv[optn_nmde] || !optnv[optn_emde])
	nvplv[nvp_extr] = 1;
else
	nvplv[nvp_extr] = 2;

/* set scan limit: dash flag */

if (optnv[optn_nmde] || !optnv[optn_emde])
	nvplv[nvp_dash] = 1;
else
	nvplv[nvp_dash] = 2;

/* set scan limit: pawn flag */

if (optnv[optn_nmde] || !optnv[optn_emde])
	nvplv[nvp_pawn] = 1;
else
	{
	xptr = sptr->s_mbase;
	i = 0;
	nvplv[nvp_pawn] = 1;
	while ((nvplv[nvp_pawn] == 1) && (i < count))
		if (cv_p_cpv[xptr->m_frcp] == p_p)
			nvplv[nvp_pawn] = 2;
		else
			{
			xptr++;
			i++;
			};
	};

/* set scan limit: cmpl flag */

if (optnv[optn_nmde] || !optnv[optn_emde])
	nvplv[nvp_cmpl] = 1;
else
	{
	nvplv[nvp_cmpl] = 1;
	xptr = sptr->s_mbase;
	i = 0;
	while ((nvplv[nvp_cmpl] == 1) && (i < count))
		if ((xptr->m_tocp != cp_v0) || (xptr->m_scmv == scmv_epc))
			nvplv[nvp_cmpl] = 2;
		else
			{
			xptr++;
			i++;
			};
	};

/* set scan limit: anno flag */

if (optnv[optn_nmde] || !optnv[optn_emde])
	nvplv[nvp_anno] = 1;
else
	nvplv[nvp_anno] = 3;

/* set up for space search by clearing scanning vector */

for (nvp = 0; nvp < nvpL; nvp++)
	nvpfv[nvp] = 0;

/* search */

while (flag && (mptr == NULL))
	{
	/* check current coordinate set */

	if (nvpfv[nvp_case] == 0)
		mptr = MatchAlgebraicScan(sptr, san0, &flag, nvpfv);
	else
		mptr = MatchAlgebraicScan(sptr, san1, &flag, nvpfv);

	/* test if increment needed */

	if (flag && (mptr == NULL))
		{
		/* increment current coordinate set */

		nvpflag = 1;
		nvp = 0;
		while (nvpflag && (nvp < nvpL))
			{
			nvpfv[nvp]++;
			nvpflag = 0;
			if (nvpfv[nvp] == nvplv[nvp])
				{
				nvpfv[nvp] = 0;
				nvpflag = 1;
				}
			nvp++;
			};

		/* check for overflow */

		if (nvpflag)
			flag = 0;
		};
	};

return (mptr);
}

/*--> MatchCoordinateMove: attempt to match string move to a coord. move */
static
mptrT
MatchCoordinateMove(charptrT s, sptrT sptr)
{
mptrT mptr;
siT flag, i, count;
sanT san;

count = sptr->s_count;
mptr = sptr->s_mbase;
i = 0;
flag = 0;

while (!flag && (i < count))
	{
	CoordinateMove(mptr, san);
	if (strcmp(s, san) == 0)
		flag = 1;
	else
		{
		mptr++;
		i++;
		};
	};

if (!flag)
	mptr = NULL;

return (mptr);
}

/*--> MatchExperimentalMove: try to match string move to experimental */
static
mptrT
MatchExperimentalMove(charptrT s, sptrT sptr, nmT nm)
{
mptrT mptr;
siT flag, i, count;
sanT san;

count = sptr->s_count;
mptr = sptr->s_mbase;
i = 0;
flag = 0;

while (!flag && (i < count))
	{
	switch (nm)
		{
		case nm_exp0:
			Exp0Move(mptr, san);
			break;

		case nm_exp1:
			Exp1Move(mptr, san);
			break;

		case nm_exp2:
			Exp2Move(mptr, san);
			break;

		case nm_exp3:
			Exp3Move(mptr, san);
			break;

		case nm_exp4:
			Exp4Move(mptr, san);
			break;

		case nm_exp5:
			Exp5Move(mptr, san);
			break;

		default:
			SwitchFault("MatchExperimentalMove");
			break;
		};
	if (strcmp(s, san) == 0)
		flag = 1;
	else
		{
		mptr++;
		i++;
		};
	};

if (!flag)
	mptr = NULL;

return (mptr);
}

/*--> MatchMove: attempt to match string move to a listed move */
nonstatic
mptrT
MatchMove(charptrT s, sptrT sptr)
{
mptrT mptr;

mptr = NULL;
switch (global_nm)
	{
	case nm_algebraic:
		mptr = MatchAlgebraicMove(s, sptr);
		break;

	case nm_coordinate:
		mptr = MatchCoordinateMove(s, sptr);
		break;

	case nm_exp0:
	case nm_exp1:
	case nm_exp2:
	case nm_exp3:
	case nm_exp4:
	case nm_exp5:
		mptr = MatchExperimentalMove(s, sptr, global_nm);
		break;

	default:
		SwitchFault("MatchMove");
		break;
	};

return (mptr);
}

/*<<< mm.c: EOF */
