/*>>> sysutil.c: system utility routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "file.h"
#include "print.h"
#include "sysutil.h"

#if (os_mac)
#include <Types.h>
#include <Processes.h>
#include <unix.h>
#endif

#if (os_unix)
#include <unistd.h>
#endif

/*--> GetProcessID: return ID number of current process */
nonstatic
liT
GetProcessID(void)
{
liT id;

#if (os_mac)
{
OSErr result;
ProcessSerialNumber psn;

result = GetCurrentProcess(&psn);
if (result != noErr)
	Diagnose("GetProcessID: GetCurrentProcess fault");

id = psn.lowLongOfPSN;
}
#endif

#if (os_unix)
id = getpid();
#endif

return (id);
}

/*--> Pause: pause and acknowledge message */
nonstatic
void
Pause(charptrT s)
{
(void) fprintf(stderr, "Pause: %s", s);
#if (0)
(void) getchar();
#else
{
liT t0;

t0 = time(NULL);
while ((time(NULL) - t0) < 5)
	;
}
fprintf(stderr, "\n");
#endif

return;
}

/*--> Acknowledge: display and acknowledge message */
nonstatic
void
Acknowledge(charptrT s)
{
(void) fprintf(stderr, "Acknowledge: %s\n", s);
(void) getchar();

return;
}

/*--> Diagnose: output string to stderr and exit */
nonstatic
void
Diagnose(charptrT s)
{
Acknowledge(s);
(void) fprintf(stderr, "%s: fatal error: %s.\n", progname, s);
exit(1);

return;
}

/*--> DiagnoseTwo: output two strings to stderr and exit */
nonstatic
void
DiagnoseTwo(charptrT s0, charptrT s1)
{
Acknowledge(s0);
Acknowledge(s1);
(void) fprintf(stderr, "%s: fatal error: %s: %s.\n", progname, s0, s1);
exit(1);

return;
}

/*--> Overflow: diagnose fatal overflow fault */
nonstatic
void
Overflow(charptrT s)
{
Acknowledge("Overflow fault");
Acknowledge(s);
(void) fprintf(stderr, "%s: fatal error: %s: [overflow]\n", progname, s);
exit(1);

return;
}

/*--> SwitchFault: diagnose fatal switch fault */
nonstatic
void
SwitchFault(charptrT s)
{
Acknowledge("Switch fault");
Acknowledge(s);
(void) fprintf(stderr, "%s: fatal error: %s: [switch fault]\n", progname, s);
exit(1);

return;
}

/*--> Fault: diagnose fatal fault */
nonstatic
void
Fault(charptrT s)
{
Acknowledge("Fault");
Acknowledge(s);
(void) fprintf(stderr, "%s: fatal error: %s: [fault]\n", progname, s);
exit(1);

return;
}

/*--> Noop: nothing */
nonstatic
void
Noop(void)
{

return;
}

/*--> Beep: honk */
nonstatic
void
Beep(siT n)
{
siT i;

for (i = 0; i < n; i++)
	{
	(void) fputc(ascii_bel, stderr);
	(void) TextFileFlush(stderr);
	};

return;
}

/*--> TimeStampAt: generate a timestamp for the given time */
nonstatic
void
TimeStampAt(time_t tval, stampT stamp)
{
struct tm tmark;

tmark = *localtime(&tval);
(void) sprintf(stamp, "%04hd.%02hd.%02hd %02hd:%02hd:%02hd",
	((siT) (tmark.tm_year + 1900)), ((siT) (tmark.tm_mon + 1)),
	((siT) tmark.tm_mday), ((siT) tmark.tm_hour),
	((siT) tmark.tm_min), ((siT) tmark.tm_sec));

return;
}

/*--> TimeStamp: generate a current timestamp */
nonstatic
void
TimeStamp(stampT stamp)
{
TimeStampAt(time(NULL), stamp);

return;
}

/*--> SyncSecond: synchronize execution to the start of a new second */
nonstatic
void
SyncSecond(void)
{
time_t t0, t1;

(void) time(&t0);
do
	{
	(void) time(&t1);
	}
while (t0 == t1);

return;
}

/*--> Sleep: sleep */
nonstatic
void
Sleep(siT n)
{
#if (os_unix)
unsigned int sleep(unsigned int n);
#endif

if (n < 0)
	Diagnose("Sleep: fault");

#if (os_unix)
sleep(n);
#endif

return;
}

/*--> EncodeTimeRecord: construct a time record given a seconds count */
nonstatic
void
EncodeTimeRecord(liT t, timerecptrT trptr)
{
/* days */

if (t < dayL)
	trptr->timerec_day = 0;
else
	{
	trptr->timerec_day = t / dayL;
	t -= trptr->timerec_day * dayL;
	};

/* hours */

if (t < hourL)
	trptr->timerec_hour = 0;
else
	{
	trptr->timerec_hour = t / hourL;
	t -= trptr->timerec_hour * hourL;
	};

/* minutes */

if (t < minuteL)
	trptr->timerec_minute = 0;
else
	{
	trptr->timerec_minute = t / minuteL;
	t -= trptr->timerec_minute * minuteL;
	};

/* seconds */

trptr->timerec_second = t;

return;
}

/*--> Transfer: process possible program transfer */
nonstatic
void
Transfer(void)
{
#if (os_mac)
if (xferline != NULL)
	PrErr("Not yet implemented");
#endif

#if (os_unix)
if (xferline != NULL)
	{
	(void) execvp(xferline, xferargv);
	Diagnose("Transfer failure");
	};
#endif

return;
}

/*<<< sysutil.c: EOF */
