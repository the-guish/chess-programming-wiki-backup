/*>>> notation.h: subprogram prototypes for notation.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CoordinateMove(mptrT mptr, sanT san);
void Exp0Move(mptrT mptr, sanT san);
void Exp1Move(mptrT mptr, sanT san);
void Exp2Move(mptrT mptr, sanT san);
void Exp3Move(mptrT mptr, sanT san);
void Exp4Move(mptrT mptr, sanT san);
void Exp5Move(mptrT mptr, sanT san);
void ConstructNotation(nmT nm, mptrT mptr, sanT san);

/*<<< notation.h: EOF */
