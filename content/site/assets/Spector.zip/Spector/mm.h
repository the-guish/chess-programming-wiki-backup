/*>>> mm.h: subprogram prototypes for mm.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

mptrT MatchMove(charptrT s, sptrT sptr);

/*<<< mm.h: EOF */
