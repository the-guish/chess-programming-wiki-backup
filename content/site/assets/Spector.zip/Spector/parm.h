/*>>> parm.h: subprogram prototypes for parm.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT ParameterCheckColor(siT ch);
cT ParameterEvalColor(siT ch);
siT ParameterCheckFile(siT ch);
fileT ParameterEvalFile(siT ch);
siT ParameterCheckPiece(siT ch);
pT ParameterEvalPiece(siT ch);
siT ParameterCheckRank(siT ch);
rankT ParameterEvalRank(siT ch);
siT ParameterCheckSI(charptrT s);
siT ParameterEvalSI(charptrT s);
siT ParameterCheckSquare(charptrT s);
sqT ParameterEvalSquare(charptrT s);
siT ParameterCheck(commT commid, siT i);
void ParameterEval(commT commid, siT i);

/*<<< parm.h: EOF */
