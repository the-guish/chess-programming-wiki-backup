/*>>> initstrs.h: subprogram prototypes for initstrs.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void InitStrs(void);

/*<<< initstrs.h: EOF */
