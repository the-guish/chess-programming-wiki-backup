/*>>> term.c: termination routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bookdefs.h"
#include "csdefs.h"
#include "epddefs.h"
#include "tbdefs.h"
#include "vpdefs.h"

#include "bookutil.h"
#include "command.h"
#include "cpmb.h"
#include "csutil.h"
#include "display.h"
#include "epd.h"
#include "file.h"
#include "link.h"
#include "memutil.h"
#include "moveset.h"
#include "mpool.h"
#include "pawn.h"
#include "predvar.h"
#include "tags.h"
#include "tb.h"
#include "term.h"
#include "ts.h"
#include "tt.h"

/*--> Term: main terminator */
nonstatic
void
Term(void)
{
/* terminate the main and the pawn structuretransposition subsystems */

TTTerm();
PawnTTTerm();

/* terminate the tablebase subsystem */

TBTerm();

/* terminate the comamnd processor for the multibook */

CPMBTerm();

/* terminate concept search items */

CSTerm();

/* terminate the tactical search module */

TSTerm();

/* terminate the list book */

ListBookTerm();

/* terminate the predicted variation subsystem */

PVarTerm();

/* terminate the Extended Position Description subsystem */

EPDTerm();

/* deallocate ordinal storage */

MemoryFree(cordbase);

/* deallocate history storage */

MemoryFree(histbase);

/* deallocate grouped killer move vector storage */

MemoryFree(gkm_base);

/* deallocate killer response storage */

MemoryFree(killer_response_base);

/* deallocate killer popularity storage */

MemoryFree(killer_pop_base);

/* deallocate counter killer storage */

MemoryFree(counter_killer_base);

/* deallocate environment storage */

MemoryFree(envn_base);

/* deallocate the bit enumeration table and the bit first table*/

MemoryFree(bevbase);
MemoryFree(bfvbase);

/* deallocate sq/sq tables and rasters */

MemoryFree(dx_table_base);
MemoryFree(taxi_table_base);
MemoryFree(mintaxi_table_base);
MemoryFree(ray_raster_base);
MemoryFree(path_raster_base);
MemoryFree(beyond_raster_base);

/* ensure move tree deallocated */

if (root_sptr != NULL)
	{
	MovesetRelease(root_sptr);
	root_sptr = NULL;
	};

/* terminate the move pool system */

MPoolTerm();

/* close the dribble file */

if (drib_fptr != NULL)
	(void) TextFileClose(drib_fptr);

/* terminate the tag subsystem */

TagTerm();

/* terminate the input command file subsystem */

CommandFileTerm();

/* terminate the external linkage */

LinkTerm();

/* terminate the display */

DpTerm();

return;
}

/*<<< term.c: EOF */
