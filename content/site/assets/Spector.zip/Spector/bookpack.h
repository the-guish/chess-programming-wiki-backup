/*>>> bookpack.h: subprogram prototypes for bookpack.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT ListBookPackp(charptrT fn_w_bkcd, charptrT fn_w_pccd, charptrT fn_w_pctx,
	charptrT fn_w_obmp);

/*<<< bookpack.h: EOF */
