/*>>> pcexec.c: process command routines (move execution) */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"

#include "commdefs.h"
#include "commvars.h"

#include "mm.h"
#include "moveset.h"
#include "pcexec.h"
#include "play.h"
#include "predvar.h"
#include "print.h"
#include "stat.h"

/*--> ProcessEXPM: process execute predicted move */
nonstatic
void
ProcessEXPM(void)
{
mT m;

/* test if a predicted move exists */

if (!PVarELength())
	PrErr("No predicted move available");
else
	{
	/* fetch and execute predicted move */

	m = *PVarEFirstMoveRef();
	PlayMove(&m);
	};

return;
}

/*--> ProcessEXPV: process execute predicted variation */
nonstatic
void
ProcessEXPV(void)
{
siT i, length;
mT m;
mptrT mptr;

/* fetch predicted variation length */

if ((length = PVarELength()) == 0)
	PrErr("No predicted variation available");
else
	{
	/* execute predicted variation */

	for (i = 0; i < length; i++)
		{
		/* fetch and execute predicted move */

		m = *PVarEFirstMoveRef();
		mptr = FindMoveNF(&m, root_sptr, "ProcessEXPV");
		PlayMove(mptr);
		};
	};

return;
}

/*--> ProcessEXSM: process execute supplied move */
nonstatic
void
ProcessEXSM(void)
{
gsT gs;
mptrT mptr;

if ((gs = GameStatus(root_sptr)) != gs_norm)
	PrStrGameStatusNL("Can't execute move: ", gs);
else
	{
	lang_san = lang_get;
	mptr = MatchMove(ipv[1].ip_str, root_sptr);
	lang_san = lang_put;

	/* process match */

	if (mptr == NULL)
		{
		PrStr("Can't locate move: ");
		PrLine(ipv[1].ip_str);
		}
	else
		PlayMove(mptr);
	};

return;
}

/*--> ProcessEXSV: process execute supplied variation */
nonstatic
void
ProcessEXSV(void)
{
gsT gs;
siT i, flag;
charptrT mstr;
mptrT mptr;

if ((gs = GameStatus(root_sptr)) != gs_norm)
	PrStrGameStatusNL("Can't execute variation: ", gs);
else
	{
	/* execute moves */

	flag = 1;
	i = 0;
	while (flag && (gs == gs_norm) && (i < (tkn - 1)))
		{
		mstr = ipv[i + 1].ip_str;

		/* set SAN input mode (must evaluate string parameters as moves) */

		lang_san = lang_get;

		/* attempt to match input move */

		mptr = MatchMove(mstr, root_sptr);

		/* set SAN output mode  */

		lang_san = lang_put;

		/* process match */

		if (mptr == NULL)
			{
			flag = 0;
			PrStr("Can't execute move: ");
			PrLine(mstr);
			}
		else
			{
			/* play the move and update */

			PlayMove(mptr);
			i++;
			gs = GameStatus(root_sptr);
			};
		};
	if (flag)
		if (i < (tkn - 1))
			{
			PrStr("Can't execute move (game status change): ");
			PrLine(ipv[i + 1].ip_str);
			};
	};

return;
}

/*<<< pcexec.c: EOF */
