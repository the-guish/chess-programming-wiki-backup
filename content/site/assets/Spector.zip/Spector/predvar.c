/*>>> predvar.c: predicted variation processing */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "vpdefs.h"

#include "optndefs.h"
#include "optnvars.h"

#include "display.h"
#include "draw.h"
#include "exec.h"
#include "memutil.h"
#include "moveset.h"
#include "mu.h"
#include "notation.h"
#include "predvar.h"
#include "print.h"
#include "san.h"
#include "tt.h"
#include "util.h"

/* working matrix access definitions (pointer values) */

#define wm_pv_depth_ref(depth, index)	\
	(wm_base + ((depth) << plyQ) + (index))
#define wm_pv_main_ref(index) wm_pv_depth_ref(0, index)

/**** Statics */

/* the established predicted variation and length */

static mT predvarv[plyL];
static siT predvarn;

/* the predicted variation working matrix base */

static lmptrT wm_base;

/*--> PVarEClear: clear the established predicted variation */
nonstatic
void
PVarEClear(void)
{
siT i;

for (i = 0; i < plyL; i++)
	predvarv[i] = null_m;

predvarn = 0;

return;
}

/*--> PVarELength: return the length of the established PV */
nonstatic
siT
PVarELength(void)
{

return (predvarn);
}

/*--> PVarECopyFromWM: copy from WM to established PV */
static
void
PVarECopyFromWM(void)
{
siT i;

predvarn = PVarWMMainLength();
for (i = 0; i < predvarn; i++)
	ConvertFromLimitedMove(wm_pv_main_ref(i), &predvarv[i]);

return;
}

/*--> PVarWMReset: reset the working matrix */
nonstatic
void
PVarWMReset(void)
{
siT depth, index;

for (depth = 0; depth < plyL; depth++)
	for (index = 0; index < plyL; index++)
		*wm_pv_depth_ref(depth, index) = null_lm;

return;
}

/*--> PVarInit: initialize the predicted variation subsystem */
nonstatic
void
PVarInit(void)
{
/* allocate working matrix */

wm_base = (lmptrT) MemoryGrab(sizeof(lmT) * plyplyL);

/* reset working matrix */

PVarWMReset();

/* clear the established predicted variation */

PVarEClear();

return;
}

/*--> PVarTerm: terminate predicted variation subsystem */
nonstatic
void
PVarTerm(void)
{
MemoryFree(wm_base);
PVarEClear();

return;
}

/*--> PVarWMTruncate: truncate a variation in the WM */
static
void
PVarWMTruncate(siT depth, siT index)
{
if (index < plyL)
	wm_pv_depth_ref(depth, index)->lm_flag |= mf_null;

return;
}

/*--> PVarWMCut: truncate variation at current ply in the WM */
nonstatic
void
PVarWMCut(void)
{
wm_pv_depth_ref(ply, ply)->lm_flag |= mf_null;

return;
}

/*--> PVarWMMerge: connect move/var at upper ply in the WM */
nonstatic
void
PVarWMMerge(mptrT mptr)
{
siT i;
siT p;
lmptrT lmptr0, lmptr1;

/* indicate upper ply */

p = ply - 1;

/* convert and insert input move in variation at upper ply */

ConvertToLimitedMove(mptr, wm_pv_depth_ref(p, p));

/* copy variation at current ply */

lmptr0 = wm_pv_depth_ref(p, ply);
lmptr1 = wm_pv_depth_ref(ply, ply);

i = ply;
while ((i < plyL) && !null_limited_move_ref(lmptr1))
	{
	*lmptr0++ = *lmptr1++;
	i++;
	};

/* truncate variation at upper ply */

PVarWMTruncate(p, i);

return;
}

/*--> PVarWMSplice: splice a move at upper ply in the WM */
nonstatic
void
PVarWMSplice(mptrT mptr)
{
lmptrT lmptr;

if (ply < (plyL - 1))
	{
	/* point to replacement slot */

	lmptr = wm_pv_depth_ref(ply, ply);
	ConvertToLimitedMove(mptr, lmptr);
	PVarWMTruncate(ply, (ply + 1));
	};

return;
}

/*--> PVarEMoveRef: return pointer to ply n move of est. PV */
nonstatic
mptrT
PVarEMoveRef(siT n)
{
mptrT mptr;

if (n >= predvarn)
	mptr = NULL;
else
	mptr = &predvarv[n];

return (mptr);
}

/*--> PVarEFirstMoveRef: return pointer to first move of est. PV */
nonstatic
mptrT
PVarEFirstMoveRef(void)
{

return (PVarEMoveRef(0));
}

/*--> PVarESetHint: insert hint move into predicted variation */
nonstatic
void
PVarESetHint(mptrT mptr)
{
/* insert only if not already there */

if ((predvarn == 0) || !SameMoveRef(mptr, &predvarv[0]))
	{
	/* insert */

	predvarv[0] = *mptr;
	predvarn = 1;
	};

return;
}

/*--> PVarEShift: (conditionally) shift established PV */
nonstatic
void
PVarEShift(mptrT mptr)
{
siT i;

if (predvarn > 0)
	if ((predvarn == 1) || !SameMoveRef(mptr, &predvarv[0]))
		PVarEClear();
	else
		{
		for (i = 0; i < (predvarn - 1); i++)
			predvarv[i] = predvarv[i + 1];
		predvarn--;
		};

return;
}

/*--> PVarEFormat: established PV format */
nonstatic
void
PVarEFormat(char tv[tL])
{
siT i, j, p, length;
cpevT cpabs;
char sv[tL];
sanT san;

if (predvarn == 0)
	sprintf(tv, "<none>");
else
	{
	i = 0;
	tv[i++] = '[';

	tv[i++] = (predvarn / ten) + '0';
	tv[i++] = (predvarn % ten) + '0';

	tv[i++] = '/';

	if (expectation >= 0)
		{
		cpabs = expectation;
		tv[i++] = '+';
		}
	else
		{
		cpabs = -expectation;
		tv[i++] = '-';
		};
	sprintf(sv, "%ld.%02ld",
		(((liT) cpabs) / hundred), (((liT) cpabs) % hundred));
	length = strlen(sv);
	for (j = 0; j < length; j++)
		tv[i++] = sv[j];

	tv[i++] = ']';

	for (p = 0; p < predvarn; p++)
		{
		tv[i++] = ' ';

		ConstructNotation(global_nm, &predvarv[p], san);
		length = strlen(san);
		for (j = 0; j < length; j++)
			tv[i++] = san[j];
		};
	tv[i++] = ascii_nul;
	};

return;
}

/*--> PVarEPrint: predicted variation print */
nonstatic
void
PVarEPrint(void)
{
siT i;

if (predvarn == 0)
	PrLine("<none>");
else
	{
	PrChar('[');
	PrTwoDigitSI(predvarn);
	PrStrCentipawn("/", expectation);
	PrChar(']');
	for (i = 0; i < predvarn; i++)
		{
		PrBlank();
		PrSAN(&predvarv[i]);
		};
	PrNL();
	};

return;
}

/*--> PVarWMDisambiguate: working matrix main PV disambiguation */
static
void
PVarWMDisambiguate(sptrT sptr, siT n)
{
mptrT mptr, cmptr;
lmptrT lmptr;
lmT lm;
mT m;

if (ply < n)
	{
	/* save the current move pointer for the moveset */

	cmptr = sptr->s_mcurr;

	/* ensure various move flags set */

	MovesetFlagsScan(sptr);

	/* start processing at this level */

	lm = *wm_pv_main_ref(ply);
	ConvertFromLimitedMove(&lm, &m);
	mptr = FindMoveNF(&m, sptr, "PVarWMDisambiguate");

	/* SAN flag inclusion */

	lmptr = wm_pv_main_ref(ply);
	lmptr->lm_flag |= mptr->m_flag & mfm_notation;

	/* next level */

	if (ply < (n - 1))
		{
		ExecuteMove(mptr);
		MovesetGenerateConnect(mptr);
		PVarWMDisambiguate(mptr->m_dptr, n);
		RetractMove(mptr);
		};

	/* restore the current move pointer for the moveset */

	sptr->s_mcurr = cmptr;
	};

return;
}

/*--> PVarWMMainLength: working matrix PV main length */
nonstatic
siT
PVarWMMainLength(void)
{
siT length;

/* calculate length of top level WM PV */

length = 0;
while ((length < plyL) &&
	!null_limited_move_ref(wm_pv_main_ref(length)))
	{
	length++;
	};

return (length);
}

/*--> PVarWMSubLength:working matrix PV subsequence length */
nonstatic
siT
PVarWMSubLength(void)
{
siT length;

/* calculate length of next-to-top level subvariation (always >= 1) */

length = 1;
while ((length < plyL) &&
	!null_limited_move_ref(wm_pv_depth_ref(1, length)))
	{
	length++;
	};

return (length);
}

/*--> PVarWMSubRef: working matrix PV subsequence reference */
nonstatic
lmptrT
PVarWMSubRef(siT n)
{

return (wm_pv_depth_ref(1, n));
}

/*--> PVarPlyZeroProcess: play zero working matrix PV processing */
nonstatic
void
PVarPlyZeroProcess(void)
{
siT i, length;
mT m;
mptrT mptr;

/* attempt extension of working matrix PV */

length = PVarWMMainLength();
for (i = 0; i < length; i++)
	{
	ConvertFromLimitedMove(wm_pv_main_ref(ply), &m);
	ExecuteMove(&m);
	};

/* T-table probe loop */

while ((ply < (plyL - 1)) && !DrawTestPartial() &&
	((mptr = TTFetchMoveExact()) != NULL))
	{
	ConvertToLimitedMove(mptr, wm_pv_main_ref(ply));
	ExecuteMove(mptr);
	};
PVarWMTruncate(0, ply);

/* retract entire WM base PV */

while (ply > 0)
	{
	ConvertFromLimitedMove(wm_pv_main_ref(ply - 1), &m);
	RetractMove(&m);
	};

/* ensure notational disambiguation of working matrix PV */

PVarWMDisambiguate(root_sptr, PVarWMMainLength());

/* copy from working matrix to the established version */

PVarECopyFromWM();

/* PV trace */

if (optnv[optn_trpv] && ponder_trace)
	{
	PrTrace("PV");
	PVarEPrint();
	};

/* display update */

DpUpdate(winid_predvar);

return;
}

/*<<< predvar.c: EOF */
