/*>>> cs.c: concept search move selection */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "csdefs.h"
#include "csvars.h"

#include "cs.h"
#include "csutil.h"
#include "print.h"

/*--> CSSearch: attempt to select a move using a concept search */
nonstatic
mptrT
CSSearch(void)
{
mptrT csbestmptr;

/* trace: intialization */

if (optnv[optn_trcs])
	{
	PrTrace("CS");
	PrLine("init");
	};

/* initialize the result */

csbestmptr = NULL;

/* expand the root moveset */

CSExpandNode(root_sptr);

/* trace: failure */

if (csbestmptr == NULL)
	if (optnv[optn_trcs])
		{
		PrTrace("CS");
		PrLine("failed");
		};

/* trace: termination */

if (optnv[optn_trcs])
	{
	PrTrace("CS");
	PrLine("term");
	};

return (csbestmptr);
}

/*<<< cs.c: EOF */
