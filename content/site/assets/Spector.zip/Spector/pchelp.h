/*>>> pchelp.h: subprogram prototypes for pchelp.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void ProcessHELP(void);

/*<<< pchelp.h: EOF */
