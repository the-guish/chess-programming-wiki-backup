/*>>> pcmove.h: subprogram prototypes for pcmove.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void ProcessGAME(void);
void ProcessMATE(void);
void ProcessPGOS(void);
void ProcessPLAY(void);
void ProcessPOND(void);
void ProcessRTMV(void);
void ProcessSRCH(void);

/*<<< pcmove.h: EOF */
