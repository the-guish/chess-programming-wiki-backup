/*>>> bookvars.h: variable references for opening library operations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* file pointers */

extern fptrT fp_bkcd; /* book code */
extern fptrT fp_pccd; /* book code (packed directed acyclic) */
extern fptrT fp_bktx; /* book text */
extern fptrT fp_obfc; /* book text (corrected notation) */
extern fptrT fp_pctx; /* book text (packed directed acyclic) */
extern fptrT fp_obmp; /* book move path text */
extern fptrT fp_obep; /* book move expanded position descriptions */

/* file pointer copies for record I/O */

extern fptrT fp_get_code; /* code file reading */
extern fptrT fp_put_code; /* code file writing */

/* the current opening library record */

extern olrT olr;

/* the current book text input character */

extern siT bookch;

/* the current book text input character count and line count */

extern liT bookcn, bookln;

/* the move, corrector, length, and variation totals */

extern liT booktmn, booktcn, booktln, booktvn;

/* the string version of (an uncorrected) book san move */

extern sanT bookusm;

/* the string version of a corrected book san move */

extern sanT bookcsm;

/* the book ordinal stack (ply indexed; generation ordinals) */

extern siT bkordv[plyL];
extern siT bkordn;

/* the book variation stack (holds stacked values of -bkordn-) */

extern siT bkvarv[bkvarL];
extern siT bkvarn;

/* the one shot flag used in compacted move tree output */

extern siT bkcmt;

/*<<< bookvars.h: EOF */
