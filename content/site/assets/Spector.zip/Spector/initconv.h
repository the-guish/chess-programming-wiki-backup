/*>>> initconv.h: subprogram prototypes for initconv.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void InitConversions(void);

/*<<< initconv.h: EOF */
