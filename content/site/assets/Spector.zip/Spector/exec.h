/*>>> exec.h: subprogram prototypes for exec.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void ExecuteMove(mptrT mptr);
void RetractMove(mptrT mptr);

/*<<< exec.h: EOF */
