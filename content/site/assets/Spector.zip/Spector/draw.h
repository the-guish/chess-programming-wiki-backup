/*>>> draw.h: subprogram prototypes for draw.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT DrawHalfMoveClock(void);
siT DrawInsufficientMaterial(void);
siT DrawHashRepeatTwice(void);
siT DrawHashRepeatThrice(void);
siT DrawRepeatTwice(void);
siT DrawRepeatThrice(void);
siT DrawTestPartial(void);

/*<<< draw.h: EOF */
