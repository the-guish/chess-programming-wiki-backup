/*>>> epddefs.h: Extended Postion Description definitions */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* EPD I/O buffer length */

#define epdL 4096

/* EPD operand basetype */

typedef siT eobT;

#define eob_nil (-1)

#define eob_string 0 /* quoted string */
#define eob_symbol 1 /* unquoted symbol */

/* EPD operand value type */

typedef struct eovS
	{
	eobT         eov_eob;  /* basetype */
	charptrT     eov_str;  /* string value */
	struct eovS *eov_prev; /* previous operand */
	struct eovS *eov_next; /* next operand */
	} eovT, *eovptrT;

/* EPD operation type */

typedef struct eopS
	{
	charptrT     eop_opsym;   /* operation code symbol */
	eovptrT      eop_headeov; /* head of operand value list */
	eovptrT      eop_taileov; /* tail of operand value list */
	struct eopS *eop_prev;    /* previous operation */
	struct eopS *eop_next;    /* next operation */
	} eopT, *eopptrT;

/* EPD record type */

typedef struct epdS
	{
	nbvT     epd_nbv;     /* piece placement nybble board vector */
	cT       epd_actc;    /* active color */
	castT    epd_cast;    /* castling availability */
	sqT      epd_epsq;    /* en passant target square */
	eopptrT  epd_headeop; /* head of operation list */
	eopptrT  epd_taileop; /* tail of operation list */
	} epdT, *epdptrT;

/* EPD standard operators */

typedef siT epdsoT, *epdsoptrT;
#define epdsoL 51
#define epdso_nil (-1)

#define epdso_acd          0 /* analysis count: depth */
#define epdso_acn          1 /* analysis count: nodes */
#define epdso_acs          2 /* analysis count: seconds */
#define epdso_am           3 /* avoid move(s) */
#define epdso_bm           4 /* best move(s) */
#define epdso_c0           5 /* comment slot 0 */
#define epdso_c1           6 /* comment slot 1 */
#define epdso_c2           7 /* comment slot 2 */
#define epdso_c3           8 /* comment slot 3 */
#define epdso_c4           9 /* comment slot 4 */
#define epdso_c5          10 /* comment slot 5 */
#define epdso_c6          11 /* comment slot 6 */
#define epdso_c7          12 /* comment slot 7 */
#define epdso_c8          13 /* comment slot 8 */
#define epdso_c9          14 /* comment slot 9 */
#define epdso_cc          15 /* chess clock */
#define epdso_ce          16 /* centipawn evaluation */
#define epdso_dm          17 /* direct move count */
#define epdso_draw_accept 18 /* draw accept */
#define epdso_draw_claim  19 /* draw claim */
#define epdso_draw_offer  20 /* draw offer */
#define epdso_draw_reject 21 /* draw reject */
#define epdso_eco         22 /* ECO code */
#define epdso_fmvn        23 /* fullmove number */
#define epdso_hmvc        24 /* halfmove clock */
#define epdso_id          25 /* position identification */
#define epdso_nic         26 /* NIC code */
#define epdso_noop        27 /* no operation */
#define epdso_pm          28 /* predicted move */
#define epdso_ptp         29 /* PGN tag pair(s) */
#define epdso_pv          30 /* predicted variation */
#define epdso_rc          31 /* repetition count */
#define epdso_refcom      32 /* referee command */
#define epdso_refreq      33 /* referee request */
#define epdso_resign      34 /* resign */
#define epdso_sm          35 /* supplied move */
#define epdso_sv          36 /* supplied variation */
#define epdso_tcgs        37 /* telecommunications: game selector */
#define epdso_tcri        38 /* telecommunications: receiver identification */
#define epdso_tcsi        39 /* telecommunications: sender identification */
#define epdso_ts          40 /* timestamp */
#define epdso_v0          41 /* variation slot 0 */
#define epdso_v1          42 /* variation slot 1 */
#define epdso_v2          43 /* variation slot 2 */
#define epdso_v3          44 /* variation slot 3 */
#define epdso_v4          45 /* variation slot 4 */
#define epdso_v5          46 /* variation slot 5 */
#define epdso_v6          47 /* variation slot 6 */
#define epdso_v7          48 /* variation slot 7 */
#define epdso_v8          49 /* variation slot 8 */
#define epdso_v9          50 /* variation slot 9 */

/* referee commands */

typedef siT refcomT, *refcomptrT;
#define refcomL 7
#define refcom_nil (-1)

#define refcom_conclude   0
#define refcom_disconnect 1
#define refcom_execute    2
#define refcom_fault      3
#define refcom_inform     4
#define refcom_respond    5
#define refcom_reset      6

/* referee requests */

typedef siT refreqT, *refreqptrT;
#define refreqL 4
#define refreq_nil (-1)

#define refreq_fault    0
#define refreq_reply    1
#define refreq_sign_on  2
#define refreq_sign_off 3

/* referee interface procedure type */

typedef epdptrT (*refintptrT)(epdptrT epdptr, siptrT flagptr);

/* environment stack entry record type */

typedef struct eseS
	{
	cT    ese_actc;      /* active color */
	castT ese_cast;      /* castling availability */
	sqT   ese_epsq;      /* en passant target square */
	siT   ese_hmvc;      /* halfmove clock */
	siT   ese_fmvn;      /* fullmove number */
	sqT   ese_ksqv[rcL]; /* king square locations */
	} eseT, *eseptrT;

/* game played move record type (entries are prior to move) */

typedef struct gpmS
	{
	mT           gpm_m;    /* the move to be played */
	eseT         gpm_ese;  /* environment statck entry storage */
	nbvT         gpm_nbv;  /* nybble board vector */
	struct gpmS *gpm_prev; /* previous played move record */
	struct gpmS *gpm_next; /* next played move record */
	} gpmT, *gpmptrT;

/* game record type */

typedef struct gamS
	{
	charptrT     gam_strv[pgnstrL]; /* PGN STR tag values */
	gtimT        gam_gtim;          /* game termination indicator */
	gpmptrT      gam_headgpm;       /* head of game played move list */
	gpmptrT      gam_tailgpm;       /* tail of game played move list */
	struct gamS *gam_prev;          /* previous game */
	struct gamS *gam_next;          /* next game */
	} gamT, *gamptrT;

/* benchmark score structure */

typedef struct bmsS
	{
	siT bms_acdflag;   /* ACD (depth) data valid flag */
	siT bms_acnflag;   /* ACN (nodes) data valid flag */
	siT bms_acsflag;   /* ACS (seconds) data valid flag */
	liT bms_total;     /* total record count */
	liT bms_solve;     /* solved record count */
	liT bms_unsol;     /* unsolved record count */
	liT bms_total_acd; /* ACD used, all records */
	liT bms_solve_acd; /* ACD used, solved records */
	liT bms_unsol_acd; /* ACD used, unsolved records */
	liT bms_total_acn; /* ACN used, all records */
	liT bms_solve_acn; /* ACN used, solved records */
	liT bms_unsol_acn; /* ACN used, unsolved records */
	liT bms_total_acs; /* ACS used, all records */
	liT bms_solve_acs; /* ACS used, solved records */
	liT bms_unsol_acs; /* ACS used, unsolved records */
	} bmsT, *bmsptrT;

/*<<< epddefs.h: EOF */
