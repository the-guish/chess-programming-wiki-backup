/*>>> pawn.c: pawn structure evaluation and hash processing */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "bb.h"
#include "memutil.h"
#include "pawn.h"
#include "util.h"

/**** Locals */

/* pawn hash table length */

#define pawnhashQ 13
#define pawnhashL ((liT) (((liT) bit) << pawnhashQ))
#define pawnhashM ((liT) (pawnhashL - 1L))

/* the pawn hash table entry type */

typedef struct pheS
	{
	xhscT	phe_phsc; /* board signature */
	siT		phe_flag; /* the in-use indicator */
	mpevT	phe_mpev; /* millipawn score (White active, negate if Black) */
	} pheT, *pheptrT;

/* macro for calculating a pawn hash xor record address */

#define phxpoint(c, sq) (phxp_base + (((c) << sqQ) + (sq)))

/* scan mode position evaluation factors (millipawn units) */

#define pef_p_supported    32
#define pef_p_phalanx      16
#define pef_p_doubled      (-80)
#define pef_p_isolated     (-200)
#define pef_p_majority     16
#define pef_p_semibackward (-40)
#define pef_p_fullbackward (-80)

/**** Statics */

/* pawn hash table storage base pointer */

static pheptrT phe_base;

/* pawn hash table exclusive-or record storage for color/square codes */

static hxptrT phxp_base;

/*--> PawnTTReset: clear entire pawn hash table */
nonstatic
void
PawnTTReset(void)
{
liT i;
pheptrT pheptr;

pheptr = phe_base;
for (i = 0; i < pawnhashL; i++)
	{
	pheptr->phe_phsc = 0;
	pheptr->phe_flag = 0;
	pheptr->phe_mpev = cpev_bust;
	pheptr++;
	};

return;
}

/*--> PawnTTInit: one time pawn hash table initialization */
nonstatic
void
PawnTTInit(void)
{
hxptrT hxptr;
cT c;
sqT sq;

/* allocate and clear pawn hash entry storage */

phe_base = (pheptrT) MemoryGrab(sizeof(pheT) * pawnhashL);
PawnTTReset();

/* allocate pawn hash color/square xor data */

phxp_base = (hxptrT) MemoryGrab(sizeof(hxT) * rcL * sqL);

/* initialize (constant) color/square pawn hash xor data */

for (c = c_w; c <= c_b; c++)
	for (sq = sq_a1; sq <= sq_h8; sq++)
		{
		hxptr = phxpoint(c, sq);
		hxptr->hx_hac = PsuedoRandomLongWord();
		hxptr->hx_hsc = PsuedoRandomLongWord();
		};

return;
}

/*--> PawnTTTerm: one time pawn hash table termination */
nonstatic
void
PawnTTTerm(void)
{
/* release pawn hash entry and xor storage */

MemoryFree(phe_base);
MemoryFree(phxp_base);

return;
}

/*--> PawnTTWhiteSingleton: update index/signature for a white pawn */
nonstatic
void
PawnTTWhiteSingleton(sqT sq)
{
hxptrT hxptr;

/* important: sq_a1 <= sq <= sq_h8 */

hxptr = phxpoint(c_w, sq);
envn.envn_phac ^= hxptr->hx_hac;
envn.envn_phsc ^= hxptr->hx_hsc;

return;
}

/*--> PawnTTBlackSingleton: update index/signature for a black pawn */
nonstatic
void
PawnTTBlackSingleton(sqT sq)
{
hxptrT hxptr;

/* important: sq_a1 <= sq <= sq_h8 */

hxptr = phxpoint(c_b, sq);
envn.envn_phac ^= hxptr->hx_hac;
envn.envn_phsc ^= hxptr->hx_hsc;

return;
}

/*--> PawnTTCreate: set the pawn hash entries in environment variable */
nonstatic
void
PawnTTCreate(void)
{
sqT sq;
cpT cp;

/* clear the pawn hash index/position signatures */

envn.envn_phac = 0;
envn.envn_phsc = 0;

/* create the pawn index position signatures from the local board */

for (sq = sq_a1; sq <= sq_h8; sq++)
	if (cv_p_cpv[cp = local.rbv[sq]] == p_p)
		if (cp == cp_wp)
			PawnTTWhiteSingleton(sq);
		else
			PawnTTBlackSingleton(sq);

return;
}

/*--> PawnTTEvaluateWhiteSingleton: calculate hash score for white pawn */
static
mpevT
PawnTTEvaluateWhiteSingleton(sqT sq)
{
mpevT mpev;
rankT rank;
fileT file;
sqT pawnsq;
bbT bb_w, bb_b;
siT wpc, bpc;

/* fetch rank and file */

rank = map_rank(sq);
file = map_file(sq);

/* initialize result as general advancement */

mpev = gpaibv[c_w].sibv[sq];

/* supported */

if (bb_tstand(atbbv[sq], cpbbv[cp_wp]))
	mpev += pef_p_supported;

/* phalanxed */

if (bb_tstand(pxbbv[sq], cpbbv[cp_wp]))
	mpev += pef_p_phalanx;

/* doubled */

if (bb_tstand(ptbbv[c_w][sq], cpbbv[cp_wp]))
	mpev += pef_p_doubled;

/* isolated */

if (bb_tstnotand(fabbv[file], cpbbv[cp_wp]))
	mpev += pef_p_isolated;

/* majority advancement */

bb_and3(ftbbv[file], cpbbv[cp_wp], bb_w);
bb_and3(ftbbv[file], cpbbv[cp_bp], bb_b);
if (bb_count(bb_w) > bb_count(bb_b))
	mpev += (rank - rank_2) * pef_p_majority;

/* backwardness */

if (bb_tstnotand(pabbv[c_b][sq], cpbbv[cp_wp]))
	{
	pawnsq = sq + dv_1;
	bb_and3(pcbbv[c_w][pawnsq], cpbbv[cp_bp], bb_b);
	if ((bpc = bb_count(bb_b)) > 0)
		{
		bb_and3(pcbbv[c_b][pawnsq], cpbbv[cp_wp], bb_w);
		if (bpc > (wpc = bb_count(bb_w)))
			if (bpc == (wpc + 1))
				mpev += pef_p_semibackward;
			else
				mpev += pef_p_fullbackward;
		};
	};

return (mpev);
}

/*--> PawnTTEvaluateBlackSingleton: calculate hash score for black pawn */
static
mpevT
PawnTTEvaluateBlackSingleton(sqT sq)
{
mpevT mpev;
rankT rank;
fileT file;
sqT pawnsq;
bbT bb_w, bb_b;
siT wpc, bpc;

/* fetch rank and file */

rank = map_rank(sq);
file = map_file(sq);

/* initialize result as general advancement */

mpev = gpaibv[c_b].sibv[sq];

/* supported */

if (bb_tstand(atbbv[sq], cpbbv[cp_bp]))
	mpev += pef_p_supported;

/* phalanxed */

if (bb_tstand(pxbbv[sq], cpbbv[cp_bp]))
	mpev += pef_p_phalanx;

/* doubled */

if (bb_tstand(ptbbv[c_b][sq], cpbbv[cp_bp]))
	mpev += pef_p_doubled;

/* isolated */

if (bb_tstnotand(fabbv[file], cpbbv[cp_bp]))
	mpev += pef_p_isolated;

/* majority advancement */

bb_and3(ftbbv[file], cpbbv[cp_bp], bb_b);
bb_and3(ftbbv[file], cpbbv[cp_wp], bb_w);
if (bb_count(bb_b) > bb_count(bb_w))
	mpev += (rank_7 - rank) * pef_p_majority;

/* backwardness */

if (bb_tstnotand(pabbv[c_w][sq], cpbbv[cp_bp]))
	{
	pawnsq = sq + dv_3;
	bb_and3(pcbbv[c_b][pawnsq], cpbbv[cp_wp], bb_w);
	if ((wpc = bb_count(bb_w)) > 0)
		{
		bb_and3(pcbbv[c_w][pawnsq], cpbbv[cp_bp], bb_b);
		if (wpc > (bpc = bb_count(bb_b)))
			if (wpc == (bpc + 1))
				mpev += pef_p_semibackward;
			else
				mpev += pef_p_fullbackward;
		};
	};

return (mpev);
}

/*--> PawnTTEvaluateStructure: calculate hash score for pawn structure */
static
mpevT
PawnTTEvaluateStructure(void)
{
mpevT mpev;
sqT sq;

/* note: the evaluation is taken from the White's view */

mpev = 0;

gp_bb = cpbbv[cp_wp];
while (bb_next_gp(sq))
	mpev += PawnTTEvaluateWhiteSingleton(sq);

gp_bb = cpbbv[cp_bp];
while (bb_next_gp(sq))
	mpev -= PawnTTEvaluateBlackSingleton(sq);

return (mpev);
}

/*--> PawnTTFetchEvaluation: fetch/calc/stash score for pawn structure */
nonstatic
mpevT
PawnTTFetchEvaluation(void)
{
mpevT mpev;
pheptrT pheptr;

/* calculate the address of the appropriate entry */

pheptr = phe_base + (envn.envn_phac & pawnhashM);

/* check for a matching entry */

if ((pheptr->phe_phsc == envn.envn_phsc) && pheptr->phe_flag)
	{
	/* valid entry located, return score according to active color */

	if (actc == c_w)
		mpev = pheptr->phe_mpev;
	else
		mpev = -(pheptr->phe_mpev);
	}
else
	{
	/* no pre-calculated entry, set the pawn hash entry */

	pheptr->phe_flag = 1;
	pheptr->phe_phsc = envn.envn_phsc;

	/* store White's score */

	pheptr->phe_mpev = mpev = PawnTTEvaluateStructure();

	/* set the return value according to active color */

	if (actc != c_w)
		mpev = -mpev;
	};

return (mpev);
}

/*<<< pawn.c: EOF */
