/*>>> cpmb.c: command processor: multibook  */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"

#include "commdefs.h"
#include "commvars.h"

#include "cpmb.h"
#include "hic.h"
#include "memutil.h"
#include "print.h"

/*--> CPMBInit: one time initialization for multibook command processing */
nonstatic
void
CPMBInit(void)
{

return;
}

/*--> CPMBTerm: one time termination for multibook command processing */
nonstatic
void
CPMBTerm(void)
{

return;
}

/*--> CPMBCommand: main entry for interactive command processing */
nonstatic
void
CPMBCommand(void)
{
siT flag;
siT done;
liptrT lcptr;
siT i, count;

done = 0;

if (!done && (strcmp(ipv[1].ip_str, "dgen") == 0))
	{
	if (tkn != 3)
		PrErr("usage: cpmb dgen <basename>");
	else
		{
		flag = HICGen(ipv[2].ip_str);
		if (!flag)
			PrErr("HIC generation problem encountered");
		};
	done = 1;
	};

if (!done && (strcmp(ipv[1].ip_str, "dvbm") == 0))
	{
	lcptr = HICProbe();
	if (lcptr != NULL)
		{
		count = root_sptr->s_count;
		for (i = 0; i < count; i++)
			if (*(lcptr + i) > 0)
				{
				PrStrSI("CMO: ", i);
				PrStrLINL("   Count: ", *(lcptr + i));
				};
		MemoryFree(lcptr);
		};
	done = 1;
	};

if (!done && (strcmp(ipv[1].ip_str, "help") == 0))
	{
	PrLine("Multibook command list");
	PrLine("  dgen <basename>   Generate HIC from HXS");
	PrLine("  dvbm              Display value: book moves");
	PrLine("  help              Print this list");
	PrLine("  test              Perform test");
	done = 1;
	};

if (!done && (strcmp(ipv[1].ip_str, "test") == 0))
	{
	PrErr("Not yet implemented");
	done = 1;
	};

if (!done)
	PrErr("Unknown multibook command");

return;
}

/*<<< cpmb.c: EOF */
