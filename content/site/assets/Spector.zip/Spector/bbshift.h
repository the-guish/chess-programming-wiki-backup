/*>>> bbshift.h: subprogram prototypes for bbshift.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void BitBoardShift(bbptrT ptr, dxT dx);

/*<<< bbshift.h: EOF */
