/*>>> vpdefs.h: viewport definitions */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* console span */

#define cspan_xL 80
#define cspan_yL 25

#define cspan_xyL (cspan_xL * cspan_yL)

/* two dimensional short integer point */

typedef struct sipS
	{
	siT sip_x; /* column */
	siT sip_y; /* row */
	} sipT, *sipptrT;

/* two dimensional short integer quantity */

typedef struct siqS
	{
	siT siq_x; /* horizontal */
	siT siq_y; /* vertical */
	} siqT, *siqptrT;

/* short integer rectangle */

typedef struct sirS
	{
	sipT sir_sip; /* base */
	siqT sir_siq; /* span */
	} sirT, *sirptrT;

/* character viewport attribute type */

typedef byteT vcaT, *vcaptrT;

#define make_vca(bold, flash, bgc, fgc) \
	(((bold) << 7) | ((flash) << 6) | ((bgc) << 3) | (fgc))

#define extract_bold(vca)  (((vca) >> 7) & 0x01)
#define extract_flash(vca)  (((vca) >> 6) & 0x01)
#define extract_bgc(vca)  (((vca) >> 3) & 0x07)
#define extract_fgc(vca)  ((vca) & 0x07)

/* character viewport flags */

#define cvpf_b0 (bit << 0) /* border 0 (upper) */
#define cvpf_b1 (bit << 1) /* border 1 (left) */
#define cvpf_b2 (bit << 2) /* border 2 (lower) */
#define cvpf_b3 (bit << 3) /* border 3 (right) */
#define cvpf_rd (bit << 4) /* redisplay required (external) */
#define cvpf_rg (bit << 5) /* regeneration required (internal) */

/* character viewport type */

typedef struct cvpS
	{
	charptrT     cvp_label;  /* label string */
	siT          cvp_flags;  /* flags ; uses -cvpf- bits */
	sirT         cvp_sir;    /* rectangle (data port position and size) */
	charptrT     cvp_cptr;   /* allocated storage base: character data */
	vcaptrT      cvp_aptr;   /* allocated storage base: attribute data */
	struct cvpS *cvp_prev;   /* previous viewport */
	struct cvpS *cvp_next;   /* next viewport */
	} cvpT, *cvpptrT;

/* window names */

typedef siT winidT;
#define winidL 9

#define winid_nil (-1)

#define winid_board   0 /* chessboard */
#define winid_clock   1 /* chess clock */
#define winid_command 2 /* command input */
#define winid_general 3 /* general output */
#define winid_logo    4 /* logograph */
#define winid_predvar 5 /* predicted variation */
#define winid_search  6 /* search status */
#define winid_status  7 /* general status */
#define winid_time    8 /* time */

/* window actions */

typedef siT winacT;
#define winacL 5

#define winac_nil (-1)

#define winac_init   0 /* one time initialization */
#define winac_copy   1 /* copy data global to local */
#define winac_redraw 2 /* redraw viewport */
#define winac_regen  3 /* regenerate viewport from local data */
#define winac_term   4 /* one time initialization */

/*<<< vpdefs.h: EOF */
