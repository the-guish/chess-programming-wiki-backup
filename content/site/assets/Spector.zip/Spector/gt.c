/*>>> gt.c: game termination codes routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "clock.h"
#include "gt.h"
#include "stat.h"
#include "sysutil.h"

/*--> GTMatchGTIM: match string as a game termination imput marker */
nonstatic
gtimT
GTMatchGTIM(charptrT s)
{
gtimT gtim;
siT flag;

if (strlen(s) == 0)
	gtim = gtim_nil;
else
	{
	flag = 0;
	gtim = 0;
	while (!flag && (gtim < gtimL))
		{
		if (strcmp(s, gtimstrv[gtim]) == 0)
			flag = 1;
		else
			gtim++;
		};
	if (!flag)
		gtim = gtim_nil;
	};

return (gtim);
}

/*--> GTCDetermine: check if new gtc available from input gtim */
nonstatic
gtcT
GTCDetermine(gtimT gtim)
{
gtcT new_gtc;

if (gtim == gtim_nil)
	new_gtc = gtc_nil;
else
	{
	new_gtc = cv_gtc_gtimv[gtim];
	if (new_gtc == gtc_nil)
		switch (gtim)
			{
			case gtim_res0:
			case gtim_res1:
				if (actc == c_w)
					new_gtc = gtc_bwin;
				else
					new_gtc = gtc_wwin;
				break;

			default:
				SwitchFault("GTCDetermine");
				break;
			};
	};

return (new_gtc);
}

/*--> GTCConsistent: check if new gtc is consistent with environment */
nonstatic
siT
GTCConsistent(gtcT new_gtc)
{
siT flag;
gsT gs;

flag = 0;
gs = GameStatus(root_sptr);
switch (new_gtc)
	{
	case gtc_none:
		flag = (gs == gs_norm) ||
			(gs == gs_wres) || (gs == gs_bres) || (gs == gs_adrw);
		break;

	case gtc_draw:
		switch (gs)
			{
			case gs_norm:
			case gs_wksm:
			case gs_bksm:
			case gs_hmvc:
			case gs_rep3:
			case gs_imat:
			case gs_adrw:
			case gs_over:
				flag = 1;
				break;

			default:
				flag = 0;
				break;
			};
		break;

	case gtc_wwin:
		flag = (((gs == gs_norm) && (actc == c_b)) || (gs == gs_bkcm));
		break;

	case gtc_bwin:
		flag = (((gs == gs_norm) && (actc == c_w)) || (gs == gs_wkcm));
		break;

	default:
		SwitchFault("GTCConsistent");
		break;
	};

return (flag);
}

/*--> GTCSet: set the new game termination code */
nonstatic
void
GTCSet(gtcT new_gtc)
{
gtc = new_gtc;
if (gtc != gtc_none)
	ClockStop();

return;
}

/*--> GTCAutoSet: check and automatically set a new game termination code */
nonstatic
void
GTCAutoSet(void)
{
gsT gs;

if (gtc == gtc_none)
	{
	gs = GameStatus(root_sptr);
	if (gs != gs_norm)
		switch(gs)
			{
			case gs_bust:
				GTCSet(gtc_none);
				break;

			case gs_wksm:
			case gs_bksm:
			case gs_hmvc:
			case gs_rep3:
			case gs_imat:
			case gs_over:
				GTCSet(gtc_draw);
				break;

			case gs_wkcm:
				GTCSet(gtc_bwin);
				break;

			case gs_bkcm:
				GTCSet(gtc_wwin);
				break;

			default:
				SwitchFault("GTCAutoSet");
				break;
			};
	};

return;
}

/*<<< gt.c: EOF */
