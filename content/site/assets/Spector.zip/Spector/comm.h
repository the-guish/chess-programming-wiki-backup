/*>>> comm.h: subprogram prototypes for comm.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CommDuplex(void);

/*<<< comm.h: EOF */
