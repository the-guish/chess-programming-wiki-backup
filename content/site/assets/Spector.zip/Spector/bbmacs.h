/*>>> bbmacs.h: bitboard macro definitions */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* bitboard inline functions */

#define bb_clr(bb) \
    { bb.bbsv[0] = bb.bbsv[1] = 0x00000000L; }
#define bb_set(bb) \
    { bb.bbsv[0] = bb.bbsv[1] = 0xffffffffL; }
#define bb_invert(bb) \
    { bb.bbsv[0] = ~bb.bbsv[0]; bb.bbsv[1] = ~bb.bbsv[1]; }

#define bb_tst(bb) \
    (bb.bbsv[0] || bb.bbsv[1])
#define bb_tstnot(bb) \
    (!bb.bbsv[0] && !bb.bbsv[1])

#define bb_equal(bb0, bb1) \
    ((bb0.bbsv[0] == bb1.bbsv[0]) && (bb0.bbsv[1] == bb1.bbsv[1]))

#define bb_complement(bb0, bb1) \
    { bb1.bbsv[0] = ~bb0.bbsv[0]; bb1.bbsv[1] = ~bb0.bbsv[1]; }

#define bb_and2(bb0, bb1) \
    { bb1.bbsv[0] &= bb0.bbsv[0]; bb1.bbsv[1] &= bb0.bbsv[1]; }
#define bb_ior2(bb0, bb1) \
    { bb1.bbsv[0] |= bb0.bbsv[0]; bb1.bbsv[1] |= bb0.bbsv[1]; }
#define bb_xor2(bb0, bb1) \
    { bb1.bbsv[0] ^= bb0.bbsv[0]; bb1.bbsv[1] ^= bb0.bbsv[1]; }
#define bb_mask2(bb0, bb1) \
    { bb1.bbsv[0] &= ~bb0.bbsv[0]; bb1.bbsv[1] &= ~bb0.bbsv[1]; }

#define bb_tstand(bb0, bb1) \
    ((bb0.bbsv[0] & bb1.bbsv[0]) || (bb0.bbsv[1] & bb1.bbsv[1]))
#define bb_tstior(bb0, bb1) \
    (bb_tst(bb0) || bb_tst(bb1))
#define bb_tstxor(bb0, bb1) \
    ((bb0.bbsv[0] ^ bb1.bbsv[0]) || (bb0.bbsv[1] ^ bb1.bbsv[1]))

#define bb_tstnotand(bb0, bb1) \
    (!(bb0.bbsv[0] & bb1.bbsv[0]) && !(bb0.bbsv[1] & bb1.bbsv[1]))

#define bb_tstmask(bb0, bb1) \
    ((~bb0.bbsv[0] & bb1.bbsv[0]) || (~bb0.bbsv[1] & bb1.bbsv[1]))
#define bb_tstnotmask(bb0, bb1) \
    (!(~bb0.bbsv[0] & bb1.bbsv[0]) && !(~bb0.bbsv[1] & bb1.bbsv[1]))

#define bb_and3(bb0, bb1, bb2) \
    { bb2.bbsv[0] = bb0.bbsv[0] & bb1.bbsv[0]; \
    bb2.bbsv[1] = bb0.bbsv[1] & bb1.bbsv[1]; }
#define bb_ior3(bb0, bb1, bb2) \
    { bb2.bbsv[0] = bb0.bbsv[0] | bb1.bbsv[0]; \
    bb2.bbsv[1] = bb0.bbsv[1] | bb1.bbsv[1]; }
#define bb_xor3(bb0, bb1, bb2) \
    { bb2.bbsv[0] = bb0.bbsv[0] ^ bb1.bbsv[0]; \
    bb2.bbsv[1] = bb0.bbsv[1] ^ bb1.bbsv[1]; }
#define bb_mask3(bb0, bb1, bb2) \
    { bb2.bbsv[0] = (~bb0.bbsv[0]) & bb1.bbsv[0]; \
    bb2.bbsv[1] = (~bb0.bbsv[1]) & bb1.bbsv[1]; }

#define bb_and4(bb0, bb1, bb2, bb3) \
    { bb3.bbsv[0] = bb0.bbsv[0] & bb1.bbsv[0] & bb2.bbsv[0]; \
    bb3.bbsv[1] = bb0.bbsv[1] & bb1.bbsv[1] & bb2.bbsv[1]; }
#define bb_ior4(bb0, bb1, bb2, bb3) \
    { bb3.bbsv[0] = bb0.bbsv[0] | bb1.bbsv[0] | bb2.bbsv[0]; \
    bb3.bbsv[1] = bb0.bbsv[1] | bb1.bbsv[1] | bb2.bbsv[1]; }
#define bb_xor4(bb0, bb1, bb2, bb3) \
    { bb3.bbsv[0] = bb0.bbsv[0] ^ bb1.bbsv[0] ^ bb2.bbsv[0]; \
    bb3.bbsv[1] = bb0.bbsv[1] ^ bb1.bbsv[1] ^ bb2.bbsv[1]; }

#define bb_clrsq(bb, sq) \
    bb.bbcv[map_rank(sq)] &= ~(bit << map_file(sq))
#define bb_setsq(bb, sq) \
    bb.bbcv[map_rank(sq)] |= (bit << map_file(sq))
#define bb_notsq(bb, sq) \
    bb.bbcv[map_rank(sq)] ^= (bit << map_file(sq))

#define bb_tstsq(bb, sq) \
    (bb.bbcv[map_rank(sq)] & (bit << map_file(sq)))
#define bb_tstnotsq(bb, sq) \
    ((~bb.bbcv[map_rank(sq)]) & (bit << map_file(sq)))

#define bb_clrsqrf(bb, rank, file) \
    bb.bbcv[rank] &= ~(bit << (file))
#define bb_setsqrf(bb, rank, file) \
    bb.bbcv[rank] |= (bit << (file))
#define bb_notsqrf(bb, rank, file) \
    bb.bbcv[rank] ^= (bit << (file))

#define bb_tstsqrf(bb, rank, file) \
    (bb.bbcv[rank] & (bit << (file)))
#define bb_tstnotsqrf(bb, rank, file) \
    ((~bb.bbcv[rank]) & (bit << (file)))

#define bb_count(bb) \
    (*(bevbase + bb.bbwv[0]) + *(bevbase + bb.bbwv[1]) + \
        *(bevbase + bb.bbwv[2]) + *(bevbase + bb.bbwv[3]))

#define bb_count_gp()       bb_count(gp_bb)

#define bb_next(bb, sq) \
    (bb.bbsv[0] ? \
        (bb.bbwv[0] ? \
            ((bb.bbwv[0] &= canwv[sq = *(bfvbase + bb.bbwv[0])]), \
                (sq += sq_a1), 1) \
        : \
            ((bb.bbwv[1] &= canwv[sq = *(bfvbase + bb.bbwv[1])]), \
                (sq += sq_a3), 1)) \
    : \
        (bb.bbsv[1] ? \
            (bb.bbwv[2] ? \
                ((bb.bbwv[2] &= canwv[sq = *(bfvbase + bb.bbwv[2])]), \
                    (sq += sq_a5), 1) \
            : \
                ((bb.bbwv[3] &= canwv[sq = *(bfvbase + bb.bbwv[3])]), \
                    (sq += sq_a7), 1)) \
        : \
            ((sq = sq_nil), 0)))

#define bb_next_gp(sq)  bb_next(gp_bb, sq)

#define bb_next_gpa(sq) bb_next(gp_abb, sq)

#define bb_once(bb) \
    (bb.bbsv[0] ? \
        (bb.bbwv[0] ? \
            (sq_a1 + *(bfvbase + bb.bbwv[0])) \
        : \
            (sq_a3 + *(bfvbase + bb.bbwv[1]))) \
    : \
        (bb.bbwv[2] ? \
            (sq_a5 + *(bfvbase + bb.bbwv[2])) \
        : \
            (sq_a7 + *(bfvbase + bb.bbwv[3]))))

#define bb_once_gp()        bb_once(gp_bb)

/*<<< bbmacs.h: EOF */
