/*>>> bb.c: bitboard manipulation */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "bb.h"

/*--> BitBoardSubset: test first bitboard to be a subset of the second */
nonstatic
siT
BitBoardSubset(bbT bb0, bbT bb1)
{
siT flag;

if (((bb0.bbsv[0] & bb1.bbsv[0]) == bb0.bbsv[0]) &&
	((bb0.bbsv[1] & bb1.bbsv[1]) == bb0.bbsv[1]))
	flag = 1;
else
	flag = 0;

return (flag);
}

/*--> BitBoardOnceRef: only square (must have one) */
nonstatic
sqT
BitBoardOnceRef(bbptrT bbptr)
{
sqT sq;
bbT bb;

bb = *bbptr;

if (bb.bbsv[0])
	if (bb.bbwv[0])
		sq = sq_a1 + *(bfvbase + bb.bbwv[0]);
	else
		sq = sq_a3 + *(bfvbase + bb.bbwv[1]);
else
	if (bb.bbwv[2])
		sq = sq_a5 + *(bfvbase + bb.bbwv[2]);
	else
		sq = sq_a7 + *(bfvbase + bb.bbwv[3]);

return (sq);
}

/*--> BitBoardNthRef: find the Nth (zero origin) true square */
nonstatic
sqT
BitBoardNthRef(siT n, bbptrT bbptr)
{
sqT sq, rsq;
siT i;
bbT bb;

sq = sq_nil;
bb = *bbptr;

if (bb_tst(bb))
	{
	/* note scanning order */

	rsq = sq_a1;
	i = 0;
	while ((sq == sq_nil) && (rsq <= sq_h8))
		{
		if (bb_tstsq(bb, rsq))
			if (i == n)
				sq = rsq;
			else
				i++;
		rsq++;
		};
	};

return (sq);
}

/*--> MinValueSq: return square of minimal piece (nonvacant only) */
nonstatic
sqT
MinValueSq(bbT bb)
{
pT p0, p1;
sqT sq0, sq1;

/* copy bitboard to global parameter */

gp_bb = bb;

/* locate first square of interest (input has only nonvacant squares) */

bb_next_gp(sq0);
p0 = cv_p_cpv[local.rbv[sq0]];

/* scan */

while ((p0 > p_p) && bb_next_gp(sq1))
	if ((p1 = cv_p_cpv[local.rbv[sq1]]) < p0)
		{
		p0 = p1;
		sq0 = sq1;
		};

return (sq0);
}

/*--> MinValueSqGP: return square of minimal piece (nonvacant gp_bb) */
nonstatic
sqT
MinValueSqGP(void)
{
pT p0, p1;
sqT sq0, sq1;

/* locate first square of interest (input has only nonvacant squares) */

bb_next_gp(sq0);
p0 = cv_p_cpv[local.rbv[sq0]];

/* scan */

while ((p0 > p_p) && bb_next_gp(sq1))
	if ((p1 = cv_p_cpv[local.rbv[sq1]]) < p0)
		{
		p0 = p1;
		sq0 = sq1;
		};

return (sq0);
}

/*--> MaxValueSq: return square of maximal piece (nonvacant only) */
nonstatic
sqT
MaxValueSq(bbT bb)
{
pT p0, p1;
sqT sq0, sq1;

/* copy bitboard to global parameter */

gp_bb = bb;

/* locate first square of interest (input has only nonvacant squares) */

bb_next_gp(sq0);
p0 = cv_p_cpv[local.rbv[sq0]];

/* scan */

while ((p0 < p_k) && bb_next_gp(sq1))
	if ((p1 = cv_p_cpv[local.rbv[sq1]]) > p0)
		{
		p0 = p1;
		sq0 = sq1;
		};

return (sq0);
}

/*--> MaxValueSqGP: return square of maximal piece (nonvacant gp_bb) */
nonstatic
sqT
MaxValueSqGP(void)
{
pT p0, p1;
sqT sq0, sq1;

/* locate first square of interest (input has only nonvacant squares) */

bb_next_gp(sq0);
p0 = cv_p_cpv[local.rbv[sq0]];

/* scan */

while ((p0 < p_k) && bb_next_gp(sq1))
	if ((p1 = cv_p_cpv[local.rbv[sq1]]) > p0)
		{
		p0 = p1;
		sq0 = sq1;
		};

return (sq0);
}

/*<<< bb.c: EOF */
