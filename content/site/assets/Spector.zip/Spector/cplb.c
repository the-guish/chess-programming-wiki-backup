/*>>> cplb.c: command processor for legacy book */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"

#include "commdefs.h"
#include "commvars.h"

#include "bookdefs.h"

#include "bookcomp.h"
#include "bookpack.h"
#include "bookutil.h"
#include "cplb.h"
#include "print.h"
#include "stat.h"
#include "util.h"

/*--> CPLBCommand: handle command token line from main command input */
nonstatic
void
CPLBCommand(void)
{
siT flag, done;
charptrT fn_bkfsrc, fn_bkfdst, fn_bkfcor, fn_bkfmpl, fn_bkfepd;
charptrT fn_bkftxt;
siT i, count;
obcptrT obcptr;
mptrT mptr;
liT total;

flag = 1;
done = 0;

/* process: cobt */

if (!done && (strcmp(ipv[1].ip_str, "cobt") == 0))
	{
	if (tkn != 7)
		{
		PrErr("usage: cplb cobt <it> <oc> <ot> <op> <pt>");
		flag = 0;
		}
	else
		{
		/* input source text file */

		fn_bkfsrc = ipv[2].ip_str;

		/* output destination code file */

		fn_bkfdst = ipv[3].ip_str;

		/* output corrected text file */

		fn_bkfcor = ipv[4].ip_str;

		/* output corrected move path list file */

		fn_bkfmpl = ipv[5].ip_str;

		/* output expanded position description list file */

		fn_bkfepd = ipv[6].ip_str;

		/* process book compilation */

		if (!ListBookTextComp(
			fn_bkfsrc, fn_bkfdst, fn_bkfcor, fn_bkfmpl, fn_bkfepd))
			{
			PrErr("Can't compile opening book text file");
			flag = 0;
			};
		};
	done = 1;
	};

/* process: dvbm */

if (!done && (strcmp(ipv[1].ip_str, "dvbm") == 0))
	{
	if (tkn != 2)
		{
		PrErr("usage: cplb dvbm");
		flag = 0;
		}
	else
		{
		if (!GameStatusNormal(root_sptr))
			PrErr("No moves");
		else
			{
			/* allocate the census vector storage */

			count = root_sptr->s_count;
			obcptr = ListBookNewOBC(root_sptr);
			(void) ListBookAutoCensus(obcptr);
			mptr = root_sptr->s_mbase;
			total = 0;
			for (i = 0; i < count; i++)
				total += (obcptr + i)->obc_count;
			for (i = 0; i < count; i++)
				{
				if ((obcptr + i)->obc_count > 0)
					{
					PrStr("Book move: ");
					PrPaddedSAN(mptr);
					PrStr(" [");
					if ((obcptr + i)->obc_pflag)
						PrStr("poor");
					else
						PrStr("okay");
					PrStr("]");
					PrStr("   ratio: ");
					FormatSTVLQR((obcptr + i)->obc_count, total);
					PrSTV();
					PrStr("   subtree nodes: ");
					PrCondOrdLI((obcptr + i)->obc_count);
					PrNL();
					};
				mptr++;
				};
			PrStr("Total book moves: ");
			PrCondOrdLI(total);
			PrNL();
			ListBookReleaseOBC(obcptr);
			};
		};
	done = 1;
	};

/* process: pobc */

if (!done && (strcmp(ipv[1].ip_str, "pobc") == 0))
	{
	if (tkn != 6)
		{
		PrErr("usage: cplb pobc <it> <oc> <ot> <pt>");
		flag = 0;
		}
	else
		{
		/* input source code file */

		fn_bkfsrc = ipv[2].ip_str;

		/* output destination packed code file */

		fn_bkfdst = ipv[3].ip_str;

		/* output move tree text file */

		fn_bkftxt = ipv[4].ip_str;

		/* output move path list text file */

		fn_bkfmpl = ipv[5].ip_str;

		/* process book packing */

		if (!ListBookPackp(fn_bkfsrc, fn_bkfdst, fn_bkftxt, fn_bkfmpl))
			{
			PrErr("Can't pack opening book code file");
			flag = 0;
			};
		};
	done = 1;
	};

if (!done)
	PrErr("Unknown cplb command");

return;
}

/*<<< cplb.c: EOF */
