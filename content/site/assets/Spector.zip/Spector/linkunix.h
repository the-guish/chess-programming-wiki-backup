/*>>> linkunix.h: subprogram prototypes for linkunix.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT LinkUnixGet(channelT channel, byteptrT bptr, liT length);
siT LinkUnixPut(channelT channel, byteptrT bptr, liT length);
liT LinkUnixStat(channelT channel);
siT LinkUnixOpen(channelT channel);
siT LinkUnixClose(channelT channel);
void LinkUnixInit(void);
void LinkUnixTerm(void);

/*<<< linkunix.h: EOF */
