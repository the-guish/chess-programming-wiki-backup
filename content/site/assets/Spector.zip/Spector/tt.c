/*>>> tt.c: transposition table routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "memutil.h"
#include "mu.h"
#include "print.h"
#include "tt.h"
#include "util.h"

/**** Locals */

/* the transposition table bank (N-way cache) */

#define tt_bankQ 1
#define tt_bankL (bit << tt_bankQ)
#define tt_bankM (tt_bankL - 1)

/* the transposition table default order (log2 total) */

#define default_tt_orderL 16

/* main transposition table entry flags and fields (tte_flag) */

#define ttef_in_use      bit_00 /* entry in use */
#define ttef_score_alpha bit_01 /* lower bound */
#define ttef_score_exact bit_02 /* exact value */
#define ttef_score_beta bit_03 /* upper bound */

/* the score flag field */

#define tteff_score (ttef_score_alpha | ttef_score_exact | ttef_score_beta)

/* the main transposition table entry type */

typedef struct tteS
	{
	xhscT tte_mhsc;  /* board signature */
	usiT  tte_hadr;  /* upper half hash code address */
	tiT   tte_flag;  /* info byte */
	tiT   tte_draft; /* analysis draft  */
	cmT   tte_cm;    /* compressed move */
	cpevT tte_cpev;  /* centipawn score for move */
	} tteT, *tteptrT;

/* macro for calculating a transposition xor record address */

#define ttpoint(cp, sq) (mhxp_base + (((cp) << sqQ) + (sq)))

/* main transposition table storage base pointers for each color/bank */

static tteptrT tte_base[rcL][tt_bankL];

/* main transposition table exclusive-or storage of c-p/square codes */

static hxptrT mhxp_base;

/* main transposition table exclusive-or storage of castling info */

static hxT mhxp_caiv[caiL];

/* main transposition table exclusive-or record storage of ep file info */

static hxT mhxp_eptf[fileL];

/* statistics: move: store, probe, match, and slice counts */

static liT tts_m_store, tts_m_probe, tts_m_match, tts_m_slice;

/* last sucessful table access entry address */

static tteptrT last_tteptr;

/* the table lookup move returned via reference */

mT trans_table_m;

/*--> TTPrintStatistics: print stats about the transposition subsystem */
nonstatic
void
TTPrintStatistics(void)
{
/* process per search statistics */

PrTrace("TT");
(void) sprintf(stv,
	"ST: %ld   PR: %ld   MT: %ld   SL: %ld",
	tts_m_store, tts_m_probe, tts_m_match, tts_m_slice);
PrSTV();
if (tts_m_match != 0)
	{
	PrStr("   MR: ");
	FormatSTVLQR(tts_m_match, tts_m_probe);
	PrSTV();
	if (tts_m_match != 0)
		{
		PrStr("   SR: ");
		FormatSTVLQR(tts_m_slice, tts_m_match);
		PrSTV();
		};
	};
PrNL();

return;
}

/*--> TTResetStatistics: reset stats about the transposition subsystem */
nonstatic
void
TTResetStatistics(void)
{
tts_m_store = tts_m_probe = tts_m_match = tts_m_slice = 0;

return;
}

/*--> TTReportUsage: report entry utilization rate */
nonstatic
void
TTReportUsage(void)
{
liT count;
tteptrT tteptr;
cT c;
siT bank;
liT i;

count = 0;

/* count total used entries */

for (c = c_w; c <= c_b; c++)
	for (bank = 0; bank < tt_bankL; bank++)
		{
		tteptr = tte_base[c][bank];
		for (i = 0; i < tt_hash_span; i++)
			{
			if (tteptr->tte_flag & ttef_in_use)
				count++;
			tteptr++;
			};
		};

PrTrace("TT");
PrStrLI("Main table slot usage: ", count);
PrStr("   coverage: ");
FormatSTVLQR(count, tt_hash_size);
PrSTVNL();

return;
}

/*--> TTReset: reset transposition subsystem (position loading) */
nonstatic
void
TTReset(void)
{
tteptrT tteptr;
cT c;
siT bank;
liT i;
cmT empty_cm;

/* set an empty compressed move */

empty_cm = 0;

/* clear main hash entries for a new loaded position */

for (c = c_w; c <= c_b; c++)
	for (bank = 0; bank < tt_bankL; bank++)
		{
		tteptr = tte_base[c][bank];
		for (i = 0; i < tt_hash_span; i++)
			{
			tteptr->tte_flag = 0;
			tteptr->tte_draft = -plyL;
			tteptr->tte_mhsc = 0;
			tteptr->tte_hadr = 0;
			tteptr->tte_cm = empty_cm;
			tteptr->tte_cpev = cpev_bust;
			tteptr++;
			};
		};

return;
}

/*--> TTSetOrder: reset the transposition table order and resize */
nonstatic
void
TTSetOrder(liT order)
{
cT c;
siT bank;

/* release */

for (c = c_w; c <= c_b; c++)
	for (bank = 0; bank < tt_bankL; bank++)
		if (tte_base[c][bank] != NULL)
			{
			MemoryFree(tte_base[c][bank]);
			tte_base[c][bank] = NULL;
			};

/* set floor */

if (order < (tt_bankQ + rcQ))
	tt_hash_order = tt_bankQ + rcQ;
else
	tt_hash_order = order;

/* calculate */

tt_hash_size = ((liT) bit) << tt_hash_order;
tt_hash_span = ((liT) bit) << (tt_hash_order - (tt_bankQ + rcQ));
tt_hash_mask = tt_hash_span - 1;

/* allocate */

for (c = c_w; c <= c_b; c++)
	for (bank = 0; bank < tt_bankL; bank++)
		tte_base[c][bank] =
			(tteptrT) MemoryGrab(tt_hash_span * sizeof(tteT));

TTReset();

return;
}

/*--> TTPSLong: return a psuedorandom long */
static
liT
TTPSLong(void)
{
liT value;

value = PsuedoRandomLongWord();
if (byte_rev)
	value = ReverseLI(value);

return (value);
}

/*--> TTInit: initialize transposition table subsystem (one time call) */
nonstatic
void
TTInit(void)
{
hxptrT hxptr;
cT c;
siT bank;
cpT cp;
sqT sq;
caiT cai;
fileT file;

/* allocate and clear hash entry storage */

for (c = c_w; c <= c_b; c++)
	for (bank = 0; bank < tt_bankL; bank++)
		tte_base[c][bank] = NULL;

TTSetOrder(default_tt_orderL);

/* allocate hash color-piece/square xor data */

mhxp_base = (hxptrT) MemoryGrab(sizeof(hxT) * rcpL * sqL);

/* initialize (constant) color-piece/square hash xor data */

for (cp = cp_wp; cp <= cp_bk; cp++)
	for (sq = sq_a1; sq <= sq_h8; sq++)
		{
		hxptr = ttpoint(cp, sq);
		hxptr->hx_hac = TTPSLong();
		hxptr->hx_hsc = TTPSLong();
		};

/* initialize (constant) castling availability hash xor data */

for (cai = cai_wk; cai <= cai_bq; cai++)
	{
	mhxp_caiv[cai].hx_hac = TTPSLong();
	mhxp_caiv[cai].hx_hsc = TTPSLong();
	};

/* initialize (constant) en passant target file hash xor data */

for (file = file_a; file <= file_h; file++)
	{
	mhxp_eptf[file].hx_hac = TTPSLong();
	mhxp_eptf[file].hx_hsc = TTPSLong();
	};

/* reset the stat counters */

TTResetStatistics();

return;
}

/*--> TTTerm: terminate transposition table subsystem (called once) */
nonstatic
void
TTTerm(void)
{
cT c;
siT bank;

/* release hash entry storage */

for (c = c_w; c <= c_b; c++)
	for (bank = 0; bank < tt_bankL; bank++)
		MemoryFree(tte_base[c][bank]);

/* release hash xor storage */

MemoryFree(mhxp_base);

return;
}

/*--> TTScrub: scrub pruning information */
nonstatic
void
TTScrub(void)
{
tteptrT tteptr;
cT c;
siT bank;
liT i;

/* adjust flag indicators of main hash entries */

for (c = c_w; c <= c_b; c++)
	for (bank = 0; bank < tt_bankL; bank++)
		{
		tteptr = tte_base[c][bank];
		for (i = 0; i < tt_hash_span; i++)
			{
			if (tteptr->tte_flag & ttef_in_use)
				{
				/* ensure scoring bits cleared */

				tteptr->tte_flag &= ~tteff_score;

				/* reset default for the move draft  */

				tteptr->tte_draft = -plyL;
				};
			tteptr++;
			};
		};

return;
}

/*--> TTColorPieceSq: change single address/signature pair */
nonstatic
void
TTColorPieceSq(cpT cp, sqT sq)
{
hxptrT hxptr;

/* important: cp_wp <= cp <= cp_bk */

hxptr = ttpoint(cp, sq);
envn.envn_mhac ^= hxptr->hx_hac;
envn.envn_mhsc ^= hxptr->hx_hsc;

return;
}

/*--> TTCastlingAvailability: change castling availability */
nonstatic
void
TTCastlingAvailability(caiT cai)
{
envn.envn_mhac ^= mhxp_caiv[cai].hx_hac;
envn.envn_mhsc ^= mhxp_caiv[cai].hx_hsc;

return;
}

/*--> TTEnPassantTargetFile: change en passant target file */
nonstatic
void
TTEnPassantTargetFile(void)
{
hxptrT hxptr;

hxptr = &mhxp_eptf[map_file(envn.envn_epsq)];
envn.envn_mhac ^= hxptr->hx_hac;
envn.envn_mhsc ^= hxptr->hx_hsc;

return;
}

/*--> TTColorPieceSqSq: change two address/signature pairs */
nonstatic
void
TTColorPieceSqSq(cpT cp, sqT sq0, sqT sq1)
{
hxptrT hxptr;

/* important: cp_wp <= cp <= cp_bk */

hxptr = ttpoint(cp, sq0);
envn.envn_mhac ^= hxptr->hx_hac;
envn.envn_mhsc ^= hxptr->hx_hsc;
hxptr = ttpoint(cp, sq1);
envn.envn_mhac ^= hxptr->hx_hac;
envn.envn_mhsc ^= hxptr->hx_hsc;

return;
}

/*--> TTCreate: create transposition subsystem address/signature */
nonstatic
void
TTCreate(void)
{
cpT cp;
sqT sq;
caiT cai;

/* clear the main hash address/position signatures */

envn.envn_mhac = 0;
envn.envn_mhsc = 0;

/* create the main hash address and signature from the local board */

for (sq = sq_a1; sq <= sq_h8; sq++)
	if ((cp = local.rbv[sq]) != cp_v0)
		TTColorPieceSq(cp, sq);

/* fold in castling availability */

for (cai = cai_wk; cai <= cai_bq; cai++)
	if (envn.envn_cast & (bit << cai))
		TTCastlingAvailability(cai);

/* fold in en passant target file */

if (envn.envn_epsq != sq_nil)
	TTEnPassantTargetFile();

return;
}

/*--> TTLocate: return tteptr of current position */
static
tteptrT
TTLocate(void)
{
tteptrT tteptr;
liT offset;
siT flag, bank, bank_modulus, index;

/* calculate the preferred bank */

bank_modulus = ((envn.envn_mhac >> tt_hash_order) & tt_bankM);

/* set up for scan */

flag = 0;
bank = 0;
offset = (envn.envn_mhac & tt_hash_mask);

/* scan */

while (!flag && (bank < tt_bankL))
	{
	/* calculate bank index */

	index = ((bank + bank_modulus) & tt_bankM);

	/* calculate candidate pointer */

	tteptr = tte_base[actc][index] + offset;

	/* test for match */

	if ((tteptr->tte_mhsc == envn.envn_mhsc) &&
		(tteptr->tte_hadr == ((envn.envn_mhac >> wordW) & longwordM)) &&
		(tteptr->tte_flag & ttef_in_use))
		flag = 1;
	else
		bank++;
	};

if (!flag)
	tteptr = NULL;

return (tteptr);
}

/*--> TTReserve: reserve an entry for unlocated current position */
static
tteptrT
TTReserve(void)
{
tteptrT tteptr;
liT offset;
siT flag, bank, bank_modulus, index, draft;
tteptrT mpv[tt_bankL];
siT draftv[tt_bankL];

/* calculate the preferred bank */

bank_modulus = ((envn.envn_mhac >> tt_hash_order) & tt_bankM);

/* set up for vacant/initial scan */

flag = 0;
bank = 0;
offset = (envn.envn_mhac & tt_hash_mask);

/* scan vacant/initial */

while (!flag && (bank < tt_bankL))
	{
	/* calculate bank index */

	index = ((bank + bank_modulus) & tt_bankM);

	/* calculate candidate pointer */

	tteptr = mpv[index] = tte_base[actc][index] + offset;

	/* test for vacant */

	if (!(tteptr->tte_flag & ttef_in_use))
		flag = 1;
	else
		{
		draftv[index] = tteptr->tte_draft;
		bank++;
		};
	};

/* search for a replacement if no vacant slot was found */

if (!flag)
	{
	tteptr = mpv[bank_modulus];
	draft = draftv[bank_modulus];

	bank = 1;
	while (bank < tt_bankL)
		{
		index = ((bank + bank_modulus) & tt_bankM);
		if (draftv[index] < draft)
			{
			tteptr = mpv[index];
			draft = tteptr->tte_draft;
			};
		bank++;
		};
	};

return (tteptr);
}

/*--> TTStashMove: insert best move into transposition table subsystem */
nonstatic
void
TTStashMove(mptrT mptr)
{
tteptrT tteptr;

last_tteptr = NULL;

/* option deactivation */

if (!optnv[optn_nhtm])
	{
	/* increment store count */

	tts_m_store++;

	/* calculate entry addressing pointer */

	tteptr = TTLocate();
	if (tteptr == NULL)
		tteptr = TTReserve();
	last_tteptr = tteptr;

	/* insert common items */

	tteptr->tte_mhsc = envn.envn_mhsc;
	tteptr->tte_hadr = (envn.envn_mhac >> wordW) & longwordM;
	tteptr->tte_flag = ttef_in_use;
	tteptr->tte_draft = iteration - ply;
	tteptr->tte_cm = make_cm(mptr->m_frsq, mptr->m_tosq, mptr->m_scmv);
	tteptr->tte_cpev = cpev_draw;
	};

return;
}

/*--> TTFetchMove: probe transposition table subsystem for simple match */
nonstatic
mptrT
TTFetchMove(void)
{
tteptrT tteptr;
mptrT mptr, exmptr;

last_tteptr = NULL;

/* set default return value */

mptr = NULL;

/* option deactivation */

if (!optnv[optn_nhtm])
	{
	/* increment probe count */

	tts_m_probe++;

	/* test table and move */

	if ((tteptr = TTLocate()) != NULL)
		{
		last_tteptr = tteptr;

		/* increment match count */

		tts_m_match++;

		/* move located, translate and copy */

		if ((exmptr = ExpandCompactMove(tteptr->tte_cm)) == NULL)
			{
			if (optnv[optn_trtt])
				{
				PrTrace("TT");
				PrLine("TTFetchMove: mismatch");
				};
			}
		else
			{
			/* set return result to indicate local static copy */

			mptr = &trans_table_m;

			/* make local static copy of the recovered move */

			trans_table_m = *exmptr;
			};
		};
	};

return (mptr);
}

/*--> TTFetchMoveExact: probe transposition table subsystem for true match */
nonstatic
mptrT
TTFetchMoveExact(void)
{
tteptrT tteptr;
mptrT mptr, exmptr;

/* set default return value */

mptr = NULL;

/* option deactivation */

if (!optnv[optn_nhtm])
	{
	/* increment probe count */

	tts_m_probe++;

	/* test table and move */

	if (((tteptr = TTLocate()) != NULL) &&
		(tteptr->tte_flag & ttef_score_exact))
		{
		/* increment match count */

		tts_m_match++;

		/* true move located, translate and copy */

		if ((exmptr = ExpandCompactMove(tteptr->tte_cm)) == NULL)
			{
			if (optnv[optn_trtt])
				{
				PrTrace("TT");
				PrLine("TTFetchMoveExact: mismatch");
				};
			}
		else
			{
			/* set return result to indicate local static copy */

			mptr = &trans_table_m;

			/* make local static copy of the recovered move */

			trans_table_m = *exmptr;
			};
		};
	};

return (mptr);
}

/*--> TTInsert: insert a scored move */
nonstatic
void
TTInsert(mptrT mptr, cpevT alpha, cpevT beta, cpevT score)
{
/* store the move */

TTStashMove(mptr);

/* store score and bound flag */

if (!ct_mate(score) && !ct_wump(score))
	if (score <= alpha)
		{
		last_tteptr->tte_flag |= ttef_score_alpha;
		last_tteptr->tte_cpev = alpha;
		}
	else
		if (score >= beta)
			{
			last_tteptr->tte_flag |= ttef_score_beta;
			last_tteptr->tte_cpev = beta;
			}
		else
			{
			last_tteptr->tte_flag |= ttef_score_exact;
			last_tteptr->tte_cpev = score;
			};

return;
}

/*--> TTExtract: extract a scored move */
nonstatic
mptrT
TTExtract(cpevptrT alphaptr, cpevptrT betaptr, cpevptrT scoreptr)
{
mptrT mptr;
cpevT score;

mptr = TTFetchMove();
#if (1)
if ((mptr != NULL) && (last_tteptr->tte_draft >= (iteration - ply)))
	if (last_tteptr->tte_flag & ttef_score_exact)
		{
		score = last_tteptr->tte_cpev;
		if (score < *alphaptr)
			score = *alphaptr;
		if (score > *betaptr)
			score = *betaptr;
		*alphaptr = *betaptr = *scoreptr = score;
		tts_m_slice++;
		}
	else
		if (last_tteptr->tte_flag & ttef_score_alpha)
			{
			if (last_tteptr->tte_cpev < *betaptr)
				{
				*betaptr = last_tteptr->tte_cpev /* + 1 */;
				if (*alphaptr >= *betaptr)
					tts_m_slice++;
				};
			}
		else
			if (last_tteptr->tte_flag & ttef_score_beta)
				{
				if (last_tteptr->tte_cpev > *alphaptr)
					{
					*alphaptr = last_tteptr->tte_cpev /* - 1 */;
					if (*alphaptr >= *betaptr)
						tts_m_slice++;
					};
				};
#endif

return (mptr);
}

/*<<< tt.c: EOF */
