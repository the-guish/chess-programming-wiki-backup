/*>>> oracle.c: oracular advice */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "tbdefs.h"

#include "draw.h"
#include "exec.h"
#include "oracle.h"
#include "print.h"
#include "tb.h"

/*--> OracularEvaluate: evaluate the current position */
nonstatic
cpevT
OracularEvaluate(void)
{
cpevT cpev;
tbidT tbid;
siT invert;

tbid = TBDetectLocal(&invert);
if (tbid != tbid_nil)
	cpev = TBScoreLocal(tbid, invert);
else
	if (DrawInsufficientMaterial())
		cpev = cpev_draw;
	else
		cpev = cpev_wrck;

return (cpev);
}

/*--> OracularMark: mark all oracular moves, return count */
nonstatic
siT
OracularMark(sptrT sptr)
{
siT n;
siT index, count;
siT invert;
mptrT mptr;
tbidT tbid;
cpevT cpev;

/* scan moves */

n = 0;
count = sptr->s_count;
mptr = sptr->s_mbase;
for (index = 0; index < count; index++)
	{
	/* execute the candidate move */

	ExecuteMove(mptr);

	/* continue if legal */

	if (!(mptr->m_flag & mf_bust))
		{
		/* check for being tablebase position */

		tbid = TBDetectLocal(&invert);
		if (tbid != tbid_nil)
			{
			/* file probe */

			cpev = TBScoreLocal(tbid, invert);
			if (cpev != cpev_wrck)
				{
				if (cpev != cpev_draw)
					if (cpev > cpev_draw)
						cpev--;
					else
						cpev++;
				mptr->m_flag |= mf_orac;
				mptr->m_eval = -cpev;
				};
			}
		else
			{
			/* check for insufficient material: KvK, KBvK, and KNvK */

			if (DrawInsufficientMaterial())
				{
				mptr->m_flag |= mf_orac;
				mptr->m_eval = cpev_draw;
				};
			};
		};

	/* count and trace */

	if (mptr->m_flag & mf_orac)
		{
		n++;

		if (optnv[optn_trpz])
			{
			PrTrace("PZ");
			PrStr("oracular: ");
			PrSAN(mptr);
			PrStr("   eval: ");
			PrCentipawn(mptr->m_eval);
			PrNL();
			};
		};

	RetractMove(mptr);
	mptr++;
	};

return (n);
}

/*--> OracularScore: locate best oracular score (if any) */
nonstatic
cpevT
OracularScore(sptrT sptr)
{
cpevT cpev;
siT index, count;
mptrT mptr;

cpev = cpev_bust;
count = sptr->s_count;

mptr = sptr->s_mbase;
for (index = 0; index < count; index++)
	{
	if (!(mptr->m_flag & mf_bust))
		if (mptr->m_flag & mf_orac)
			if (mptr->m_eval > cpev)
				cpev = mptr->m_eval;
	mptr++;
	};

return (cpev);
}

/*--> OracularSearch: search tablebases for a ply zero move */
nonstatic
mptrT
OracularSearch(void)
{
mptrT mptr;
mptrT rmptr;
siT index, count, found;

/* set default return value */

mptr = NULL;

/* scan ply zero moves */

count = root_sptr->s_count;
found = OracularMark(root_sptr);

/* test for all moves being oracular */

if (count == found)
	{
	/* locate and assign best oracular move */

	rmptr = root_sptr->s_mbase;
	for (index = 0; index < count; index++)
		{
		if (rmptr->m_flag & mf_orac)
			if ((mptr == NULL) || (rmptr->m_eval > mptr->m_eval))
				mptr = rmptr;
		rmptr++;
		};

	/* assign expectation */

	expectation = mptr->m_eval;
	};

/* look for a shortest mate if not all moves oracular */

if (count != found)
	{
	rmptr = root_sptr->s_mbase;
	for (index = 0; index < count; index++)
		{
		if (rmptr->m_flag & mf_orac)
			if (ct_bigw(rmptr->m_eval))
				if ((mptr == NULL) || (rmptr->m_eval > mptr->m_eval))
					mptr = rmptr;
		rmptr++;
		};

	if (mptr != NULL)
		expectation = mptr->m_eval;
	};

return (mptr);
}

/*<<< oracle.c: EOF */
