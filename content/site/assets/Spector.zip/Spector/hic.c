/*>>> hic.c: hash index code opening book processing */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "hicdefs.h"

#include "file.h"
#include "hic.h"
#include "memutil.h"
#include "print.h"
#include "san.h"
#include "sysutil.h"
#include "util.h"

/* input and output files */

static charptrT fn0, fn1;
static fptrT fp0, fp1;

/* temporary file names for index and chunk segments */

static charptrT hacfnv[rcL], hscfnv[rcL];

/* temporary file pointers for index and chunk segments */

static fptrT hacfpv[rcL], hscfpv[rcL];

/* master header array */

static hicT hicv[rcL];

/* input buffers for current line */

static cT db_c;
static liT db_hac;
static liT db_hsc;
static siT db_cmo;

/* current record under construction */

static cT ccr_c;
static liT ccr_hac;
static hdbptrT ccr_head, ccr_tail;

/* line, index, position, and move counts */

static liT lcenv[rcL];
static liT icenv[rcL];
static liT pcenv[rcL];
static liT mcenv[rcL];

/* slot for move return value */

static mT hic_m;

/*--> RCBI: read canonical byte integer */
static
siT
RCBI(fptrT fp)
{
siT val;

val = (fgetc(fp) & byteM);

return (val);
}

/*--> RCSI: read canonical short integer */
static
siT
RCSI(fptrT fp)
{
siT val;
siT b0, b1;

b0 = (RCBI(fp) & byteM);
b1 = (RCBI(fp) & byteM);
val = ((b1 << byteW) | b0);

return (val);
}

/*--> RCLI: read canonical long integer */
static
liT
RCLI(fptrT fp)
{
liT val;
liT s0, s1;

s0 = (RCSI(fp) & longwordM);
s1 = (RCSI(fp) & longwordM);
val = ((s1 << wordW) | s0);

return (val);
}

/*--> WCBI: write canonical byte integer */
static
void
WCBI(fptrT fp, byteT byte)
{
fputc(byte, fp);

return;
}

/*--> WCSI: write canonical short integer */
static
void
WCSI(fptrT fp, siT si)
{
WCBI(fp, (si & 0x00ff));
WCBI(fp, ((si >> byteW) & 0x00ff));

return;
}

/*--> WCLI: write canonical long integer */
static
void
WCLI(fptrT fp, liT li)
{
WCSI(fp, (li & 0x0000ffffL));
WCSI(fp, ((li >> wordW) & 0x0000ffffL));

return;
}

/*--> HMENew: create a new HME record */
static
hmeptrT
HMENew(void)
{
hmeptrT hmeptr;

hmeptr = (hmeptrT) MemoryGrab(sizeof(hmeT));

hmeptr->hme_cmo = 0;
hmeptr->hme_count = 0;
hmeptr->hme_prev = NULL;
hmeptr->hme_next = NULL;

return (hmeptr);
}

/*--> HMERelease: dispose of an HME record */
static
void
HMERelease(hmeptrT hmeptr)
{
if (hmeptr != NULL)
	MemoryFree(hmeptr);

return;
}

/*--> HMEAppend: append an HME record to an HDB chain */
static
void
HMEAppend(hmeptrT hmeptr, hdbptrT hdbptr)
{
if (hdbptr->hdb_head == NULL)
	hdbptr->hdb_head = hmeptr;
else
	hdbptr->hdb_tail->hme_next = hmeptr;

hmeptr->hme_prev = hdbptr->hdb_tail;
hmeptr->hme_next = NULL;

hdbptr->hdb_tail = hmeptr;

return;
}

/*--> HMEUnthread: unthread an HME record from an HDB chain */
static
void
HMEUnthread(hmeptrT hmeptr, hdbptrT hdbptr)
{
if (hmeptr->hme_prev == NULL)
	hdbptr->hdb_head = hmeptr->hme_next;
else
	hmeptr->hme_prev->hme_next = hmeptr->hme_next;

if (hmeptr->hme_next == NULL)
	hdbptr->hdb_tail = hmeptr->hme_prev;
else
	hmeptr->hme_next->hme_prev = hmeptr->hme_prev;

return;
}

/*--> HDBNew: create a new HDB record */
static
hdbptrT
HDBNew(void)
{
hdbptrT hdbptr;

hdbptr = (hdbptrT) MemoryGrab(sizeof(hdbT));

hdbptr->hdb_hsc = 0;
hdbptr->hdb_total = 0;
hdbptr->hdb_head = NULL;
hdbptr->hdb_tail = NULL;
hdbptr->hdb_prev = NULL;
hdbptr->hdb_next = NULL;

return (hdbptr);
}

/*--> HDBRelease: dispose of an HDB record */
static
void
HDBRelease(hdbptrT hdbptr)
{
hmeptrT hmeptr;

if (hdbptr != NULL)
	{
	while (hdbptr->hdb_tail != NULL)
		{
		hmeptr = hdbptr->hdb_tail;
		HMEUnthread(hmeptr, hdbptr);
		HMERelease(hmeptr);
		};
	MemoryFree(hdbptr);
	};

return;
}

/*--> HDBAppend: append an HDB record to the current chunk */
static
void
HDBAppend(hdbptrT hdbptr)
{
if (ccr_head == NULL)
	ccr_head = hdbptr;
else
	ccr_tail->hdb_next = hdbptr;

hdbptr->hdb_prev = ccr_tail;
hdbptr->hdb_next = NULL;

ccr_tail = hdbptr;

return;
}

/*--> HDBUnthread: unthread an HDB record from the current chunk */
static
void
HDBUnthread(hdbptrT hdbptr)
{
if (hdbptr->hdb_prev == NULL)
	ccr_head = hdbptr->hdb_next;
else
	hdbptr->hdb_prev->hdb_next = hdbptr->hdb_next;

if (hdbptr->hdb_next == NULL)
	ccr_tail = hdbptr->hdb_prev;
else
	hdbptr->hdb_next->hdb_prev = hdbptr->hdb_prev;

return;
}

/*--> CCRClear: clear the current chunk record */
static
void
CCRClear(void)
{
ccr_c = c_nil;
ccr_hac = 0;
ccr_head = ccr_tail = NULL;

return;
}

/*--> CCRRelease: release the current chunk record */
static
void
CCRRelease(void)
{
hdbptrT hdbptr;

while (ccr_head != NULL)
	{
	hdbptr = ccr_head;
	HDBUnthread(hdbptr);
	HDBRelease(hdbptr);
	};

return;
}

/*--> CCRAccumulate: accumulate the current buffer into current chunk */
static
void
CCRAccumulate(void)
{
hdbptrT hdbptr;
hmeptrT hmeptr;

/* ensure color and address set okay */

if (ccr_c == c_nil)
	{
	ccr_c = db_c;
	ccr_hac = db_hac;
	icenv[ccr_c]++;
	};

/* locate/append HSC match  */

hdbptr = ccr_head;
while ((hdbptr != NULL) && (hdbptr->hdb_hsc != db_hsc))
	hdbptr = hdbptr->hdb_next;

if (hdbptr == NULL)
	{
	hdbptr = HDBNew();
	hdbptr->hdb_hsc = db_hsc;
	HDBAppend(hdbptr);
	pcenv[ccr_c]++;
	};

/* locate/append HME match  */

hmeptr = hdbptr->hdb_head;
while ((hmeptr != NULL) && (hmeptr->hme_cmo != db_cmo))
	hmeptr = hmeptr->hme_next;

if (hmeptr == NULL)
	{
	hmeptr = HMENew();
	hmeptr->hme_cmo = db_cmo;
	HMEAppend(hmeptr, hdbptr);
	mcenv[ccr_c]++;
	};

/* increment counts */

hdbptr->hdb_total++;
hmeptr->hme_count++;

return;
}

/*--> CCRDischarge: discharge the current chunk */
static
void
CCRDischarge(void)
{
liT chunk_length;
hdbptrT hdbptr;
hmeptrT hmeptr;

if (ccr_c != c_nil)
	{
	/* output to index segment */

	WCLI(hacfpv[ccr_c], ccr_hac);
	hicv[ccr_c].hic_i_length += sizeof(liT);

	WCLI(hacfpv[ccr_c], hicv[ccr_c].hic_c_length);
	hicv[ccr_c].hic_i_length += sizeof(liT);

	/* output to chunk segment */

	chunk_length = 0;

	/* start of chunk */

	WCBI(hscfpv[ccr_c], icd_c0);
	chunk_length++;

	/* process HDB loop (mulitple HDB records per chunk) */

	hdbptr = ccr_head;
	while (hdbptr != NULL)
		{
		/* start of HDB set */

		WCBI(hscfpv[ccr_c], icd_s0);
		chunk_length++;

		/* output the signature for this move collection */

		WCLI(hscfpv[ccr_c], hdbptr->hdb_hsc);
		chunk_length += sizeof(liT);

		/* output the count total for this move collection */

		WCLI(hscfpv[ccr_c], hdbptr->hdb_total);
		chunk_length += sizeof(liT);

		/* process HME loop (mulitple HME records per HSC) */

		hmeptr = hdbptr->hdb_head;
		while (hmeptr != NULL)
			{
			/* start of move entry */

			WCBI(hscfpv[ccr_c], icd_m0);
			chunk_length++;

			/* output move ordinal */

			WCBI(hscfpv[ccr_c], hmeptr->hme_cmo);
			chunk_length++;

			/* output popularity count */

			WCLI(hscfpv[ccr_c], hmeptr->hme_count);
			chunk_length += sizeof(liT);

			/* end of move entry */

			WCBI(hscfpv[ccr_c], icd_m1);
			chunk_length++;

			/* next HME record */

			hmeptr = hmeptr->hme_next;
			};

		/* end of HDB set */

		WCBI(hscfpv[ccr_c], icd_s1);
		chunk_length++;

		/* next HDB record */

		hdbptr = hdbptr->hdb_next;
		};

	/* end of chunk */

	WCBI(hscfpv[ccr_c], icd_c1);
	chunk_length++;

	hicv[ccr_c].hic_c_length += chunk_length;

	/* cleanup for next chunk */

	CCRRelease();
	CCRClear();
	};

return;
}

/*--> Load: load the buffer */
static
void
Load(void)
{
char tv[tL];

if (fgets(tv, tL, fp0) == NULL)
	db_c = c_nil;
else
	{
	sscanf(tv, "%01hx %08lx %08lx %02hx",
		&db_c, &db_hac, &db_hsc, &db_cmo);
	lcenv[db_c]++;
	};

return;
}

/*--> Pass1: perform first pass */
static
siT
Pass1(void)
{
siT flag;
cT c;

flag = 1;

/* clear the census counts */

for (c = c_w; c <= c_b; c++)
	{
	lcenv[c] = 0;
	icenv[c] = 0;
	pcenv[c] = 0;
	mcenv[c] = 0;
	};

/* clear the master header array */

for (c = c_w; c <= c_b; c++)
	{
	hicv[c].hic_i_start = 0;
	hicv[c].hic_i_length = 0;
	hicv[c].hic_c_start = 0;
	hicv[c].hic_c_length = 0;
	};

/* prepare the output files */

for (c = c_w; c <= c_b; c++)
	{
	if ((hacfpv[c] = CodeFileOpen(hacfnv[c], "wb")) == NULL)
		Diagnose("Can't open an HAC file for output");
	SetBigBuffer(hacfpv[c]);

	if ((hscfpv[c] = CodeFileOpen(hscfnv[c], "wb")) == NULL)
		Diagnose("Can't open an HSC file for output");
	SetBigBuffer(hscfpv[c]);
	};

/* clear the current record */

CCRClear();

/* scan */

Load();
while (db_c != c_nil)
	{
	/* flush non matching chunk if needed */

	if ((db_c != ccr_c) || (db_hac != ccr_hac))
		CCRDischarge();

	/* accumulate buffer into current chunk */

	CCRAccumulate();

	/* next buffer */

	Load();
	};

/* flush last chunk */

CCRDischarge();

/* close the temporary binary files */

for (c = c_w; c <= c_b; c++)
	{
	CodeFileClose(hacfpv[c]);
	CodeFileClose(hscfpv[c]);
	};

return (flag);
}

/*--> Pass2: perform second pass */
static
siT
Pass2(void)
{
siT flag;
cT c;
liT i, offset;

flag = 1;

/* open the temporary binary files */

for (c = c_w; c <= c_b; c++)
	{
	if ((hacfpv[c] = CodeFileOpen(hacfnv[c], "rb")) == NULL)
		Diagnose("Can't open an HAC file for input");
	SetBigBuffer(hacfpv[c]);

	if ((hscfpv[c] = CodeFileOpen(hscfnv[c], "rb")) == NULL)
		Diagnose("Can't open an HSC file for input");
	SetBigBuffer(hscfpv[c]);
	};

/* set the initial offset */

offset = sizeof(hicv);

/* adjust the master header offsets for the index segments */

for (c = c_w; c <= c_b; c++)
	{
	hicv[c].hic_i_start = offset;
	offset += hicv[c].hic_i_length;
	};

/* adjust the master header offsets for the chunk segments */

for (c = c_w; c <= c_b; c++)
	{
	hicv[c].hic_c_start = offset;
	offset += hicv[c].hic_c_length;
	};

/* output the master header index segment information */

for (c = c_w; c <= c_b; c++)
	{
	WCLI(fp1, hicv[c].hic_i_start);
	WCLI(fp1, hicv[c].hic_i_length);
	};

/* output the master header chunk segment information */

for (c = c_w; c <= c_b; c++)
	{
	WCLI(fp1, hicv[c].hic_c_start);
	WCLI(fp1, hicv[c].hic_c_length);
	};

/* output the index segments via copy */

for (c = c_w; c <= c_b; c++)
	for (i = 0; i < hicv[c].hic_i_length; i++)
		fputc(fgetc(hacfpv[c]), fp1);

/* output the chunk segments via copy */

for (c = c_w; c <= c_b; c++)
	for (i = 0; i < hicv[c].hic_c_length; i++)
		fputc(fgetc(hscfpv[c]), fp1);

/* close the temporary files */

for (c = c_w; c <= c_b; c++)
	{
	CodeFileClose(hacfpv[c]);
	CodeFileClose(hscfpv[c]);
	};

/* delete the temporary files */

for (c = c_w; c <= c_b; c++)
	{
	remove(hacfnv[c]);
	remove(hscfnv[c]);
	};

return (flag);
}

/*--> HICGen: main program for hic maker */
nonstatic
siT
HICGen(charptrT basename)
{
siT flag;
char tv[tL];
cT c;

flag = 1;

fn0 = fn1 = NULL;
fp0 = fp1 = NULL;

for (c = c_w; c <= c_b; c++)
	{
	hacfnv[c] = NULL;
	hscfnv[c] = NULL;
	};

/* generate file names */

sprintf(tv, "%s.hxs", basename);
fn0 = StringGrab(tv);

sprintf(tv, "%s.hic", basename);
fn1 = StringGrab(tv);

/* open main input and output files */

if (flag)
		if ((fp0 = TextFileOpen(fn0, "r")) == NULL)
		{
		PrErr("Can't open main input file");
		flag = 0;
		}
	else
		SetBigBuffer(fp0);

if (flag)
	if ((fp1 = CodeFileOpen(fn1, "wb")) == NULL)
		{
		PrErr("Can't open main output file");
		flag = 0;
		}
	else
		SetBigBuffer(fp1);

/* construct temporary file names */

if (flag)
	for (c = c_w; c <= c_b; c++)
		{
		sprintf(tv, "%s.a.%hd", basename, c);
		hacfnv[c] = StringGrab(tv);

		sprintf(tv, "%s.s.%hd", basename, c);
		hscfnv[c] = StringGrab(tv);
		};

/* perform the passes */

if (flag)
	flag = Pass1();

if (flag)
	flag = Pass2();

/* close the main files */

if (fp0 != NULL)
	TextFileClose(fp0);
if (fp1 != NULL)
	CodeFileClose(fp1);

/* status report */

if (flag)
	{
	PrStrLINL("White line count: ", lcenv[c_w]);
	PrStrLINL("Black line count: ", lcenv[c_b]);
	PrStrLINL("Total line count: ", (lcenv[c_w] + lcenv[c_b]));

	PrStrLINL("White index count: ", icenv[c_w]);
	PrStrLINL("Black index count: ", icenv[c_b]);
	PrStrLINL("Total index count: ", (icenv[c_w] + icenv[c_b]));

	PrStrLINL("White position count: ", pcenv[c_w]);
	PrStrLINL("Black position count: ", pcenv[c_b]);
	PrStrLINL("Total position count: ", (pcenv[c_w] + pcenv[c_b]));

	PrStrLINL("White move count: ", mcenv[c_w]);
	PrStrLINL("Black move count: ", mcenv[c_b]);
	PrStrLINL("Total move count: ", (mcenv[c_w] + mcenv[c_b]));
	};

/* release temporary file name storage */

for (c = c_w; c <= c_b; c++)
	{
	if (hacfnv[c] != NULL)
		MemoryFree(hacfnv[c]);
	if (hscfnv[c] != NULL)
		MemoryFree(hscfnv[c]);
	};

/* relase remaining name storage */

if (fn0 != NULL)
	MemoryFree(fn0);
if (fn1 != NULL)
	MemoryFree(fn1);

return (flag);
}

/*--> HICProbe: return a probe vector of the HIC book */
nonstatic
liptrT
HICProbe(void)
{
liptrT lcptr;
char hicname[tL];
siT flag, i, count;
cT c;
fptrT fp;
uliT hac, hsc;
liT loc;
hicT header[rcL];
liT hmin, hmax, hmid;
liT offset;
siT match_hac, match_hsc;
siT byte, cmo;
liT pop;

/* set up */

flag = 1;
fp = NULL;
loc = 0;

/* allocate and clear return value */

count = root_sptr->s_count;
lcptr = (liptrT) MemoryGrab(sizeof(liT) * count);
for (i = 0; i < count; i++)
	*(lcptr + i) = 0;

/* open HIC book */

sprintf(hicname, "%s/%s", hicdir, hicbook);
fp = CodeFileOpen(hicname, "rb");
if (fp == NULL)
	flag = 0;

/* read HIC header */

if (flag)
	{
	/* read index information */

	for (c = c_w; c <= c_b; c++)
		{
		header[c].hic_i_start = RCLI(fp);
		header[c].hic_i_length = RCLI(fp);
		};

	/* read chunk information */

	for (c = c_w; c <= c_b; c++)
		{
		header[c].hic_c_start = RCLI(fp);
		header[c].hic_c_length = RCLI(fp);
		};
	};

/* probe index segment for HAC match */

if (flag)
	{
	hmin = 0;
	hmax = (header[actc].hic_i_length / (2 * sizeof(liT))) - 1;
	match_hac = 0;
	while (!match_hac && (hmin <= hmax))
		{
		hmid = (hmin + hmax) >> 1;
		offset = header[actc].hic_i_start + (hmid * (2 * sizeof(liT)));

		fseek(fp, offset, SEEK_SET);
		hac = RCLI(fp);

		if (envn.envn_mhac == hac)
			{
			loc = RCLI(fp);
			match_hac = 1;
			}
		else
			if (envn.envn_mhac < hac)
				hmax = hmid - 1;
			else
				hmin = hmid + 1;
		};
	};

/* parse chunk segment entry if HAC match was found */

if (flag)
	if (match_hac)
		{
		offset = header[actc].hic_c_start + loc;
		fseek(fp, offset, SEEK_SET);

		byte = RCBI(fp);
		if (byte != icd_c0)
			Diagnose("HICProbe: expected icd_c0");

		/* try reading the next chunk */

		byte = RCBI(fp);
		while (byte != icd_c1)
			{
			/* process set */

			if (byte != icd_s0)
				Diagnose("HICProbe: expected icd_s0");

			/* fetch hsc and skip total */

            hsc = RCLI(fp);
            match_hsc = (hsc == envn.envn_mhsc);
			(void) RCLI(fp);

			byte = RCBI(fp);
			while (byte != icd_s1)
				{
				/* process moves */

				if (byte != icd_m0)
					Diagnose("HICProbe: expected icd_m0");

				/* fetch cmo and pop */

				cmo = RCBI(fp);
				pop = RCLI(fp);

				if ((match_hsc) && (cmo < root_sptr->s_count))
					*(lcptr + cmo) += pop;

				byte = RCBI(fp);
				if (byte != icd_m1)
					Diagnose("HICProbe: expected icd_m1");

				byte = RCBI(fp);
				};

			if (byte != icd_s1)
				Diagnose("HICProbe: expected icd_s1");

			byte = RCBI(fp);
			};
		};

/* close HIC book */

if (fp != NULL)
	CodeFileClose(fp);

return (lcptr);
}

/*--> HICBookSearch: attempt to locate a move from the HIC book */
nonstatic
mptrT
HICBookSearch(void)
{
mptrT mptr;
liptrT lcptr;
siT i, count;
liT total, sum, offset;

/* initialize */

hic_m = null_m;
mptr = NULL;

/* perform probe and collect total */

lcptr = HICProbe();
count = root_sptr->s_count;
total = 0;
for (i = 0; i < count; i++)
	total += *(lcptr + i);

/* select move */

if (total > 0)
	{
	sum = 0;
	offset = TBPsuedoRandomLI() % total;
	i = 0;
	while (mptr == NULL)
		{
		if (*(lcptr + i) > 0)
			{
			sum += *(lcptr + i);
			if (sum >= offset)
				{
				hic_m = *LocateOrdinalMove(i, root_sptr);
				mptr = &hic_m;
				};
			};
		i++;
		};
	};

/* release probe memory */

MemoryFree(lcptr);

return (mptr);
}

/* hic.c: EOF */
