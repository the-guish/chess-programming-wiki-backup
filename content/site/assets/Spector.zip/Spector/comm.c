/*>>> comm.c: Duplex communication processing */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "commdefs.h"
#include "commvars.h"

#include "epddefs.h"
#include "vpdefs.h"

#include "comm.h"
#include "display.h"
#include "epd.h"
#include "file.h"
#include "gms.h"
#include "init.h"
#include "memutil.h"
#include "mm.h"
#include "play.h"
#include "print.h"
#include "san.h"
#include "select.h"
#include "sysutil.h"

/**** Locals */

/* direction flows */

#define flowL 2

/*--> CommHandler: respond to Duplex mediator command */
static
epdptrT
CommHandler(epdptrT epdptr0, siptrT flagptr)
{
epdptrT epdptr1;
eopptrT eopptr;
char fnv[tL];
fptrT fptr;
mptrT mptr;
mT m;
sanT san;
liT pid;

/* assing default return value */

epdptr1 = NULL;

/* set running flag */

*flagptr = 1;

/* process according to input referee command */

switch (EPDExtractRefcomIndex(epdptr0))
	{
	case refcom_conclude:

		/* fetch process ID */

		pid = GetProcessID();

		/* output game */

		sprintf(fnv, "d%05hd.pgn", ((siT) (pid & 0x7fff)));
		fptr = TextFileOpen(fnv, "w");
		if (fptr == NULL)
			PrErr("Can't open event report output file");
		else
			{
			GMSER(fptr);
			(void) TextFileClose(fptr);
			};

		break;

	case refcom_disconnect:
		break;

	case refcom_execute:

		/* execute a move */

		eopptr = EPDLocateEOPCode(epdptr0, epdso_sm);
		if ((eopptr != NULL) && (eopptr->eop_headeov != NULL))
			{
			mptr = MatchMove(eopptr->eop_headeov->eov_str, root_sptr);
			if (mptr == NULL)
				*flagptr = 0;
			else
				{
				m = *mptr;
				PlayMove(&m);
				};
			};

		break;

	case refcom_fault:
		*flagptr = 0;
		break;

	case refcom_inform:
		break;

	case refcom_reset:

		/* set up for a new game */

		InitNewGame();

		break;

	case refcom_respond:

		/* respond to a (possible) move */

		eopptr = EPDLocateEOPCode(epdptr0, epdso_sm);
		if ((eopptr != NULL) && (eopptr->eop_headeov != NULL))
			{
			mptr = MatchMove(eopptr->eop_headeov->eov_str, root_sptr);
			if (mptr == NULL)
				*flagptr = 0;
			else
				{
				m = *mptr;
				PlayMove(&m);
				};
			};

		/* select a move */

		SelectMove();

		/* generate outgoing EPD */

		epdptr1 = EPDSetCurrent();

		/* add in referee request */

		EPDAddOpSym(epdptr1, epdso_refreq, EPDFetchRefreqStr(refreq_reply));

		/* add in supplied move */

		SANMove(root_sptr->s_mbest, san);
		EPDAddOpSym(epdptr1, epdso_sm, san);

		/* play the program move */

		PlayMove(root_sptr->s_mbest);

		break;

	default:
		SwitchFault("CommHandler");
		break;
	};

/* update everything */

DpUpdateAll();

/* clean up if an error occured */

if (!*flagptr)
	if (epdptr1 != NULL)
		{
		EPDReleaseEPD(epdptr1);
		epdptr1 = NULL;
		};

return (epdptr1);
}

/*--> CommDuplex: process Duplex communication */
nonstatic
void
CommDuplex(void)
{
siT flag;
siT done;
siT flow;
refcomT refcom;
charptrT pfnv[flowL];
fptrT pfptrv[flowL];
epdptrT epdptr0, epdptr1;
charptrT eptr;
char ev[epdL];

/* set default result: success */

flag = 1;

/* set up for a new game */

InitNewGame();

/* generate pipe file names and clear their pointers */

for (flow = 0; flow < flowL; flow++)
	{
	pfnv[flow] = StringGrab(ipv[1].ip_str);
	pfnv[flow] = StringAppendStr(pfnv[flow], ".pc");
	pfnv[flow] = StringAppendChar(pfnv[flow], (flow + '0'));
	pfptrv[flow] = NULL;
	};

/* pipe files already created by Duplex, attempt open */

flow = 0;
while (flag && (flow < flowL))
	{
	pfptrv[flow] = TextFileOpen(pfnv[flow], "a+");
	if (pfptrv[flow] == NULL)
		flag = 0;
	else
		flow++;
	};

/* sign on to Duplex */

if (flag)
	{
	epdptr0 = EPDSetCurrent();
	EPDAddOpSym(epdptr0, epdso_refreq,
		 EPDFetchRefreqStr(refreq_sign_on));
	eptr = EPDEncode(epdptr0);
	EPDReleaseEPD(epdptr0);
	fprintf(pfptrv[0], "%s\n", eptr);
	fflush(pfptrv[0]);
	MemoryFree(eptr);
	};

/* run event cycle loop */

done = 0;
while (flag && !done)
	{
	/* read an incoming EPD message */

	if (fgets(ev, (epdL - 1), pfptrv[1]) == NULL)
		flag = 0;
	else
		{
		/* decode the message */

		epdptr1 = EPDDecode(ev);
		if ((epdptr1 == NULL) ||
			((refcom = EPDExtractRefcomIndex(epdptr1)) == refcom_nil))
			flag = 0;
		else
			{
			/* send the message to the callback routine */

			epdptr0 = CommHandler(epdptr1, &flag);

			/* release input storage */

			EPDReleaseEPD(epdptr1);

			/* construct and transmit output string */

			if (flag && (epdptr0 != NULL))
				{
				eptr = EPDEncode(epdptr0);
				fprintf(pfptrv[0], "%s\n", eptr);
				fflush(pfptrv[0]);
				MemoryFree(eptr);
				};

			/* release output storage */

			if (epdptr0 != NULL)
				EPDReleaseEPD(epdptr0);

			/* set the completion flag on disconnect */

			if (flag && !done && (refcom == refcom_disconnect))
				done = 1;
			};
		};
	};

/* close pipes and release pipe file names */

for (flow = 0; flow < flowL; flow++)
	{
	if (pfptrv[flow] != NULL)
		(void) TextFileClose(pfptrv[flow]);
	MemoryFree(pfnv[flow]);
	};

/* report */

if (!flag)
	PrErr("Trouble occurred during Duplex communication.");

return;
}

/*<<< comm.c: EOF */
