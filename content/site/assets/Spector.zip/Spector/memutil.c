/*>>> memutil.c: memory allocation management routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "memutil.h"
#include "sysutil.h"

/**** Locals */

/* allocated alignment: 0=unforced alignment, 1=four byte alignment */

#define mem_alignment 1

#if (mem_alignment)
/*--> MemoryGrab: memory grab */
nonstatic
voidptrT
MemoryGrab(allocT n)
{
voidptrT result, base;

/* reserve */

if ((base = malloc(n + 6)) == NULL)
	{
	(void) fprintf(stderr, "MemoryGrab: n: %ld\n", n);
	Fault("MemoryGrab");
	};

/* set result from true base */

if (((liT) base) & 2)
	result = (voidptrT) (((uliT) base) + 6);
else
	result = (voidptrT) (((uliT) base) + 4);

/* insert true base in region */

*((void **) (((uliT) result) - 4)) = base;

return (result);
}
#else
/*--> MemoryGrab: memory grab */
nonstatic
voidptrT
MemoryGrab(allocT n)
{
voidptrT result;

/* reserve */

if ((result = malloc(n)) == NULL)
	{
	(void) fprintf(stderr, "MemoryGrab: n: %ld\n", n);
	Fault("MemoryGrab");
	};

return (result);
}
#endif

/*--> StringGrab: allocate and copy a string */
nonstatic
charptrT
StringGrab(charptrT s)
{
charptrT p;

p = MemoryGrab(strlen(s) + 1);
(void) strcpy(p, s);

return (p);
}

/*--> StringAppendChar: append char to a string (str deallocated) */
nonstatic
charptrT
StringAppendChar(charptrT s, char ch)
{
charptrT p;
siT length;

length = strlen(s);
p = MemoryGrab(length + 2);
(void) strcpy(p, s);
*(p + length) = ch;
*(p + length + 1) = ascii_nul;
MemoryFree(s);

return (p);
}

/*--> StringAppendStr: append string to a string (1st str deallocated) */
nonstatic
charptrT
StringAppendStr(charptrT s0, charptrT s1)
{
charptrT p;

p = MemoryGrab(strlen(s0) + strlen(s1) + 1);
(void) strcpy(p, s0);
(void) strcat(p, s1);
MemoryFree(s0);

return (p);
}

#if (mem_alignment)
/*--> MemoryResize: memory resize */
nonstatic
voidptrT
MemoryResize(voidptrT p, allocT n)
{
voidptrT result, base0, base1;

/* fetch old base */

base0 = *((voidptrT *) (((uliT) p) - 4));

/* reallocate region */

base1 = realloc(base0, (n + 6));
if (base1 == NULL)
	{
	(void) fprintf(stderr, "MemoryResize: n: %ld\n", n);
	Fault("MemoryResize");
	};

/* set new base if necessary */

if (base0 == base1)
	result = p;
else
	{
	/* set result from true base */

	if (((liT) base1) & 2)
		result = (voidptrT) (((uliT) base1) + 6);
	else
		result = (voidptrT) (((uliT) base1) + 4);

	/* insert true base in region */

	*((void **) (((uliT) result) - 4)) = base1;
	};

return (result);
}
#else
/*--> MemoryResize: memory resize */
nonstatic
voidptrT
MemoryResize(voidptrT p, allocT n)
{
voidptrT result;

/* reallocate region */

result = realloc(p, (n ? n : 1));
if (result == NULL)
	{
	(void) fprintf(stderr, "MemoryResize: n: %ld\n", n);
	Fault("MemoryResize");
	};

return (result);
}
#endif

#if (mem_alignment)
/*--> MemoryFree: memory free */
nonstatic
void
MemoryFree(voidptrT p)
{
voidptrT base;

if (p != NULL)
	{
	/* fetch true base */

	base = *((voidptrT *) (((uliT) p) - 4));

	/* free using true base */

	free(base);
	}
else
	Fault("MemoryFree");

return;
}
#else
/*--> MemoryFree: memory free */
nonstatic
void
MemoryFree(voidptrT p)
{
if (p != NULL)
	free(p);
else
	Fault("MemoryFree");

return;
}
#endif

/*<<< memutil.c: EOF */
