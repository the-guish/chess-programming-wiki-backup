/*>>> pgc.h: subprogram prototypes for pgc.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void PGCWriteCurrent(fptrT fptr);

/*<<< pgc.h: EOF */
