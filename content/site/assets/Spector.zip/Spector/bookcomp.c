/*>>> bookcomp.c: opening book compilation routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bookdefs.h"
#include "bookvars.h"

#include "epddefs.h"

#include "bookcomp.h"
#include "bookutil.h"
#include "epd.h"
#include "exec.h"
#include "file.h"
#include "init.h"
#include "memutil.h"
#include "mm.h"
#include "moveset.h"
#include "notation.h"
#include "print.h"
#include "sysutil.h"
#include "util.h"

/*--> ListBookTextCompGetChar: read the next character from the book text */
static
void
ListBookTextCompGetChar(void)
{
/* read a character */

bookch = fgetc(fp_bktx);
if (bookch != EOF)
	bookcn++;

/* local echo to console */

if (optnv[optn_trbc])
	if (bookch != EOF)
		PrChar(bookch);

return;
}

/*--> ListBookTextCompEchoChar: echo character to correction file */
static
void
ListBookTextCompEchoChar(void)
{
if (fp_obfc != NULL)
	if (bookch != EOF)
		(void) fputc(bookch, fp_obfc);

return;
}

/*--> ListBookTextCompAdvanceChar: echo character, get another */
static
void
ListBookTextCompAdvanceChar(void)
{
ListBookTextCompEchoChar();
ListBookTextCompGetChar();

return;
}

/*--> ListBookTextCompEchoMove: echo corrected move to correction file */
static
void
ListBookTextCompEchoMove(siT poorflag)
{
if (fp_obfc != NULL)
	{
	(void) fprintf(fp_obfc, "%s", bookcsm);
	if (poorflag)
		(void) fputc(bkchar_poormv, fp_obfc);
	};

return;
}

/*--> ListBookTextCompGetToken: read the next token from the book text */
static
bktftcT
ListBookTextCompGetToken(void)
{
siT flag, i, bcn;
bktftcT bktftc;
liT bookbcln;

/* clear token indicator */

flag = 0;

/* clear the block comment nesting level */

bcn = 0;

/* find a token */

while (!flag)
	{
	/* clear the result */

	bktftc = bktftc_bvar;

	/* skip some whitespace */

	while ((bookch == ascii_sp) || (bookch == ascii_ht))
		ListBookTextCompAdvanceChar();

	/* process according to initial character */

	switch (bookch)
		{
		/* end of file check */

		case EOF:
			bktftc = bktftc_stop;
			flag = 1;
			break;

		/* begin variation */

		case bkchar_varbgn:
			ListBookTextCompAdvanceChar();
			bktftc = bktftc_bvar;
			flag = 1;
			break;

		/* end variation */

		case bkchar_varend:
			ListBookTextCompAdvanceChar();
			bktftc = bktftc_evar;
			flag = 1;
			break;

		/* line comment */

		case bkchar_slcbgn:
			ListBookTextCompAdvanceChar();
			while ((bookch != '\n') && (bookch != EOF))
				ListBookTextCompAdvanceChar();
			break;

		/* nestable block comment */

		case bkchar_nbcbgn:
			bcn++;
			bookbcln = bookln;
			ListBookTextCompAdvanceChar();

			while ((bcn > 0) && (bookch != EOF))
				switch (bookch)
					{
					case bkchar_nbcbgn:
						bcn++;
						ListBookTextCompAdvanceChar();
						break;

					case bkchar_nbcend:
						bcn--;
						ListBookTextCompAdvanceChar();
						break;

					case '\n':
						ListBookTextCompAdvanceChar();
						bookln++;
						break;

					case bkchar_slcbgn:
						ListBookTextCompAdvanceChar();
						while ((bookch != '\n') && (bookch != EOF))
							ListBookTextCompAdvanceChar();
						break;

					default:
						ListBookTextCompAdvanceChar();
						break;
					};

			if (bcn != 0)
				{
				bktftc = bktftc_bust;
				flag = 1;
				PrNL();
				(void) sprintf(stv, "Unmatched block comment from line %ld",
					(bookbcln + 1));
				PrErrSTV();
				};
			break;

		/* newline */

		case '\n':
			ListBookTextCompAdvanceChar();
			bookln++;
			break;

		/* other */

		default:
			i = 0;
			while ((bookch != ascii_sp) && (bookch != ascii_ht) &&
				(bookch != '\n') && (bookch != bkchar_slcbgn) &&
				(bookch != bkchar_varbgn) &&
				(bookch != bkchar_varend) && (bookch != EOF))
				{
				if (i < (sanL - 1))
					bookusm[i] = (char) bookch;
				i++;
				ListBookTextCompGetChar();
				};
			if (i >= sanL)
				bktftc = bktftc_bust;
			else
				{
				while (i < sanL)
					bookusm[i++] = ascii_nul;
				bktftc = bktftc_move;
				};
			flag = 1;
			break;
		};
	};

return (bktftc);
}

/*--> ListBookTextCompCheckPoor: check and process poor move indication */
static
siT
ListBookTextCompCheckPoor(sanT san)
{
siT flag, i;

flag = 0;
i = 0;

while (!flag && (i < (sanL - 1)) && (san[i] != ascii_nul))
	if (san[i] == bkchar_poormv)
		flag = 1;
	else
		i++;

if (flag)
	san[i] = ascii_nul;

return (flag);
}

/*--> ListBookTextComp: compile opening book text file */
nonstatic
siT
ListBookTextComp(charptrT fn_bkfsrc, charptrT fn_bkfdst, charptrT fn_bkfcor,
	charptrT fn_bkfmpl, charptrT fn_bkfepd)
{
sptrT sptr, psptr;
siT flag, scan, poorflag, tply, ord, iply;
sanT san;
charptrT ptr;

/* set scanning flag */

flag = 1;

/* set up for start of game */

InitNewGame();

/* set the starting pointer */

sptr = root_sptr;

/* set up statistics */

booktmn = booktcn = booktln = booktvn = 0;

/* set up file pointers */

fp_bktx = fp_bkcd = fp_obfc = fp_obmp = fp_obep = NULL;

/* open the input text file */

if (flag)
	{
	fp_bktx = TextFileOpen(fn_bkfsrc, "r");
	if (fp_bktx == NULL)
		flag = 0;
	else
		SetBigBuffer(fp_bktx);
	};

/* open the output code file (note: binary mode open) */

if (flag)
	{
	fp_bkcd = CodeFileOpen(fn_bkfdst, "wb");
	if (fp_bkcd == NULL)
		flag = 0;
	else
		{
		SetBigBuffer(fp_bkcd);
		fp_put_code = fp_bkcd;
		}
	};

/* open (conditionally) the opening book corrected text output file */

if (flag)
	if (optnv[optn_obfc])
		{
		fp_obfc = TextFileOpen(fn_bkfcor, "w");
		if (fp_obfc == NULL)
			flag = 0;
		else
			SetBigBuffer(fp_obfc);
		};

/* open (conditionally) the opening book move path list text output file */

if (flag)
	if (optnv[optn_obmp])
		{
		fp_obmp = TextFileOpen(fn_bkfmpl, "w");
		if (fp_obmp == NULL)
			flag = 0;
		else
			SetBigBuffer(fp_obmp);
		};

/* open (conditionally) the EPD text output file */

if (flag)
	if (optnv[optn_obep])
		{
		fp_obep = TextFileOpen(fn_bkfepd, "w");
		if (fp_obep == NULL)
			flag = 0;
		else
			SetBigBuffer(fp_obep);
		};

/* set up for text scan */

if (flag)
	{
	bkvarn = 0;
	bookln = bookcn = 0;
	ListBookTextCompGetChar();
	};

/* loop through each token in the input text */

if (flag)
	{
	scan = 1;
	while (flag && scan)
		{
		if (optnv[optn_trbc])
			TextFileFlush(stdout);
		switch (ListBookTextCompGetToken())
			{
			/* process move */

			case bktftc_move:

				/* check for depth oveflow */

				if (ply == bkmcdL)
					{
					PrNL();
					(void) sprintf(stv, "Sequence overflow on line %ld",
						(bookln + 1));
					PrErrSTV();
					flag = 0;
					};

				/* set the "poor move flag" */

				if (flag)
					poorflag = ListBookTextCompCheckPoor(bookusm);

				/* attempt to match the input move */

				if (flag)
					{
					/* set SAN mode for input */

					lang_san = lang_get;

					/* match move */

					sptr->s_mcurr = MatchMove(bookusm, sptr);

					/* check for non-match */

					if (sptr->s_mcurr == NULL)
						{
						PrNL();
						PrStr("-- Error: can't match move: [");
						PrStrNoTrailingBlanks(bookusm);
						(void) sprintf(stv, "] on line %ld",
							(bookln + 1));
						PrSTVNL();
						flag = 0;
						};
					};

				/* check the move generation ordinal */

				if (flag)
					{
					ord = sptr->s_mcurr - sptr->s_mbase;
					if (ord >= bkgenL)
						{
						PrNL();
						PrStr("-- Error: choice overflow: [");
						PrStrNoTrailingBlanks(bookusm);
						(void) sprintf(stv, "] on line %ld", (bookln + 1));
						PrSTVNL();
						flag = 0;
						};
					};

				/* record move, execute move, then extend tree */

				if (flag)
					{
					/* set SAN output mode */

					lang_san = lang_put;

					/* generate (possibly) corrected move */

					ConstructNotation(global_nm, sptr->s_mcurr, bookcsm);
					if (strcmp(bookusm, bookcsm) != 0)
						booktcn++;

					/* mark move as a book move in moveset */

					sptr->s_mcurr->m_flag |= mf_book;
					if (poorflag)
						sptr->s_mcurr->m_flag |= mf_poor;

					/* output (possibly) corrected move */

					ListBookTextCompEchoMove(poorflag);

					/* output generation ordinal to code file */

					if (poorflag)
						ListBookCodePutAnnotatedMove(ord, bkanno_poor);
					else
						ListBookCodePutMove(ord);
					booktmn++;

					/* handle expanded description position generation */

					if (optnv[optn_obep] && !poorflag)
						{
						ptr = EPDGenBasicCurrent();
						fprintf(fp_obep, "%s m %s\n", ptr, bookcsm);
						MemoryFree(ptr);
						};

					/* execute */

					ExecuteMove(sptr->s_mcurr);

					/* tree extension */

					MovesetGenerateConnect(sptr->s_mcurr);
					sptr = sptr->s_mcurr->m_dptr;
					MovesetFullExpand(sptr, 0);
					};

				break;

			/* process variation begin */

			case bktftc_bvar:

				/* check for variation nesting overflow */

				if (bkvarn == bkvarL)
					{
					PrNL();
					(void) sprintf(stv, "Nesting overflow at line %ld",
						(bookln + 1));
					PrErrSTV();
					flag = 0;
					};

				/* push variation ply index; output marker to code file */

				if (flag)
					{
					bkvarv[bkvarn++] = ply;
					ListBookCodePutControl(bkcntl_bvar);
					booktvn++;
					};

				break;

			/* process variation end */

			case bktftc_evar:

				/* check for variation nesting underflow */

				if (bkvarn == 0)
					{
					PrNL();
					(void) sprintf(stv, "Nesting underflow at line %ld",
						(bookln + 1));
					PrErrSTV();
					flag = 0;
					};

				/* trace print */

				if (optnv[optn_trmp] && !optnv[optn_trbc])
					{
					PrTrace("MP");
					PrMovePath(root_sptr);
					PrNL();
					};

				/* process move path file list */

				if (optnv[optn_obmp])
					{
					psptr = root_sptr;
					for (iply = 0; iply < ply; iply++)
						{
						if (iply != 0)
							(void) fputc(ascii_sp, fp_obmp);
						ConstructNotation(global_nm, psptr->s_mcurr, san);
						(void) fprintf(fp_obmp, "%s", san);
						if (psptr->s_mcurr->m_flag & mf_poor)
							(void) fputc(bkchar_poormv, fp_obmp);
						psptr = psptr->s_mcurr->m_dptr;
						};
					(void) fputc('\n', fp_obmp);
					};

				/* unstack and output marker */

				if (flag)
					{
					/* adjust total book length */

					booktln += ply;

					/* unstack sequence */

					tply = bkvarv[--bkvarn];
					while (ply > tply)
						{
						/* get parent moveset pointer */

						sptr = sptr->s_mprev->m_cptr;

						/* check for tree conservation */

						if (ply >= mtrdL)
							if (!optnv[optn_obrt])
								MovesetDisconnectRelease(sptr->s_mcurr);
							else
								if (ply >= level)
									MovesetDisconnectRelease(sptr->s_mcurr);

						/* retract */

						RetractMove(sptr->s_mcurr);

						};

					/* output variation end marker to code file */

					ListBookCodePutControl(bkcntl_evar);
					};

				break;

			/* process end of text */

			case bktftc_stop:

				/* stop the scan */

				scan = 0;

				/* check for non-return condition */

				if (ply != 0)
					{
					PrNL();
					PrErr("Can't return to ground state");
					flag = 0;
					};

				/* output end of book marker to code file */

				if (flag)
					ListBookCodePutControl(bkcntl_stop);

				break;

			/* process unidentified token */

			case bktftc_bust:

				/* diagnostic */

				PrNL();
				(void) sprintf(stv, "Trash on line %ld", (bookln + 1));
				PrErrSTV();
				flag = 0;

				break;

			default:
				SwitchFault("ListBookTextComp");
				break;
			};
		};
	};

/* close files */

if (fp_bktx != NULL)
	(void) TextFileClose(fp_bktx);
if (fp_bkcd != NULL)
	(void) TextFileClose(fp_bkcd);
if (fp_obfc != NULL)
	(void) TextFileClose(fp_obfc);
if (fp_obmp != NULL)
	(void) TextFileClose(fp_obmp);
if (fp_obep != NULL)
	(void) TextFileClose(fp_obep);

/* clean up if needed */

if (!flag)
	{
	/* unwind stacks */

	while (ply > 0)
		{
		sptr = sptr->s_mprev->m_cptr;
		if (ply >= mtrdL)
			MovesetDisconnectRelease(sptr->s_mcurr);
		RetractMove(sptr->s_mcurr);
		};

	/* remove any output files because of error(s) */

	(void) remove(fn_bkfdst);
	if (optnv[optn_obfc])
		(void) remove(fn_bkfcor);
	if (optnv[optn_obmp])
		(void) remove(fn_bkfmpl);
	};

/* statistics */

if (flag)
	if (optnv[optn_trbc])
		{
		PrTrace("BC");
		PrStrCondOrdLINL("text bytes: ", bookcn);

		PrTrace("BC");
		PrStrCondOrdLINL("text lines: ", bookln);

		PrTrace("BC");
		PrStrCondOrdLINL("chessmoves: ", booktmn);

		PrTrace("BC");
		PrStrCondOrdLINL("variations: ", booktvn);

		if (booktvn > 0)
			{
			PrTrace("BC");
			PrStr("avg length: ");
			FormatSTVLQR(booktmn, booktvn);
			PrSTVNL();
			};

		if (optnv[optn_obfc])
			{
			PrTrace("BC");
			PrStrCondOrdLINL("correctors: ", booktcn);
			};

		};

return (flag);
}

/*<<< bookcomp.c: EOF */
