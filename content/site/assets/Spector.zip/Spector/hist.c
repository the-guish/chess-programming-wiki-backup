/*>>> hist.c: history routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "hist.h"
#include "mu.h"
#include "sysutil.h"

/*--> HistoryPush: push the current position on the history stack */
nonstatic
void
HistoryPush(mptrT mptr)
{
histptrT ptr;
sqT sq;

if (histn < histL)
	{
	ptr = histcurr;

	ptr->hist_mhac = envn.envn_mhac;
	ptr->hist_mhsc = envn.envn_mhsc;

	if (ply < history_full_push)
		{
		ConvertToLimitedMove(mptr, &ptr->hist_lm);

		ptr->hist_actc = actc;
		ptr->hist_cast = envn.envn_cast;
		ptr->hist_epsq = envn.envn_epsq;
		ptr->hist_fmvn = envn.envn_fmvn;
		ptr->hist_hmvc = envn.envn_hmvc;
		ptr->hist_pasc = pasc;

		for (sq = sq_a1; sq <= sq_h8; sq += 2)
			ptr->hist_nbv[sq >> 1] =
				(byteT) ((local.rbv[sq + 1] << nybbW) | local.rbv[sq]);
		};
	cordcurr++;
	histcurr++;
	histn++;
	}
else
	Overflow("HistoryPush");

return;
}

/*--> HistoryPop: pop the history stack into the current position */
nonstatic
void
HistoryPop(void)
{
histptrT ptr;
sqT sq;
byteT byte;

/* NOTE: this routine is called ONLY when retracting moves at ply 0 */

if (histn > 0)
	{
	cordcurr--;
	histcurr--;
	histn--;
	ptr = histcurr;
	envn.envn_fmvn = ptr->hist_fmvn;
	actc = ptr->hist_actc;
	pasc = ptr->hist_pasc;
	envn.envn_cast = ptr->hist_cast;
	envn.envn_epsq = ptr->hist_epsq;
	envn.envn_hmvc = ptr->hist_hmvc;
	for (sq = sq_a1; sq <= sq_h8; sq += 2)
		{
		byte = ptr->hist_nbv[sq >> 1];
		local.rbv[sq] = byte & nybbM;
		local.rbv[sq + 1] = (byte >> nybbW) & nybbM;
		};
	}
else
	Diagnose("HistoryPop: underflow");

return;
}

/*--> HistoryDrop: decrement the history stack */
nonstatic
void
HistoryDrop(void)
{
if (histn > 0)
	{
	histn--;
	histcurr--;
	cordcurr--;
	}
else
	Diagnose("HistoryDrop: underflow");

return;
}

/*--> HistoryClear: clear the history stack */
nonstatic
void
HistoryClear(void)
{
/* clear the history */

histn = 0;
histcurr = histbase;
cordcurr = cordbase;

return;
}

/*--> OrdinalSet: set the current move on the ordinal stack */
nonstatic
void
OrdinalSet(cordT cord)
{
/* this routine is called just prior to history push */

*cordcurr = cord;

return;
}

/*<<< cord.c: EOF */
