/*>>> tact.h: subprogram prototypes for tact.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT TacticalExtend(void);

/*<<< tact.h: EOF */
