/*>>> pvs.h: subprogram prototypes for pvs.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

mptrT PVSSearch(void);

/*<<< pvs.h: EOF */
