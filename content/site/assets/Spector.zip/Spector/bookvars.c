/*>>> bookvars.c: opening book variable declarations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"

#include "bookdefs.h"

/* file pointers */

fptrT fp_bkcd; /* book code */
fptrT fp_pccd; /* book code (packed directed acyclic) */
fptrT fp_bktx; /* book text */
fptrT fp_obfc; /* book text (corrected notation) */
fptrT fp_pctx; /* book text (packed directed acyclic) */
fptrT fp_obmp; /* book move path text */
fptrT fp_obep; /* book move expanded position descriptions */

/* file pointer copies for record I/O */

fptrT fp_get_code; /* code file reading */
fptrT fp_put_code; /* code file writing */

/* the current opening library record */

olrT olr;

/* the current book text input character */

siT bookch;

/* the current book text input character count and line count */

liT bookcn, bookln;

/* the move, corrector, length, and variation totals */

liT booktmn, booktcn, booktln, booktvn;

/* the string version of (an uncorrected) book san move */

sanT bookusm;

/* the string version of a corrected book san move */

sanT bookcsm;

/* the book ordinal stack (ply indexed; generation ordinals) */

siT bkordv[plyL];
siT bkordn;

/* the book variation stack (holds stacked values of -bkordn-) */

siT bkvarv[bkvarL];
siT bkvarn;

/* the one shot flag used in compacted move tree output */

siT bkcmt;

/*<<< bookvars.c: EOF */
