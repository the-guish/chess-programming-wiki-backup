/*>>> initoptn.h: subprogram prototypes for initoptn.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void InitOptions(void);

/*<<< initoptn.h: EOF */
