/*>>> clock.h: subprogram prototypes for clock.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void ClockClear(void);
void ClockUpdate(void);
void ClockStart(void);
void ClockStop(void);
void ClockAMET(void);
void ClockDecode(liT val, char clks[clksL]);
liT ClockRecode(liT val);
void TimeControlReset(void);
siT TimeControlPeriod(void);
void ClockSelectStart(void);
void ClockModifyPonderBudget(void);
siT ClockPastObvious(void);
siT ClockPastNextIteration(void);
siT ClockPastNextCandidate(void);
siT ClockPastMondo(void);
siT CountdownTimerExpired(void);
siT NodeCountdownExpired(void);

/*<<< clock.h: EOF */
