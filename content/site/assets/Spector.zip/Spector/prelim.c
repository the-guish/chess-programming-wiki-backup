/*>>> prelim.c: preliminary evaluation routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bbmacs.h"

#include "bb.h"
#include "chkmrk.h"
#include "eval.h"
#include "exec.h"
#include "moveset.h"
#include "prelim.h"
#include "print.h"
#include "sysutil.h"

/**** Locals */

/* motivation table */

static cpevT prelmotivev[rpL][8] =
	{
		{-4,  -3,  -2,  -1, 0, 1, 2,  3},
		{-8,  -6,  -4,  -2, 0, 2, 4,  6},
		{-12, -9,  -6,  -3, 0, 3, 6,  9},
		{-16, -12, -8,  -4, 0, 4, 8,  12},
		{-20, -15, -10, -5, 0, 5, 10, 15},
		{-24, -18, -12, -6, 0, 6, 12, 18}
	};

/*--> CopyPreliminaries: copy preliminary scores to evaluations */
nonstatic
void
CopyPreliminaries(sptrT sptr)
{
siT index, count;
mptrT mptr;

count = sptr->s_count;
mptr = sptr->s_mbase;
for (index = 0; index < count; index++)
	{
	mptr->m_eval = mptr->m_prel;
	mptr++;
	};

return;
}

/*--> PreliminaryKillerPreset: adjust prel scores for killer heuristics */
static
void
PreliminaryKillerPreset(sptrT sptr)
{
mptrT mptr, pmptr;
gkmptrT gkmptr;
cpevT prel;
sqT tosq, frsq, response_frsq, response_tosq;
smptrT smptr;
bbT bb;
siT i, count;
kmT kmh;
sqT sq, centroid_sq;
siT r_sum, f_sum;
siT fr_taxi, to_taxi;

/* mark obvious checks */

CheckMark(sptr);

/* calculate centroid of passive pieces */

bb = c0bbv[pasc];
r_sum = f_sum = count = 0;
while (bb_next(bb, sq))
	{
	r_sum += map_rank(sq);
	f_sum += map_file(sq);
	count++;
	};
r_sum /= count;
f_sum /= count;
centroid_sq = map_sq(r_sum, f_sum);

/* get killer response best fr/to squares if a prior move exists */

if (((pmptr = sptr->s_mprev) == NULL) || null_move_ref(pmptr))
	response_frsq = response_tosq = sq_nil;
else
	{
	smptr = killer_response_base +
		offset_rcsqsq(actc, pmptr->m_frsq, pmptr->m_tosq);
	response_frsq = smptr->sm_frsq;
	response_tosq = smptr->sm_tosq;
	};

/* set up for group killer move access */

gkmptr = gkm_base + ply;
if (ply < 2)
	kmh.km_frsq = kmh.km_tosq = sq_nil;
else
	kmh = (gkmptr - 2)->gkm_m0;

/* scan each move in moveset */

mptr = sptr->s_mbase;
count = sptr->s_count;
for (i = 0; i < count; i++)
	{
	/* fetch prior preliminary evaluation */

	prel = mptr->m_prel;

	/* process various bonuses for non-certain evaluations */

	if (!(mptr->m_flag & mfm_certain) &&
		(prel < (cpev_mate - ((4 * pval_p) + plyL))))
		{
		/* assign local copies of from/to square coordinates */

		frsq = mptr->m_frsq;
		tosq = mptr->m_tosq;

		/* determine centroid motion bonus */

		if (bb_tstnotsq(acbbv[pasc], tosq))
			{
			fr_taxi = *(taxi_table_base + offset_sqsq(frsq, centroid_sq));
			to_taxi = *(taxi_table_base + offset_sqsq(tosq, centroid_sq));

			if (fr_taxi != to_taxi)
				if (fr_taxi > to_taxi)
					prel++;
				else
					prel--;
			};

		/* process killer moves: primary, secondary, historical */

		if ((tosq == gkmptr->gkm_m0.km_tosq) &&
			(frsq == gkmptr->gkm_m0.km_frsq))
			prel += pval_n / 2;
		else
			if ((tosq == gkmptr->gkm_m1.km_tosq) &&
				(frsq == gkmptr->gkm_m1.km_frsq))
				prel += pval_n / 3;
			else
				if ((tosq == gkmptr->gkm_m2.km_tosq) &&
					(frsq == gkmptr->gkm_m2.km_frsq))
					prel += pval_n / 4;
				else
					if ((tosq == kmh.km_tosq) && (frsq == kmh.km_frsq))
						prel += pval_n / 5;

		/* process killer response move */

		if ((tosq == response_tosq) && (frsq == response_frsq))
			prel += pval_n / 2;

		/* apply check bonus */

		if (mptr->m_flag & mf_chec)
			prel += pval_p / 4;

		/* assign updated NodePlyZero-style evaluation */

		mptr->m_prel = prel;
		};

	/* point to next move */

	mptr++;
	};

return;
}

/*--> PreliminaryEvaluationsPopular: assign popular evaluatations */
nonstatic
void
PreliminaryEvaluationsPopular(sptrT sptr)
{
siT i, count;
mptrT mptr;

/* scan each move in moveset */

mptr = sptr->s_mbase;
count = sptr->s_count;
for (i = 0; i < count; i++)
	{
	/* assign evaluation */

	mptr->m_prel =
		*(killer_pop_base +
		offset_rcsqsq(actc, mptr->m_frsq, mptr->m_tosq));

	/* point to next move */

	mptr++;
	};

return;
}

/*--> PreliminaryEvaluationsPlain: assign plain evaluatations to moveset */
nonstatic
void
PreliminaryEvaluationsPlain(sptrT sptr)
{
mptrT mptr;
mptrT scmptr;
siT i, count;
cpevT prel, maxprel;

/* save the current move pointer */

scmptr = sptr->s_mcurr;

/* set the maximum preliminary score to awful */

maxprel = cpev_bust;

/* scan each move in moveset */

sptr->s_mcurr = sptr->s_mbase;
count = sptr->s_count;
for (i = 0; i < count; i++)
	{
	/* set the move pointer */

	mptr = sptr->s_mcurr;

	/* certain evaluation processing */

	if (mptr->m_flag & (mf_draw | mf_mate | mf_pdrw))
		{
		/* certain evaluation */

		if (mptr->m_flag & mf_mate)
			mptr->m_eval = prel = synth_mate(1) - ply;
		else
			mptr->m_eval = prel = cpev_draw;
		}
	else
		if (mptr->m_flag & mf_orac)
			prel = mptr->m_eval;
		else
			{
			/* full evaluation (if legal) */

			ExecuteMove(mptr);
			if (mptr->m_flag & mf_bust)
				prel = cpev_bust;
			else
				prel = -Evaluate();
			RetractMove(mptr);
			};

	/* assign evaluation */

	mptr->m_prel = prel;

	/* adjust maximum preliminary score */

	if (prel > maxprel)
		maxprel = prel;

	/* point to next move */

	sptr->s_mcurr++;
	};

/* assign q0 */

sptr->s_sflag |= sf_vsq0;
sptr->s_cpeq0 = maxprel;

/* restore the current move pointer */

sptr->s_mcurr = scmptr;

return;
}

/*--> PreliminaryEvaluationsDouble: assign evals to a moveset (minimax) */
nonstatic
void
PreliminaryEvaluationsDouble(sptrT sptr)
{
sptrT dsptr;
mptrT mptr, dmptr, scmptr;
siT i, j, count, dcount;
cpevT prel, dprel;

/* save the current move pointer */

scmptr = sptr->s_mcurr;

/* scan with one level of minimax */

sptr->s_mcurr = sptr->s_mbase;
count = sptr->s_count;
for (i = 0; i < count; i++)
	{
	/* select the move */

	mptr = sptr->s_mcurr;

	/* set default preliminary evaluation for this upper level move */

	prel = cpev_bust;

	/* try move at upper level */

	ExecuteMove(mptr);
	if (!(mptr->m_flag & mf_bust))
		{
		/* evaluate set at next lower level */

		MovesetGenerateConnect(mptr);
		dsptr = mptr->m_dptr;
		PreliminaryEvaluationsPlain(dsptr);
		dcount = dsptr->s_count;
		dmptr = dsptr->s_mbase;
		dprel = cpev_bust;
		for (j = 0; j < dcount; j++)
			{
			if (dmptr->m_prel > dprel)
				dprel = dmptr->m_prel;
			dmptr++;
			};
		if (dprel < -prel)
			prel = -dprel;
		};
	RetractMove(mptr);

	/* assign evaluation */

	mptr->m_prel = prel;

	/* next move */

	sptr->s_mcurr++;
	};

/* restore the current move pointer */

sptr->s_mcurr = scmptr;

return;
}

/*--> PreliminaryEvaluationsBasic: assign evals to a moveset (basic) */
nonstatic
void
PreliminaryEvaluationsBasic(sptrT sptr)
{
siT i, count, motive;
cpevT prel;
mptrT mptr, scmptr;
bbT atkc_pasc_bb, atkd_actc_bb, hung_actc_bb, xchg_actc_bb;

/* save the current move pointer */

scmptr = sptr->s_mcurr;

/* calculate various active/passive bitboards */

if (actc == c_w)
	{
	atkc_pasc_bb = acbbv[c_b];
	bb_and3(acbbv[c_b], c0bbv[c_w], atkd_actc_bb);
	bb_and3(acbbv[c_w], atkd_actc_bb, xchg_actc_bb);
	bb_mask3(acbbv[c_w], atkd_actc_bb, hung_actc_bb);
	}
else
	{
	atkc_pasc_bb = acbbv[c_w];
	bb_and3(acbbv[c_w], c0bbv[c_b], atkd_actc_bb);
	bb_and3(acbbv[c_b], atkd_actc_bb, xchg_actc_bb);
	bb_mask3(acbbv[c_b], atkd_actc_bb, hung_actc_bb);
	};

/* scan each move in moveset */

sptr->s_mcurr = sptr->s_mbase;
count = sptr->s_count;
for (i = 0; i < count; i++)
	{
	/* set up */

	mptr = sptr->s_mcurr;

	/* capture/recapture */

	if (mptr->m_tocp == cp_v0)
		{
		/* noncapture ordering; assign default neutral value */

		motive = 4;

		/* try to move hung and exchangable pieces */

		if (bb_tstsq(hung_actc_bb, mptr->m_frsq))
			motive += 2;
		else
			if (bb_tstsq(xchg_actc_bb, mptr->m_frsq))
				motive += 1;

		/* try not to move to attacked squares */

		if (bb_tstsq(atkc_pasc_bb, mptr->m_tosq))
			motive += -4;

		/* scale according to moving piece kind */

		prel = prelmotivev[cv_p_cpv[mptr->m_frcp]][motive];
		}
	else
		{
		/* capture ordering */

		prel = cpvalv[mptr->m_tocp];
		if (bb_tstsq(atkc_pasc_bb, mptr->m_tosq))
			prel -= cpvalv[mptr->m_frcp];
		};

	/* special case */

	switch (mptr->m_scmv)
		{
		case scmv_reg:
			break;

		case scmv_epc:
			prel += pval_p;
			break;

		case scmv_cks:
			prel += 10;
			break;

		case scmv_cqs:
			prel += 10;
			break;

		case scmv_ppn:
			prel += (pval_n - pval_p);
			break;

		case scmv_ppb:
			prel += (pval_b - pval_p);
			break;

		case scmv_ppr:
			prel += (pval_r - pval_p);
			break;

		case scmv_ppq:
			prel += (pval_q - pval_p);
			break;

		default:
			SwitchFault("PreliminaryEvaluationsQuick");
			break;
		};

	/* assign evaluation */

	mptr->m_prel = prel;

	/* point to next move */

	sptr->s_mcurr++;
	};

/* restore the current move pointer */

sptr->s_mcurr = scmptr;

return;
}

/*--> PreliminaryEvaluationsQuick: assign evals to a moveset (quick) */
nonstatic
void
PreliminaryEvaluationsQuick(sptrT sptr)
{
/* assign basic preliminary scores */

PreliminaryEvaluationsBasic(sptr);

/* process killer heuristics */

PreliminaryKillerPreset(sptr);

return;
}

/*--> PreliminaryEvaluationsCaptureNK: assign evals to a moveset (captures) */
static
void
PreliminaryEvaluationsCaptureNK(sptrT sptr)
{
siT i, count, f0, f1;
cpevT prel;
mptrT mptr, scmptr;
bbT atkc_pasc_bb;

/* save the current move pointer */

scmptr = sptr->s_mcurr;

/* set local copy of merged passive attacks */

atkc_pasc_bb = acbbv[pasc];

/* scan each move in moveset */

sptr->s_mcurr = sptr->s_mbase;
count = sptr->s_count;
for (i = 0; i < count; i++)
	{
	mptr = sptr->s_mcurr;

	/* capture/recapture */

	if (mptr->m_tocp == cp_v0)
		prel = 0;
	else
		{
		prel = cpvalv[mptr->m_tocp];
		f0 = bb_tstsq(atkc_pasc_bb, mptr->m_frsq);
		f1 = bb_tstsq(atkc_pasc_bb, mptr->m_tosq);
		if (f0 && !f1)
			prel += xcpvalv[mptr->m_frcp];
		else
			if (!f0 && f1)
				prel -= xcpvalv[mptr->m_frcp];
		};

	/* special case */

	switch (mptr->m_scmv)
		{
		case scmv_reg:
			break;

		case scmv_epc:
			prel += pval_p;
			break;

		case scmv_cks:
			break;

		case scmv_cqs:
			break;

		case scmv_ppn:
			prel += (pval_n - pval_p);
			break;

		case scmv_ppb:
			prel += (pval_b - pval_p);
			break;

		case scmv_ppr:
			prel += (pval_r - pval_p);
			break;

		case scmv_ppq:
			prel += (pval_q - pval_p);
			break;

		default:
			SwitchFault("PreliminaryEvaluationsCapture");
			break;
		};

	/* assign NodeCapture-style evaluation */

	mptr->m_prel = prel;

	/* point to next move */

	sptr->s_mcurr++;
	};

/* restore the current move pointer */

sptr->s_mcurr = scmptr;

return;
}

/*--> PreliminaryEvaluationsCapture: assign evals to a moveset (captures) */
nonstatic
void
PreliminaryEvaluationsCapture(sptrT sptr)
{
PreliminaryEvaluationsCaptureNK(sptr);
PreliminaryKillerPreset(sptr);

return;
}

/*--> PreliminaryEvaluationsSetUp: assign prelims (full) and sort */
nonstatic
void
PreliminaryEvaluationsSetUp(sptrT sptr)
{
/* generate preliminary evaluations */

PreliminaryEvaluationsPlain(sptr);

/* ply zero sort by descending m_prel scores */

MovesetSortPreliminaries(sptr);

/* rethread descendant movesets following sort */

MovesetRethread(sptr);

/* set default value for best move pointer */

if (sptr->s_count > 0)
	sptr->s_mbest = sptr->s_mbase;
else
	sptr->s_mbest = NULL;

return;
}

/*<<< prelim.c: EOF */
