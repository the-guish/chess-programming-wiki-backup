/*>>> util.c: utility routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "file.h"
#include "memutil.h"
#include "sysutil.h"
#include "util.h"

#if (os_mac)
#include <unix.h>
#endif

/**** Locals */

/* type for short conversion */

typedef union cvsiU
	{
	siT   cvsi_si;
	byteT cvsi_bv[2];
	} cvsiT;

/* type for long conversion */

typedef union cvliU
	{
	liT   cvli_li;
	byteT cvli_bv[4];
	} cvliT;

/* the psuedorandom generator seed */

static uliT psuedorandom_seed = 1L;

/* the SI multiplier prefix and the scaled value */

static char simpv[4];
static lrT sicval;

/*--> ReverseLI: reverse byte sequence in a long integer */
nonstatic
liT
ReverseLI(liT value)
{
cvliT cvli0, cvli1;

cvli0.cvli_li = value;

cvli1.cvli_bv[0] = cvli0.cvli_bv[3];
cvli1.cvli_bv[1] = cvli0.cvli_bv[2];
cvli1.cvli_bv[2] = cvli0.cvli_bv[1];
cvli1.cvli_bv[3] = cvli0.cvli_bv[0];

return (cvli1.cvli_li);
}

/*--> ConvFrCSI: convert from canonical two byte integer format */
nonstatic
siT
ConvFrCSI(siT value)
{
siT result;
cvsiT cvsi;

cvsi.cvsi_si = value;

result =
	(cvsi.cvsi_bv[0] << (0 * byteW)) |
	(cvsi.cvsi_bv[1] << (1 * byteW));

return (result);
}

/*--> ConvToCSI: convert to canonical two byte integer format */
nonstatic
siT
ConvToCSI(siT value)
{
cvsiT cvsi;

cvsi.cvsi_bv[0] = (value >> (0 * byteW)) & byteM;
cvsi.cvsi_bv[1] = (value >> (1 * byteW)) & byteM;

return (cvsi.cvsi_si);
}

/*--> ConvToCLI: convert to canonical four byte integer format */
nonstatic
liT
ConvToCLI(liT value)
{
cvliT cvli;

cvli.cvli_bv[0] = (value >> (0 * byteW)) & byteM;
cvli.cvli_bv[1] = (value >> (1 * byteW)) & byteM;
cvli.cvli_bv[2] = (value >> (2 * byteW)) & byteM;
cvli.cvli_bv[3] = (value >> (3 * byteW)) & byteM;

return (cvli.cvli_li);
}

/*--> ConvFrCLI: convert from canonical four byte integer format */
nonstatic
liT
ConvFrCLI(liT value)
{
liT result;
cvliT cvli;

cvli.cvli_li = value;

result =
	(cvli.cvli_bv[0] << (0 * byteW)) |
	(cvli.cvli_bv[1] << (1 * byteW)) |
	(cvli.cvli_bv[2] << (2 * byteW)) |
	(cvli.cvli_bv[3] << (3 * byteW));

return (result);
}

/*--> EncodeHexLong: encode a four byte hexidecimal number */
nonstatic
void
EncodeHexLong(liT val, charptrT ptr)
{
siT i;
char bv[9];
charptrT p;

p = ptr;
sprintf(bv, "%08lx", val);
for (i = 0; i < 8; i++)
	*p++ = map_lower(bv[i]);

return;
}

/*--> LRSIC: long real SI conversion */
static
void
LRSIC(lrT val)
{
if (val >= 1.0e+9)
	{
	sicval = val * 1.0e-9;
	(void) strcpy(simpv, "G");
	}
else
	if (val >= 1.0e+6)
		{
		sicval = val * 1.0e-6;
		(void) strcpy(simpv, "M");
		}
	else
		if (val >= 1.0e+3)
			{
			sicval = val * 1.0e-3;
			(void) strcpy(simpv, "K");
			}
		else
			if ((val >= 1.0e+0) || (val == 0.0))
				{
				sicval = val * 1.0e+0;
				(void) strcpy(simpv, "");
				}
			else
				if (val >= 1.0e-3)
					{
					sicval = val * 1.0e+3;
					(void) strcpy(simpv, "m");
					}
				else
					if (val >= 1.0e-6)
						{
						sicval = val * 1.0e+6;
						(void) strcpy(simpv, "u");
						}
					else
						{
						sicval = val * 1.0e+9;
						(void) strcpy(simpv, "n");
						};

return;
}

/*--> FormatSTVLQF: format a long integer quotient frequency in the STV */
nonstatic
void
FormatSTVLQF(liT num, liT den)
{
lrT q;

q = ((lrT) num) / ((lrT) den);
LRSIC(q);
(void) sprintf(stv, "%.3f %sHz", sicval, simpv);

return;
}

/*--> FormatSTVLQI: format a long integer quotient interval in the STV */
nonstatic
void
FormatSTVLQI(liT num, liT den)
{
lrT q;

q = ((lrT) num) / ((lrT) den);
LRSIC(q);
(void) sprintf(stv, "%.3f %ss", sicval, simpv);

return;
}

/*--> FormatSTVLQR: format a long integer quotient ratio in the STV */
nonstatic
void
FormatSTVLQR(liT num, liT den)
{
lrT q;

q = ((lrT) num) / ((lrT) den);
(void) sprintf(stv, "%.3f", q);

return;
}

/*--> ZapBytes: clear memory */
nonstatic
void
ZapBytes(voidptrT p, allocT n)
{
allocT i;
charptrT q;

q = (charptrT) p;
for (i = 0; i < n; i++)
	*q++ = ascii_nul;

return;
}

/*--> ByteCmp: compare n bytes */
nonstatic
siT
ByteCmp(voidptrT p0, voidptrT p1, allocT n)
{
siT flag, v0, v1;
allocT i;

flag = 0;
i = 0;

while ((flag == 0) && (i < n))
	{
	v0 = *(((charptrT) p0) + i) & byteM;
	v1 = *(((charptrT) p1) + i) & byteM;
	if (v0 == v1)
		i++;
	else
		if (v0 < v1)
			flag = -1;
		else
			flag = 1;
	};

return (flag);
}

/*--> AbsSI: short integer absolute value */
nonstatic
siT
AbsSI(siT x)
{

return ((x > 0) ? x : -x);
}

/*--> MaxLI: return maximum of two long integers */
nonstatic
liT
MaxLI(liT i, liT j)
{

return ((i > j) ? i : j);
}

/*--> MinLI: return minimum of two long integers */
nonstatic
liT
MinLI(liT i, liT j)
{

return ((i < j) ? i : j);
}

/*--> IdentChar: return identifier character status */
nonstatic
siT
IdentChar(siT c)
{
siT flag;

if ((c < 0) || (c > 255))
	flag = 0;
else
	if (isalpha(c) || isdigit(c) || (c == '_'))
		flag = 1;
	else
		flag = 0;

return (flag);
}

/*--> CICharEqual: case independent character equality test */
nonstatic
siT
CICharEqual(char c0, char c1)
{
siT cmp;

if (map_lower(c0) == map_lower(c1))
	cmp = 1;
else
	cmp = 0;

return (cmp);
}

/*--> CIStrEqual: staged case independent string equality test */
nonstatic
siT
CIStrEqual(charptrT s0, charptrT s1)
{
siT cmp, c0, c1;

cmp = 0;
if ((s0 == NULL) || (s1 == NULL))
	Diagnose("CIStrEqual: bad input");
else
	if ((s0 == s1) || (strcmp(s0, s1) == 0))
		cmp = 1;
	else
		if (strlen(s0) != strlen(s1))
			cmp = 0;
		else
			{
			cmp = 1;
			while (cmp && (*s0 != ascii_nul))
				{
				c0 = *s0++;
				c1 = *s1++;
				cmp = CICharEqual(c0, c1);
				};
			};

return (cmp);
}

/*--> PsuedoRandomNonNegativeWord: psuedorandom positive 16 bit word */
static
siT
PsuedoRandomNonNegativeWord(void)
{
psuedorandom_seed = (psuedorandom_seed * 1103515245L) + 12345L;

return ((siT) ((psuedorandom_seed >> wordW) & 0x7fff));
}

/*--> PsuedoRandomByte: return psuedorandom 8 bit byte (in a word) */
nonstatic
siT
PsuedoRandomByte(void)
{

return ((PsuedoRandomNonNegativeWord() >> nybbW) & byteM);
}

/*--> PsuedoRandomWord: return psuedorandom 16 bit word (in a long word) */
nonstatic
liT
PsuedoRandomWord(void)
{
liT n;

n = (((liT) PsuedoRandomByte()) << byteW) |
	((liT) PsuedoRandomByte());

return (n);
}

/*--> PsuedoRandomLongWord: return psuedorandom 32 bit word */
nonstatic
liT
PsuedoRandomLongWord(void)
{
liT n;

n = (PsuedoRandomWord() << wordW) | (PsuedoRandomWord() & longwordM);

return (n);
}

/*--> TBPsuedoRandomLI: time based pseudorandom positive long integer */
nonstatic
liT
TBPsuedoRandomLI(void)
{
liT n;
liT v0, v1, v2, v3;

v0 = ((rand() >> nybbW) & byteM);
v1 = ((rand() >> nybbW) & byteM);
v2 = ((rand() >> nybbW) & byteM);
v3 = ((rand() >> nybbW) & byteM);

n = (v3 << (3 * nybbW)) | (v3 << (2 * nybbW)) | (v3 << (1 * nybbW)) | v3;
n &= 0x7fffffffL;

return (n);
}

/*--> BCBGrab: initialize (allocate) a general I/O buffer */
nonstatic
void
BCBGrab(bcbptrT bcbptr, liT length)
{
bcbptr->bcb_base = (byteptrT) MemoryGrab(length);
bcbptr->bcb_count = 0;
bcbptr->bcb_length = length;

return;
}

/*--> BCBFree: terminate (deallocate fields) a general I/O buffer */
nonstatic
void
BCBFree(bcbptrT bcbptr)
{
MemoryFree(bcbptr->bcb_base);
bcbptr->bcb_base = NULL;
bcbptr->bcb_count = 0;
bcbptr->bcb_length = 0;

return;
}

/*<<< util.c: EOF */
