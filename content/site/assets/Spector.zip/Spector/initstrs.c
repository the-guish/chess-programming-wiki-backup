/*>>> initstrs.c: initialize string vectors */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "initstrs.h"

/*--> InitStrs: set up string vectors */
nonstatic
void
InitStrs(void)
{
/* set up language strings */

langstrv[lang_deutsch   ] = "deutsch";
langstrv[lang_english   ] = "english";
langstrv[lang_espanol   ] = "espanol";
langstrv[lang_fide      ] = "fide";
langstrv[lang_francais  ] = "francais";
langstrv[lang_italiano  ] = "italiano";
langstrv[lang_nederlands] = "nederlands";
langstrv[lang_svenska   ] = "svenska";

/* set up color strings */

cstrv[c_w] = "white";
cstrv[c_b] = "black";

/* set up piece strings */

pstrv[p_p] = "pawn";
pstrv[p_n] = "knight";
pstrv[p_b] = "bishop";
pstrv[p_r] = "rook";
pstrv[p_q] = "queen";
pstrv[p_k] = "king";
pstrv[p_v] = "vacant";
pstrv[p_x] = "border";

/* set up special case move indication strings */

scmvstrv[scmv_reg] = "reg";
scmvstrv[scmv_epc] = "epc";
scmvstrv[scmv_cks] = "cks";
scmvstrv[scmv_cqs] = "cqs";
scmvstrv[scmv_ppn] = "ppn";
scmvstrv[scmv_ppb] = "ppb";
scmvstrv[scmv_ppr] = "ppr";
scmvstrv[scmv_ppq] = "ppq";

/* set up moveset flag strings */

sflagstrv[sfi_abbo] = "abbo";
sflagstrv[sfi_capt] = "capt";
sflagstrv[sfi_cdmm] = "cdmm";
sflagstrv[sfi_cert] = "cert";
sflagstrv[sfi_cnpd] = "cnpd";
sflagstrv[sfi_dsam] = "dsam";
sflagstrv[sfi_exec] = "exec";
sflagstrv[sfi_full] = "full";
sflagstrv[sfi_gcon] = "gcon";
sflagstrv[sfi_mark] = "mark";
sflagstrv[sfi_plcd] = "plcd";
sflagstrv[sfi_sing] = "sing";
sflagstrv[sfi_vsq0] = "vsq0";
sflagstrv[sfi_vsq1] = "vsq1";

/* set up move flag strings */

mflagstrv[mfi_anfp] = "anfp";
mflagstrv[mfi_anrp] = "anrp";
mflagstrv[mfi_book] = "book";
mflagstrv[mfi_bust] = "bust";
mflagstrv[mfi_chec] = "chec";
mflagstrv[mfi_draw] = "draw";
mflagstrv[mfi_exec] = "exec";
mflagstrv[mfi_mark] = "mark";
mflagstrv[mfi_mate] = "mate";
mflagstrv[mfi_null] = "null";
mflagstrv[mfi_orac] = "orac";
mflagstrv[mfi_pdrw] = "pdrw";
mflagstrv[mfi_poor] = "poor";
mflagstrv[mfi_pthr] = "pthr";
mflagstrv[mfi_srch] = "srch";
mflagstrv[mfi_xtra] = "xtra";

/* set up search termination reason code strings */

strcstrv[strc_none] = "no reason, or nonterminated search";
strcstrv[strc_bigl] = "big loss detected";
strcstrv[strc_bigw] = "big win detected";
strcstrv[strc_book] = "book move located";
strcstrv[strc_cert] = "certain move located";
strcstrv[strc_frcd] = "forced move located";
strcstrv[strc_full] = "full search completed";
strcstrv[strc_intr] = "interrupted and not resumed";
strcstrv[strc_iter] = "iteration level limit";
strcstrv[strc_mate] = "mating move located";
strcstrv[strc_node] = "node limit";
strcstrv[strc_obvs] = "obvious move located";
strcstrv[strc_save] = "saving drawing move located";
strcstrv[strc_sing] = "single move exists";
strcstrv[strc_targ] = "target move located";
strcstrv[strc_time] = "general time expiration";

/* set up game status strings */

gsstrv[gs_norm] = "Legal position";
gsstrv[gs_bust] = "Illegal position";
gsstrv[gs_wkcm] = "White is checkmated";
gsstrv[gs_bkcm] = "Black is checkmated";
gsstrv[gs_wksm] = "White is stalemated";
gsstrv[gs_bksm] = "Black is stalemated";
gsstrv[gs_hmvc] = "Fifty move rule draw";
gsstrv[gs_rep3] = "Three time repetition draw";
gsstrv[gs_imat] = "Insufficient material draw";
gsstrv[gs_wres] = "White resigns";
gsstrv[gs_bres] = "Black resigns";
gsstrv[gs_adrw] = "Draw agreed";
gsstrv[gs_over] = "** PROGRAM OVERFLOW **";

/* set up short game status strings */

sgsstrv[gs_norm] = "norm";
sgsstrv[gs_bust] = "bust";
sgsstrv[gs_wkcm] = "wkcm";
sgsstrv[gs_bkcm] = "bkcm";
sgsstrv[gs_wksm] = "wksm";
sgsstrv[gs_bksm] = "bksm";
sgsstrv[gs_hmvc] = "hmvc";
sgsstrv[gs_rep3] = "rep3";
sgsstrv[gs_imat] = "imat";
sgsstrv[gs_wres] = "wres";
sgsstrv[gs_bres] = "bres";
sgsstrv[gs_adrw] = "adrw";
sgsstrv[gs_over] = "over";

/* set up game termination input marker strings */

gtimstrv[gtim_none] = "*";
gtimstrv[gtim_drw0] = "1/2-1/2";
gtimstrv[gtim_drw1] = "1/2";
gtimstrv[gtim_drw2] = "1-2";
gtimstrv[gtim_drw3] = "draw";
gtimstrv[gtim_drw4] = "drawn";
gtimstrv[gtim_wwn0] = "1-0";
gtimstrv[gtim_wwn1] = "1/0";
gtimstrv[gtim_wwn2] = "1:0";
gtimstrv[gtim_bwn0] = "0-1";
gtimstrv[gtim_bwn1] = "0/1";
gtimstrv[gtim_bwn2] = "0:1";
gtimstrv[gtim_res0] = "resign";
gtimstrv[gtim_res1] = "resigns";

/* set up game termination output marker strings */

gtomstrv[gtom_none] = gtimstrv[gtim_none];
gtomstrv[gtom_draw] = gtimstrv[gtim_drw0];
gtomstrv[gtom_wwin] = gtimstrv[gtim_wwn0];
gtomstrv[gtom_bwin] = gtimstrv[gtim_bwn0];

/* set up notation mode strings */

nmstrv[nm_algebraic ] = "algebraic";
nmstrv[nm_coordinate] = "coordinate";
nmstrv[nm_exp0      ] = "exp0";
nmstrv[nm_exp1      ] = "exp1";
nmstrv[nm_exp2      ] = "exp2";
nmstrv[nm_exp3      ] = "exp3";
nmstrv[nm_exp4      ] = "exp4";
nmstrv[nm_exp5      ] = "exp5";

/* set up strategy name strings */

strtstrv[strt_knowbs] = "knowbs";
strtstrv[strt_privar] = "privar";
strtstrv[strt_random] = "random";
strtstrv[strt_testds] = "testds";

/* ordinals: unit vector */

ord_unitv[0] = "zero";
ord_unitv[1] = "one";
ord_unitv[2] = "two";
ord_unitv[3] = "three";
ord_unitv[4] = "four";
ord_unitv[5] = "five";
ord_unitv[6] = "six";
ord_unitv[7] = "seven";
ord_unitv[8] = "eight";
ord_unitv[9] = "nine";

/* ordinals: tens vector */

ord_tensv[0] = "";
ord_tensv[1] = "ten";
ord_tensv[2] = "twenty";
ord_tensv[3] = "thirty";
ord_tensv[4] = "forty";
ord_tensv[5] = "fifty";
ord_tensv[6] = "sixty";
ord_tensv[7] = "seventy";
ord_tensv[8] = "eighty";
ord_tensv[9] = "ninety";

/* ordinals: teen vector */

ord_teenv[0] = "ten";
ord_teenv[1] = "eleven";
ord_teenv[2] = "twelve";
ord_teenv[3] = "thirteen";
ord_teenv[4] = "fourteen";
ord_teenv[5] = "fifteen";
ord_teenv[6] = "sixteen";
ord_teenv[7] = "seventeen";
ord_teenv[8] = "eighteen";
ord_teenv[9] = "nineteen";

/* phonentic strings: color */

phs_cv[c_w] = "!C w uh3 ah2 y t !T";
phs_cv[c_b] = "!C b l ae1 ae1 k !T";

/* phonentic strings: piece */

phs_pv[p_p] = "!C p aw1 n !T";
phs_pv[p_n] = "!C n ah2 y t !T";
phs_pv[p_b] = "!C b i1 i2 sh ah p !T";
phs_pv[p_r] = "!C r oo k !T";
phs_pv[p_q] = "!C k w e1 n !T";
phs_pv[p_k] = "!C k i1 i3 ng !T";
phs_pv[p_v] = "";
phs_pv[p_x] = "";

/* phonentic strings: ranks */

phs_rv[rank_1] = "1";
phs_rv[rank_2] = "2";
phs_rv[rank_3] = "3";
phs_rv[rank_4] = "4";
phs_rv[rank_5] = "5";
phs_rv[rank_6] = "6";
phs_rv[rank_7] = "7";
phs_rv[rank_8] = "8";

/* phonentic strings: files */

phs_fv[file_a] = "!E a !T";
phs_fv[file_b] = "!E b !T";
phs_fv[file_c] = "!E c !T";
phs_fv[file_d] = "!E d !T";
phs_fv[file_e] = "!E e !T";
phs_fv[file_f] = "!E f !T";
phs_fv[file_g] = "!E g !T";
phs_fv[file_h] = "!E h !T";

return;
}

/*<<< initstrs.c: EOF */
