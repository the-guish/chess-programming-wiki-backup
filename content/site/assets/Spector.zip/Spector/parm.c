/*>>> parm.c: command parameter processing routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "commdefs.h"
#include "commvars.h"

#include "parm.h"
#include "sysutil.h"
#include "util.h"

/*--> ParameterCheckColor: parameter check (color) */
nonstatic
siT
ParameterCheckColor(siT ch)
{
siT flag;

if (CICharEqual(ch, asccv[lang_san][c_w]) ||
	CICharEqual(ch, asccv[lang_san][c_b]))
	flag = 1;
else
	flag = 0;

return (flag);
}

/*--> ParameterEvalColor: parameter evaluate (color) */
nonstatic
cT
ParameterEvalColor(siT ch)
{
cT c;

if (CICharEqual(ch, asccv[lang_san][c_w]))
	c = c_w;
else
	c = c_b;

return (c);
}

/*--> ParameterCheckFile: parameter check (file) */
nonstatic
siT
ParameterCheckFile(siT ch)
{
siT flag;
fileT file;

file = file_a;
flag = 0;
while (!flag && (file <= file_h))
	if (CICharEqual(ch, ascfv[file]))
		flag = 1;
	else
		file++;

return (flag);
}

/*--> ParameterEvalFile: parameter evaluate (file) */
nonstatic
fileT
ParameterEvalFile(siT ch)
{
fileT file;
siT flag;

flag = 1;
file = file_a;
while (flag)
	if (CICharEqual(ch, ascfv[file]))
		flag = 0;
	else
		file++;

return (file);
}

/*--> ParameterCheckLanguage: parameter check (lang) */
static
siT
ParameterCheckLanguage(charptrT s)
{
siT flag;
langT lang;

flag = 0;
lang = 0;
while (!flag && (lang < langL))
	if (CIStrEqual(s, langstrv[lang]))
		flag = 1;
	else
		lang++;

return (flag);
}

/*--> ParameterEvalLanguage: parameter evaluate (lang) */
static
langT
ParameterEvalLanguage(charptrT s)
{
langT lang;
siT flag;

flag = 0;
lang = 0;
while (!flag && (lang < langL))
	if (CIStrEqual(s, langstrv[lang]))
		flag = 1;
	else
		lang++;

return (lang);
}

/*--> ParameterCheckLI: parameter check (long integer) */
static
siT
ParameterCheckLI(charptrT s)
{
siT flag, i;

i = 0;
flag = 1;
while (flag && (*(s + i) != ascii_nul))
	{
	flag = (isdigit(*(s + i)) ? 1 : 0);
	if (flag)
		i++;
	};

return (flag);
}

/*--> ParameterEvalLI: parameter evaluate (long integer) */
static
liT
ParameterEvalLI(charptrT s)
{
liT li, i;

li = 0;
i = 0;
while (*(s + i) != ascii_nul)
	{
	li *= ten;
	li += *(s + i) - ascii_zero;
	i++;
	};

return (li);
}

/*--> ParameterCheckNotationMode: parameter check (nm) */
static
siT
ParameterCheckNotationMode(charptrT s)
{
siT flag;
nmT nm;

flag = 0;
nm = 0;
while (!flag && (nm < nmL))
	if (CIStrEqual(s, nmstrv[nm]))
		flag = 1;
	else
		nm++;

return (flag);
}

/*--> ParameterEvalNotationMode: parameter evaluate (nm) */
static
nmT
ParameterEvalNotationMode(charptrT s)
{
nmT nm;
siT flag;

flag = 0;
nm = 0;
while (!flag && (nm < nmL))
	if (CIStrEqual(s, nmstrv[nm]))
		flag = 1;
	else
		nm++;

return (nm);
}

/*--> ParameterCheckOption: parameter check (optn) */
static
siT
ParameterCheckOption(charptrT s)
{
siT flag;
optnT optn;

flag = 0;
optn = 0;
if (strlen(s) == optnnameL)
	while (!flag && (optn < optnL))
	if (strcmp(s, optnstrv[optn]) == 0)
			flag = 1;
		else
			optn++;

return (flag);
}

/*--> ParameterEvalOption: parameter evaluate (optn) */
static
optnT
ParameterEvalOption(charptrT s)
{
optnT optn;
siT flag;

flag = 0;
optn = 0;
while (!flag && (optn < optnL))
	if (strcmp(s, optnstrv[optn]) == 0)
		flag = 1;
	else
		optn++;

return (optn);
}

/*--> ParameterCheckPiece: parameter check (piece) */
nonstatic
siT
ParameterCheckPiece(siT ch)
{
siT flag;
pT p;

p = p_p;
flag = 0;
while (!flag && (p <= p_k))
	if (CICharEqual(ch, ascpv[lang_san][p]))
		flag = 1;
	else
		p++;

return (flag);
}

/*--> ParameterEvalPiece: parameter evaluate (piece) */
nonstatic
pT
ParameterEvalPiece(siT ch)
{
pT p;
siT flag;

flag = 1;
p = p_p;
while (flag)
	if (CICharEqual(ch, ascpv[lang_san][p]))
		flag = 0;
	else
		p++;

return (p);
}

/*--> ParameterCheckRank: parameter check (rank) */
nonstatic
siT
ParameterCheckRank(siT ch)
{
siT flag;
rankT rank;

rank = rank_1;
flag = 0;
while (!flag && (rank <= rank_8))
	if (CICharEqual(ch, ascrv[rank]))
		flag = 1;
	else
		rank++;

return (flag);
}

/*--> ParameterEvalRank: parameter evaluate (rank) */
nonstatic
rankT
ParameterEvalRank(siT ch)
{
rankT rank;
siT flag;

flag = 1;
rank = rank_1;
while (flag)
	if (CICharEqual(ch, ascrv[rank]))
		flag = 0;
	else
		rank++;

return (rank);
}

/*--> ParameterCheckSI: parameter check (short integer) */
nonstatic
siT
ParameterCheckSI(charptrT s)
{
siT flag, i;

i = 0;
flag = 1;
while (flag && (*(s + i) != ascii_nul))
	{
	flag = (isdigit(*(s + i)) ? 1 : 0);
	if (flag)
		i++;
	};

return (flag);
}

/*--> ParameterEvalSI: parameter evaluate (short integer) */
nonstatic
siT
ParameterEvalSI(charptrT s)
{
siT si, i;

si = 0;
i = 0;
while (*(s + i) != ascii_nul)
	{
	si *= ten;
	si += *(s + i) - ascii_zero;
	i++;
	};

return (si);
}

/*--> ParameterCheckSquare: parameter check (sq) */
nonstatic
siT
ParameterCheckSquare(charptrT s)
{
siT flag;

if ((strlen(s) == 2) &&
	ParameterCheckFile(*(s + 0)) && ParameterCheckRank(*(s + 1)))
	flag = 1;
else
	flag = 0;

return (flag);
}

/*--> ParameterEvalSquare: parameter evaluate (sq) */
nonstatic
sqT
ParameterEvalSquare(charptrT s)
{
sqT sq;

sq = map_sq(ParameterEvalRank(*(s + 1)), ParameterEvalFile(*(s + 0)));

return (sq);
}

/*--> ParameterCheckStrategy: parameter check (strt) */
static
siT
ParameterCheckStrategy(charptrT s)
{
siT flag;
strtT strt;

flag = 0;
strt = 0;
while (!flag && (strt < strtL))
	if (CIStrEqual(s, strtstrv[strt]))
		flag = 1;
	else
		strt++;

return (flag);
}

/*--> ParameterEvalStrategy: parameter evaluate (strt) */
static
strtT
ParameterEvalStrategy(charptrT s)
{
strtT strt;
siT flag;

flag = 0;
strt = 0;
while (!flag && (strt < strtL))
	if (CIStrEqual(s, strtstrv[strt]))
		flag = 1;
	else
		strt++;

return (strt);
}

/*--> ParameterCheck: determine if parameter string has correct syntax */
nonstatic
siT
ParameterCheck(commT commid, siT i)
{
siT flag, len;
charptrT ptr;

/* set up */

flag = 0;
ptr = tkv[i];
len = strlen(ptr);

/* process according to class */

switch (crv[commid].cr_parc)
	{
	case parc_none:
		flag = 1;
		break;

	case parc_c:
		if (len != 1)
			flag = 0;
		else
			flag = ParameterCheckColor(ptr[0]);
		break;

	case parc_cai:
		if (len != 2)
			flag = 0;
		else
			if (!CICharEqual(ptr[0], asccv[lang_san][c_w]) &&
				!CICharEqual(ptr[0], asccv[lang_san][c_b]))
				flag = 0;
			else
				if (!CICharEqual(ptr[1], ascpv[lang_san][p_k]) &&
					!CICharEqual(ptr[1], ascpv[lang_san][p_q]))
					flag = 0;
				else
					flag = 1;
		break;

	case parc_cpsq:
		if (len != 4)
			flag = 0;
		else
			if (ParameterCheckColor(ptr[0]) && ParameterCheckPiece(ptr[1]) &&
				ParameterCheckFile(ptr[2]) && ParameterCheckRank(ptr[3]))
				flag = 1;
			else
				flag = 0;
		break;

	case parc_lint:
		flag = ParameterCheckLI(ptr);
		break;

	case parc_lang:
		flag = ParameterCheckLanguage(ptr);
		break;

	case parc_nm:
		flag = ParameterCheckNotationMode(ptr);
		break;

	case parc_optn:
		flag = ParameterCheckOption(ptr);
		break;

	case parc_sint:
		flag = ParameterCheckSI(ptr);
		break;

	case parc_sq:
		flag = ParameterCheckSquare(ptr);
		break;

	case parc_str:
		flag = 1;
		break;

	case parc_strt:
		flag = ParameterCheckStrategy(ptr);
		break;

	default:
		SwitchFault("ParameterCheck");
		break;
	};

return (flag);
}

/*--> ParameterEval: evaluate correct parameter string */
nonstatic
void
ParameterEval(commT commid, siT i)
{
charptrT ptr;

/* set up */

ptr = tkv[i];

/* process according to class */

switch (crv[commid].cr_parc)
	{
	case parc_none:
		break;

	case parc_c:
		ipv[i].ip_c = ParameterEvalColor(ptr[0]);
		break;

	case parc_cai:
		if (CICharEqual(ptr[0], asccv[lang_san][c_w]))
			if (CICharEqual(ptr[1], ascpv[lang_san][p_k]))
				ipv[i].ip_cai = cf_wk;
			else
				ipv[i].ip_cai = cf_wq;
		else
			if (CICharEqual(ptr[1], ascpv[lang_san][p_k]))
				ipv[i].ip_cai = cf_bk;
			else
				ipv[i].ip_cai = cf_bq;
		break;

	case parc_cpsq:
		ipv[i].ip_cpsq.cpsq_cp = cv_cp_c_pv
			[ParameterEvalColor(ptr[0])][ParameterEvalPiece(ptr[1])];
		ipv[i].ip_cpsq.cpsq_sq =
			map_sq(ParameterEvalRank(ptr[3]), ParameterEvalFile(ptr[2]));
		break;

	case parc_lang:
		ipv[i].ip_lang = ParameterEvalLanguage(ptr);
		break;

	case parc_lint:
		ipv[i].ip_lint = ParameterEvalLI(ptr);
		break;

	case parc_nm:
		ipv[i].ip_nm = ParameterEvalNotationMode(ptr);
		break;

	case parc_optn:
		ipv[i].ip_optn = ParameterEvalOption(ptr);
		break;

	case parc_sint:
		ipv[i].ip_sint = ParameterEvalSI(ptr);
		break;

	case parc_sq:
		ipv[i].ip_sq = ParameterEvalSquare(ptr);
		break;

	case parc_str:
		ipv[i].ip_str = ptr;
		break;

	case parc_strt:
		ipv[i].ip_strt = ParameterEvalStrategy(ptr);
		break;

	default:
		SwitchFault("ParameterEval");
		break;
	};

return;
}

/*<<< parm.c: EOF */
