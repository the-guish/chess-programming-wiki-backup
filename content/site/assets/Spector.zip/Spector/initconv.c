/*>>> initconv.c: initialize conversion vectors */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "initconv.h"

/*--> InitLanguageVector: initialize ascii conversion for a language */
static
void
InitLanguageVector(langT lang, charptrT s)
{
/* colors */

asccv[lang][c_w] = *(s + 0);
asccv[lang][c_b] = *(s + 1);
asccv[lang][c_v] = ascii_sp;
asccv[lang][c_x] = '?';

/* pieces */

ascpv[lang][p_p] = *(s + 7);
ascpv[lang][p_n] = *(s + 6);
ascpv[lang][p_b] = *(s + 5);
ascpv[lang][p_r] = *(s + 4);
ascpv[lang][p_q] = *(s + 3);
ascpv[lang][p_k] = *(s + 2);
ascpv[lang][p_v] = ascii_sp;
ascpv[lang][p_x] = '?';

return;
}

/*--> InitConversions: set up conversion vectors */
nonstatic
void
InitConversions(void)
{
rankT rank;
fileT file;
cpT cp;
siT i;

/* initializ the ascii conversion vectors */

InitLanguageVector(lang_deutsch,    "wsKDTLSB");
InitLanguageVector(lang_english,    "wbKQRBNP");
InitLanguageVector(lang_espanol,    "bnRSTACP");
InitLanguageVector(lang_fide,       "wbKQRBNP");
InitLanguageVector(lang_francais,   "bnRDTFCP");
InitLanguageVector(lang_italiano,   "bnRDTACP");
InitLanguageVector(lang_nederlands, "wzKDTLPO");
InitLanguageVector(lang_svenska,    "vsKDTLHB");

/* initialize the rank character translation vector */

for (rank = rank_1; rank <= rank_8; rank++)
	ascrv[rank] = (char) (rank + '1');

/* initialize the file character translation vector */

for (file = file_a; file <= file_h; file++)
	ascfv[file] = (char) (file + 'a');

/* initialize the hex digit conversion vector */

for (i = 0; i < ten; i++)
	cv_ahc_iv[i] = '0' + i;
for (i = ten; i < 16; i++)
	cv_ahc_iv[i] = 'a' + i - ten;

/* initialize the color from color-piece conversion vector */

for (cp = cp_wp; cp <= cp_wk; cp++)
	cv_c_cpv[cp] = c_w;
for (cp = cp_bp; cp <= cp_bk; cp++)
	cv_c_cpv[cp] = c_b;
cv_c_cpv[cp_v0] = c_v;
cv_c_cpv[cp_x0] = c_x;

/* initialize the piece from color-piece conversion vector */

cv_p_cpv[cp_wp] = cv_p_cpv[cp_bp] = p_p;
cv_p_cpv[cp_wn] = cv_p_cpv[cp_bn] = p_n;
cv_p_cpv[cp_wb] = cv_p_cpv[cp_bb] = p_b;
cv_p_cpv[cp_wr] = cv_p_cpv[cp_br] = p_r;
cv_p_cpv[cp_wq] = cv_p_cpv[cp_bq] = p_q;
cv_p_cpv[cp_wk] = cv_p_cpv[cp_bk] = p_k;

cv_p_cpv[cp_v0] = p_v;
cv_p_cpv[cp_x0] = p_x;

/* initialize color-piece vector from restricted-color-piece vector */

cv_cp_c_pv[c_w][p_p] = cp_wp;
cv_cp_c_pv[c_w][p_n] = cp_wn;
cv_cp_c_pv[c_w][p_b] = cp_wb;
cv_cp_c_pv[c_w][p_r] = cp_wr;
cv_cp_c_pv[c_w][p_q] = cp_wq;
cv_cp_c_pv[c_w][p_k] = cp_wk;
cv_cp_c_pv[c_b][p_p] = cp_bp;
cv_cp_c_pv[c_b][p_n] = cp_bn;
cv_cp_c_pv[c_b][p_b] = cp_bb;
cv_cp_c_pv[c_b][p_r] = cp_br;
cv_cp_c_pv[c_b][p_q] = cp_bq;
cv_cp_c_pv[c_b][p_k] = cp_bk;

/* set the piece from special case indicator conversion vector */

cv_p_scmvv[scmv_reg] = cv_p_scmvv[scmv_epc] = p_v;
cv_p_scmvv[scmv_cks] = cv_p_scmvv[scmv_cqs] = p_v;
cv_p_scmvv[scmv_ppn] = p_n;
cv_p_scmvv[scmv_ppb] = p_b;
cv_p_scmvv[scmv_ppr] = p_r;
cv_p_scmvv[scmv_ppq] = p_q;

/* set the color-piece bitfield from color-piece conversion vector */

cv_cpbf_cpv[cp_wp] = cpbf_wp;
cv_cpbf_cpv[cp_wn] = cpbf_wn;
cv_cpbf_cpv[cp_wb] = cpbf_wb;
cv_cpbf_cpv[cp_wr] = cpbf_wr;
cv_cpbf_cpv[cp_wq] = cpbf_wq;
cv_cpbf_cpv[cp_wk] = cpbf_wk;
cv_cpbf_cpv[cp_bp] = cpbf_bp;
cv_cpbf_cpv[cp_bn] = cpbf_bn;
cv_cpbf_cpv[cp_bb] = cpbf_bb;
cv_cpbf_cpv[cp_br] = cpbf_br;
cv_cpbf_cpv[cp_bq] = cpbf_bq;
cv_cpbf_cpv[cp_bk] = cpbf_bk;
cv_cpbf_cpv[cp_v0] = cpbf_v0;
cv_cpbf_cpv[cp_x0] = cpbf_x0;
cv_cpbf_cpv[cp_x1] = cpbf_x1;
cv_cpbf_cpv[cp_x2] = cpbf_x2;

/* initialize the game termination input marker conversion vector */

cv_gtc_gtimv[gtim_none] = gtc_none;
cv_gtc_gtimv[gtim_drw0] = gtc_draw;
cv_gtc_gtimv[gtim_drw1] = gtc_draw;
cv_gtc_gtimv[gtim_drw2] = gtc_draw;
cv_gtc_gtimv[gtim_drw3] = gtc_draw;
cv_gtc_gtimv[gtim_drw4] = gtc_draw;
cv_gtc_gtimv[gtim_wwn0] = gtc_wwin;
cv_gtc_gtimv[gtim_wwn1] = gtc_wwin;
cv_gtc_gtimv[gtim_wwn2] = gtc_wwin;
cv_gtc_gtimv[gtim_bwn0] = gtc_bwin;
cv_gtc_gtimv[gtim_bwn1] = gtc_bwin;
cv_gtc_gtimv[gtim_bwn2] = gtc_bwin;
cv_gtc_gtimv[gtim_res0] = gtc_nil;
cv_gtc_gtimv[gtim_res1] = gtc_nil;

/* initialize the game termination internal code conversion vector */

cv_gtom_gtcv[gtc_none] = gtom_none;
cv_gtom_gtcv[gtc_draw] = gtom_draw;
cv_gtom_gtcv[gtc_wwin] = gtom_wwin;
cv_gtom_gtcv[gtc_bwin] = gtom_bwin;

return;
}

/*<<< initconv.c: EOF */
