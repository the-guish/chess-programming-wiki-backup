/*>>> gt.h: subprogram prototypes for gt.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

gtimT GTMatchGTIM(charptrT s);
gtcT GTCDetermine(gtimT gtim);
siT GTCConsistent(gtcT new_gtc);
void GTCSet(gtcT new_gtc);
void GTCAutoSet(void);

/*<<< gt.h: EOF */
