/*>>> systimer.c: system timer access */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <signal.h>

#include "defs.h"
#include "vars.h"

#include "systimer.h"

/*<<< systimer.c: EOF */
