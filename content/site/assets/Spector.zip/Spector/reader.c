/*>>> reader.c: read game score text */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "epddefs.h"

#include "epd.h"
#include "file.h"
#include "gms.h"
#include "gt.h"
#include "init.h"
#include "memutil.h"
#include "mm.h"
#include "mu.h"
#include "notation.h"
#include "pgc.h"
#include "play.h"
#include "print.h"
#include "reader.h"
#include "sysutil.h"
#include "tags.h"

/* the game score token type */

#define gstL 13

typedef siT gstT;

#define gst_nil	(-1)

#define gst_bif     0 /* broket information form */
#define gst_eof     1 /* EOF */
#define gst_error   2 /* error */
#define gst_gtim    3 /* game termination indicator marker */
#define gst_lbrack  4 /* left bracket */
#define gst_lparen  5 /* left parenthesis */
#define gst_nag     6 /* numeric annotation glyph */
#define gst_period  7 /* period */
#define gst_pline   8 /* percent sign directive line */
#define gst_rbrack  9 /* right bracket */
#define gst_rparen 10 /* right parenthesis */
#define gst_string 11 /* string */
#define gst_symbol 12 /* symbol */

/* the game reader translation mode */

static grtmT gs_grtm;

/* the file pointer for reading the game score */

static fptrT gpar_fptr;

/* the file pointer for writing games and game variations */

static fptrT gvar_fptr;

/* token information returned by the lexer */

static gstT gst;
static gtimT gsf_gtim;
static charptrT gsf_sptr;
static siT gsf_nag;

/* the game score current character */

static siT gsf_char;

/* the "game finished" indicator */

static siT gst_done;

/* the last read game termination marker */

static gtimT last_gtim;

/* the number of games processed */

static liT gsf_gn;

/* the number of moves in scanned game */

static siT gsf_mvc;

/* the number of forms in scanned game */

static siT gsf_fmc;

/* the count of newline characters */

static siT gsf_cnl;

/* the line number of the current token start */

static siT gsf_tln;

/* the character column count */

static siT gsf_ccc;

/* forward declarations */

static siT RGParseForm(void);

/*--> RGSetGRTM: set the game reader translation mode */
nonstatic
void
RGSetGRTM(grtmT grtm)
{
gs_grtm = grtm;

return;
}

/*--> RGInteger: test string for integer status */
static
siT
RGInteger(void)
{
siT flag, length, i;

if ((length = strlen(gsf_sptr)) == 0)
	flag = 0;
else
	{
	flag = 1;
	i = 0;
	while (flag && (i < length))
		if (isdigit(*(gsf_sptr + i)))
			i++;
		else
			flag = 0;
	};

return (flag);
}

/*--> RGClass0: test character for class zero (digits) */
static
siT
RGClass0(void)
{
siT flag;

if ((gsf_char != EOF) && isdigit(gsf_char))
	flag = 1;
else
	flag = 0;

return (flag);
}

/*--> RGClass1: test character for class one (symbol characters) */
static
siT
RGClass1(void)
{
siT flag;

if (gsf_char == EOF)
	flag = 0;
else
	if (isalnum(gsf_char))
		flag = 1;
	else
		switch (gsf_char)
			{
			case '+':
			case '-':
			case '*':
			case '/':
			case '=':
			case '#':
			case ':':
				flag = 1;
				break;

			default:
				flag = 0;
				break;
			};

return (flag);
}

/*--> RGClass2: test character for class two (string characters) */
static
siT
RGClass2(void)
{
siT flag;

if (gsf_char == EOF)
	flag = 0;
else
	if (RGClass1())
		flag = 1;
	else
		if ((gsf_char >= 0x20) && (gsf_char <= 0x7e) && (gsf_char != '"'))
			flag = 1;
		else
			flag = 0;

return (flag);
}

/*--> RGChar: read a character from the game score file */
static
void
RGChar(void)
{
if (gsf_char == '\n')
	gsf_ccc = 0;

if (gsf_char != EOF)
	{
	gsf_char = fgetc(gpar_fptr);
	if (gsf_char != EOF)
		gsf_ccc++;
	};

if (gsf_char == '\n')
	gsf_cnl++;

return;
}

/*--> RGToken: read a game score token from a file */
static
void
RGToken(void)
{
siT i;
liT bracecount;

gst = gst_nil;
while (gst == gst_nil)
	{
	gsf_tln = gsf_cnl;
	if (gsf_char == EOF)
		gst = gst_eof;
	else
		switch (gsf_char)
			{
			case ' ':
			case '\t':
			case '\n':
				RGChar();
				break;

			case ';':
				RGChar();
				while ((gsf_char != EOF) && (gsf_char != '\n'))
					RGChar();
				if (gsf_char == '\n')
					RGChar();
				break;

			case '{':
				RGChar();
				bracecount = 1;
				while ((gsf_char != EOF) && (bracecount > 0))
					{
					if (gsf_char == '{')
						bracecount++;
					else
						if (gsf_char == '}')
							bracecount--;
					RGChar();
					};
				if (bracecount != 0)
					gst = gst_error;
				break;

			case '[':
				gst = gst_lbrack;
				RGChar();
				break;

			case '(':
				gst = gst_lparen;
				RGChar();
				break;

			case '.':
				gst = gst_period;
				RGChar();
				break;

			case ']':
				gst = gst_rbrack;
				RGChar();
				break;

			case ')':
				gst = gst_rparen;
				RGChar();
				break;

			case '%':
				if (gsf_ccc != 1)
					gst = gst_error;
				else
					{
					gst = gst_pline;
					i = 0;
					*(gsf_sptr + i++) = gsf_char;
					RGChar();
					while ((gsf_char != EOF) && (gsf_char != '\n'))
						{
						if (i < (tL - 1))
							*(gsf_sptr + i++) = gsf_char;
						RGChar();
						};
					*(gsf_sptr + i) = ascii_nul;
					};
				break;

			case '\x24': /* dollar sign */
				RGChar();
				if (!RGClass0())
					gst = gst_error;
				else
					{
					gst = gst_nag;
					gsf_nag = gsf_char - '0';
					RGChar();
					while (RGClass0())
						{
						gsf_nag = (gsf_nag * ten) + (gsf_char - '0');
						RGChar();
						};
					};

				break;

			case '"':
				RGChar();
				i = 0;
				while (RGClass2())
					{
					if (i < (tL - 1))
						*(gsf_sptr + i++) = gsf_char;
					RGChar();
					};
				*(gsf_sptr + i) = ascii_nul;
				if (gsf_char == '"')
					{
					gst = gst_string;
					RGChar();
					}
				else
					gst = gst_error;
				break;

			default:
				if (!RGClass1())
					{
					(void) sprintf(stv,
						"Spurious character (0x%02x) at line %hd ignored",
						gsf_char, (gsf_tln + 1));
					PrSTVNL();
					RGChar();
					}
				else
					{
					i = 0;
					while (RGClass1())
						{
						if (i < (tL - 1))
							*(gsf_sptr + i++) = gsf_char;
						RGChar();
						};
					*(gsf_sptr + i) = ascii_nul;
					gsf_gtim = GTMatchGTIM(gsf_sptr);
					if (gsf_gtim != gtim_nil)
						gst = gst_gtim;
					else
						gst = gst_symbol;
					};
				break;
			};
	};

return;
}

/*--> RGFileStart: start processing for an input file */
static
siT
RGFileStart(charptrT fn)
{
siT flag;

/* clear the counters */

gsf_gn = 0;
gsf_cnl = 0;
gsf_tln = 0;
gsf_ccc = 0;

/* get a text buffer */

gsf_sptr = (charptrT) MemoryGrab(tL);

/* open the input file */

if ((gpar_fptr = TextFileOpen(fn, "r")) == NULL)
	flag = 0;
else
	flag = 1;

/* initialize the lexer */

if (flag)
	{
	gsf_char = ascii_nul;
	RGChar();
	RGToken();
	};

return (flag);
}

/*--> RGFileFinish: finish processing for an input file */
static
void
RGFileFinish(void)
{
if (gpar_fptr != NULL)
	{
	TextFileClose(gpar_fptr);
	gpar_fptr = NULL;
	};

if (gsf_sptr != NULL)
	{
	MemoryFree(gsf_sptr);
	gsf_sptr = NULL;
	};

return;
}

/*--> RGError: report a scanning error */
static
void
RGError(charptrT s)
{
(void) sprintf(stv, "%s at line %hd\n", s, (gsf_tln + 1));
PrErrSTV();

return;
}

/*--> RGParseSymbol: parse a symbol */
static
siT
RGParseSymbol(void)
{
siT flag, mn;
mptrT mptr;

/* try a move number first */

if (RGInteger())
	{
	mn = 0;
	(void) sscanf(gsf_sptr, sfs_si, &mn);
	if (mn == envn.envn_fmvn)
		{
		flag = 1;
		RGToken();
		}
	else
		{
		RGError("Unexpected integer");
		flag = 0;
		};
	}
else
	{
	/* not a move number, try a move */

	lang_san = lang_get;
	mptr = MatchMove(gsf_sptr, root_sptr);
	lang_san = lang_put;
	if (mptr != NULL)
		{
		flag = 1;
		RGToken();
		PlayMove(mptr);
		gsf_mvc++;
		}
	else
		{
		RGError("Undecipherable symbol");
		flag = 0;
		};
	};

return (flag);
}

/*--> RGParseTag: parse a tag directive */
static
siT
RGParseTag(void)
{
siT flag;
charptrT tnptr, tvptr;
tagptrT tagptr;

/* set default return value */

flag = 1;

/* skip to label */

RGToken();
if (gst != gst_symbol)
	{
	RGError("Expected symbol");
	flag = 0;
	}
else
	{
	tnptr = StringGrab(gsf_sptr);
	tvptr = NULL;
	RGToken();
	if (gst == gst_rbrack)
		{
		RGToken();
		tagptr = TagLocate(tnptr);
		if ((tagptr != NULL) &&
			!(tagptr->tag_flag & tagf_perm))
			TagDelete(tagptr);
		}
	else
		{
		if ((gst == gst_string) || (gst == gst_symbol))
			{
			/* copy the input string and advance to next token */

			tvptr = StringGrab(gsf_sptr);
			RGToken();

			/* process concluding bracket */

			if (gst == gst_rbrack)
				{
				RGToken();
				tagptr = TagLocate(tnptr);
				if (tagptr == NULL)
					{
					tagptr = TagCreate(tnptr, 0);
					TagInsert(tagptr);
					}
				TagAssign(tagptr, tvptr);
				}
			else
				{
				RGError("Expected ']'");
				flag = 0;
				};

			/* release string */

			MemoryFree(tvptr);
			}
		else
			{
			RGError("Expected string, symbol, or ']'");
			flag = 0;
			};
		};
	MemoryFree(tnptr);
	};

return (flag);
}

/*--> RGParseGTIM: parse a game termination indicator marker */
static
siT
RGParseGTIM(void)
{
siT flag;
gtcT local_gtc;

/* set default return value */

flag = 1;

/* set the "last" gtim */

last_gtim = gsf_gtim;

/* handle gtim token */

local_gtc = GTCDetermine(gsf_gtim);
if (!GTCConsistent(local_gtc))
	{
	(void) sprintf(stv, "%s (%s) at line %hd",
		"Inconsistent game termination marker", gsf_sptr, (gsf_tln + 1));
	PrWarning(stv);
	};

GTCSet(local_gtc);
TagAssignReserved(rsvtag_result, gtomstrv[cv_gtom_gtcv[local_gtc]]);
RGToken();
gst_done = 1;

return (flag);
}

/*--> RGParseList: parse a parenthesized move list */
static
siT
RGParseList(void)
{
siT flag;

/* set default return value */

flag = 1;

/* scan */

RGToken();
while (flag && (gst != gst_eof) && (gst != gst_rparen))
	flag = RGParseForm();

/* conclude */

if (flag && (gst == gst_rparen))
	RGToken();
else
	{
	RGError("Unmatched parenthesis");
	flag = 0;
	};

return (flag);
}

/*--> RGParseNAG: parse a numeric annotation glyph */
static
siT
RGParseNAG(void)
{
siT flag;

flag = 1;
RGToken();

return (flag);
}

/*--> RGParsePLine: parse a percent line */
static
siT
RGParsePLine(void)
{
siT flag;

flag = 1;
RGToken();

return (flag);
}

/*--> RGParseForm: parse a game form */
static
siT
RGParseForm(void)
{
siT flag;

/* set default return value */

flag = 1;

/* switch according to string match */

switch (gst)
	{
	case gst_eof:
		gst_done = 1;
		break;

	case gst_error:
		RGError("Lexical error");
		flag = 0;
		break;

	case gst_gtim:
		flag = RGParseGTIM();
		break;

	case gst_lbrack:
		flag = RGParseTag();
		break;

	case gst_lparen:
		flag = RGParseList();
		break;

	case gst_nag:
		flag = RGParseNAG();
		break;

	case gst_period:
		RGToken();
		break;

	case gst_pline:
		flag = RGParsePLine();
		break;

	case gst_rbrack:
		RGError("Unexpected ']'");
		flag = 0;
		break;

	case gst_rparen:
		RGError("Unexpected ')'");
		flag = 0;
		break;

	case gst_string:
		RGError("Unexpected string");
		flag = 0;
		break;

	case gst_symbol:
		flag = RGParseSymbol();
		break;

	default:
		SwitchFault("RGParseForm");
		break;
	};

if (flag && (gst != gst_eof))
	gsf_fmc++;

return (flag);
}

/*--> RGParseGame: parse a single game sequence from the current file */
static
siT
RGParseGame(void)
{
siT flag;

/* set default return value */

flag = 1;

/* prepare for scan */

InitNewGame();
TagClearAll();
last_gtim = gtim_nil;
gst_done = 0;
gsf_mvc = 0;
gsf_fmc = 0;

/* scan */

while (flag && !gst_done)
	flag = RGParseForm();

/* check for game termination to make a game */

if (gtc != gtc_none)
	{
	gsf_gn++;
	if (optnv[optn_verb])
		PrStrLINL("Finished translation for game number: ", gsf_gn);
	};

return (flag);
}

/*--> RGWriteEPD: output the current game EPD (grtm_epd) */
static
void
RGWriteEPD(void)
{
siT i;
sqT sq;
histptrT histptr;
charptrT ptr;
rbT rb;

histptr = histbase;
for (i = 0; i < histn; i++)
	{
	for (sq = sq_a1; sq <= sq_h8; sq++)
		{
		if ((sq % 2) == 0)
			rb.rbv[sq] = (histptr->hist_nbv[sq >> 1] & nybbM);
		else
			rb.rbv[sq] = ((histptr->hist_nbv[sq >> 1] >> nybbW) & nybbM);
		};
	ptr = EPDGenBasic(&rb,
		histptr->hist_actc, histptr->hist_cast, histptr->hist_epsq);
	fprintf(gvar_fptr, "%s\n", ptr);
	MemoryFree(ptr);
	histptr++;
	};

ptr = EPDGenBasicCurrent();
fprintf(gvar_fptr, "%s\n", ptr);
MemoryFree(ptr);

return;
}

/*--> RGWriteHex: output game hex for book construction (grtm_hex) */
static
void
RGWriteHex(void)
{
siT i, limit;
cT c;
histptrT histptr;
cordptrT cordptr;

/* determine victory color (if any) */

switch (gtc)
	{
	case gtc_wwin:
		c = c_w;
		break;

	case gtc_bwin:
		c = c_b;
		break;

	default:
		c = c_nil;
		break;
	};

/* output hex lines for winning color */

if (c != c_nil)
	{
	if (histn <= plyL)
		limit = histn;
	else
		limit = plyL;

	histptr = histbase;
	cordptr = cordbase;
	for (i = 0; i < limit; i++)
		{
		if (histptr->hist_actc == c)
			{
			fprintf(gvar_fptr, "%1hd", c);
			fprintf(gvar_fptr, " %08lx", histptr->hist_mhac);
			fprintf(gvar_fptr, " %08lx", histptr->hist_mhsc);
			fprintf(gvar_fptr, " %02hx", (*cordptr & byteM));
			fprintf(gvar_fptr, "\n");
			};
		histptr++;
		cordptr++;
		};
	};

return;
}

/*--> RGWriteVariation: output the current game variation (grtm_vars) */
static
void
RGWriteVariation(void)
{
siT i, n;
histptrT histptr;
mT m;
sanT san;

(void) fputc('(', gvar_fptr);

histptr = histbase;

n = histn;

for (i = 0; i < n; i++)
	{
	ConvertFromLimitedMove(&histptr->hist_lm, &m);
	ConstructNotation(global_nm, &m, san);
	(void) fprintf(gvar_fptr, "%s", san);
	if (i < (n - 1))
		(void) fputc(ascii_sp, gvar_fptr);
	histptr++;
	};

(void) fputc(')', gvar_fptr);

if (gtc != gtc_none)
	(void) fprintf(gvar_fptr, " ; %s", gtomstrv[cv_gtom_gtcv[gtc]]);

(void) fputc('\n', gvar_fptr);

return;
}

/*--> RGSingle: read a single game score given a file name */
nonstatic
siT
RGSingle(charptrT fn, liptrT gnptr)
{
siT flag;

/* Initialize */

flag = RGFileStart(fn);

/* scan */

if (flag)
	flag = RGParseGame();

/* finish input file */

RGFileFinish();

/* assign game read count */

*gnptr = gsf_gn;

return (flag);
}

/*--> RGMultiple: read multiple game scores and produce translation */
nonstatic
siT
RGMultiple(charptrT fn0, charptrT fn1, liptrT gnptr)
{
siT flag, done;
nmT save_nm;

/* initialize the input file */

flag = RGFileStart(fn0);

/* initialize the output file */

if (flag)
	{
	gvar_fptr = TextFileOpen(fn1, "w");
	if (gvar_fptr == NULL)
		flag = 0;
	};

/* scan */

done = 0;
while (flag && !done)
	{
	flag = RGParseGame();

	if (flag && (last_gtim == gtim_nil))
		done = 1;

	save_nm = global_nm;
	global_nm = nm_algebraic;
	if (flag && !done)
		switch (gs_grtm)
			{
			case grtm_epd:
				RGWriteEPD();
				break;

			case grtm_hex:
				RGWriteHex();
				break;

			case grtm_pgc:
				PGCWriteCurrent(gvar_fptr);
				break;

			case grtm_pgn:
				GMSER(gvar_fptr);
				break;

			case grtm_var:
				RGWriteVariation();
				break;

			default:
				SwitchFault("RGMultiple");
				break;
			};
	global_nm = save_nm;
	};

/* finish output file */

if (gvar_fptr != NULL)
	{
	TextFileClose(gvar_fptr);
	gvar_fptr = NULL;
	};

/* finish input file */

RGFileFinish();

/* reset */

InitNewGame();

/* assign game read count */

*gnptr = gsf_gn;

return (flag);
}

/*<<< reader.c: EOF */
