/*>>> exec.c: move execution/retraction routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "attack.h"
#include "exec.h"
#include "hist.h"
#include "mu.h"
#include "pawn.h"
#include "print.h"
#include "setsq.h"
#include "sysutil.h"
#include "tt.h"

/*--> ExecuteMove: execute move */
nonstatic
void
ExecuteMove(mptrT mptr)
{
sqT ppsq;
bbT bb;

#if (0)
{
if (!ExtraSanityCheck(mptr))
	{
	PrNL();
	PrCurrentPath();
	PrNL();
	PrSANNL(mptr);
	Fault("ExecuteMove: non-sane move");
	};
}
#endif

/* ply overflow check */

if (ply == plyL)
	Overflow("ExecuteMove");

/* push to history */

HistoryPush(mptr);

/* stack environmental variables */

*envn_curr++ = envn;

/* test for null move */

if (null_move_ref(mptr))
	{
	/* a null move, clear the ep target and increment the halfmove clock */

	if (envn.envn_epsq != sq_nil)
		{
		TTEnPassantTargetFile();
		envn.envn_epsq = sq_nil;
		};
	envn.envn_hmvc++;
	}
else
	{
	/* process non-null move by special case */

	switch (mptr->m_scmv)
		{
		case scmv_reg:
			TTColorPieceSqSq(mptr->m_frcp, mptr->m_frsq, mptr->m_tosq);
			if (mptr->m_tocp == cp_v0)
				{
				SqSet(mptr->m_frcp, mptr->m_tosq);
				AttackCut(mptr->m_tosq);
				}
			else
				{
				envn.envn_mcpv[pasc] -= cpvalv[mptr->m_tocp];
				TTColorPieceSq(mptr->m_tocp, mptr->m_tosq);
				AttackDel(mptr->m_tosq);
				SqSet(mptr->m_frcp, mptr->m_tosq);
				};
			AttackDel(mptr->m_frsq);
			SqClr(mptr->m_frsq);
			AttackPro(mptr->m_frsq);
			AttackAdd(mptr->m_tosq);
			break;

		case scmv_epc:
			if (actc == c_w)
				{
				ppsq = mptr->m_tosq + dv_3;
				AttackDel(ppsq);
				SqClr(ppsq);
				AttackPro(ppsq);
				SqSet(cp_wp, mptr->m_tosq);
				AttackCut(mptr->m_tosq);
				AttackDel(mptr->m_frsq);
				SqClr(mptr->m_frsq);
				AttackPro(mptr->m_frsq);
				AttackAdd(mptr->m_tosq);
				envn.envn_mcpv[c_b] -= pval_p;
				TTColorPieceSqSq(cp_wp, mptr->m_frsq, mptr->m_tosq);
				TTColorPieceSq(cp_bp, ppsq);
				}
			else
				{
				ppsq = mptr->m_tosq + dv_1;
				AttackDel(ppsq);
				SqClr(ppsq);
				AttackPro(ppsq);
				SqSet(cp_bp, mptr->m_tosq);
				AttackCut(mptr->m_tosq);
				AttackDel(mptr->m_frsq);
				SqClr(mptr->m_frsq);
				AttackPro(mptr->m_frsq);
				AttackAdd(mptr->m_tosq);
				envn.envn_mcpv[c_w] -= pval_p;
				TTColorPieceSqSq(cp_bp, mptr->m_frsq, mptr->m_tosq);
				TTColorPieceSq(cp_wp, ppsq);
				};
			break;

		case scmv_cks:
			if (actc == c_w)
				{
				SqSet(cp_wr, sq_f1);
				AttackAdd(sq_f1);
				AttackDel(sq_h1);
				SqClr(sq_h1);
				AttackPro(sq_h1);
				SqSet(cp_wk, sq_g1);
				AttackCut(sq_g1);
				AttackDel(sq_e1);
				SqClr(sq_e1);
				AttackPro(sq_e1);
				AttackAdd(sq_g1);
				TTColorPieceSqSq(cp_wk, sq_e1, sq_g1);
				TTColorPieceSqSq(cp_wr, sq_h1, sq_f1);
				}
			else
				{
				SqSet(cp_br, sq_f8);
				AttackAdd(sq_f8);
				AttackDel(sq_h8);
				SqClr(sq_h8);
				AttackPro(sq_h8);
				SqSet(cp_bk, sq_g8);
				AttackCut(sq_g8);
				AttackDel(sq_e8);
				SqClr(sq_e8);
				AttackPro(sq_e8);
				AttackAdd(sq_g8);
				TTColorPieceSqSq(cp_bk, sq_e8, sq_g8);
				TTColorPieceSqSq(cp_br, sq_h8, sq_f8);
				};
			break;

		case scmv_cqs:
			if (actc == c_w)
				{
				SqSet(cp_wr, sq_d1);
				AttackAdd(sq_d1);
				AttackDel(sq_a1);
				SqClr(sq_a1);
				AttackPro(sq_a1);
				SqSet(cp_wk, sq_c1);
				AttackCut(sq_c1);
				AttackDel(sq_e1);
				SqClr(sq_e1);
				AttackPro(sq_e1);
				AttackAdd(sq_c1);
				TTColorPieceSqSq(cp_wk, sq_e1, sq_c1);
				TTColorPieceSqSq(cp_wr, sq_a1, sq_d1);
				}
			else
				{
				SqSet(cp_br, sq_d8);
				AttackAdd(sq_d8);
				AttackDel(sq_a8);
				SqClr(sq_a8);
				AttackPro(sq_a8);
				SqSet(cp_bk, sq_c8);
				AttackCut(sq_c8);
				AttackDel(sq_e8);
				SqClr(sq_e8);
				AttackPro(sq_e8);
				AttackAdd(sq_c8);
				TTColorPieceSqSq(cp_bk, sq_e8, sq_c8);
				TTColorPieceSqSq(cp_br, sq_a8, sq_d8);
				};
			break;

		case scmv_ppn:
			if (actc == c_w)
				{
				TTColorPieceSq(cp_wp, mptr->m_frsq);
				TTColorPieceSq(cp_wn, mptr->m_tosq);
				envn.envn_mcpv[c_w] += (pval_n - pval_p);
				if (mptr->m_tocp == cp_v0)
					{
					SqSet(cp_wn, mptr->m_tosq);
					AttackCut(mptr->m_tosq);
					}
				else
					{
					TTColorPieceSq(mptr->m_tocp, mptr->m_tosq);
					envn.envn_mcpv[c_b] -= cpvalv[mptr->m_tocp];
					AttackDel(mptr->m_tosq);
					SqSet(cp_wn, mptr->m_tosq);
					};
				AttackDel(mptr->m_frsq);
				SqClr(mptr->m_frsq);
				AttackPro(mptr->m_frsq);
				AttackAdd(mptr->m_tosq);
				}
			else
				{
				TTColorPieceSq(cp_bp, mptr->m_frsq);
				TTColorPieceSq(cp_bn, mptr->m_tosq);
				envn.envn_mcpv[c_b] += (pval_n - pval_p);
				if (mptr->m_tocp == cp_v0)
					{
					SqSet(cp_bn, mptr->m_tosq);
					AttackCut(mptr->m_tosq);
					}
				else
					{
					TTColorPieceSq(mptr->m_tocp, mptr->m_tosq);
					envn.envn_mcpv[c_w] -= cpvalv[mptr->m_tocp];
					AttackDel(mptr->m_tosq);
					SqSet(cp_bn, mptr->m_tosq);
					};
				AttackDel(mptr->m_frsq);
				SqClr(mptr->m_frsq);
				AttackPro(mptr->m_frsq);
				AttackAdd(mptr->m_tosq);
				};
			break;

		case scmv_ppb:
			if (actc == c_w)
				{
				TTColorPieceSq(cp_wp, mptr->m_frsq);
				TTColorPieceSq(cp_wb, mptr->m_tosq);
				envn.envn_mcpv[c_w] += (pval_b - pval_p);
				if (mptr->m_tocp == cp_v0)
					{
					SqSet(cp_wb, mptr->m_tosq);
					AttackCut(mptr->m_tosq);
					}
				else
					{
					TTColorPieceSq(mptr->m_tocp, mptr->m_tosq);
					envn.envn_mcpv[c_b] -= cpvalv[mptr->m_tocp];
					AttackDel(mptr->m_tosq);
					SqSet(cp_wb, mptr->m_tosq);
					};
				AttackDel(mptr->m_frsq);
				SqClr(mptr->m_frsq);
				AttackPro(mptr->m_frsq);
				AttackAdd(mptr->m_tosq);
				}
			else
				{
				TTColorPieceSq(cp_bp, mptr->m_frsq);
				TTColorPieceSq(cp_bb, mptr->m_tosq);
				envn.envn_mcpv[c_b] += (pval_b - pval_p);
				if (mptr->m_tocp == cp_v0)
					{
					SqSet(cp_bb, mptr->m_tosq);
					AttackCut(mptr->m_tosq);
					}
				else
					{
					TTColorPieceSq(mptr->m_tocp, mptr->m_tosq);
					envn.envn_mcpv[c_w] -= cpvalv[mptr->m_tocp];
					AttackDel(mptr->m_tosq);
					SqSet(cp_bb, mptr->m_tosq);
					};
				AttackDel(mptr->m_frsq);
				SqClr(mptr->m_frsq);
				AttackPro(mptr->m_frsq);
				AttackAdd(mptr->m_tosq);
				};
			break;

		case scmv_ppr:
			if (actc == c_w)
				{
				TTColorPieceSq(cp_wp, mptr->m_frsq);
				TTColorPieceSq(cp_wr, mptr->m_tosq);
				envn.envn_mcpv[c_w] += (pval_r - pval_p);
				if (mptr->m_tocp == cp_v0)
					{
					SqSet(cp_wr, mptr->m_tosq);
					AttackCut(mptr->m_tosq);
					}
				else
					{
					TTColorPieceSq(mptr->m_tocp, mptr->m_tosq);
					envn.envn_mcpv[c_b] -= cpvalv[mptr->m_tocp];
					AttackDel(mptr->m_tosq);
					SqSet(cp_wr, mptr->m_tosq);
					};
				AttackDel(mptr->m_frsq);
				SqClr(mptr->m_frsq);
				AttackPro(mptr->m_frsq);
				AttackAdd(mptr->m_tosq);
				}
			else
				{
				TTColorPieceSq(cp_bp, mptr->m_frsq);
				TTColorPieceSq(cp_br, mptr->m_tosq);
				envn.envn_mcpv[c_b] += (pval_r - pval_p);
				if (mptr->m_tocp == cp_v0)
					{
					SqSet(cp_br, mptr->m_tosq);
					AttackCut(mptr->m_tosq);
					}
				else
					{
					TTColorPieceSq(mptr->m_tocp, mptr->m_tosq);
					envn.envn_mcpv[c_w] -= cpvalv[mptr->m_tocp];
					AttackDel(mptr->m_tosq);
					SqSet(cp_br, mptr->m_tosq);
					};
				AttackDel(mptr->m_frsq);
				SqClr(mptr->m_frsq);
				AttackPro(mptr->m_frsq);
				AttackAdd(mptr->m_tosq);
				};
			break;

		case scmv_ppq:
			if (actc == c_w)
				{
				TTColorPieceSq(cp_wp, mptr->m_frsq);
				TTColorPieceSq(cp_wq, mptr->m_tosq);
				envn.envn_mcpv[c_w] += (pval_q - pval_p);
				if (mptr->m_tocp == cp_v0)
					{
					SqSet(cp_wq, mptr->m_tosq);
					AttackCut(mptr->m_tosq);
					}
				else
					{
					TTColorPieceSq(mptr->m_tocp, mptr->m_tosq);
					envn.envn_mcpv[c_b] -= cpvalv[mptr->m_tocp];
					AttackDel(mptr->m_tosq);
					SqSet(cp_wq, mptr->m_tosq);
					};
				AttackDel(mptr->m_frsq);
				SqClr(mptr->m_frsq);
				AttackPro(mptr->m_frsq);
				AttackAdd(mptr->m_tosq);
				}
			else
				{
				TTColorPieceSq(cp_bp, mptr->m_frsq);
				TTColorPieceSq(cp_bq, mptr->m_tosq);
				envn.envn_mcpv[c_b] += (pval_q - pval_p);
				if (mptr->m_tocp == cp_v0)
					{
					SqSet(cp_bq, mptr->m_tosq);
					AttackCut(mptr->m_tosq);
					}
				else
					{
					TTColorPieceSq(mptr->m_tocp, mptr->m_tosq);
					envn.envn_mcpv[c_w] -= cpvalv[mptr->m_tocp];
					AttackDel(mptr->m_tosq);
					SqSet(cp_bq, mptr->m_tosq);
					};
				AttackDel(mptr->m_frsq);
				SqClr(mptr->m_frsq);
				AttackPro(mptr->m_frsq);
				AttackAdd(mptr->m_tosq);
				};
			break;

		default:
			SwitchFault("ExecuteMove");
			break;
		};

	/* process update pawn hash index/signature */

	if (actc == c_w)
		{
		/* check moving piece and special case processing */

		if (mptr->m_frcp == cp_wp)
			{
			PawnTTWhiteSingleton(mptr->m_frsq);
			if (mptr->m_scmv == scmv_reg)
				PawnTTWhiteSingleton(mptr->m_tosq);
			else
				if (mptr->m_scmv == scmv_epc)
					{
					PawnTTWhiteSingleton(mptr->m_tosq);
					PawnTTBlackSingleton(mptr->m_tosq + dv_3);
					};
			};

		/* check target piece */

		if (mptr->m_tocp == cp_bp)
			PawnTTBlackSingleton(mptr->m_tosq);
		}
	else
		{
		/* check moving piece and special case processing */

		if (mptr->m_frcp == cp_bp)
			{
			PawnTTBlackSingleton(mptr->m_frsq);
			if (mptr->m_scmv == scmv_reg)
				PawnTTBlackSingleton(mptr->m_tosq);
			else
				if (mptr->m_scmv == scmv_epc)
					{
					PawnTTBlackSingleton(mptr->m_tosq);
					PawnTTWhiteSingleton(mptr->m_tosq + dv_1);
					};
			};

		/* check target piece */

		if (mptr->m_tocp == cp_wp)
			PawnTTWhiteSingleton(mptr->m_tosq);
		};

	/* process castling status update via terminal square examination */

	if (envn.envn_cast != 0)
		{
		bb = sqbbv[mptr->m_frsq];
		bb_setsq(bb, mptr->m_tosq);

		if ((envn.envn_cast & cf_wk) && bb_tstand(wktbb, bb))
			{
			envn.envn_cast &= ~cf_wk;
			TTCastlingAvailability(cai_wk);
			};

		if ((envn.envn_cast & cf_wq) && bb_tstand(wqtbb, bb))
			{
			envn.envn_cast &= ~cf_wq;
			TTCastlingAvailability(cai_wq);
			};

		if ((envn.envn_cast & cf_bk) && bb_tstand(bktbb, bb))
			{
			envn.envn_cast &= ~cf_bk;
			TTCastlingAvailability(cai_bk);
			};

		if ((envn.envn_cast & cf_bq) && bb_tstand(bqtbb, bb))
			{
			envn.envn_cast &= ~cf_bq;
			TTCastlingAvailability(cai_bq);
			};
		};

	/* process ep capture square update (non-null move) */

	if (envn.envn_epsq != sq_nil)
		TTEnPassantTargetFile();

	if (cv_p_cpv[mptr->m_frcp] != p_p)
		envn.envn_epsq = sq_nil;
	else
		if (actc == c_w)
			{
			if ((map_rank(mptr->m_frsq) == rank_2) &&
				(map_rank(mptr->m_tosq) == rank_4))
				{
				envn.envn_epsq = mptr->m_frsq + dv_1;
				TTEnPassantTargetFile();
				}
			else
				envn.envn_epsq = sq_nil;
			}
		else
			{
			if ((map_rank(mptr->m_frsq) == rank_7) &&
				(map_rank(mptr->m_tosq) == rank_5))
				{
				envn.envn_epsq = mptr->m_frsq + dv_3;
				TTEnPassantTargetFile();
				}
			else
				envn.envn_epsq = sq_nil;
			};

	/* process halfmove clock update (non-null move) */

	if ((cv_p_cpv[mptr->m_frcp] == p_p) || (mptr->m_tocp != cp_v0))
		envn.envn_hmvc = 0;
	else
		envn.envn_hmvc++;
	};

/* toggle colors */

if (actc == c_w)
	{
	actc = c_b;
	pasc = c_w;
	}
else
	{
	actc = c_w;
	pasc = c_b;
	};

/* increment ply */

ply++;

/* fullmove number update */

if (actc == c_w)
	envn.envn_fmvn++;

/* process move flag: executed */

mptr->m_flag |= mf_exec;

/* process move flags: checking/illegal */

if (actc == c_w)
	{
	if (bb_tstand(acbbv[c_b], cpbbv[cp_wk]))
		mptr->m_flag |= mf_chec;
	if (bb_tstand(acbbv[c_w], cpbbv[cp_bk]))
		mptr->m_flag |= mf_bust;
	}
else
	{
	if (bb_tstand(acbbv[c_w], cpbbv[cp_bk]))
		mptr->m_flag |= mf_chec;
	if (bb_tstand(acbbv[c_b], cpbbv[cp_wk]))
		mptr->m_flag |= mf_bust;
	};

/* statistics */

count_exec++;

return;
}

/*--> RetractMove: retract move */
nonstatic
void
RetractMove(mptrT mptr)
{
sqT ppsq;

/* fullmove number downdate */

if (actc == c_w)
	envn.envn_fmvn--;

/* decrement ply */

ply--;

/* toggle colors */

if (actc == c_w)
	{
	actc = c_b;
	pasc = c_w;
	}
else
	{
	actc = c_w;
	pasc = c_b;
	};

/* process for non-null move */

if (!null_move_ref(mptr))
	{
	/* process according to special case */

	switch (mptr->m_scmv)
		{
		case scmv_reg:
			SqSet(mptr->m_frcp, mptr->m_frsq);
			if (mptr->m_tocp == cp_v0)
				{
				AttackCut(mptr->m_frsq);
				AttackDel(mptr->m_tosq);
				SqClr(mptr->m_tosq);
				AttackPro(mptr->m_tosq);
				AttackAdd(mptr->m_frsq);
				}
			else
				{
				AttackAdd(mptr->m_frsq);
				AttackCut(mptr->m_frsq);
				AttackDel(mptr->m_tosq);
				SqSet(mptr->m_tocp, mptr->m_tosq);
				AttackAdd(mptr->m_tosq);
				};
			break;

		case scmv_epc:
			if (actc == c_w)
				{
				ppsq = mptr->m_tosq + dv_3;
				SqSet(cp_bp, ppsq);
				AttackCut(ppsq);
				AttackAdd(ppsq);
				SqSet(cp_wp, mptr->m_frsq);
				AttackCut(mptr->m_frsq);
				AttackDel(mptr->m_tosq);
				SqClr(mptr->m_tosq);
				AttackPro(mptr->m_tosq);
				AttackAdd(mptr->m_frsq);
				}
			else
				{
				ppsq = mptr->m_tosq + dv_1;
				SqSet(cp_wp, ppsq);
				AttackCut(ppsq);
				AttackAdd(ppsq);
				SqSet(cp_bp, mptr->m_frsq);
				AttackCut(mptr->m_frsq);
				AttackDel(mptr->m_tosq);
				SqClr(mptr->m_tosq);
				AttackPro(mptr->m_tosq);
				AttackAdd(mptr->m_frsq);
				};
			break;

		case scmv_cks:
			if (actc == c_w)
				{
				SqSet(cp_wr, sq_h1);
				AttackDel(sq_f1);
				SqClr(sq_f1);
				AttackPro(sq_f1);
				AttackAdd(sq_h1);
				SqSet(cp_wk, sq_e1);
				AttackCut(sq_e1);
				AttackDel(sq_g1);
				SqClr(sq_g1);
				AttackPro(sq_g1);
				AttackAdd(sq_e1);
				}
			else
				{
				SqSet(cp_br, sq_h8);
				AttackDel(sq_f8);
				SqClr(sq_f8);
				AttackPro(sq_f8);
				AttackAdd(sq_h8);
				SqSet(cp_bk, sq_e8);
				AttackCut(sq_e8);
				AttackDel(sq_g8);
				SqClr(sq_g8);
				AttackPro(sq_g8);
				AttackAdd(sq_e8);
				};
			break;

		case scmv_cqs:
			if (actc == c_w)
				{
				SqSet(cp_wr, sq_a1);
				AttackDel(sq_d1);
				SqClr(sq_d1);
				AttackPro(sq_d1);
				AttackAdd(sq_a1);
				SqSet(cp_wk, sq_e1);
				AttackCut(sq_e1);
				AttackDel(sq_c1);
				SqClr(sq_c1);
				AttackPro(sq_c1);
				AttackAdd(sq_e1);
				}
			else
				{
				SqSet(cp_br, sq_a8);
				AttackDel(sq_d8);
				SqClr(sq_d8);
				AttackPro(sq_d8);
				AttackAdd(sq_a8);
				SqSet(cp_bk, sq_e8);
				AttackCut(sq_e8);
				AttackDel(sq_c8);
				SqClr(sq_c8);
				AttackPro(sq_c8);
				AttackAdd(sq_e8);
				};
			break;

		case scmv_ppn:
		case scmv_ppb:
		case scmv_ppr:
		case scmv_ppq:
			if (actc == c_w)
				{
				SqSet(cp_wp, mptr->m_frsq);
				if (mptr->m_tocp == cp_v0)
					{
					AttackCut(mptr->m_frsq);
					AttackDel(mptr->m_tosq);
					SqClr(mptr->m_tosq);
					AttackPro(mptr->m_tosq);
					AttackAdd(mptr->m_frsq);
					}
				else
					{
					AttackAdd(mptr->m_frsq);
					AttackCut(mptr->m_frsq);
					AttackDel(mptr->m_tosq);
					SqSet(mptr->m_tocp, mptr->m_tosq);
					AttackAdd(mptr->m_tosq);
					};
				}
			else
				{
				SqSet(cp_bp, mptr->m_frsq);
				if (mptr->m_tocp == cp_v0)
					{
					AttackCut(mptr->m_frsq);
					AttackDel(mptr->m_tosq);
					SqClr(mptr->m_tosq);
					AttackPro(mptr->m_tosq);
					AttackAdd(mptr->m_frsq);
					}
				else
					{
					AttackAdd(mptr->m_frsq);
					AttackCut(mptr->m_frsq);
					AttackDel(mptr->m_tosq);
					SqSet(mptr->m_tocp, mptr->m_tosq);
					AttackAdd(mptr->m_tosq);
					};
				};
			break;

		default:
			SwitchFault("RetractMove");
			break;
		};
	};

/* unstack environmental variables */

envn = *--envn_curr;

/* drop history stack */

HistoryDrop();

return;
}

/*<<< exec.c: EOF */
