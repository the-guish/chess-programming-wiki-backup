/*>>> tbmoves.c: tablebase move management routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "tbdefs.h"
#include "tbvars.h"

#include "memutil.h"
#include "sysutil.h"
#include "tb.h"
#include "tbmoves.h"

/**** Locals */

/*--> TBOcSetUp: set up square occupancy */
nonstatic
void
TBOcSetUp(void)
{
sqT sq;
cT c;
siT i;

for (sq = sq_a1; sq <= sq_h8; sq++)
	tb_ocsqv[sq] = 0;

for (c = c_w; c <= c_b; c++)
	for (i = 0; i < tb_mcpnv[c]; i++)
		tb_ocsqv[tb_csqv[c][i]]++;

return;
}

/*--> TBOcMax: determine maximum occupancy */
nonstatic
siT
TBOcMax(void)
{
siT limit;
cT c;
siT i;

limit = 0;
for (c = c_w; c <= c_b; c++)
	for (i = 0; i < tb_mcpnv[c]; i++)
		if (tb_ocsqv[tb_csqv[c][i]] > limit)
			limit = tb_ocsqv[tb_csqv[c][i]];

return (limit);
}

/*--> TBOcPairSq: return the square of the first pair */
nonstatic
sqT
TBOcPairSq(void)
{
sqT sq;
sqT rsq;

sq = sq_nil;
rsq = sq_a1;
while ((sq == sq_nil) && (rsq <= sq_h8))
	if (tb_ocsqv[rsq] == 2)
		sq = rsq;
	else
		rsq++;

return (sq);
}

/*--> TBOcSetPair: set up the color-piece pair */
nonstatic
void
TBOcSetPair(sqT sq)
{
cT c;
siT i;

for (c = c_w; c <= c_b; c++)
	{
	tb_occpv[c] = cp_v0;
	i = 0;
	while ((tb_occpv[c] == cp_v0) && (i < tb_mcpnv[c]))
		if (tb_csqv[c][i] == sq)
			tb_occpv[c] = tb_mcpv[c][i];
		else
			i++;
	};

return ;
}

/*--> TBClearCapture: clear capture information */
static
void
TBClearCapture(void)
{
tb_capt_cp = cp_v0;
tb_capt_sq = sq_nil;
tb_capt_index = -1;

return;
}

/*--> TBEraseBoard: erase the TB board and related items */
nonstatic
void
TBEraseBoard(void)
{
sqT sq;
cT c;
siT index;

for (c = c_w; c <= c_b; c++)
	for (index = 0; index < tb_mgpnv[c]; index++)
	{
	sq = tb_mgpv[c][index];
	tb_cpv[sq] = cp_v0;
	tb_piv[sq] = -1;
	};

for (c = c_w; c <= c_b; c++)
	tb_mgpnv[c] = 0;

TBClearCapture();

return;
}

/*--> TBSetSquare: add a square value */
nonstatic
void
TBSetSquare(cpT cp, sqT sq)
{
siT index;
cT c;

c = cv_c_cpv[cp];
index = tb_mgpnv[c]++;
tb_mgpv[c][index] = sq;
if ((cp != tb_capt_cp) || (sq != tb_capt_sq))
	{
	tb_cpv[sq] = cp;
	tb_piv[sq] = index;
	};

return;
}

/*--> TBTestAttack: test if a color attacks a square */
static
siT
TBTestAttack(cT c, sqT sq)
{
siT flag, stop;
dxT dx;
dvT dv;
xdvT xdv;
sqT rsq;
xbsqT xbsq, xbrsq;
cpT rcp;
pT rp;

flag = 0;
xbsq = trn_xbsq(sq);

/* ortho directions */

if (!flag)
	{
	dx = dx_0;
	while (!flag && (dx <= dx_3))
		{
		dv = dvv[dx];
		xdv = xdvv[dx];
		xbrsq = xbsq + xdv;
		if (xb.xbv[xbrsq] == cp_v0)
			{
			rsq = sq + dv;
			if ((rcp = tb_cpv[rsq]) != cp_v0)
				{
				if (cv_c_cpv[rcp] == c)
					{
					rp = cv_p_cpv[rcp];
					if ((rp == p_r) || (rp == p_q) || (rp == p_k))
						flag = 1;
					};
				}
			else
				{
				stop = 0;
				while (!stop)
					{
					xbrsq += xdv;
					if (xb.xbv[xbrsq] != cp_v0)
						stop = 1;
					else
						{
						rsq += dv;
						rcp = tb_cpv[rsq];
						if (rcp != cp_v0)
							{
							stop = 1;
							if (cv_c_cpv[rcp] == c)
								{
								rp = cv_p_cpv[rcp];
								if ((rp == p_r) || (rp == p_q))
									flag = 1;
								};
							};
						};
					};
				};
			};

		dx++;
		};
	};

/* diag directions */

if (!flag)
	{
	dx = dx_4;
	while (!flag && (dx <= dx_7))
		{
		dv = dvv[dx];
		xdv = xdvv[dx];
		xbrsq = xbsq + xdv;
		if (xb.xbv[xbrsq] == cp_v0)
			{
			rsq = sq + dv;
			if ((rcp = tb_cpv[rsq]) != cp_v0)
				{
				if (cv_c_cpv[rcp] == c)
					{
					rp = cv_p_cpv[rcp];
					if ((rp == p_b) || (rp == p_q) || (rp == p_k))
						flag = 1;
					else
						if (rp == p_p)
							if (c == c_w)
								{
								if ((dx == dx_6) || (dx == dx_7))
									flag = 1;
								}
							else
								{
								if ((dx == dx_4) || (dx == dx_5))
									flag = 1;
								};
					};
				}
			else
				{
				stop = 0;
				while (!stop)
					{
					xbrsq += xdv;
					if (xb.xbv[xbrsq] != cp_v0)
						stop = 1;
					else
						{
						rsq += dv;
						rcp = tb_cpv[rsq];
						if (rcp != cp_v0)
							{
							stop = 1;
							if (cv_c_cpv[rcp] == c)
								{
								rp = cv_p_cpv[rcp];
								if ((rp == p_b) || (rp == p_q))
									flag = 1;
								};
							};
						};
					};
				};
			};

		dx++;
		};
	};

/* knight moves */

if (!flag)
	{
	dx = dx_8;
	while (!flag && (dx <= dx_f))
		{
		if (xb.xbv[xbsq + xdvv[dx]] == cp_v0)
			{
			rcp = tb_cpv[sq + dvv[dx]];
			if ((cv_c_cpv[rcp] == c) && (cv_p_cpv[rcp] == p_n))
				flag = 1;
			};
		dx++;
		};
	};

return (flag);
}

/*--> TBActiveKIC: determine active king in check condition */
nonstatic
siT
TBActiveKIC(void)
{
siT flag;

flag = TBTestAttack(tb_pasc, tb_mgpv[tb_actc][0]);

return (flag);
}

/*--> TBPassiveKIC: determine passive king in check condition */
nonstatic
siT
TBPassiveKIC(void)
{
siT flag;

flag = TBTestAttack(tb_actc, tb_mgpv[tb_pasc][0]);

return (flag);
}

/*--> TBToggle: toggle colors */
static
void
TBToggle(void)
{
tb_actc = inv_cv[tb_actc];
tb_pasc = inv_cv[tb_pasc];

return;
}

/*--> TBExecute: execute a move */
nonstatic
void
TBExecute(tmptrT tmptr)
{
siT act_index, pas_index;

act_index = tb_piv[tmptr->tm_frsq];
pas_index = tb_piv[tmptr->tm_tosq];

tb_cpv[tmptr->tm_frsq] = cp_v0;
tb_piv[tmptr->tm_frsq] = -1;

tb_cpv[tmptr->tm_tosq] = tmptr->tm_frcp;
tb_piv[tmptr->tm_tosq] = act_index;

tb_mgpv[tb_actc][act_index] = tmptr->tm_tosq;

if (pas_index == -1)
	TBClearCapture();
else
	{
	tb_capt_cp = tmptr->tm_tocp;
	tb_capt_sq = tmptr->tm_tosq;
	tb_capt_index = pas_index;
	};

TBToggle();

return;
}

/*--> TBRetract: retract a move */
nonstatic
void
TBRetract(tmptrT tmptr)
{
siT act_index;

TBToggle();

act_index = tb_piv[tmptr->tm_tosq];

tb_cpv[tmptr->tm_frsq] = tmptr->tm_frcp;
tb_piv[tmptr->tm_frsq] = act_index;

tb_mgpv[tb_actc][act_index] = tmptr->tm_frsq;

if (tmptr->tm_tocp == cp_v0)
	{
	tb_cpv[tmptr->tm_tosq] = cp_v0;
	tb_piv[tmptr->tm_tosq] = -1;
	}
else
	{
	tb_cpv[tmptr->tm_tosq] = tb_capt_cp;
	tb_piv[tmptr->tm_tosq] = tb_capt_index;
	};

TBClearCapture();

return;
}

/*--> TBClearBoard: clear the TB board and related items */
static
void
TBClearBoard(void)
{
sqT sq;
cT c;

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	tb_cpv[sq] = cp_v0;
	tb_piv[sq] = -1;
	};

for (c = c_w; c <= c_b; c++)
	tb_mgpnv[c] = 0;

TBClearCapture();

return;
}

/*--> TBGenDirect: generate direct moves from the TB board */
nonstatic
void
TBGenDirect(void)
{
siT pi, pn;
sqT frsq, tosq;
cpT frcp, tocp;
tmptrT tmptr;
siT tmn;
dxT dx;
dvT dv;
xbsqT xbfrsq, xbtosq;
xdvT xdv;

tmptr = tb_dtmv[tb_actc];
tmn = 0;
pn = tb_mgpnv[tb_actc];

for (pi = 0; pi < pn; pi++)
	{
	frsq = tb_mgpv[tb_actc][pi];
	frcp = tb_cpv[frsq];
	xbfrsq = trn_xbsq(frsq);
	switch (frcp)
		{
		case cp_wp:
			tosq = frsq + dv_1;
			tocp = tb_cpv[tosq];
			if (tocp == cp_v0)
				{
				tmptr->tm_frsq = frsq;
				tmptr->tm_tosq = tosq;
				tmptr->tm_frcp = frcp;
				tmptr->tm_tocp = tocp;
				tmptr++;
				tmn++;
				if (map_rank(frsq) == rank_2)
					{
					tosq = frsq + (2 * dv_1);
					tocp = tb_cpv[tosq];
					if (tocp == cp_v0)
						{
						tmptr->tm_frsq = frsq;
						tmptr->tm_tosq = tosq;
						tmptr->tm_frcp = frcp;
						tmptr->tm_tocp = tocp;
						tmptr++;
						tmn++;
						};
					};
				};

			if (map_file(frsq) > file_a)
				{
				tosq = frsq + dv_5;
				tocp = tb_cpv[tosq];
				if (cv_c_cpv[tocp] == c_b)
					{
					tmptr->tm_frsq = frsq;
					tmptr->tm_tosq = tosq;
					tmptr->tm_frcp = frcp;
					tmptr->tm_tocp = tocp;
					tmptr++;
					tmn++;
					};
				};

			if (map_file(frsq) < file_h)
				{
				tosq = frsq + dv_4;
				tocp = tb_cpv[tosq];
				if (cv_c_cpv[tocp] == c_b)
					{
					tmptr->tm_frsq = frsq;
					tmptr->tm_tosq = tosq;
					tmptr->tm_frcp = frcp;
					tmptr->tm_tocp = tocp;
					tmptr++;
					tmn++;
					};
				};
			break;

		case cp_bp:
			tosq = frsq + dv_3;
			tocp = tb_cpv[tosq];
			if (tocp == cp_v0)
				{
				tmptr->tm_frsq = frsq;
				tmptr->tm_tosq = tosq;
				tmptr->tm_frcp = frcp;
				tmptr->tm_tocp = tocp;
				tmptr++;
				tmn++;
				if (map_rank(frsq) == rank_7)
					{
					tosq = frsq + (2 * dv_3);
					tocp = tb_cpv[tosq];
					if (tocp == cp_v0)
						{
						tmptr->tm_frsq = frsq;
						tmptr->tm_tosq = tosq;
						tmptr->tm_frcp = frcp;
						tmptr->tm_tocp = tocp;
						tmptr++;
						tmn++;
						};
					};
				};

			if (map_file(frsq) > file_a)
				{
				tosq = frsq + dv_6;
				tocp = tb_cpv[tosq];
				if (cv_c_cpv[tocp] == c_w)
					{
					tmptr->tm_frsq = frsq;
					tmptr->tm_tosq = tosq;
					tmptr->tm_frcp = frcp;
					tmptr->tm_tocp = tocp;
					tmptr++;
					tmn++;
					};
				};

			if (map_file(frsq) < file_h)
				{
				tosq = frsq + dv_7;
				tocp = tb_cpv[tosq];
				if (cv_c_cpv[tocp] == c_w)
					{
					tmptr->tm_frsq = frsq;
					tmptr->tm_tosq = tosq;
					tmptr->tm_frcp = frcp;
					tmptr->tm_tocp = tocp;
					tmptr++;
					tmn++;
					};
				};
			break;

		case cp_wn:
		case cp_bn:
			for (dx = dx_8; dx <= dx_f; dx++)
				{
				if (xb.xbv[xbfrsq + xdvv[dx]] == cp_v0)
					{
					tosq = frsq + dvv[dx];
					tocp = tb_cpv[tosq];
					if (cv_c_cpv[tocp] != tb_actc)
						{
						tmptr->tm_frsq = frsq;
						tmptr->tm_tosq = tosq;
						tmptr->tm_frcp = frcp;
						tmptr->tm_tocp = tocp;
						tmptr++;
						tmn++;
						};
					};
				};
			break;

		case cp_wb:
		case cp_bb:
			for (dx = dx_4; dx <= dx_7; dx++)
				{
				dv = dvv[dx];
				xdv = xdvv[dx];
				tosq = frsq + dv;
				xbtosq = xbfrsq + xdv;
				while ((xb.xbv[xbtosq] == cp_v0) &&
					((tocp = tb_cpv[tosq]) == cp_v0))
					{
					tmptr->tm_frsq = frsq;
					tmptr->tm_tosq = tosq;
					tmptr->tm_frcp = frcp;
					tmptr->tm_tocp = tocp;
					tmptr++;
					tmn++;

					tosq += dv;
					xbtosq += xdv;
					};

				if ((xb.xbv[xbtosq] == cp_v0) &&
					(cv_c_cpv[tocp = tb_cpv[tosq]] == tb_pasc))
					{
					tmptr->tm_frsq = frsq;
					tmptr->tm_tosq = tosq;
					tmptr->tm_frcp = frcp;
					tmptr->tm_tocp = tocp;
					tmptr++;
					tmn++;
					};
				};
			break;

		case cp_wr:
		case cp_br:
			for (dx = dx_0; dx <= dx_3; dx++)
				{
				dv = dvv[dx];
				xdv = xdvv[dx];
				tosq = frsq + dv;
				xbtosq = xbfrsq + xdv;
				while ((xb.xbv[xbtosq] == cp_v0) &&
					((tocp = tb_cpv[tosq]) == cp_v0))
					{
					tmptr->tm_frsq = frsq;
					tmptr->tm_tosq = tosq;
					tmptr->tm_frcp = frcp;
					tmptr->tm_tocp = tocp;
					tmptr++;
					tmn++;

					tosq += dv;
					xbtosq += xdv;
					};

				if ((xb.xbv[xbtosq] == cp_v0) &&
					(cv_c_cpv[tocp = tb_cpv[tosq]] == tb_pasc))
					{
					tmptr->tm_frsq = frsq;
					tmptr->tm_tosq = tosq;
					tmptr->tm_frcp = frcp;
					tmptr->tm_tocp = tocp;
					tmptr++;
					tmn++;
					};
				};
			break;

		case cp_wq:
		case cp_bq:
			for (dx = dx_0; dx <= dx_7; dx++)
				{
				dv = dvv[dx];
				xdv = xdvv[dx];
				tosq = frsq + dv;
				xbtosq = xbfrsq + xdv;
				while ((xb.xbv[xbtosq] == cp_v0) &&
					((tocp = tb_cpv[tosq]) == cp_v0))
					{
					tmptr->tm_frsq = frsq;
					tmptr->tm_tosq = tosq;
					tmptr->tm_frcp = frcp;
					tmptr->tm_tocp = tocp;
					tmptr++;
					tmn++;

					tosq += dv;
					xbtosq += xdv;
					};

				if ((xb.xbv[xbtosq] == cp_v0) &&
					(cv_c_cpv[tocp = tb_cpv[tosq]] == tb_pasc))
					{
					tmptr->tm_frsq = frsq;
					tmptr->tm_tosq = tosq;
					tmptr->tm_frcp = frcp;
					tmptr->tm_tocp = tocp;
					tmptr++;
					tmn++;
					};
				};
			break;

		case cp_wk:
		case cp_bk:
			for (dx = dx_0; dx <= dx_7; dx++)
				{
				if (xb.xbv[xbfrsq + xdvv[dx]] == cp_v0)
					{
					tosq = frsq + dvv[dx];
					tocp = tb_cpv[tosq];
					if (cv_c_cpv[tocp] != tb_actc)
						{
						tmptr->tm_frsq = frsq;
						tmptr->tm_tosq = tosq;
						tmptr->tm_frcp = frcp;
						tmptr->tm_tocp = tocp;
						tmptr++;
						tmn++;
						};
					};
				};
			break;

		default:
			SwitchFault("TBGenDirect");
			break;
		};
	};

tb_dtmnv[tb_actc] = tmn;

return;
}

/*--> TBGenRetro: generate retrograde moves from the TB board */
nonstatic
void
TBGenRetro(void)
{
siT pi, pn;
sqT frsq, tosq;
cpT frcp, tocp;
tmptrT tmptr;
siT tmn;
dxT dx;
dvT dv;
xbsqT xbfrsq, xbtosq;
xdvT xdv;
sqT prom_sq;

tmptr = tb_rtmv[tb_pasc];
tmn = 0;
pn = tb_mgpnv[tb_pasc];

prom_sq = sq_nil;
pi = 1;
while ((pi < pn) && (prom_sq == sq_nil))
	{
	tosq = tb_mgpv[tb_pasc][pi];
	frcp = tb_cpv[tosq];
	if (cv_p_cpv[frcp] == p_p)
		switch (frcp)
			{
			case cp_wp:
				if (map_rank(tosq) == rank_8)
					prom_sq = tosq;
				break;

			case cp_bp:
				if (map_rank(tosq) == rank_1)
					prom_sq = tosq;
				break;
			};
	pi++;
	};

for (pi = 0; pi < pn; pi++)
	{
	tosq = tb_mgpv[tb_pasc][pi];
	frcp = tb_cpv[tosq];
	xbtosq = trn_xbsq(tosq);

	if (tb_capt_sq == tosq)
		tocp = tb_capt_cp;
	else
		tocp = cp_v0;

	if (((tb_capt_sq == sq_nil) || (tb_capt_sq == tosq)) &&
		((prom_sq == sq_nil) || (prom_sq == tosq)))
		{
		switch (frcp)
			{
			case cp_wp:
				if (map_rank(tosq) > rank_2)
					{
					if (tb_capt_sq == sq_nil)
						{
						frsq = tosq - dv_1;
						if (tb_cpv[frsq] == cp_v0)
							{
							tmptr->tm_frsq = frsq;
							tmptr->tm_tosq = tosq;
							tmptr->tm_frcp = frcp;
							tmptr->tm_tocp = tocp;
							tmptr++;
							tmn++;
							if (map_rank(tosq) == rank_4)
								{
								frsq = tosq - (2 * dv_1);
								if (tb_cpv[frsq] == cp_v0)
									{
									tmptr->tm_frsq = frsq;
									tmptr->tm_tosq = tosq;
									tmptr->tm_frcp = frcp;
									tmptr->tm_tocp = tocp;
									tmptr++;
									tmn++;
									};
								};
							};
						}
					else
						{
						if (map_file(tosq) > file_a)
							{
							frsq = tosq - dv_4;
							if (tb_cpv[frsq] == cp_v0)
								{
								tmptr->tm_frsq = frsq;
								tmptr->tm_tosq = tosq;
								tmptr->tm_frcp = frcp;
								tmptr->tm_tocp = tocp;
								tmptr++;
								tmn++;
								};
							};

						if (map_file(tosq) < file_h)
							{
							frsq = tosq - dv_5;
							if (tb_cpv[frsq] == cp_v0)
								{
								tmptr->tm_frsq = frsq;
								tmptr->tm_tosq = tosq;
								tmptr->tm_frcp = frcp;
								tmptr->tm_tocp = tocp;
								tmptr++;
								tmn++;
								};
							};
						};
					};
				break;

			case cp_bp:
				if (map_rank(tosq) < rank_7)
					{
					if (tb_capt_sq == sq_nil)
						{
						frsq = tosq - dv_3;
						if (tb_cpv[frsq] == cp_v0)
							{
							tmptr->tm_frsq = frsq;
							tmptr->tm_tosq = tosq;
							tmptr->tm_frcp = frcp;
							tmptr->tm_tocp = tocp;
							tmptr++;
							tmn++;
							if (map_rank(tosq) == rank_5)
								{
								frsq = tosq - (2 * dv_3);
								if (tb_cpv[frsq] == cp_v0)
									{
									tmptr->tm_frsq = frsq;
									tmptr->tm_tosq = tosq;
									tmptr->tm_frcp = frcp;
									tmptr->tm_tocp = tocp;
									tmptr++;
									tmn++;
									};
								};
							};
						}
					else
						{
						if (map_file(tosq) > file_a)
							{
							frsq = tosq - dv_7;
							if (tb_cpv[frsq] == cp_v0)
								{
								tmptr->tm_frsq = frsq;
								tmptr->tm_tosq = tosq;
								tmptr->tm_frcp = frcp;
								tmptr->tm_tocp = tocp;
								tmptr++;
								tmn++;
								};
							};

						if (map_file(tosq) < file_h)
							{
							frsq = tosq - dv_6;
							if (tb_cpv[frsq] == cp_v0)
								{
								tmptr->tm_frsq = frsq;
								tmptr->tm_tosq = tosq;
								tmptr->tm_frcp = frcp;
								tmptr->tm_tocp = tocp;
								tmptr++;
								tmn++;
								};
							};
						};
					};
				break;

			case cp_wn:
			case cp_bn:
				for (dx = dx_8; dx <= dx_f; dx++)
					{
					if (xb.xbv[xbtosq - xdvv[dx]] == cp_v0)
						{
						frsq = tosq - dvv[dx];
						if (tb_cpv[frsq] == cp_v0)
							{
							tmptr->tm_frsq = frsq;
							tmptr->tm_tosq = tosq;
							tmptr->tm_frcp = frcp;
							tmptr->tm_tocp = tocp;
							tmptr++;
							tmn++;
							};
						};
					};
				break;

			case cp_wb:
			case cp_bb:
				for (dx = dx_4; dx <= dx_7; dx++)
					{
					dv = -dvv[dx];
					xdv = -xdvv[dx];
					frsq = tosq + dv;
					xbfrsq = xbtosq + xdv;
					while ((xb.xbv[xbfrsq] == cp_v0) &&
						(tb_cpv[frsq] == cp_v0))
						{
						tmptr->tm_frsq = frsq;
						tmptr->tm_tosq = tosq;
						tmptr->tm_frcp = frcp;
						tmptr->tm_tocp = tocp;
						tmptr++;
						tmn++;

						frsq += dv;
						xbfrsq += xdv;
						};
					};
				break;

			case cp_wr:
			case cp_br:
				for (dx = dx_0; dx <= dx_3; dx++)
					{
					dv = -dvv[dx];
					xdv = -xdvv[dx];
					frsq = tosq + dv;
					xbfrsq = xbtosq + xdv;
					while ((xb.xbv[xbfrsq] == cp_v0) &&
						(tb_cpv[frsq] == cp_v0))
						{
						tmptr->tm_frsq = frsq;
						tmptr->tm_tosq = tosq;
						tmptr->tm_frcp = frcp;
						tmptr->tm_tocp = tocp;
						tmptr++;
						tmn++;

						frsq += dv;
						xbfrsq += xdv;
						};
					};
				break;

			case cp_wq:
			case cp_bq:
				for (dx = dx_0; dx <= dx_7; dx++)
					{
					dv = -dvv[dx];
					xdv = -xdvv[dx];
					frsq = tosq + dv;
					xbfrsq = xbtosq + xdv;
					while ((xb.xbv[xbfrsq] == cp_v0) &&
						(tb_cpv[frsq] == cp_v0))
						{
						tmptr->tm_frsq = frsq;
						tmptr->tm_tosq = tosq;
						tmptr->tm_frcp = frcp;
						tmptr->tm_tocp = tocp;
						tmptr++;
						tmn++;

						frsq += dv;
						xbfrsq += xdv;
						};
					};
				break;

			case cp_wk:
			case cp_bk:
				for (dx = dx_0; dx <= dx_7; dx++)
					{
					if (xb.xbv[xbtosq - xdvv[dx]] == cp_v0)
						{
						frsq = tosq - dvv[dx];
						if (tb_cpv[frsq] == cp_v0)
							{
							tmptr->tm_frsq = frsq;
							tmptr->tm_tosq = tosq;
							tmptr->tm_frcp = frcp;
							tmptr->tm_tocp = tocp;
							tmptr++;
							tmn++;
							};
						};
					};
				break;

			default:
				SwitchFault("TBGenRetro");
				break;
			};
		};
	};

tb_rtmnv[tb_pasc] = tmn;

return;
}

/*--> TBInitMG: initialize construction move generation */
nonstatic
void
TBInitMG(void)
{
cT c;

for (c = c_w; c <= c_b; c++)
	{
	tb_dtmv[c] = (tmptrT) MemoryGrab(sizeof(tmT) * gmL);
	tb_rtmv[c] = (tmptrT) MemoryGrab(sizeof(tmT) * gmL);
	};

TBClearBoard();

return;
}

/*--> TBTermMG: terminate construction move generation */
nonstatic
void
TBTermMG(void)
{
cT c;

for (c = c_w; c <= c_b; c++)
	{
	MemoryFree(tb_dtmv[c]);
	MemoryFree(tb_rtmv[c]);
	};

return;
}

/*<<< tbmoves.c: EOF */
