/*>>> tb.h: subprogram prototypes for tb.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void TBFormFileNameTBID(tbidT tbid, cT c, charptrT s);
tbidT TBDetectLocal(siptrT invertptr);
cpevT TBScoreLocal(tbidT, siT invert);
liT TBGenIndex(tbsptrT tbsptr);
siT TBCommand(charptrT tbidstr, charptrT tbcstr, liptrT resultptr);
void TBInit(void);
void TBTerm(void);

/*<<< tb.h: EOF */
