/*>>> pc.c: process command routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "commdefs.h"
#include "commvars.h"

#include "vpdefs.h"

#include "comm.h"
#include "command.h"
#include "cplb.h"
#include "cpic.h"
#include "cpmb.h"
#include "cptb.h"
#include "create.h"
#include "csprnt.h"
#include "display.h"
#include "eval.h"
#include "hint.h"
#include "init.h"
#include "pc.h"
#include "print.h"
#include "sortfile.h"
#include "stat.h"
#include "sysutil.h"
#include "test.h"
#include "ts.h"

/*--> ProcessBEEP: process emit single beep */
nonstatic
void
ProcessBEEP(void)
{
Beep(1);

return;
}

/*--> ProcessCALL: process call command subfile */
nonstatic
void
ProcessCALL(void)
{
if (!CommandFileCall(ipv[1].ip_str))
	PrErr("Can't open command input subfile");

return;
}

/*--> ProcessCOMM: process comminicate with Duplex mediator */
nonstatic
void
ProcessCOMM(void)
{
CommDuplex();

return;
}

/*--> ProcessCPIC: process command processor: interprocess communication */
nonstatic
void
ProcessCPIC(void)
{
CPICCommand();

return;
}

/*--> ProcessCPLB: process command processor: legacy book */
nonstatic
void
ProcessCPLB(void)
{
CPLBCommand();

return;
}

/*--> ProcessCPMB: process command processor: multibook */
nonstatic
void
ProcessCPMB(void)
{
CPMBCommand();

return;
}

/*--> ProcessCPTB: process command processor: tablebase subsystem */
nonstatic
void
ProcessCPTB(void)
{
CPTBCommand();

return;
}

/*--> ProcessDESC: process describe position */
nonstatic
void
ProcessDESC(void)
{
if (root_sptr != NULL)
	CSPrintDescription(root_sptr);

return;
}

/*--> ProcessECHO: process echo arguments */
nonstatic
void
ProcessECHO(void)
{
siT i;

for (i = 1; i < tkn; i++)
	{
	PrStr(ipv[i].ip_str);
	if (i < (tkn - 1))
		PrBlank();
	};
PrNL();

return;
}

/*--> ProcessENUM: process enumeration */
nonstatic
void
ProcessENUM(void)
{
siT depth;
liT sum;

depth = ipv[1].ip_sint;
if ((depth >= 1) && (depth < plyL))
	{
	SyncSecond();
	sum = TSEnumerate(depth);
	if (!optnv[optn_tren])
		PrStrLINL("Path count: ", sum);
	}
else
	PrErr("Ply depth out of bounds");

return;
}

/*--> ProcessEVAL: process evaluation */
nonstatic
void
ProcessEVAL(void)
{
gsT gs;
cpevT cpev;

/* print status */

gs = GameStatus(root_sptr);
PrStrGameStatusNL("Game status: ", gs);

/* evaluate for normal position */

if (gs != gs_norm)
	PrLine("No evaluation available.");
else
	{
	cpev = Evaluate();
	PrStrCentipawnNL("Evaluation: ", cpev);
	};

return;
}

/*--> ProcessEXIT: process program exit */
nonstatic
void
ProcessEXIT(void)
{
progdone = 1;

return;
}

/*--> ProcessHINT: process offer a move hint */
nonstatic
void
ProcessHINT(void)
{
InteractiveHint();

return;
}

/*--> ProcessINFO: process print identification information */
nonstatic
void
ProcessINFO(void)
{
PrInformationBanner();

return;
}

/*--> ProcessJUMP: process exit and transfer */
nonstatic
void
ProcessJUMP(void)
{
#if (os_mac)
{
if (tkn > 2)
	PrErr("Too many parameters for Mac OS");
else
	{
	xferline = malloc(strlen(ipv[1].ip_str) + 1);
	if (xferline == NULL)
		PrErr("Can't allocate transfer command line");
	else
		{
		/* copy program name */

		(void) strcpy(xferline, ipv[1].ip_str);

		/* mark execution completed */

		progdone = 1;
		};
	};
}
#endif

#if (os_unix)
{
siT i;
charptrT argp;

xferline = (charptrT) malloc(strlen(ipv[1].ip_str) + 1);
if (xferline == NULL)
	Diagnose("can't allocate transfer command line");
else
	{
	/* copy program name */

	(void) strcpy(xferline, ipv[1].ip_str);

	/* process program arguments */

	xferargv = (charptrT *) malloc(sizeof(charptrT) * tkn);
	if (xferargv == NULL)
		Diagnose("can't allocate transfer argument vector");
	for (i = 1; i < tkn; i++)
		{
		argp = (charptrT) malloc(strlen(ipv[i].ip_str) + 1);
		if (argp == NULL)
			Diagnose("can't allocate transfer argument");
		(void) strcpy(argp, ipv[i].ip_str);
		*(xferargv + i - 1) = argp;
		};
	*(xferargv + tkn - 1) = NULL;

	/* mark execution completed */

	progdone = 1;
	};
}
#endif

#if (os_mac)
PrErr("Unavailable with this system");
#endif

return;
}

/*--> ProcessLOGO: process print program logo */
nonstatic
void
ProcessLOGO(void)
{
PrLogoBanner();

return;
}

/*--> ProcessMARK: process report/establish time mark */
nonstatic
void
ProcessMARK(void)
{
liT delta_time;

/* synchronize, then set the update time */

SyncSecond();
tmark_update = time(NULL);

/* calculate delta and reset mark command time */

delta_time = tmark_update - tmark_mkcomm;
tmark_mkcomm = tmark_update;

/* report elapsed time */

PrStr("Initial: ");
PrExpandedTime(tmark_update - tmark_pstart);
PrNL();

PrStr("Elapsed: ");
PrExpandedTime(delta_time);
PrNL();

return;
}

/*--> ProcessNEWG: process new game */
nonstatic
void
ProcessNEWG(void)
{
InitNewGame();

return;
}

/*--> ProcessNOOP: process nothing */
nonstatic
void
ProcessNOOP(void)
{
Noop();

return;
}

/*--> ProcessRTRN: process return from command subfile */
nonstatic
void
ProcessRTRN(void)
{
CommandFileReturn();
if (tail_commfile == NULL)
	progdone = 1;

return;
}

/*--> ProcessSCON: process set console configuration */
nonstatic
void
ProcessSCON(void)
{
DpCommand();

return;
}

/*--> ProcessSORT: process sort text file */
nonstatic
void
ProcessSORT(void)
{
SortTextFile(ipv[1].ip_str, ipv[2].ip_str);

return;
}

/*--> ProcessSWAP: process swap colors */
nonstatic
void
ProcessSWAP(void)
{
sqT sq;
fileT file;
rankT rank;
rbT tboard;
castT tcast;

/* save board */

tboard = board;

/* copy board upside down */

for (rank = rank_1; rank <= rank_8; rank++)
	for (file = file_a; file <= file_h; file++)
		board.rbm[rank_8 - rank][file] = tboard.rbm[rank][file];

/* change piece colors */

for (sq = sq_a1; sq <= sq_h8; sq++)
	board.rbv[sq] = inv_cpv[board.rbv[sq]];

/* handle castling */

tcast = envn.envn_cast;
envn.envn_cast = 0;
if (tcast & cf_wk)
	envn.envn_cast |= cf_bk;
if (tcast & cf_wq)
	envn.envn_cast |= cf_bq;
if (tcast & cf_bk)
	envn.envn_cast |= cf_wk;
if (tcast & cf_bq)
	envn.envn_cast |= cf_wq;

/* handle ep target */

if (envn.envn_epsq != sq_nil)
	if (map_rank(envn.envn_epsq) == rank_3)
		envn.envn_epsq = map_sq(rank_6, map_file(envn.envn_epsq));
	else
		envn.envn_epsq = map_sq(rank_3, map_file(envn.envn_epsq));

/* swap colors */

actc = inv_cv[actc];
pasc = inv_cv[pasc];

/* create the database and tree */

CreateSetUp();

return;
}

/*--> ProcessSYST: process execute system command */
nonstatic
void
ProcessSYST(void)
{
#if (os_unix)
(void) system(ipv[1].ip_str);
#else
PrErr("Command not implemented");
#endif

return;
}

/*--> ProcessTEST: process test */
nonstatic
void
ProcessTEST(void)
{
Test();

return;
}

/*--> ProcessTRAC: process set general tracking options */
nonstatic
void
ProcessTRAC(void)
{
optnv[optn_freq] = optnv[optn_trab] = optnv[optn_trpv] =
	optnv[optn_trst] = optnv[optn_trtt] = optnv[optn_verb] = 1;

return;
}

/*<<< pc.c: EOF */
