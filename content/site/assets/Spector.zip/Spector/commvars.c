/*>>> commvars.c: command variable declarations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>

#include "defs.h"

#include "optndefs.h"

#include "commdefs.h"

/* command records */

crT crv[commL];

/**** tokens and parameters */

/* count of input tokens */

siT tkn;

/* array of pointers to tokens */

charptrT tkv[itL];

/* input parameter values */

ipT ipv[ipL];

/*<<< commvars.c: EOF */
