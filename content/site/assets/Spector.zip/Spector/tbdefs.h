/*>>> tbdefs.h: tablebase definitions */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* tablebase id type */

typedef siT tbidT, *tbidptrT;
#define tbidL 73
#define tbid_nil (-1)

#define tbid_kbbk   0
#define tbid_kbbkb  1
#define tbid_kbbkn  2
#define tbid_kbbkq  3
#define tbid_kbbkr  4
#define tbid_kbkb   5
#define tbid_kbkn   6
#define tbid_kbkp   7
#define tbid_kbnk   8
#define tbid_kbnkb  9
#define tbid_kbnkn 10
#define tbid_kbnkq 11
#define tbid_kbnkr 12
#define tbid_kbpk  13
#define tbid_knkn  14
#define tbid_knkp  15
#define tbid_knnk  16
#define tbid_knnkb 17
#define tbid_knnkn 18
#define tbid_knnkq 19
#define tbid_knnkr 20
#define tbid_knpk  21
#define tbid_kpk   22
#define tbid_kpkp  23
#define tbid_kppk  24
#define tbid_kqbk  25
#define tbid_kqbkb 26
#define tbid_kqbkn 27
#define tbid_kqbkq 28
#define tbid_kqbkr 29
#define tbid_kqk   30
#define tbid_kqkb  31
#define tbid_kqkn  32
#define tbid_kqkp  33
#define tbid_kqkq  34
#define tbid_kqkr  35
#define tbid_kqnk  36
#define tbid_kqnkb 37
#define tbid_kqnkn 38
#define tbid_kqnkq 39
#define tbid_kqnkr 40
#define tbid_kqpk  41
#define tbid_kqqk  42
#define tbid_kqqkb 43
#define tbid_kqqkn 44
#define tbid_kqqkq 45
#define tbid_kqqkr 46
#define tbid_kqrk  47
#define tbid_kqrkb 48
#define tbid_kqrkn 49
#define tbid_kqrkq 50
#define tbid_kqrkr 51
#define tbid_krbk  52
#define tbid_krbkb 53
#define tbid_krbkn 54
#define tbid_krbkq 55
#define tbid_krbkr 56
#define tbid_krk   57
#define tbid_krkb  58
#define tbid_krkn  59
#define tbid_krkp  60
#define tbid_krkr  61
#define tbid_krnk  62
#define tbid_krnkb 63
#define tbid_krnkn 64
#define tbid_krnkq 65
#define tbid_krnkr 66
#define tbid_krpk  67
#define tbid_krrk  68
#define tbid_krrkb 69
#define tbid_krrkn 70
#define tbid_krrkq 71
#define tbid_krrkr 72

/* tablebase directory name */

#define tbdn "TB"

/* tablebase byte entry semispan length */

#define tbbe_ssL ((pageL - 4) / 2)

/* the signed byte evaulation type */

typedef tiT bevT, *bevptrT;

/* tablebase signed byte entry values */

#define bev_broken   (tbbe_ssL + 1)  /* illegal or busted */

#define bev_mi1      tbbe_ssL        /* mate in 1 move */
#define bev_mimin    1               /* mate in 126 moves */

#define bev_draw     0               /* draw */

#define bev_limax    (-1)            /* mated in 125 moves */
#define bev_li0      (-tbbe_ssL)     /* mated in 0 moves */

#define bev_reserved (-tbbe_ssL - 1) /* reserved */
#define bev_unknown  (-tbbe_ssL - 2) /* unknown */

/* signed byte entry range testing macros */

#define tbe_mating(bev) \
	(((bev) >= bev_mimin) && ((bev) <= bev_mi1))

#define tbe_losing(bev) \
	(((bev) >= bev_li0) && ((bev) <= bev_limax))

#define tbe_wld(bev) \
	(((bev) >= bev_li0) && ((bev) <= bev_mi1))

#define tbe_special(bev) \
	(((bev) < bev_li0) || ((bev) > bev_mi1))

/* reflection macros */

#define reflect_x(sq) ((sq) ^ 0x38)
#define reflect_y(sq) ((sq) ^ 0x07)
#define reflect_xy(sq) ((((sq) >> 3) & 0x07) | (((sq) << 3) & 0x38))

/* tablebase scanning patterns */

typedef siT tbspidT;
#define tbspidL 3
#define tbspid_nil (-1)

#define tbspid_all 0 /* all 64 squares: a1, b1, ... h8 */
#define tbspid_tri 1 /* triangle: a1-d1, b2-d2, c3-d3, d4 */
#define tbspid_qsf 2 /* queenside flank: a1-d1, a2-d2, ... a8-d8 */

/* tablebase scanning vector component lengths */

#define tbsp_allL sqL
#define tbsp_triL ((((fileL / 2) * (fileL / 2)) + (fileL / 2)) / 2)
#define tbsp_qsfL ((fileL / 2) * rankL)

/* scaling */

#define tbsp_all2L (((liT) tbsp_allL) * tbsp_allL)
#define tbsp_all3L (((liT) tbsp_allL) * tbsp_all2L)
#define tbsp_all4L (((liT) tbsp_allL) * tbsp_all3L)

/* tablebase index generation vector total length */

#define tbigvL (tbsp_allL + tbsp_triL + tbsp_qsfL)

/* tablebase man count limits: side and total */

#define tbmcsL 3
#define tbmctL 5

/* tablebase flags */

typedef siT tbfT;

#define tbf_scwp bit_00 /* sp case: white pawn(s) */
#define tbf_scbp bit_01 /* sp case: black pawn(s) */
#define tbf_scap bit_02 /* sp case: at least one pawn */
#define tbf_scpp bit_03 /* sp case: both sides have at least one pawn */

/* tablebase command type */

typedef siT tbcT;
#define tbcL 4
#define tbc_nil (-1)

#define tbc_make  0 /* construct */
#define tbc_srpb  1 /* summary report BTM */
#define tbc_srpw  2 /* summary report WTM */
#define tbc_vrfy  3 /* pair verification playthrough */

/* tablebase case selector: index generation */

typedef siT tbcsigT;
#define tbcsigL 9
#define tbcsig_nil (-1)

#define tbcsig_a21 0 /* mode A, 2 white, 1 black: KxK */
#define tbcsig_a22 1 /* mode A, 2 white, 2 black: KxKy */
#define tbcsig_a31 2 /* mode A, 3 white, 1 black: KxyK */
#define tbcsig_a32 3 /* mode A, 3 white, 2 black: KxyKz */
#define tbcsig_a41 4 /* mode A, 4 white, 1 black: KxyzK */
#define tbcsig_b21 5 /* mode B, 2 white, 1 black: KPK */
#define tbcsig_b22 6 /* mode B, 2 white, 2 black: KxKP */
#define tbcsig_c31 7 /* mode C, 3 white, 1 black: KxPK, KPPK */
#define tbcsig_d22 8 /* mode D, 2 white, 2 black: KPKP */

/* tablebase type */

typedef struct tbsS
	{
	tbidT    tbs_tbid;             /* ident */
	tbfT     tbs_flag;             /* flag word */
	charptrT tbs_name;             /* string name */
	liT      tbs_size;             /* per file byte length */
	tbcsigT  tbs_tbcsig;           /* index generation */
	siT      tbs_tmn;              /* total man count */
	tbspidT  tbs_spidv[tbmctL];    /* scanning idents */
	liT      tbs_spanv[tbmctL];    /* scanning spans */
	siT      tbs_mnv[rcL];         /* man count vector */
	cpT      tbs_cpv[rcL][tbmcsL]; /* chessmen */
	siT      tbs_cpnv[cpL];        /* color piece census */
	} tbsT, *tbsptrT;

/* tablebase file descriptor cache list element type */

typedef struct tfcS
	{
	tbidT        tfc_tbid; /* tablebase class */
	cT           tfc_c;    /* tablebase active color */
	fptrT        tfc_fptr; /* file descriptor (NULL: unavailable) */
	struct tfcS *tfc_prev; /* previous record */
	struct tfcS *tfc_next; /* next record */
	} tfcT, *tfcptrT;

/*<<< tbdefs.h: EOF */
