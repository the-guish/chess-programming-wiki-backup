/*>>> pred.c: general predicate evaluation routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "attack.h"
#include "bb.h"
#include "pred.h"
#include "setsq.h"

/*--> CastlingFlankOkay: determine if specified castling is okay */
nonstatic
siT
CastlingFlankOkay(flankT flank)
{
siT flag;

flag = 0;

/* process according to active color; then flank */

if (actc == c_w)
	if (flank == flank_k)
		{
		if ((envn.envn_cast & cf_wk) &&
			bb_tstnotand(acbbv[c_b], cpbbv[cp_wk]) &&
			bb_tstnotand(wkobb, apmbb) &&
			bb_tstnotand(wkabb, acbbv[c_b]))
			flag = 1;
		}
	else
		{
		if ((envn.envn_cast & cf_wq) &&
			bb_tstnotand(acbbv[c_b], cpbbv[cp_wk]) &&
			bb_tstnotand(wqobb, apmbb) &&
			bb_tstnotand(wqabb, acbbv[c_b]))
			flag = 1;
		}
else
	if (flank == flank_k)
		{
		if ((envn.envn_cast & cf_bk) &&
			bb_tstnotand(acbbv[c_w], cpbbv[cp_bk]) &&
			bb_tstnotand(bkobb, apmbb) &&
			bb_tstnotand(bkabb, acbbv[c_w]))
			flag = 1;
		}
	else
		{
		if ((envn.envn_cast & cf_bq) &&
			bb_tstnotand(acbbv[c_w], cpbbv[cp_bk]) &&
			bb_tstnotand(bqobb, apmbb) &&
			bb_tstnotand(bqabb, acbbv[c_w]))
			flag = 1;
		};

return (flag);
}

/*--> LoneKingMate: test if the active color is a mated lone king */
nonstatic
siT
LoneKingMate(void)
{
sqT sq;
siT flag;

/* set default return value */

flag = 0;

/* test for mated lone king */

if (actc == c_w)
	{
	/* test for lone king */

	if (lone_king(c_w))
		{
		/* test for unattacked to-squares */

		if (bb_tstnotmask(acbbv[c_b], acbbv[c_w]))
			flag = 1;
		else
			if (bb_tstand(acbbv[c_b], cpbbv[cp_wk]))
				{
				sq = bb_once(cpbbv[cp_wk]);
				SqClr(sq);
				AttackPro(sq);
				if (bb_tstnotmask(acbbv[c_b], acbbv[c_w]))
					flag = 1;
				AttackCut(sq);
				SqSet(cp_wk, sq);
				};
		};
	}
else
	{
	/* test for lone king */

	if (lone_king(c_b))
		{
		/* test for unattacked to-squares */

		if (bb_tstnotmask(acbbv[c_w], acbbv[c_b]))
			flag = 1;
		else
			if (bb_tstand(acbbv[c_w], cpbbv[cp_bk]))
				{
				sq = bb_once(cpbbv[cp_bk]);
				SqClr(sq);
				AttackPro(sq);
				if (bb_tstnotmask(acbbv[c_w], acbbv[c_b]))
					flag = 1;
				AttackCut(sq);
				SqSet(cp_bk, sq);
				};
		};
	};

return (flag);
}

/*<<< pred.c: EOF */
