/*>>> vars.c: common variable declarations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

/**** Constants */

/* program identification */

charptrT progname;
charptrT progauth;
charptrT proguscf;
charptrT progexpr;
charptrT progdate;
charptrT progvers;

/* major and minor version numbers */

siT version_major, version_minor;

/* the "nil" string */

charptrT nilstr;

/* language strings */

charptrT langstrv[langL];

/* color and piece strings */

charptrT cstrv[rcL], pstrv[pL];

/* special case move indication strings */

charptrT scmvstrv[scmvL];

/* moveset flag strings */

charptrT sflagstrv[sfiL];

/* move flag strings */

charptrT mflagstrv[mfiL];

/* search termination reason code strings */

charptrT strcstrv[strcL];

/* game status strings */

charptrT gsstrv[gsL];

/* short game status strings */

charptrT sgsstrv[gsL];

/* game termination input marker strings */

charptrT gtimstrv[gtimL];

/* game termination output strings */

charptrT gtomstrv[gtomL];

/* strategy name strings */

charptrT strtstrv[strtL];

/* notation mode strings */

charptrT nmstrv[nmL];

/* ordinal strings: unit/tens/teen */

charptrT ord_unitv[decadeL], ord_tensv[decadeL], ord_teenv[decadeL];

/* phonetic strings: color, piece, rank, file */

charptrT phs_cv[rcL], phs_pv[pL], phs_rv[rankL], phs_fv[fileL];

/* character translation vectors */

char asccv[langL][cL], ascpv[langL][pL];
char ascrv[rankL], ascfv[fileL];

/* conversion vectors: ASCII hexadecimal character from integer */

char cv_ahc_iv[16];

/* conversion vectors: color from color-piece */

cT cv_c_cpv[cpL];

/* conversion vectors: piece from color-piece */

pT cv_p_cpv[cpL];

/* conversion vectors: color-piece from restricted-color and piece */

cpT cv_cp_c_pv[rcL][pL];

/* conversion vectors: piece from special cased move indicator */

pT cv_p_scmvv[scmvL];

/* conversion vectors: color-piece bit field from color-piece */

cpbfT cv_cpbf_cpv[cpL];

/* conversion vectors: game termination code from gt input marker */

gtcT cv_gtc_gtimv[gtimL];

/* conversion vectors: game termination output marker from gt code */

gtomT cv_gtom_gtcv[gtcL];

/* the enumeration word table base (count of on bits) */

byteptrT bevbase;

/* the bit first table base (lowest of on bits) */

byteptrT bfvbase;

/* cancellation word vector */

siT canwv[wordW];

/* rank and file directional delta vectors */

dvrT dvrv[dxL];
dvfT dvfv[dxL];

/* board and extended board direction deltas */

dvT dvv[dxL];
xdvT xdvv[dxL];

/* complementary direction vector */

dxT compdxv[dxL];

/* the rank and file direction component offsets */

siT rdvv[dxL], fdvv[dxL];

/* the square bitboard vector */

bbT sqbbv[sqL];

/* rank and file bitboard vectors */

bbT r0bbv[rankL], f0bbv[fileL];

/* the file adjacent bitboard vector */

bbT fabbv[fileL];

/* the file triplet bitboard vector */

bbT ftbbv[fileL];

/* the reduced direction edge bitboard vector */

bbT debbv[rdxL];

/* the extended board */

xbT xb;

/* piece move bitboard vectors */

bbT nmbbv[sqL], bmbbv[sqL], rmbbv[sqL], qmbbv[sqL], kmbbv[sqL];

/* pawn move and pawn capture bitboard vectors */

bbT pmbbv[rcL][sqL], pcbbv[rcL][sqL];

/* the pawn forward tracking bitboard vector */

bbT ptbbv[rcL][sqL];

/* the pawn adjacency forward tracking bitboard vector */

bbT pabbv[rcL][sqL];

/* the passed pawn check tracking bitboard vector */

bbT ppbbv[rcL][sqL];

/* the pawn phalanx horizontal adjacency bitboard vector */

bbT pxbbv[sqL];

/* the king hustle bitboard vector */

bbT khbbv[sqL];

/* the castling attack square bitboards */

bbT wkabb, wqabb, bkabb, bqabb;

/* the castling occupancy square bitboards */

bbT wkobb, wqobb, bkobb, bqobb;

/* the castling terminal square bitboards */

bbT wktbb, wqtbb, bktbb, bqtbb;

/* color square bitboard vector */

bbT csbbv[rcL];

/* rank based pawn advancement scaling (mostly for passed pawns) */

siT rbpasv[rcL][rankL];

/* pawn general advancement credit board (millipawn units) */

sibT gpaibv[rcL];

/* the castling information vector */

ciT civ[rcL];

/* color inversion vector */

cT inv_cv[cL];

/* color piece inversion vector */

cpT inv_cpv[cpL];

/* color-piece sweep indicator vector */

siT cp_sweepv[cpL];

/* the directional sweep bounds vectors */

dxT dx_sweep0v[pL], dx_sweep1v[pL];

/* promotion ranks by color */

rankT promrankv[rcL];

/* the null move */

mT null_m;

/* the null killer move */

kmT null_km;

/* the null limited move */

lmT null_lm;

/* the null simple move */

smT null_sm;

/* the null tactical search move */

tsmT null_tsm;

/* piece values */

cpevT pvalv[pL], cpvalv[cpL], xcpvalv[cpL];
siT scpvalv[cpL];

/* central distances (ortho summation: 1 <-> 7) */

sibT centdist;

/* opposing positions bitboard for active king checkmates */

bbT opposing;

/* rim and center bitboards */

bbT ontherim, incenter;

/* halfboard bitboards */

bbT hbbb_kingside, hbbb_queenside, hbbb_whiteside, hbbb_blackside;

/* sanctuary and cramped bitboard vectors */

bbT sancspot[rcL], cramspot[rcL];

/**** table base pointers */

/* the direction connection sq/sq table */

dxptrT dx_table_base;

/* the taxi distance sq/sq table */

byteptrT taxi_table_base;

/* the mintaxi and maxtaxi distance sq/sq tables */

byteptrT mintaxi_table_base, maxtaxi_table_base;

/**** raster base pointers */

/* the intersquare, beyond, and ray pathway sq/sq rasters */

bbptrT path_raster_base, beyond_raster_base, ray_raster_base;

/**** database variables */

/* color and color-piece bitboard vectors */

bbT c0bbv[rcL], cpbbv[rcpL];

/* the all pieces merged bitboard */

bbT apmbb;

/* attack-to, attack-from, and combined attack bitboards */

bbT atbbv[sqL], afbbv[sqL], acbbv[rcL];

/* the local board */

rbT local;

/* the null move used for generation base */

mT genbase_m;

/* the generated move */

mT gen_m;

/**** global parameters */

/* the global bitboard and the global auxillary bitboard */

bbT gp_bb, gp_abb;

/**** ply */

/* the current ply */

siT ply;

/**** environment */

/* local copy of the environment */

envnT envn;

/* environmental pointers: base and current */

envnptrT envn_base, envn_curr;

/**** move tree */

/* the root for the entire move tree */

sptrT root_sptr;

/* the root move node, either null or last move played */

mT root_m;

/**** history full info push depth */

/* ply depth to copy full position information (always >= 1) */

siT history_full_push;

/**** search results */

/* the most recent search expectation score */

cpevT expectation;

/**** forced mate search: nodes and seconds */

liT fms_nodes, fms_seconds;

/**** statistics */

/* counting statistics */

liT count_exec, count_node, pre_count_node;

/* node count and time at start of a search */

liT search_start_node;
time_t search_start_time;

/**** tags (environment pairs) */

/* head and tail of tag list */

tagptrT head_tagptr, tail_tagptr;

/* default reserved tag names */

charptrT rsvtagv[rsvtagL];

/**** program status */

/* global termination flag */

siT progdone;

/* move/multimove stop flag */

siT stop_play;

/* pointer to transfer program command line */

charptrT xferline;

/* program transfer argument vector */

charptrT *xferargv;

/* notation mode indicator */

nmT global_nm;

/* notation language indices for input and output (set by command) */

langT lang_get;  /* input to program */
langT lang_put;  /* output from program */

/* notation language index for SAN (either get/put; set by program) */

langT lang_san;

/**** game status */

/* the position set-up flag */

siT setup;

/* the real board */

rbT board;

/* the active and passive colors at the current ply */

cT actc, pasc;

/* the active and passive colors at the ply zero */

cT p0actc, p0pasc;

/* game termination code */

gtcT gtc;

/**** files */

/* dribble file pointer */

fptrT drib_fptr;

/* command file list head and tail pointers */

commfileptrT head_commfile, tail_commfile;

/**** communication linkage */

/* serial channel status vector */

scsT scsv[channelL];

/**** text I/O */

/* read text input vector */

char rtv[tL];

/* scratch text vector */

char stv[tL];

/**** game score and history */

/* number of positions stacked in history/ordinal storage */

siT histn;

/* the base and current history pointers */

histptrT histbase, histcurr;

/**** canonical move ordinals */

/* the base and current canonical move ordinal pointers */

cordptrT cordbase, cordcurr;

/**** static exchange evaluation */

/* the directional attacker vector */

cpsqT sxv[dxL];

/**** search */

/* the strategies */

strtT strtv[rcL];

/* the playing level */

siT level;

/* the current alpha beta iteration */

siT iteration;

/* the forcing iteration completion indicator */

siT force_iteration;

/* the search abort and search interrupt indicators */

siT search_abort, search_interrupt;

/* first time descent flags: first time down per iteration/ply zero move */

siT FTDIteration, FTDPlyZeroMove;

/* the target move list (-srch- command) */

mlstptrT target_mlstptr;

/* the ply zero search node count storage base */

liptrT pzsnc_base;

/* search termination reason code */

strcT strc;

/**** ponder search  */

/* the ponder search indicator flag */

siT ponder_active;

/* the ponder search result success flag */

siT ponder_result;

/* the ponder search trace flag */

siT ponder_trace;

/* the ponder search manual stop flag */

siT ponder_manual_stop;

/* the ponder search match flag (true if ponder search succeeds) */

siT ponder_match;

/* the ponder search mismatch flag (true if ponder search fails) */

siT ponder_mismatch;

/* the predicted move */

mT ponder_m;

/**** evaluation */

/* position sums (millipawns) */

mpevT position_ev[rcL];

/**** killer moves */

/* group killer move vector storage base */

gkmptrT gkm_base;

/* killer response storage base */

smptrT killer_response_base;

/* killer popularity storage base */

siptrT killer_pop_base;

/* counter killer base pointer */

smptrT counter_killer_base;

/**** chess clocks */

/* the accumulated time (in seconds) for each color */

liT clockv[rcL];

/* mark time of last clock update */

time_t clockm;

/* clock running flag */

siT clockflag;

/**** search termination timers */

/* the countdown timer */

liT countdown_timer;

/* the node countdown */

liT node_countdown;

/**** time control */

/* the time control vector */

tcntlT tcntlv[tcntlL];

/* time control: per move basic allocation */

liT sec_alloc;

/* time control: elapsed time since start of game */

liT tcntl_et0;

/* time control: budgeted time (per move) for various checkpoints */

liT tcntl_obvious, tcntl_next_iteration;
liT tcntl_next_candidate, tcntl_mondo;

/**** time marks */

/* time marks: program start, commanded, and update (current) values */

liT tmark_pstart, tmark_mkcomm, tmark_update;

/* time of last clank probe */

liT tmark_clank;

/**** transposition table */

liT tt_hash_order;
liT tt_hash_span;
liT tt_hash_size;
liT tt_hash_mask;

/**** silent play control */

siT silent_play;

/**** fifty move draw deactivation */

siT no_50mvdraw;

/**** display items for input into presentation generation */

/* DI: search */

siT di_expectation;
siT di_iteration;
siT di_p0span;
siT di_p0pick;
mT di_p0m;
liT di_nodes;
liT di_seconds;
lrT di_completion;
liT di_prediction;

/*<<< vars.c: EOF */
