/*>>> initcons.c: initialize misc constant values */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "initbbcv.h"
#include "initcomm.h"
#include "initcons.h"
#include "initconv.h"
#include "initoptn.h"
#include "initstrs.h"
#include "memutil.h"
#include "util.h"

/*--> InitSIBoardRank: set up the 8 values for an sib rank */
static
void
InitSIBoardRank(sibptrT sibptr, rankT rank,
	siT iv_a, siT iv_b, siT iv_c, siT iv_d,
	siT iv_e, siT iv_f, siT iv_g, siT iv_h)
{
sibptr->sibm[rank][file_a] = iv_a;
sibptr->sibm[rank][file_b] = iv_b;
sibptr->sibm[rank][file_c] = iv_c;
sibptr->sibm[rank][file_d] = iv_d;
sibptr->sibm[rank][file_e] = iv_e;
sibptr->sibm[rank][file_f] = iv_f;
sibptr->sibm[rank][file_g] = iv_g;
sibptr->sibm[rank][file_h] = iv_h;

return;
}

/*--> InitSIBoards: initialize constant short integer valued boards */
static
void
InitSIBoards(void)
{
/* initialize the central distance board */

InitSIBoardRank(&centdist, rank_8,  7,  6,  5,  4,  4,  5,  6,  7);
InitSIBoardRank(&centdist, rank_7,  6,  5,  4,  3,  3,  4,  5,  6);
InitSIBoardRank(&centdist, rank_6,  5,  4,  3,  2,  2,  3,  4,  5);
InitSIBoardRank(&centdist, rank_5,  4,  3,  2,  1,  1,  2,  3,  4);
InitSIBoardRank(&centdist, rank_4,  4,  3,  2,  1,  1,  2,  3,  4);
InitSIBoardRank(&centdist, rank_3,  5,  4,  3,  2,  2,  3,  4,  5);
InitSIBoardRank(&centdist, rank_2,  6,  5,  4,  3,  3,  4,  5,  6);
InitSIBoardRank(&centdist, rank_1,  7,  6,  5,  4,  4,  5,  6,  7);

return;
}

/*--> InitDynamicTables: initialize the various dynamic tables */
static
void
InitDynamicTables(void)
{
sqT sq0, sq1, sq2;
siT delta_r, delta_f;
dxT dx;
dvT dv;
xbsqT xbsq;
xdvT xdv;
bbT bb;

/* set up the direction table */

dx_table_base = (dxptrT) MemoryGrab(sizeof(dxT) * sqsqL);
for (sq0 = sq_a1; sq0 <= sq_h8; sq0++)
	{
	/* set default */

	for (sq1 = sq_a1; sq1 <= sq_h8; sq1++)
		*(dx_table_base + offset_sqsq(sq0, sq1)) = dx_nil;

	/* sweeps */

	for (dx = dx_0; dx <= dx_7; dx++)
		{
		sq1 = sq0;
		dv = dvv[dx];
		xdv = xdvv[dx];
		xbsq = trn_xbsq(sq0) + xdv;
		while (xb.xbv[xbsq] == cp_v0)
			{
			sq1 += dv;
			*(dx_table_base + offset_sqsq(sq0, sq1)) = dx;
			xbsq += xdv;
			};
		};

	/* knights */

	for (dx = rdxL; dx <= dx_f; dx++)
		if (xb.xbv[trn_xbsq(sq0) + xdvv[dx]] == cp_v0)
			{
			sq1 = sq0 + dvv[dx];
			*(dx_table_base + offset_sqsq(sq0, sq1)) = dx;
			};
	};

/* set up the taxi distance table */

taxi_table_base = (byteptrT) MemoryGrab(sizeof(byteT) * sqsqL);
for (sq0 = sq_a1; sq0 <= sq_h8; sq0++)
	for (sq1 = sq_a1; sq1 <= sq_h8; sq1++)
		{
		delta_r = map_rank(sq1) - map_rank(sq0);
		delta_f = map_file(sq1) - map_file(sq0);
		*(taxi_table_base + offset_sqsq(sq0, sq1)) =
				AbsSI(delta_r) + AbsSI(delta_f);
		};

/* set up the mintaxi and maxtaxi distance tables */

mintaxi_table_base = (byteptrT) MemoryGrab(sizeof(byteT) * sqsqL);
maxtaxi_table_base = (byteptrT) MemoryGrab(sizeof(byteT) * sqsqL);
for (sq0 = sq_a1; sq0 <= sq_h8; sq0++)
	for (sq1 = sq_a1; sq1 <= sq_h8; sq1++)
		{
		if ((delta_r = map_rank(sq1) - map_rank(sq0)) < 0)
			delta_r = -delta_r;
		if ((delta_f = map_file(sq1) - map_file(sq0)) < 0)
			delta_f = -delta_f;
		*(mintaxi_table_base + offset_sqsq(sq0, sq1)) =
			min(delta_r, delta_f);
		*(maxtaxi_table_base + offset_sqsq(sq0, sq1)) =
			max(delta_r, delta_f);
		};

/* set up the directional ray extension raster table */

ray_raster_base = (bbptrT) MemoryGrab(sizeof(bbT) * rdxL * sqL);
for (dx = dx_0; dx <= dx_7; dx++)
	{
	dv = dvv[dx];
	xdv = xdvv[dx];
	for (sq0 = sq_a1; sq0 <= sq_h8; sq0++)
		{
		bb_clr(bb);
		xbsq = trn_xbsq(sq0) + xdv;
		sq1 = sq0;
		while (xb.xbv[xbsq] == cp_v0)
			{
			sq1 += dv;
			bb_setsq(bb, sq1);
			xbsq += xdv;
			};
		*(ray_raster_base + offset_dxsq(dx, sq0)) = bb;
		};
	};

/* set up the intersquare path raster table */

path_raster_base = (bbptrT) MemoryGrab(sizeof(bbT) * sqsqL);
for (sq0 = sq_a1; sq0 <= sq_h8; sq0++)
	for (sq1 = sq_a1; sq1 <= sq_h8; sq1++)
		{
		bb_clr(bb);
		dx = *(dx_table_base + offset_sqsq(sq0, sq1));
		if ((dx >= dx_0) && (dx <= dx_7))
			{
			dv = dvv[dx];
			sq2 = sq0 + dv;
			while (sq2 != sq1)
				{
				bb_setsq(bb, sq2);
				sq2 += dv;
				};
			};
		*(path_raster_base + offset_sqsq(sq0, sq1)) = bb;
		};

/* set up the beyond (extension) raster table */

beyond_raster_base = (bbptrT) MemoryGrab(sizeof(bbT) * sqsqL);
for (sq0 = sq_a1; sq0 <= sq_h8; sq0++)
	for (sq1 = sq_a1; sq1 <= sq_h8; sq1++)
		{
		bb_clr(bb);
		dx = *(dx_table_base + offset_sqsq(sq0, sq1));
		if ((dx >= dx_0) && (dx <= dx_7))
			{
			dv = dvv[dx];
			xdv = xdvv[dx];
			xbsq = trn_xbsq(sq1) + xdv;
			sq2 = sq1;
			while (xb.xbv[xbsq] == cp_v0)
				{
				sq2 += dv;
				bb_setsq(bb, sq2);
				xbsq += xdv;
				};
			};
		*(beyond_raster_base + offset_sqsq(sq0, sq1)) = bb;
		};

return;
}

/*--> InitConstants: set up constant values */
nonstatic
void
InitConstants(void)
{
siT i;
rankT rank, aux_rank;

/* initialize the integer valued boards */

InitSIBoards();

/* initialize various strings */

InitStrs();

/* initialize the conversion vectors */

InitConversions();

/* initialize the command set */

InitCommands();

/* initialize the options */

InitOptions();

/* initialize constant bitboard values (includes other move gen items) */

InitBitBoardConstants();

/* intialize the various sq/sq tables */

InitDynamicTables();

/* initialize the color inversion vector */

inv_cv[c_w] = c_b;
inv_cv[c_b] = c_w;
inv_cv[c_v] = c_v;
inv_cv[c_x] = c_x;

/* initialize the color piece inversion vector */

inv_cpv[cp_wp] = cp_bp;
inv_cpv[cp_wn] = cp_bn;
inv_cpv[cp_wb] = cp_bb;
inv_cpv[cp_wr] = cp_br;
inv_cpv[cp_wq] = cp_bq;
inv_cpv[cp_wk] = cp_bk;
inv_cpv[cp_bp] = cp_wp;
inv_cpv[cp_bn] = cp_wn;
inv_cpv[cp_bb] = cp_wb;
inv_cpv[cp_br] = cp_wr;
inv_cpv[cp_bq] = cp_wq;
inv_cpv[cp_bk] = cp_wk;
inv_cpv[cp_v0] = cp_v0;
inv_cpv[cp_x0] = cp_x0;
inv_cpv[cp_x1] = cp_x1;
inv_cpv[cp_x2] = cp_x2;

/* initialize the promotion rank vector */

promrankv[c_w] = rank_8;
promrankv[c_b] = rank_1;

/* initialize the null move */

null_m.m_flag = mf_null;
null_m.m_frsq = null_m.m_tosq = sq_nil;
null_m.m_frcp = null_m.m_tocp = cp_nil;
null_m.m_scmv = scmv_nil;
null_m.m_prel = null_m.m_eval = cpev_bust;
null_m.m_cptr = null_m.m_dptr = NULL;

/* initialize the null killer move */

null_km.km_frsq = null_km.km_tosq = sq_nil;
null_km.km_usage = 0;

/* initialize the null limited move */

null_lm.lm_flag = mf_null;
null_lm.lm_frsq = null_lm.lm_tosq = sq_nil;
null_lm.lm_frcp = null_lm.lm_tocp = cp_nil;
null_lm.lm_scmv = scmv_nil;

/* initialize the null simple move */

null_sm.sm_frsq = null_sm.sm_tosq = sq_nil;

/* initialize the null tactical search move */

null_tsm.tsm_flag = tsmf_null;
null_tsm.tsm_frsq = null_tsm.tsm_tosq = sq_nil;
null_tsm.tsm_frcp = null_tsm.tsm_tocp = cp_nil;
null_tsm.tsm_scmv = scmv_nil;
null_tsm.tsm_prel = cpev_bust;

/* initialize the piece value vectors */

cpvalv[cp_wp] = cpvalv[cp_bp] = pvalv[p_p] = pval_p;
cpvalv[cp_wn] = cpvalv[cp_bn] = pvalv[p_n] = pval_n;
cpvalv[cp_wb] = cpvalv[cp_bb] = pvalv[p_b] = pval_b;
cpvalv[cp_wr] = cpvalv[cp_br] = pvalv[p_r] = pval_r;
cpvalv[cp_wq] = cpvalv[cp_bq] = pvalv[p_q] = pval_q;
cpvalv[cp_wk] = cpvalv[cp_bk] = pvalv[p_k] = pval_k;
cpvalv[cp_v0] = pvalv[p_v] = 0;
cpvalv[cp_x0] = pvalv[p_x] = 0;

/* initialize the piece value vectors (for exchange analysis) */

xcpvalv[cp_wp] = xcpvalv[cp_bp] = pval_p;
xcpvalv[cp_wn] = xcpvalv[cp_bn] = pval_n;
xcpvalv[cp_wb] = xcpvalv[cp_bb] = pval_b;
xcpvalv[cp_wr] = xcpvalv[cp_br] = pval_r;
xcpvalv[cp_wq] = xcpvalv[cp_bq] = pval_q;
xcpvalv[cp_wk] = xcpvalv[cp_bk] = (2 * pval_q);
xcpvalv[cp_v0] = 0;
xcpvalv[cp_x0] = 0;

/* initialize the piece value vectors (for simple recapture) */

scpvalv[cp_wp] = scpvalv[cp_bp] = 1;
scpvalv[cp_wn] = scpvalv[cp_bn] = 3;
scpvalv[cp_wb] = scpvalv[cp_bb] = 3;
scpvalv[cp_wr] = scpvalv[cp_br] = 5;
scpvalv[cp_wq] = scpvalv[cp_bq] = 9;
scpvalv[cp_wk] = scpvalv[cp_bk] = 0;
scpvalv[cp_v0] = 0;
scpvalv[cp_x0] = 0;

/* initialize the rank based pawn advancement vector */

i = 1;
for (rank = rank_1; rank <= rank_8; rank++)
	{
	aux_rank = rank_8 - rank;
	rbpasv[c_w][rank] = rbpasv[c_b][aux_rank] = i * i;
	i++;
	};

/* initialize the pawn general advancement boards (millipawn credits) */

i = 1;
for (rank = rank_1; rank <= rank_8; rank++)
	{
	aux_rank = rank_8 - rank;

	gpaibv[c_w].sibm[rank][file_a] = gpaibv[c_w].sibm[rank][file_h] =
	gpaibv[c_b].sibm[aux_rank][file_a] = gpaibv[c_b].sibm[aux_rank][file_h] =
		(i - 2) * 1;

	gpaibv[c_w].sibm[rank][file_b] = gpaibv[c_w].sibm[rank][file_g] =
	gpaibv[c_b].sibm[aux_rank][file_b] = gpaibv[c_b].sibm[aux_rank][file_g] =
		(i - 2) * 2;

	gpaibv[c_w].sibm[rank][file_c] = gpaibv[c_w].sibm[rank][file_f] =
	gpaibv[c_b].sibm[aux_rank][file_c] = gpaibv[c_b].sibm[aux_rank][file_f] =
		(i - 2) * 30;

	gpaibv[c_w].sibm[rank][file_d] = gpaibv[c_w].sibm[rank][file_e] =
	gpaibv[c_b].sibm[aux_rank][file_d] = gpaibv[c_b].sibm[aux_rank][file_e] =
		(i - 2) * 50;

	i++;
	};

return;
}

/*<<< initcons.c: EOF */
