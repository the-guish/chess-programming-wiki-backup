/*>>> bbshift.c: bitboard shift */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbshift.h"
#include "sysutil.h"

/*--> BitBoardShift: shift bitboard 1 step in a direction */
nonstatic
void
BitBoardShift(bbptrT ptr, dxT dx)
{
bbT bb0, bb1;

bb0 = *ptr;
switch (dx)
	{
	case dx_0:
		bb1.bbcv[rank_1] = (byteT) (bb0.bbcv[rank_1] << 1);
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_2] << 1);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_3] << 1);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_4] << 1);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_5] << 1);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_6] << 1);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_7] << 1);
		bb1.bbcv[rank_8] = (byteT) (bb0.bbcv[rank_8] << 1);
		break;

	case dx_1:
		bb1.bbcv[rank_1] = (byteT) 0x00;
		bb1.bbcv[rank_2] = (byteT) bb0.bbcv[rank_1];
		bb1.bbcv[rank_3] = (byteT) bb0.bbcv[rank_2];
		bb1.bbcv[rank_4] = (byteT) bb0.bbcv[rank_3];
		bb1.bbcv[rank_5] = (byteT) bb0.bbcv[rank_4];
		bb1.bbcv[rank_6] = (byteT) bb0.bbcv[rank_5];
		bb1.bbcv[rank_7] = (byteT) bb0.bbcv[rank_6];
		bb1.bbcv[rank_8] = (byteT) bb0.bbcv[rank_7];
		break;

	case dx_2:
		bb1.bbcv[rank_1] = (byteT) (bb0.bbcv[rank_1] >> 1);
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_2] >> 1);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_3] >> 1);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_4] >> 1);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_5] >> 1);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_6] >> 1);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_7] >> 1);
		bb1.bbcv[rank_8] = (byteT) (bb0.bbcv[rank_8] >> 1);
		break;

	case dx_3:
		bb1.bbcv[rank_1] = (byteT) bb0.bbcv[rank_2];
		bb1.bbcv[rank_2] = (byteT) bb0.bbcv[rank_3];
		bb1.bbcv[rank_3] = (byteT) bb0.bbcv[rank_4];
		bb1.bbcv[rank_4] = (byteT) bb0.bbcv[rank_5];
		bb1.bbcv[rank_5] = (byteT) bb0.bbcv[rank_6];
		bb1.bbcv[rank_6] = (byteT) bb0.bbcv[rank_7];
		bb1.bbcv[rank_7] = (byteT) bb0.bbcv[rank_8];
		bb1.bbcv[rank_8] = (byteT) 0x00;
		break;

	case dx_4:
		bb1.bbcv[rank_1] = (byteT) 0x00;
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_1] << 1);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_2] << 1);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_3] << 1);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_4] << 1);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_5] << 1);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_6] << 1);
		bb1.bbcv[rank_8] = (byteT) (bb0.bbcv[rank_7] << 1);
		break;

	case dx_5:
		bb1.bbcv[rank_1] = (byteT) 0x00;
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_1] >> 1);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_2] >> 1);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_3] >> 1);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_4] >> 1);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_5] >> 1);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_6] >> 1);
		bb1.bbcv[rank_8] = (byteT) (bb0.bbcv[rank_7] >> 1);
		break;

	case dx_6:
		bb1.bbcv[rank_1] = (byteT) (bb0.bbcv[rank_2] >> 1);
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_3] >> 1);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_4] >> 1);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_5] >> 1);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_6] >> 1);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_7] >> 1);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_8] >> 1);
		bb1.bbcv[rank_8] = (byteT) 0x00;
		break;

	case dx_7:
		bb1.bbcv[rank_1] = (byteT) (bb0.bbcv[rank_2] << 1);
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_3] << 1);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_4] << 1);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_5] << 1);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_6] << 1);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_7] << 1);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_8] << 1);
		bb1.bbcv[rank_8] = (byteT) 0x00;
		break;

	case dx_8:
		bb1.bbcv[rank_1] = (byteT) 0x00;
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_1] << 2);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_2] << 2);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_3] << 2);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_4] << 2);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_5] << 2);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_6] << 2);
		bb1.bbcv[rank_8] = (byteT) (bb0.bbcv[rank_7] << 2);
		break;

	case dx_9:
		bb1.bbcv[rank_1] = (byteT) 0x00;
		bb1.bbcv[rank_2] = (byteT) 0x00;
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_1] << 1);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_2] << 1);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_3] << 1);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_4] << 1);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_5] << 1);
		bb1.bbcv[rank_8] = (byteT) (bb0.bbcv[rank_6] << 1);
		break;

	case dx_a:
		bb1.bbcv[rank_1] = (byteT) 0x00;
		bb1.bbcv[rank_2] = (byteT) 0x00;
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_1] >> 1);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_2] >> 1);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_3] >> 1);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_4] >> 1);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_5] >> 1);
		bb1.bbcv[rank_8] = (byteT) (bb0.bbcv[rank_6] >> 1);
		break;

	case dx_b:
		bb1.bbcv[rank_1] = (byteT) 0x00;
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_1] >> 2);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_2] >> 2);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_3] >> 2);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_4] >> 2);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_5] >> 2);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_6] >> 2);
		bb1.bbcv[rank_8] = (byteT) (bb0.bbcv[rank_7] >> 2);
		break;

	case dx_c:
		bb1.bbcv[rank_1] = (byteT) (bb0.bbcv[rank_2] >> 2);
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_3] >> 2);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_4] >> 2);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_5] >> 2);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_6] >> 2);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_7] >> 2);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_8] >> 2);
		bb1.bbcv[rank_8] = (byteT) 0x00;
		break;

	case dx_d:
		bb1.bbcv[rank_1] = (byteT) (bb0.bbcv[rank_3] >> 1);
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_4] >> 1);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_5] >> 1);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_6] >> 1);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_7] >> 1);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_8] >> 1);
		bb1.bbcv[rank_7] = (byteT) 0x00;
		bb1.bbcv[rank_8] = (byteT) 0x00;
		break;

	case dx_e:
		bb1.bbcv[rank_1] = (byteT) (bb0.bbcv[rank_3] << 1);
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_4] << 1);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_5] << 1);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_6] << 1);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_7] << 1);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_8] << 1);
		bb1.bbcv[rank_7] = (byteT) 0x00;
		bb1.bbcv[rank_8] = (byteT) 0x00;
		break;

	case dx_f:
		bb1.bbcv[rank_1] = (byteT) (bb0.bbcv[rank_2] << 2);
		bb1.bbcv[rank_2] = (byteT) (bb0.bbcv[rank_3] << 2);
		bb1.bbcv[rank_3] = (byteT) (bb0.bbcv[rank_4] << 2);
		bb1.bbcv[rank_4] = (byteT) (bb0.bbcv[rank_5] << 2);
		bb1.bbcv[rank_5] = (byteT) (bb0.bbcv[rank_6] << 2);
		bb1.bbcv[rank_6] = (byteT) (bb0.bbcv[rank_7] << 2);
		bb1.bbcv[rank_7] = (byteT) (bb0.bbcv[rank_8] << 2);
		bb1.bbcv[rank_8] = (byteT) 0x00;
		break;

	default:
		SwitchFault("BitBoardShift");
		break;
	};
*ptr = bb1;

return;
}

/*<<< bbshift.c: EOF */
