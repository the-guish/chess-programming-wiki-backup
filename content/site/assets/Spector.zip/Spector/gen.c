/*>>> gen.c: move generation routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "bb.h"
#include "gen.h"
#include "moveset.h"
#include "print.h"
#include "sysutil.h"

/**** locals */

/* macro for pawn promotion generation sequence */

#define GenPromotions() \
	{ \
	gen_m.m_scmv = scmv_ppq; \
	*sptr->s_mcurr++ = gen_m; \
	gen_m.m_scmv = scmv_ppr; \
	*sptr->s_mcurr++ = gen_m; \
	gen_m.m_scmv = scmv_ppb; \
	*sptr->s_mcurr++ = gen_m; \
	gen_m.m_scmv = scmv_ppn; \
	*sptr->s_mcurr++ = gen_m; \
	gen_m.m_scmv = scmv_reg; \
	}

/* type for generation dispatch vector */

typedef void (*frvsptrsqptrT)(sptrT sptr, sqT sq);

/* function dispatch vector for general moves */

static frvsptrsqptrT gen_dispatch[rcpL];

/* function dispatch vector for capture search moves */

static frvsptrsqptrT gen_capt_dispatch[rcpL];

/* active and passive king squares */

static sqT actk_sq, pask_sq;

/* active bitboards */

static bbT act_c0bbv;

/* passive bitboards */

static bbT pas_acbbv, pas_c0bbv;

/*--> GenerateCheckEscape: generate moves for active player in check */
static
void
GenerateCheckEscape(sptrT sptr)
{
sqT asq, locp_sq, sq;
cpT acp;
siT attack_count;
bbT attack_bb, beyond_bb, ip_bb, km_bb;

/* clear */

asq = sq_nil;

/* king moves */

km_bb = kmbbv[actk_sq];

/* process according to active color */

if (actc == c_w)
	{
	/* fetch attacker count */

	bb_and3(atbbv[actk_sq], c0bbv[c_b], attack_bb);
	attack_count = bb_count(attack_bb);

	/* try captures if only one attacker */

	if (attack_count == 1)
		{
		/* locate and set single attacker piece for later processing */

		acp = local.rbv[asq = bb_once(attack_bb)];

		/* calculate all friendly attackers to -asq- */

		bb_and3(atbbv[asq], c0bbv[c_w], gp_bb);

		/* test if capturable */

		if (bb_tst(gp_bb))
			{
			/* set up capturing move defaults */

			gen_m.m_tocp = acp;
			gen_m.m_tosq = asq;

			/* generate all non-king capturing moves to -asq- */

			while (bb_next_gp(locp_sq))
				{
				/* process according to capturing piece */

				switch (gen_m.m_frcp = local.rbv[gen_m.m_frsq = locp_sq])
					{
					case cp_wp:
						if (map_rank(asq) != rank_8)
							{
							*sptr->s_mcurr++ = gen_m;
							}
						else
							{
 							GenPromotions();
							};
						break;

					case cp_wn:
					case cp_wb:
					case cp_wr:
					case cp_wq:
						*sptr->s_mcurr++ = gen_m;
						break;

					case cp_wk:
						break;

					default:
						SwitchFault("GenerateCheckEscape");
						break;
					};
				};
			/* reset move defaults */

			gen_m.m_tocp = cp_v0;
			gen_m.m_tosq = sq_nil;
			};
		};

	/* start generation of all king moves */

	gen_m.m_frsq = actk_sq;
	gen_m.m_frcp = cp_wk;

	/* set initial king moves to non-attacked squares */

	bb_mask3(acbbv[c_b], km_bb, gp_bb);

	/* mask out flight squares occupied by friendly pieces */

	bb_mask2(c0bbv[c_w], gp_bb);

	/* eliminate false flight squares due to sweep attackers */

	if (attack_count == 1)
		{
		/* single attacker, acp/asq already set */

		if (cp_sweepv[acp])
			{
			/* fetch sweep beyond attacked squares */

			beyond_bb = *(beyond_raster_base + offset_sqsq(asq, actk_sq));

			/* mask out false flight squares */

			bb_mask2(beyond_bb, gp_bb);
			};
		}
	else
		{
		/* double check, handle both attackers */

		while (bb_next(attack_bb, asq))
			if (cp_sweepv[local.rbv[asq]])
				{
				/* fetch sweep beyond attacked squares */

				beyond_bb =
					*(beyond_raster_base + offset_sqsq(asq, actk_sq));

				/* mask out false flight squares */

				bb_mask2(beyond_bb, gp_bb);
				};
		};

	/* generate moves to flight squares */

	while (bb_next_gp(locp_sq))
		{
		gen_m.m_tocp = local.rbv[gen_m.m_tosq = locp_sq];
		*sptr->s_mcurr++ = gen_m;
		};
	gen_m.m_tocp = cp_v0;
	gen_m.m_tosq = sq_nil;

	/* try interpositions */

	if ((attack_count == 1) &&
		cp_sweepv[acp] &&
		bb_tstnotsq(km_bb, asq))
		{
		/* generate all potential non-pawn/non-king interposers */

		bb_ior4(cpbbv[cp_wn], cpbbv[cp_wb], cpbbv[cp_wr], ip_bb);
		bb_ior2(cpbbv[cp_wq], ip_bb);

		/* fetch interposition square set bitboard */

		gp_abb = *(path_raster_base + offset_sqsq(asq, actk_sq));
		while (bb_next_gpa(sq))
			{
			/* generate non-king interpositions to a (vacant) square */

			gen_m.m_tosq = sq;

			/* try a pawn single move interposition */

			if ((map_rank(sq) > rank_2) && (local.rbv[sq + dv_3] == cp_wp))
				{
				gen_m.m_frcp = cp_wp;
				gen_m.m_frsq = sq + dv_3;

				/* check for promotions */

				if (map_rank(sq) != rank_8)
					{
					*sptr->s_mcurr++ = gen_m;
					}
				else
					{
 					GenPromotions();
					};
				};

			/* try a pawn double move interposition */

			if ((map_rank(sq) == rank_4) &&
				(local.rbv[sq + (dv_3 + dv_3)] == cp_wp) &&
				(local.rbv[sq + dv_3] == cp_v0))
				{
				gen_m.m_frcp = cp_wp;
				gen_m.m_frsq = sq + (dv_3 + dv_3);
				*sptr->s_mcurr++ = gen_m;
				};

			/* try non-pawn/non-king interpositions */

			bb_and3(atbbv[sq], ip_bb, gp_bb);
			while (bb_next_gp(locp_sq))
				{
				gen_m.m_frcp = local.rbv[gen_m.m_frsq = locp_sq];
				*sptr->s_mcurr++ = gen_m;
				};
			};
		};

	/* try en passant capture */

	if (envn.envn_epsq != sq_nil)
		{
		/* handle ep capture to kingside */

		if (map_file(envn.envn_epsq) > file_a)
			{
			if (local.rbv[envn.envn_epsq + dv_6] == cp_wp)
				{
				gen_m.m_frsq = envn.envn_epsq + dv_6;
				gen_m.m_frcp = cp_wp;
				gen_m.m_tosq = envn.envn_epsq;
				gen_m.m_scmv = scmv_epc;
				*sptr->s_mcurr++ = gen_m;
				gen_m.m_scmv = scmv_reg;
				};
			};

		/* handle ep capture to queenside */

		if (map_file(envn.envn_epsq) < file_h)
			{
			if (local.rbv[envn.envn_epsq + dv_7] == cp_wp)
				{
				gen_m.m_frsq = envn.envn_epsq + dv_7;
				gen_m.m_frcp = cp_wp;
				gen_m.m_tosq = envn.envn_epsq;
				gen_m.m_scmv = scmv_epc;
				*sptr->s_mcurr++ = gen_m;
				gen_m.m_scmv = scmv_reg;
				};
			};
		};
	}
else
	{
	/* fetch attacker count */

	bb_and3(atbbv[actk_sq], c0bbv[c_w], attack_bb);
	attack_count = bb_count(attack_bb);

	/* try captures if only one attacker */

	if (attack_count == 1)
		{
		/* locate and set single attacker piece for later processing */

		acp = local.rbv[asq = bb_once(attack_bb)];

		/* calculate all friendly attackers to -asq- */

		bb_and3(atbbv[asq], c0bbv[c_b], gp_bb);

		/* test if capturable */

		if (bb_tst(gp_bb))
			{
			/* set up capturing move defaults */

			gen_m.m_tocp = acp;
			gen_m.m_tosq = asq;

			/* generate all non-king capturing moves to -asq- */

			while (bb_next_gp(locp_sq))
				{
				/* process according to capturing piece */

				switch (gen_m.m_frcp = local.rbv[gen_m.m_frsq = locp_sq])
					{
					case cp_bp:
						if (map_rank(asq) != rank_1)
							{
							*sptr->s_mcurr++ = gen_m;
							}
						else
							{
 							GenPromotions();
							};
						break;

					case cp_bn:
					case cp_bb:
					case cp_br:
					case cp_bq:
						*sptr->s_mcurr++ = gen_m;
						break;

					case cp_bk:
						break;

					default:
						SwitchFault("GenerateCheckEscape");
						break;
					};
				};
			/* reset move defaults */

			gen_m.m_tocp = cp_v0;
			gen_m.m_tosq = sq_nil;
			};
		};

	/* start generation of all king moves */

	gen_m.m_frsq = actk_sq;
	gen_m.m_frcp = cp_bk;

	/* set initial king moves to non-attacked squares */

	bb_mask3(acbbv[c_w], km_bb, gp_bb);

	/* mask out flight squares occupied by friendly pieces */

	bb_mask2(c0bbv[c_b], gp_bb);

	/* eliminate false flight squares due to sweep attackers */

	if (attack_count == 1)
		{
		/* single attacker, acp/asq already set */

		if (cp_sweepv[acp])
			{
			/* fetch sweep beyond attacked squares */

			beyond_bb = *(beyond_raster_base + offset_sqsq(asq, actk_sq));

			/* mask out false flight squares */

			bb_mask2(beyond_bb, gp_bb);
			};
		}
	else
		{
		/* double check, handle both attackers */

		while (bb_next(attack_bb, asq))
			if (cp_sweepv[local.rbv[asq]])
				{
				/* fetch sweep beyond attacked squares */

				beyond_bb =
					*(beyond_raster_base + offset_sqsq(asq, actk_sq));

				/* mask out false flight squares */

				bb_mask2(beyond_bb, gp_bb);
				};
		};

	/* generate moves to flight squares */

	while (bb_next_gp(locp_sq))
		{
		gen_m.m_tocp = local.rbv[gen_m.m_tosq = locp_sq];
		*sptr->s_mcurr++ = gen_m;
		};
	gen_m.m_tocp = cp_v0;
	gen_m.m_tosq = sq_nil;

	/* try interpositions */

	if ((attack_count == 1) &&
		cp_sweepv[acp] &&
		bb_tstnotsq(km_bb, asq))
		{
		/* generate all potential non-pawn/non-king interposers */

		bb_ior4(cpbbv[cp_bn], cpbbv[cp_bb], cpbbv[cp_br], ip_bb);
		bb_ior2(cpbbv[cp_bq], ip_bb);

		/* fetch interposition square set bitboard */

		gp_abb = *(path_raster_base + offset_sqsq(asq, actk_sq));
		while (bb_next_gpa(sq))
			{
			/* generate non-king interpositions to a (vacant) square */

			gen_m.m_tosq = sq;

			/* try a pawn single move interposition */

			if ((map_rank(sq) < rank_7) && (local.rbv[sq + dv_1] == cp_bp))
				{
				gen_m.m_frcp = cp_bp;
				gen_m.m_frsq = sq + dv_1;

				/* check for promotions */

				if (map_rank(sq) != rank_1)
					{
					*sptr->s_mcurr++ = gen_m;
					}
				else
					{
 					GenPromotions();
					};
				};

			/* try a pawn double move interposition */

			if ((map_rank(sq) == rank_5) &&
				(local.rbv[sq + (dv_1 + dv_1)] == cp_bp) &&
				(local.rbv[sq + dv_1] == cp_v0))
				{
				gen_m.m_frcp = cp_bp;
				gen_m.m_frsq = sq + (dv_1 + dv_1);
				*sptr->s_mcurr++ = gen_m;
				};

			/* try non-pawn/non-king interpositions */

			bb_and3(atbbv[sq], ip_bb, gp_bb);
			while (bb_next_gp(locp_sq))
				{
				gen_m.m_frcp = local.rbv[gen_m.m_frsq = locp_sq];
				*sptr->s_mcurr++ = gen_m;
				};
			};
		};

	/* try en passant capture */

	if (envn.envn_epsq != sq_nil)
		{
		/* handle ep capture to kingside */

		if (map_file(envn.envn_epsq) > file_a)
			{
			if (local.rbv[envn.envn_epsq + dv_5] == cp_bp)
				{
				gen_m.m_frsq = envn.envn_epsq + dv_5;
				gen_m.m_frcp = cp_bp;
				gen_m.m_tosq = envn.envn_epsq;
				gen_m.m_scmv = scmv_epc;
				*sptr->s_mcurr++ = gen_m;
				gen_m.m_scmv = scmv_reg;
				};
			};

		/* handle ep capture to queenside */

		if (map_file(envn.envn_epsq) < file_h)
			{
			if (local.rbv[envn.envn_epsq + dv_4] == cp_bp)
				{
				gen_m.m_frsq = envn.envn_epsq + dv_4;
				gen_m.m_frcp = cp_bp;
				gen_m.m_tosq = envn.envn_epsq;
				gen_m.m_scmv = scmv_epc;
				*sptr->s_mcurr++ = gen_m;
				gen_m.m_scmv = scmv_reg;
				};
			};
		};
	};

return;
}

/*--> GeneratePawnMoves: generate moves for a pawn */
static
void
GeneratePawnMoves(sptrT sptr, sqT sq)
{
sqT tosq;
rankT torank;
fileT frfile, epfile;

/* set the from file */

frfile = map_file(sq);

/* process according to color */

if (actc == c_w)
	{
	/* set the nominal destination rank */

	torank = map_rank(sq) + 1;

	/* forward, no capture */

	tosq = sq + dv_1;
	if (bb_tstnotsq(apmbb, tosq))
		{
		gen_m.m_tosq = tosq;
		if (torank != rank_8)
			{
			*sptr->s_mcurr++ = gen_m;
			}
		else
			{
 			GenPromotions();
			};
		if (torank == rank_3)
			{
			tosq = sq + (dv_1 + dv_1);
			if (bb_tstnotsq(apmbb, tosq))
				{
				gen_m.m_tosq = tosq;
				*sptr->s_mcurr++ = gen_m;
				};
			};
		};

	/* capture to kingside */

	if (frfile != file_h)
		{
		tosq = sq + dv_4;
		if (bb_tstsq(c0bbv[c_b], tosq))
			{
			gen_m.m_tocp = local.rbv[gen_m.m_tosq = tosq];
			if (torank != rank_8)
				{
				*sptr->s_mcurr++ = gen_m;
				}
			else
				{
 				GenPromotions();
				};
			gen_m.m_tocp = cp_v0;
			};
		};

	/* capture to queenside */

	if (frfile != file_a)
		{
		tosq = sq + dv_5;
		if (bb_tstsq(c0bbv[c_b], tosq))
			{
			gen_m.m_tocp = local.rbv[gen_m.m_tosq = tosq];
			if (torank != rank_8)
				{
				*sptr->s_mcurr++ = gen_m;
				}
			else
				{
 				GenPromotions();
				};
			gen_m.m_tocp = cp_v0;
			};
		};

	/* try en passant capture */

	if ((map_rank(sq) == rank_5) && (envn.envn_epsq != sq_nil))
		{
		epfile = map_file(envn.envn_epsq);

		/* try ep capture to kingside */

		if (epfile == (frfile + 1))
			{
			gen_m.m_tosq = envn.envn_epsq;
			gen_m.m_scmv = scmv_epc;
			*sptr->s_mcurr++ = gen_m;
			gen_m.m_scmv = scmv_reg;
			};

		/* try ep capture to queenside */

		if (epfile == (frfile - 1))
			{
			gen_m.m_tosq = envn.envn_epsq;
			gen_m.m_scmv = scmv_epc;
			*sptr->s_mcurr++ = gen_m;
			gen_m.m_scmv = scmv_reg;
			};
		};
	}
else
	{
	/* set the nominal destination rank */

	torank = map_rank(sq) - 1;

	/* forward, no capture */

	tosq = sq + dv_3;
	if (bb_tstnotsq(apmbb, tosq))
		{
		gen_m.m_tosq = tosq;
		if (torank != rank_1)
			{
			*sptr->s_mcurr++ = gen_m;
			}
		else
			{
 			GenPromotions();
			};
		if (torank == rank_6)
			{
			tosq = sq + (dv_3 + dv_3);
			if (bb_tstnotsq(apmbb, tosq))
				{
				gen_m.m_tosq = tosq;
				*sptr->s_mcurr++ = gen_m;
				};
			};
		};

	/* capture to kingside */

	if (frfile != file_h)
		{
		tosq = sq + dv_7;
		if (bb_tstsq(c0bbv[c_w], tosq))
			{
			gen_m.m_tocp = local.rbv[gen_m.m_tosq = tosq];
			if (torank != rank_1)
				{
				*sptr->s_mcurr++ = gen_m;
				}
			else
				{
 				GenPromotions();
				};
			gen_m.m_tocp = cp_v0;
			};
		};

	/* capture to queenside */

	if (frfile != file_a)
		{
		tosq = sq + dv_6;
		if (bb_tstsq(c0bbv[c_w], tosq))
			{
			gen_m.m_tocp = local.rbv[gen_m.m_tosq = tosq];
			if (torank != rank_1)
				{
				*sptr->s_mcurr++ = gen_m;
				}
			else
				{
 				GenPromotions();
				};
			gen_m.m_tocp = cp_v0;
			};
		};

	/* try en passant capture */

	if ((map_rank(sq) == rank_4) && (envn.envn_epsq != sq_nil))
		{
		epfile = map_file(envn.envn_epsq);

		/* try ep capture to kingside */

		if (epfile == (frfile + 1))
			{
			gen_m.m_tosq = envn.envn_epsq;
			gen_m.m_scmv = scmv_epc;
			*sptr->s_mcurr++ = gen_m;
			gen_m.m_scmv = scmv_reg;
			};

		/* try ep capture to queenside */

		if (epfile == (frfile - 1))
			{
			gen_m.m_tosq = envn.envn_epsq;
			gen_m.m_scmv = scmv_epc;
			*sptr->s_mcurr++ = gen_m;
			gen_m.m_scmv = scmv_reg;
			};
		};
	};

return;
}

/*--> GeneratePawnCaptures: generate captures/promotes for a pawn */
static
void
GeneratePawnCaptures(sptrT sptr, sqT sq)
{
sqT tosq;
rankT torank;
fileT frfile, epfile;

/* set the from file */

frfile = map_file(sq);

/* process according to color */

if (actc == c_w)
	{
	/* set the nominal destination rank */

	torank = map_rank(sq) + 1;

	/* forward, no capture, promote */

	tosq = sq + dv_1;
	if ((torank == rank_8) && bb_tstnotsq(apmbb, tosq))
		{
		gen_m.m_tosq = tosq;
 		GenPromotions();
		};

	/* capture to kingside */

	if (frfile != file_h)
		{
		tosq = sq + dv_4;
		if (bb_tstsq(c0bbv[c_b], tosq))
			{
			gen_m.m_tocp = local.rbv[gen_m.m_tosq = tosq];
			if (torank != rank_8)
				{
				*sptr->s_mcurr++ = gen_m;
				}
			else
				{
 				GenPromotions();
				};
			gen_m.m_tocp = cp_v0;
			};
		};

	/* capture to queenside */

	if (frfile != file_a)
		{
		tosq = sq + dv_5;
		if (bb_tstsq(c0bbv[c_b], tosq))
			{
			gen_m.m_tocp = local.rbv[gen_m.m_tosq = tosq];
			if (torank != rank_8)
				{
				*sptr->s_mcurr++ = gen_m;
				}
			else
				{
 				GenPromotions();
				};
			gen_m.m_tocp = cp_v0;
			};
		};

	/* try en passant capture */

	if ((map_rank(sq) == rank_5) && (envn.envn_epsq != sq_nil))
		{
		epfile = map_file(envn.envn_epsq);

		/* try ep capture to kingside */

		if (epfile == (frfile + 1))
			{
			gen_m.m_tosq = envn.envn_epsq;
			gen_m.m_scmv = scmv_epc;
			*sptr->s_mcurr++ = gen_m;
			gen_m.m_scmv = scmv_reg;
			};

		/* try ep capture to queenside */

		if (epfile == (frfile - 1))
			{
			gen_m.m_tosq = envn.envn_epsq;
			gen_m.m_scmv = scmv_epc;
			*sptr->s_mcurr++ = gen_m;
			gen_m.m_scmv = scmv_reg;
			};
		};
	}
else
	{
	/* set the nominal destination rank */

	torank = map_rank(sq) - 1;

	/* forward, no capture, promote */

	tosq = sq + dv_3;
	if ((torank == rank_1) && bb_tstnotsq(apmbb, tosq))
		{
		gen_m.m_tosq = tosq;
 		GenPromotions();
		};

	/* capture to kingside */

	if (frfile != file_h)
		{
		tosq = sq + dv_7;
		if (bb_tstsq(c0bbv[c_w], tosq))
			{
			gen_m.m_tocp = local.rbv[gen_m.m_tosq = tosq];
			if (torank != rank_1)
				{
				*sptr->s_mcurr++ = gen_m;
				}
			else
				{
 				GenPromotions();
				};
			gen_m.m_tocp = cp_v0;
			};
		};

	/* capture to queenside */

	if (frfile != file_a)
		{
		tosq = sq + dv_6;
		if (bb_tstsq(c0bbv[c_w], tosq))
			{
			gen_m.m_tocp = local.rbv[gen_m.m_tosq = tosq];
			if (torank != rank_1)
				{
				*sptr->s_mcurr++ = gen_m;
				}
			else
				{
 				GenPromotions();
				};
			gen_m.m_tocp = cp_v0;
			};
		};

	/* try en passant capture */

	if ((map_rank(sq) == rank_4) && (envn.envn_epsq != sq_nil))
		{
		epfile = map_file(envn.envn_epsq);

		/* try ep capture to kingside */

		if (epfile == (frfile + 1))
			{
			gen_m.m_tosq = envn.envn_epsq;
			gen_m.m_scmv = scmv_epc;
			*sptr->s_mcurr++ = gen_m;
			gen_m.m_scmv = scmv_reg;
			};

		/* try ep capture to queenside */

		if (epfile == (frfile - 1))
			{
			gen_m.m_tosq = envn.envn_epsq;
			gen_m.m_scmv = scmv_epc;
			*sptr->s_mcurr++ = gen_m;
			gen_m.m_scmv = scmv_reg;
			};
		};
	};

return;
}

/*--> GenerateUsualMoves: generate moves for nonking/nonpawn */
static
void
GenerateUsualMoves(sptrT sptr, sqT sq)
{
sqT rsq, asq;
dxT kdx;
bbT bb0, bb1;
pT mp;
siT skip;

/* set default skip value: no pin */

skip = 0;

/* check if moving piece is in line with the king */

kdx = *(dx_table_base + offset_sqsq(actk_sq, sq));
if ((kdx >= dx_0) && (kdx <= dx_7))
	{
	/* moving piece is in line, check attacked status */

	if (bb_tstsq(pas_acbbv, sq))
		{
		/* piece is attacked; test for interpath vacancy */

		bb0 = *(path_raster_base + offset_sqsq(actk_sq, sq));
		if (bb_tstnotand(bb0, apmbb))
			{
			/* piece is attacked; get attackers */

			bb_and3(atbbv[sq], pas_c0bbv, bb0);

			/* fetch only in line attacker, if any */

			bb1 = *(ray_raster_base + offset_dxsq(kdx, sq));
			bb_and2(bb0, bb1);

			/* is there an in line attacker? */

			if (bb_tst(bb1))
				{
				/* in line attacker exists; get its square */

				asq = bb_once(bb1);

				/* is the attacker a sweep piece? */

				if (cp_sweepv[local.rbv[asq]])
					{
					/* a pin exists; is it non-total? */

					mp = cv_p_cpv[gen_m.m_frcp];
					if ((kdx >= dx_sweep0v[mp]) &&
						(kdx <= dx_sweep1v[mp]))
						{
						/* non-total pin located; initialize destinations */

						skip = 1;
						bb_mask3(act_c0bbv, afbbv[sq], gp_bb);
						bb0 =
							*(path_raster_base + offset_sqsq(actk_sq, asq));
						bb_and2(bb0, gp_bb);
						bb_setsq(gp_bb, asq);
						}
					else
						skip = 2;
					};
				};
			};
		};
	};

/* generate only if no pin or no total pin was found */

if (skip < 2)
	{
	/* initialize the to-square bitboard if no pin */

	if (skip == 0)
		bb_mask3(act_c0bbv, afbbv[sq], gp_bb);

	/* generate normal moves */

	while (bb_next_gp(rsq))
		{
		gen_m.m_tocp = local.rbv[gen_m.m_tosq = rsq];
		*sptr->s_mcurr++ = gen_m;
		};

	/* reset destination cp */

	gen_m.m_tocp = cp_v0;
	};

return;
}

/*--> GenerateUsualCaptures: generate captures (nonking/nonpawn) */
static
void
GenerateUsualCaptures(sptrT sptr, sqT sq)
{
sqT rsq;

/* initialize the to-square bitboard */

bb_and3(pas_c0bbv, afbbv[sq], gp_bb);

/* generate normal moves */

while (bb_next_gp(rsq))
	{
	gen_m.m_tocp = local.rbv[gen_m.m_tosq = rsq];
	*sptr->s_mcurr++ = gen_m;
	};

/* reset destination cp */

gen_m.m_tocp = cp_v0;

return;
}

/*--> GenerateKingMoves: generate moves for a king */
static
void
GenerateKingMoves(sptrT sptr, sqT sq)
{
sqT rsq;

/* initialize the moving piece and the to-square bitboard */

if (actc == c_w)
	{
	bb_mask3(c0bbv[c_w], afbbv[sq], gp_bb);
	bb_mask2(acbbv[c_b], gp_bb);
	}
else
	{
	bb_mask3(c0bbv[c_b], afbbv[sq], gp_bb);
	bb_mask2(acbbv[c_w], gp_bb);
	};

/* generate normal king moves */

while (bb_next_gp(rsq))
	{
	gen_m.m_tocp = local.rbv[gen_m.m_tosq = rsq];
	*sptr->s_mcurr++ = gen_m;
	};

/* reset destination cp */

gen_m.m_tocp = cp_v0;

/* try castling */

if ((envn.envn_cast != 0) && bb_tstnotsq(pas_acbbv, sq))
	{
	if (actc == c_w)
		{
		/* try white kingside castling */

		if (envn.envn_cast & cf_wk)
			if (bb_tstnotand(wkobb, apmbb))
				if (bb_tstnotand(wkabb, acbbv[c_b]))
					{
					gen_m.m_tosq = sq_g1;
					gen_m.m_scmv = scmv_cks;
					*sptr->s_mcurr++ = gen_m;
					gen_m.m_scmv = scmv_reg;
					};

		/* try white queenside castling */

		if (envn.envn_cast & cf_wq)
			if (bb_tstnotand(wqobb, apmbb))
				if (bb_tstnotand(wqabb, acbbv[c_b]))
					{
					gen_m.m_tosq = sq_c1;
					gen_m.m_scmv = scmv_cqs;
					*sptr->s_mcurr++ = gen_m;
					gen_m.m_scmv = scmv_reg;
					};
		}
	else
		{
		/* try black kingside castling */

		if (envn.envn_cast & cf_bk)
			if (bb_tstnotand(bkobb, apmbb))
				if (bb_tstnotand(bkabb, acbbv[c_w]))
					{
					gen_m.m_tosq = sq_g8;
					gen_m.m_scmv = scmv_cks;
					*sptr->s_mcurr++ = gen_m;
					gen_m.m_scmv = scmv_reg;
					};

		/* try black queenside castling */

		if (envn.envn_cast & cf_bq)
			if (bb_tstnotand(bqobb, apmbb))
				if (bb_tstnotand(bqabb, acbbv[c_w]))
					{
					gen_m.m_tosq = sq_c8;
					gen_m.m_scmv = scmv_cqs;
					*sptr->s_mcurr++ = gen_m;
					gen_m.m_scmv = scmv_reg;
					};
		};
	};

return;
}

/*--> GenerateKingCaptures: generate captures for a king */
static
void
GenerateKingCaptures(sptrT sptr, sqT sq)
{
sqT rsq;

/* initialize the the to-square bitboard */

if (actc == c_w)
	{
	bb_and3(c0bbv[c_b], afbbv[sq], gp_bb);
	bb_mask2(acbbv[c_b], gp_bb);
	}
else
	{
	bb_and3(c0bbv[c_w], afbbv[sq], gp_bb);
	bb_mask2(acbbv[c_w], gp_bb);
	};

/* generate capturing king moves */

while (bb_next_gp(rsq))
	{
	gen_m.m_tocp = local.rbv[gen_m.m_tosq = rsq];
	*sptr->s_mcurr++ = gen_m;
	};

/* reset destination cp */

gen_m.m_tocp = cp_v0;

return;
}

/*--> Generate: allocate and generate moves for the active color */
nonstatic
sptrT
Generate(siT full)
{
sptrT sptr;
sqT sq;

/* set some subexpressions */

if (actc == c_w)
	{
	actk_sq = bb_once(cpbbv[cp_wk]);
	pask_sq = bb_once(cpbbv[cp_bk]);
	act_c0bbv = c0bbv[c_w];
	pas_c0bbv = c0bbv[c_b];
	pas_acbbv = acbbv[c_b];
	}
else
	{
	actk_sq = bb_once(cpbbv[cp_bk]);
	pask_sq = bb_once(cpbbv[cp_wk]);
	act_c0bbv = c0bbv[c_b];
	pas_c0bbv = c0bbv[c_w];
	pas_acbbv = acbbv[c_w];
	};

/* allocate the moveset record and move storage */

MovesetAllocate(sptr = MovesetNew());

/* set the initial current move pointer */

sptr->s_mcurr = sptr->s_mbase;

/* set the default values for the generated move */

gen_m = genbase_m;

/* set the common containing moveset pointer */

gen_m.m_cptr = sptr;

/* process according to "in-check" status */

if (bb_tstsq(pas_acbbv, actk_sq))
	{
	/* process check-escape moves */

	GenerateCheckEscape(sptr);

	/* mark moveset as full width */

	sptr->s_sflag |= sf_full;
	}
else
	if (full)
		{
		/* loop through active pieces for all moves */

		gp_abb = act_c0bbv;
		while (bb_next_gpa(sq))
			{
			/* set the from square and from square value */

			gen_m.m_frcp = local.rbv[gen_m.m_frsq = sq];

			/* dispatch according to piece type */

			(*gen_dispatch[gen_m.m_frcp])(sptr, sq);

			};

		/* mark moveset as full width */

		sptr->s_sflag |= sf_full;
		}
	else
		{
		/* loop through active pieces for captures/promotes */

		gp_abb = act_c0bbv;
		while (bb_next_gpa(sq))
			{
			/* set the from square and from square value */

			gen_m.m_frcp = local.rbv[gen_m.m_frsq = sq];

			/* dispatch according to piece type */

			(*gen_capt_dispatch[gen_m.m_frcp])(sptr, sq);
			};

		/* mark moveset as captures only */

		sptr->s_sflag |= sf_capt;
		};

/* set the moveset count */

sptr->s_count = sptr->s_mcurr - sptr->s_mbase;

/* clear the initial current move pointer */

sptr->s_mcurr = NULL;

/* resize (shrink) the new moveset */

MovesetResize(sptr);

return (sptr);
}

/*--> GenerateInit: initialize the move generation system (called once) */
nonstatic
void
GenerateInit(void)
{
/* clear the generation template move */

/* initialize the null move used for generation */

genbase_m.m_flag = 0;
genbase_m.m_frcp = cp_nil;
genbase_m.m_tocp = cp_v0;
genbase_m.m_frsq = genbase_m.m_tosq = sq_nil;
genbase_m.m_scmv = scmv_reg;
genbase_m.m_cptr = genbase_m.m_dptr = NULL;

/* set up the general move dispatch vector */

gen_dispatch[cp_wp] = gen_dispatch[cp_bp] = GeneratePawnMoves;
gen_dispatch[cp_wn] = gen_dispatch[cp_bn] = GenerateUsualMoves;
gen_dispatch[cp_wb] = gen_dispatch[cp_bb] = GenerateUsualMoves;
gen_dispatch[cp_wr] = gen_dispatch[cp_br] = GenerateUsualMoves;
gen_dispatch[cp_wq] = gen_dispatch[cp_bq] = GenerateUsualMoves;
gen_dispatch[cp_wk] = gen_dispatch[cp_bk] = GenerateKingMoves;

/* set up the capture move dispatch vector */

gen_capt_dispatch[cp_wp] = gen_capt_dispatch[cp_bp] = GeneratePawnCaptures;
gen_capt_dispatch[cp_wn] = gen_capt_dispatch[cp_bn] = GenerateUsualCaptures;
gen_capt_dispatch[cp_wb] = gen_capt_dispatch[cp_bb] = GenerateUsualCaptures;
gen_capt_dispatch[cp_wr] = gen_capt_dispatch[cp_br] = GenerateUsualCaptures;
gen_capt_dispatch[cp_wq] = gen_capt_dispatch[cp_bq] = GenerateUsualCaptures;
gen_capt_dispatch[cp_wk] = gen_capt_dispatch[cp_bk] = GenerateKingCaptures;

return;
}

/*<<< gen.c: EOF */
