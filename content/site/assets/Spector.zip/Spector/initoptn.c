/*>>> initoptn.c: initialize option vectors */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "initoptn.h"

/*--> InitOp: set up a single option vector entry */
static
void
InitOp(optnT optn, charptrT nptr, charptrT hptr)
{
optnstrv[optn] = nptr;
optnhlpv[optn] = hptr;
optnv[optn] = 0;

return;
}

/*--> InitOptions: set up option vectors */
nonstatic
void
InitOptions(void)
{
InitOp(optn_adcb, "adcb", "automatic display chess board after move");
InitOp(optn_adps, "adps", "automatic display program status after move");
InitOp(optn_amet, "amet", "automatic move entry time adjust");
InitOp(optn_apps, "apps", "automatic program ponder search");
InitOp(optn_asgc, "asgc", "automatic save game checkpoints");
InitOp(optn_brep, "brep", "beep on program move reply");
InitOp(optn_dbug, "dbug", "general debugging");
InitOp(optn_dwob, "dwob", "display is white on black background");
InitOp(optn_echo, "echo", "enable command input echo to dribble file");
InitOp(optn_emde, "emde", "extraordinary move disambiguation efforts");
InitOp(optn_expn, "expn", "expanded notation");
InitOp(optn_flsh, "flsh", "force output file flushing");
InitOp(optn_freq, "freq", "report move execution frequency");
InitOp(optn_nafm, "nafm", "no announcement of forced mates");
InitOp(optn_napr, "napr", "no auto program move reply");
InitOp(optn_nbms, "nbms", "no opening book move search");
InitOp(optn_ndpm, "ndpm", "no display played move");
InitOp(optn_nhtm, "nhtm", "no hash table moves");
InitOp(optn_nmde, "nmde", "no move disambiguation efforts");
InitOp(optn_nocm, "nocm", "no oracular consultation moves");
InitOp(optn_nqmr, "nqmr", "no quick move response");
InitOp(optn_obep, "obep", "opening book compile: exp. position generation");
InitOp(optn_obfc, "obfc", "opening book compile: file correction");
InitOp(optn_obmp, "obmp", "opening book compile: write move path file");
InitOp(optn_obrt, "obrt", "opening book compile: retain move tree");
InitOp(optn_osnr, "osnr", "use ordinal string numeric representations");
InitOp(optn_pbmp, "pbmp", "packed book production: write move path file");
InitOp(optn_pbtx, "pbtx", "packed book production: write move tree file");
InitOp(optn_poor, "poor", "consider even poor opening book moves");
InitOp(optn_rsgn, "rsgn", "resignation offers/suggestions");
InitOp(optn_spin, "spin", "rotate board display output by pi radians");
InitOp(optn_temp, "temp", "temporary usage development flag");
InitOp(optn_teps, "teps", "trace enable during ponder search");
InitOp(optn_test, "test", "developer testing active");
InitOp(optn_trab, "trab", "trace: alpha beta search");
InitOp(optn_trbc, "trbc", "trace: opening book compilation");
InitOp(optn_trcs, "trcs", "trace: concept search");
InitOp(optn_trel, "trel", "trace: external link activity");
InitOp(optn_tren, "tren", "trace: descendant enumeration");
InitOp(optn_trev, "trev", "trace: position evaluation");
InitOp(optn_trfd, "trfd", "trace: first time down tree search");
InitOp(optn_trmp, "trmp", "trace: move path");
InitOp(optn_trpm, "trpm", "trace: predicted move");
InitOp(optn_trpt, "trpt", "trace: command processing time");
InitOp(optn_trpv, "trpv", "trace: predicted variation");
InitOp(optn_trpz, "trpz", "trace: ply zero move pick");
InitOp(optn_trrs, "trrs", "trace: refutation sequences");
InitOp(optn_trst, "trst", "trace: search termination reason");
InitOp(optn_trts, "trts", "trace: timestamp trace");
InitOp(optn_trtt, "trtt", "trace: transposition table subsystem");
InitOp(optn_verb, "verb", "verbose mode");
InitOp(optn_vsyn, "vsyn", "voice synthesizer");
InitOp(optn_wump, "wump", "announce opponent's forced checkmates");
InitOp(optn_xtra, "xtra", "extra option");

return;
}

/*<<< initoptn.c: EOF */
