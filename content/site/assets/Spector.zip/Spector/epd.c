/*>>> epd.c: Extended Position Description routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"

#include "commdefs.h"

#include "epddefs.h"
#include "epdvars.h"

#include "create.h"
#include "epd.h"
#include "memutil.h"
#include "parm.h"
#include "sysutil.h"
#include "util.h"

/* EPD standard opcode mnemonics */

static charptrT epdsostrv[epdsoL];

/* EPD refcom operand strings */

static charptrT refcomstrv[refcomL];

/* EPD refreq operand strings */

static charptrT refreqstrv[refreqL];

/* PGN Seven Tag Roster names */

static charptrT pgnstrstrv[pgnstrL];

/*--> EPDNewEOV: allocate a new EOV record */
nonstatic
eovptrT
EPDNewEOV(void)
{
eovptrT eovptr;

eovptr = (eovptrT) MemoryGrab(sizeof(eovT));

eovptr->eov_eob = eob_nil;
eovptr->eov_str = NULL;
eovptr->eov_prev = eovptr->eov_next = NULL;

return (eovptr);
}

/*--> EPDReleaseEOV: release an EOV record */
nonstatic
void
EPDReleaseEOV(eovptrT eovptr)
{
if (eovptr != NULL)
	{
	if (eovptr->eov_str != NULL)
		MemoryFree(eovptr->eov_str);
	MemoryFree(eovptr);
	};

return;
}

/*--> EPDAppendEOV: append an EOV record */
nonstatic
void
EPDAppendEOV(eopptrT eopptr, eovptrT eovptr)
{
if (eopptr->eop_taileov == NULL)
	eopptr->eop_headeov = eovptr;
else
	eopptr->eop_taileov->eov_next = eovptr;

eovptr->eov_prev = eopptr->eop_taileov;
eovptr->eov_next = NULL;

eopptr->eop_taileov = eovptr;

return;
}

/*--> EPDUnthreadEOV: unthread an EOV record */
static
void
EPDUnthreadEOV(eopptrT eopptr, eovptrT eovptr)
{
if (eovptr->eov_prev == NULL)
	eopptr->eop_headeov = eovptr->eov_next;
else
	eovptr->eov_prev->eov_next = eovptr->eov_next;

if (eovptr->eov_next == NULL)
	eopptr->eop_taileov = eovptr->eov_prev;
else
	eovptr->eov_next->eov_prev = eovptr->eov_prev;

return;
}

/*--> EPDCreateEOVStr: create a new EOV record with a string value */
nonstatic
eovptrT
EPDCreateEOVStr(charptrT str)
{
eovptrT eovptr;

eovptr = EPDNewEOV();
eovptr->eov_eob = eob_string;
eovptr->eov_str = StringGrab(str);

return (eovptr);
}

/*--> EPDCreateEOVSym: create a new EOV record with a symbol value */
nonstatic
eovptrT
EPDCreateEOVSym(charptrT sym)
{
eovptrT eovptr;

eovptr = EPDNewEOV();
eovptr->eov_eob = eob_symbol;
eovptr->eov_str = StringGrab(sym);

return (eovptr);
}

/*--> EPDCreateEOVInt: create a new EOV record with an integer value */
nonstatic
eovptrT
EPDCreateEOVInt(liT lval)
{
eovptrT eovptr;
char tv[tL];

sprintf(tv, "%ld", lval);
eovptr = EPDNewEOV();
eovptr->eov_eob = eob_symbol;
eovptr->eov_str = StringGrab(tv);

return (eovptr);
}

/*--> EPDLocateEOV: try to locate 1st EOV record with given string value */
nonstatic
eovptrT
EPDLocateEOV(eopptrT eopptr, charptrT strval)
{
eovptrT eovptr;
siT flag;

flag = 0;
eovptr = eopptr->eop_headeov;
while (!flag && (eovptr != NULL))
	if (strcmp(strval, eovptr->eov_str) == 0)
		flag = 1;
	else
		eovptr = eovptr->eov_next;

if (!flag)
	eovptr = NULL;

return (eovptr);
}

/*--> EPDCountEOV: count EOV entries in EOP */
nonstatic
siT
EPDCountEOV(eopptrT eopptr)
{
eovptrT eovptr;
siT count;

count = 0;
eovptr = eopptr->eop_headeov;
while (eovptr != NULL)
	{
	count++;
	eovptr = eovptr->eov_next;
	};

return (count);
}

/*--> EPDReplaceEOVStr: replace EOV string value with  given string value */
nonstatic
void
EPDReplaceEOVStr(eovptrT eovptr, charptrT str)
{
if (eovptr->eov_str != NULL)
	{
	MemoryFree(eovptr->eov_str);
	eovptr->eov_str = NULL;
	};

if (str != NULL)
	eovptr->eov_str = StringGrab(str);

return;
}

/*--> EPDAddOpSym: add a single symbol operand operation */
nonstatic
void
EPDAddOpSym(epdptrT epdptr, epdsoT epdso, charptrT s)
{
eopptrT eopptr;
eovptrT eovptr;

eovptr = EPDCreateEOVSym(s);
eopptr = EPDCreateEOPCode(epdso);
EPDAppendEOV(eopptr, eovptr);
EPDDropIfLocEOPCode(epdptr, epdso);
EPDAppendEOP(epdptr, eopptr);

return;
}

/*--> EPDNewEOP: allocate a new EOP record */
nonstatic
eopptrT
EPDNewEOP(void)
{
eopptrT eopptr;

eopptr = (eopptrT) MemoryGrab(sizeof(eopT));

eopptr->eop_opsym = NULL;
eopptr->eop_headeov = eopptr->eop_taileov = NULL;
eopptr->eop_prev = eopptr->eop_next = NULL;

return (eopptr);
}

/*--> EPDReleaseEOP: release an EOP record */
nonstatic
void
EPDReleaseEOP(eopptrT eopptr)
{
eovptrT eovptr0, eovptr1;

if (eopptr != NULL)
	{
	if (eopptr->eop_opsym != NULL)
		MemoryFree(eopptr->eop_opsym);
	eovptr0 = eopptr->eop_headeov;
	while (eovptr0 != NULL)
		{
		eovptr1 = eovptr0->eov_next;
		EPDUnthreadEOV(eopptr, eovptr0);
		EPDReleaseEOV(eovptr0);
		eovptr0 = eovptr1;
		};
	MemoryFree(eopptr);
	};

return;
}

/*--> EPDAppendEOP: append an EOP record */
nonstatic
void
EPDAppendEOP(epdptrT epdptr, eopptrT eopptr)
{
if (epdptr->epd_taileop == NULL)
	epdptr->epd_headeop = eopptr;
else
	epdptr->epd_taileop->eop_next = eopptr;

eopptr->eop_prev = epdptr->epd_taileop;
eopptr->eop_next = NULL;

epdptr->epd_taileop = eopptr;

return;
}

/*--> EPDUnthreadEOP: unthread an EOP record */
static
void
EPDUnthreadEOP(epdptrT epdptr, eopptrT eopptr)
{
if (eopptr->eop_prev == NULL)
	epdptr->epd_headeop = eopptr->eop_next;
else
	eopptr->eop_prev->eop_next = eopptr->eop_next;

if (eopptr->eop_next == NULL)
	epdptr->epd_taileop = eopptr->eop_prev;
else
	eopptr->eop_next->eop_prev = eopptr->eop_prev;

return;
}

/*--> EPDCreateEOP: create a new EOP record with opsym */
nonstatic
eopptrT
EPDCreateEOP(charptrT opsym)
{
eopptrT eopptr;

eopptr = EPDNewEOP();
eopptr->eop_opsym = StringGrab(opsym);

return (eopptr);
}

/*--> EPDCreateEOPCode: create a new EOP record using opsym index */
nonstatic
eopptrT
EPDCreateEOPCode(epdsoT epdso)
{
eopptrT eopptr;

eopptr = EPDCreateEOP(EPDFetchOpsym(epdso));

return (eopptr);
}

/*--> EPDLocateEOP: attempt to locate EOP record with  given opsym */
nonstatic
eopptrT
EPDLocateEOP(epdptrT epdptr, charptrT opsym)
{
eopptrT eopptr;
siT flag;

flag = 0;
eopptr = epdptr->epd_headeop;
while (!flag && (eopptr != NULL))
	if (strcmp(opsym, eopptr->eop_opsym) == 0)
		flag = 1;
	else
		eopptr = eopptr->eop_next;

if (!flag)
	eopptr = NULL;

return (eopptr);
}

/*--> EPDLocateEOPCode: attempt to locate EOP record with given code */
nonstatic
eopptrT
EPDLocateEOPCode(epdptrT epdptr, epdsoT epdso)
{

return (EPDLocateEOP(epdptr, epdsostrv[epdso]));
}

/*--> EPDCountEOP: count EOP entries in EPD */
nonstatic
siT
EPDCountEOP(epdptrT epdptr)
{
eopptrT eopptr;
siT count;

count = 0;
eopptr = epdptr->epd_headeop;
while (eopptr != NULL)
	{
	count++;
	eopptr = eopptr->eop_next;
	};

return (count);
}

/*--> EPDDropIfLocEOP: try to locate/drop EOP record with given opsym */
nonstatic
void
EPDDropIfLocEOP(epdptrT epdptr, charptrT opsym)
{
eopptrT eopptr;

eopptr = EPDLocateEOP(epdptr, opsym);
if (eopptr != NULL)
	{
	EPDUnthreadEOP(epdptr, eopptr);
	EPDReleaseEOP(eopptr);
	};

return;
}

/*--> EPDDropIfLocEOPCode: try to locate/drop EOP record with given code */
nonstatic
void
EPDDropIfLocEOPCode(epdptrT epdptr, epdsoT epdso)
{
eopptrT eopptr;

eopptr = EPDLocateEOP(epdptr, epdsostrv[epdso]);
if (eopptr != NULL)
	{
	EPDUnthreadEOP(epdptr, eopptr);
	EPDReleaseEOP(eopptr);
	};

return;
}

/*--> EPDNewEPD: allocate a new EPD record */
nonstatic
epdptrT
EPDNewEPD(void)
{
epdptrT epdptr;
siT i;

epdptr = (epdptrT) MemoryGrab(sizeof(epdT));

for (i = 0; i < nbL; i++)
	epdptr->epd_nbv[i] = ((cp_v0 << nybbW) | cp_v0);

epdptr->epd_actc = c_w;
epdptr->epd_cast = 0;
epdptr->epd_epsq = sq_nil;
epdptr->epd_headeop = epdptr->epd_taileop = NULL;

return (epdptr);
}

/*--> EPDReleaseOperations: release EPD operation list */
nonstatic
void
EPDReleaseOperations(epdptrT epdptr)
{
eopptrT eopptr0, eopptr1;

if (epdptr != NULL)
	{
	eopptr0 = epdptr->epd_headeop;
	while (eopptr0 != NULL)
		{
		eopptr1 = eopptr0->eop_next;
		EPDUnthreadEOP(epdptr, eopptr0);
		EPDReleaseEOP(eopptr0);
		eopptr0 = eopptr1;
		};
	epdptr->epd_headeop = NULL;
	epdptr->epd_taileop = NULL;
	};

return;
}

/*--> EPDReleaseEPD: release an EPD record */
nonstatic
void
EPDReleaseEPD(epdptrT epdptr)
{
if (epdptr != NULL)
	{
	EPDReleaseOperations(epdptr);
	MemoryFree(epdptr);
	};

return;
}

/*--> EPDFetchOpsym: return a pointer to the indicated mnemonic */
nonstatic
charptrT
EPDFetchOpsym(epdsoT epdso)
{

return (epdsostrv[epdso]);
}

/*--> EPDFetchRefcomStr: return  pointer of indicated refcom string */
nonstatic
charptrT
EPDFetchRefcomStr(refcomT refcom)
{

return (refcomstrv[refcom]);
}

/*--> EPDFetchRefreqStr: return  pointer of indicated refreq string */
nonstatic
charptrT
EPDFetchRefreqStr(refreqT refreq)
{

return (refreqstrv[refreq]);
}

/*--> EPDFetchRefcomIndex: return a referee command index */
nonstatic
refcomT
EPDFetchRefcomIndex(charptrT s)
{
refcomT refcom;
refcomT rcom;

refcom = refcom_nil;
rcom = 0;
while ((refcom == refcom_nil) && (rcom < refcomL))
	if (strcmp(s, EPDFetchRefcomStr(rcom)) == 0)
		refcom = rcom;
	else
		rcom++;

return (refcom);
}

/*--> EPDFetchRefreqIndex: return a referee request index */
nonstatic
refreqT
EPDFetchRefreqIndex(charptrT s)
{
refreqT refreq;
refreqT rreq;

refreq = refreq_nil;
rreq = 0;
while ((refreq == refreq_nil) && (rreq < refreqL))
	if (strcmp(s, EPDFetchRefreqStr(rreq)) == 0)
		refreq = rreq;
	else
		rreq++;

return (refreq);
}

/*--> EPDExtractRefcomIndex: extract a referee command index */
nonstatic
refcomT
EPDExtractRefcomIndex(epdptrT epdptr)
{
refcomT refcom;
eopptrT eopptr;
eovptrT eovptr;

/* set default return value */

refcom = refreq_nil;

if (epdptr != NULL)
	if ((eopptr = EPDLocateEOPCode(epdptr, epdso_refcom)) != NULL)
		if ((eovptr = eopptr->eop_headeov) != NULL)
			refcom = EPDFetchRefcomIndex(eovptr->eov_str);

return (refcom);
}

/*--> EPDExtractRefreqIndex: extract a referee request index */
nonstatic
refreqT
EPDExtractRefreqIndex(epdptrT epdptr)
{
refreqT refreq;
eopptrT eopptr;
eovptrT eovptr;

/* set default return value */

refreq = refreq_nil;

if (epdptr != NULL)
	if ((eopptr = EPDLocateEOPCode(epdptr, epdso_refreq)) != NULL)
		if ((eovptr = eopptr->eop_headeov) != NULL)
			refreq = EPDFetchRefreqIndex(eovptr->eov_str);

return (refreq);
}

/*--> EPDCountOperands: count operands */
static
siT
EPDCountOperands(eopptrT eopptr)
{
siT count;
eovptrT eovptr;

count = 0;
eovptr = eopptr->eop_headeov;
while (eovptr != NULL)
	{
	count++;
	eovptr = eovptr->eov_next;
	};

return (count);
}

/*--> EPDCountOperations: count operations */
static
siT
EPDCountOperations(epdptrT epdptr)
{
siT count;
eopptrT eopptr;

count = 0;
eopptr = epdptr->epd_headeop;
while (eopptr != NULL)
	{
	count++;
	eopptr = eopptr->eop_next;
	};

return (count);
}

/*--> EPDSortOperands: sort operands according to string value */
static
void
EPDSortOperands(eopptrT eopptr)
{
siT count;
siT pass, flag;
eovptrT ptr0, ptr1, ptr2, ptr3;

count = EPDCountOperands(eopptr);
if (count > 1)
	{
	flag = 1;
	pass = 0;
	while (flag && (pass < (count - 1)))
		{
		flag = 0;
		ptr0 = eopptr->eop_headeov;
		ptr1 = ptr0->eov_next;
		while (ptr1 != NULL)
			{
			if (strcmp(ptr0->eov_str, ptr1->eov_str) > 0)
				{
				flag = 1;

				ptr2 = ptr0->eov_prev;
				ptr3 = ptr1->eov_next;

				ptr0->eov_prev = ptr1;
				ptr0->eov_next = ptr3;

				ptr1->eov_prev = ptr2;
				ptr1->eov_next = ptr0;

				if (ptr2 == NULL)
					eopptr->eop_headeov = ptr1;
				else
					ptr2->eov_next = ptr1;

				if (ptr3 == NULL)
					eopptr->eop_taileov = ptr0;
				else
					ptr3->eov_prev = ptr0;
				}
			else
				ptr0 = ptr1;

			ptr1 = ptr0->eov_next;
			};
		pass++;
		};
	};

return;
}

/*--> EPDSortOperations: sort operations according to opcode */
static
void
EPDSortOperations(epdptrT epdptr)
{
siT count;
siT pass, flag;
eopptrT ptr0, ptr1, ptr2, ptr3;

count = EPDCountOperations(epdptr);
if (count > 1)
	{
	flag = 1;
	pass = 0;
	while (flag && (pass < (count - 1)))
		{
		flag = 0;
		ptr0 = epdptr->epd_headeop;
		ptr1 = ptr0->eop_next;
		while (ptr1 != NULL)
			{
			if (strcmp(ptr0->eop_opsym, ptr1->eop_opsym) > 0)
				{
				flag = 1;

				ptr2 = ptr0->eop_prev;
				ptr3 = ptr1->eop_next;

				ptr0->eop_prev = ptr1;
				ptr0->eop_next = ptr3;

				ptr1->eop_prev = ptr2;
				ptr1->eop_next = ptr0;

				if (ptr2 == NULL)
					epdptr->epd_headeop = ptr1;
				else
					ptr2->eop_next = ptr1;

				if (ptr3 == NULL)
					epdptr->epd_taileop = ptr0;
				else
					ptr3->eop_prev = ptr0;
				}
			else
				ptr0 = ptr1;

			ptr1 = ptr0->eop_next;
			};
		pass++;
		};
	};

return;
}

/*--> EPDNormalize: apply normalizing sorts */
static
void
EPDNormalize(epdptrT epdptr)
{
eopptrT eopptr;
charptrT opsym;
siT flag;

EPDSortOperations(epdptr);

eopptr = epdptr->epd_headeop;
while (eopptr != NULL)
	{
	flag = 0;
	opsym = eopptr->eop_opsym;

	if (!flag && (strcmp(opsym, "am") == 0))
		{
		EPDSortOperands(eopptr);
		flag = 1;
		};

	if (!flag && (strcmp(opsym, "bm") == 0))
		{
		EPDSortOperands(eopptr);
		flag = 1;
		};

	eopptr = eopptr->eop_next;
	};

return;
}

/*--> EPDSet: set up an EPD structure for the given position */
nonstatic
epdptrT
EPDSet(rbptrT rbptr, cT actc, castT cast, sqT epsq)
{
epdptrT epdptr;
sqT sq;
cpT cp0, cp1;

epdptr = EPDNewEPD();

for (sq = sq_a1; sq <= sq_h8; sq += 2)
	{
	cp0 = rbptr->rbv[sq + 0];
	cp1 = rbptr->rbv[sq + 1];
	epdptr->epd_nbv[sq >> 1] = ((cp1 << nybbW) | cp0);
	};

epdptr->epd_actc = actc;
epdptr->epd_cast = cast;
epdptr->epd_epsq = epsq;

return (epdptr);
}

/*--> EPDSetCurrent: generate basic EPD for current position */
nonstatic
epdptrT
EPDSetCurrent(void)
{
epdptrT epdptr;

epdptr = EPDSet(&local, actc, envn.envn_cast, envn.envn_epsq);

return (epdptr);
}

/*--> EPDGenBasic: generate basic EPD notation for a given position */
nonstatic
charptrT
EPDGenBasic(rbptrT rbptr, cT actc, castT cast, sqT epsq)
{
charptrT ptr;
epdptrT epdptr;

epdptr = EPDSet(rbptr, actc, cast, epsq);
ptr = EPDEncode(epdptr);

EPDReleaseEPD(epdptr);

return (ptr);
}

/*--> EPDGenBasicCurrent: generate basic EPD for current position */
nonstatic
charptrT
EPDGenBasicCurrent(void)
{
charptrT ptr;

ptr = EPDGenBasic(&local, actc, envn.envn_cast, envn.envn_epsq);

return (ptr);
}

/*--> EPDDecode: read an EPD structure from a string */
nonstatic
epdptrT
EPDDecode(charptrT s)
{
epdptrT epdptr;
eopptrT eopptr;
eovptrT eovptr;
siT flag, quoteflag;
siT ch;
liT i;
siT j, d;
byteptrT bptr;
fileT file;
rankT rank;
sqT sq;
cT c;
pT p;
cpT cp;

/* set up */

flag = 1;
i = 0;
ch = *(s + i++);

/* initialize the return structure */

epdptr = EPDNewEPD();

/* skip whitespace */

if (flag)
	{
	while (flag && (ch != ascii_nul) && isspace(ch))
		ch = *(s + i++);
	if (ch == ascii_nul)
		flag = 0;
	};

/* process piece placement data */

if (flag)
	{
	rank = rank_8;
	file = file_a;

	while (flag && (ch != ascii_nul) && !isspace(ch))
		{
		switch (ch)
			{
			case '/':
				if ((file != fileL) || (rank == rank_1))
					flag = 0;
				else
					{
					rank--;
					file = file_a;
					};
				break;

			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
				d = ch - '0';
				if ((file + d) > fileL)
					flag = 0;
				else
					for (j = 0; j < d; j++)
						{
						sq = map_sq(rank, file);
						bptr = &epdptr->epd_nbv[sq >> 1];
						if ((sq % 2) == 0)
							{
							*bptr &= ~nybbM;
							*bptr |= cp_v0;
							}
						else
							{
							*bptr &= ~(nybbM << nybbW);
							*bptr |= (cp_v0 << nybbW);
							};
						file++;
						};
				break;

			default:
				if (!ParameterCheckPiece(ch) || (file >= fileL))
					flag = 0;
				else
					{
					p = ParameterEvalPiece(ch);
					if (isupper(ch))
						c = c_w;
					else
						c = c_b;
					sq = map_sq(rank, file);
					bptr = &epdptr->epd_nbv[sq >> 1];
					cp = cv_cp_c_pv[c][p];
					if ((sq % 2) == 0)
						{
						*bptr &= ~nybbM;
						*bptr |= cp;
						}
					else
						{
						*bptr &= ~(nybbM << nybbW);
						*bptr |= (cp << nybbW);
						};
					file++;
					};
				break;
			};

		ch = *(s + i++);
		};

	if (flag)
		if ((file != fileL) || (rank != rank_1))
			flag = 0;
	};

/* skip whitespace */

if (flag)
	{
	while (flag && (ch != ascii_nul) && isspace(ch))
		ch = *(s + i++);
	if (ch == ascii_nul)
		flag = 0;
	};

/* process active color */

if (flag)
	{
	if (!ParameterCheckColor(ch))
		flag = 0;
	else
		{
		epdptr->epd_actc = ParameterEvalColor(ch);
		ch = *(s + i++);
		if (!isspace(ch))
			flag = 0;
		};
	};

/* skip whitespace */

if (flag)
	{
	while (flag && (ch != ascii_nul) && isspace(ch))
		ch = *(s + i++);
	if (ch == ascii_nul)
		flag = 0;
	};

/* process castling availability */

if (flag)
	{
	if (ch == '-')
		{
		epdptr->epd_cast = 0;
		ch = *(s + i++);
		if (!isspace(ch))
			flag = 0;
		}
	else
		{
		epdptr->epd_cast = 0;
		j = 0;
		while (flag && (ch != ascii_nul) && !isspace(ch))
			{
			if (isupper(ch))
				{
				if (CICharEqual(ch, ascpv[lang_san][p_k]))
					epdptr->epd_cast |= cf_wk;
				else
					if (CICharEqual(ch, ascpv[lang_san][p_q]))
						epdptr->epd_cast |= cf_wq;
					else
						flag = 0;
				}
			else
				{
				if (CICharEqual(ch, ascpv[lang_san][p_k]))
					epdptr->epd_cast |= cf_bk;
				else
					if (CICharEqual(ch, ascpv[lang_san][p_q]))
						epdptr->epd_cast |= cf_bq;
					else
						flag = 0;
				};

			if (flag && (j > 4))
				flag = 0;

			if (flag)
				{
				j++;
				ch = *(s + i++);
				};
			};

		if (flag && !isspace(ch))
			flag = 0;
		};
	};

/* skip whitespace */

if (flag)
	{
	while (flag && (ch != ascii_nul) && isspace(ch))
		ch = *(s + i++);
	if (ch == ascii_nul)
		flag = 0;
	};

/* process en passant target */

if (flag)
	{
	if (ch == '-')
		{
		epdptr->epd_epsq = sq_nil;
		ch = *(s + i++);
		if ((ch != ascii_nul) && !isspace(ch))
			flag = 0;
		}
	else
		{
		if (flag)
			if (!ParameterCheckFile(ch))
				flag = 0;
			else
				{
				file = ParameterEvalFile(ch);
				ch = *(s + i++);
				};
		if (flag)
			if (!ParameterCheckRank(ch))
				flag = 0;
			else
				{
				rank = ParameterEvalRank(ch);
				ch = *(s + i++);
				};
		if (flag)
			epdptr->epd_epsq = map_sq(rank, file);
		};
	};

/* skip whitespace (end-of-line is not an error) */

if (flag)
	{
	while (flag && (ch != ascii_nul) && isspace(ch))
		ch = *(s + i++);
	};

/* process operation sequence (if any) */

if (flag)
	{
	while (flag && (ch != ascii_nul))
		{
		/* allocate a new operation */

		eopptr = EPDNewEOP();

		/* form opsym (first character) */

		if (IdentChar(ch))
			{
			eopptr->eop_opsym = StringGrab("");
			eopptr->eop_opsym = StringAppendChar(eopptr->eop_opsym, ch);
			ch = *(s + i++);
			}
		else
			flag = 0;

		/* form remainder of opsym */

		while (IdentChar(ch))
			{
			eopptr->eop_opsym = StringAppendChar(eopptr->eop_opsym, ch);
			ch = *(s + i++);
			};

		/* skip whitespace */

		if (flag)
			{
			while (flag && (ch != ascii_nul) && isspace(ch))
				ch = *(s + i++);
			if (ch == ascii_nul)
				flag = 0;
			};

		/* process operand list */

		while (flag && (ch != ';'))
			{
			/* allocate operand value */

			eovptr = EPDNewEOV();

			/* set quoted string as appropriate */

			if (ch == '"')
				{
				quoteflag = 1;
				eovptr->eov_eob = eob_string;
				ch = *(s + i++);
				}
			else
				{
				quoteflag = 0;
				eovptr->eov_eob = eob_symbol;
				};

			eovptr->eov_str = StringGrab("");

			if (quoteflag)
				{
				while (flag && (ch != '"'))
					{
					if (ch == ascii_nul)
						flag = 0;
					else
						{
						eovptr->eov_str =
							StringAppendChar(eovptr->eov_str, ch);
						ch = *(s + i++);
						};
					};
				if (ch == '"')
					ch = *(s + i++);
				}
			else
				{
				while (flag && !isspace(ch) && (ch != ';'))
					{
					if (ch == ascii_nul)
						flag = 0;
					else
						{
						eovptr->eov_str =
							StringAppendChar(eovptr->eov_str, ch);
						ch = *(s + i++);
						};
					};
				};

			/* append operand onto operation */

			if (flag)
				EPDAppendEOV(eopptr, eovptr);
			else
				EPDReleaseEOV(eovptr);

			/* skip whitespace */

			while (flag && (ch != ascii_nul) && isspace(ch))
				ch = *(s + i++);
			};

		/* process semicolon */

		if (flag)
			if (ch == ';')
				ch = *(s + i++);
			else
				flag = 0;

		/* append operation */

		if (flag)
			EPDAppendEOP(epdptr, eopptr);
		else
			EPDReleaseEOP(eopptr);

		/* skip whitespace (end-of-line is not an error) */

		if (flag)
			while (flag && (ch != ascii_nul) && isspace(ch))
				ch = *(s + i++);
		};
	};

/* check for fault */

if (!flag)
	{
	EPDReleaseEPD(epdptr);
	epdptr = NULL;
	};

/* normalize */

if (epdptr != NULL)
	EPDNormalize(epdptr);

return (epdptr);
}

/*--> EPDEncode: write an EPD structure to a string */
nonstatic
charptrT
EPDEncode(epdptrT epdptr)
{
charptrT ptr;
sqT sq;
cpT cp;
rankT rank;
fileT file;
siT bi, ps, ch;
char bv[tL];
eopptrT eopptr;
eovptrT eovptr;
charptrT s0, s1;

bi = 0;

/* normalize */

if (epdptr != NULL)
	EPDNormalize(epdptr);

/* output board */

for (rank = rank_8; rank >= rank_1; rank--)
	{
	ps = 0;
	for (file = file_a; file <= file_h; file++)
		{
		sq = map_sq(rank, file);
		if ((sq % 2) == 0)
			cp = (epdptr->epd_nbv[sq >> 1] & nybbM);
		else
			cp = ((epdptr->epd_nbv[sq >> 1] >> nybbW) & nybbM);

		if (cp == cp_v0)
			ps++;
		else
			{
			if (ps != 0)
				{
				bv[bi++] = '0' + ps;
				ps = 0;
				};
			ch = ascpv[lang_put][cv_p_cpv[cp]];
			if (cv_c_cpv[cp] == c_w)
				ch = map_upper(ch);
			else
				ch = map_lower(ch);
			bv[bi++] = ch;
			};
		};
	if (ps != 0)
		{
		bv[bi++] = '0' + ps;
		ps = 0;
		};
	if (rank != rank_1)
		bv[bi++] = '/';
	};
bv[bi++] = ' ';

/* output active color (lower case) */

bv[bi++] = map_lower(asccv[lang_put][epdptr->epd_actc]);
bv[bi++] = ' ';

/* output castling availablility */

if (epdptr->epd_cast == 0)
	bv[bi++] = '-';
else
	{
	if (epdptr->epd_cast & cf_wk)
		bv[bi++] = map_upper(ascpv[lang_put][p_k]);
	if (epdptr->epd_cast & cf_wq)
		bv[bi++] = map_upper(ascpv[lang_put][p_q]);
	if (epdptr->epd_cast & cf_bk)
		bv[bi++] = map_lower(ascpv[lang_put][p_k]);
	if (epdptr->epd_cast & cf_bq)
		bv[bi++] = map_lower(ascpv[lang_put][p_q]);
	};
bv[bi++] = ' ';

/* output ep capture square */

if (epdptr->epd_epsq == sq_nil)
	bv[bi++] = '-';
else
	{
	bv[bi++] = ascfv[map_file(epdptr->epd_epsq)];
	bv[bi++] = ascrv[map_rank(epdptr->epd_epsq)];
	};

/* NUL termination */

bv[bi++] = ascii_nul;

/* allocate and copy basic result */

ptr = StringGrab(bv);

/* construct and append operations */

eopptr = epdptr->epd_headeop;
while (eopptr != NULL)
	{
	/* leading space */

	s0 = StringGrab(" ");

	/* opcode */

	s0 = StringAppendStr(s0, eopptr->eop_opsym);

	/* construct and append operands */

	eovptr = eopptr->eop_headeov;
	while (eovptr != NULL)
		{
		/* leading space */

		s1 = StringGrab(" ");

		/* conjure operand value */

		switch (eovptr->eov_eob)
			{
			case eob_string:
				s1 = StringAppendChar(s1, '"');
				s1 = StringAppendStr(s1, eovptr->eov_str);
				s1 = StringAppendChar(s1, '"');
				break;

			case eob_symbol:
				s1 = StringAppendStr(s1, eovptr->eov_str);
				break;

			default:
				SwitchFault("EPDEncode");
				break;
			};

		/* append */

		s0 = StringAppendStr(s0, s1);
		MemoryFree(s1);

		/* next operand */

		eovptr = eovptr->eov_next;
		};

	/* trailing semicolon */

	s0 = StringAppendChar(s0, ';');

	/* append operation */

	ptr = StringAppendStr(ptr, s0);
	MemoryFree(s0);

	/* advance */

	eopptr = eopptr->eop_next;
	};

return (ptr);
}

/*--> EPDRealize: set the current position according to EPD */
nonstatic
void
EPDRealize(epdptrT epdptr)
{
sqT sq;
cpT cp;

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	if ((sq % 2) == 0)
		cp = (epdptr->epd_nbv[sq >> 1] & nybbM);
	else
		cp = ((epdptr->epd_nbv[sq >> 1] >> nybbW) & nybbM);
	board.rbv[sq] = cp;
	};

actc = epdptr->epd_actc;
pasc = inv_cv[actc];

envn.envn_cast = epdptr->epd_cast;
envn.envn_epsq = epdptr->epd_epsq;

envn.envn_hmvc = 0;
envn.envn_fmvn = 1;

CreateSetUp();

return;
}

/*--> EPDInit: one time initialization for EPD */
nonstatic
void
EPDInit(void)
{
/* initialize the standard opcode string vector */

epdsostrv[epdso_acd        ] = "acd";
epdsostrv[epdso_acn        ] = "acn";
epdsostrv[epdso_acs        ] = "acs";
epdsostrv[epdso_am         ] = "am";
epdsostrv[epdso_bm         ] = "bm";
epdsostrv[epdso_c0         ] = "c0";
epdsostrv[epdso_c1         ] = "c1";
epdsostrv[epdso_c2         ] = "c2";
epdsostrv[epdso_c3         ] = "c3";
epdsostrv[epdso_c4         ] = "c4";
epdsostrv[epdso_c5         ] = "c5";
epdsostrv[epdso_c6         ] = "c6";
epdsostrv[epdso_c7         ] = "c7";
epdsostrv[epdso_c8         ] = "c8";
epdsostrv[epdso_c9         ] = "c9";
epdsostrv[epdso_cc         ] = "cc";
epdsostrv[epdso_ce         ] = "ce";
epdsostrv[epdso_dm         ] = "dm";
epdsostrv[epdso_draw_accept] = "draw_accept";
epdsostrv[epdso_draw_claim ] = "draw_claim";
epdsostrv[epdso_draw_offer ] = "draw_offer";
epdsostrv[epdso_draw_reject] = "draw_reject";
epdsostrv[epdso_eco        ] = "eco";
epdsostrv[epdso_fmvn       ] = "fmvn";
epdsostrv[epdso_hmvc       ] = "hmvc";
epdsostrv[epdso_id         ] = "id";
epdsostrv[epdso_nic        ] = "nic";
epdsostrv[epdso_noop       ] = "noop";
epdsostrv[epdso_pm         ] = "pm";
epdsostrv[epdso_ptp        ] = "ptp";
epdsostrv[epdso_pv         ] = "pv";
epdsostrv[epdso_rc         ] = "rc";
epdsostrv[epdso_refcom     ] = "refcom";
epdsostrv[epdso_refreq     ] = "refreq";
epdsostrv[epdso_resign     ] = "resign";
epdsostrv[epdso_sm         ] = "sm";
epdsostrv[epdso_sv         ] = "sv";
epdsostrv[epdso_tcgs       ] = "tcgs";
epdsostrv[epdso_tcri       ] = "tcri";
epdsostrv[epdso_tcsi       ] = "tcsi";
epdsostrv[epdso_ts         ] = "ts";
epdsostrv[epdso_v0         ] = "v0";
epdsostrv[epdso_v1         ] = "v1";
epdsostrv[epdso_v2         ] = "v2";
epdsostrv[epdso_v3         ] = "v3";
epdsostrv[epdso_v4         ] = "v4";
epdsostrv[epdso_v5         ] = "v5";
epdsostrv[epdso_v6         ] = "v6";
epdsostrv[epdso_v7         ] = "v7";
epdsostrv[epdso_v8         ] = "v8";
epdsostrv[epdso_v9         ] = "v9";

/* set the EPD refcom operand strings */

refcomstrv[refcom_conclude  ] = "conclude";
refcomstrv[refcom_disconnect] = "disconnect";
refcomstrv[refcom_execute   ] = "execute";
refcomstrv[refcom_fault     ] = "fault";
refcomstrv[refcom_inform    ] = "inform";
refcomstrv[refcom_respond   ] = "respond";
refcomstrv[refcom_reset     ] = "reset";

/* set the EPD refreq operand strings */

refreqstrv[refreq_fault   ] = "fault";
refreqstrv[refreq_reply   ] = "reply";
refreqstrv[refreq_sign_on ] = "sign_on";
refreqstrv[refreq_sign_off] = "sign_off";

/* set the PGN Seven Tag Roster names */

pgnstrstrv[pgnstr_event ] = "Event";
pgnstrstrv[pgnstr_site  ] = "Site";
pgnstrstrv[pgnstr_date  ] = "Date";
pgnstrstrv[pgnstr_round ] = "Round";
pgnstrstrv[pgnstr_white ] = "White";
pgnstrstrv[pgnstr_black ] = "Black";
pgnstrstrv[pgnstr_result] = "Result";

return;
}

/*--> EPDTerm: one time termination for EPD */
nonstatic
void
EPDTerm(void)
{

return;
}

/*<<< epd.c: EOF */
