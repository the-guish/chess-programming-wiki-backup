/*>>> reader.h: subprogram prototypes for reader.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void RGSetGRTM(grtmT grtm);
siT RGSingle(charptrT fn, liptrT gnptr);
siT RGMultiple(charptrT fn0, charptrT fn1, liptrT gnptr);

/*<<< reader.h: EOF */
