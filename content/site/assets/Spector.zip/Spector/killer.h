/*>>> killer.h: subprogram prototypes for killer.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void KillerTrioUpdate(sqT frsq, sqT tosq);
void KillerBumpPop(sqT frsq, sqT tosq);
void KillerSetCounter(mptrT mptr0, mptrT mptr1, mptrT mptr2);
smptrT KillerGetCounter(mptrT mptr0, mptrT mptr1);
void KillerReset(void);
void KillerPresetResponse(void);

/*<<< killer.h: EOF */
