/*>>> tags.h: subprogram prototypes for tags.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT TagCount(void);
charptrT TagFormat(tagptrT tagptr);
void TagFilePrint(fptrT fptr, tagptrT tagptr);
void TagFilePrintReserved(fptrT fptr, rsvtagT rsvtag);
void TagFilePrintAll(fptrT fptr);
tagptrT TagCreate(charptrT name, tagfT tagf);
tagptrT TagLocate(charptrT name);
void TagAssign(tagptrT tagptr, charptrT value);
void TagAssignReserved(rsvtagT rsvtag, charptrT value);
void TagDelete(tagptrT tagptr);
void TagInsert(tagptrT tagptr);
void TagClear(tagptrT tagptr);
void TagClearAll(void);
void TagInit(void);
void TagTerm(void);

/*<<< tags.h: EOF */
