/*>>> csvars.h: concept search variable external declarations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/**** Basic patterns */

/* the null basic pattern frame */

extern bpfT null_bpf;

/* the basic pattern descriptor vector */

extern bpdT bpdv[bpL];

/*<<< csvars.h: EOF */
