/*>>> attack.c: attack bitboard access routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "attack.h"
#include "bb.h"
#include "sysutil.h"

/*--> AttackAdd: add attacks of a piece on a square (must be occupied) */
nonstatic
void
AttackAdd(sqT sq)
{
sqT rsq;
rankT rsq_rank, sq_rank;
fileT rsq_file, sq_file;
cpT cp;
bbT bsbb;
cT c;

/* process according to piece type */

c = cv_c_cpv[cp = local.rbv[sq]];
switch (cv_p_cpv[cp])
	{
	case p_p:
		gp_bb = pcbbv[c][sq];
		break;

	case p_n:
		gp_bb = nmbbv[sq];
		break;

	case p_b:
		bb_clr(gp_bb);

		/* set up rank/file origin */

		rsq_rank = sq_rank = map_rank(sq);
		rsq_file = sq_file = map_file(sq);

		/* scan dx_4 */

		if (bb_tstnotsqrf(debbv[dx_4], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_4], apmbb, bsbb);
			do
				{
				rsq_rank++;
				rsq_file++;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_5 */

		rsq_rank = sq_rank;
		rsq_file = sq_file;
		if (bb_tstnotsqrf(debbv[dx_5], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_5], apmbb, bsbb);
			do
				{
				rsq_rank++;
				rsq_file--;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_6 */

		rsq_rank = sq_rank;
		rsq_file = sq_file;
		if (bb_tstnotsqrf(debbv[dx_6], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_6], apmbb, bsbb);
			do
				{
				rsq_rank--;
				rsq_file--;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_7 */

		rsq_rank = sq_rank;
		rsq_file = sq_file;
		if (bb_tstnotsqrf(debbv[dx_7], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_7], apmbb, bsbb);
			do
				{
				rsq_rank--;
				rsq_file++;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		break;

	case p_r:
		bb_clr(gp_bb);

		/* set up rank/file origin */

		rsq_rank = sq_rank = map_rank(sq);
		rsq_file = sq_file = map_file(sq);

		/* scan dx_0 */

		if (bb_tstnotsqrf(debbv[dx_0], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_0], apmbb, bsbb);
			do
				{
				rsq_file++;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_1 */

		rsq_file = sq_file;
		if (bb_tstnotsqrf(debbv[dx_1], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_1], apmbb, bsbb);
			do
				{
				rsq_rank++;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_2 */

		rsq_rank = sq_rank;
		if (bb_tstnotsqrf(debbv[dx_2], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_2], apmbb, bsbb);
			do
				{
				rsq_file--;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_3 */

		rsq_file = sq_file;
		if (bb_tstnotsqrf(debbv[dx_3], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_3], apmbb, bsbb);
			do
				{
				rsq_rank--;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		break;

	case p_q:
		bb_clr(gp_bb);

		/* set up rank/file origin */

		rsq_rank = sq_rank = map_rank(sq);
		rsq_file = sq_file = map_file(sq);

		/* scan dx_0 */

		if (bb_tstnotsqrf(debbv[dx_0], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_0], apmbb, bsbb);
			do
				{
				rsq_file++;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_1 */

		rsq_file = sq_file;
		if (bb_tstnotsqrf(debbv[dx_1], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_1], apmbb, bsbb);
			do
				{
				rsq_rank++;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_2 */

		rsq_rank = sq_rank;
		if (bb_tstnotsqrf(debbv[dx_2], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_2], apmbb, bsbb);
			do
				{
				rsq_file--;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_3 */

		rsq_file = sq_file;
		if (bb_tstnotsqrf(debbv[dx_3], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_3], apmbb, bsbb);
			do
				{
				rsq_rank--;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_4 */

		rsq_rank = sq_rank;
		rsq_file = sq_file;
		if (bb_tstnotsqrf(debbv[dx_4], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_4], apmbb, bsbb);
			do
				{
				rsq_rank++;
				rsq_file++;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_5 */

		rsq_rank = sq_rank;
		rsq_file = sq_file;
		if (bb_tstnotsqrf(debbv[dx_5], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_5], apmbb, bsbb);
			do
				{
				rsq_rank++;
				rsq_file--;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_6 */

		rsq_rank = sq_rank;
		rsq_file = sq_file;
		if (bb_tstnotsqrf(debbv[dx_6], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_6], apmbb, bsbb);
			do
				{
				rsq_rank--;
				rsq_file--;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		/* scan dx_7 */

		rsq_rank = sq_rank;
		rsq_file = sq_file;
		if (bb_tstnotsqrf(debbv[dx_7], rsq_rank, rsq_file))
			{
			bb_ior3(debbv[dx_7], apmbb, bsbb);
			do
				{
				rsq_rank--;
				rsq_file++;
				bb_setsqrf(gp_bb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};

		break;

	case p_k:
		gp_bb = kmbbv[sq];
		break;

	default:
		SwitchFault("AttackAdd");
		break;
	};

/* set the attack-from bitboard entry */

afbbv[sq] = gp_bb;

/* set the attack-by-color bitboard entry */

bb_ior2(gp_bb, acbbv[c]);

/* set the various attack-to bitboards */

rsq_rank = map_rank(sq);
rsq_file = bit << map_file(sq);
while (bb_next_gp(rsq))
	atbbv[rsq].bbcv[rsq_rank] |= (byteT) rsq_file;

return;
}
/*--> AttackDel: delete attacks of a piece on a square (must be occupied) */
nonstatic
void
AttackDel(sqT sq)
{
sqT rsq;
rankT sq_rank;
fileT sq_file;

/* set up local attack-from bitboard */

gp_bb = afbbv[sq];

/* clear the from-square attack bitboard */

bb_clr(afbbv[sq]);

/* fetch rank and file of square */

sq_rank = map_rank(sq);
sq_file = map_file(sq);

/* process according to occupant color */

if (cp_tstw(local.rbv[sq]))
	{
	/* clear the to-square attack entries as required */

	while (bb_next_gp(rsq))
		{
		bb_clrsqrf(atbbv[rsq], sq_rank, sq_file);
		if (bb_tstnotand(atbbv[rsq], c0bbv[c_w]))
			bb_clrsq(acbbv[c_w], rsq);
		};
	}
else
	{
	/* clear the to-square attack entries as required */

	while (bb_next_gp(rsq))
		{
		bb_clrsqrf(atbbv[rsq], sq_rank, sq_file);
		if (bb_tstnotand(atbbv[rsq], c0bbv[c_b]))
			bb_clrsq(acbbv[c_b], rsq);
		};
	};

return;
}

/*--> AttackPro: propagate attacks through a square (must be empty) */
nonstatic
void
AttackPro(sqT sq)
{
sqT rsq, asq;
rankT rsq_rank, asq_rank;
fileT rsq_file, asq_file;
dvfT dvf;
dvrT dvr;
dvT dv;
dxT dx;
cpT acp;
cT ac;
bbT axbb, debb, bsbb;

/* cycle through attack-to list */

gp_bb = atbbv[sq];
while (bb_next_gp(asq))
	{
	/* fetch and process for attacking sweep piece */

	if (cp_sweepv[acp = local.rbv[asq]])
		{
		/* calculate direction and edge from asq to sq */

		debb = debbv[dx = *(dx_table_base + offset_sqsq(asq, sq))];

		/* check for sq on edge, process if not */

		if (bb_tstnotsq(debb, sq))
			{
			/* set up for scan beyond square */

			asq_rank = map_rank(asq);
			asq_file = map_file(asq);
			ac = cv_c_cpv[acp];
			bb_clr(axbb);
			dv = dvv[dx];
			dvf = dvfv[dx];
			dvr = dvrv[dx];
			rsq = sq;
			rsq_rank = map_rank(rsq);
			rsq_file = map_file(rsq);
			bb_ior3(debb, apmbb, bsbb);
			do
				{
				rsq += dv;
				rsq_rank += dvr;
				rsq_file += dvf;
				bb_setsqrf(atbbv[rsq], asq_rank, asq_file);
				bb_setsqrf(axbb, rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			bb_ior2(axbb, afbbv[asq]);
			bb_ior2(axbb, acbbv[ac]);
			};
		};
	};

return;
}

/*--> AttackCut: cut attacks through a square */
nonstatic
void
AttackCut(sqT sq)
{
sqT rsq, asq;
rankT rsq_rank, asq_rank;
fileT rsq_file, asq_file;
dvfT dvf;
dvrT dvr;
dvT dv;
dxT dx;
cpT acp;
cT ac;
bbT debb, bsbb, c0bb_ac;

/* cycle through attack-to list */

gp_bb = atbbv[sq];
while (bb_next_gp(asq))
	{
	/* fetch and process for attacking sweep piece */

	if (cp_sweepv[acp = local.rbv[asq]])
		{
		/* calculate direction and edge from asq to sq */

		debb = debbv[dx = *(dx_table_base + offset_sqsq(asq, sq))];

		/* check for sq on edge, process if not */

		if (bb_tstnotsq(debb, sq))
			{
			/* set up for scan beyond square */

			asq_rank = map_rank(asq);
			asq_file = map_file(asq);
			c0bb_ac = c0bbv[ac = cv_c_cpv[acp]];
			dv = dvv[dx];
			dvf = dvfv[dx];
			dvr = dvrv[dx];
			rsq = sq;
			rsq_rank = map_rank(rsq);
			rsq_file = map_file(rsq);
			bb_ior3(debb, apmbb, bsbb);
			do
				{
				rsq += dv;
				rsq_rank += dvr;
				rsq_file += dvf;
				bb_clrsqrf(atbbv[rsq], asq_rank, asq_file);
				bb_clrsqrf(afbbv[asq], rsq_rank, rsq_file);
				if (bb_tstnotand(atbbv[rsq], c0bb_ac))
					bb_clrsqrf(acbbv[ac], rsq_rank, rsq_file);
				}
			while (bb_tstnotsqrf(bsbb, rsq_rank, rsq_file));
			};
		};
	};

return;
}

/*--> AttackClr: clear attack bitboard vectors */
static
void
AttackClr(void)
{
sqT sq;

bb_clr(acbbv[c_w]);
bb_clr(acbbv[c_b]);

for (sq = sq_a1; sq <= sq_h8; sq++)
	{
	bb_clr(atbbv[sq]);
	bb_clr(afbbv[sq]);
	};

return;
}

/*--> AttackSet: set up attack bitboard vectors */
nonstatic
void
AttackSet(void)
{
sqT sq;

/* clear all entries */

AttackClr();

/* for each occupied square, set the appropriate entries */

gp_abb = apmbb;
while (bb_next_gpa(sq))
	AttackAdd(sq);

return;
}

/*<<< attack.c: EOF */
