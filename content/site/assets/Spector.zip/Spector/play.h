/*>>> play.h: subprogram prototypes for play.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void UnplayMove(void);
void PlayMove(mptrT mptr);

/*<<< play.h: EOF */
