/*>>> file.c: file access routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "file.h"
#include "print.h"
#include "sysutil.h"

#if (os_mac)
#include <Files.h>
#include <Types.h>
#endif

/*--> MapFileName: map a file pathname from standard into local format */
static
charptrT
MapFileName(charptrT fn)
{
static char fv[tL];

#if (os_mac)
{
siT i;

/* check for slashes */

if (strchr(fn, '/') == NULL)
	if (strlen(fn) >= tL)
		Diagnose("MapFileName: filename too long");
	else
		(void) strcpy(fv, fn);
else
	if (strlen(fn) >= (tL - 1))
		Diagnose("MapFileName: filename too long");
	else
		{
		(void) strcpy(fv, ":");
		strcat(fv, fn);
		i = 1;
		while (fv[i] != ascii_nul)
			{
			if (fv[i] == '/')
				fv[i] = ':';
			i++;
			};
		};
}
#else
{
if (strlen(fn) >= tL)
	Diagnose("MapFileName: filename too long");
else
	(void) strcpy(fv, fn);
}
#endif

return (fv);
}

/*--> SetBigBuffer: set a big buffer for a newly opened file */
nonstatic
void
SetBigBuffer(fptrT fptr)
{
setvbuf(fptr, NULL, _IOFBF, rlbL);

return;
}

/*--> SetBuffer: set a sized buffer for a newly opened file */
nonstatic
void
SetBuffer(fptrT fptr, liT length)
{
setvbuf(fptr, NULL, _IOFBF, length);

return;
}

/*--> SetBiggerBuffer: set a bigger buffer for a newly opened file */
nonstatic
void
SetBiggerBuffer(fptrT fptr)
{
setvbuf(fptr, NULL, _IOFBF, (16 * rlbL));

return;
}

/*--> CodeFileOpen: open a code file */
nonstatic
fptrT
CodeFileOpen(charptrT filename, charptrT filemode)
{
fptrT fptr;
char fn[tL];

(void) strcpy(fn, MapFileName(filename));
fptr = fopen(fn, filemode);

return (fptr);
}

/*--> CodeFileClose: close a code file */
nonstatic
siT
CodeFileClose(fptrT fptr)
{
siT result;

result = fclose(fptr);

return (result);
}

/*--> TextFileOpen: open a text file */
nonstatic
fptrT
TextFileOpen(charptrT filename, charptrT filemode)
{
fptrT fptr;
char fn[tL];

(void) strcpy(fn, MapFileName(filename));
fptr = fopen(fn, filemode);

#if (os_mac)
{
OSErr code;
siT vRefNum;
FInfo finderinfo;
char vn[tL];
siT i, blen;

if ((fptr != NULL) && (strcmp(filemode, "w") == 0))
	{
	code = GetVol((StringPtr) vn, &vRefNum);
	if (code != noErr)
		Diagnose("TextFileOpen: GetVol fault");

	blen = strlen(fn);
	for (i = 0; i < blen; i++)
		fn[blen - i] = fn[(blen - i) - 1];
	fn[0] = (byteT) blen;
	code = GetFInfo((StringPtr) fn, vRefNum, &finderinfo);
	if (code != noErr)
		Diagnose("TextFileOpen: GetFInfo fault");

	finderinfo.fdCreator = 'QED1';
	code = SetFInfo((StringPtr) fn, vRefNum, &finderinfo);
	if (code != noErr)
		Diagnose("TextFileOpen: SetFInfo fault");
	};
}
#endif

return (fptr);
}

/*--> TextFileClose: close a text file */
nonstatic
siT
TextFileClose(fptrT fptr)
{
siT result;

result = fclose(fptr);

return (result);
}

/*--> TextFileFlush: flush a text file */
nonstatic
siT
TextFileFlush(fptrT fptr)
{
siT result;

result = fflush(fptr);

return (result);
}

/*--> GateChar: gate a character to a file */
nonstatic
void
GateChar(fptrT fptr, char ch)
{
if (fptr == stdout)
	PrChar(ch);
else
	(void) fputc(ch, fptr);

return;
}

/*--> GateStr: gate a string to a file */
nonstatic
void
GateStr(fptrT fptr, charptrT s)
{
if (fptr == stdout)
	PrStr(s);
else
	(void) fputs(s, fptr);

return;
}
/*<<< file.c: EOF */
