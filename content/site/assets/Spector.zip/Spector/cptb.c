/*>>> cptb.c: command processor for endgame tablebase subsystem */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "commdefs.h"
#include "commvars.h"

#include "tbdefs.h"

#include "cptb.h"
#include "print.h"
#include "tb.h"

/*--> CPTBCommand: handle command token line from main command input */
nonstatic
void
CPTBCommand(void)
{
siT flag;
liT result;

flag = TBCommand(ipv[1].ip_str, ipv[2].ip_str, &result);
if (!flag)
	PrErr("CPTBCommand fault");
else
	if (optnv[optn_verb])
		PrStrLINL("TB command result: ", result);

return;
}

/*<<< cptb.c: EOF */
