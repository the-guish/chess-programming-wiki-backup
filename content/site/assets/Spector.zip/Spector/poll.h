/*>>> poll.h: subprogram prototypes for poll.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void AbortSearch(void);
void InterruptSearch(int sig);
void PollSelectInit(void);
void PollSelectTerm(void);
void PollNode(void);

/*<<< poll.h: EOF */
