/*>>> tbvars.h: tablebase variable external declarations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* generated moves (direct) */

extern siT tb_dtmnv[rcL];
extern tmptrT tb_dtmv[rcL];

/* generated moves (retro) */

extern siT tb_rtmnv[rcL];
extern tmptrT tb_rtmv[rcL];

/* tablebase active/passive colors */

extern cT tb_actc, tb_pasc;

/* tablebase local board (color-piece) */

extern tiT tb_cpv[sqL];

/* tablebase local board (piece indexes) */

extern tiT tb_piv[sqL];

/* tablebase move generation piece vector */

extern siT tb_mgpnv[rcL];
extern sqT tb_mgpv[rcL][pmaxL];

/* captured piece kind, last square, and index */

extern cpT tb_capt_cp;
extern sqT tb_capt_sq;
extern siT tb_capt_index;

/* master color-piece number vector */

extern siT tb_mcpnv[rcL];

/* master scanning pattern vector */

extern tbspidT tb_mspv[rcL][pmaxL];

/* master color piece vector */

extern cpT tb_mcpv[rcL][pmaxL];

/* occupancy calculations */

extern siT tb_ocsqv[sqL];
extern cpT tb_occpv[rcL];

/* current scanning pattern index vector */

extern siT tb_cspiv[rcL][pmaxL];

/* current square vector (always post-retraction) */

extern siT tb_csqv[rcL][pmaxL];

/* anchor pointers for the tablebase file cache list */

extern tfcptrT head_tfcptr;
extern tfcptrT tail_tfcptr;

/*<<< tbvars.h: EOF */
