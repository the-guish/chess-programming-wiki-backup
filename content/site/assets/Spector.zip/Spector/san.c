/*>>> san.c: standard algebraic notation routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "moveset.h"
#include "memutil.h"
#include "mu.h"
#include "san.h"

/**** Local definitions */

#define an_ch_capture     'x'
#define an_ch_capture_alt ':'
#define an_ch_check       '+'
#define an_ch_dash        '-'
#define an_ch_draw        '='
#define an_ch_illegal     '*'
#define an_ch_mate        '#'
#define an_ch_oh_ucase    'O'
#define an_ch_zero        ascii_zero
#define an_ch_good        '!'
#define an_ch_poor        '?'

/* storage for LocateOrdinalMove result */

static mT ord_m;

/*--> SANMoveAux: calculate algebraic notation for a move */
nonstatic
void
SANMoveAux(mptrT mptr, sanT san, nvpcvT nvpfv)
{
siT i, j;
char pch;

/* initialize character vector index */

i = 0;

/* null move special case */

if (null_move_ref(mptr))
	{
	san[i++] = '<';
	san[i++] = 'n';
	san[i++] = 'u';
	san[i++] = 'l';
	san[i++] = 'l';
	san[i++] = '>';
	}
else
	{
	/* illegal indicator */

	if (mptr->m_flag & mf_bust)
		san[i++] = an_ch_illegal;

	/* not null move, process according to moving piece */

	switch (cv_p_cpv[mptr->m_frcp])
		{
		case p_p:
			/* process extraneous pawn indication */

			if (nvpfv[nvp_pawn])
				san[i++] = ascpv[lang_san][p_p];

			/* process from file */

			san[i++] = ascfv[map_file(mptr->m_frsq)];

			/* process extraneous rank print */

			if (nvpfv[nvp_extr] == 1)
				san[i++] = ascrv[map_rank(mptr->m_frsq)];

			/* process non-capture indication */

			if (mptr->m_tocp == cp_v0)
				if (nvpfv[nvp_dash] == 1)
					san[i++] = an_ch_dash;

			/* process capture indication */

			if ((mptr->m_tocp != cp_v0) || (mptr->m_scmv == scmv_epc))
				switch (nvpfv[nvp_capt])
					{
					case 0:
						san[i++] = an_ch_capture;
						break;

					case 1:
						break;

					case 2:
						san[i++] = an_ch_capture_alt;
						break;

					case 3:
						san[i++] = an_ch_dash;
						break;

					case 4:
						break;
					};

			/* process captured man piece letter prefix */

			if ((mptr->m_tocp != cp_v0) || (mptr->m_scmv == scmv_epc))
				if (nvpfv[nvp_cmpl])
					if (mptr->m_scmv == scmv_epc)
						san[i++] = ascpv[lang_san][p_p];
					else
						san[i++] = ascpv[lang_san][cv_p_cpv[mptr->m_tocp]];

			/* process to-square location */

			if (map_file(mptr->m_frsq) != map_file(mptr->m_tosq))
				{
				san[i++] = ascfv[map_file(mptr->m_tosq)];
				if (!nvpfv[nvp_pcdr])
					san[i++] = ascrv[map_rank(mptr->m_tosq)];
				}
			else
				{
				/* process extraneous file print */

				if (nvpfv[nvp_extf] == 1)
					san[i++] = ascfv[map_file(mptr->m_frsq)];

				/* append the destination rank */

				san[i++] = ascrv[map_rank(mptr->m_tosq)];
				};

			/* process according to special case */

			switch (mptr->m_scmv)
				{
				case scmv_reg:
					break;

				case scmv_epc:
					switch (nvpfv[nvp_epsq])
						{
						case 0:
							break;

						case 1:
							san[i++] = 'e';
							san[i++] = 'p';
							break;
						};
					break;

				case scmv_ppn:
				case scmv_ppb:
				case scmv_ppr:
				case scmv_ppq:
					pch = ascpv[lang_san][cv_p_scmvv[mptr->m_scmv]];
					switch (nvpfv[nvp_prom])
						{
						case 0:
							san[i++] = '=';
							san[i++] = pch;
							break;

						case 1:
							san[i++] = pch;
							break;

						case 2:
							san[i++] = '/';
							san[i++] = pch;
							break;

						case 3:
							san[i++] = '(';
							san[i++] = pch;
							san[i++] = ')';
							break;
						};
					break;
				};
			break;

		case p_n:
		case p_b:
		case p_r:
		case p_q:
			/* set moving piece */

			san[i++] = ascpv[lang_san][cv_p_cpv[mptr->m_frcp]];

			/* process file print indicator */

			if ((mptr->m_flag & mf_anfp) || (nvpfv[nvp_extf] == 1))
				san[i++] = ascfv[map_file(mptr->m_frsq)];

			/* process rank print indicator */

			if ((mptr->m_flag & mf_anrp) || (nvpfv[nvp_extr] == 1))
				san[i++] = ascrv[map_rank(mptr->m_frsq)];

			/* process non-capture indication */

			if (mptr->m_tocp == cp_v0)
				if (nvpfv[nvp_dash] == 1)
					san[i++] = an_ch_dash;

			/* process capture indication */

			if (mptr->m_tocp != cp_v0)
				switch (nvpfv[nvp_capt])
					{
					case 0:
						san[i++] = an_ch_capture;
						break;

					case 1:
						break;

					case 2:
						san[i++] = an_ch_capture_alt;
						break;

					case 3:
						san[i++] = an_ch_dash;
						break;

					case 4:
						break;
					};

			/* process captured man piece letter prefix */

			if (mptr->m_tocp != cp_v0)
				if (nvpfv[nvp_cmpl])
					san[i++] = ascpv[lang_san][cv_p_cpv[mptr->m_tocp]];

			/* process to-square location */

			san[i++] = ascfv[map_file(mptr->m_tosq)];
			san[i++] = ascrv[map_rank(mptr->m_tosq)];
			break;

		case p_k:
			switch (mptr->m_scmv)
				{
				case scmv_reg:
					/* set moving piece */

					san[i++] = ascpv[lang_san][p_k];

					/* extraneous file print */

					if (nvpfv[nvp_extf] == 1)
						san[i++] = ascfv[map_file(mptr->m_frsq)];

					/* extraneous rank print */

					if (nvpfv[nvp_extr] == 1)
						san[i++] = ascrv[map_rank(mptr->m_frsq)];

					/* process non-capture indication */

					if (mptr->m_tocp == cp_v0)
						if (nvpfv[nvp_dash] == 1)
							san[i++] = an_ch_dash;

					/* process capture indication */

					if (mptr->m_tocp != cp_v0)
						switch (nvpfv[nvp_capt])
							{
							case 0:
								san[i++] = an_ch_capture;
								break;
							case 1:
								break;
							case 2:
								san[i++] = an_ch_capture_alt;
								break;
							case 3:
								san[i++] = an_ch_dash;
								break;
							case 4:
								break;
							};

					/* process captured man piece letter prefix */

					if (mptr->m_tocp != cp_v0)
						if (nvpfv[nvp_cmpl])
							san[i++] =
								ascpv[lang_san][cv_p_cpv[mptr->m_tocp]];

					/* process to-square location */

					san[i++] = ascfv[map_file(mptr->m_tosq)];
					san[i++] = ascrv[map_rank(mptr->m_tosq)];

					break;

				case scmv_cks:
					switch (nvpfv[nvp_cast])
						{
						case 0:
							san[i++] = an_ch_oh_ucase;
							san[i++] = an_ch_dash;
							san[i++] = an_ch_oh_ucase;
							break;

						case 1:
							san[i++] = an_ch_zero;
							san[i++] = an_ch_dash;
							san[i++] = an_ch_zero;
							break;

						case 2:
							san[i++] = an_ch_oh_ucase;
							san[i++] = an_ch_oh_ucase;
							break;

						case 3:
							san[i++] = an_ch_zero;
							san[i++] = an_ch_zero;
							break;
						};
					break;

				case scmv_cqs:
					switch (nvpfv[nvp_cast])
						{
						case 0:
							san[i++] = an_ch_oh_ucase;
							san[i++] = an_ch_dash;
							san[i++] = an_ch_oh_ucase;
							san[i++] = an_ch_dash;
							san[i++] = an_ch_oh_ucase;
							break;

						case 1:
							san[i++] = an_ch_zero;
							san[i++] = an_ch_dash;
							san[i++] = an_ch_zero;
							san[i++] = an_ch_dash;
							san[i++] = an_ch_zero;
							break;

						case 2:
							san[i++] = an_ch_oh_ucase;
							san[i++] = an_ch_oh_ucase;
							san[i++] = an_ch_oh_ucase;
							break;

						case 3:
							san[i++] = an_ch_zero;
							san[i++] = an_ch_zero;
							san[i++] = an_ch_zero;
							break;
						};
					break;
				};
			break;
		};

	/* capture suffix */

	if ((mptr->m_tocp != cp_v0) || (mptr->m_scmv == scmv_epc))
		if (nvpfv[nvp_capt] == 4)
			san[i++] = an_ch_capture_alt;

	/* check indicator */

	if ((mptr->m_flag & mf_chec) && !(mptr->m_flag & mf_mate))
		switch (nvpfv[nvp_chec])
			{
			case 0:
				san[i++] = an_ch_check;
				break;

			case 1:
				break;

			case 2:
				san[i++] = 'c';
				san[i++] = 'h';
				break;
			};

	/* checkmate indicator */

	if (mptr->m_flag & mf_mate)
		switch (nvpfv[nvp_mate])
			{
			case 0:
				san[i++] = an_ch_mate;
				break;

			case 1:
				san[i++] = an_ch_check;
				break;

			case 2:
				break;

			case 3:
				san[i++] = an_ch_check;
				san[i++] = an_ch_check;
				break;
			};

	/* drawing indicator */

	if (mptr->m_flag & mf_draw)
		if (nvpfv[nvp_mate])
			san[i++] = an_ch_draw;

	/* annotation indication */

	switch (nvpfv[nvp_anno])
		{
		case 0:
			break;

		case 1:
			san[i++] = an_ch_good;
			break;

		case 2:
			san[i++] = an_ch_poor;
			break;
		};

	/* case folding */

	if (nvpfv[nvp_case])
		for (j = 0; j < i; j++)
			san[j] = map_lower(san[j]);
	};

/* append NUL characters */

while (i < sanL)
	san[i++] = ascii_nul;

return;
}

/*--> SANMove: calculate standard algebraic notation for a move */
nonstatic
void
SANMove(mptrT mptr, sanT san)
{
nvpcvT nvpfv;
nvpT nvp;

for (nvp = 0; nvp < nvpL; nvp++)
	nvpfv[nvp] = 0;
SANMoveAux(mptr, san, nvpfv);

return;
}

/*--> SANDisambiguate: set disambiguation annotation for an entire moveset */
nonstatic
void
SANDisambiguate(sptrT sptr)
{
siT tmc, fmc, rmc, i, j, count;
mptrT mptr0, mptr1;
rankT frrank;
fileT frfile;

/* moveset disambiguation flag check */

if (!(sptr->s_sflag & sf_dsam))
	{
	/* set disambiguation flag */

	sptr->s_sflag |= sf_dsam;

	/* set up for scan */

	mptr0 = sptr->s_mbase;
	count = sptr->s_count;

	/* scan each move */

	for (i = 0; i < count; i++)
		{
		/* scan for duplications */

		if ((cv_p_cpv[mptr0->m_frcp] != p_p) &&
			(cv_p_cpv[mptr0->m_frcp] != p_k))
			{
			/* only non-pawn, non-king movers are of interest */

			frfile = map_file(mptr0->m_frsq);
			frrank = map_rank(mptr0->m_frsq);
			mptr1 = sptr->s_mbase;
			tmc = fmc = rmc = 0;

			/* inner move scan loop */

			for (j = 0; j < count; j++)
				{
				if (i != j)
					if ((mptr0->m_tosq == mptr1->m_tosq) &&
						(mptr0->m_frcp == mptr1->m_frcp))
						{
						tmc++;
						if (frfile == map_file(mptr1->m_frsq))
							fmc++;
						if (frrank == map_rank(mptr1->m_frsq))
							rmc++;
						};
				mptr1++;
				};

			/* check to-square match count */

			if (tmc > 0)
				{
				if ((rmc > 0) || ((rmc == 0) && (fmc == 0)))
					mptr0->m_flag |= mf_anfp;
				if (fmc > 0)
					mptr0->m_flag |= mf_anrp;
				};
			};

		/* increment to next move */

		mptr0++;
		};
	};

return;
}

/*--> SANSort: sort moveset based on SAN */
nonstatic
void
SANSort(sptrT sptr)
{
siT i, j, pair, pass, flag;
sanptrT sanbaseptr, sanptr0, sanptr1;
mptrT mptr0, mptr1;
char t_ch;
mT t_m;

/* allocate the SAN string vector */

sanbaseptr = (sanptrT) MemoryGrab(sizeof(sanT) * sptr->s_count);

/* generate notation vector */

mptr0 = sptr->s_mbase;
sanptr0 = sanbaseptr;
for (i = 0; i < sptr->s_count; i++)
	{
	SANMove(mptr0, *sanptr0);
	mptr0++;
	sanptr0++;
	};

/* sort the SAN vector in ASCII order */

flag = 1;
pass = 0;
while (flag && (pass < (sptr->s_count - 1)))
	{
	sanptr0 = sanbaseptr;
	sanptr1 = sanbaseptr + 1;
	mptr0 = sptr->s_mbase;
	mptr1 = sptr->s_mbase + 1;
	flag = 0;
	pair = 0;
	while (pair < (sptr->s_count - pass - 1))
		{
		/* case sensitive ascending order */

		if (strcmp((charptrT) sanptr0, (charptrT) sanptr1) > 0)
			{
			flag = 1;
			for (j = 0; j < sanL; j++)
				{
				t_ch = (*sanptr0)[j];
				(*sanptr0)[j] = (*sanptr1)[j];
				(*sanptr1)[j] = t_ch;
				};
			t_m = *mptr0;
			*mptr0 = *mptr1;
			*mptr1 = t_m;
			};
		sanptr0++;
		sanptr1++;
		mptr0++;
		mptr1++;
		pair++;
		};
	pass++;
	};

/* free the allocated vector */

MemoryFree(sanbaseptr);

/* rethread the moveset */

MovesetRethread(sptr);

return;
}

/*--> SANSortList: sort san storage based on ascending string value */
nonstatic
void
SANSortList(sanT sanv[], siT count)
{
siT flag, pass, pair, i;
sanT san;

if (count > 1)
	{
	/* set up pass loop */

	flag = 1;
	pass = 0;
	while (flag && (pass < (count - 1)))
		{
		/* set up pair loop */

		flag = 0;
		pair = 0;
		while (pair < (count - pass - 1))
			{
			/* test for swap */

			if (strcmp(sanv[pair], sanv[pair + 1]) > 0)
				{
				for (i = 0; i < sanL; i++)
					san[i] = sanv[pair][i];
				for (i = 0; i < sanL; i++)
					sanv[pair][i] = sanv[pair + 1][i];
				for (i = 0; i < sanL; i++)
					sanv[pair + 1][i] = san[i];
				flag = 1;
				};

			/* next pair */

			pair++;
			};

		/* next pass */

		if (flag)
			pass++;
		};
	};

return;
}

/*--> SANSortMoveList: sort move list based on ascending string value */
nonstatic
void
SANSortMoveList(mlstptrT mlstptr)
{
siT n, pair, pass, flag;
mlstptrT ptr0, ptr1;
sanT san0, san1;
mptrT mptr;

/* count items */

n = 0;
ptr0 = mlstptr;
while (ptr0 != NULL)
	{
	n++;
	ptr0 = ptr0->mlst_next;
	};

/* set up for sort if at least two items */

if (n > 1)
	{
	flag = 1;
	pass = 0;
	while (flag && (pass < (n - 1)))
		{
		flag = 0;
		pair = 0;
		ptr0 = mlstptr;
		ptr1 = ptr0->mlst_next;
		while (pair < (n - pass - 1))
			{
			SANMove(ptr0->mlst_mptr, san0);
			SANMove(ptr1->mlst_mptr, san1);
			if (strcmp(san0, san1) > 0)
				{
				mptr = ptr0->mlst_mptr;
				ptr0->mlst_mptr = ptr1->mlst_mptr;
				ptr1->mlst_mptr = mptr;
				flag = 1;
				};
			ptr0 = ptr1;
			ptr1 = ptr0->mlst_next;
			pair++;
			};
		pass++;
		};
	};

return;
}

/*--> LocateOrdinal: locate the canonical move ordinal for a move */
nonstatic
siT
LocateOrdinal(mptrT mptr, sptrT sptr)
{
siT ord;
siT i, j, pair, pass, flag;
sanptrT sanbaseptr, sanptr0, sanptr1;
mptrT mbaseptr, mptr0, mptr1;
char t_ch;
mT t_m;

/* set default return value */

ord = -1;

/* allocate the SAN string vector and the move vector */

sanbaseptr = (sanptrT) MemoryGrab(sizeof(sanT) * sptr->s_count);
mbaseptr = (mptrT) MemoryGrab(sizeof(mT) * sptr->s_count);

/* copy the moves from the current generation vector and convert */

for (i = 0; i < sptr->s_count; i++)
	{
	*(mbaseptr + i) = *(sptr->s_mbase + i);
	SANMove((mbaseptr + i), *(sanbaseptr + i));
	};

/* sort the SAN vector in ASCII order */

flag = 1;
pass = 0;
while (flag && (pass < (sptr->s_count - 1)))
	{
	sanptr0 = sanbaseptr;
	sanptr1 = sanbaseptr + 1;
	mptr0 = mbaseptr;
	mptr1 = mbaseptr + 1;
	flag = 0;
	pair = 0;
	while (pair < (sptr->s_count - pass - 1))
		{
		/* case sensitive ascending order */

		if (strcmp((charptrT) sanptr0, (charptrT) sanptr1) > 0)
			{
			flag = 1;
			for (j = 0; j < sanL; j++)
				{
				t_ch = (*sanptr0)[j];
				(*sanptr0)[j] = (*sanptr1)[j];
				(*sanptr1)[j] = t_ch;
				};
			t_m = *mptr0;
			*mptr0 = *mptr1;
			*mptr1 = t_m;
			};
		sanptr0++;
		sanptr1++;
		mptr0++;
		mptr1++;
		pair++;
		};
	pass++;
	};

/* search for the matching move */

i = 0;
while ((ord == -1) && (i < sptr->s_count))
	if (SameMoveRef(mptr, (mbaseptr + i)))
		ord = i;
	else
		i++;

/* free the allocated vectors */

MemoryFree(sanbaseptr);
MemoryFree(mbaseptr);

return (ord);
}

/*--> LocateOrdinalMove: locate the move for a ordinal */
nonstatic
mptrT
LocateOrdinalMove(siT gord, sptrT sptr)
{
mptrT mptr;
siT i, j, pair, pass, flag;
sanptrT sanbaseptr, sanptr0, sanptr1;
mptrT mbaseptr, mptr0, mptr1;
char t_ch;
mT t_m;

/* set default return value */

mptr = NULL;

/* allocate the SAN string vector and the move vector */

sanbaseptr = (sanptrT) MemoryGrab(sizeof(sanT) * sptr->s_count);
mbaseptr = (mptrT) MemoryGrab(sizeof(mT) * sptr->s_count);

/* copy the moves from the current generation vector and convert */

for (i = 0; i < sptr->s_count; i++)
	{
	*(mbaseptr + i) = *(sptr->s_mbase + i);
	SANMove((mbaseptr + i), *(sanbaseptr + i));
	};

/* sort the SAN vector in ASCII order */

flag = 1;
pass = 0;
while (flag && (pass < (sptr->s_count - 1)))
	{
	sanptr0 = sanbaseptr;
	sanptr1 = sanbaseptr + 1;
	mptr0 = mbaseptr;
	mptr1 = mbaseptr + 1;
	flag = 0;
	pair = 0;
	while (pair < (sptr->s_count - pass - 1))
		{
		/* case sensitive ascending order */

		if (strcmp((charptrT) sanptr0, (charptrT) sanptr1) > 0)
			{
			flag = 1;
			for (j = 0; j < sanL; j++)
				{
				t_ch = (*sanptr0)[j];
				(*sanptr0)[j] = (*sanptr1)[j];
				(*sanptr1)[j] = t_ch;
				};
			t_m = *mptr0;
			*mptr0 = *mptr1;
			*mptr1 = t_m;
			};
		sanptr0++;
		sanptr1++;
		mptr0++;
		mptr1++;
		pair++;
		};
	pass++;
	};

/* fetch the matching move */

if (gord < sptr->s_count)
	{
	ord_m = *(mbaseptr + gord);
	mptr = &ord_m;
	};

/* free the allocated vectors */

MemoryFree(sanbaseptr);
MemoryFree(mbaseptr);

return (mptr);
}

/*<<< san.c: EOF */
