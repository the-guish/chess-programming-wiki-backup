/*>>> hicdefs.c: hash index code opening book definitions */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* HIC file master header record array element type, one per color */

typedef struct hicS
	{
	liT hic_i_start;  /* lseek from file start to index segment start */
	liT hic_i_length; /* length of sorted index segment */
	liT hic_c_start;  /* lseek from file start to chunk segment start */
	liT hic_c_length; /* length of HSC chunk segment */
	} hicT, *hicptrT;

/* HIC file index addressing type; used for index segment contents */

typedef struct hiaS
	{
	liT hia_hac; /* hash addressing code */
	liT hia_lso; /* lseek from chunk segment start to indicated chunk */
	} hiaT, *hiaptrT;

/* HIC move entry (multiple per HSC chunk) */

typedef struct hmeS
	{
	siT          hme_cmo;   /* canonical move ordinal */
	liT          hme_count; /* count of occurances */
	struct hmeS *hme_prev;  /* previous */
	struct hmeS *hme_next;  /* next */
	} hmeT, *hmeptrT;

/* HIC HSC entry (multiple per HAC); used for chunk segment contents */

typedef struct hdbS
	{
	liT          hdb_hsc;   /* hash signature code */
	liT          hdb_total; /* total of move counts */
	hmeptrT      hdb_head;  /* head of move entry list for this HSC */
	hmeptrT      hdb_tail;  /* tail of move entry list for this HSC */
	struct hdbS *hdb_prev;  /* previous */
	struct hdbS *hdb_next;  /* next */
	} hdbT, *hdbptrT;

/* internal delimiter bytes for chunk data */

#define icd_c0 0 /* chunk begin */
#define icd_c1 1 /* chunk end */
#define icd_s0 2 /* set begin */
#define icd_s1 3 /* set end */
#define icd_m0 4 /* move begin */
#define icd_m1 5 /* move end */

/* HIC directory name */

#define hicdir "Book"

/* HIC book name */

#define hicbook "book.hic"

/*<<< hicdefs.h: EOF */
