/*>>> pcstat.h: subprogram prototypes for pcstat.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void ProcessSTAT(void);

/*<<< pcstat.h: EOF */
