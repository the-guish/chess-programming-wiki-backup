/*>>> comm.h: subprogram prototypes for comm.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CommandFileReturn(void);
siT CommandFileCall(charptrT s);
void CommandFileInit(void);
void CommandFileTerm(void);
void Command(void);

/*<<< comm.h: EOF */
