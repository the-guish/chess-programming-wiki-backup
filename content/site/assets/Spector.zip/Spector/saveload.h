/*>>> saveload.h: subprogram prototypes for saveload.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT LoadGameCode(charptrT s);
siT SaveGameCode(charptrT s);

/*<<< saveload.h: EOF */
