/*>>> epos.c: positional components evaluation */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bbmacs.h"

#include "bb.h"
#include "epos.h"
#include "pawn.h"
#include "print.h"

/**** Locals */

/* piece scan dispatch table */

typedef void (*frvsqptrT)(sqT sq);
static frvsqptrT piece_scan_routine[rcpL];

/**** Local positional evaluation declarations */

/* mop-up evaluation scalars */

static siT pe_mop_flag; /* mop-up positional evaluation mode active */

static cT pe_mop_wc; /* mop-up: winning color */
static cT pe_mop_lc; /* mop-up: losing color */

/* king location scalars */

static sqT pe_wksq; /* white king square */
static sqT pe_bksq; /* black king square */

static rankT pe_wkrank; /* white king rank */
static fileT pe_wkfile; /* white king file */
static rankT pe_bkrank; /* black king rank */
static fileT pe_bkfile; /* black king file */

/* material evaluation factors (centipawn units) */

#define pef_material_margin     400
#define pef_material_threshhold 700
#define pef_material_endgame    1500

/* attacked piece terms (millipawn units) */

#define pef_actc_atkd_single   (-160)
#define pef_actc_atkd_multiple (-380)

/* pinned piece penalty */

#define pef_pinned (-150)

/* muliple minor piece development term (millipawn units) */

#define pef_multiple_n_b_undev (-100)

/* side to play evaluation terms (millipawn units) */

#define pef_stp_actc 75
#define pef_stp_pasc (-75)

/* mopup mode position evaluation factors (millipawn units) */

#define pef_mopup_k_decentral (-32)
#define pef_mopup_k_tropism   48
#define pef_mopup_k_hustle    5
#define pef_mopup_k_rimmed    32
#define pef_mopup_n_tropism   32
#define pef_mopup_k_opposing  64

/* scan mode position evaluation factors (millipawn units) */

#define pef_p_passed_basic    23
#define pef_p_passed_blocked  (-7)
#define pef_p_passed_attacked (-4)
#define pef_p_passed_defended 3

#define pef_n_center_tropism 6
#define pef_n_king_tropism   10
#define pef_n_rimmed         (-94)

#define pef_b_square_control 24
#define pef_b_rimmed         (-110)
#define pef_b_blocked        (-55)

#define pef_r_square_control 16
#define pef_r_connect        80
#define pef_r_king_tropism   (-10)
#define pef_r_open_file      100
#define pef_r_semiopen_file  45
#define pef_r_mult_hz_p_atk  220

#define pef_q_square_control 8
#define pef_q_king_tropism   (-5)

#define pef_k_sanctuary         31
#define pef_k_cramped           (-8)
#define pef_k_shelter_one       (-20)
#define pef_k_shelter_none      (-40)
#define pef_k_no_front_pawn     (-50)
#define pef_k_immed_front_pawn  20
#define pef_k_no_side_pawn      (-40)
#define pef_k_multiple_attacks  (-12)
#define pef_k_eg_center_tropism (-23)
#define pef_k_eg_pawn_tropism   (-78)

/*--> EvaluatePositionalSetUp: general positional evaluation set up */
static
void
EvaluatePositionalSetUp(void)
{
siT wbc, wnc;

/* clear accumulators */

position_ev[c_w] = position_ev[c_b] = 0;

/* set up king locations */

pe_wksq = bb_once(cpbbv[cp_wk]);
pe_wkrank = map_rank(pe_wksq);
pe_wkfile = map_file(pe_wksq);

pe_bksq = bb_once(cpbbv[cp_bk]);
pe_bkrank = map_rank(pe_bksq);
pe_bkfile = map_file(pe_bksq);

/* determine mop up mode (potential) win/lose colors */

if (envn.envn_mcpv[c_w] > envn.envn_mcpv[c_b])
	{
	pe_mop_wc = c_w;
	pe_mop_lc = c_b;
	}
else
	{
	pe_mop_wc = c_b;
	pe_mop_lc = c_w;
	};

/* determine mop up flag */

pe_mop_flag = 0;
if (pe_mop_wc == c_w)
	{
	if ((envn.envn_mcpv[c_w] - envn.envn_mcpv[c_b]) >= pef_material_margin)
		if (envn.envn_mcpv[c_b] <= pef_material_threshhold)
			if (bb_tst(cpbbv[cp_wq]))
				pe_mop_flag = 1;
			else
				if (bb_tst(cpbbv[cp_wr]))
					pe_mop_flag = 1;
				else
					if (bb_tstnot(cpbbv[cp_wp]))
						if ((wbc = bb_count(cpbbv[cp_wb])) >= 2)
							pe_mop_flag = 1;
						else
							{
							wnc = bb_count(cpbbv[cp_wn]);
							if (((wbc == 1) && (wnc >= 1)) || (wnc >= 3))
								pe_mop_flag = 1;
							};
	}
else
	{
	if ((envn.envn_mcpv[c_b] - envn.envn_mcpv[c_w]) >= pef_material_margin)
		if (envn.envn_mcpv[c_w] <= pef_material_threshhold)
			if (bb_tst(cpbbv[cp_bq]))
				pe_mop_flag = 1;
			else
				if (bb_tst(cpbbv[cp_br]))
					pe_mop_flag = 1;
				else
					if (bb_tstnot(cpbbv[cp_bp]))
						if ((wbc = bb_count(cpbbv[cp_bb])) >= 2)
							pe_mop_flag = 1;
						else
							{
							wnc = bb_count(cpbbv[cp_bn]);
							if (((wbc == 1) && (wnc >= 1)) || (wnc >= 3))
								pe_mop_flag = 1;
							};
	};

return;
}

/*--> EvaluatePinWhite: detect and score a pinned white piece */
static
cpevT
EvaluatePinWhite(sqT sq)
{
cpevT result;
bbT bb0, bb1, bb2;
sqT sq0, sq1;
cpT cp0, cp1;
dxT dx;
dvT dv;

result = 0;

/* is the piece under attack? */

if (bb_tstsq(acbbv[c_b], sq))
	{
	/* get the attackers */

	bb_and3(atbbv[sq], c0bbv[c_b], bb0);

	/* scan the attackers */

	while (bb_next(bb0, sq0))
		{
		/* is the attacker a sweep piece? */

		if (cp_sweepv[cp0 = local.rbv[sq0]])
			{
			/* sweep attack, get direction */

			dx = *(dx_table_base + offset_sqsq(sq0, sq));

			/* fetch shadow bitboard */

			bb1 = *(ray_raster_base + offset_dxsq(dx, sq));

			/* are any white pieces in the shadow? */

			if (bb_tstand(c0bbv[c_w], bb1))
				{
				/* at least one white shadow piece, start scan */

				dv = dvv[dx];
				sq1 = sq + dv;
				while ((cp1 = local.rbv[sq1]) == cp_v0)
					sq1 += dv;

				/* first shadow piece found; is it white? */

				if (cp_tstw(cp1))
					{
					/* white shadow piece located */

					if ((cp1 == cp_wk) || (cpvalv[cp1] > cpvalv[cp0]))
						result += pef_pinned;
					else
						if (bb_tstnotsq(acbbv[c_w], sq1))
							result += pef_pinned;
					};
				};
			};
		};
	};

if (result != 0)
	{
	bb0 = atbbv[sq];
	bb_and3(bb0, c0bbv[c_w], bb1);
	bb_and3(bb0, c0bbv[c_b], bb2);
	if (bb_count(bb2) > bb_count(bb1))
		result += pef_pinned;
	};

return (result);
}

/*--> EvaluatePinBlack: detect and score a pinned black piece */
static
cpevT
EvaluatePinBlack(sqT sq)
{
cpevT result;
bbT bb0, bb1, bb2;
sqT sq0, sq1;
cpT cp0, cp1;
dxT dx;
dvT dv;

result = 0;

/* is the piece under attack? */

if (bb_tstsq(acbbv[c_w], sq))
	{
	/* get the attackers */

	bb_and3(atbbv[sq], c0bbv[c_w], bb0);

	/* scan the attackers */

	while (bb_next(bb0, sq0))
		{
		/* is the attacker a sweep piece? */

		if (cp_sweepv[cp0 = local.rbv[sq0]])
			{
			/* sweep attack, get direction */

			dx = *(dx_table_base + offset_sqsq(sq0, sq));

			/* fetch shadow bitboard */

			bb1 = *(ray_raster_base + offset_dxsq(dx, sq));

			/* are any black pieces in the shadow? */

			if (bb_tstand(c0bbv[c_b], bb1))
				{
				/* at least one black shadow piece, start scan */

				dv = dvv[dx];
				sq1 = sq + dv;
				while ((cp1 = local.rbv[sq1]) == cp_v0)
					sq1 += dv;

				/* first shadow piece found; is it black? */

				if (!cp_tstw(cp1))
					{
					/* black shadow piece located */

					if ((cp1 == cp_bk) || (cpvalv[cp1] > cpvalv[cp0]))
						result += pef_pinned;
					else
						if (bb_tstnotsq(acbbv[c_b], sq1))
							result += pef_pinned;
					};
				};
			};
		};
	};

if (result != 0)
	{
	bb0 = atbbv[sq];
	bb_and3(bb0, c0bbv[c_b], bb1);
	bb_and3(bb0, c0bbv[c_w], bb2);
	if (bb_count(bb2) > bb_count(bb1))
		result += pef_pinned;
	};

return (result);
}

/*--> EvaluatePositionalMopUp: evaluate mop up positional factors */
static
void
EvaluatePositionalMopUp(void)
{
siT dist;
sqT sq;

/* losing king decentralization penalty */

if (pe_mop_wc == c_w)
	position_ev[c_b] += centdist.sibv[pe_bksq] * pef_mopup_k_decentral;
else
	position_ev[c_w] += centdist.sibv[pe_wksq] * pef_mopup_k_decentral;

/* special winning knight <-> losing king tropism bonus */

if (pe_mop_wc == c_w)
	{
	if (bb_tst(cpbbv[cp_wn]))
		{
		dist = 0;
		gp_bb = cpbbv[cp_wn];
		while (bb_next_gp(sq))
			dist += *(taxi_table_base + offset_sqsq(pe_bksq, sq));
		position_ev[c_w] += (14 - dist) * pef_mopup_n_tropism;
		};
	}
else
	{
	if (bb_tst(cpbbv[cp_bn]))
		{
		dist = 0;
		gp_bb = cpbbv[cp_bn];
		while (bb_next_gp(sq))
			dist += *(taxi_table_base + offset_sqsq(pe_wksq, sq));
		position_ev[c_b] += (14 - dist) * pef_mopup_n_tropism;
		};
	};

/* special winning king <-> losing king tropism bonus */

if (pe_mop_wc == c_w)
	position_ev[c_w] +=
		(14 - *(taxi_table_base + offset_sqsq(pe_wksq, pe_bksq))) *
		pef_mopup_k_tropism;
else
	position_ev[c_b] +=
		(14 - *(taxi_table_base + offset_sqsq(pe_bksq, pe_wksq))) *
		pef_mopup_k_tropism;

/* winning king checkmating positioning bonus */

if (pe_mop_wc == c_w)
	{
	if (bb_tstsqrf(ontherim, pe_bkrank, pe_bkfile))
		{
		position_ev[c_w] += pef_mopup_k_rimmed;
		if (bb_tstsqrf(opposing, pe_wkrank, pe_wkfile))
			if (((pe_bkrank == rank_1) && (pe_wkrank == rank_3)) ||
				((pe_bkrank == rank_8) && (pe_wkrank == rank_6)) ||
				((pe_bkfile == file_a) && (pe_wkfile == file_c)) ||
				((pe_bkfile == file_h) && (pe_wkfile == file_f)))
				position_ev[c_w] += pef_mopup_k_opposing;
		};
	}
else
	{
	if (bb_tstsqrf(ontherim, pe_wkrank, pe_wkfile))
		{
		position_ev[c_b] += pef_mopup_k_rimmed;
		if (bb_tstsqrf(opposing, pe_bkrank, pe_bkfile))
			if (((pe_wkrank == rank_1) && (pe_bkrank == rank_3)) ||
				((pe_wkrank == rank_8) && (pe_bkrank == rank_6)) ||
				((pe_wkfile == file_a) && (pe_bkfile == file_c)) ||
				((pe_wkfile == file_h) && (pe_bkfile == file_f)))
				position_ev[c_b] += pef_mopup_k_opposing;
		};
	};

/* losing king hustled bonus */

if (pe_mop_wc == c_w)
	{
	bb_and3(acbbv[c_w], khbbv[pe_bksq], gp_bb);
	if (bb_equal(khbbv[pe_bksq], gp_bb))
		position_ev[c_w] += pef_mopup_k_hustle;
	}
else
	{
	bb_and3(acbbv[c_b], khbbv[pe_wksq], gp_bb);
	if (bb_equal(khbbv[pe_wksq], gp_bb))
		position_ev[c_b] += pef_mopup_k_hustle;
	};

return;
}

/*--> EvaluatePositionalWhitePawn: position factors: wP */
static
void
EvaluatePositionalWhitePawn(sqT sq)
{
rankT pawnrank;
fileT pawnfile;
sqT pawnsq;
mpevT value;

/* passed */

if (bb_tstnotand(ppbbv[c_w][sq], cpbbv[cp_bp]))
	{
	value = pef_p_passed_basic;
	pawnsq = sq + dv_1;
	pawnrank = map_rank(pawnsq);
	pawnfile = map_file(pawnsq);
	if (bb_tstsqrf(c0bbv[c_b], pawnrank, pawnfile))
		value += pef_p_passed_blocked;
	if (bb_tstsqrf(acbbv[c_b], pawnrank, pawnfile))
		value += pef_p_passed_attacked;
	if (bb_tstsqrf(acbbv[c_w], pawnrank, pawnfile))
		value += pef_p_passed_defended;
	position_ev[c_w] += value * rbpasv[c_w][map_rank(sq)];
	};

return;
}

/*--> EvaluatePositionalWhiteKnight: position factors: wN */
static
void
EvaluatePositionalWhiteKnight(sqT sq)
{
/* pin penalty */

position_ev[c_w] += EvaluatePinWhite(sq);

/* center tropism */

position_ev[c_w] += (6 - (2 * centdist.sibv[sq])) * pef_n_center_tropism;

/* king tropism */

position_ev[c_w] +=
	(5 - *(taxi_table_base + offset_sqsq(pe_bksq, sq))) * pef_n_king_tropism;

/* development */

if (bb_tstsq(ontherim, sq))
	position_ev[c_w] += pef_n_rimmed;

return;
}

/*--> EvaluatePositionalWhiteBishop: position factors: wB */
static
void
EvaluatePositionalWhiteBishop(sqT sq)
{
/* pin penalty */

position_ev[c_w] += EvaluatePinWhite(sq);

/* square control */

bb_mask3(cpbbv[cp_wp], afbbv[sq], gp_bb);
position_ev[c_w] += (bb_count_gp() - 7) * pef_b_square_control;

/* development */

if (bb_tstsq(ontherim, sq))
	{
	position_ev[c_w] += pef_b_rimmed;
	if (bb_count(afbbv[sq]) < 3)
		position_ev[c_w] += pef_b_blocked;
	};

return;
}

/*--> EvaluatePositionalWhiteRook: position factors: wR */
static
void
EvaluatePositionalWhiteRook(sqT sq)
{
sqT pawnsq;
bbT rankbb, filebb;

/* pin penalty */

position_ev[c_w] += EvaluatePinWhite(sq);

/* square control */

position_ev[c_w] += bb_count(afbbv[sq]) * pef_r_square_control;

/* connected */

if (bb_tstand(afbbv[sq], cpbbv[cp_wr]))
	position_ev[c_w] += pef_r_connect;

/* king tropism */

position_ev[c_w] +=
	*(mintaxi_table_base + offset_sqsq(pe_bksq, sq)) * pef_r_king_tropism;

/* file credits */

filebb = f0bbv[map_file(sq)];
if (bb_tstnotand(filebb, cpbbv[cp_wp]))
	if (bb_tstnotand(filebb, cpbbv[cp_bp]))
		position_ev[c_w] += pef_r_open_file;
	else
		{
		bb_and3(filebb, cpbbv[cp_bp], gp_bb);
		pawnsq = bb_once_gp();
		if (bb_tstnotand(pcbbv[c_w][pawnsq], cpbbv[cp_bp]))
			{
			pawnsq -= dv_1;
			if (bb_tstand(pcbbv[c_b][pawnsq], cpbbv[cp_wp]))
				position_ev[c_w] += pef_r_semiopen_file;
			};
		};

/* horizontal multipawn (indirect) attack */

rankbb = r0bbv[map_rank(sq)];
bb_and3(rankbb, cpbbv[cp_bp], gp_bb);
if (bb_count_gp() >= 3)
	position_ev[c_w] += pef_r_mult_hz_p_atk;

return;
}

/*--> EvaluatePositionalWhiteQueen: position factors: wQ */
static
void
EvaluatePositionalWhiteQueen(sqT sq)
{
/* pin penalty */

position_ev[c_w] += EvaluatePinWhite(sq);

/* square control */

bb_mask3(acbbv[c_b], afbbv[sq], gp_bb);
position_ev[c_w] += bb_count_gp() * pef_q_square_control;

/* king tropism */

position_ev[c_w] +=
	*(mintaxi_table_base + offset_sqsq(pe_bksq, sq)) * pef_q_king_tropism;

return;
}

/*--> EvaluatePositionalWhiteKing: position factors: wK */
static
void
EvaluatePositionalWhiteKing(sqT sq)
{
mpevT ks_value;
siT dist, n, ks_import;
sqT psq;

/* determine king safety importance */

bb_ior4(cpbbv[cp_bn], cpbbv[cp_bb], cpbbv[cp_br], gp_bb);
bb_ior2(cpbbv[cp_bq], gp_bb);
if (bb_tst(cpbbv[cp_bq]))
	ks_import = bb_count_gp();
else
	ks_import = bb_count_gp() - 2;

/* process safety evaluations */

if (ks_import > 0)
	{
	/* clear safety value */

	ks_value = 0;

	/* sanctuary check */

	if (bb_tstsqrf(sancspot[c_w], pe_wkrank, pe_wkfile))
		ks_value += pef_k_sanctuary;

	/* cramp check */

	if (bb_tstsqrf(cramspot[c_w], pe_wkrank, pe_wkfile))
		{
		bb_and3(r0bbv[rank_2], afbbv[sq], gp_bb);
		bb_mask2(cpbbv[cp_wp], gp_bb);
		bb_mask2(acbbv[c_b], gp_bb);
		if (bb_tstnot(gp_bb))
			ks_value += pef_k_cramped;
		};

	/* shelter */

	bb_and3(c0bbv[c_w], afbbv[sq], gp_bb);
	if ((n = bb_count_gp()) < 2)
		if (n == 1)
			ks_value += pef_k_shelter_one;
		else
			ks_value += pef_k_shelter_none;

	/* front pawn check */

	if (pe_wkrank != rank_8)
		if (bb_tstnotand(ptbbv[c_w][sq], cpbbv[cp_wp]))
			ks_value += pef_k_no_front_pawn;
		else
			if (local.rbv[sq + dv_1] == cp_wp)
				ks_value += pef_k_immed_front_pawn;

	/* side pawn check (full file) */

	if (bb_tstnotand(fabbv[pe_wkfile], cpbbv[cp_wp]))
		ks_value += pef_k_no_side_pawn;

	/* multiple attacks */

	bb_and3(acbbv[c_b], afbbv[sq], gp_bb);
	if ((n = bb_count_gp()) > 1)
		ks_value += (n - 1) * pef_k_multiple_attacks;

	/* fold safety component product */

	position_ev[c_w] += ks_import * ks_value;

	};

/* determine endgame status */

if (envn.envn_mcpv[c_b] < pef_material_endgame)
	{
	/* center tropism */

	position_ev[c_w] += (2 * centdist.sibv[sq]) * pef_k_eg_center_tropism;

	/* pawn tropism */

	bb_ior3(cpbbv[cp_wp], cpbbv[cp_bp], gp_bb);
	if ((n = bb_count_gp()) > 0)
		{
		dist = 0;
		while (bb_next_gp(psq))
			dist += *(taxi_table_base + offset_sqsq(sq, psq));
		position_ev[c_w] +=
			((dist - (6 * n)) * pef_k_eg_pawn_tropism) / n;
		};
	};

return;
}

/*--> EvaluatePositionalBlackPawn: position factors: bP */
static
void
EvaluatePositionalBlackPawn(sqT sq)
{
rankT pawnrank;
fileT pawnfile;
sqT pawnsq;
mpevT value;

/* passed */

if (bb_tstnotand(ppbbv[c_b][sq], cpbbv[cp_wp]))
	{
	value = pef_p_passed_basic;
	pawnsq = sq + dv_3;
	pawnrank = map_rank(pawnsq);
	pawnfile = map_file(pawnsq);
	if (bb_tstsqrf(c0bbv[c_w], pawnrank, pawnfile))
		value += pef_p_passed_blocked;
	if (bb_tstsqrf(acbbv[c_w], pawnrank, pawnfile))
		value += pef_p_passed_attacked;
	if (bb_tstsqrf(acbbv[c_b], pawnrank, pawnfile))
		value += pef_p_passed_defended;
	position_ev[c_b] += value * rbpasv[c_b][map_rank(sq)];
	};

return;
}

/*--> EvaluatePositionalBlackKnight: position factors: bN */
static
void
EvaluatePositionalBlackKnight(sqT sq)
{
/* pin penalty */

position_ev[c_b] += EvaluatePinBlack(sq);

/* center tropism */

position_ev[c_b] += (6 - (2 * centdist.sibv[sq])) * pef_n_center_tropism;

/* king tropism */

position_ev[c_b] +=
	(5 - *(taxi_table_base + offset_sqsq(pe_wksq, sq))) * pef_n_king_tropism;

/* development */

if (bb_tstsq(ontherim, sq))
	position_ev[c_b] += pef_n_rimmed;

return;
}

/*--> EvaluatePositionalBlackBishop: position factors: bB */
static
void
EvaluatePositionalBlackBishop(sqT sq)
{
/* pin penalty */

position_ev[c_b] += EvaluatePinBlack(sq);

/* square control */

bb_mask3(cpbbv[cp_bp], afbbv[sq], gp_bb);
position_ev[c_b] += (bb_count_gp() - 7) * pef_b_square_control;

/* development */

if (bb_tstsq(ontherim, sq))
	{
	position_ev[c_b] += pef_b_rimmed;
	if (bb_count(afbbv[sq]) < 3)
		position_ev[c_b] += pef_b_blocked;
	};

return;
}

/*--> EvaluatePositionalBlackRook: position factors: bR */
static
void
EvaluatePositionalBlackRook(sqT sq)
{
sqT pawnsq;
bbT rankbb, filebb;

/* pin penalty */

position_ev[c_b] += EvaluatePinBlack(sq);

/* square control */

position_ev[c_b] += bb_count(afbbv[sq]) * pef_r_square_control;

/* connected */

if (bb_tstand(afbbv[sq], cpbbv[cp_br]))
	position_ev[c_b] += pef_r_connect;

/* king tropism */

position_ev[c_b] +=
	*(mintaxi_table_base + offset_sqsq(pe_wksq, sq)) * pef_r_king_tropism;

/* file credits */

filebb = f0bbv[map_file(sq)];
if (bb_tstnotand(filebb, cpbbv[cp_bp]))
	if (bb_tstnotand(filebb, cpbbv[cp_wp]))
		position_ev[c_b] += pef_r_open_file;
	else
		{
		bb_and3(filebb, cpbbv[cp_wp], gp_bb);
		pawnsq = bb_once_gp();
		if (bb_tstnotand(pcbbv[c_b][pawnsq], cpbbv[cp_wp]))
			{
			pawnsq += dv_1;
			if (bb_tstand(pcbbv[c_w][pawnsq], cpbbv[cp_bp]))
				position_ev[c_b] += pef_r_semiopen_file;
			};
		};

/* horizontal multipawn (indirect) attack */

rankbb = r0bbv[map_rank(sq)];
bb_and3(rankbb, cpbbv[cp_wp], gp_bb);
if (bb_count_gp() >= 3)
	position_ev[c_b] += pef_r_mult_hz_p_atk;

return;
}

/*--> EvaluatePositionalBlackQueen: position factors: bQ */
static
void
EvaluatePositionalBlackQueen(sqT sq)
{
/* pin penalty */

position_ev[c_b] += EvaluatePinBlack(sq);

/* square control */

bb_mask3(acbbv[c_w], afbbv[sq], gp_bb);
position_ev[c_b] += bb_count_gp() * pef_q_square_control;

/* king tropism */

position_ev[c_b] +=
	*(mintaxi_table_base + offset_sqsq(pe_wksq, sq)) * pef_q_king_tropism;

return;
}

/*--> EvaluatePositionalBlackKing: position factors: bK */
static
void
EvaluatePositionalBlackKing(sqT sq)
{
mpevT ks_value;
siT dist, n, ks_import;
sqT psq;

/* determine king safety importance */

bb_ior4(cpbbv[cp_wn], cpbbv[cp_wb], cpbbv[cp_wr], gp_bb);
bb_ior2(cpbbv[cp_wq], gp_bb);
if (bb_tst(cpbbv[cp_wq]))
	ks_import = bb_count_gp();
else
	ks_import = bb_count_gp() - 2;

/* process safety evaluations */

if (ks_import > 0)
	{
	/* clear safety value */

	ks_value = 0;

	/* sanctuary check */

	if (bb_tstsqrf(sancspot[c_b], pe_bkrank, pe_bkfile))
		ks_value += pef_k_sanctuary;

	/* cramp check */

	if (bb_tstsqrf(cramspot[c_b], pe_bkrank, pe_bkfile))
		{
		bb_and3(r0bbv[rank_7], afbbv[sq], gp_bb);
		bb_mask2(cpbbv[cp_bp], gp_bb);
		bb_mask2(acbbv[c_w], gp_bb);
		if (bb_tstnot(gp_bb))
			ks_value += pef_k_cramped;
		};

	/* shelter */

	bb_and3(c0bbv[c_b], afbbv[sq], gp_bb);
	if ((n = bb_count_gp()) < 2)
		if (n == 1)
			ks_value += pef_k_shelter_one;
		else
			ks_value += pef_k_shelter_none;

	/* front pawn check */

	if (pe_bkrank != rank_1)
		if (bb_tstnotand(ptbbv[c_b][sq], cpbbv[cp_bp]))
			ks_value += pef_k_no_front_pawn;
		else
			if (local.rbv[sq + dv_3] == cp_bp)
				ks_value += pef_k_immed_front_pawn;

	/* side pawn check (full file) */

	if (bb_tstnotand(fabbv[pe_bkfile], cpbbv[cp_bp]))
		ks_value += pef_k_no_side_pawn;

	/* multiple attacks */

	bb_and3(acbbv[c_w], afbbv[sq], gp_bb);
	if ((n = bb_count_gp()) > 1)
		ks_value += (n - 1) * pef_k_multiple_attacks;

	/* fold safety component product */

	position_ev[c_b] += ks_import * ks_value;

	};

/* determine endgame status */

if (envn.envn_mcpv[c_w] < pef_material_endgame)
	{
	/* center tropism */

	position_ev[c_b] += (2 * centdist.sibv[sq]) * pef_k_eg_center_tropism;

	/* pawn tropism */

	bb_ior3(cpbbv[cp_wp], cpbbv[cp_bp], gp_bb);
	if ((n = bb_count_gp()) > 0)
		{
		dist = 0;
		while (bb_next_gp(psq))
			dist += *(taxi_table_base + offset_sqsq(sq, psq));
		position_ev[c_b] +=
			((dist - (6 * n)) * pef_k_eg_pawn_tropism) / n;
		};
	};

return;
}

/*--> EvaluatePositionalPieceScan: eval positional (scan and dispatch) */
static
void
EvaluatePositionalPieceScan(void)
{
sqT sq;
mpevT half_mpev;

/* handle each piece */

gp_abb = apmbb;
while (bb_next_gpa(sq))
	(*piece_scan_routine[local.rbv[sq]])(sq);

/* fetch the pawn structure score */

half_mpev = PawnTTFetchEvaluation() >> 1;
if (actc == c_w)
	{
	position_ev[c_w] += half_mpev;
	position_ev[c_b] -= half_mpev;
	}
else
	{
	position_ev[c_b] += half_mpev;
	position_ev[c_w] -= half_mpev;
	};

return;
}

/*--> EvaluatePositional: get positional factors, fold into accumulators */
nonstatic
cpevT
EvaluatePositional(void)
{
mpevT posval, absposval, adjposval, ratio_bonus;
siT shift, sign, n;
cT c;
bbT hung_actc_bb;

/* general set up */

EvaluatePositionalSetUp();

/* process according to mode */

if (pe_mop_flag)
	{
	/* high speed mop evaluation */

	EvaluatePositionalMopUp();
	}
else
	{
	/* slow speed piece scan */

	EvaluatePositionalPieceScan();
	};

/* calculate active hung bitboard */

if (actc == c_w)
	{
	bb_and3(acbbv[c_b], c0bbv[c_w], hung_actc_bb);
	bb_mask2(acbbv[c_w], hung_actc_bb);
	}
else
	{
	bb_and3(acbbv[c_w], c0bbv[c_b], hung_actc_bb);
	bb_mask2(acbbv[c_b], hung_actc_bb);
	};

/* multiple minor piece non-development terms */

if (!pe_mop_flag)
	{
	/* white undeveloped minor pieces */

	bb_ior3(cpbbv[cp_wn], cpbbv[cp_wb], gp_bb);
	bb_and2(ontherim, gp_bb);
	if ((n = bb_count_gp()) > 1)
		position_ev[c_w] += (n - 1) * pef_multiple_n_b_undev;

	/* black undeveloped minor pieces */

	bb_ior3(cpbbv[cp_bn], cpbbv[cp_bb], gp_bb);
	bb_and2(ontherim, gp_bb);
	if ((n = bb_count_gp()) > 1)
		position_ev[c_b] += (n - 1) * pef_multiple_n_b_undev;
	};

/* active attacked piece term (to be revised) */

if (!pe_mop_flag && bb_tst(hung_actc_bb))
	position_ev[actc] += pef_actc_atkd_single;

/* side-to-play adjustment */

if (actc == c_w)
	{
	position_ev[c_w] += pef_stp_actc;
	position_ev[c_b] += pef_stp_pasc;
	}
else
	{
	position_ev[c_b] += pef_stp_actc;
	position_ev[c_w] += pef_stp_pasc;
	};

/* ratio bonus (millipawn units) */

if (envn.envn_mcpv[c_w] != envn.envn_mcpv[c_b])
	if (envn.envn_mcpv[c_w] > envn.envn_mcpv[c_b])
		{
		ratio_bonus = (mpevT) ((((liT) envn.envn_mcpv[c_w]) << 8) /
			(envn.envn_mcpv[c_w] + envn.envn_mcpv[c_b])) - 128;
		position_ev[c_w] += ratio_bonus;
		}
	else
		{
		ratio_bonus = (mpevT)  ((((liT) envn.envn_mcpv[c_b]) << 8) /
			(envn.envn_mcpv[c_w] + envn.envn_mcpv[c_b])) - 128;
		position_ev[c_b] += ratio_bonus;
		};

/* scaling */

for (c = c_w; c <= c_b; c++)
	{
	/* get raw score */

	posval = position_ev[c];

	/* calculate absolute value and record sign */

	if (posval >= 0)
		{
		sign = 1;
		absposval = posval;
		}
	else
		{
		sign = -1;
		absposval = -posval;
		};

	/* calculate logarithmically scaled adjusted score */

	adjposval = 0;
	shift = 0;
	while (absposval >= mp_posband)
		{
		adjposval += (mp_posband >> shift);
		absposval -= mp_posband;
		shift++;
		};
	adjposval += (absposval >> shift);

	/* set result to adjusted value based on initial sign */

	if (sign == 1)
		position_ev[c] = adjposval;
	else
		position_ev[c] = -adjposval;
	};

/* trace positional */

if (optnv[optn_trev])
	{
	PrTrace("EV");
	PrStrMillipawn("w/pos: ", position_ev[c_w]);
	PrNL();
	PrTrace("EV");
	PrStrMillipawn("b/pos: ", position_ev[c_b]);
	PrNL();
	};

/* combined magnitude */

posval = position_ev[actc] - position_ev[pasc];

return (posval / ecsf_ctm);
}

/*--> EvaluatePositionalInit: set up positional system (one time call) */
nonstatic
void
EvaluatePositionalInit(void)
{
/* set up the piece scan dispatch table */

piece_scan_routine[cp_wp] = EvaluatePositionalWhitePawn;
piece_scan_routine[cp_wn] = EvaluatePositionalWhiteKnight;
piece_scan_routine[cp_wb] = EvaluatePositionalWhiteBishop;
piece_scan_routine[cp_wr] = EvaluatePositionalWhiteRook;
piece_scan_routine[cp_wq] = EvaluatePositionalWhiteQueen;
piece_scan_routine[cp_wk] = EvaluatePositionalWhiteKing;

piece_scan_routine[cp_bp] = EvaluatePositionalBlackPawn;
piece_scan_routine[cp_bn] = EvaluatePositionalBlackKnight;
piece_scan_routine[cp_bb] = EvaluatePositionalBlackBishop;
piece_scan_routine[cp_br] = EvaluatePositionalBlackRook;
piece_scan_routine[cp_bq] = EvaluatePositionalBlackQueen;
piece_scan_routine[cp_bk] = EvaluatePositionalBlackKing;

return;
}

/*<<< epos.c: EOF */
