/*>>> setsq.c: database square set/clear routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "setsq.h"

/*--> SqClr: clear database entry for square (acts on the local board) */
nonstatic
void
SqClr(sqT sq)
{
cpT old_cp;
rankT rank;
fileT file;

/* process for nonvacant squares only; this will clear the square */

if ((old_cp = local.rbv[sq]) != cp_v0)
	{
	/* clear local board */

	local.rbv[sq] = cp_v0;

	/* fetch rank and file coordinates */

	rank = map_rank(sq);
	file = map_file(sq);

	/* adjust bitboards */

	if (cp_tstw(old_cp))
		bb_clrsqrf(c0bbv[c_w], rank, file);
	else
		bb_clrsqrf(c0bbv[c_b], rank, file);
	bb_clrsqrf(cpbbv[old_cp], rank, file);
	bb_clrsqrf(apmbb, rank, file);
	};

return;
}

/*--> SqSet: set database entry for square (also sets the local board) */
nonstatic
void
SqSet(cpT new_cp, sqT sq)
{
cpT old_cp;
rankT rank;
fileT file;

/* process only if old value is different from new value */

if ((old_cp = local.rbv[sq]) != new_cp)
	{
	/* update the local board */

	local.rbv[sq] = new_cp;

	/* fetch rank and file coordinates */

	rank = map_rank(sq);
	file = map_file(sq);

	/* processing based on old cp value */

	if (old_cp != cp_v0)
		{
		if (cp_tstw(old_cp))
			bb_clrsqrf(c0bbv[c_w], rank, file);
		else
			bb_clrsqrf(c0bbv[c_b], rank, file);
		bb_clrsqrf(cpbbv[old_cp], rank, file);
		};

	/* processing based on new cp value */

	if (new_cp == cp_v0)
		bb_clrsqrf(apmbb, rank, file);
	else
		{
		if (cp_tstw(new_cp))
			bb_setsqrf(c0bbv[c_w], rank, file);
		else
			bb_setsqrf(c0bbv[c_b], rank, file);
		bb_setsqrf(cpbbv[new_cp], rank, file);
		bb_setsqrf(apmbb, rank, file);
		};
	};

return;
}

/*<<< setsq.c: EOF */
