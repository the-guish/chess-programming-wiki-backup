/*>>> draw.c: drawing status routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "bb.h"
#include "draw.h"
#include "sysutil.h"

/*--> DrawHalfMoveClock: determine if a halfmove clock draw exists */
nonstatic
siT
DrawHalfMoveClock(void)
{

return ((envn.envn_hmvc >= hmvcL) ? 1 : 0);
}

/*--> DrawInsufficientMaterial: determine if an insufficient material draw */
nonstatic
siT
DrawInsufficientMaterial(void)
{
siT flag;
bbT mpbb;

if (bb_tst(cpbbv[cp_wp]) || bb_tst(cpbbv[cp_bp]) ||
	bb_tst(cpbbv[cp_wr]) || bb_tst(cpbbv[cp_br]) ||
	bb_tst(cpbbv[cp_wq]) || bb_tst(cpbbv[cp_bq]))
	flag = 0;
else
	{
	bb_clr(mpbb);
	bb_ior2(cpbbv[cp_wn], mpbb);
	bb_ior2(cpbbv[cp_bn], mpbb);
	bb_ior2(cpbbv[cp_wb], mpbb);
	bb_ior2(cpbbv[cp_bb], mpbb);
	if (bb_count(mpbb) < 2)
		flag = 1;
	else
		flag = 0;
	};

return (flag);
}

/*--> DrawHashRepeatCount: return position occurance count (always >= 1) */
static
siT
DrawHashRepeatCount(siT n)
{
siT i, count;
histptrT hptr;

/* position occurs at least once (the current position) */

count = 1;

/* check for a maximum of n repetitions (not accurate if null moves exist) */

if (envn.envn_hmvc >= ((n - 1) * 4))
	{
	hptr = histcurr;
	for (i = 0; i < envn.envn_hmvc; i += 2)
		{
		hptr -= 2;
		if (hptr->hist_mhac == envn.envn_mhac)
			if (hptr->hist_mhsc == envn.envn_mhsc)
				count++;
		};
	};

return (count);
}

/*--> DrawRepeatCount: return position occurance count (always >= 1) */
static
siT
DrawRepeatCount(siT n)
{
siT i, count, bust;
sqT sq;
histptrT hptr;
byteT byte;

/* hash coding used past ply -history_full_push- */

if (ply > history_full_push)
	Diagnose("DrawRepeatCount: ply > history_full_push");

/* position occurs at least once (the current position) */

count = 1;

/* check for a maximum of n repetitions (not accurate if null moves exist) */

if (envn.envn_hmvc >= ((n - 1) * 4))
	{
	hptr = histcurr;
	for (i = 0; i < envn.envn_hmvc; i += 2)
		{
		hptr -= 2;
		if (hptr->hist_mhac == envn.envn_mhac)
			if (hptr->hist_mhsc == envn.envn_mhsc)
				if (hptr->hist_cast == envn.envn_cast)
					if (hptr->hist_epsq == envn.envn_epsq)
						{
						bust = 0;
						sq = sq_a1;
						while (!bust && (sq <= sq_h8))
							{
							byte = hptr->hist_nbv[sq >> 1];
							if ((byte & nybbM) != local.rbv[sq])
								bust = 1;
							else
								if (((byte >> nybbW) & nybbM) !=
									local.rbv[sq + 1])
									bust = 1;
								else
									sq += 2;
							};
						if (!bust)
							count++;
						};
		};
	};

return (count);
}

/*--> DrawHashRepeatTwice: determine if two time repeat (potential draw) */
nonstatic
siT
DrawHashRepeatTwice(void)
{

return ((DrawHashRepeatCount(2) < 2) ? 0 : 1);
}

/*--> DrawHashRepeatThrice: determine if two time repeat (potential draw) */
nonstatic
siT
DrawHashRepeatThrice(void)
{

return ((DrawHashRepeatCount(3) < 3) ? 0 : 1);
}

/*--> DrawRepeatTwice: determine if two time rep exists (potential draw) */
nonstatic
siT
DrawRepeatTwice(void)
{

return ((DrawRepeatCount(2) < 2) ? 0 : 1);
}

/*--> DrawRepeatThrice: determine if a three time rep draw exists */
nonstatic
siT
DrawRepeatThrice(void)
{

return ((DrawRepeatCount(3) < 3) ? 0 : 1);
}

/*--> DrawTestPartial: partial draw check (used in search) */
nonstatic
siT
DrawTestPartial(void)
{

return (DrawHalfMoveClock() ||
	DrawInsufficientMaterial() || DrawHashRepeatTwice());
}

/*<<< draw.c: EOF */
