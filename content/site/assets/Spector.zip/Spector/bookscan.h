/*>>> bookscan.h: subprogram prototypes for bookscan.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

mptrT ListBookSearch(void);

/*<<< bookscan.h: EOF */
