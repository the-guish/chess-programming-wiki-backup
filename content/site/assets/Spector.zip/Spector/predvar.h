/*>>> predvar.h: subprogram prototypes for predvar.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void PVarEClear(void);
siT PVarELength(void);
void PVarWMReset(void);
void PVarInit(void);
void PVarTerm(void);
void PVarWMCut(void);
void PVarWMMerge(mptrT mptr);
void PVarWMSplice(mptrT mptr);
mptrT PVarEMoveRef(siT n);
mptrT PVarEFirstMoveRef(void);
void PVarESetHint(mptrT mptr);
void PVarEShift(mptrT mptr);
void PVarEFormat(char tv[tL]);
void PVarEPrint(void);
siT PVarWMMainLength(void);
siT PVarWMSubLength(void);
lmptrT PVarWMSubRef(siT n);
void PVarPlyZeroProcess(void);

/*<<< predvar.h: EOF */
