/*>>> cpmb.h: subprogram prototypes for cpmb.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CPMBInit(void);
void CPMBTerm(void);
void CPMBCommand(void);

/*<<< cpmb.h: EOF */
