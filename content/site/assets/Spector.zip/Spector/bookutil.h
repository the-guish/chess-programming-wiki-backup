/*>>> bookutil.h: subprogram prototypes for bookutil.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

obcptrT ListBookNewOBC(sptrT sptr);
void ListBookReleaseOBC(obcptrT obcptr);
void ListBookCodeGetRecord(void);
void ListBookCodePutControl(bkcntlT bkcntl);
void ListBookCodePutMove(siT gord);
void ListBookCodePutAnnotatedMove(siT gord, bkannoT bkanno);
void ListBookSetCodeFiles(charptrT fn_bic, charptrT fn_wtm, charptrT fn_btm);
siT ListBookCensus(charptrT fn, sptrT sptr, obcptrT obcptr);
siT ListBookAutoCensus(obcptrT obcptr);
void ListBookInit(void);
void ListBookTerm(void);

/*<<< bookutil.h: EOF */
