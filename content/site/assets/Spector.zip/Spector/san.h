/*>>> san.h: subprogram prototypes for san.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void SANMoveAux(mptrT mptr, sanT san, nvpcvT nvpcv);
void SANMove(mptrT mptr, sanT san);
void SANDisambiguate(sptrT sptr);
void SANSort(sptrT sptr);
void SANSortList(sanT sanv[], siT count);
void SANSortMoveList(mlstptrT mlstptr);
siT LocateOrdinal(mptrT mptr, sptrT sptr);
mptrT LocateOrdinalMove(siT gord, sptrT sptr);

/*<<< san.h: EOF */
