/*>>> bookutil.c: opening book routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bookdefs.h"
#include "bookvars.h"

#include "bookutil.h"
#include "file.h"
#include "memutil.h"
#include "sysutil.h"

/**** Locals */

/* combined list opening book file name */

static charptrT fn_obcbc;

/* per color list opening book file names */

static charptrT fn_obcpcv[rcL];

/*--> ListBookNewOBC: allocate and initialize obc vector */
nonstatic
obcptrT
ListBookNewOBC(sptrT sptr)
{
obcptrT obcptr, ptr;
siT i, count;

count = sptr->s_count;
obcptr = (obcptrT) MemoryGrab(sizeof(obcT) * count);
ptr = obcptr;
for (i = 0; i < count; i++)
	{
	ptr->obc_count = 0;
	ptr->obc_pflag = 0;
	ptr++;
	};

return (obcptr);
}

/*--> ListBookReleaseOBC: deallocate obc vector */
nonstatic
void
ListBookReleaseOBC(obcptrT obcptr)
{
MemoryFree(obcptr);

return;
}

/*--> BookCNTL: test control marker match */
static
siT
BookCNTL(bkcntlT bkcntl)
{
siT flag;

if (olr.olr_mflg)
	flag = 0;
else
	flag = (olr.olr_cntl == bkcntl);

return (flag);
}

/*--> BookCodeGetByte: get the next byte from a code file */
static
siT
BookCodeGetByte(void)
{
siT c;

c = fgetc(fp_get_code);
if (c == EOF)
	Diagnose("BookCodeGetByte: EOF");

return (c & byteM);
}

/*--> ListBookCodeGetRecord: get the next olr from the code file */
nonstatic
void
ListBookCodeGetRecord(void)
{
siT c0, c1;

c0 = BookCodeGetByte();
if (c0 & bkhbit_mark)
	if (c0 & bkhbit_cntl)
		{
		/* control mark */

		olr.olr_mflg = 0;
		olr.olr_cntl = c0 & bkmask_cntl;
		}
	else
		{
		/* annotated move */

		c1 = BookCodeGetByte();
		olr.olr_mflg = 1;
		olr.olr_gord = c1 & bkmask_gord;
		olr.olr_anno = c0 & bkmask_anno;
		olr.olr_cntl = bkcntl_none;
		}
else
	{
	/* unannotated move */

	olr.olr_mflg = 1;
	olr.olr_gord = c0 & bkmask_gord;
	olr.olr_anno = bkanno_none;
	olr.olr_cntl = bkcntl_none;
	};

return;
}

/*--> BookCodePutRecord: put the next olr to a code file */
static
void
BookCodePutRecord(void)
{
if (olr.olr_mflg)
	{
	if (olr.olr_anno != bkanno_none)
		(void) fputc((bkhbit_mark | olr.olr_anno), fp_put_code);
	(void) fputc(olr.olr_gord, fp_put_code);
	}
else
	if (olr.olr_cntl != bkcntl_none)
		(void) fputc((bkhbit_mark | bkhbit_cntl | olr.olr_cntl),
			fp_put_code);
	else
		Fault("BookPutRecord");

return;
}

/*--> ListBookCodePutControl: put a simple control mark to a code file */
nonstatic
void
ListBookCodePutControl(bkcntlT bkcntl)
{
olr.olr_mflg = 0;
olr.olr_anno = bkanno_none;
olr.olr_cntl = bkcntl;
BookCodePutRecord();

return;
}

/*--> ListBookCodePutMove: put a simple move to the code file */
nonstatic
void
ListBookCodePutMove(siT gord)
{
olr.olr_mflg = 1;
olr.olr_gord = gord;
olr.olr_anno = bkanno_none;
olr.olr_cntl = bkcntl_none;
BookCodePutRecord();

return;
}

/*--> ListBookCodePutAnnotatedMove: put an annotated move to code file */
nonstatic
void
ListBookCodePutAnnotatedMove(siT gord, bkannoT bkanno)
{
olr.olr_mflg = 1;
olr.olr_gord = gord;
olr.olr_anno = bkanno;
olr.olr_cntl = bkcntl_none;
BookCodePutRecord();

return;
}

/*--> ListBookCensus: search opening book and accumulate census vector */
nonstatic
siT
ListBookCensus(charptrT fn, sptrT sptr, obcptrT obcptr)
{
siT flag, candidate, hmc;
mptrT mptr;

/* set default return value */

flag = 1;

/* continue only if position is not a setup */

if (!setup)
	{
	/* clear file pointer if no name was supplied */

	if (fn != NULL)
		fp_bkcd = NULL;

	/* initialize the history match count and the nil candidate */

	hmc = 0;
	candidate = -1;

	/* set up stack indices for book scan */

	bkvarn = 0;
	bkordn = 0;

	/* open the book code file and set scanning flag (note: binary open) */

	if (fn != NULL)
		{
		fp_bkcd = CodeFileOpen(fn, "rb");
		if (fp_bkcd == NULL)
			flag = 0;
		else
			{
			fp_get_code = fp_bkcd;
			SetBigBuffer(fp_bkcd);
			};
		}
	else
		rewind(fp_bkcd);

	/* scan entire book */

	if (flag)
		{
		ListBookCodeGetRecord();
		while (!BookCNTL(bkcntl_stop))
			{
			if (olr.olr_mflg)
				{
				/* stack generation index */

				bkordv[bkordn++] = olr.olr_gord;

				/* update match count */

				if ((hmc == (bkordn - 1)) && (hmc < histn) &&
					(*(cordbase + hmc) == bkordv[hmc]))
					hmc++;

				/* check for a new candidate move */

				if ((candidate == -1) &&
					(hmc == histn) &&
					(histn == (bkordn - 1)))
					{
					candidate = olr.olr_gord;
					mptr = sptr->s_mbase + candidate;
					mptr->m_flag |= mf_book;
					if (olr.olr_anno == bkanno_poor)
						{
						(obcptr + candidate)->obc_pflag = 1;
						mptr->m_flag |= mf_poor;
						};
					};

				/* update census count */

				if (candidate != -1)
					(obcptr + candidate)->obc_count++;
				}
			else
				{
				switch (olr.olr_cntl)
					{
					/* no operation */

					case bkcntl_none:
						break;

					/* stack variation */

					case bkcntl_bvar:
						bkvarv[bkvarn++] = bkordn;
						break;

					/* unstack variation and restore history match count */

					case bkcntl_evar:
						bkordn = bkvarv[--bkvarn];
						if (hmc > bkordn)
							hmc = bkordn;
						if ((candidate != -1) && (bkordn <= histn))
							candidate = -1;
						break;

					/* bust */

					default:
						SwitchFault("BookCensus");
						break;
					};
				};

			/* get next code */

			ListBookCodeGetRecord();
			};
		};

	/* close the bfnm_code file */

	if (fn != NULL)
		if (fp_bkcd != NULL)
			(void) TextFileClose(fp_bkcd);
	};

return (flag);
}

/*--> ListBookAutoCensus: get census vector for current position + color */
nonstatic
siT
ListBookAutoCensus(obcptrT obcptr)
{
siT flag, f0, f1;

f0 = ListBookCensus(fn_obcpcv[actc], root_sptr, obcptr);
f1 = ListBookCensus(fn_obcbc, root_sptr, obcptr);
flag = (f0 || f1);

return (flag);
}

/*--> ListBookInit: initialize the list opening book */
nonstatic
void
ListBookInit(void)
{
char tv[tL];

sprintf(tv, "%s/%s", lbdn_book, fn_bkcd);
fn_obcbc = StringGrab(tv);

sprintf(tv, "%s/%s", lbdn_book, fn_bcow);
fn_obcpcv[c_w] = StringGrab(tv);

sprintf(tv, "%s/%s", lbdn_book, fn_bcob);
fn_obcpcv[c_b] = StringGrab(tv);

return;
}

/*--> ListBookTerm: terminate the list opening book */
nonstatic
void
ListBookTerm(void)
{
MemoryFree(fn_obcbc);
MemoryFree(fn_obcpcv[c_w]);
MemoryFree(fn_obcpcv[c_b]);

return;
}

/*<<< bookutil.c: EOF */
