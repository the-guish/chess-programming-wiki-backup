/*>>> bb.h: subprogram prototypes for bb.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT BitBoardSubset(bbT bb0, bbT bb1);
siT BitBoardCountRef(bbptrT bbptr);
siT BitBoardCountGP(void);
sqT BitBoardNextRef(bbptrT bbptr);
sqT BitBoardNextGP(void);
sqT BitBoardNextGPA(void);
sqT BitBoardOnceRef(bbptrT bbptr);
sqT BitBoardOnceGP(void);
sqT BitBoardNthRef(siT n, bbptrT bbptr);
sqT MinValueSq(bbT bb);
sqT MinValueSqGP(void);
sqT MaxValueSq(bbT bb);
sqT MaxValueSqGP(void);

/*<<< bb.h: EOF */
