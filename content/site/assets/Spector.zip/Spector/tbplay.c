/*>>> tbplay.c: tablebase demonstration playback */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "fen.h"
#include "hist.h"
#include "memutil.h"
#include "oracle.h"
#include "play.h"
#include "print.h"
#include "san.h"
#include "stat.h"
#include "tbplay.h"

/**** Locals */

/* the playthrough list element, one per player turn */

typedef struct ptlS
	{
	siT          ptl_fmvn; /* fullmove number of turn */
	cT           ptl_actc; /* active color of turn */
	siT          ptl_smvc; /* SAN move count */
	sanptrT      ptl_nptr; /* base of SAN notation vector */
	struct ptlS *ptl_prev; /* previous turn */
	struct ptlS *ptl_next; /* next turn */
	} ptlT, *ptlptrT;

/* playthough list anchor pair */

static ptlptrT head_ptlptr;
static ptlptrT tail_ptlptr;

/*--> TBPlayNewPTL: allocate, initialize, and append a new PTL record */
static
ptlptrT
TBPlayNewPTL(siT n)
{
ptlptrT ptlptr;

ptlptr = (ptlptrT) MemoryGrab(sizeof(ptlT));

ptlptr->ptl_fmvn = envn.envn_fmvn;
ptlptr->ptl_actc = actc;
ptlptr->ptl_smvc = n;
ptlptr->ptl_nptr = (sanptrT) MemoryGrab(n * sizeof(sanT));

if (head_ptlptr == NULL)
	head_ptlptr = ptlptr;
else
	tail_ptlptr->ptl_next = ptlptr;

ptlptr->ptl_prev = tail_ptlptr;
ptlptr->ptl_next = NULL;

tail_ptlptr = ptlptr;

return (ptlptr);
}

/*--> TBPlayReleasePTL: dethread and deallocate a PTL record */
static
void
TBPlayReleasePTL(ptlptrT ptlptr)
{
if (ptlptr != NULL)
	{
	if (ptlptr->ptl_next == NULL)
		tail_ptlptr = ptlptr->ptl_prev;
	else
		ptlptr->ptl_next->ptl_prev = ptlptr->ptl_prev;

	if (ptlptr->ptl_prev == NULL)
		head_ptlptr = ptlptr->ptl_next;
	else
		ptlptr->ptl_prev->ptl_next = ptlptr->ptl_next;

	if (ptlptr->ptl_nptr != NULL)
		MemoryFree(ptlptr->ptl_nptr);
	MemoryFree(ptlptr);
	};

return;
}

/*--> TBPlayGenerate: generate tablebase playthrough game score */
static
void
TBPlayGenerate(void)
{
siT flag;
siT i;
siT n, index, count;
cpevT cpev;
mptrT mptr;
sanT san;
sanptrT sanptr;
ptlptrT ptlptr;

flag = GameStatusNormal(root_sptr);

while (flag)
	{
	/* locate oracular moves */

	count = OracularMark(root_sptr);

	/* proceed when all moves oracular */

	if (count != root_sptr->s_count)
		flag = 0;
	else
		{
		/* fetch best oracular score */

		cpev = OracularScore(root_sptr);

		/* enumerate total best moves */

		n = 0;
		mptr = root_sptr->s_mbase;
		for (index = 0; index < count; index++)
			{
			if (mptr->m_eval == cpev)
				n++;
			mptr++;
			};

		/* initialize a new output record */

		ptlptr = TBPlayNewPTL(n);

		/* record move notations */

		n = 0;
		mptr = root_sptr->s_mbase;
		for (index = 0; index < count; index++)
			{
			if (mptr->m_eval == cpev)
				{
				SANMove(mptr, san);
				sanptr = ptlptr->ptl_nptr + n;
				for (i = 0; i < sanL; i++)
					(*sanptr)[i] = san[i];
				n++;
				};
			mptr++;
			};

		/* locate the first best move */

		mptr = root_sptr->s_mbase;
		while (mptr->m_eval != cpev)
			mptr++;

		/* play the first best move */

		PlayMove(mptr);
		};

	/* update status */

	if (flag)
		flag = GameStatusNormal(root_sptr);
	};

return;
}

/*--> TBPlayDS: display string for TB game score output */
static
siT
TBPlayDS(siT col, charptrT s)
{
siT newcol;
liT length;

length = strlen(s);
if (col == 0)
	{
	PrStr(s);
	newcol = length;
	}
else
	if ((col + 1 + length) < soccL)
		{
		PrBlank();
		PrStr(s);
		newcol = col + 1 + length;
		}
	else
		{
		PrNL();
		PrStr(s);
		newcol = length;
		};

return (newcol);
}

/*--> TBPlayDisplay: display tablebase playthrough game score */
static
void
TBPlayDisplay(void)
{
ptlptrT ptlptr;
sanptrT sanptr;
siT i, n;
siT col;
char tv[tL];

/* display loop */

i = 0;
col = 0;
ptlptr = head_ptlptr;
while (ptlptr != NULL)
	{
	/* handle move indication */

	if ((ptlptr->ptl_actc == c_w) || (ptlptr == head_ptlptr))
		{
		sprintf(tv, "%hd.", ptlptr->ptl_fmvn);
		col = TBPlayDS(col, tv);
		};

	/* handle ellipsis indication */

	if ((ptlptr == head_ptlptr) && (ptlptr->ptl_actc == c_b))
		{
		sprintf(tv, "...");
		col = TBPlayDS(col, tv);
		};

	/* handle move */

	sprintf(tv, "%s", *(ptlptr->ptl_nptr));
	col = TBPlayDS(col, tv);

	/* handle alternate set */

	n = ptlptr->ptl_smvc;
	if (n > 1)
		{
		sanptr = ptlptr->ptl_nptr + 1;
		for (i = 1; i < n; i++)
			{
			/* handle move */

			if (i == 1)
				if (i == (n - 1))
					sprintf(tv, "{%s}", *sanptr);
				else
					sprintf(tv, "{%s", *sanptr);
			else
				if (i == (n - 1))
					sprintf(tv, "%s}", *sanptr);
				else
					sprintf(tv, "%s", *sanptr);

			col = TBPlayDS(col, tv);

			/* next move */

			sanptr++;
			};
		};

	i++;
	ptlptr = ptlptr->ptl_next;
	};

if (col != 0)
	PrNL();
PrNL();

return;
}

/*--> TBPlay: tablebase playthrough */
nonstatic
void
TBPlay(void)
{
charptrT fenptr;
siT h0;
cpevT cpev;

/* silence play output */

silent_play = 1;
no_50mvdraw = 1;

/* set up */

head_ptlptr = tail_ptlptr = NULL;

/* report position FEN */

PrStr("FEN: ");
fenptr = FENGenerate();
PrLine(fenptr);

/* report mate/loss/draw status */

PrStr("Evaluation: ");
cpev = OracularEvaluate();
switch (cpev)
	{
	case cpev_bust:
		PrLine("checkmated");
		break;

	case cpev_draw:
		PrLine("drawn");
		break;

	case cpev_wrck:
		PrLine("unavailable");
		break;

	default:
		if (ct_mate(cpev))
			PrStrSINL("Mate in ", (cpev_mate - cpev + 1) / 2);
		else
			PrStrSINL("Loss in ", (cpev + cpev_mate) / 2);
		break;
	}
PrNL();

/* play thorugh for mating or losing games only */

if ((cpev != cpev_wrck) && (ct_mate(cpev) || ct_wump(cpev)))
	{
	/* mark starting history index */

	h0 = histn;

	/* generate */

	TBPlayGenerate();

	/* display */

	TBPlayDisplay();

	/* release storage */

	while (head_ptlptr != NULL)
		TBPlayReleasePTL(head_ptlptr);

	/* unwind history */

	if (histn > h0)
		{
		while (histn > (h0 + 1))
			HistoryDrop();
		UnplayMove();
		};
	}
else
	{
	PrLine("No sample game for other than mates/losses.");
	PrNL();
	};

/* unsilence play output */

silent_play = 0;
no_50mvdraw = 0;

return;
}

/*<<< tbplay.c: EOF */
