/*>>> pick.c: pick moves based on preliminary evaluations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "pick.h"
#include "sysutil.h"

#if (0)
/*--> PickCheck: check a pick for sanity */
static
void
PickCheck(sptrT sptr)
{
mptrT mptr;

if (sptr == NULL)
	Diagnose("PickCheck: sptr NULL");

if (sptr->s_mbase == NULL)
	Diagnose("PickCheck: sptr->s_mbase NULL");

mptr = sptr->s_mcurr;
if (mptr != NULL)
	{
	if (mptr < sptr->s_mbase)
		Diagnose("PickCheck: mptr too low");

	if (mptr >= (sptr->s_mbase + sptr->s_count))
		Diagnose("PickCheck: mptr too high");

	if (!(mptr->m_flag & mf_srch))
		Diagnose("PickCheck: mptr srch unset");
	};

return;
}
#endif

/*--> PickBestPrel: pick a move for trial from moveset */
nonstatic
mptrT
PickBestPrel(sptrT sptr)
{
mptrT mptr0, mptr1;
cpevT score0, score1;
siT i, count;

/* process best move selection */

score1 = cpev_bust;
if (((mptr0 = sptr->s_mbest) != NULL) && !(mptr0->m_flag & mf_srch))
	mptr1 = mptr0;
else
	{
	mptr0 = sptr->s_mbase;
	mptr1 = NULL;
	count = sptr->s_count;
	for (i = 0; i < count; i++)
		{
		/* search for maximum value */

		if (!(mptr0->m_flag & mf_srch))
			if (mptr1 == NULL)
				{
				mptr1 = mptr0;
				score1 = mptr1->m_prel;
				}
			else
				if ((score0 = mptr0->m_prel) > score1)
					{
					mptr1 = mptr0;
					score1 = score0;
					};
		mptr0++;
		};
	};

/* set searched flag for move */

if (mptr1 != NULL)
	mptr1->m_flag |= mf_srch;

/* reset current move pointer in moveset */

sptr->s_mcurr = mptr1;

return (mptr1);
}

/*--> PickThisMove: pick a specific move for trial from moveset */
nonstatic
mptrT
PickThisMove(sptrT sptr, mptrT mptr)
{
/* reset current move pointer in moveset */

sptr->s_mcurr = mptr;

/* mark move as searched (may already be marked) */

mptr->m_flag |= mf_srch;

return (mptr);
}

/*--> PickSingleton: pick the single move in a singleton moveset */
nonstatic
mptrT
PickSingleton(sptrT sptr)
{
mptrT mptr;

/* reset current move pointer in moveset */

mptr = sptr->s_mcurr = sptr->s_mbase;

/* mark move as searched (may already be marked) */

mptr->m_flag |= mf_srch;

return (mptr);
}

/*--> PickLinear: pick a move for trial from moveset */
nonstatic
mptrT
PickLinear(sptrT sptr)
{
mptrT mptr0, mptr1;
siT i, count;

count = sptr->s_count;
if (count == 0)
	mptr1 = NULL;
else
	{
	/* process best move selection */

	if (((mptr0 = sptr->s_mbest) != NULL) && !(mptr0->m_flag & mf_srch))
		mptr1 = mptr0;
	else
		{
		/* set up for scan */

		mptr0 = sptr->s_mbase;
		mptr1 = NULL;
		count = sptr->s_count;

		/* scan linearly; pick first unsearched move */

		i = 0;
		while ((i < count) && (mptr1 == NULL))
			if (mptr0->m_flag & mf_srch)
				{
				i++;
				mptr0++;
				}
			else
				mptr1 = mptr0;
		};
	};

/* set searched flag for move */

if (mptr1 != NULL)
	mptr1->m_flag |= mf_srch;

/* reset current move pointer in moveset */

sptr->s_mcurr = mptr1;

return (mptr1);
}

/*<<< pick.c: EOF */
