/*>>> bbrotate.h: subprogram prototypes for bbrotate.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void BitBoardRotate(bbptrT ptr, dxT dx);

/*<<< bbrotate.h: EOF */
