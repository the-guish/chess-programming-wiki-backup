/*>>> assist.c: assistance routines for node processing */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bbmacs.h"
#include "vpdefs.h"

#include "assist.h"
#include "bb.h"
#include "bbshift.h"
#include "display.h"
#include "moveset.h"
#include "predvar.h"
#include "print.h"
#include "refute.h"
#include "sysutil.h"

/**** Statics */

/* move storage for obvious capture result reference */

static mT ocr_move;

/*--> SIDUpdate: search item display update */
nonstatic
void
SIDUpdate(void)
{
/* display items update */

di_expectation = expectation;
di_iteration = iteration;
di_nodes = count_node - search_start_node;
di_seconds = time(NULL) - search_start_time;

/* display update */

DpUpdate(winid_clock);
DpUpdate(winid_search);
DpUpdate(winid_time);

return;
}

/*--> MovePathTrace: process move path trace at node entry */
nonstatic
void
MovePathTrace(void)
{
/* process trace: general move path */

if (optnv[optn_trmp] && ponder_trace)
	{
	PrTrace("MP");
	PrCurrentPath();
	PrNL();
	};

return;
}

/*--> PlyZeroTrace0: handle ply zero move trace (before search) */
nonstatic
void
PlyZeroTrace0(sptrT dsptr)
{
/* process ply zero trace */

if (optnv[optn_trpz])
	{
	PrTrace("PZ");
	PrCondExpandedSAN(dsptr->s_mcurr);
	PrBlank();
	PrMoveFlags(dsptr->s_mcurr);
	if (dsptr->s_mcurr->m_dptr != NULL)
		{
		PrBlank();
		PrMovesetFlags(dsptr->s_mcurr->m_dptr);
		};
	PrNL();
	};

return;
}

/*--> PlyZeroTrace1: handle ply zero move trace (after search) */
nonstatic
void
PlyZeroTrace1(sptrT dsptr)
{
/* ply zero trace */

if (optnv[optn_trpz])
	{
	PrTrace("PZ");
	PrSAN(dsptr->s_mcurr);
	PrStrCentipawnNL("   eval: ", dsptr->s_mcurr->m_eval);
	};

return;
}

/*--> MateDist: return number of fullmoves until mate */
nonstatic
siT
MateDist(cpevT score)
{
siT dist;

if (ct_mate(score))
	dist = ((cpev_mate - score) + 1) / 2;
else
	dist = -1;

return (dist);
}

/*--> RotateNodeCounts: rotate the ply zero node count list */
static
void
RotateNodeCounts(siT n)
{
siT i;
liptrT liptr0, liptr1;
liT save;

/* save count number n */

save = *(pzsnc_base + n);

/* shift down */

liptr0 = pzsnc_base + n - 2;
liptr1 = pzsnc_base + n - 1;
for (i = 0; i < n; i++)
	*liptr1-- = *liptr0--;

/* restore count number n */

*(pzsnc_base + n) = save;

return;
}

/*--> RotatePlyZero: rotate ply zero best move to start of list */
nonstatic
void
RotatePlyZero(void)
{
mptrT mptr0, mptr1;
siT i, n;
mT m;

/* tree reordering only if current move is not the first move */

if (root_sptr->s_mcurr != root_sptr->s_mbase)
	{
	/* get a copy of the current move */

	m = *root_sptr->s_mcurr;

	/* calculate number of moves to shift in the moveset (positive) */

	n = CurrentPlyZeroMoveIndex();

	/* initialize the roving pointers */

	mptr1 = root_sptr->s_mcurr;
	mptr0 = mptr1 - 1;

	/* perform downward (away from base) move shift and rethread */

	for (i = 0; i < n; i++)
		{
		*mptr1 = *mptr0;
		MovesetRethreadMove(mptr1);
		mptr0--;
		mptr1--;
		};

	/* reset the current pointer to the base */

	root_sptr->s_mcurr = root_sptr->s_mbase;

	/* reset the current move */

	*root_sptr->s_mcurr = m;

	/* reset the moveset best move pointer */

	root_sptr->s_mbest = root_sptr->s_mbase;

	/* rethread current move */

	MovesetRethreadMove(root_sptr->s_mcurr);

	/* shift the refutation sequences by the same displacement */

	RefuteShift(n);

	/* rotate the node counts by the same displacement */

	RotateNodeCounts(n);
	};

return;
}

/*--> BestMoveTrace: trace the best move */
nonstatic
void
BestMoveTrace(void)
{
/* process trace: predicted move */

if (optnv[optn_trpm] && ponder_trace)
	{
	PrTrace("PM");

	/* print the evaluation and the move */

	PrStrCentipawn("[", expectation);
	PrStr("] ");
	PrCondExpandedSAN(root_sptr->s_mbest);
	PrNL();
	};

return;
}

/*--> ObviousCaptureResponse: attempt construction of capture response */
nonstatic
mptrT
ObviousCaptureResponse(mptrT mptr)
{
mptrT dmptr;

/* set destination square */

ocr_move.m_tosq = mptr->m_tosq;

/* process according to active color */

if (actc == c_w)
	{
	/* check if destination is attacked */

	if (bb_tstsq(acbbv[c_w], ocr_move.m_tosq))
		{
		/* square is attacked, find minimal attacker */

		bb_and3(atbbv[ocr_move.m_tosq], c0bbv[c_w], gp_bb);
		ocr_move.m_frcp = local.rbv[ocr_move.m_frsq = MinValueSqGP()];

		/* fetch target piece */

		ocr_move.m_tocp = local.rbv[ocr_move.m_tosq];

		/* test attacker/defender exchange suitablity */

		if (bb_tstnotsq(acbbv[c_b], ocr_move.m_tosq) ||
			(xcpvalv[ocr_move.m_frcp] <= xcpvalv[ocr_move.m_tocp]))
			{
			/* obvious capture response exists; clear flags */

			ocr_move.m_flag = 0;

			/* check for pawn promotion */

			if ((ocr_move.m_frcp == cp_wp) &&
				(map_rank(ocr_move.m_tosq) == rank_8))
				ocr_move.m_scmv = scmv_ppq;
			else
				ocr_move.m_scmv = scmv_reg;

			/* clear remaining items */

			ocr_move.m_eval = ocr_move.m_prel = cpev_bust;
			ocr_move.m_cptr = ocr_move.m_dptr = NULL;

			/* set return result */

			dmptr = &ocr_move;
			}
		else
			{
			/* improper capture */

			dmptr = NULL;
			};
		}
	else
		{
		/* square not attacked, set null result */

		dmptr = NULL;
		};
	}
else
	{
	/* check if destination is attacked */

	if (bb_tstsq(acbbv[c_b], ocr_move.m_tosq))
		{
		/* square is attacked, find minimal attacker */

		bb_and3(atbbv[ocr_move.m_tosq], c0bbv[c_b], gp_bb);
		ocr_move.m_frcp = local.rbv[ocr_move.m_frsq = MinValueSqGP()];

		/* fetch target piece */

		ocr_move.m_tocp = local.rbv[ocr_move.m_tosq];

		/* test attacker/defender exchange suitablity */

		if (bb_tstnotsq(acbbv[c_w], ocr_move.m_tosq) ||
			(xcpvalv[ocr_move.m_frcp] <= xcpvalv[ocr_move.m_tocp]))
			{
			/* obvious capture response exists; clear flags */

			ocr_move.m_flag = 0;

			/* check for pawn promotion */

			if ((ocr_move.m_frcp == cp_bp) &&
				(map_rank(ocr_move.m_tosq) == rank_1))
				ocr_move.m_scmv = scmv_ppq;
			else
				ocr_move.m_scmv = scmv_reg;

			/* clear remaining items */

			ocr_move.m_eval = ocr_move.m_prel = cpev_bust;
			ocr_move.m_cptr = ocr_move.m_dptr = NULL;

			/* set return result */

			dmptr = &ocr_move;
			}
		else
			{
			/* improper capture */

			dmptr = NULL;
			};
		}
	else
		{
		/* square not attacked, set null result */

		dmptr = NULL;
		};
	};

return (dmptr);
}

/*--> BestCaptureGain: estimate of best possible capture for a position */
nonstatic
cpevT
BestCaptureGain(void)
{
cpevT gain, pot_gain;
bbT p7_bb;
fileT epsq_file;

/* calculate passive attacked pieces */

if (pasc == c_w)
	{
	bb_and3(acbbv[c_b], c0bbv[c_w], gp_bb);
	}
else
	{
	bb_and3(acbbv[c_w], c0bbv[c_b], gp_bb);
	};

/* examine passive attacked pieces */

if (bb_tst(gp_bb))
	gain = cpvalv[local.rbv[MaxValueSqGP()]];
else
	gain = 0;

/* examine pawn promotions */

if (actc == c_w)
	{
	/* locate seventh rank white pawns */

	bb_and3(cpbbv[cp_wp], r0bbv[rank_7], p7_bb);
	if (bb_tst(p7_bb))
		{
		/* move pawns straight */

		gp_bb = p7_bb;
		BitBoardShift(&gp_bb, dx_1);
		if (bb_tstnotand(gp_bb, apmbb))
			if (gain < (pval_q - pval_p))
				gain = (pval_q - pval_p);

		/* move pawns to kingside (capture) */

		gp_bb = p7_bb;
		BitBoardShift(&gp_bb, dx_4);
		if (bb_tstand(c0bbv[c_b], gp_bb))
			{
			pot_gain =
				(pval_q - pval_p) + cpvalv[local.rbv[MaxValueSqGP()]];
			if (gain < pot_gain)
				gain = pot_gain;
			};

		/* move pawns to queenside (capture) */

		gp_bb = p7_bb;
		BitBoardShift(&gp_bb, dx_5);
		if (bb_tstand(c0bbv[c_b], gp_bb))
			{
			pot_gain =
				(pval_q - pval_p) + cpvalv[local.rbv[MaxValueSqGP()]];
			if (gain < pot_gain)
				gain = pot_gain;
			};
		};
	}
else
	{
	/* locate second (seventh) rank black pawns */

	bb_and3(cpbbv[cp_bp], r0bbv[rank_2], p7_bb);
	if (bb_tst(p7_bb))
		{
		/* move pawns straight */

		gp_bb = p7_bb;
		BitBoardShift(&gp_bb, dx_3);
		if (bb_tstnotand(gp_bb, apmbb))
			if (gain < (pval_q - pval_p))
				gain = (pval_q - pval_p);

		/* move pawns to kingside (capture) */

		gp_bb = p7_bb;
		BitBoardShift(&gp_bb, dx_7);
		if (bb_tstand(c0bbv[c_w], gp_bb))
			{
			pot_gain =
				(pval_q - pval_p) + cpvalv[local.rbv[MaxValueSqGP()]];
			if (gain < pot_gain)
				gain = pot_gain;
			};

		/* move pawns to queenside (capture) */

		gp_bb = p7_bb;
		BitBoardShift(&gp_bb, dx_6);
		if (bb_tstand(c0bbv[c_w], gp_bb))
			{
			pot_gain =
				(pval_q - pval_p) + cpvalv[local.rbv[MaxValueSqGP()]];
			if (gain < pot_gain)
				gain = pot_gain;
			};
		};
	};

/* ep capture */

if (gain == 0)
	if (envn.envn_epsq != sq_nil)
		{
		epsq_file = map_file(envn.envn_epsq);
		if (actc == c_w)
			{
			if (epsq_file > file_a)
				if (local.rbv[envn.envn_epsq + dv_6] == cp_wp)
					gain = pval_p;
			if (epsq_file < file_h)
				if (local.rbv[envn.envn_epsq + dv_7] == cp_wp)
					gain = pval_p;
			}
		else
			{
			if (epsq_file > file_a)
				if (local.rbv[envn.envn_epsq + dv_5] == cp_bp)
					gain = pval_p;
			if (epsq_file < file_h)
				if (local.rbv[envn.envn_epsq + dv_4] == cp_bp)
					gain = pval_p;
			};
		};

return (gain);
}

/*--> BestCaptureGainMove: estimate of best possible capture for a move */
nonstatic
cpevT
BestCaptureGainMove(mptrT mptr)
{
cpevT gain;
cpT cp_gain;

/* process capture gain */

if ((cp_gain = mptr->m_tocp) == cp_v0)
	gain = 0;
else
	gain = cpvalv[cp_gain];

/* process special case gain */

switch (mptr->m_scmv)
	{
	case scmv_reg:
		break;

	case scmv_epc:
		gain = pval_p;
		break;

	case scmv_cks:
		break;

	case scmv_cqs:
		break;

	case scmv_ppn:
		gain += (pval_n - pval_p);
		break;

	case scmv_ppb:
		gain += (pval_b - pval_p);
		break;

	case scmv_ppr:
		gain += (pval_r - pval_p);
		break;

	case scmv_ppq:
		gain += (pval_q - pval_p);
		break;

	default:
		SwitchFault("BestCaptureGainMove");
		break;
	};

return (gain);
}

/*--> TaperScore: taper an evaluation towards a draw */
nonstatic
cpevT
TaperScore(cpevT score)
{
cpevT newscore;

/* process based on distance to last capture or pawn move */

if ((envn.envn_hmvc == 0) || (score == cpev_draw))
	newscore = score;
else
	if (envn.envn_hmvc < hmvcL)
		newscore = (((liT) score) * (hmvcL - envn.envn_hmvc)) / hmvcL;
	else
		newscore = cpev_draw;

return (newscore);
}

/*--> BogusScore: check for bogus score */
nonstatic
siT
BogusScore(cpevT cpev)
{
siT flag;

flag = 0;

if (cpev == cpev_wrck)
	flag = 1;
else
	if (ct_mate(cpev))
		{
		if (!(ply & bit))
			if (cpev & bit)
				flag = 1;
		}
	else
		if (ct_wump(cpev))
			{
			if (!(ply & bit))
				if (!(cpev & bit))
					flag = 1;
			};

return (flag);
}

/*<<< assist.c: EOF */
