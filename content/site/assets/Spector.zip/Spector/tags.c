/*>>> tags.c: tag pair routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "file.h"
#include "memutil.h"
#include "print.h"
#include "tags.h"

/*--> TagCount: count tags */
nonstatic
siT
TagCount(void)
{
siT count;
tagptrT tagptr;

count = 0;
tagptr = head_tagptr;
while (tagptr != NULL)
	{
	count++;
	tagptr = tagptr->tag_next;
	};

return (count);
}

/*--> TagFormat: format an allocated tag display including newline */
nonstatic
charptrT
TagFormat(tagptrT tagptr)
{
charptrT s;

/* start with opening bracket and tag name */

s = StringGrab("[");
s = StringAppendStr(s, tagptr->tag_name);

/* process value */

if (tagptr->tag_value != NULL)
		{
		s = StringAppendChar(s, ' ');
		s = StringAppendChar(s, '"');
		s = StringAppendStr(s, tagptr->tag_value);
		s = StringAppendChar(s, '"');
		};

/* closing bracket */

s = StringAppendStr(s, "]\n");

return (s);
}

/*--> TagFilePrint: out a single tag value to a file */
nonstatic
void
TagFilePrint(fptrT fptr, tagptrT tagptr)
{
charptrT s;

s = TagFormat(tagptr);
GateStr(fptr, s);
MemoryFree(s);

return;
}

/*--> TagFilePrintReserved: output a reserved tag value to a file */
nonstatic
void
TagFilePrintReserved(fptrT fptr, rsvtagT rsvtag)
{
TagFilePrint(fptr, TagLocate(rsvtagv[rsvtag]));

return;
}

/*--> TagFilePrintAll: output all the tag values to a file */
nonstatic
void
TagFilePrintAll(fptrT fptr)
{
tagptrT tagptr;

tagptr = head_tagptr;
while (tagptr != NULL)
	{
	TagFilePrint(fptr, tagptr);
	tagptr = tagptr->tag_next;
	};

return;
}

/*--> TagCreate: create and assign storage for a new tag */
nonstatic
tagptrT
TagCreate(charptrT name, tagfT tagf)
{
tagptrT tagptr;

tagptr = (tagptrT) MemoryGrab(sizeof(tagT));
tagptr->tag_name = StringGrab(name);
tagptr->tag_value = NULL;
tagptr->tag_prev = tagptr->tag_next = NULL;
tagptr->tag_flag = tagf;

return (tagptr);
}

/*--> TagLocate: locate the indicated tag record by name */
nonstatic
tagptrT
TagLocate(charptrT name)
{
tagptrT tagptr0, tagptr1;

tagptr0 = head_tagptr;
tagptr1 = NULL;
while ((tagptr0 != NULL) && (tagptr1 == NULL))
	if (strcmp(tagptr0->tag_name, name) == 0)
		tagptr1 = tagptr0;
	else
		tagptr0 = tagptr0->tag_next;

return (tagptr1);
}

/*--> TagAssign: assign a value to the indicated tag record */
nonstatic
void
TagAssign(tagptrT tagptr, charptrT value)
{
if (tagptr->tag_value != NULL)
	MemoryFree(tagptr->tag_value);
tagptr->tag_value = NULL;

if (value != NULL)
	tagptr->tag_value = StringGrab(value);

return;
}

/*--> TagAssignReserved: assign a value to a reserved tag record */
nonstatic
void
TagAssignReserved(rsvtagT rsvtag, charptrT value)
{
tagptrT tagptr;

tagptr = TagLocate(rsvtagv[rsvtag]);

/* assume that value is preallocated */

TagAssign(tagptr, value);

return;
}

/*--> TagDelete: delete the indicated tag record */
nonstatic
void
TagDelete(tagptrT tagptr)
{
if (tagptr->tag_prev == NULL)
	head_tagptr = tagptr->tag_next;
else
	tagptr->tag_prev->tag_next = tagptr->tag_next;

if (tagptr->tag_next == NULL)
	tail_tagptr = tagptr->tag_prev;
else
	tagptr->tag_next->tag_prev = tagptr->tag_prev;

MemoryFree(tagptr->tag_name);
if (tagptr->tag_value != NULL)
	MemoryFree(tagptr->tag_value);

MemoryFree(tagptr);

return;
}

/*--> TagInsert: insert the indicated tag record */
nonstatic
void
TagInsert(tagptrT tagptr)
{
/* insert at end of list */

if (head_tagptr == NULL)
	{
	head_tagptr = tagptr;
	tagptr->tag_prev = NULL;
	}
else
	{
	tail_tagptr->tag_next = tagptr;
	tagptr->tag_prev = tail_tagptr;
	};
tagptr->tag_next = NULL;
tail_tagptr = tagptr;

return;
}

/*--> TagInitTag: initialize a tag */
static
void
TagInitTag(rsvtagT rsvtag, charptrT name, tagfT tagf)
{
rsvtagv[rsvtag] = name;
TagInsert(TagCreate(rsvtagv[rsvtag], tagf));

return;
}

/*--> TagClear: clear a single tag value */
nonstatic
void
TagClear(tagptrT tagptr)
{
TagAssign(tagptr, "");

return;
}

/*--> TagClearAll: clear all tag values */
nonstatic
void
TagClearAll(void)
{
tagptrT tagptr;

tagptr = head_tagptr;
while (tagptr != NULL)
	{
	TagClear(tagptr);
	tagptr = tagptr->tag_next;
	};

return;
}

/*--> TagInit: one time initialization for tag subsystem */
nonstatic
void
TagInit(void)
{
/* clear the head and tail pointers */

head_tagptr = tail_tagptr = NULL;

/* insert the reserved tags */

TagInitTag(rsvtag_event,   "Event",   (tagf_perm));
TagInitTag(rsvtag_site,    "Site",    (tagf_perm));
TagInitTag(rsvtag_date,    "Date",    (tagf_estm | tagf_perm));
TagInitTag(rsvtag_round,   "Round",   (tagf_perm));
TagInitTag(rsvtag_white,   "White",   (tagf_crep | tagf_perm));
TagInitTag(rsvtag_black,   "Black",   (tagf_crep | tagf_perm));
TagInitTag(rsvtag_result,  "Result",  (tagf_estm | tagf_perm));

return;
}

/*--> TagTerm: one time termination for tag subsystem */
nonstatic
void
TagTerm(void)
{
/* release tag storage */

while (head_tagptr != NULL)
	TagDelete(head_tagptr);

return;
}

/*<<< tags.c: EOF */
