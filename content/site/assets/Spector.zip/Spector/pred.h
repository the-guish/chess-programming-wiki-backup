/*>>> pred.h: subprogram prototypes for pred.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT CastlingFlankOkay(flankT flank);
siT LoneKingMate(void);

/*<<< pred.h: EOF */
