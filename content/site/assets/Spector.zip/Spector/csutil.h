/*>>> csutil.h: subprogram prototypes for csutil.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CSInit(void);
void CSTerm(void);
void CSConceptNotationRelease(cnptrT cnptr);
void CSExpandNode(sptrT sptr);

/*<<< csutil.h: EOF */
