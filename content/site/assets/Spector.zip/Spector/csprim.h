/*>>> csprim.h: subprogram prototypes for csprim.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CSPrimitiveNone(sptrT sptr);
void CSPrimitiveActive(sptrT sptr);
void CSPrimitiveActiveking(sptrT sptr);
void CSPrimitiveAdverse(sptrT sptr);
void CSPrimitiveAttacked(sptrT sptr);
void CSPrimitiveAttacks(sptrT sptr);
void CSPrimitiveCheckmated(sptrT sptr);
void CSPrimitiveConnected(sptrT sptr);
void CSPrimitiveDefended(sptrT sptr);
void CSPrimitiveDefends(sptrT sptr);
void CSPrimitiveDiscover(sptrT sptr);
void CSPrimitiveDrawn(sptrT sptr);
void CSPrimitiveExchangable(sptrT sptr);
void CSPrimitiveExists(sptrT sptr);
void CSPrimitiveFiftymove(sptrT sptr);
void CSPrimitiveHung(sptrT sptr);
void CSPrimitiveIndirect(sptrT sptr);
void CSPrimitiveJeopardy(sptrT sptr);
void CSPrimitiveMove(sptrT sptr);
void CSPrimitiveOutofwood(sptrT sptr);
void CSPrimitivePassive(sptrT sptr);
void CSPrimitivePassiveking(sptrT sptr);
void CSPrimitiveProtected(sptrT sptr);
void CSPrimitiveRepeated(sptrT sptr);
void CSPrimitiveStalemated(sptrT sptr);
void CSPrimitiveThirdrepeat(sptrT sptr);
void CSPrimitiveUnconnected(sptrT sptr);

/*<<< csprim.h: EOF */
