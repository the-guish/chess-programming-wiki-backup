/*>>> commdefs.h: command definitions */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* input token limit */

#define itL (tL / 2)

/* input parameter limit */

#define ipL itL

/* parameter classes */

typedef siT parcT;
#define parcL 12

#define parc_none  0 /* none */
#define parc_c     1 /* color */
#define parc_cai   2 /* castling availability indicator */
#define parc_cpsq  3 /* color-piece-file-rank */
#define parc_lang  4 /* language */
#define parc_lint  5 /* long integer */
#define parc_nm    6 /* notation mode */
#define parc_optn  7 /* option identifier */
#define parc_sint  8 /* short integer */
#define parc_sq    9 /* square */
#define parc_str  10 /* string */
#define parc_strt 11 /* strategy */

/* the input parameter union */

typedef union ipU
    {
    cT       ip_c;    /* color */
    castT    ip_cai;  /* castling availability indicator */
    cpsqT    ip_cpsq; /* color-piece-file-rank */
    langT    ip_lang; /* language */
    liT      ip_lint; /* long integer */
    nmT      ip_nm;   /* notation mode */
    optnT    ip_optn; /* option identifier */
    siT      ip_sint; /* short integer */
    sqT      ip_sq;   /* square */
    charptrT ip_str;  /* string */
    strtT    ip_strt; /* strategy */
    } ipT, *ipptrT;

/* command name length */

#define commnameL 4

/* the command type */

typedef siT commT;
#define commL 121

#define comm_afgs   0 /* append file: game status */
#define comm_beep   1 /* emit single beep */
#define comm_call   2 /* call command subfile */
#define comm_cfdo   3 /* close file: dribble output */
#define comm_comm   4 /* communicate with Duplex mediator */
#define comm_cpic   5 /* command processor: interproccess communication */
#define comm_cplb   6 /* command processor: legacy book */
#define comm_cpmb   7 /* command processor: multibook */
#define comm_cptb   8 /* command processor: tablebase subsystem */
#define comm_cvca   9 /* clear value: castling availability */
#define comm_cvcb  10 /* clear value: chessboard */
#define comm_cvcc  11 /* clear value: chess clock */
#define comm_cvcf  12 /* clear value: clock flag */
#define comm_cvep  13 /* clear value: en passant square */
#define comm_cvgt  14 /* clear value: game termination code */
#define comm_cvop  15 /* clear value: option */
#define comm_cvsq  16 /* clear value: squares */
#define comm_cvtf  17 /* clear value: tag fields */
#define comm_desc  18 /* describe position */
#define comm_dvas  19 /* display value: hash address and signature */
#define comm_dvcb  20 /* display value: chessboard */
#define comm_dvcr  21 /* display value: concise report */
#define comm_dvct  22 /* display value: countdown timer */
#define comm_dver  23 /* display value: event report */
#define comm_dvfe  24 /* display value: Forsyth-Edwards notation */
#define comm_dvlm  25 /* display value: legal moves */
#define comm_dvnc  26 /* display value: node countdown */
#define comm_dvpe  27 /* display value: preliminary evaluations */
#define comm_dvpm  28 /* display value: predicted move */
#define comm_dvpv  29 /* display value: predicted variation */
#define comm_dvss  30 /* display value: search strategies */
#define comm_dvtc  31 /* display value: time control */
#define comm_dvte  32 /* display value: tag environment */
#define comm_dvtf  33 /* display value: tag fields */
#define comm_dvts  34 /* display value: timestamp */
#define comm_dvtt  35 /* display value: transposition table order */
#define comm_echo  36 /* echo arguments */
#define comm_enum  37 /* enumerate ply descendants */
#define comm_eval  38 /* display evaluation of current position */
#define comm_evca  39 /* estimate value: castling availability */
#define comm_evte  40 /* estimate value: tag environment */
#define comm_evtf  41 /* estimate value: tag fields */
#define comm_exit  42 /* exit program */
#define comm_expm  43 /* execute predicted move */
#define comm_expv  44 /* execute predicted variation */
#define comm_exsm  45 /* execute supplied move */
#define comm_exsv  46 /* execute supplied variation */
#define comm_game  47 /* calculate and play to end of game */
#define comm_help  48 /* display help list */
#define comm_hint  49 /* offer hint */
#define comm_info  50 /* display program identification information */
#define comm_jump  51 /* exit/transfer */
#define comm_lfer  52 /* load file: event report */
#define comm_lfgc  53 /* load file: game code */
#define comm_lfkb  54 /* load file: knowledge base */
#define comm_lfms  55 /* load file: move sequence */
#define comm_lfpd  56 /* load file: position data */
#define comm_logo  57 /* display program logo */
#define comm_mark  58 /* report (and establish) time mark */
#define comm_mate  59 /* search for mate in -n- moves */
#define comm_newg  60 /* new game */
#define comm_noop  61 /* no operation */
#define comm_ofdo  62 /* open file: dribble output */
#define comm_pfdn  63 /* process file: EPD data normalization */
#define comm_pflc  64 /* process file: EPD locate cooks */
#define comm_pfms  65 /* process file: EPD mate scan */
#define comm_pfpa  66 /* process file: EPD position analysis */
#define comm_pfro  67 /* process file: EPD remove operations */
#define comm_pfts  68 /* process file: EPD target search */
#define comm_pgos  69 /* play game: oracular sequence */
#define comm_play  70 /* play one or more moves */
#define comm_pond  71 /* ponder search */
#define comm_rtmv  72 /* retract one or more moves */
#define comm_rtrn  73 /* return from command subfile */
#define comm_rvca  74 /* reset value: castling availability */
#define comm_rvcc  75 /* reset value: chess clock */
#define comm_rvct  76 /* reset value: countdown timer */
#define comm_rvht  77 /* reset value: hash table information */
#define comm_rvnc  78 /* reset value: node countdown */
#define comm_rvop  79 /* reset value: option set */
#define comm_rvss  80 /* reset value: search strategies */
#define comm_rvtc  81 /* reset value: time control */
#define comm_scon  82 /* set console configuration */
#define comm_sfcr  83 /* save file: concise report */
#define comm_sfer  84 /* save file: event report */
#define comm_sfgc  85 /* save file: game code */
#define comm_sfkb  86 /* save file: knowledge base */
#define comm_sfms  87 /* save file: move sequence */
#define comm_sfpd  88 /* save file: position data */
#define comm_sort  89 /* sort text file */
#define comm_srch  90 /* search for a move from a target list */
#define comm_stat  91 /* status report (includes available move list) */
#define comm_svac  92 /* set value: active color */
#define comm_svca  93 /* set value: castling availability */
#define comm_svcc  94 /* set value: chess clock */
#define comm_svcf  95 /* set value: clock flag */
#define comm_svct  96 /* set value: countdown timer */
#define comm_svep  97 /* set value: en passant square */
#define comm_svfe  98 /* set value: Forsyth-Edwards notation */
#define comm_svhc  99 /* set value: halfmove clock */
#define comm_svko 100 /* set value: kings only position */
#define comm_svmn 101 /* set value: move number */
#define comm_svnc 102 /* set value: node countdown */
#define comm_svnl 103 /* set value: notational language */
#define comm_svnm 104 /* set value: notation mode */
#define comm_svop 105 /* set value: option */
#define comm_svpl 106 /* set value: ply limit */
#define comm_svsq 107 /* set value: square */
#define comm_svss 108 /* set value: search strategies */
#define comm_svtc 109 /* set value: time control */
#define comm_svtf 110 /* set value: tag fields */
#define comm_svtt 111 /* set value: transposition table order */
#define comm_swap 112 /* swap colors */
#define comm_syst 113 /* execute system command */
#define comm_test 114 /* testing */
#define comm_tfgc 115 /* translate file: games to PGC */
#define comm_tfge 116 /* translate file: games to EPD */
#define comm_tfgg 117 /* translate file: games to PGN */
#define comm_tfgh 118 /* translate file: games to hex */
#define comm_tfgv 119 /* translate file: games to variations */
#define comm_trac 120 /* general trace (freq|trab|trpv|trst|trtt|verb) */

/* the command record type */

typedef struct crS
    {
    frvptrT  cr_func; /* command function */
    charptrT cr_help; /* command help */
    siT      cr_maxc; /* maximum argument count */
    siT      cr_minc; /* minimum argument count */
    charptrT cr_name; /* command name */
    parcT    cr_parc; /* parameter class */
    } crT;

/*<<< commdefs.h: EOF */
