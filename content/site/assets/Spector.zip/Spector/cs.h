/*>>> cs.h: subprogram prototypes for cs.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

mptrT CSSearch(void);

/*<<< cs.h: EOF */
