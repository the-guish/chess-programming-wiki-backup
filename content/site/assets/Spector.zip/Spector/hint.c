/*>>> hint.c: move hint routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "hint.h"
#include "moveset.h"
#include "predvar.h"
#include "prelim.h"
#include "print.h"
#include "stat.h"
#include "sysutil.h"

/*--> FindHint: find a hint in the root moveset */
nonstatic
mptrT
FindHint(void)
{
mptrT mptr, mptr1;
siT i, count;

/* check game status to determine if a hint is appropriate */

if (!GameStatusNormal(root_sptr))
	mptr = NULL;
else
	{
	/* check if a predicted variation exists */

	if (PVarELength() > 0)
		mptr = FindMoveNF(PVarEFirstMoveRef(), root_sptr, "FindHint");
	else
		{
		/* no predicted variation, perform quick evaluations */

		PreliminaryEvaluationsPlain(root_sptr);
		mptr = NULL;
		mptr1 = root_sptr->s_mbase;
		count = root_sptr->s_count;
		for (i = 0; i < count; i++)
			{
			if ((mptr == NULL) || (mptr->m_prel < mptr1->m_prel))
				mptr = mptr1;
			mptr1++;
			};

		/* adjust the predicted variation for the quick hint */

		PVarESetHint(mptr);
		};
	};

return (mptr);
}

/*--> InteractiveHint: offer a move hint */
nonstatic
void
InteractiveHint(void)
{
gsT gs;
mptrT mptr;

/* check game status to determine if a hint is appropriate */

if ((gs = GameStatus(root_sptr)) != gs_norm)
	PrStrGameStatusNL("Can't offer hint: ", gs);
else
	{
	/* find a hint */

	mptr = FindHint();

	/* test */

	if (mptr == NULL)
		Fault("InteractiveHint");

	/* print hint */

	PrStr("Try: ");
	PrCondExpandedSAN(mptr);
	PrNL();
	};

return;
}

/*<<< hint.c: EOF */
