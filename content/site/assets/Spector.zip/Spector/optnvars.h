/*>>> optnvars.h: option variable references */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/* option strings, helps, and values */

extern charptrT optnstrv[optnL];
extern charptrT optnhlpv[optnL];
extern siT optnv[optnL];

/*<<< optnvars.h: EOF */
