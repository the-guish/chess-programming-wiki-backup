/*>>> format.h: subprogram prototypes for format.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

/*<<< format.h: EOF */
