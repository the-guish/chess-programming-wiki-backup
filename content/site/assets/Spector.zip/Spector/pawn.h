/*>>> pawn.h: subprogram prototypes for pawn.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void PawnTTReset(void);
void PawnTTInit(void);
void PawnTTTerm(void);
void PawnTTWhiteSingleton(sqT sq);
void PawnTTBlackSingleton(sqT sq);
void PawnTTCreate(void);
mpevT PawnTTFetchEvaluation(void);

/*<<< pawn.h: EOF */
