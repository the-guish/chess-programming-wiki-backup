/*>>> create.c: database variable creation for a new position */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "bbmacs.h"

#include "attack.h"
#include "bb.h"
#include "create.h"
#include "gt.h"
#include "hist.h"
#include "moveset.h"
#include "pawn.h"
#include "predvar.h"
#include "setsq.h"
#include "tags.h"
#include "tt.h"
#include "util.h"

/*--> CreateMaterial: count material and post in globals */
static
void
CreateMaterial(void)
{
cpT cp;

/* clear material evaluations */

envn.envn_mcpv[c_w] = envn.envn_mcpv[c_b] = 0;

/* sum white material components */

for (cp = cp_wp; cp <= cp_wk; cp++)
	envn.envn_mcpv[c_w] += cpvalv[cp] * bb_count(cpbbv[cp]);

/* sum black material components */

for (cp = cp_bp; cp <= cp_bk; cp++)
	envn.envn_mcpv[c_b] += cpvalv[cp] * bb_count(cpbbv[cp]);

return;
}

/*--> CreateDatabase: create database variables from the board (ply zero) */
static
void
CreateDatabase(void)
{
cpT cp;
sqT sq;

/* assign ply zero colors */

p0actc = actc;
p0pasc = pasc;

/* initialize the color bitboards to an empty board */

bb_clr(c0bbv[c_w]);
bb_clr(c0bbv[c_b]);

/* initialize the color-piece bitboards to an empty board */

for (cp = cp_wp; cp <= cp_bk; cp++)
	bb_clr(cpbbv[cp]);

/* initialize the all pieces merged bitboard for an empty board */

bb_clr(apmbb);

/* set local board vacant */

for (sq = sq_a1; sq <= sq_h8; sq++)
	local.rbv[sq] = cp_v0;

/* set up the location bitboards from the main board (this sets -local-) */

for (sq = sq_a1; sq <= sq_h8; sq++)
	SqSet(board.rbv[sq], sq);

/* create the material sums */

CreateMaterial();

/* create the main and pawn hash table index/position signatures */

TTCreate();
PawnTTCreate();

/* set the attack bitboards */

AttackSet();

return;
}

/*--> CreateAll: create database and tree */
nonstatic
void
CreateAll(void)
{
CreateDatabase();
TreeNew();

return;
}

/*--> CreateEnvironment: create/init history, database, and best variation */
nonstatic
void
CreateEnvironment(void)
{
/* clear all game history (preventing illegal move retractions) */

HistoryClear();

/* create the database and the tree */

CreateAll();

/* set the game termination code */

gtc = gtc_none;
GTCAutoSet();

/* clear any predicted variation information */

PVarEClear();

return;
}

/*--> CreateSetUp: create database and tree for position set-up */
nonstatic
void
CreateSetUp(void)
{
/* mark position as being set-up (ineligible for book scan) */

setup = 1;

/* clear main and pawn hash table information */

TTReset();
PawnTTReset();

/* create the environment */

CreateEnvironment();

return;
}

/*<<< create.c: EOF */
