/*>>> select.c: program move selection */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "assist.h"
#include "bookscan.h"
#include "clock.h"
#include "cs.h"
#include "hic.h"
#include "mu.h"
#include "moveset.h"
#include "oracle.h"
#include "pcstat.h"
#include "play.h"
#include "poll.h"
#include "prelude.h"
#include "print.h"
#include "pvs.h"
#include "select.h"
#include "sysutil.h"
#include "ts.h"
#include "voice.h"

/*--> SelectMove: select a move for the program */
nonstatic
void
SelectMove(void)
{
mptrT mptr;
siT flag, count, i;

/* set up search success flag */

flag = 0;

/* initialize clock time control */

ClockSelectStart();

/* set the default expectation */

expectation = cpev_draw;

/* initialize the statistics scalars */

search_start_node = count_node;
search_start_time = time(NULL);

/* clear the search termination reason code */

strc = strc_none;

/* clear the search abort indicator */

search_abort = 0;

/* initialize interrupt processing for the search */

PollSelectInit();

/* set up for top level moveset */

SetUpRootMove();
count = root_sptr->s_count;

/* initialize the "best move so far" pointer in the root moveset */

root_sptr->s_mbest = NULL;

/* [pre-search: checkmating] check if a mating move is available */

if (!flag)
	{
	i = 0;
	mptr = root_sptr->s_mbase;
	while (!flag && (i < count))
		if (mptr->m_flag & mf_mate)
			{
			flag = 1;
			strc = strc_mate;
			root_sptr->s_mbest = mptr;
			expectation = synth_mate(1);
			if (optnv[optn_verb] && ponder_trace)
				PrLine("A checkmating move is selected.");
			}
		else
			{
			mptr++;
			i++;
			};
	};

/* [pre-search: singleton] check if at only one legal move is available */

if (!flag && (count == 1))
	{
	root_sptr->s_mbest = root_sptr->s_mbase;
	strc = strc_sing;
	flag = 1;
	if (optnv[optn_verb] && ponder_trace)
		PrLine("Only one move is available.");
	};

/* [pre-search: lookup] check for an oracular move */

if (!flag)
	if (!optnv[optn_nocm])
		if ((mptr = OracularSearch()) != NULL)
			{
			flag = 1;
			strc = strc_cert;
			root_sptr->s_mbest = FindMoveNF(mptr, root_sptr,
				"SelectMove");
			if (optnv[optn_verb] && ponder_trace)
				PrLine("An oracular move is selected.");
			};

/* [pre-search: lookup] check for an HIC book move */

if (!flag)
	if ((histn < plyL) && !optnv[optn_nbms])
		if ((mptr = HICBookSearch()) != NULL)
			{
			flag = 1;
			strc = strc_book;
			root_sptr->s_mbest =
				FindMoveNF(mptr, root_sptr, "SelectMove");
			if (optnv[optn_verb] && ponder_trace)
				PrLine("An HIC opening book move is selected.");
			};

/* [pre-search: lookup] check for a list book move */

if (!flag)
	if (!setup && (histn < bkmcdL) && !optnv[optn_nbms])
		if ((mptr = ListBookSearch()) != NULL)
			{
			flag = 1;
			strc = strc_book;
			root_sptr->s_mbest =
				FindMoveNF(mptr, root_sptr, "SelectMove");
			if (optnv[optn_verb] && ponder_trace)
				PrLine("An list opening book move is selected.");
			};

/* [pre-search: mate in 2] check for a mate in two */

if (!flag)
	if ((mptr = TSMate(2)) != NULL)
		{
		flag = 1;
		strc = strc_mate;
		root_sptr->s_mbest = FindMoveNF(mptr, root_sptr, "PVSSearch");
		expectation = synth_mate(2);
		if (optnv[optn_verb] && ponder_trace)
			PrLine("A mate in two move is selected.");
		};

/* [pre-search: mate in 3] check for a mate in three (active checks) */

if (!flag)
	if ((mptr = TSMateACO(3)) != NULL)
		{
		flag = 1;
		strc = strc_mate;
		root_sptr->s_mbest = FindMoveNF(mptr, root_sptr, "PVSSearch");
		expectation = synth_mate(3);
		if (optnv[optn_verb] && ponder_trace)
			PrLine("An obvious mate in three move is selected.");
		};

/* If no move found in the pre-search, try indicated strategy */

if (!flag)
	{
	/* perform common pre-search operations */

	Prelude();

	/* search according to indcated strategy */

	switch (strtv[p0actc])
		{
		case strt_knowbs:
			/* knowledge base */

			if ((mptr = CSSearch()) != NULL)
				{
				flag = 1;
				strc = strc_full;
				root_sptr->s_mbest = FindMoveNF(mptr, root_sptr,
					"SelectMove");
				if (optnv[optn_verb] && ponder_trace)
					PrLine("A knowledge base search move is selected.");
				};
			break;

		case strt_privar:
			/* principal variation search */

			if ((mptr = PVSSearch()) != NULL)
				{
				flag = 1;
				strc = strc_full;
				root_sptr->s_mbest = FindMoveNF(mptr, root_sptr,
					"SelectMove");
				if (optnv[optn_verb] && ponder_trace)
					PrLine( "A PVS move is selected.");
				};
			break;

		case strt_random:
			/* random selection */

			mptr = root_sptr->s_mbase + (rand() % root_sptr->s_count);
			flag = 1;
			strc = strc_full;
			root_sptr->s_mbest = FindMoveNF(mptr, root_sptr,
				"SelectMove");
			if (optnv[optn_verb] && ponder_trace)
				PrLine("A random move is selected.");
			break;

		case strt_testds:
			/* test developmental search */

			if ((mptr = TSSearch()) != NULL)
				{
				flag = 1;
				strc = strc_full;
				root_sptr->s_mbest = FindMoveNF(mptr, root_sptr,
					"SelectMove");
				if (optnv[optn_verb] && ponder_trace)
					PrLine("A test developmental search move is selected.");
				};
			break;

		default:
			SwitchFault("SelectMove");
			break;
		};

	/* perform common post-search operations */

	Postlude();
	};

/* terminate interrupt processing for the search */

PollSelectTerm();

/* process the report node frequency option */

if (optnv[optn_freq] && ponder_trace)
	PrSearchFrequencyReport(search_start_node, search_start_time);

/* if necessary, report search abort */

if (search_abort && optnv[optn_verb] && ponder_trace)
	PrLine("*** search abort");

/* process search termination trace */

if (optnv[optn_trst] && ponder_trace)
	{
	PrTrace("ST");
	(void) sprintf(stv, "[%02hd] %s", strc, strcstrv[strc]);
	PrSTVNL();
	};

/* process search failure */

if (!flag)
	Diagnose("SelectMove: search failure");

/* set expectation if a mating move is located */

if (flag && (root_sptr->s_mbest->m_flag & mf_mate))
	expectation = synth_mate(1);

/* process forced mate announcement */

if (!optnv[optn_nafm] && ponder_trace)
	if (ct_mate(expectation))
		{
		i = MateDist(expectation);
		PrStr("Located mate in ");
		PrCondOrdSI(i);
		if (i == 1)
			PrLine(" move.");
		else
			PrLine(" moves.");
		if (optnv[optn_vsyn])
			VSSpeakMate(i);
		};

return;
}

/*--> ProgramMove: select and play a move for the program */
nonstatic
void
ProgramMove(void)
{
/* search only if a null result was returned for the ponder search */

if (ponder_result)
	ponder_result = 0;
else
	SelectMove();

/* process the beep reply option */

if (optnv[optn_brep])
	Beep(1);

/* process the adjustment for move entry time overhead */

if (optnv[optn_amet])
	ClockAMET();

/* play the program move */

PlayMove(root_sptr->s_mbest);

/* process the auto board display and the auto status display options */

if (optnv[optn_adps])
	ProcessSTAT();
else
	if (optnv[optn_adcb])
		PrBoard(&board);

return;
}

/*<<< select.c: EOF */
