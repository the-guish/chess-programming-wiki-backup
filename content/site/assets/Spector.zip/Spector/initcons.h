/*>>> initcons.h: subprogram prototypes for initcons.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void InitConstants(void);

/*<<< initcons.h: EOF */
