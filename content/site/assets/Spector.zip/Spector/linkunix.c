/*>>> linkunix.c: external player linkage utilities (Unix) */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "linkunix.h"
#include "print.h"

/**** Locals */

#if (os_unix)
#endif

/**** Functions */

#if (os_unix)
/*--> LinkUnixGet: get bytes from input link */
nonstatic
siT
LinkUnixGet(channelT channel, byteptrT bptr, liT length)
{
siT flag;

flag = 0;
PrWarning("LinkUnixGet: not implemented");

return (flag);
}

/*--> LinkUnixPut: put bytes to output link */
nonstatic
siT
LinkUnixPut(channelT channel, byteptrT bptr, liT length)
{
siT flag;

flag = 0;
PrWarning("LinkUnixStat: not implemented");

return (flag);
}

/*--> LinkUnixStat: return character available count */
nonstatic
liT
LinkUnixStat(channelT channel)
{
liT count;

count = -1;
PrWarning("LinkUnixStat: not implemented");

return (count);
}

/*--> LinkUnixOpen: open external link */
nonstatic
siT
LinkUnixOpen(channelT channel)
{
siT flag;

flag = 0;
PrWarning("LinkUnixOpen: not implemented");

return (flag);
}

/*--> LinkUnixClose: close external link */
nonstatic
siT
LinkUnixClose(channelT channel)
{
siT flag;

flag = 0;
PrWarning("LinkUnixClose: not implemented");

return (flag);
}

/*--> LinkUnixInit: one time Unix link initialization */
nonstatic
void
LinkUnixInit(void)
{

return;
}

/*--> LinkUnixTerm: one time Unix link termination */
nonstatic
void
LinkUnixTerm(void)
{

return;
}
#endif

/*<<< linkunix.c: EOF */
