/*>>> create.h: subprogram prototypes for create.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CreateAll(void);
void CreateEnvironment(void);
void CreateSetUp(void);

/*<<< create.h: EOF */
