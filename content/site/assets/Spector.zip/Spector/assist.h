/*>>> assist.h: subprogram prototypes for assist.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void SIDUpdate(void);
void MovePathTrace(void);
void PlyZeroTrace0(sptrT dsptr);
void PlyZeroTrace1(sptrT dsptr);
siT MateDist(cpevT score);
void RotatePlyZero(void);
void BestMoveTrace(void);
mptrT ObviousCaptureResponse(mptrT mptr);
cpevT BestCaptureGain(void);
cpevT BestCaptureGainMove(mptrT mptr);
cpevT TaperScore(cpevT score);
siT BogusScore(cpevT cpev);

/*<<< assist.h: EOF */
