/*>>> mpool.c: moveset pool routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "memutil.h"
#include "moveset.h"
#include "mpool.h"
#include "print.h"

/**** Locals */

/* moveset pool element */

/* free list anchor pointers */

static sptrT free_head_sptr;
static sptrT free_tail_sptr;

/* used list anchor pointers */

static sptrT used_head_sptr;
static sptrT used_tail_sptr;

/*--> MPoolAppendFree: append a record to the free list */
static
void
MPoolAppendFree(sptrT sptr)
{
if (free_tail_sptr == NULL)
	{
	free_head_sptr = sptr;
	sptr->s_sprev = NULL;
	}
else
	{
	free_tail_sptr->s_snext = sptr;
	sptr->s_sprev = free_tail_sptr;
	};

sptr->s_snext = NULL;
free_tail_sptr = sptr;

return;
}

/*--> MPoolDethreadFree: Dethread a record from the free list */
static
void
MPoolDethreadFree(sptrT sptr)
{
if (sptr->s_sprev == NULL)
	free_head_sptr = sptr->s_snext;
else
	sptr->s_sprev->s_snext = sptr->s_snext;

if (sptr->s_snext == NULL)
	free_tail_sptr = sptr->s_sprev;
else
	sptr->s_snext->s_sprev = sptr->s_sprev;

return;
}

/*--> MPoolAppendUsed: append a record to the used list */
static
void
MPoolAppendUsed(sptrT sptr)
{
if (used_tail_sptr == NULL)
	{
	used_head_sptr = sptr;
	sptr->s_sprev = NULL;
	}
else
	{
	used_tail_sptr->s_snext = sptr;
	sptr->s_sprev = used_tail_sptr;
	};

sptr->s_snext = NULL;
used_tail_sptr = sptr;

return;
}

/*--> MPoolDethreadUsed: Dethread a record from the used list */
static
void
MPoolDethreadUsed(sptrT sptr)
{
if (sptr->s_sprev == NULL)
	used_head_sptr = sptr->s_snext;
else
	sptr->s_sprev->s_snext = sptr->s_snext;

if (sptr->s_snext == NULL)
	used_tail_sptr = sptr->s_sprev;
else
	sptr->s_snext->s_sprev = sptr->s_sprev;

return;
}

/*--> MPoolPickMoveset: pick storage for a moveset header */
nonstatic
sptrT
MPoolPickMoveset(void)
{
sptrT sptr;

if (free_head_sptr == NULL)
	{
	/* no free elements; allocate one */

	sptr = MemoryGrab(sizeof(sT));
	MPoolAppendFree(sptr);
	};

/* grab from free list */

sptr = free_tail_sptr;
MPoolDethreadFree(sptr);
MPoolAppendUsed(sptr);

return (sptr);
}

/*--> MPoolDropMoveset: drop storage for a moveset header */
nonstatic
void
MPoolDropMoveset(sptrT sptr)
{
/* move to free list */

MPoolDethreadUsed(sptr);
MPoolAppendFree(sptr);

return;
}

/*--> MPoolInit: one time move pool initialization */
nonstatic
void
MPoolInit(void)
{
free_head_sptr = free_tail_sptr = NULL;
used_head_sptr = used_tail_sptr = NULL;

return;
}

/*--> MPoolTerm: one time move pool termination */
nonstatic
void
MPoolTerm(void)
{
sptrT sptr;

while ((sptr = free_head_sptr) != NULL)
	{
	MPoolDethreadFree(sptr);
	MemoryFree(sptr);
	};

if (used_head_sptr != NULL)
	PrLine("MPoolTerm: warning: used sptr list non-empty");

return;
}

/*<<< mpool.c: EOF */
