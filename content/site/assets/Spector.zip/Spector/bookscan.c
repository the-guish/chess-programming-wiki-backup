/*>>> bookscan.c: opening book scanning routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bookdefs.h"
#include "bookvars.h"

#include "bookscan.h"
#include "bookutil.h"
#include "memutil.h"
#include "util.h"

/*--> ListBookSearch: search the opening book for a move (at root only) */
nonstatic
mptrT
ListBookSearch(void)
{
siT flag, i, n;
mptrT mptr;
liT match, tmatch, smatch;
obcptrT obcptr;

/* set move not found */

mptr = NULL;

/* set scanning flag */

if (!setup && (histn < bkmcdL) && !optnv[optn_nbms])
	flag = 1;
else
	flag = 0;

/* process if search worthwhile */

if (flag)
	{
	/* allocate the census vector storage */

	n = root_sptr->s_count;
	obcptr = ListBookNewOBC(root_sptr);

	/* calculate the census vectors */

	(void) ListBookAutoCensus(obcptr);

	/* count the number of playable matches */

	match = 0;
	for (i = 0; i < n; i++)
		if (((obcptr + i)->obc_pflag == 0) || optnv[optn_poor])
			match += (obcptr + i)->obc_count;

	/* select among alternatives */

	if (match > 0)
		{
		tmatch = TBPsuedoRandomLI() % match;
		smatch = 0;
		i = 0;
		while (mptr == NULL)
			{
			if (((obcptr + i)->obc_count > 0) &&
				(((obcptr + i)->obc_pflag == 0) || optnv[optn_poor]))
				{
				smatch += (obcptr + i)->obc_count;
				if (smatch > tmatch)
					mptr = root_sptr->s_mbase + i;
				};
			i++;
			};
		};

	/* deallocate census vector storage */

	ListBookReleaseOBC(obcptr);
	};

return (mptr);
}

/*<<< bookscan.c: EOF */
