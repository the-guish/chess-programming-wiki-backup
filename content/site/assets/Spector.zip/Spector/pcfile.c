/*>>> pcfile.c: process command routines for most file operations */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "commdefs.h"
#include "commvars.h"

#include "bbmacs.h"
#include "csdefs.h"
#include "epddefs.h"
#include "vpdefs.h"

#include "bb.h"
#include "command.h"
#include "create.h"
#include "csknow.h"
#include "display.h"
#include "epd.h"
#include "fen.h"
#include "file.h"
#include "gms.h"
#include "memutil.h"
#include "mm.h"
#include "moveset.h"
#include "mu.h"
#include "notation.h"
#include "pawn.h"
#include "pcfile.h"
#include "print.h"
#include "reader.h"
#include "san.h"
#include "saveload.h"
#include "select.h"
#include "stat.h"
#include "sysutil.h"
#include "ts.h"
#include "tt.h"
#include "util.h"
#include "voice.h"

/*--> ProcessAFGS: process append file: game status */
nonstatic
void
ProcessAFGS(void)
{
fptrT fp_gsrp;
charptrT fn;
gsT gs;

fn = ipv[1].ip_str;
fp_gsrp = TextFileOpen(fn, "a");
if (fp_gsrp == NULL)
	PrErr("Can't open game status report file");
else
	{
	gs = GameStatus(root_sptr);
	(void) fprintf(fp_gsrp, "afgs: %s (%s)\n", sgsstrv[gs], gsstrv[gs]);
	(void) TextFileClose(fp_gsrp);
	};

return;
}

/*--> ProcessCFDO: process close file: dribble output */
nonstatic
void
ProcessCFDO(void)
{
if (drib_fptr != NULL)
	{
	(void) TextFileClose(drib_fptr);
	drib_fptr = NULL;
	};

return;
}

/*--> ProcessLFER: process load file: event report */
nonstatic
void
ProcessLFER(void)
{
charptrT fn;
liT gn;

fn = ipv[1].ip_str;
if (!RGSingle(fn, &gn))
	PrErr("Can't load event report from file");
else
	if (gn != 1)
		PrNote("No game termination marker in event report");

return;
}

/*--> ProcessLFGC: process load file: game code */
nonstatic
void
ProcessLFGC(void)
{
charptrT fn;

fn = ipv[1].ip_str;
if (!LoadGameCode(fn))
	PrErr("Can't load game from file");

return;
}

/*--> ProcessLFKB: process load file: knowledge base */
nonstatic
void
ProcessLFKB(void)
{
charptrT fn;

fn = ipv[1].ip_str;
if (!CSLoadKnowledge(fn))
	PrErr("Can't load knowledge database from file");

return;
}

/*--> ProcessLFMS: process load file: move sequence */
nonstatic
void
ProcessLFMS(void)
{
charptrT fn;

fn = ipv[1].ip_str;
if (!CommandFileCall(fn))
	PrErr("Can't load move execution sequence from file");

return;
}

/*--> ProcessLFPD: process load file: position data */
nonstatic
void
ProcessLFPD(void)
{
charptrT fn;

fn = ipv[1].ip_str;
if (!CommandFileCall(fn))
	PrErr("Can't load position from file");
else
	{
	TTReset();
	PawnTTReset();
	};

return;
}

/*--> ProcessOFDO: process open file: dribble output */
nonstatic
void
ProcessOFDO(void)
{
charptrT fn;

if (drib_fptr != NULL)
	{
	(void) TextFileClose(drib_fptr);
	drib_fptr = NULL;
	};

fn = ipv[1].ip_str;
drib_fptr = TextFileOpen(fn, "w");
if (drib_fptr == NULL)
	PrErr("Can't open dribble file");

return;
}

/*--> ProcessPFDN: process process file: EPD data normalization */
nonstatic
void
ProcessPFDN(void)
{
siT flag;
castT vcast;
charptrT fn1, fn2;
charptrT s;
fptrT fp1, fp2;
char ev[epdL];
epdptrT epdptr;
eopptrT eopptr;
eovptrT eovptr;
mptrT mptr;
sanT san;

/* set up */

flag = 1;
fp1 = fp2 = NULL;

/* open EPD input file */

if (flag)
	{
	fn1 = ipv[1].ip_str;
	fp1 = TextFileOpen(fn1, "r");
	if (fp1 == NULL)
		{
		PrErr("Can't open input EPD file");
		flag = 0;
		};
	};

/* open EPD output file */

if (flag)
	{
	fn2 = ipv[2].ip_str;
	fp2 = TextFileOpen(fn2, "w");
	if (fp2 == NULL)
		{
		PrErr("Can't open output EPD file");
		flag = 0;
		};
	};

/* perform scan */

while (flag && (fgets(ev, (epdL - 1), fp1) != NULL))
	{
	/* update display */

	DpUpdateAll();

	/* echo input */

	if (optnv[optn_verb])
		PrStr(ev);

	/* decode */

	epdptr = EPDDecode(ev);
	if (epdptr == NULL)
		{
		PrErr("Malformed EPD");
		flag = 0;
		}
	else
		{
		/* set up position on the board */

		EPDRealize(epdptr);

		/* move notation conversion and castling estimation */

		if (optnv[optn_test])
			if (GameStatus(root_sptr) == gs_bust)
				{
				PrErr("Illegal position");
				flag = 0;
				}
			else
				{
				/* save old castling status */

				vcast = epdptr->epd_cast;

				/* castling estimation */

				epdptr->epd_cast = 0;
				if (board.rbv[sq_e1] == cp_wk)
					{
					if (board.rbv[sq_a1] == cp_wr)
						epdptr->epd_cast |= cf_wq;
					if (board.rbv[sq_h1] == cp_wr)
						epdptr->epd_cast |= cf_wk;
					};
				if (board.rbv[sq_e8] == cp_bk)
					{
					if (board.rbv[sq_a8] == cp_br)
						epdptr->epd_cast |= cf_bq;
					if (board.rbv[sq_h8] == cp_br)
						epdptr->epd_cast |= cf_bk;
					};

				/* regenerate if castling availability changed */

				if (epdptr->epd_cast != vcast)
					{
					envn.envn_cast = epdptr->epd_cast;
					CreateSetUp();
					};

				/* SAN conversion for "bm" opsym */

				eopptr = EPDLocateEOP(epdptr, "bm");
				if (eopptr != NULL)
					{
					eovptr = eopptr->eop_headeov;
					while (flag && (eovptr != NULL))
						{
						mptr = MatchMove(eovptr->eov_str, root_sptr);
						if (mptr == NULL)
							{
							PrErr("Unmatchable move");
							flag = 0;
							}
						else
							{
							SANMove(mptr, san);
							EPDReplaceEOVStr(eovptr, san);
							};
						eovptr = eovptr->eov_next;
						};
					};
				};

		/* output normalzed EPD */

		s = EPDEncode(epdptr);
		fprintf(fp2, "%s\n", s);
		MemoryFree(s);
		};

	/* release EPD */

	if (epdptr != NULL)
		EPDReleaseEPD(epdptr);
	};

/* close files */

if (fp1 != NULL)
	TextFileClose(fp1);
if (fp2 != NULL)
	TextFileClose(fp2);

return;
}

/*--> ProcessPFLC: process process file: EPD locate cooks */
nonstatic
void
ProcessPFLC(void)
{
siT flag;
charptrT fn1;
fptrT fp1;
char ev[epdL];
epdptrT epdptr;
eopptrT ideopptr, smeopptr, bmeopptr;

/* set up */

flag = 1;
fp1 = NULL;

/* open EPD input file */

if (flag)
	{
	fn1 = ipv[1].ip_str;
	fp1 = TextFileOpen(fn1, "r");
	if (fp1 == NULL)
		{
		PrErr("Can't open input EPD file");
		flag = 0;
		};
	};

/* perform scan */

while (flag && (fgets(ev, (epdL - 1), fp1) != NULL))
	{
	/* update display */

	DpUpdateAll();

	/* echo input */

	if (optnv[optn_verb])
		PrStr(ev);

	/* decode */

	epdptr = EPDDecode(ev);
	if (epdptr == NULL)
		{
		PrErr("Malformed EPD");
		flag = 0;
		}
	else
		{
		/* test for various locations */

		if ((EPDLocateEOP(epdptr, "mate") != NULL) &&
			((bmeopptr = EPDLocateEOP(epdptr, "bm")) != NULL) &&
			((smeopptr = EPDLocateEOP(epdptr, "sm")) != NULL) &&
			(smeopptr->eop_headeov != NULL) &&
			((ideopptr = EPDLocateEOP(epdptr, "id")) != NULL) &&
			(ideopptr->eop_headeov != NULL))
			{
			/* solved mate located */

			if (EPDLocateEOV(bmeopptr,
				smeopptr->eop_headeov->eov_str) == NULL)
				{
				/* cook located */

				PrStr("Mate cook located: id: ");
				PrStr(ideopptr->eop_headeov->eov_str);
				PrStr("   key: ");
				PrStr(smeopptr->eop_headeov->eov_str);
				PrNL();
				};
			};
		};

	/* release EPD */

	if (epdptr != NULL)
		EPDReleaseEPD(epdptr);
	};

/* close input file */

if (fp1 != NULL)
	TextFileClose(fp1);

return;
}

/*--> ProcessPFMS: process process file: EPD mate search */
nonstatic
void
ProcessPFMS(void)
{
siT flag;
charptrT fn1, fn2;
fptrT fp1, fp2;
char ev[epdL];
epdptrT epdptr;
eopptrT eopptr;
eovptrT eovptr;
charptrT s;
sanT fms_san;
mptrT mptr, rptr;

/* set up */

flag = 1;
fp1 = fp2 = NULL;

/* open EPD input file */

if (flag)
	{
	fn1 = ipv[1].ip_str;
	fp1 = TextFileOpen(fn1, "r");
	if (fp1 == NULL)
		{
		PrErr("Can't open input EPD file");
		flag = 0;
		};
	};

/* open EPD output file */

if (flag)
	{
	fn2 = ipv[2].ip_str;
	fp2 = TextFileOpen(fn2, "w");
	if (fp2 == NULL)
		{
		PrErr("Can't open output EPD file");
		flag = 0;
		};
	};

/* perform scan */

while (flag && (fgets(ev, (epdL - 1), fp1) != NULL))
	{
	/* update display */

	DpUpdateAll();

	/* echo input */

	if (optnv[optn_verb])
		PrStr(ev);

	/* decode */

	epdptr = EPDDecode(ev);
	if (epdptr == NULL)
		{
		PrErr("Malformed EPD");
		flag = 0;
		}
	else
		{
		/* echo ID */

		eopptr = EPDLocateEOP(epdptr, "id");
		if (eopptr == NULL)
			PrLine("No id operation present");
		else
			if (eopptr->eop_headeov == NULL)
				PrLine("Malformed position ID");
			else
				PrTwoStrsNL("Position: ", eopptr->eop_headeov->eov_str);

		/* search for mate opcode */

		eopptr = EPDLocateEOP(epdptr, "mate");
		if (eopptr == NULL)
			{
			/* attempt to solve problem */

			EPDRealize(epdptr);

			/* update display */

			DpUpdateAll();

			/* proceed if position okay */

			if (!GameStatusNormal(root_sptr))
				PrLine("Improper game status");
			else
				{
				mptr = TSTMate(level);
				if (mptr == NULL)
					{
					if (optnv[optn_verb])
						PrLine("No mate located");
					}
				else
					{
					rptr = FindMoveNF(mptr, root_sptr, "ProcessPFMS");

					/* insert/replace supplied move */

					EPDDropIfLocEOP(epdptr, "sm");
					eopptr = EPDCreateEOP("sm");
					SANMove(rptr, fms_san);
					eovptr = EPDCreateEOVSym(fms_san);
					EPDAppendEOV(eopptr, eovptr);
					EPDAppendEOP(epdptr, eopptr);

					/* insert mate depth indication */

					eopptr = EPDCreateEOP("mate");
					eovptr = EPDCreateEOVInt(level);
					EPDAppendEOV(eopptr, eovptr);
					EPDAppendEOP(epdptr, eopptr);

					if (optnv[optn_verb])
						{
						PrStrSI("Located mate in ", level);
						if (level == 1)
							PrStr(" move.");
						else
							PrStr(" moves.");
						PrStrSANNL("  Key move: ", rptr);
						};
					};

				/* node count */

				EPDDropIfLocEOP(epdptr, "acn");
				eopptr = EPDCreateEOP("acn");
				EPDAppendEOV(eopptr, EPDCreateEOVInt(fms_nodes));
				EPDAppendEOP(epdptr, eopptr);

				/* seconds count */

				EPDDropIfLocEOP(epdptr, "acs");
				eopptr = EPDCreateEOP("acs");
				EPDAppendEOV(eopptr, EPDCreateEOVInt(fms_seconds));
				EPDAppendEOP(epdptr, eopptr);

				/* frequency report */

				if (optnv[optn_freq])
					PrFrequencyReport(fms_nodes, fms_seconds);
				};
			}
		else
			PrLine("Problem already solved");

		/* output EPD to result file */

		s = EPDEncode(epdptr);
		fprintf(fp2, "%s\n", s);
		MemoryFree(s);
		};

	/* release EPD */

	if (epdptr != NULL)
		EPDReleaseEPD(epdptr);
	};

/* close files */

if (fp1 != NULL)
	TextFileClose(fp1);
if (fp2 != NULL)
	TextFileClose(fp2);

return;
}

/*--> ProcessPFPA: process process file: EPD position analysis */
nonstatic
void
ProcessPFPA(void)
{
siT flag;
charptrT fn1, fn2;
fptrT fp1, fp2;
char ev[epdL];
epdptrT epdptr;
eopptrT eopptr;
charptrT s;

/* set up */

flag = 1;
fp1 = fp2 = NULL;

/* open EPD input file */

if (flag)
	{
	fn1 = ipv[1].ip_str;
	fp1 = TextFileOpen(fn1, "r");
	if (fp1 == NULL)
		{
		PrErr("Can't open input EPD file");
		flag = 0;
		};
	};

/* open EPD output file */

if (flag)
	{
	fn2 = ipv[2].ip_str;
	fp2 = TextFileOpen(fn2, "w");
	if (fp2 == NULL)
		{
		PrErr("Can't open output EPD file");
		flag = 0;
		};
	};

/* perform scan */

while (flag && (fgets(ev, (epdL - 1), fp1) != NULL))
	{
	/* update display */

	DpUpdateAll();

	/* echo input */

	if (optnv[optn_verb])
		PrStr(ev);

	/* decode */

	epdptr = EPDDecode(ev);
	if (epdptr == NULL)
		{
		PrErr("Malformed EPD");
		flag = 0;
		}
	else
		{
		/* echo ID */

		eopptr = EPDLocateEOP(epdptr, "id");
		if (eopptr == NULL)
			PrLine("No id operation present");
		else
			if (eopptr->eop_headeov == NULL)
				PrLine("Malformed position ID");
			else
				PrTwoStrsNL("Position: ", eopptr->eop_headeov->eov_str);

		/* TBD */

		/* output EPD to result file */

		s = EPDEncode(epdptr);
		fprintf(fp2, "%s\n", s);
		MemoryFree(s);
		};

	/* release EPD */

	if (epdptr != NULL)
		EPDReleaseEPD(epdptr);
	};

/* close files */

if (fp1 != NULL)
	TextFileClose(fp1);
if (fp2 != NULL)
	TextFileClose(fp2);

return;
}

/*--> ProcessPFRO: process process file: EPD remove operations */
nonstatic
void
ProcessPFRO(void)
{
siT flag;
charptrT fn1, fn2;
fptrT fp1, fp2;
char ev[epdL];
epdptrT epdptr;
charptrT s;

/* set up */

flag = 1;
fp1 = fp2 = NULL;

/* open EPD input file */

if (flag)
	{
	fn1 = ipv[1].ip_str;
	fp1 = TextFileOpen(fn1, "r");
	if (fp1 == NULL)
		{
		PrErr("Can't open input EPD file");
		flag = 0;
		};
	};

/* open EPD output file */

if (flag)
	{
	fn2 = ipv[2].ip_str;
	fp2 = TextFileOpen(fn2, "w");
	if (fp2 == NULL)
		{
		PrErr("Can't open output EPD file");
		flag = 0;
		};
	};

/* perform scan */

while (flag && (fgets(ev, (epdL - 1), fp1) != NULL))
	{
	/* update display */

	DpUpdateAll();

	/* echo input */

	if (optnv[optn_verb])
		PrStr(ev);

	/* decode */

	epdptr = EPDDecode(ev);
	if (epdptr == NULL)
		{
		PrErr("Malformed EPD");
		flag = 0;
		}
	else
		{
		/* drop all operations */

		EPDReleaseOperations(epdptr);

		/* output EPD to result file */

		s = EPDEncode(epdptr);
		fprintf(fp2, "%s\n", s);
		MemoryFree(s);
		};

	/* release EPD */

	if (epdptr != NULL)
		EPDReleaseEPD(epdptr);
	};

/* close files */

if (fp1 != NULL)
	TextFileClose(fp1);
if (fp2 != NULL)
	TextFileClose(fp2);

return;
}

/*--> ProcessPFTS: process process file: EPD target search */
nonstatic
void
ProcessPFTS(void)
{
siT flag;
charptrT fn1, fn2;
fptrT fp1, fp2;
char ev[epdL];
charptrT s;
epdptrT epdptr;
eopptrT eopptr;
eovptrT eovptr;
time_t mark_secs, used_secs;
liT mark_node, used_node;
mlstptrT mlstptr, mlstptr1;
siT smflag, fmflag;
sanT san;

/* set up */

flag = 1;
fp1 = fp2 = NULL;

/* open EPD input file */

if (flag)
	{
	fn1 = ipv[1].ip_str;
	fp1 = TextFileOpen(fn1, "r");
	if (fp1 == NULL)
		{
		PrErr("Can't open input EPD file");
		flag = 0;
		};
	};

/* open EPD output file */

if (flag)
	{
	fn2 = ipv[2].ip_str;
	fp2 = TextFileOpen(fn2, "w");
	if (fp2 == NULL)
		{
		PrErr("Can't open output EPD file");
		flag = 0;
		};
	};

/* perform scan */

while (flag && (fgets(ev, (epdL - 1), fp1) != NULL))
	{
	/* update display */

	DpUpdateAll();

	/* echo input */

	if (optnv[optn_verb])
		PrStr(ev);

	/* clear local allocation item */

	target_mlstptr = NULL;

	/* decode input */

	epdptr = EPDDecode(ev);
	if (epdptr == NULL)
		{
		PrErr("Malformed EPD");
		flag = 0;
		}
	else
		{
		/* echo ID */

		eopptr = EPDLocateEOP(epdptr, "id");
		if (eopptr == NULL)
			PrLine("No id operation present");
		else
			if (eopptr->eop_headeov == NULL)
				PrLine("Malformed position ID");
			else
				PrTwoStrsNL("Position: ", eopptr->eop_headeov->eov_str);

		/* set up position */

		EPDRealize(epdptr);

		/* update display */

		DpUpdateAll();

		/* check if position okay */

		if (!GameStatusNormal(root_sptr))
			{
			PrLine("Improper game status");
			flag = 0;
			};

		/* attempt to match moves on target list */

		if (flag)
			{
			eopptr = EPDLocateEOP(epdptr, "bm");
			if (eopptr != NULL)
				{
				eovptr = eopptr->eop_headeov;
				while (flag && (eovptr != NULL))
					if (MatchMove(eovptr->eov_str, root_sptr) == NULL)
						{
						PrTwoStrsNL("Can't match target move: ",
							eovptr->eov_str);
						flag = 0;
						}
					else
						eovptr = eovptr->eov_next;
				};
			};

		/* generate the target move list for search termination test */

		if (flag)
			{
			mlstptr1 = NULL;
			eopptr = EPDLocateEOP(epdptr, "bm");
			if (eopptr != NULL)
				{
				eovptr = eopptr->eop_headeov;
				while (eovptr != NULL)
					{
					/* allocate and initialize move entry */

					mlstptr = (mlstptrT) MemoryGrab(sizeof(mlstT));
					mlstptr->mlst_mptr = (mptrT) MemoryGrab(sizeof(mT));
					*mlstptr->mlst_mptr =
						*MatchMove(eovptr->eov_str, root_sptr);
					mlstptr->mlst_next = NULL;

					/* thread */

					if (mlstptr1 == NULL)
						target_mlstptr = mlstptr;
					else
						mlstptr1->mlst_next = mlstptr;
					mlstptr1 = mlstptr;

					/* next */

					eovptr = eovptr->eov_next;
					};
				};

			if (target_mlstptr != NULL)
				SANSortMoveList(target_mlstptr);
			};

		/* perform search */

		if (flag)
			{
			/* synchronize to the next second */

			SyncSecond();

			/* set starting time and exec mark values */

			mark_secs = time(NULL);
			mark_node = count_node;

			/* search for a move */

			SelectMove();

			/* set used time and exec values */

			used_secs = time(NULL) - mark_secs;
			used_node = count_node - mark_node;

			/* insure time is nonzero */

			if (used_secs == 0)
				used_secs = 1;
			};

		/* report search */

		if (flag)
			{
			/* test result */

			if (LocateListMoveEntry(root_sptr->s_mbest, target_mlstptr) ==
				NULL)
				{
				smflag = 0;
				PrStrSAN("Target move unfound.  Result: ",
					root_sptr->s_mbest);
				PrStr("   Target set: {");
				mlstptr = target_mlstptr;
				while (mlstptr != NULL)
					{
					PrSAN(mlstptr->mlst_mptr);
					mlstptr = mlstptr->mlst_next;
					if (mlstptr != NULL)
						PrBlank();
					};
				PrCharNL('}');
				if (optnv[optn_vsyn])
					{
					(void) VSSpeakPhrase("Target move was not found.");
					(void) VSSpeakStringMove("Result: ", root_sptr->s_mbest);
					};
				}
			else
				{
				smflag = 1;
				PrStrSAN("Target move located.  Result: ",
					root_sptr->s_mbest);
				PrStr("   Target set: {");
				mlstptr = target_mlstptr;
				while (mlstptr != NULL)
					{
					PrSAN(mlstptr->mlst_mptr);
					mlstptr = mlstptr->mlst_next;
					if (mlstptr != NULL)
						PrBlank();
					};
				PrCharNL('}');
				if (optnv[optn_vsyn])
					{
					(void) VSSpeakPhrase("Target move was found.");
					(void) VSSpeakStringMove("Result: ", root_sptr->s_mbest);
					};
				};

			/* forced mate found? */

			if (ct_mate(expectation))
				fmflag = 1;
			else
				fmflag = 0;

			/* output data scan line */

			(void) sprintf(stv, "*srch: %hd   [%02hd/%1hd]",
				smflag, strc, fmflag);
			PrSTV();
			PrStrLI("   secs: ", used_secs);
			PrStrLINL("   node: ", used_node);

			/* adjust/insert EPD result fields */

			EPDDropIfLocEOP(epdptr, "acn");
			eopptr = EPDCreateEOP("acn");
			EPDAppendEOV(eopptr, EPDCreateEOVInt(used_node));
			EPDAppendEOP(epdptr, eopptr);

			EPDDropIfLocEOP(epdptr, "acs");
			eopptr = EPDCreateEOP("acs");
			EPDAppendEOV(eopptr, EPDCreateEOVInt(used_secs));
			EPDAppendEOP(epdptr, eopptr);

			EPDDropIfLocEOP(epdptr, "sm");
			eopptr = EPDCreateEOP("sm");
			ConstructNotation(global_nm, root_sptr->s_mbest, san);
			EPDAppendEOV(eopptr, EPDCreateEOVSym(san));
			EPDAppendEOP(epdptr, eopptr);
			};

		/* output EPD to result file */

		s = EPDEncode(epdptr);
		fprintf(fp2, "%s\n", s);
		MemoryFree(s);
		};

	/* free local allocation item */

	if (target_mlstptr != NULL)
		{
		FreeMoveList(target_mlstptr);
		target_mlstptr = NULL;
		};

	/* free EPD */

	if (epdptr != NULL)
		EPDReleaseEPD(epdptr);
	};

/* close files */

if (fp1 != NULL)
	TextFileClose(fp1);
if (fp2 != NULL)
	TextFileClose(fp2);

return;
}

/*--> ProcessSFCR: process save file: concise report */
nonstatic
void
ProcessSFCR(void)
{
charptrT fn;
fptrT fptr;

fn = ipv[1].ip_str;
fptr = TextFileOpen(fn, "w");
if (fptr == NULL)
	PrErr("Can't open concise report output file");
else
	{
	GMSCR(fptr);
	(void) TextFileClose(fptr);
	};

return;
}

/*--> ProcessSFER: process save file: event report */
nonstatic
void
ProcessSFER(void)
{
charptrT fn;
fptrT fptr;

fn = ipv[1].ip_str;
fptr = TextFileOpen(fn, "w");
if (fptr == NULL)
	PrErr("Can't open event report output file");
else
	{
	GMSER(fptr);
	(void) TextFileClose(fptr);
	};

return;
}

/*--> ProcessSFGC: process save file: game code */
nonstatic
void
ProcessSFGC(void)
{
charptrT fn;

fn = ipv[1].ip_str;
if (!SaveGameCode(fn))
	PrErr("Can't save game to file");

return;
}

/*--> ProcessSFKB: process save file: knowledge base */
nonstatic
void
ProcessSFKB(void)
{
charptrT fn;

fn = ipv[1].ip_str;
if (!CSSaveKnowledge(fn))
	PrErr("Can't save knowledge database to file");

return;
}

/*--> ProcessSFMS: process save file: move sequence */
nonstatic
void
ProcessSFMS(void)
{
charptrT fn;
fptrT fptr;
siT i;
mT m;
sanT san;

/* get filename */

fn = ipv[1].ip_str;

/* save */

fptr = TextFileOpen(fn, "w");
if (fptr == NULL)
	PrErr("Can't open file for writing");
else
	{
	for (i = 0; i < histn; i++)
		{
		(void) fprintf(fptr, "exms ");
		ConvertFromLimitedMove(&(histbase + i)->hist_lm, &m);
		ConstructNotation(global_nm, &m, san);
		(void) fprintf(fptr, "%s\n", san);
		};
	(void) fprintf(fptr, "rtrn\n");
	(void) TextFileClose(fptr);
	};

return;
}

/*--> ProcessSFPD: process save file: position data */
nonstatic
void
ProcessSFPD(void)
{
charptrT fn, s;
fptrT fptr;

/* get filename */

fn = ipv[1].ip_str;

/* save */

fptr = TextFileOpen(fn, "w");
if (fptr == NULL)
	PrErr("Can't open file for writing");
else
	{
	if (lang_get == lang_put)
		(void) fprintf(fptr, "svnl %s\n", langstrv[lang_get]);
	else
		(void) fprintf(fptr,
			"svnl %s %s\n", langstrv[lang_get], langstrv[lang_put]);

	lang_san = lang_get;
	s = FENGenerate();
	lang_san = lang_put;
	(void) fprintf(fptr, "svfe %s\n", s);
	MemoryFree(s);

	(void) fprintf(fptr, "rtrn\n");
	(void) TextFileClose(fptr);
	};

return;
}

/*--> ProcessTFGC: process translate file: games to PGC */
nonstatic
void
ProcessTFGC(void)
{
liT gn;

gn = 0;
RGSetGRTM(grtm_pgc);
if (!RGMultiple(ipv[1].ip_str, ipv[2].ip_str, &gn))
	PrErr("Problems encountered when reading games from file");
if (optnv[optn_verb])
	{
	PrStr("Translated game count: ");
	PrCondOrdLINL(gn);
	};

return;
}

/*--> ProcessTFGE: process translate file: games to EPD */
nonstatic
void
ProcessTFGE(void)
{
liT gn;

gn = 0;
RGSetGRTM(grtm_epd);
if (!RGMultiple(ipv[1].ip_str, ipv[2].ip_str, &gn))
	PrErr("Problems encountered when reading games from file");
if (optnv[optn_verb])
	{
	PrStr("Translated game count: ");
	PrCondOrdLINL(gn);
	};

return;
}

/*--> ProcessTFGG: process translate file: games to games */
nonstatic
void
ProcessTFGG(void)
{
liT gn;

gn = 0;
RGSetGRTM(grtm_pgn);
if (!RGMultiple(ipv[1].ip_str, ipv[2].ip_str, &gn))
	PrErr("Problems encountered when reading games from file");
if (optnv[optn_verb])
	{
	PrStr("Translated game count: ");
	PrCondOrdLINL(gn);
	};

return;
}

/*--> ProcessTFGH: process translate file: games to hex */
nonstatic
void
ProcessTFGH(void)
{
liT gn;

gn = 0;
RGSetGRTM(grtm_hex);
if (!RGMultiple(ipv[1].ip_str, ipv[2].ip_str, &gn))
	PrErr("Problems encountered when reading games from file");
if (optnv[optn_verb])
	{
	PrStr("Translated game count: ");
	PrCondOrdLINL(gn);
	};

return;
}

/*--> ProcessTFGV: process translate file: games to variations */
nonstatic
void
ProcessTFGV(void)
{
liT gn;

gn = 0;
RGSetGRTM(grtm_var);
if (!RGMultiple(ipv[1].ip_str, ipv[2].ip_str, &gn))
	PrErr("Problems encountered when reading games from file");
if (optnv[optn_verb])
	{
	PrStr("Translated game count: ");
	PrCondOrdLINL(gn);
	};

return;
}

/*<<< pcfile.c: EOF */
