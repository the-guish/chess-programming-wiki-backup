/*>>> display.c: console display routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "bbmacs.h"
#include "vpdefs.h"

#include "cfc.h"
#include "clock.h"
#include "display.h"
#include "predvar.h"
#include "print.h"
#include "san.h"
#include "sysutil.h"
#include "util.h"

/**** Locals */

/* short window width */

#define swwL (soccL - (2 * 1))

/* four borders */

#define four_bd (cvpf_b0 | cvpf_b1 | cvpf_b2 | cvpf_b3)

/* window pointers */

static cvpptrT winptrv[winidL];

/* items: board window */

static rbT d_rb;
static siT d_spin;

/* items: clock window */

static liT d_clockv[rcL];
static siT d_clockflag;
static cT d_p0actc;

/* items: general window */

static siT d_cpgw_x, d_cpgw_y;

/* items: predvar window */

static char d_pvar_tv[tL];

/* items: search window */

static cpevT d_expectation;
static siT d_iteration;
static siT d_p0span;
static siT d_p0pick;
static mT d_p0m;
static liT d_nodes;
static liT d_seconds;
static time_t d_prediction;
static lrT d_completion;

/* items: status window */

static siT d_optnv[optnL];

/* items: time window */

static time_t d_time;

#if (0)
/*--> DpDStr: display debug string and get acknowledgment */
static
void
DpDStr(charptrT s)
{
CFCSetXYCVP(winptrv[winid_command], 0, 0);
printf("DEBUG: %s ", s);
fflush(stdout);
getchar();
CFCSetXYCVP(winptrv[winid_command], 0, 0);

return;
}
#endif

/*--> DpCommand: process tokenized console command */
nonstatic
void
DpCommand(void)
{
winidT winid;

/* perform forced update */

CFCDrawWallpaper();

DpApplyAll(winac_copy);
DpApplyAll(winac_regen);
DpApplyAll(winac_redraw);

for (winid = 0; winid < winidL; winid++)
	CFCDrawBorderCVP(winptrv[winid]);

return;
}

/*--> DpWriteChar: write a character to the general window */
nonstatic
void
DpWriteChar(siT c)
{
siT x, y;
cvpptrT cvpptr;
charptrT c0ptr, c1ptr;

cvpptr = winptrv[winid_general];

if (c == '\n')
	{
	d_cpgw_x = 0;
	d_cpgw_y++;
	if (d_cpgw_y == cvpptr->cvp_sir.sir_siq.siq_y)
		{
		d_cpgw_y--;
		c0ptr = cvpptr->cvp_cptr;
		c1ptr = cvpptr->cvp_cptr + cvpptr->cvp_sir.sir_siq.siq_x;
		for (y = 0; y < (cvpptr->cvp_sir.sir_siq.siq_y - 1); y++)
			for (x = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
				*c0ptr++ = *c1ptr++;
		for (x = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
			*c0ptr++ = ascii_sp;
		CFCDrawDataCVP(cvpptr);
		};
	}
else
	{
	CFCPutCharCVP(cvpptr, d_cpgw_x, d_cpgw_y, c);
	d_cpgw_x++;
	};

return;
}

/*--> DpWriteStr: write a string to the general window */
nonstatic
void
DpWriteStr(charptrT s)
{
liT i, length;

length = strlen(s);
for (i = 0; i < length; i++)
	DpWriteChar(*(s + i));

return;
}

/*--> DpReadCommand: read a command line from the command window */
nonstatic
charptrT
DpReadCommand(void)
{
siT i;
cvpptrT cvpptr;

/* set the command window pointer */

cvpptr = winptrv[winid_command];

/* blank the command display */

CFCPutBlanksCVP(cvpptr);
CFCDrawDataCVP(cvpptr);

/* position cursor at buffer start */

CFCSetXYCVP(cvpptr, 0, 0);

/* clear the command vector */

for (i = 0; i < tL; i++)
	rtv[i] = ascii_nul;

/* load the command vector */

fgets(rtv, (tL - 1), stdin);   /* TBD */

/* re-position cursor at buffer start */

CFCSetXYCVP(cvpptr, 0, 0);

return (rtv);
}

/*--> DpReadResponse: read a response line from the command window */
nonstatic
void
DpReadResponse(char tv[tL])
{
siT i;
cvpptrT cvpptr;

/* set the command window pointer */

cvpptr = winptrv[winid_command];

/* blank the command display */

CFCPutBlanksCVP(cvpptr);
CFCDrawDataCVP(cvpptr);

/* position cursor at buffer start */

CFCSetXYCVP(cvpptr, 0, 0);

/* clear the response vector */

for (i = 0; i < tL; i++)
	tv[i] = ascii_nul;

/* load the command vector */

fgets(tv, (tL - 1), stdin);   /* TBD */

/* re-position cursor at buffer start */

CFCSetXYCVP(cvpptr, 0, 0);

return;
}

/*--> DpHandleBoard: handle winid_board */
static
void
DpHandleBoard(winacT winac)
{
cvpptrT cvpptr;
fileT file;
rankT rank;
sqT sq;
cpT cp;
char c_ch, p_ch;
siT x, y;
vcaT vca;

switch (winac)
	{
	case winac_init:
		cvpptr = winptrv[winid_board] =
			CFCNewCVP("Board", four_bd, 1, 1, (fileL * 2), rankL);

		for (file = file_a; file <= file_h; file++)
			for (rank = rank_1; rank <= rank_8; rank++)
				{
				if ((file & bit) == (rank & bit))
					vca = make_vca(0, 0, asc_green, asc_black);
				else
					vca = make_vca(0, 0, asc_white, asc_black);
				CFCPutVCACVP(cvpptr,
					((file * 2) + 0), (rank_8 - rank), vca);
				CFCPutCharCVP(cvpptr,
					((file * 2) + 0), (rank_8 - rank), ascii_sp);
				CFCPutVCACVP(cvpptr,
					((file * 2) + 1), (rank_8 - rank), vca);
				CFCPutCharCVP(cvpptr,
					((file * 2) + 1), (rank_8 - rank), ascii_sp);
				};

		for (sq = sq_a1; sq <= sq_h8; sq++)
			d_rb.rbv[sq] = cp_v0;
		d_spin = 0;

		break;

	case winac_copy:
		cvpptr = winptrv[winid_board];

		for (sq = sq_a1; sq <= sq_h8; sq++)
			if (board.rbv[sq] != d_rb.rbv[sq])
				{
				d_rb.rbv[sq] = board.rbv[sq];
				cvpptr->cvp_flags |= cvpf_rg;
				};

		if (d_spin != optnv[optn_spin])
			{
			d_spin = optnv[optn_spin];
			cvpptr->cvp_flags |= cvpf_rg;
			};

		break;

	case winac_redraw:
		cvpptr = winptrv[winid_board];
		CFCDrawDataCVP(cvpptr);
		cvpptr->cvp_flags &= ~cvpf_rd;
		break;

	case winac_regen:
		cvpptr = winptrv[winid_board];

		for (rank = rank_1; rank <= rank_8; rank++)
			for (file = file_a; file <= file_h; file++)
				{
				cp = d_rb.rbm[rank][file];
				if (os_unix)
					{
					c_ch = asccv[lang_put][cv_c_cpv[cp]];
					p_ch = ascpv[lang_put][cv_p_cpv[cp]];
					}
				else
					if (cp != cp_v0)
						{
						c_ch = asccv[lang_put][cv_c_cpv[cp]];
						p_ch = ascpv[lang_put][cv_p_cpv[cp]];
						}
					else
						if (bb_tstsqrf(csbbv[c_b], rank, file))
							c_ch = p_ch = ':';
						else
							c_ch = p_ch = ascii_sp;

				if (optnv[optn_spin])
					{
					x = (file_h - file) * 2;
					y = rank;
					}
				else
					{
					x = file * 2;
					y = rank_8 - rank;
					};

				if (os_unix)
					{
					if (cp != cp_v0)
						{
						if (bb_tstsqrf(csbbv[c_b], rank, file))
							if (cp_tstw(cp))
								vca = make_vca(0, 0, asc_green, asc_red);
							else
								vca = make_vca(0, 0, asc_green, asc_blue);
						else
							if (cp_tstw(cp))
								vca = make_vca(0, 0, asc_white, asc_red);
							else
								vca = make_vca(0, 0, asc_white, asc_blue);
						}
					else
						{
						if (bb_tstsqrf(csbbv[c_b], rank, file))
							vca = make_vca(0, 0, asc_green, asc_black);
						else
							vca = make_vca(0, 0, asc_white, asc_black);
						};

					CFCPutVCACVP(cvpptr, (x + 0), y, vca);
					CFCPutVCACVP(cvpptr, (x + 1), y, vca);
					};

				CFCPutCharCVP(cvpptr, (x + 0), y, c_ch);
				CFCPutCharCVP(cvpptr, (x + 1), y, p_ch);
				};

		cvpptr->cvp_flags |= cvpf_rd;
		cvpptr->cvp_flags &= ~cvpf_rg;
		break;

	case winac_term:
		CFCReleaseCVP(winptrv[winid_board]);
		break;
	};

return;
}

/*--> DpHandleClock: handle winid_clock */
static
void
DpHandleClock(winacT winac)
{
cvpptrT cvpptr;
vcaT vca;
siT x;
char clks[clksL];
siT i;

switch (winac)
	{
	case winac_init:
		cvpptr = winptrv[winid_clock] =
			CFCNewCVP("Chess clock",
				four_bd, 19, 1, 29, 1);

		vca = make_vca(0, 0, asc_red, asc_cyan);
		for (x = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
			{
			CFCPutVCACVP(cvpptr, x, 0, vca);
			CFCPutCharCVP(cvpptr, x, 0, ascii_sp);
			};

		d_clockv[c_w] = d_clockv[c_b] = 0;
		d_clockflag = 0;
		d_p0actc = c_w;

		break;

	case winac_copy:
		cvpptr = winptrv[winid_clock];

		ClockUpdate();

		if (d_clockv[c_w] != clockv[c_w])
			{
			d_clockv[c_w] = clockv[c_w];
			cvpptr->cvp_flags |= cvpf_rg;
			};

		if (d_clockv[c_b] != clockv[c_b])
			{
			d_clockv[c_b] = clockv[c_b];
			cvpptr->cvp_flags |= cvpf_rg;
			};

		if (d_clockflag != clockflag)
			{
			d_clockflag = clockflag;
			cvpptr->cvp_flags |= cvpf_rg;
			};

		if (d_p0actc != p0actc)
			{
			d_p0actc = p0actc;
			cvpptr->cvp_flags |= cvpf_rg;
			};

		break;

	case winac_redraw:
		cvpptr = winptrv[winid_clock];
		CFCDrawDataCVP(cvpptr);
		cvpptr->cvp_flags &= ~cvpf_rd;
		break;

	case winac_regen:
		cvpptr = winptrv[winid_clock];
		CFCPutBlanksCVP(cvpptr);

		ClockDecode(d_clockv[c_w], clks);
		for (i = 0; i < (clksL - 1); i++)
			CFCPutCharCVP(cvpptr, i, 0, clks[i]);

		if (d_clockflag)
			{
			CFCPutCharCVP(cvpptr, (clksL + 1), 0, '-');
			if (d_p0actc == c_w)
				CFCPutCharCVP(cvpptr, (clksL + 0), 0, '<');
			else
				CFCPutCharCVP(cvpptr, (clksL + 2), 0, '>');
			}
		else
			CFCPutCharCVP(cvpptr, (clksL + 1), 0, '=');

		ClockDecode(d_clockv[c_b], clks);
		for (i = 0; i < (clksL - 1); i++)
			CFCPutCharCVP(cvpptr, (i + clksL + 4), 0, clks[i]);

		cvpptr->cvp_flags |= cvpf_rd;
		cvpptr->cvp_flags &= ~cvpf_rg;
		break;

	case winac_term:
		CFCReleaseCVP(winptrv[winid_clock]);
		break;
	};

return;
}

/*--> DpHandleCommand: handle winid_command */
static
void
DpHandleCommand(winacT winac)
{
cvpptrT cvpptr;
vcaT vca;
siT x;

switch (winac)
	{
	case winac_init:
		cvpptr = winptrv[winid_command] =
			CFCNewCVP("Command", four_bd, 1, 23, swwL, 1);

		vca = make_vca(1, 0, asc_blue, asc_white);
		for (x = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
			{
			CFCPutVCACVP(cvpptr, x, 0, vca);
			CFCPutCharCVP(cvpptr, x, 0, ascii_sp);
			};
		break;

	case winac_copy:
		break;

	case winac_redraw:
		cvpptr = winptrv[winid_command];
		CFCDrawDataCVP(cvpptr);
		cvpptr->cvp_flags &= ~cvpf_rd;
		break;

	case winac_regen:
		cvpptr = winptrv[winid_command];

		cvpptr->cvp_flags |= cvpf_rd;
		cvpptr->cvp_flags &= ~cvpf_rg;
		break;

	case winac_term:
		CFCReleaseCVP(winptrv[winid_command]);
		break;
	};

return;
}

/*--> DpHandleGeneral: handle winid_general */
static
void
DpHandleGeneral(winacT winac)
{
cvpptrT cvpptr;
vcaT vca;
siT x, y;

switch (winac)
	{
	case winac_init:
		cvpptr = winptrv[winid_general] =
			CFCNewCVP("General", cvpf_b0, 0, 13, soccL, 9);

		vca = make_vca(0, 0, asc_cyan, asc_black);
		for (y = 0; y < cvpptr->cvp_sir.sir_siq.siq_y; y++)
			for (x = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
				{
				CFCPutVCACVP(cvpptr, x, y, vca);
				CFCPutCharCVP(cvpptr, x, y, ascii_sp);
				};

		d_cpgw_x = d_cpgw_y = 0;
		break;

	case winac_copy:
		break;

	case winac_redraw:
		cvpptr = winptrv[winid_general];
		CFCDrawDataCVP(cvpptr);
		cvpptr->cvp_flags &= ~cvpf_rd;
		break;

	case winac_regen:
		cvpptr = winptrv[winid_general];

		cvpptr->cvp_flags |= cvpf_rd;
		cvpptr->cvp_flags &= ~cvpf_rg;
		break;

	case winac_term:
		CFCReleaseCVP(winptrv[winid_general]);
		break;
	};

return;
}

/*--> DpHandleLogo: handle winid_logo */
static
void
DpHandleLogo(winacT winac)
{
cvpptrT cvpptr;
vcaT vca;
siT x;

switch (winac)
	{
	case winac_init:
		cvpptr = winptrv[winid_logo] = CFCNewCVP(NULL, 0, 73, 0, 7, 1);

		vca = make_vca(1, 0, asc_blue, asc_white);
		for (x  = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
			{
			CFCPutVCACVP(cvpptr, x, 0, vca);
			CFCPutCharCVP(cvpptr, x, 0, progname[x]);
			};
		break;

	case winac_copy:
		break;

	case winac_redraw:
		cvpptr = winptrv[winid_logo];
		CFCDrawDataCVP(cvpptr);
		cvpptr->cvp_flags &= ~cvpf_rd;
		break;

	case winac_regen:
		cvpptr = winptrv[winid_logo];

		for (x  = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
			CFCPutCharCVP(cvpptr, x, 0, progname[x]);

		cvpptr->cvp_flags |= cvpf_rd;
		cvpptr->cvp_flags &= ~cvpf_rg;
		break;

	case winac_term:
		CFCReleaseCVP(winptrv[winid_logo]);
		break;
	};

return;
}

/*--> DpHandlePredvar: handle winid_predvar */
static
void
DpHandlePredvar(winacT winac)
{
cvpptrT cvpptr;
char pvar_tv[tL];
vcaT vca;
charptrT cptr;
siT i, length, limit;
siT x;

switch (winac)
	{
	case winac_init:
		cvpptr = winptrv[winid_predvar] =
			CFCNewCVP("Predicted variation", cvpf_b0, 0, 11, soccL, 1);

		vca = make_vca(0, 0, asc_magneta, asc_black);
		for (x = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
			{
			CFCPutVCACVP(cvpptr, x, 0, vca);
			CFCPutCharCVP(cvpptr, x, 0, ascii_sp);
			};

		for (i = 0; i < tL; i++)
			d_pvar_tv[i] = '\0';
		break;

	case winac_copy:
		cvpptr = winptrv[winid_predvar];
		PVarEFormat(pvar_tv);
		if (strcmp(d_pvar_tv, pvar_tv) != 0)
			{
			strcpy(d_pvar_tv, pvar_tv);
			cvpptr->cvp_flags |= cvpf_rg;
			};
		break;

	case winac_redraw:
		cvpptr = winptrv[winid_predvar];
		CFCDrawDataCVP(cvpptr);
		cvpptr->cvp_flags &= ~cvpf_rd;
		break;

	case winac_regen:
		cvpptr = winptrv[winid_predvar];

		cptr = cvpptr->cvp_cptr;
		length = strlen(d_pvar_tv);
		limit = min(length, cvpptr->cvp_sir.sir_siq.siq_x);
		for (i = 0; i < limit; i++)
			*cptr++ = d_pvar_tv[i];
		for (i = limit; i < cvpptr->cvp_sir.sir_siq.siq_x; i++)
			*cptr++ = ascii_sp;

		cvpptr->cvp_flags |= cvpf_rd;
		cvpptr->cvp_flags &= ~cvpf_rg;
		break;

	case winac_term:
		CFCReleaseCVP(winptrv[winid_predvar]);
		break;
	};

return;
}

/*--> DpHandleSearch: handle winid_search */
static
void
DpHandleSearch(winacT winac)
{
cvpptrT cvpptr;
vcaT vca;
siT x, y;
liT i, length, limit;
sanT san;
charptrT cptr;
char tv[tL];
stampT stamp;

switch (winac)
	{
	case winac_init:
		cvpptr = winptrv[winid_search] =
			CFCNewCVP("Search",
				four_bd, 19, 4, 29, 5);

		vca = make_vca(0, 0, asc_green, asc_black);
		for (y = 0; y < cvpptr->cvp_sir.sir_siq.siq_y; y++)
			for (x = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
				{
				CFCPutVCACVP(cvpptr, x, y, vca);
				CFCPutCharCVP(cvpptr, x, y, ascii_sp);
				};

		d_expectation = cpev_draw;
		d_iteration = -1;
		d_nodes = d_seconds = 0;
		d_completion = 0.0;
		d_prediction = 0;
		break;

	case winac_copy:
		cvpptr = winptrv[winid_search];

		if (d_expectation != di_expectation)
			{
			d_expectation = di_expectation;
			cvpptr->cvp_flags |= cvpf_rg;
			};

		if (d_iteration != di_iteration)
			{
			d_iteration = di_iteration;
			cvpptr->cvp_flags |= cvpf_rg;
			};

		if (d_nodes != di_nodes)
			{
			d_nodes = di_nodes;
			cvpptr->cvp_flags |= cvpf_rg;
			};

		if (d_seconds != di_seconds)
			{
			d_seconds = di_seconds;
			cvpptr->cvp_flags |= cvpf_rg;
			};

		if (d_p0span != di_p0span)
			{
			d_p0span = di_p0span;
			cvpptr->cvp_flags |= cvpf_rg;
			};

		if (d_p0pick != di_p0pick)
			{
			d_p0pick = di_p0pick;
			cvpptr->cvp_flags |= cvpf_rg;
			};

		if (ByteCmp(&d_p0m, &di_p0m, sizeof(mT)) != 0)
			{
			d_p0m = di_p0m;
			cvpptr->cvp_flags |= cvpf_rg;
			};

		if (d_completion != di_completion)
			{
			d_completion = di_completion;
			cvpptr->cvp_flags |= cvpf_rg;
			};

		if (d_prediction != di_prediction)
			{
			d_prediction = di_prediction;
			cvpptr->cvp_flags |= cvpf_rg;
			};

		break;

	case winac_redraw:
		cvpptr = winptrv[winid_search];
		CFCDrawDataCVP(cvpptr);
		cvpptr->cvp_flags &= ~cvpf_rd;
		break;

	case winac_regen:
		cvpptr = winptrv[winid_search];

		if (d_iteration == 0)
			strcpy(tv, "");
		else
			{
			SANMove(&d_p0m, san);
			sprintf(tv, "I: %hd   C/W: %hd/%hd   M: %s",
				d_iteration, d_p0pick, d_p0span, san);
			};
		length = strlen(tv);
		limit = min(length, cvpptr->cvp_sir.sir_siq.siq_x);
		cptr = cvpptr->cvp_cptr + (cvpptr->cvp_sir.sir_siq.siq_x * 0);
		for (i = 0; i < limit; i++)
			*cptr++ = tv[i];
		for (i = limit; i < cvpptr->cvp_sir.sir_siq.siq_x; i++)
			*cptr++ = ascii_sp;

		if (d_iteration == 0)
			strcpy(tv, "");
		else
			sprintf(tv, "N: %ld   S: %ld", d_nodes, d_seconds);
		length = strlen(tv);
		limit = min(length, cvpptr->cvp_sir.sir_siq.siq_x);
		cptr = cvpptr->cvp_cptr + (cvpptr->cvp_sir.sir_siq.siq_x * 1);
		for (i = 0; i < limit; i++)
			*cptr++ = tv[i];
		for (i = limit; i < cvpptr->cvp_sir.sir_siq.siq_x; i++)
			*cptr++ = ascii_sp;

		if ((d_iteration == 0) || (d_nodes == 0) || (d_seconds == 0))
			strcpy(tv, "");
		else
			{
			strcpy(tv, "F: ");
			FormatSTVLQF(d_nodes, d_seconds);
			strcat(tv, stv);

			strcat(tv, "   P: ");
			FormatSTVLQI(d_seconds, d_nodes);
			strcat(tv, stv);
			};
		length = strlen(tv);
		limit = min(length, cvpptr->cvp_sir.sir_siq.siq_x);
		cptr = cvpptr->cvp_cptr + (cvpptr->cvp_sir.sir_siq.siq_x * 2);
		for (i = 0; i < limit; i++)
			*cptr++ = tv[i];
		for (i = limit; i < cvpptr->cvp_sir.sir_siq.siq_x; i++)
			*cptr++ = ascii_sp;

		if (d_completion == 0.0)
			strcpy(tv, "");
		else
			sprintf(tv, "Completion: %5.3f", d_completion);
		length = strlen(tv);
		limit = min(length, cvpptr->cvp_sir.sir_siq.siq_x);
		cptr = cvpptr->cvp_cptr + (cvpptr->cvp_sir.sir_siq.siq_x * 3);
		for (i = 0; i < limit; i++)
			*cptr++ = tv[i];
		for (i = limit; i < cvpptr->cvp_sir.sir_siq.siq_x; i++)
			*cptr++ = ascii_sp;

		if (d_prediction == 0)
			strcpy(tv, "");
		else
			{
			TimeStampAt(d_prediction, stamp);
			sprintf(tv, "CT: %s", stamp);
			};
		length = strlen(tv);
		limit = min(length, cvpptr->cvp_sir.sir_siq.siq_x);
		cptr = cvpptr->cvp_cptr + (cvpptr->cvp_sir.sir_siq.siq_x * 4);
		for (i = 0; i < limit; i++)
			*cptr++ = tv[i];
		for (i = limit; i < cvpptr->cvp_sir.sir_siq.siq_x; i++)
			*cptr++ = ascii_sp;

		cvpptr->cvp_flags |= cvpf_rd;
		cvpptr->cvp_flags &= ~cvpf_rg;
		break;

	case winac_term:
		CFCReleaseCVP(winptrv[winid_search]);
		break;
	};

return;
}

/*--> DpHandleStatus: handle winid_status */
static
void
DpHandleStatus(winacT winac)
{
cvpptrT cvpptr;
vcaT vca;
siT x, y;
charptrT cptr;
optnT optn;
siT row, col;
siT i;

switch (winac)
	{
	case winac_init:
		cvpptr = winptrv[winid_status] =
			CFCNewCVP("Status",
				four_bd, 50, 4, 29, 5);

		vca = make_vca(0, 0, asc_white, asc_black);
		for (y = 0; y < cvpptr->cvp_sir.sir_siq.siq_y; y++)
			for (x = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
				{
				CFCPutVCACVP(cvpptr, x, y, vca);
				CFCPutCharCVP(cvpptr, x, y, ascii_sp);
				};

		for (optn = 0; optn < optnL; optn++)
			d_optnv[optn] = 0;

		break;

	case winac_copy:
		cvpptr = winptrv[winid_status];

		for (optn = 0; optn < optnL; optn++)
			if (d_optnv[optn] != optnv[optn])
				{
				d_optnv[optn] = optnv[optn];
				cvpptr->cvp_flags |= cvpf_rg;
				};

		break;

	case winac_redraw:
		cvpptr = winptrv[winid_status];
		CFCDrawDataCVP(cvpptr);
		cvpptr->cvp_flags &= ~cvpf_rd;
		break;

	case winac_regen:
		cvpptr = winptrv[winid_status];

		cptr = cvpptr->cvp_cptr;
		for (y = 0; y < cvpptr->cvp_sir.sir_siq.siq_y; y++)
			for (x = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
				*cptr++ = ascii_sp;

		row = 3;
		col = 0;
		optn = 0;
		while (optn < optnL)
			{
			if (d_optnv[optn])
				if (row < cvpptr->cvp_sir.sir_siq.siq_y)
					{
					cptr = cvpptr->cvp_cptr + (col * (optnnameL + 1)) +
						(row * cvpptr->cvp_sir.sir_siq.siq_x);

					for (i = 0; i < optnnameL; i++)
						*cptr++ = *(optnstrv[optn] + i);

					col++;
					if (col ==
						((cvpptr->cvp_sir.sir_siq.siq_x + 1) /
						(optnnameL + 1)))
						{
						col = 0;
						row++;
						};
					};
			optn++;
			};

		cvpptr->cvp_flags |= cvpf_rd;
		cvpptr->cvp_flags &= ~cvpf_rg;
		break;

	case winac_term:
		CFCReleaseCVP(winptrv[winid_status]);
		break;
	};

return;
}

/*--> DpHandleTime: handle winid_time */
static
void
DpHandleTime(winacT winac)
{
cvpptrT cvpptr;
vcaT vca;
siT x;
siT i;
stampT stamp;
time_t newtime;

switch (winac)
	{
	case winac_init:
		cvpptr = winptrv[winid_time] =
			CFCNewCVP("Time",
				four_bd, 50, 1, 19, 1);

		vca = make_vca(0, 0, asc_cyan, asc_red);
		for (x = 0; x < cvpptr->cvp_sir.sir_siq.siq_x; x++)
			{
			CFCPutVCACVP(cvpptr, x, 0, vca);
			CFCPutCharCVP(cvpptr, x, 0, ascii_sp);
			};

		d_time = 0;
		break;

	case winac_copy:
		cvpptr = winptrv[winid_time];
		newtime = time(NULL);
		if (newtime != d_time)
			{
			d_time = newtime;
			cvpptr->cvp_flags |= cvpf_rg;
			};
		break;

	case winac_redraw:
		cvpptr = winptrv[winid_time];
		CFCDrawDataCVP(cvpptr);
		if (os_unix)
			CFCCursorOff();
		cvpptr->cvp_flags &= ~cvpf_rd;
		break;

	case winac_regen:
		cvpptr = winptrv[winid_time];
		TimeStampAt(d_time, stamp);
		for (i = 0; i < (stampL - 1); i++)
			CFCPutCharCVP(cvpptr, i, 0, stamp[i]);
		cvpptr->cvp_flags |= cvpf_rd;
		cvpptr->cvp_flags &= ~cvpf_rg;
		break;

	case winac_term:
		CFCReleaseCVP(winptrv[winid_time]);
		break;
	};

return;
}

/*--> DpApply: apply an action to a window */
nonstatic
void
DpApply(winidT winid, winacT winac)
{
if (disenv_random)
	switch (winid)
		{
		case winid_board:
			DpHandleBoard(winac);
			break;

		case winid_clock:
			DpHandleClock(winac);
			break;

		case winid_command:
			DpHandleCommand(winac);
			break;

		case winid_general:
			DpHandleGeneral(winac);
			break;

		case winid_logo:
			DpHandleLogo(winac);
			break;

		case winid_predvar:
			DpHandlePredvar(winac);
			break;

		case winid_search:
			DpHandleSearch(winac);
			break;

		case winid_status:
			DpHandleStatus(winac);
			break;

		case winid_time:
			DpHandleTime(winac);
			break;
		};

return;
}

/*--> DpApplyAll: apply the same action to all windows */
nonstatic
void
DpApplyAll(winacT winac)
{
winidT winid;

if (disenv_random)
	for (winid = 0; winid < winidL; winid++)
		DpApply(winid, winac);

return;
}

/*--> DpUpdate: handle conditional update for a window */
nonstatic
void
DpUpdate(winidT winid)
{
cvpptrT cvpptr;

if (disenv_random)
	{
	DpApply(winid, winac_copy);

	cvpptr = winptrv[winid];

	if (cvpptr->cvp_flags & cvpf_rg)
		DpApply(winid, winac_regen);

	if (cvpptr->cvp_flags & cvpf_rd)
		DpApply(winid, winac_redraw);
	};

return;
}

/*--> DpUpdateAll: handle conditional update for all windows */
nonstatic
void
DpUpdateAll(void)
{
winidT winid;

if (disenv_random)
	for (winid = 0; winid < winidL; winid++)
		DpUpdate(winid);

return;
}

/*--> DpInit: one time display initialization */
nonstatic
void
DpInit(void)
{
winidT winid;

/* initialize the console */

CFCInit();

/* initialize the random cursor access system */

if (disenv_random)
	{
	/* set up default CFC items */

	CFCEnter();
	CFCDrawWallpaper();

	/* initialize all character viewports */

	DpApplyAll(winac_init);

	/* process the first time border draw */

	for (winid = 0; winid < winidL; winid++)
		CFCDrawBorderCVP(winptrv[winid]);

	/* perform first draw of all character viewports */

	DpApplyAll(winac_redraw);
	};

return;
}

/*--> DpTerm: one time display termination */
nonstatic
void
DpTerm(void)
{
/* close down display */

if (disenv_random)
	{
	DpApplyAll(winac_term);
	CFCExit();
	};

/* terminate the console */

CFCTerm();

return;
}

/*<<< display.c: EOF */
