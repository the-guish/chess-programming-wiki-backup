/*>>> chkmrk.h: subprogram prototypes for cspatt.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CheckMark(sptrT sptr);

/*<<< chkmrk.h: EOF */
