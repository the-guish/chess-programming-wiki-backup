/*>>> command.c: command processing routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include <signal.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "commdefs.h"
#include "commvars.h"

#include "tbdefs.h"
#include "vpdefs.h"

#include "clock.h"
#include "command.h"
#include "display.h"
#include "file.h"
#include "gt.h"
#include "memutil.h"
#include "mm.h"
#include "parm.h"
#include "play.h"
#include "ponder.h"
#include "print.h"
#include "select.h"
#include "tbcache.h"
#include "stat.h"
#include "util.h"

#if (os_mac)
#include <QuickDraw.h>
#include <ToolUtils.h>
#endif

/*--> CommandFileReturn: input command file return */
nonstatic
void
CommandFileReturn(void)
{
commfileptrT p;

/* delink tail */

p = tail_commfile;
tail_commfile = p->commfile_prev;
if (tail_commfile == NULL)
	head_commfile = NULL;

/* deallocate tail */

if (p->commfile_fn != NULL)
	{
	MemoryFree(p->commfile_fn);
	if (p->commfile_fptr != NULL)
		(void) TextFileClose(p->commfile_fptr);
	};
MemoryFree(p);

return;
}

/*--> CommandFileCall: input command file call */
nonstatic
siT
CommandFileCall(charptrT s)
{
siT flag;
commfileptrT p;

/* set default */

flag = 1;

/* allocate */

p = (commfileptrT) MemoryGrab(sizeof(commfileT));
if (s == NULL)
	p->commfile_fn = NULL;
else
	p->commfile_fn = StringGrab(s);
p->commfile_prev = tail_commfile;

/* link at tail */

if (head_commfile == NULL)
	head_commfile = p;
tail_commfile = p;

/* open */

if (s == NULL)
	p->commfile_fptr = stdin;
else
	{
	p->commfile_fptr = TextFileOpen(s, "r");
	if (p->commfile_fptr == NULL)
		{
		flag = 0;
		CommandFileReturn();
		};
	};

return (flag);
}

/*--> CommandFileInit: input command file initialization (one time call) */
nonstatic
void
CommandFileInit(void)
{
/* set up global pointers */

head_commfile = tail_commfile = NULL;

/* set the first record as standard input */

(void) CommandFileCall((charptrT) NULL);

/* set the second record as the startup configuration file */

(void) CommandFileCall(fn_init);

return;
}

/*--> CommandFileTerm: input command file termination (one time call) */
nonstatic
void
CommandFileTerm(void)
{
/* release all records */

while (head_commfile != NULL)
	CommandFileReturn();

return;
}

/*--> CommandRead: command reader (returns global EOF status) */
static
siT
CommandRead(void)
{
siT eofflag, charflag, length;
charptrT cptr;

/* clear the global EOF flag and the character received flag */

eofflag = charflag = 0;

/* read the input */

while (!eofflag && !charflag)
	{
	/* clear the input buffer */

	rtv[0] = ascii_nul;

	/* input prompt */

	if (disenv_scroll && (tail_commfile->commfile_fn == NULL))
		PrStrNoDribble(": ");

	/* read from current input including newline (if any) */

	if (disenv_scroll)
		cptr = fgets(rtv, (tL - 1), tail_commfile->commfile_fptr);
	else
		if (tail_commfile->commfile_fn != NULL)
			cptr = fgets(rtv, (tL - 1), tail_commfile->commfile_fptr);
		else
			cptr = DpReadCommand();

	/* was the end of file encountered? */

	if (cptr == NULL)
		{
		if (tail_commfile->commfile_fn == NULL)
			eofflag = 1;
		CommandFileReturn();
		}
	else
		{
		charflag = 1;

		/* strip trailing newline if present */

		length = strlen(rtv);
		if ((length > 0) && (rtv[length - 1] == '\n'))
			rtv[length - 1] = ascii_nul;
		};
	};

/* conditionally echo command subfile input to standard output */

if (tail_commfile->commfile_fn != NULL)
	if (optnv[optn_verb])
		{
		PrStrNoDribble("> ");
		PrStrNoDribble(rtv);
		PrNLNoDribble();
		};

/* conditionally echo input to dribble file */

if (drib_fptr != NULL)
	if (optnv[optn_echo])
		{
		if (tail_commfile->commfile_fn != NULL)
			(void) fprintf(drib_fptr, "> ");
		else
			(void) fprintf(drib_fptr, ": ");
		(void) fprintf(drib_fptr, "%s\n", rtv);
		if (optnv[optn_flsh])
			(void) TextFileFlush(drib_fptr);
		};

return (eofflag);
}

/*--> CommandTokenizer: command text tokenizer */
static
void
CommandTokenizer(void)
{
siT i, j, c;
charptrT ptr;

/* clear the token count */

tkn = 0;

/* clear the token string vector */

for (i = 0; i < itL; i++)
	tkv[i] = NULL;

/* scan the read text buffer */

i = 0;
c = rtv[i++];
while (c != ascii_nul)
	if (isspace(c))
		c = rtv[i++];
	else
		{
		/* set up for new token */

		ptr = &rtv[i - 1];
		j = 0;

		/* check for quoted string */

		if (c == '"')
			{
			/* handle quoted string */

			ptr++;
			c = rtv[i++];
			while ((c != ascii_nul) && (c != '"'))
				{
				j++;
				c = rtv[i++];
				};
			if (c == '"')
				c = rtv[i++];
			}
		else
			{
			/* handle non-quoted string */

			while ((c != ascii_nul) && (!isspace(c)))
				{
				j++;
				c = rtv[i++];
				};
			};

		/* allocate and copy */

		tkv[tkn] = MemoryGrab(j + 1);
		(void) strncpy(tkv[tkn], ptr, j);
		tkv[tkn][j] = ascii_nul;
		tkn++;
		};

return;
}

/*--> CommandReleaseTokens: deallocate token vector */
static
void
CommandReleaseTokens(void)
{
siT i;

for (i = 0; i < tkn; i++)
	MemoryFree(tkv[i]);

return;
}

/*--> Command: mainline command processor */
nonstatic
void
Command(void)
{
siT flag, match, i, eofflag;
commT commid;
gtcT new_gtc;
gtimT gtim;
mptrT mptr;
liT ct0, ct1;

#if (os_mac)
CursHandle ch_ibeam;
CursHandle ch_watch;
#endif

#if (os_mac)
ch_ibeam = GetCursor(iBeamCursor);
ch_watch = GetCursor(watchCursor);
#endif

/* update clocks at least once per command cycle */

ClockUpdate();

/* refresh */

DpUpdateAll();

/* set SAN input mode (required for parameter handling and move match) */

lang_san = lang_get;

/* read text input */

eofflag = CommandRead();

/* tokenization */

CommandTokenizer();

/* attempt to match command */

if (tkn == 0)
	{
	/* insert an implied "noop" or "exit" command token */

	match = 1;
	tkn = 1;
	commid = (eofflag ? comm_exit : comm_noop);
	tkv[0] = StringGrab(crv[commid].cr_name);
	}
else
	{
	/* attempt to locate command as indicated by the first parameter */

	match = 0;
	commid = 0;
	if (strlen(tkv[0]) == commnameL)
		while (!match && (commid < commL))
			if (strcmp(tkv[0], crv[commid].cr_name) == 0)
				match = 1;
			else
				commid++;
	};

/* process command match */

if (match)
	{
	flag = 1;

	/* assign command name */

	ipv[0].ip_str = crv[commid].cr_name;

	/* check minumum parameter count */

	if (flag)
		if (tkn < crv[commid].cr_minc)
			{
			PrErr("Too few parameters");
			flag = 0;
			};

	/* check maximum parameter count */

	if (flag)
		if (tkn > crv[commid].cr_maxc)
			{
			PrErr("Too many parameters");
			flag = 0;
			};

	/* check parameter syntax */

	if (flag)
		{
		i = 1;
		while (flag && (i < tkn))
			if (!ParameterCheck(commid, i))
				flag = 0;
			else
				i++;
		if (!flag)
			PrErr("Invalid parameter syntax");
		};

	/* evaluate parameters */

	if (flag)
		for (i = 1; i < tkn; i++)
			ParameterEval(commid, i);

	/* perform function call */

	if (flag)
		{
		/* set SAN output mode (most commands only output SAN) */

		lang_san = lang_put;

#if (os_mac)
		/* set watch cursor */

		SetCursor(*ch_watch);
#endif

		/* time executed command */

		ct0 = time(NULL);
		(*crv[commid].cr_func)();
		ct1 = time(NULL);

#if (os_mac)
	/* set I-beam cursor */

	SetCursor(*ch_ibeam);
#endif

		/* report command timing */

		if (optnv[optn_trpt])
			{
			PrTrace("PT");
			PrExpandedTime(ct1 - ct0);
			PrNL();
			};
		};
	};

/* test for game termination input marker */

if (!match && (tkn == 1))
	{
	gtim = GTMatchGTIM(tkv[0]);
	if (gtim != gtim_nil)
		{
		match = 1;
		new_gtc = GTCDetermine(gtim);
		if (!GTCConsistent(new_gtc))
			PrNote("Inconsistent game termination marker");
		GTCSet(new_gtc);
		ClockStop();
		};
	};

/* process user move */

if (!match && (tkn == 1))
	if (GameStatusNormal(root_sptr))
		{
		mptr = MatchMove(tkv[0], root_sptr);
		if (mptr != NULL)
			{
			/* move is matched */

			match = 1;

			/* play user move */

			PlayMove(mptr);

			/* process machine reply */

			if (!optnv[optn_napr])
				if (GameStatusNormal(root_sptr))
					{
					/* select and play a move for the program */

					ProgramMove();

					/* process ponder search check */

					if (optnv[optn_apps])
						do
							{
							PonderSearch();
							}
						while (ponder_match);
					};
			};
		}
	else
		{
		PrPlayer(actc);
		PrLine(" has no moves.");
		};

/* process error */

if (!match)
	PrErr("Unrecognized input; enter \"help\" for help");

/* deallocate token vector */

CommandReleaseTokens();

/* release tablebase cache */

TBCacheFlush();

return;
}

/*<<< command.c: EOF */
