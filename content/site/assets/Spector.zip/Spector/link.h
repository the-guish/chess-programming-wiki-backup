/*>>> link.h: subprogram prototypes for link.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT LinkGet(channelT channel, byteptrT bptr, liT length);
siT LinkPut(channelT channel, byteptrT bptr, liT length);
liT LinkStat(channelT channel);
siT LinkOpen(channelT channel, ccpT ccp, rscT rsc);
siT LinkClose(channelT channel);
void LinkInit(void);
void LinkTerm(void);

/*<<< link.h: EOF */
