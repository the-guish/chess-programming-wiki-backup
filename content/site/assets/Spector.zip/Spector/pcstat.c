/*>>> pcstat.c: print status */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "optndefs.h"
#include "optnvars.h"

#include "clock.h"
#include "pcstat.h"
#include "print.h"
#include "stat.h"

/*--> ProcessSTAT: print status display */
nonstatic
void
ProcessSTAT(void)
{
gsT gs;
optnT optn;
char clks[clksL];

/* active color and clocks */

PrStr("Active player    : ");
PrPlayer(p0actc);
ClockUpdate();
ClockDecode(clockv[c_w], clks);
PrTwoStrs(" [", clks);
PrBlank();
ClockUpdate();
ClockDecode(clockv[c_b], clks);
PrTwoStrs(clks, "] ");
if (clockflag)
	PrLine("running");
else
	PrLine("stopped");

/* game status */

gs = GameStatus(root_sptr);
PrStrGameStatusNL("Game status      : ", gs);

/* full move number and set up code */

PrStr("Move number      : ");
PrCondOrdSI(envn.envn_fmvn);
if (setup)
	PrStr(" (position set-up)");
PrNL();

/* castling availability */

PrStr("Castling         :");
if (!envn.envn_cast)
	PrLine(" none");
else
	{
	if (envn.envn_cast & cf_wk)
		{
		(void) sprintf(stv, " %c%c",
			asccv[lang_san][c_w], ascpv[lang_san][p_k]);
		PrSTV();
		};
	if (envn.envn_cast & cf_wq)
		{
		(void) sprintf(stv, " %c%c",
			asccv[lang_san][c_w], ascpv[lang_san][p_q]);
		PrSTV();
		};
	if (envn.envn_cast & cf_bk)
		{
		(void) sprintf(stv, " %c%c",
			asccv[lang_san][c_b], ascpv[lang_san][p_k]);
		PrSTV();
		};
	if (envn.envn_cast & cf_bq)
		{
		(void) sprintf(stv, " %c%c",
			asccv[lang_san][c_b], ascpv[lang_san][p_q]);
		PrSTV();
		};
	PrNL();
	};

/* en passant capture square */

PrStr("En passant square: ");
if (envn.envn_epsq == sq_nil)
	PrLine("none");
else
	{
	PrSq(envn.envn_epsq);
	PrNL();
	};

/* halfmove clock */

PrStr("Halfmove count   : ");
PrCondOrdSINL(envn.envn_hmvc);

/* options */

PrStr("Active options   :");
for (optn = 0; optn < optnL; optn++)
	if (optnv[optn])
		{
		PrBlank();
		PrStr(optnstrv[optn]);
		};
PrNL();

/* playing level */

PrStr("Playing level    : ");
PrCondOrdSI(level);
if (level == (plyL - 1))
	PrStr(" (maximum)");
else
	if (level == 0)
		PrStr(" (minimum)");
PrStr(" (search strategies: [");
PrStr(strtstrv[strtv[c_w]]);
PrStr("/");
PrStr(strtstrv[strtv[c_b]]);
PrLine("])");

/* time control */

PrStr("Time control     : ");
PrCurrentTimeControl();

/* languages */

if (lang_get == lang_put)
	PrTwoStrsNL("Language         : ", langstrv[lang_get]);
else
	{
	PrStr("Languages        : ");
	(void) sprintf(stv, "input: %s   output: %s",
		langstrv[lang_get], langstrv[lang_put]);
	PrSTVNL();
	};

return;
}

/*<<< pcstat.c: EOF */
