/*>>> voice.h: subprogram prototypes for voice.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT VSSpeakPhrase(charptrT s);
siT VSSpeakMove(mptrT mptr);
siT VSSpeakStringMove(charptrT s, mptrT mptr);
siT VSSpeakMate(siT n);

/*<<< voice.h: EOF */
