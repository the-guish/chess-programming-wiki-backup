/*>>> voice.c: external voice synthesizer routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "defs.h"
#include "vars.h"

#include "link.h"
#include "memutil.h"
#include "voice.h"
#include "vsan.h"

#if (os_mac)
#include <Speech.h>
#endif

/**** Locals */

/* the usual voice channel */

#define vox_chan 0

/*--> VSSpeakOpen: open speaking channel */
static
siT
VSSpeakOpen(void)
{
siT flag;

#if (os_unix)
flag = LinkOpen(vox_chan, ccp_synthesis, rsc_microvox);
#else
flag = 1;
#endif

return (flag);
}

/*--> VSSpeakClose: close speaking channel */
static
siT
VSSpeakClose(void)
{
siT flag;

#if (os_unix)
flag = LinkClose(vox_chan);
#else
flag = 1;
#endif

return (flag);
}

/*--> VSSpeakPhrase: speak a phase (final merge point) */
nonstatic
siT
VSSpeakPhrase(charptrT s)
{
siT flag;
liT length;
charptrT b;

flag = 1;

/* set up strings */

length = strlen(s);

b = (charptrT) MemoryGrab(length + 2);
#if (os_unix)
(void) strcpy(b, s);
(void) strcat(b, "\r");
#else
*(b + 0) = (tiT) length;
(void) strcpy(&b[1], s);
#endif

flag = 0; /* TBD VSSpeakOpen(); */

#if (os_unix)
if (flag)
	flag = LinkPut(vox_chan, (byteptrT) b, strlen(b));
#else
if (flag)
	((voidptrT) b);
#endif

MemoryFree(b);

if (flag)
	flag = VSSpeakClose();

return (flag);
}

/*--> VSSpeakTwoStrings: speak two strings as a phrase */
static
siT
VSSpeakTwoStrings(charptrT s0, charptrT s1)
{
siT flag;
charptrT b;

b = (charptrT) MemoryGrab(strlen(s0) + strlen(s1) + 1);
(void) strcpy(b, s0);
(void) strcat(b, s1);
flag = VSSpeakPhrase(b);
MemoryFree(b);

return (flag);
}

/*--> VSSpeakMove: speak a move (as the only part of a phrase) */
nonstatic
siT
VSSpeakMove(mptrT mptr)
{
siT flag;
vsanT vsan;

VSANMove(mptr, vsan);
flag = VSSpeakTwoStrings(vsan, ".");

return (flag);
}

/*--> VSSpeakStringMove: speak a string and a move as a phrase */
nonstatic
siT
VSSpeakStringMove(charptrT s, mptrT mptr)
{
siT flag;
vsanT vsan;
charptrT b, t;

VSANMove(mptr, vsan);
t = ".";
b = (charptrT) MemoryGrab(strlen(s) + strlen(vsan) + strlen(t) + 1);
(void) strcpy(b, s);
(void) strcat(b, vsan);
(void) strcat(b, t);
flag = VSSpeakPhrase(b);
MemoryFree(b);

return (flag);
}

/*--> VSSpeakMate: speak an announced mate as a phrase */
nonstatic
siT
VSSpeakMate(siT n)
{
siT flag;
char tv[tL];

(void) sprintf(tv, "Check mate in %hd moves.", n);
flag = VSSpeakPhrase(tv);

return (flag);
}

/*<<< voice.c: EOF */
