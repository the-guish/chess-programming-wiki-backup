/*>>> mpool.h: subprogram prototypes for mpool.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

sptrT MPoolPickMoveset(void);
void MPoolDropMoveset(sptrT sptr);
void MPoolInit(void);
void MPoolTerm(void);

/*<<< mpool.h: EOF */
