/*>>> tact.c: tactical assessment routines */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "defs.h"
#include "vars.h"

#include "tact.h"

/*--> TacticalExtend: determine if a tactical extension is indicated */
nonstatic
siT
TacticalExtend(void)
{
siT flag;

/* currently disabled */

flag = 0;

return (flag);
}

/*<<< tact.c: EOF */
