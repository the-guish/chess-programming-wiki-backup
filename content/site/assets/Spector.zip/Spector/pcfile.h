/*>>> pcfile.h: subprogram prototypes for pcfile.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void ProcessAFGS(void);
void ProcessCFDO(void);
void ProcessCFEX(void);
void ProcessLFER(void);
void ProcessLFGC(void);
void ProcessLFKB(void);
void ProcessLFMS(void);
void ProcessLFPD(void);
void ProcessOFDO(void);
void ProcessOFEX(void);
void ProcessPFDN(void);
void ProcessPFLC(void);
void ProcessPFMS(void);
void ProcessPFPA(void);
void ProcessPFRO(void);
void ProcessPFTS(void);
void ProcessSFCR(void);
void ProcessSFER(void);
void ProcessSFGC(void);
void ProcessSFKB(void);
void ProcessSFMS(void);
void ProcessSFPD(void);
void ProcessTFGC(void);
void ProcessTFGE(void);
void ProcessTFGG(void);
void ProcessTFGH(void);
void ProcessTFGV(void);

/*<<< pcfile.h: EOF */
