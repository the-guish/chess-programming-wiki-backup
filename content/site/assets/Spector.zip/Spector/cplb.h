/*>>> cplb.h: subprogram prototypes for cplb.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

void CPLBCommand(void);

/*<<< cplb.h: EOF */
