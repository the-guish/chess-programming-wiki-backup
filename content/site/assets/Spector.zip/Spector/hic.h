/*>>> hic.h: subprogram prototypes for hic.c */

/*===================  Spector: A Chessplaying Program  ===================*/
/*==  Copyright (C) 1996 by Steven James Edwards.  All rights reserved.  ==*/

siT HICGen(charptrT basename);
liptrT HICProbe(void);
mptrT HICBookSearch(void);

/*<<< hic.h: EOF */
